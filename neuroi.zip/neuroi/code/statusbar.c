/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

//============================================================================
//						Status bar window routines
//============================================================================


#include "statusbar.h"

//=============================================================================================
//                         define status window
//=============================================================================================
LRESULT CALLBACK StatusWndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);

HWND RegisterStatusWindow(HWND hwnd, HINSTANCE hInst){

	WNDCLASS wc;
	HWND hwndStatusBar;

	memset(&hwndStatusBar,0,sizeof(HWND));

	memset(&wc,0,sizeof(WNDCLASS));

	wc.style = CS_HREDRAW|CS_VREDRAW |CS_DBLCLKS ;
	wc.lpfnWndProc = (WNDPROC)StatusWndProc;
	wc.hInstance = hInst;
	wc.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
	wc.lpszClassName = "StatusWndClass";
	wc.lpszMenuName = NULL;

	if (RegisterClass(&wc)){
		hwndStatusBar=CreateWindow("StatusWndClass","",
		WS_VISIBLE|WS_BORDER|WS_CHILD,
		0,0,0,0,
		hwnd,
		(HMENU)1,                                                               //child window identifier
		hInst,
		NULL);


		ShowWindow(hwndStatusBar,SW_SHOW);
	}
    return hwndStatusBar;
}




//=============================================================================================
//                     callback for status bar
//=============================================================================================
LRESULT CALLBACK StatusWndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	HDC hDC;
	PAINTSTRUCT PaintStruct;
	TEXTMETRIC	tm;
	RECT Rect;

	switch(msg)
	{
	case WM_PAINT:
		hDC=BeginPaint(hwnd, &PaintStruct);
        ShowStatusInfo(gMainPict.x, gMainPict.y, gMainPict.slice, gImage.filename,
                       gMainPict.X, gMainPict.Y, gMainPict.Z, gImage.volumes,
                       gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0, 1.0);
		EndPaint(hwnd, &PaintStruct);
	break;

	case WM_CREATE:
	case WM_SIZE:
		hDC=GetDC(hwnd);
		if (GetTextMetrics(hDC,&tm)){
			GetClientRect(GetParent(hwnd),&Rect);
			//the size of the status window is set here.
			MoveWindow(hwnd, 0, (int)(Rect.bottom-5*tm.tmHeight), Rect.right, (int)(5*tm.tmHeight),TRUE);
		}
		ReleaseDC(hwnd,hDC);
	break;


	default:	return DefWindowProc(hwnd,msg,wParam,lParam);
	}

	return 0;
}



//=============================================================================================
//                       Show the status information
//=============================================================================================
int ShowStatusInfo(int x, int y, int z, char filename[], int X, int Y, int Z, int volumes,
                       float dx, float dy, float dz, float x0, float y0, float z0, float intensity){

    char txt[256];
    HDC hDCSB;
	TEXTMETRIC tm;
	int width, height;

    if ((!X) || (!Y) || (!Z)) return 0;


	hDCSB=GetDC(hStatusBar);

	GetTextMetrics(hDCSB,&tm);
	width=tm.tmAveCharWidth;
	height=tm.tmHeight;


	SetBkMode(hDCSB, OPAQUE);
	SetBkColor(hDCSB,RGB(190,190,190));



    sprintf(txt,"slice %d  volume=%d/%d Intensity=%g           ",z, volumes*z/Z+1, volumes, intensity);
    SetTextColor(hDCSB,RGB(200,0,0));
	TextOut(hDCSB,10,0,txt,strlen(txt));


    sprintf(txt,"Image size={%d, %d, %d} ", X, Y, Z);
    SetTextColor(hDCSB,RGB(0,0,0));
	TextOut(hDCSB,45*width,0,txt,strlen(txt));


    sprintf(txt,"Voxel size={%1.2f, %1.2f, %1.2f} ", dx, dy, dz);
    SetTextColor(hDCSB,RGB(0,0,200));
	TextOut(hDCSB,75*width,0,txt,strlen(txt));

	sprintf(txt,"{%1.2f, %1.2f, %1.2f}mm     ", dx*x-x0, dy*y-y0, dz*z-z0);
    SetTextColor(hDCSB,RGB(0,0,200));
	TextOut(hDCSB,140,3*height,txt,strlen(txt));

	sprintf(txt,"{x=%d, y=%d}   ", x, y);
    SetTextColor(hDCSB,RGB(0,0,200));
	TextOut(hDCSB,10,3*height,txt,strlen(txt));

	SetTextColor(hDCSB,RGB(100,0,100));
	TextOut(hDCSB,10,1.5*height,filename,strlen(filename));


    ReleaseDC(hStatusBar,hDCSB);
    return 1;
}

