/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"
#include "numerical.h"



//=============================================================================================
//                      handle the WM_COMMAND messages
//=============================================================================================
int WMcommandFunc(HWND hwnd, WPARAM wParam, LPARAM lParam)
{

    RECT rect=GetImageRect(hwnd, hStatusBar, hToolBar);
    static int FirstLoad=1;
    int load;
    int slice, slicespv;
    char txt[MAX_PATH];


    switch(LOWORD(wParam))
    {

    case IDM_FILE_OPEN:
    case IDM_OPEN_TEMPLATE:
    case IDM_OPEN_TALAIRACH:
    case IDM_OPEN_GM:
        load=0;
        if (gImage.X) FirstLoad=0;//if an image was loaded from the command line
        if (LOWORD(wParam)==IDM_FILE_OPEN) load= LoadAnalyzeOrNifti(hwnd, &gImage, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE));  //FILE
        else if (LOWORD(wParam)==IDM_OPEN_TEMPLATE)
        {
            sprintf(txt,"%s\\brain.img",gOptions.TemplateDir);
            load=LoadFromFileName(hwnd, txt, &gImage, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE));
            if (!load)
            {
                sprintf(txt,"%s\\brain.nii",gOptions.TemplateDir);
                load=LoadFromFileName(hwnd, txt, &gImage, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE));
                if (!load) MessageBox(hwnd,"Please set the template directory","",MB_OK|MB_ICONWARNING);
            }
        }
        else if (LOWORD(wParam)==IDM_OPEN_TALAIRACH)
        {
            sprintf(txt,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
            load = LoadFromFileName(hwnd, txt, &gImage,0);
        }
        else
        {
            sprintf(txt,"%s\\GM\\CRTgmTal.nii", ExecutableDirectory);
            load = LoadFromFileName(hwnd, txt, &gImage,0);
        }
        if (load)
        {
            ReleaseOverlays();
            if (FirstLoad)
            {
                //add buttons to the ToolBar now that an image has been loaded
                AddToolbarButtons(hToolBar, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE));

                //Enable the menu items
                EnableMainMenuItem(hwnd);
            }
            SetMenuItemState(hwnd, MF_ENABLED);
            InitialisePicture(hwnd, &gImage, &gMainPict);
            SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
            FirstLoad=0;
            FreeROIMemory();
        }
        break;




    case IDM_FILE_SAVEAS_CHAR:
            SaveAsCharImage(&gImage,1);
        break;
    case IDM_FILE_SAVEAS_FLOAT:
        if (gImage.DataType==DT_FLOAT)
        {
            MessageBox(hwnd,"Data type is already float","",MB_OK);
            break;
        }
        gImage.DataType=DT_FLOAT;
        if (!SaveAs(&gImage)) MessageBox(hwnd, "File Not Saved","",MB_OK|MB_ICONWARNING);
        break;



    case IDM_SAVE_BITMAP:
        DrawBitmapEx((HDC)NULL, hwnd, &gMainPict, hStatusBar, SAVE_BITMAP_AS);
        SendMessage(hwnd, WM_COMMAND, ID_REFRESH,0);
        break;
    case IDM_SAVE_ALL_BITMAPS:
        for (gMainPict.slice=0; gMainPict.slice<gImage.Z; gMainPict.slice++)
        {
            SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
            if (IsMenuItemChecked(hwnd, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwnd, &gMainPict, &gImage);
            DrawBitmapEx((HDC)NULL, hwnd, &gMainPict, hStatusBar, SAVE_BITMAP);
            SendMessage(hwnd, WM_COMMAND, ID_REFRESH,0);
        }
        break;




    case IDM_FILE_SAVE:
        if (!Save(&gImage)) MessageBox(hwnd, "File Not Saved","",MB_OK|MB_ICONWARNING);
        break;



    case IDM_FILE_SAVEAS:
        if (!SaveAs(&gImage)) MessageBox(hwnd, "File Not Saved","",MB_OK|MB_ICONWARNING);
        break;



    case IDM_LOAD_OVERLAY:
        LoadOverlayImage(hwnd, 0, &gImage);
        break;
    case IDM_ADD_OVERLAY:
        LoadOverlayImage(hwnd, 1, &gImage);
        break;






    case ID_ZOOM_UP:                                                        //zoom up
        gMainPict.zoom*=1.3;
        if (gMainPict.zoom>MAX_ZOOM) gMainPict.zoom=MAX_ZOOM;              //dont allow too much zoom
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;

    case ID_ZOOM_DOWN:                                                      //zoom down
        gMainPict.zoom/=1.3;
        if (gMainPict.zoom<0.1) gMainPict.zoom=0.1;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;










    case IDM_FILTER_GAUSS_1:                                                //FILTERS
        FilterImage(&gImage, GAUSSIAN, 1.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_GAUSS_2:
        FilterImage(&gImage, GAUSSIAN, 2.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_GAUSS_3:
        FilterImage(&gImage, GAUSSIAN, 3.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_GAUSS_4:
        FilterImage(&gImage, GAUSSIAN, 4.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_MEDIAN:
        FilterImage(&gImage, MEDIAN, 0.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_SOBEL2D:
        FilterImage(&gImage, SOBEL2D, 0.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;
    case IDM_FILTER_SOBEL3D:
        FilterImage(&gImage, SOBEL3D, 0.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_FILTER_MGS:
        FilterImage(&gImage, MAXIMALSUPRESSION, 0.0);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
        break;

    case IDM_MULTI_VOLUME_FILTER:
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else MultiVolumeSimilarityFilter(gImage.img, gImage.X, gImage.Y, gImage.Z/gImage.volumes, gImage.volumes, gImage.dx, gImage.dy, gImage.dz, 1);
        break;















    case IDM_SHOW_CROSS:                                                    //SETTINGS
    case IDM_COLOUR_BACKGROUND:
    case IDM_SHOW_ROIS:
    case IDM_SHOW_ROI_NUMBERS:
    case IDM_LINK_PROGRAMS:
        if (IsMenuItemChecked(hwnd, LOWORD(wParam)))	CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_UNCHECKED);
        else CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_SHOW_OVERLAYS:
        if (IsMenuItemChecked(hwnd, LOWORD(wParam)))	CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_UNCHECKED);
        else CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        break;
    case IDM_SHOW_SOLID_OVERLAYS:
        if (IsMenuItemChecked(hwnd, LOWORD(wParam)))	CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_UNCHECKED);
        else CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        break;
    case IDM_OVERLAY_RGB:
    case IDM_OVERLAY_RBG:
    case IDM_OVERLAY_GRB:
    case IDM_OVERLAY_GBR:
    case IDM_OVERLAY_BRG:
    case IDM_OVERLAY_BGR:
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_RGB,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_RBG,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_GRB,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_GBR,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_BRG,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)IDM_OVERLAY_BGR,MF_UNCHECKED);
        CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        break;
    case IDM_VIEW_PLANES:
        /*if (gImage.volumes>1)
        {
            if ( !IsMenuItemChecked(hwnd, LOWORD(wParam)) &&
                    MessageBox(hwnd, "This image is multi volumed. Are you sure you would like to view planes?", "", MB_YESNO)==IDNO) break;
        }*/
        if (IsMenuItemChecked(hwnd, LOWORD(wParam)))	CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_UNCHECKED);
        else CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_STANDARD_SCALE:
        gImage.scale=1.0;
        gImage.offset=0.0;
        break;
    case IDM_LOAD_WITH_STANDARD_SCALE:
        if (IsMenuItemChecked(hwnd, LOWORD(wParam)))	CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_UNCHECKED);
        else CheckMenuItem(GetMenu(hwnd),(UINT)LOWORD(wParam),MF_CHECKED);
        break;
    case IDM_CROSS_HAIR:
        gMainPict.CrossHairSize+=2;
        if (gMainPict.CrossHairSize>7) gMainPict.CrossHairSize=1;
        SendMessage(hwnd, WM_COMMAND, ID_REFRESH,0);
        break;
    case IDM_TEMPLATE_DIR:
        GetDirectoryName(hwnd, gOptions.TemplateDir, "Select Template Directory");
        SaveOptions(ExecutableDirectory, &gOptions);
        break;
    case ID_SET_ORIGIN:
        gImage.x0=gMainPict.x*gImage.dx;
        gImage.y0=gMainPict.y*gImage.dy;
        gImage.z0=gMainPict.slice*gImage.dz;
        break;
    case IDM_OPTIONS:
        hwndOptions=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_OPTIONS),hwnd,OptionsDlg);
        break;













    case IDM_ROTATE_X:                                                      //REFORMAT
        Rotate90(&gImage,X_AXIS);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_ROTATE_Y:
        Rotate90(&gImage,Y_AXIS);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_ROTATE_Z:
        Rotate90(&gImage,Z_AXIS);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_FORCE_1x1x1:
        ReSizeImage(&gImage, 1.0, 1.0, 1.0);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_MIRROR:
        MirrorImage(&gImage);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_SLICE_ORDER:
        ArrangeByVolume(&gImage);
        break;
    case IDM_VOLUME_ORDER:
        ArrangeBySlice(&gImage);
        break;





    case IDM_HISTOGRAM_EQUALISE:                                            //PROCESS
        HistogramEqualiseImage(&gImage);
        break;










    case IDM_RANGE_TOOL:
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else                                                     //TOOLS
        {
            hRange=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_RANGE),hwnd,HighlightDlg);
        }
        break;
    case IDM_EDIT_HEADER:
        hHeader=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_HEADER),hwnd,HeaderDlg);
        gMainPict.ML.valid=0;
        ReleaseOverlays();
        break;
    case IDM_AUTO_THRESHOLD_BRAIN:
        gMainPict.ML.valid=0;
        gImage.changed=AutoRemoveNoisyBackground(hwnd, &gImage,1);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_AUTO_THRESHOLD:
        gMainPict.ML.valid=0;
        gImage.changed=AutoRemoveNoisyBackground(hwnd, &gImage,0);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_INTERLEAVE:
        InterleaveImages(hwnd, &gImage);
        InitialisePicture(hwnd, &gImage, &gMainPict);//make sure picture is initialised for new interleaved image
        if (gImage.volumes>1) CheckMenuItem(GetMenu(hwnd),IDM_VIEW_PLANES,MF_UNCHECKED);
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_APPEND_VOLUMES:
        AppendImages(hwnd, &gImage);
        InitialisePicture(hwnd, &gImage, &gMainPict);//make sure picture is initialised for new volumes
        if (gImage.volumes>1) CheckMenuItem(GetMenu(hwnd),IDM_VIEW_PLANES,MF_UNCHECKED);
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_SEPARATE_VOLUMES:
        ReleaseOverlays();
        SeparateVolumes(&gImage);
        break;
    case IDM_ADD_IMAGES:
        AddImages(hwnd, &gImage);
        InitialisePicture(hwnd, &gImage, &gMainPict);//make sure picture is initialised for new volumes
        if (gImage.volumes>1) CheckMenuItem(GetMenu(hwnd),IDM_VIEW_PLANES,MF_UNCHECKED);
        ReleaseOverlays();
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_COREGISTER:
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else
        {
            ReleaseOverlays();
            hCoregisterDlg=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_COREGISTER),hwnd, CoregisterDlg);
        }
        break;
    case IDM_MV_COREGISTER:
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else
        {
            MultiVolumeRegistration(hwnd, &gImage);
        }
        break;
    case IDM_FIT_T1:
        FitT1ToIR(hwnd, &gImage, 0, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE), 0, 0);
        gMainPict.ML.valid=0;
        break;
    case IDM_FIT_T1_MLE:
        FitT1ToIR(hwnd, &gImage, 0, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE), 1, 0);
        gMainPict.ML.valid=0;
        break;
    case IDM_FIT_T1S:
        FitT1ToIR(hwnd, &gImage, 1, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE),0, 0);
        gMainPict.ML.valid=0;
        break;
    case IDM_T1_CALIBRATION:
        hT1Dlg=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_T1_CALIBRATION),hwnd, CalibrateT1);
        break;
    case IDM_LARGE_INHOMOGENEITY:
        CorrectInhomogeneityUsingClassification(hwnd, &gImage, 4, 5);
        gMainPict.ML.valid=0;
        break;
    case IDM_APPLY_MASK:
        ApplyBinaryMaskToImage(hwnd, &gImage,1);
        break;
    case IDM_APPLY_NOT_MASK:
        ApplyBinaryMaskToImage(hwnd, &gImage,0);
        break;
    case IDM_CONVERT_TO_BINARY:
        ConvertToBinary(hwnd, &gImage);
        break;
    case IDM_COMPUTE_MTR:
        ComputeMTR(hwnd, &gImage, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE));
        gMainPict.ML.valid=0;
        break;
    case IDM_COMPUTE_MTR_MVOL:
        ComputeMTRfromTwoVolume(hwnd, &gImage, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE));
        gMainPict.ML.valid=0;
        break;
    case IDM_CONVERT_TO_MIP:
        ReleaseOverlays();
        ConvertToMaxIntensityProjection(&gImage);
        gMainPict.ML.valid=0;
        break;
    case IDM_UNWRAP:
        UnwrapPhaseWrappedImage(hwnd, &gImage, 0);
        break;
    case IDM_UNWRAP_CORRECT:
        UnwrapPhaseWrappedImage(hwnd, &gImage, 1);
        break;
    case  IDM_LOCALALE:
        hLocalALE=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_LOCAL_ALE),hwnd, LocalALEDlg);
        break;

    case  IDM_CLUSTERZ:
        hClusterZ = CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_CLUSTERZ),hwnd, ClusterZDlg);
        break;

    case IDM_COORDINATE_DENSITY_ANALYSIS:
        hCDAnalysis = CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_COORDINATE_DENSITY),hwnd, CDA_Dlg);
        break;
    case  IDM_CBMAN:
        hCBMAN = CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_CBMAN),hwnd, CBMAN_Dlg);
        break;
    case IDM_SORT_BY_STUDYID:
        OrderExperimentsBy(STUDYID_LABEL);
    break;
    case IDM_SORT_BY_CONDITION:
        OrderExperimentsBy(CONDITION_LABEL);
    break;
    case IDM_SORT_BY_CONTRAST:
        OrderExperimentsBy(CONTRAST_LABEL);
    break;
    case  IDM_CORRELATE_Z_SCORES:
        hCorrelateZ=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_Z_CORRELATION),hwnd, CorrelateZDlg);
    break;
    case IDM_DIFFERENCE:
        hDifference=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_DIFFERENCE),hwnd, DifferenceDlg);
        break;




    case IDM_AUTO_ROIS:                                                         //ROIs
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else hAutoROI=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_AUTO_ROI),hwnd,AutoROIsDlg);
        break;
    case IDM_MANUAL_ROIS:
        hManualROI=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_MANUAL_ROI),
                                hwnd,ManualROIsDlg);
        break;

    case IDM_LOAD_ROIS:
        LoadROIs(gMainPict.X, gMainPict.Y, gMainPict.Z);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;

    case IDM_SAVE_ROIS:
        SaveROIs(0, gImage.X, gImage.Y, gImage.Z);
        break;

    case IDM_CLEAR_ROIS:
        FreeROIMemory();
        SendMessage(hwnd, WM_COMMAND, ID_REFRESH,0);
        break;
    case IDM_SAVE_ROI_BINARY:
        SaveROIobject(&gImage, 1);
        break;
    case IDM_SAVE_OBJECTS:
        SaveROIobject(&gImage, 0);
        break;
    case IDM_ROIs_TO_OBJECTS:
        ReNumberROIObjects(hwnd, &gImage);
        break;
    case IDM_ROI_OBJECT_OVERLAP:
        CompareROIobjectMasks(hwnd, &gImage);
        break;
    case IDM_CONVERT_OBJECT_TO_ROIs:
        ConvertObjectToROIs(hwnd, &gImage);
        break;
    case IDM_TRANSFORM_ROIs:
        TransformROIs(hwnd, &gImage);
        gMainPict.ML.valid=0;
        break;







    case ID_REFRESH:
        InvalidateRect(hwnd, &rect, 0);
        break;
    case ID_REDRAW:
        FillPictureStruct(hwnd, &gMainPict, &gImage);
        InvalidateRect(hwnd, &rect, (BOOL)lParam);
        break;














    case IDM_STATS:  //ANALYSIS
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else hStatsDlg=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_STATS),hwnd,StatsDlg);
        break;
    case IDM_CORD_AREA:
        if (!IsImageScalar(gImage.DataType))
        {
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
        }
        else ComputeMeanCordArea(&gImage);
        break;
    case IDM_COMBINE_HISTOGRAMS:
        CombineHistogramFiles();
        break;









        //=============DWI=============

    case IDM_TENSOR_ROIS:
        hTensorROI=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_TENSOR_ROI),
                                hwnd,TensorROIsDlg);
        break;
    case IDM_DTI_GT:
        GTtractography(hwnd, &gImage, TENSOR_MODE);
        break;
    case IDM_DTI_GT_CONNECT_ROIs:
        GT_ConnectROIs(hwnd, &gImage, TENSOR_MODE);
        break;
        break;
    case IDM_GENERATE_ORTHOGONAL_DIRECTIONS:
        hGenerateOrthogonalDirections=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_GENERATE_ORTHOGONAL_DIRECTIONS),
                                      hwnd, GenerateOrthogonalDirectionsDlg);
        break;
    case IDM_CHECK_ORTHONORMALITY:
        CheckOrthonormalisationOfVectors(hwnd);
        break;
    case IDM_GENERATE_BMAT_FILE:
        CreateBmatrixFile();
        break;
    case IDM_CHECK_DIRECTIONS:
        CheckDirections(hwnd);
        break;
    case IDM_FODF_ROIS:
        hTensorROI=CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_FODF_ROI),
                                hwnd, FodfROIsDlg);
        break;
    case IDM_FODF_GT:
        GTtractography(hwnd, &gImage, FODF_MODE);
        break;
    case IDM_FODF_GT_CONNECT_ROIs:
        GT_ConnectROIs(hwnd, &gImage, FODF_MODE);
        break;
    case IDM_PROCESS_DWI:
        ProcessDWI(hwnd, &gImage);
        break;
    case IDM_ARRANGE_DWI_VOLUMES://rearange DWI so there is only 1 b=0 and it is the first volume
        RearrangeDWI(&gImage);
        break;
    case IDM_CONVERT_FSL_V_RGB:
        ConvertFSL_V_to_RGB(hwnd, &gImage);
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;


        //  TEMPLATE FUNCTIONS
        //Chnaged to nonparametric functions 20/04/11
    case IDM_EXTRACT_BRAIN:
        ExtractBrainByTemplateRegistrationNonParametric(hwnd, &gImage, REGISTRATION_PARAMETERS_ORDER2);
        break;
    case IDM_REGISTER_TEMPLATE:
        TemplateRegistration(hwnd, &gImage);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_REGISTER_TEMPLATE_BRAINSTEM:
        TemplateBrainstemRegistration(hwnd, &gImage);
        gMainPict.ML.valid=0;
        SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
        break;
    case IDM_CLASSIFY_WM_GM_CSF:
        Classify_WM_GM_CSF_NonParametric(hwnd, &gImage, 1, REGISTRATION_PARAMETERS_ORDER2);
        break;
    case IDM_CLASSIFY_WM_GM_CSF_INHOMOGENEITY:
        CorrectInhomogeneityUsingTemplateNonParametric(hwnd, &gImage, 1);
        break;
    case IDM_INHOMOGENEITY_CLASS:
        CorrectInhomogeneityUsingTemplateNonParametric(hwnd, &gImage, 0);
        gMainPict.ML.valid=0;
        break;



    case IDM_BATCH_FITt1:
        BatchFitT1(hwnd, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE), 0, 0);
        break;
    case IDM_BATCH_FITt1_SMOOTH:
        BatchFitT1(hwnd, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE), 1, 0);
        break;
    case IDM_BATCH_FITt1_MLE:
        BatchFitT1(hwnd, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE), 0, 1);
        break;
    case IDM_BATCH_INHOMOGENEITY:                                     //BATCH JOBS
        BatchReduceInhomogeneity(hwnd, 0);
        break;
    case IDM_BATCH_INHOMOGENEITY_TEMPLATE:
        BatchReduceInhomogeneity(hwnd, 1);
        break;
    case IDM_BATCH_PHASE_UNWRAP:
        BatchUnwrapPhaseImages(hwnd, 0);
        break;
    case IDM_BATCH_PHASE_UNWRAP_CORRECT:
        BatchUnwrapPhaseImages(hwnd, 1);
        break;
    case IDM_BATCH_PROCESS_DWI:
        BatchProcessDWI(hwnd, ExecutableDirectory);
        break;
    case IDM_BATCH_EXTRACT_BRAIN:
        BatchExtractBrain(hwnd);
        break;
    case IDM_BATCH_REMOVE_BACKGROUND:
        BatchRemoveBackground(hwnd);
        break;
    case IDM_BATCH_REGISTER_RIGID:
    case IDM_BATCH_REGISTER_AFFINE:
    case IDM_BATCH_REGISTER_NONLIN:
        BatchRegister(hwnd, LOWORD(wParam),0, PRE_PROCESS_SMOOTH);
        break;
    case IDM_BATCH_REGISTER_RIGID_SAME_BASE:
    case IDM_BATCH_REGISTER_AFFINE_SAME_BASE:
    case IDM_BATCH_REGISTER_NONLIN_SAME_BASE:
        BatchRegister(hwnd, LOWORD(wParam),1, PRE_PROCESS_SMOOTH);
        break;
    case IDM_BATCH_REGISTER_RIGID_UNSMOOTH:
    case IDM_BATCH_REGISTER_AFFINE_UNSMOOTH:
    case IDM_BATCH_REGISTER_NONLIN_UNSMOOTH:
        BatchRegister(hwnd, LOWORD(wParam),0, 1.0);
        break;
    case IDM_BATCH_REGISTER_RIGID_SAME_BASE_UNSMOOTH:
    case IDM_BATCH_REGISTER_AFFINE_SAME_BASE_UNSMOOTH:
    case IDM_BATCH_REGISTER_NONLIN_SAME_BASE_UNSMOOTH:
        BatchRegister(hwnd, LOWORD(wParam),1, 1.0);
        break;
    case IDM_BATCH_APPLY_TRANSFORM:
        BatchApplyTransformation(hwnd);
        break;
    case IDM_BATCH_REGISTER_TO_TEMPLATE:
        BatchRegisterToTemplate(hwnd, 0);
        break;
    case IDM_BATCH_REGISTER_TO_TEMPLATE_BRAINSTEM:
        BatchRegisterToTemplate(hwnd, 1);
        break;



    case IDM_ABOUT:                                                         //HELP
        CreateDialog((HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE) ,MAKEINTRESOURCE(DLG_ABOUT),hwnd,AboutDlg);
        break;



    case IDM_TEST:
        TestFisher(hwnd);
        //SaveROImeans(&gImage);
        //ConvertRGBtoGrey(&gImage);
        //TestRandomVoxelALE(&gImage);
        //TestBinomialCDF();
        //WeightedVolume(&gImage);
        // TestPvalueOfCoordinate();
        //TestSigmoidpm1();
        //TestCorrelationSampleSize();
        //TestBunaryLogisticRegression();
        //TestShortTalairachLabel(hwnd);
        //TestPvalueOfCoordinate();
        //TestNextPermutation();

        //make sure the selected voxel is in the first volume
        if (gMainPict.volumes)
        {
            slicespv=gMainPict.Z/gMainPict.volumes;
            slice=gMainPict.slice;
            while(slice>slicespv)
            {
                slice-=slicespv;
            }
            gMainPict.ML.valid=0;
        }
        gMainPict.ML.valid=0;
        break;



    case IDM_FILE_EXIT:
        SendMessage(hwnd, WM_DESTROY, 0,0);                                //send a WM_QUIT to the message queue
        break;

    }
    return 0;
}





//=============================================================================================
//                  handle the WM_KEYDOWN messages for key presses
//                  the specific key message is in wParam
//=============================================================================================
int WMcommandKeyFuncs(HWND hwndMain, HWND hwndStatus, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, struct Image *image)
{

    char txt[1024];


    switch(wParam)
    {
    case VK_LEFT:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        if (gMainPict.FocalPlane==PLANE_1)
        {
            gMainPict.slice--;
            if (gMainPict.slice<0) gMainPict.slice=(int)gImage.Z-1;
        }
        else if (gMainPict.FocalPlane==PLANE_2)
        {
            gMainPict.y--;
            if (gMainPict.y<0) gMainPict.y=gMainPict.Y-1;
        }
        else if (gMainPict.FocalPlane==PLANE_3)
        {
            gMainPict.x--;
            if (gMainPict.x<0) gMainPict.x=gMainPict.X-1;
        }
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_RIGHT:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        if (gMainPict.FocalPlane==PLANE_1)
        {
            gMainPict.slice++;
            if (gMainPict.slice>=gMainPict.Z) gMainPict.slice=0;
        }
        else if (gMainPict.FocalPlane==PLANE_2)
        {
            gMainPict.y++;
            if (gMainPict.y>=gMainPict.Y) gMainPict.y=0;
        }
        else if (gMainPict.FocalPlane==PLANE_3)
        {
            gMainPict.x++;
            if (gMainPict.x>=gMainPict.X) gMainPict.x=0;
        }
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_DOWN:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        gMainPict.slice-=gImage.Z/5;
        if (gMainPict.slice<0) gMainPict.slice=(int)gImage.Z-1;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_UP:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        gMainPict.slice+=gImage.Z/5;
        if (gMainPict.slice>=(int)gImage.Z) gMainPict.slice=0;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_RETURN:
        if (hAutoROI) SendMessage(hAutoROI, WM_COMMAND, ID_ACCEPT_ROI, 0);
        if (hManualROI) SendMessage(hManualROI, WM_COMMAND, ID_ACCEPT_ROI, 0);
        break;

    case VK_HOME:
        gMainPict.slice=0;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_END:
        gMainPict.slice=gImage.Z-1;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_NEXT:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        if (!gImage.volumes) break;
        gMainPict.slice+=gImage.Z/gImage.volumes;
        if (gMainPict.slice>=(int)gImage.Z) gMainPict.slice-=gImage.Z;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_PRIOR:
        if (gMainPict.NeedsRedraw) break;
        gMainPict.NeedsRedraw=1;
        if (!gImage.volumes) break;
        gMainPict.slice-=gImage.Z/gImage.volumes;
        if (gMainPict.slice<0) gMainPict.slice+=gImage.Z;
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);
        break;

    case VK_F1:
        sprintf(txt,"Left:\tback 1 slice\n");
        sprintf(txt,"%sRight:\tforward 1 slice\n\n",txt);
        sprintf(txt,"%sUp:\tforward several slices\n",txt);
        sprintf(txt,"%sDown:\tbackward several slices\n\n",txt);
        sprintf(txt,"%sPage up:\t\tforward 1 volume\n",txt);
        sprintf(txt,"%sPage down:\tbackward 1 volume\n\n",txt);
        sprintf(txt,"%sEnd:\tgo to last slice\n",txt);
        sprintf(txt,"%sHome:\tgo to first slice\n\n",txt);
        sprintf(txt,"%sShift + mouse move:\tLocal zoom under mouse\n\n",txt);
        sprintf(txt,"%sRight mouse button + mouse move:\tchange image brightness\n\n",txt);
        sprintf(txt,"%sMiddle mouse button:\tview planes\n\n",txt);
        sprintf(txt,"%sshift + x:\tRotate 90 about X\n",txt);
        sprintf(txt,"%sshift + y:\tRotate 90 about Y\n",txt);
        sprintf(txt,"%sshift + z:\tRotate 90 about Z\n\n",txt);
        sprintf(txt,"%sF2:\tShow header\n",txt);
        MessageBox(NULL,txt,"Key help",MB_OK);
        break;
    case VK_F2:
        ShowHeader(&gImage);
        break;

    case VK_ESCAPE:
        if (hAutoROI) SendMessage(hAutoROI, WM_COMMAND, VK_ESCAPE,0);
        if (hManualROI) SendMessage(hManualROI, WM_COMMAND, VK_ESCAPE,0);
        break;
    case VK_DELETE:
        if (hAutoROI) SendMessage(hAutoROI, WM_COMMAND, VK_DELETE,0);
        if (hManualROI) SendMessage(hManualROI, WM_COMMAND, VK_DELETE,0);
        break;
    }
    return 0;
}




//=============================================================================================
//                            handle the mouse messages for key presses
//6-May-09 Added *pict and *image instead of using gImage & gMainPict
//=============================================================================================
int ProcessWMmouseFuncs(HWND hwndMain, HWND hwndStatus, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, struct Image *image)
{

    int x,y;
    int width;
    static int xi,yi;
    short int xim, yim, zim;

    width=(*pict).ML.x1-(*pict).ML.x0+1;
    switch (msg)
    {

    case WM_MOUSEWHEEL:
        if ((short int)HIWORD(wParam)>0) SendMessage(hwndMain, WM_KEYDOWN, VK_LEFT,0);
        else SendMessage(hwndMain, WM_KEYDOWN, VK_RIGHT,0);
        break;

    case WM_LBUTTONDOWN:
        xi=(int)LOWORD(lParam)-(*pict).xpos;
        yi=(int)HIWORD(lParam)-(*pict).ypos;
        PictureToImage(pict,  xi, yi, &(*pict).x, &(*pict).y, &(*pict).slice, IsMenuItemChecked(hwndMain, IDM_VIEW_PLANES));
        SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
        if (IsMenuItemChecked(hwndMain, IDM_LINK_PROGRAMS)) SendCursorPositionToEachInstance(hwndMain, pict, image);

        if ((wParam&MK_SHIFT) && ((*pict).zoom))
        {
            xi/=(*pict).zoom;
            yi/=(*pict).zoom;
            if (xi>=width && xi<2*width)
            {
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
            }
            if (xi>=2*width && xi<(*pict).width)
            {
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_X,0);
                SendMessage(hwndMain, WM_COMMAND, IDM_ROTATE_Y,0);
            }
        }
        break;

    case WM_MBUTTONDOWN:
        SendMessage(hwndMain, WM_COMMAND, IDM_VIEW_PLANES,0);
        break;

    case WM_RBUTTONDOWN:
        xi=LOWORD(lParam);
        yi=HIWORD(lParam);
        break;


    case WM_MOUSEMOVE:
        x=(int)LOWORD(lParam)-(*pict).xpos;
        y=(int)HIWORD(lParam)-(*pict).ypos;

        (*pict).FocalPlane=PLANE_1;
        if (IsMenuItemChecked(hwndMain, IDM_VIEW_PLANES))
        {
            if ((x/(*pict).zoom)>=width && (x/(*pict).zoom)<2*width) (*pict).FocalPlane=PLANE_2;
            if ((x/(*pict).zoom)>=2*width && (x/(*pict).zoom)<(*pict).width) (*pict).FocalPlane=PLANE_3;
        }

        PictureToImage(pict, x, y, &xim, &yim, &zim, IsMenuItemChecked(hwndMain, IDM_VIEW_PLANES));
        ShowStatusInfo(xim, yim, zim, (*image).filename,(*image).X, (*image).Y, (*image).Z, (*image).volumes,
                       (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0, ImageIntensity(image, xim, yim, zim));

        if (wParam==MK_RBUTTON)                                             //change contrast
        {
            x=GET_X_LPARAM(lParam);
            y=GET_Y_LPARAM(lParam);

            (*pict).saturation+=(double)(x-xi)*2/X_SCREEN_SIZE;

            if ((*pict).saturation<0.0001) (*pict).saturation=0.0001;
            if ((*pict).saturation>1.0) (*pict).saturation=1.0;

            (*pict).LowThresh+=(double)(y-yi)/Y_SCREEN_SIZE;


            if ((*pict).LowThresh>0.99) (*pict).LowThresh=0.99;
            if ((*pict).LowThresh>=((*pict).saturation-0.001)) (*pict).LowThresh=(*pict).saturation-0.001;
            if ((*pict).LowThresh<0.0) (*pict).LowThresh=0.0;

            SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,0);
            xi=x;
            yi=y;
        }

        if (LOWORD(wParam)==MK_CONTROL)
        {
            PictureToImage(pict, x, y, &(*pict).x, &(*pict).y, &(*pict).slice, IsMenuItemChecked(hwndMain, IDM_VIEW_PLANES));
            (*pict).LocalZoom=1;
            SendMessage(hwndMain, WM_COMMAND, ID_REFRESH,0);
        }
        else
        {
            if ((*pict).LocalZoom)
            {
                (*pict).LocalZoom=0;
                SendMessage(hwndMain, WM_COMMAND, ID_REFRESH,0);
            }
            else (*pict).LocalZoom=0;
        }

        break;

    }

    if (hAutoROI) SendMessage(hAutoROI, msg, wParam, lParam);                   //handle the mouse input for Auto ROIs
    if (hManualROI) SendMessage(hManualROI, msg, wParam, lParam);               //handle the mouse input for Manual ROIs
    if (hStatsDlg) SendMessage(hStatsDlg, msg, wParam, lParam);                 //handle the mouse input for Stats
    if (hTensorROI) SendMessage(hTensorROI, msg, wParam, lParam);               //handle the mouse input for Tensor based ROI
    //also for fODF based ROIs

    return 0;
}




//==============================================================================
//       Send Left Mouse Click To Each Instance Of NeuRoi2
//  sends coordinates in mm relative to the reference location
//==============================================================================
int SendCursorPositionToEachInstance(HWND hwndMain, struct Picture *picture, struct Image *image)
{

    HWND hNext;
    int count=0;
    char *nullstring='\0';
    static struct ThreeVector V;
    static COPYDATASTRUCT coordinates;
    //HDC hDC=GetDC(hwndMain);
    //char txt[256];

    V.x=(*image).dx*(*picture).x - (*image).x0;
    V.y=(*image).dy*(*picture).y - (*image).y0;
    V.z=(*image).dz*(*picture).slice - (*image).z0;

    coordinates.dwData=1234;
    coordinates.cbData=sizeof(struct ThreeVector);
    coordinates.lpData=(PVOID)&V;

    //sprintf(txt,"%f %f %f",V.x, V.y, V.z);
    //TextOut(hDC,200,300,txt,strlen(txt));

    hNext=hwndMain;
    do
    {
        hNext=FindWindowEx((HWND)NULL, hNext, CLASSNAME, nullstring);
        if (hNext && (hNext!=hwndMain))
        {
            //send the message to make the orthogonal planes the same in other instances
            SendMessageTimeout(hNext, WM_COPYDATA, (WPARAM)ID_SET_ORTHOGONAL_COORDINATES, (LPARAM)(LPVOID) &coordinates,
                                                SMTO_BLOCK, 100,NULL);
            //SendMessage(hNext, WM_COPYDATA, (WPARAM)ID_SET_ORTHOGONAL_COORDINATES, (LPARAM)(LPVOID) &coordinates);
            count++;
        }
    }
    while(hNext);

    //ReleaseDC(hwndMain,hDC);
    return count;
}

/*

//==============================================================================
//       Send Left Mouse Click To Each Instance Of NeuRoi2
//==============================================================================
int SendCursorPositionToEachInstance(HWND hwndMain, struct Picture *picture, struct Image *image)
{

    HWND hNext;
    int count=0;
    char *nullstring='\0';
    LPARAM lParam;

    //make lParam the unique voxel number
    lParam=(*picture).x + (*picture).y*(*image).X + (*picture).slice*(*image).X*(*image).Y;

    hNext=hwndMain;
    do
    {
        hNext=FindWindowEx((HWND)NULL, hNext, CLASSNAME, nullstring);
        if (hNext)
        {
            //send the message to make the orthogonal planes the same in other instances
            PostMessage(hNext, WM_COMMAND, (WPARAM)ID_SET_ORTHOGONAL_COORDINATES, lParam);
            count++;
        }
    }
    while(hNext);

    return count;
}
*/


//==============================================================================
//       Set the Orthogonal planes to be equal amongst instances of NeuRoi
//==============================================================================
int SetOrthogonalPlanes(HWND hwnd, RECT rect, struct Picture *picture, struct Image *image, LPARAM lParam)
{

    int x,y,z;

    if ( !((*image).X) || !((*image).Y) ) return 0;

    ComputeXYZfromVoxel(image, lParam, &x, &y, &z);

    (*picture).x=x;
    (*picture).y=y;
    (*picture).slice=z;

    FillPictureStruct(hwnd, picture, image);
    InvalidateRect(hwnd, &rect, 0);

    return 1;
}


//==============================================================================
//       Set the Orthogonal planes to be equal amongst instances of NeuRoi
//==============================================================================
int SetOrthogonalPlanesFromExternalCall(HWND hwnd, RECT rect, struct Picture *picture, struct Image *image, COPYDATASTRUCT *coordinates)
{

    struct ThreeVector *V=NULL;
    //char txt[256];
    //HDC hDC=GetDC(hwnd);

    if ( !((*image).X) || !((*image).Y) ) return 0;

    if ((*coordinates).dwData!=1234) return 0;

    V=(struct ThreeVector *)(*coordinates).lpData;

    //sprintf(txt,"%f %f %f",(*V).x,(*V).y,(*V).z);
    //TextOut(hDC,200,100,txt,strlen(txt));

    (*picture).x=((*V).x + (*image).x0)/(*image).dx + 0.5;
    (*picture).y=((*V).y + (*image).y0)/(*image).dy + 0.5;
    (*picture).slice=((*V).z + (*image).z0)/(*image).dz + 0.5;

    FillPictureStruct(hwnd, picture, image);
    InvalidateRect(hwnd, &rect, 0);

    //ReleaseDC(hwnd, hDC);

    return 1;
}






//==============================================================================
//                    the on-load new image procedure
//==============================================================================
int InitialisePicture(HWND hwnd, struct Image *image, struct Picture *picture)
{



    (*picture).xpos=X_ORIGIN;
    (*picture).ypos=Y_ORIGIN;
    (*picture).zoom=2.0;
    (*picture).slice=0;
    (*picture).ML.valid=0;
    (*picture).CrossHairSize=5;
    (*picture).saturation=1.0;
    (*picture).LowThresh=0.0;

    if ( (*image).volumes>1 ) CheckMenuItem(GetMenu(hwnd),IDM_VIEW_PLANES, MF_UNCHECKED);

    return 1;
}












//=============================================================================================
//                           -Is a menu item checked?
//                           -returns 1 or 0
//=============================================================================================
int IsMenuItemChecked(HWND hwnd, int ID)
{

    MENUITEMINFO mii;

    mii.cbSize=sizeof(MENUITEMINFO);
    mii.fMask=MIIM_STATE;
    GetMenuItemInfo(GetMenu(hwnd),(UINT)ID,FALSE,&mii);

    return mii.fState&MFS_CHECKED;
}

















//=============================================================================================
//                           About dialog callback function
//=============================================================================================
INT_PTR CALLBACK AboutDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    switch(msg)
    {
    case WM_CLOSE:
        EndDialog(hwnd,0);
        break;
    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case IDOK:
            EndDialog(hwnd,1);
            break;
        }
        break;
    }
    return 0;
}

















//=======================================================================================
//                      ENABLE MENU ITEMS
//=======================================================================================
int EnableMainMenuItem(HWND hwnd)
{

    HMENU hMenu;

    hMenu=GetMenu(hwnd);

    EnableMenuItem(hMenu,IDM_FILE_SAVE,MF_ENABLED);
    EnableMenuItem(hMenu,IDM_SAVE_BITMAP,MF_ENABLED);
    EnableMenuItem(hMenu,IDM_SAVE_ALL_BITMAPS,MF_ENABLED);


    return 1;
}







//=======================================================================================
//                      ENABLE MENU ITEMS
//=======================================================================================
int SetMenuItemState(HWND hwnd, int state)
{

    HMENU hMenu=GetMenu(hwnd);

    if (state==MF_GRAYED) SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_FILE_OPEN, 0);
    else SendMessage(hToolBar, TB_ENABLEBUTTON, IDM_FILE_OPEN, 1);
    EnableMenuItem(hMenu,IDM_FILE_OPEN, state);
    EnableMenuItem(hMenu,IDM_OPEN_TEMPLATE, state);
    EnableMenuItem(hMenu,IDM_LOAD_OVERLAY, state);
    EnableMenuItem(hMenu,IDM_ADD_OVERLAY, state);
    EnableMenuItem(hMenu,IDM_FILE_SAVEAS_FLOAT, state);
    EnableMenuItem(hMenu,IDM_FILE_SAVEAS_CHAR, state);

    EnableMenuItem(hMenu,IDM_FILTER_GAUSS_1, state);
    EnableMenuItem(hMenu,IDM_FILTER_GAUSS_2, state);
    EnableMenuItem(hMenu,IDM_FILTER_GAUSS_3, state);
    EnableMenuItem(hMenu,IDM_FILTER_GAUSS_4, state);

    EnableMenuItem(hMenu,IDM_FILTER_MEDIAN, state);
    EnableMenuItem(hMenu,IDM_FILTER_SOBEL2D, state);
    EnableMenuItem(hMenu,IDM_FILTER_SOBEL3D, state);
    EnableMenuItem(hMenu,IDM_FILTER_MGS, state);
    EnableMenuItem(hMenu,IDM_MULTI_VOLUME_FILTER, state);

    EnableMenuItem(hMenu,IDM_ROTATE_X, state);
    EnableMenuItem(hMenu,IDM_ROTATE_Y, state);
    EnableMenuItem(hMenu,IDM_ROTATE_Z, state);

    EnableMenuItem(hMenu,IDM_MIRROR, state);
    EnableMenuItem(hMenu,IDM_FORCE_1x1x1, state);
    EnableMenuItem(hMenu,IDM_HISTOGRAM_EQUALISE, state);



    EnableMenuItem(hMenu,IDM_STATS, state);
    EnableMenuItem(hMenu,IDM_CORD_AREA, state);

    EnableMenuItem(hMenu,IDM_RANGE_TOOL, state);
    EnableMenuItem(hMenu,IDM_EDIT_HEADER, state);
    EnableMenuItem(hMenu,IDM_AUTO_THRESHOLD, state);
    EnableMenuItem(hMenu,IDM_AUTO_THRESHOLD_BRAIN, state);
    EnableMenuItem(hMenu,IDM_INTERLEAVE, state);
    EnableMenuItem(hMenu,IDM_INHOMOGENEITY, state);
    EnableMenuItem(hMenu,IDM_LARGE_INHOMOGENEITY, state);
    EnableMenuItem(hMenu,IDM_APPEND_VOLUMES, state);
    EnableMenuItem(hMenu,IDM_ADD_IMAGES, state);
    EnableMenuItem(hMenu,IDM_COREGISTER, state);
    EnableMenuItem(hMenu,IDM_MV_COREGISTER, state);
    EnableMenuItem(hMenu,IDM_SEPARATE_VOLUMES, state);
    EnableMenuItem(hMenu,IDM_LOCALALE, state);
    EnableMenuItem(hMenu,IDM_METAL, state);
    EnableMenuItem(hMenu,IDM_CLUSTERZ, state);
    EnableMenuItem(hMenu,IDM_CBMAN, state);
    EnableMenuItem(hMenu,IDM_COORDINATE_DENSITY_ANALYSIS, state);
    EnableMenuItem(hMenu,IDM_FLATTEN_OCT, state);
    EnableMenuItem(hMenu,IDM_CROP_TOP_OCT, state);
    EnableMenuItem(hMenu,IDM_CROP_BOTTOM_OCT, state);
    EnableMenuItem(hMenu,IDM_DIFFERENCE, state);


    EnableMenuItem(hMenu,IDM_REGISTER_TEMPLATE, state);
    EnableMenuItem(hMenu,IDM_CLASSIFY_WM_GM_CSF, state);
    EnableMenuItem(hMenu,IDM_CLASSIFY_WM_GM_CSF_INHOMOGENEITY, state);
    EnableMenuItem(hMenu,IDM_CLASSIFY_PRIOR, state);
    EnableMenuItem(hMenu,IDM_INHOMOGENEITY_CLASS, state);

    EnableMenuItem(hMenu,IDM_SLICE_ORDER, state);
    EnableMenuItem(hMenu,IDM_VOLUME_ORDER, state);

    EnableMenuItem(hMenu,IDM_FIT_T1, state);
    EnableMenuItem(hMenu,IDM_FIT_T1S, state);
    EnableMenuItem(hMenu,IDM_FIT_T1_MLE, state);
    EnableMenuItem(hMenu,IDM_T1_CALIBRATION, state);

    EnableMenuItem(hMenu,IDM_APPLY_MASK, state);
    EnableMenuItem(hMenu,IDM_APPLY_NOT_MASK, state);
    EnableMenuItem(hMenu,IDM_CONVERT_TO_BINARY, state);

    EnableMenuItem(hMenu,IDM_COMPUTE_MTR, state);
    EnableMenuItem(hMenu,IDM_COMPUTE_MTR_MVOL, state);

    EnableMenuItem(hMenu,IDM_CONVERT_TO_MIP, state);

    EnableMenuItem(hMenu,IDM_UNWRAP, state);
    EnableMenuItem(hMenu,IDM_UNWRAP_CORRECT, state);


    EnableMenuItem(hMenu,IDM_AUTO_ROIS, state);
    EnableMenuItem(hMenu,IDM_MANUAL_ROIS, state);
    EnableMenuItem(hMenu,IDM_LOAD_ROIS, state);
    EnableMenuItem(hMenu,IDM_SAVE_ROIS, state);
    EnableMenuItem(hMenu,IDM_CLEAR_ROIS, state);
    EnableMenuItem(hMenu,IDM_SAVE_ROI_BINARY, state);
    EnableMenuItem(hMenu,IDM_SAVE_OBJECTS, state);
    EnableMenuItem(hMenu,IDM_ROIs_TO_OBJECTS, state);
    EnableMenuItem(hMenu,IDM_ROI_OBJECT_OVERLAP, state);
    EnableMenuItem(hMenu,IDM_CONVERT_OBJECT_TO_ROIs, state);
    EnableMenuItem(hMenu,IDM_TRANSFORM_ROIs, state);



    EnableMenuItem(hMenu,IDM_TENSOR_ROIS, state);
    EnableMenuItem(hMenu,IDM_DTI_GT, state);
    EnableMenuItem(hMenu,IDM_DTI_GT_CONNECT_ROIs, state);
    EnableMenuItem(hMenu,IDM_FODF_ROIS, state);
    EnableMenuItem(hMenu,IDM_FODF_GT, state);
    EnableMenuItem(hMenu,IDM_FODF_GT_CONNECT_ROIs, state);
    EnableMenuItem(hMenu,IDM_PROCESS_DWI, state);
    EnableMenuItem(hMenu,IDM_ARRANGE_DWI_VOLUMES, state);
    EnableMenuItem(hMenu,IDM_CONVERT_FSL_V_RGB, state);


    EnableMenuItem(hMenu,IDM_OPTIONS, state);

    EnableMenuItem(hMenu,IDM_EXTRACT_BRAIN, state);


    return 1;
}


//=======================================================================================
//                      Use PeekMessage to see if escape was pressed
//=======================================================================================
int EscapePressed(HWND hwnd)
{

    MSG Msg;

    PeekMessage(&Msg, hwnd,0,0,PM_NOREMOVE);
    if (Msg.message==WM_KEYDOWN && Msg.wParam==VK_ESCAPE) return 1;
    return 0;
}
