/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "loader.h"
#include "imageprocess.h"


int     LoadAnalyzeImage(char filename[], struct Image *image, int StandardiseScale);
int     LoadNiftiImage(HWND hwnd, char filename[], struct Image *image, int StandardiseScale);

unsigned long int     Get_File_Size(char name[]);
int FillImageStruct(int X, int Y, int Z, int volumes, float dx, float dy, float dz, float x0, float y0, float z0,
                    float scale, float offset, float vox_offset, char units[], char PatientID[], char descrip[], int swapbytes, char hdrname[], char filename[],
                    int datatype, int imagetype, short int NIFTImethod, struct Image *image, int StandardiseScale);
float   ConvertTypeTofloat(unsigned char cimg[], int voxel, short int datatype, int bytes);
float *LoadTheData(char file[], short int BitsPerPix, int ReverseBytes, short int datatype, int voxels, int SliceVoxels, int skip);




//=============================================================================================
//Get a file name
//=============================================================================================
int GetFileName(char name[])
{
    return GetFileNameTitle(name, "Select Image File");
}
//=============================================================================================
//Get a file name
//=============================================================================================
int GetFileNameTitle(char name[], char title[])
{

    OPENFILENAME fnamedlg;

    name[0]='\0';

    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Image Files\0*.img;*.nii\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=name;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle=title;
    fnamedlg.lpstrDefExt="img";


    if(GetOpenFileName(&fnamedlg))
        return 1;
    return 0;
}




//=============================================================================================
//                      get the filename first, then load the image
//                      will load either Analyze or nifti image formats
//                      message is displayed in the top bar of the dialog box
//=============================================================================================
int LoadAnalyzeOrNifti(HWND hwnd, struct Image *image, int StandardiseScale)
{
    return LoadAnalyzeOrNiftiEx(hwnd, image, "Select Image File", StandardiseScale);
}

//=============================================================================================
//                      get the filename first, then load the image
//                      will load either Analyze or nifti image formats
//                      message is displayed in the top bar of the dialog box
//=============================================================================================
int LoadAnalyzeOrNiftiEx(HWND hwnd, struct Image *image, char message[], int StandardiseScale)
{

    OPENFILENAME fnamedlg;
    char FileTitle[MAX_PATH];       //the filename with no path
    char filename[MAX_PATH];        //the filename including path

    FileTitle[0]='\0';
    filename[0]='\0';

    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Image Files\0*.img;*.nii\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=filename;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrFileTitle=FileTitle;
    fnamedlg.nMaxFileTitle=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle=message;
    fnamedlg.lpstrDefExt="img";


    if(GetOpenFileName(&fnamedlg))
    {
        //---------------------------------------Analyze---------------------------------------------
        if (strstr(filename,".img") || strstr(filename,".IMG"))
            return LoadAnalyzeImage(filename, image, StandardiseScale);
        //-----------------------------------------NIFTI---------------------------------------------
        else if (strstr(filename,".nii") || strstr(filename,".NII"))
            return LoadNiftiImage(hwnd, filename, image, StandardiseScale);
    }

    return 0;
}










//=============================================================================================
//                       given the filename of the image, load
//                       will load either Analyze or NIFTI image formats
//=============================================================================================
int LoadFromFileName(HWND hwnd, char name[], struct Image *image, int StandardiseScale)
{

    if (strstr(name,".img") || strstr(name,".IMG"))
        return LoadAnalyzeImage(name, image, StandardiseScale);	       //Analyze
    else if (strstr(name,".nii") || strstr(name,".NII"))
        return LoadNiftiImage(hwnd, name, image, StandardiseScale);		   //Nifti
    return 0;
}











//=============================================================================================
//                          load the header
//                          if successful, load the image data also
//                          then fill the image struct
//=============================================================================================
int LoadAnalyzeImage(char filename[], struct Image *image, int StandardiseScale)
{

    FILE *fp;
    int voxels;
    unsigned long int filesize;
    int ans;
    int BytesPerPixel;
    short int XPIXELS, YPIXELS, SLICES, VOLUMES;
    short int BITSPERPIXEL;
    short int DATATYPE;
    int SWAP_BYTES;
    int length;
    int fill;
    float XDIM,YDIM,ZDIM;
    float scale,offset;
    short int ORIGIN[3];
    char hdrname[MAX_PATH], txt[256];
    char Descrip[256], PatientID[256];
    char units[4];
    struct dsr Analyzehdr;


    //get the name of the header
    length=strlen(filename);
    strncpy(hdrname,filename,length-3);
    hdrname[length-3]='\0';
    strcat(hdrname,"hdr");




    //First Load the Header file
    if ( (fp=fopen(hdrname,"rb")) )
    {

        fread(&Analyzehdr, 1, sizeof(struct dsr), fp);

        if (fp)
            fclose(fp);//Close the file

        //--------collect the used parts from the header----------------------------
        SWAP_BYTES=       ( Analyzehdr.hk.sizeof_hdr==sizeof(struct dsr)) ? 0:1;
        BITSPERPIXEL=     ( Analyzehdr.dime.bitpix );
        XPIXELS=          ( Analyzehdr.dime.dim[1] );
        YPIXELS=          ( Analyzehdr.dime.dim[2] );
        SLICES=           ( Analyzehdr.dime.dim[3] );
        VOLUMES=          ( Analyzehdr.dime.dim[4] );
        DATATYPE=         ( Analyzehdr.dime.datatype );
        sprintf(Descrip,"%s",Analyzehdr.hist.descrip);
        sprintf(PatientID,"%s",Analyzehdr.hist.patient_id);



        if (!strlen(Analyzehdr.dime.vox_units))
            sprintf(units,"?");
        else
            sprintf(units,"%s",Analyzehdr.dime.vox_units);//voxel dimension units



        //hist.originator is in voxels, rather than mm, for example
        //this is converted when filling the Image structure
        memcpy(ORIGIN,Analyzehdr.hist.originator,sizeof(short int)*3);

        XDIM=(float)fabs( Analyzehdr.dime.pixdim[1] );
        YDIM=(float)fabs( Analyzehdr.dime.pixdim[2] );
        ZDIM=(float)fabs( Analyzehdr.dime.pixdim[3] );

        scale=Analyzehdr.dime.funused1;
        offset=Analyzehdr.dime.funused2;


        if (SWAP_BYTES) //IF BYTES ARE SWAPED, REVERSE THEM
        {
            SwapBytes((char *)&BITSPERPIXEL, 	    sizeof(short int));
            SwapBytes((char *)&XPIXELS, 			sizeof(short int));
            SwapBytes((char *)&YPIXELS, 			sizeof(short int));
            SwapBytes((char *)&SLICES, 			sizeof(short int));
            SwapBytes((char *)&VOLUMES, 			sizeof(short int));
            SwapBytes((char *)&DATATYPE, 			sizeof(short int));
            SwapBytes((char *)&ORIGIN[0], 		sizeof(short int));
            SwapBytes((char *)&ORIGIN[1], 		sizeof(short int));
            SwapBytes((char *)&ORIGIN[2], 		sizeof(short int));
            SwapBytes((char *)&XDIM, 				sizeof(float));
            SwapBytes((char *)&YDIM, 				sizeof(float));
            SwapBytes((char *)&ZDIM, 				sizeof(float));
            SwapBytes((char *)&scale, 			sizeof(float));
            SwapBytes((char *)&offset, 			sizeof(float));
        }


        if (VOLUMES<=0)
            VOLUMES=1;  //this should be at least 1

        SLICES*=VOLUMES;            //slices in the header is slices per volume

        voxels=XPIXELS*YPIXELS*SLICES;

        BytesPerPixel=BITSPERPIXEL/8;
    }
    else
        return 0;



    //-----------------some data types are not supported yet--------------------------------------------------
    //------------DT_DOUBLE only supported if cast to float does not result in loss of information------------
    if ((DATATYPE!=DT_UNSIGNED_SHORT) && (DATATYPE!=DT_SIGNED_SHORT) && (DATATYPE!=DT_SIGNED_INT) &&
        (DATATYPE!=DT_FLOAT) && (DATATYPE!=DT_UNSIGNED_CHAR) && (DATATYPE!=DT_DOUBLE) && (DATATYPE!=DT_RGB) && (DATATYPE!=DT_BINARY))
    {
        sprintf(txt,"unsupported datatype: %d",DATATYPE);
        MessageBox(NULL,"Image data type not supported in this version.",txt,MB_OK);
        return 0;
    }


    filesize=Get_File_Size(filename);			  //file size in bytes

    if (BytesPerPixel)
        filesize/=BytesPerPixel;		      //filesize now in voxels

    //-------------check that the filesize is correct given the header---------------------------
    if (/*(DATATYPE==DT_BINARY && filesize!=voxels/8) ||*/ (DATATYPE!=DT_BINARY && filesize!=voxels))
    {
        if ((VOLUMES==1)&&(filesize>voxels))
        {
            if (!(filesize%voxels))
            {
                VOLUMES=filesize/voxels;
                SLICES*=VOLUMES;
                voxels*=VOLUMES;
            }
            else
                return 0;
        }
        else if (VOLUMES && (filesize==(voxels/VOLUMES)))
        {
            ans=MessageBox(NULL,"The header is not correct for this image. Should VOLUMES be adjusted to 1 (Fix the problem).","",MB_YESNO|MB_ICONQUESTION);
            if (ans==IDYES)
            {
                voxels/=VOLUMES;
                SLICES/=VOLUMES;
                VOLUMES=1;
            }
            else
                return 0;
        }
        else
        {
            sprintf(txt,"Load Failed\nvoxels=%d  filesize(voxels)=%d VOLUMES=%d\n XPIXELS=%d  YPIXELS=%d SLICES=%d \nBITSPERPIXEL=%d DATATYPE=%d VoxOffset=%d",
                    voxels,(int)filesize,(int)VOLUMES,(int)XPIXELS,(int)YPIXELS,(int)SLICES,BITSPERPIXEL,DATATYPE, (int)Analyzehdr.dime.vox_offset);
            MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
            return 0;
        }
    }


    ReleaseImage(image);
    (*image).img=LoadTheData(filename, BITSPERPIXEL, SWAP_BYTES, DATATYPE, voxels, XPIXELS*YPIXELS, 0);


    if ((*image).img)
    {

        if (scale<=0.0)
            scale=1.0;                                                   //in case it has not been set in the header
        fill=FillImageStruct(XPIXELS, YPIXELS, SLICES, VOLUMES, XDIM, YDIM, ZDIM, ORIGIN[0]*XDIM, ORIGIN[1]*YDIM,ORIGIN[2]*ZDIM,
                             scale, offset, 0.0, units, PatientID, Descrip, SWAP_BYTES, hdrname, filename, DATATYPE, HDR, 0, image, StandardiseScale);
        (*image).hdr=Analyzehdr;

        return fill;
    }
    else
    {
        MessageBox(NULL,"Unable to load data","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    return 0;
}











//===========================================================================================================
//									NIFTI IMAGE FILE Loader
//===========================================================================================================
int LoadNiftiImage(HWND hwnd, char filename[], struct Image *image, int StandardiseScale)
{

    FILE *fp;
    int voxels;
    int ans;
    int fill;
    int BytesPerPixel;
    unsigned long int filesize;
    short int XPIXELS, YPIXELS, SLICES;
    short int VOLUMES;
    short int DATATYPE;
    short int SWAP_BYTES;
    short int BITSPERPIXEL;
    short int qform, sform, method;
    char txt[256];
    char Descrip[256], PatientID[256];
    char units[4];
    float XDIM, YDIM, ZDIM;
    float scale,offset;
    float x0, y0, z0;
    float vox_offset;
    struct nifti_1_header NIFTIheader;

    memset(&NIFTIheader,0,sizeof(struct nifti_1_header));

    if ( (fp=fopen(filename,"rb")) ) 										        //First Load the Header file
    {


        fread(&NIFTIheader, 1, sizeof(struct nifti_1_header), fp);

        if (fp)
            fclose(fp);														//Close the file

        SWAP_BYTES=(NIFTIheader.dim[0]>=1 && NIFTIheader.dim[0]<=7) ? 0:1;      //1..7 only allowed in NIFTI
        BITSPERPIXEL=NIFTIheader.bitpix;
        XPIXELS=	( NIFTIheader.dim[1] );
        YPIXELS=	( NIFTIheader.dim[2] );
        SLICES=		( NIFTIheader.dim[3] );
        VOLUMES=	( NIFTIheader.dim[4] );
        DATATYPE=	( NIFTIheader.datatype );

    //char txt[256];
    //sprintf(txt,"%d %d %d %d",XPIXELS,YPIXELS,SLICES,VOLUMES);
    //MessageBox(NULL,txt,"",MB_OK);



        sprintf(Descrip,"%s",NIFTIheader.descrip);
        PatientID[0]='\0';//doesnt seem to be a patient ID for NIFTI

        vox_offset=NIFTIheader.vox_offset;				                        //where does the image data begin?

        XDIM=(float)fabs( NIFTIheader.pixdim[1] );
        YDIM=(float)fabs( NIFTIheader.pixdim[2] );
        ZDIM=(float)fabs( NIFTIheader.pixdim[3] );


        if (NIFTIheader.xyzt_units==NIFTI_UNITS_METER)
            sprintf(units,"m");//voxel dimension units
        else if (NIFTIheader.xyzt_units==NIFTI_UNITS_MM)
            sprintf(units,"mm");//voxel dimension units
        else if (NIFTIheader.xyzt_units==NIFTI_UNITS_MICRON)
            sprintf(units,"mcr");//voxel dimension units
        else
            sprintf(units,"?");

        scale=	NIFTIheader.scl_slope;
        offset=	NIFTIheader.scl_inter;

        x0=NIFTIheader.qoffset_x;             //qoffset_? is a float, but ANALYZE hist.originator is short int.
        y0=NIFTIheader.qoffset_y;             //In Analyze the units are voxels, but here they are
        z0=NIFTIheader.qoffset_z;             //the same as .pixdim (usually mm)

        qform=NIFTIheader.qform_code;//these relate to the NIFTI methods
        sform=NIFTIheader.sform_code;

        if (SWAP_BYTES) 													    //IF BYTES ARE SWAPED, REVERSE THEM
        {
            SwapBytes((char *)&BITSPERPIXEL, sizeof(short int));
            SwapBytes((char *)&XPIXELS, 		    sizeof(short int));
            SwapBytes((char *)&YPIXELS, 		sizeof(short int));
            SwapBytes((char *)&SLICES, 			sizeof(short int));
            SwapBytes((char *)&VOLUMES, 		sizeof(short int));
            SwapBytes((char *)&DATATYPE, 		sizeof(short int));
            SwapBytes((char *)&x0, 			    sizeof(float));
            SwapBytes((char *)&y0, 			    sizeof(float));
            SwapBytes((char *)&z0, 			        sizeof(float));
            SwapBytes((char *)&XDIM, 			sizeof(float));
            SwapBytes((char *)&YDIM, 			sizeof(float));
            SwapBytes((char *)&ZDIM, 			sizeof(float));
            SwapBytes((char *)&scale, 			    sizeof(float));
            SwapBytes((char *)&offset, 			sizeof(float));
            SwapBytes((char *)&vox_offset, 		sizeof(float));
            SwapBytes((char *)&qform, 	        sizeof(short int));
            SwapBytes((char *)&sform, 	        sizeof(short int));
        }



        method=1;
        if (qform)
            method=2;//normal method
        if (sform)
            method=3;

        if (VOLUMES<=0)
            VOLUMES=1;

        SLICES*=VOLUMES;

        voxels=XPIXELS*YPIXELS*SLICES;

        BytesPerPixel=BITSPERPIXEL/8;

    }
    else
    {
        MessageBox(NULL,filename,"Can't load that file.",MB_OK|MB_OK);
        return 0;
    }



    if ((DATATYPE!=DT_UNSIGNED_SHORT) && (DATATYPE!=DT_SIGNED_SHORT) && (DATATYPE!=DT_SIGNED_INT) && (DATATYPE!=DT_FLOAT) &&
        (DATATYPE!=DT_UNSIGNED_CHAR) && (DATATYPE!=DT_DOUBLE) && (DATATYPE!=DT_RGB) && (DATATYPE!=DT_BINARY))
    {
        sprintf(txt,"unsupported datatype: %d",DATATYPE);
        MessageBox(NULL,"Image data type not supported in this version.",txt,MB_OK);
        return 0;
    }

    //according to the NIFTI format, there must be at least 4 bytes after the end of the nifti header before the image data
    //the header is 348 bytes
    if (vox_offset<352)
        vox_offset=352;



    filesize=Get_File_Size(filename)-(int)vox_offset;		                        //file size in bytes
    if (BytesPerPixel)
        filesize/=BytesPerPixel;                                                        //filesize in voxels


    if ( (DATATYPE==DT_BINARY && filesize!=voxels/8) || (DATATYPE!=DT_BINARY && filesize!=voxels) )
    {
        if ((VOLUMES==1)&&(filesize>voxels))
        {
            if (!(filesize%voxels))
            {
                VOLUMES=filesize/voxels;
                SLICES*=VOLUMES;
                voxels*=VOLUMES;
            }
            else
            {
                MessageBox(NULL,"Problem with filesize","",MB_OK|MB_ICONWARNING);
                return 0;
            }

        }
        else if (VOLUMES && (filesize==(voxels/VOLUMES)))
        {
            ans=MessageBox(NULL,"The header is not correct for this image. Should VOLUMES be adjusted to 1 (Fix the problem).","",
                           MB_YESNO|MB_ICONQUESTION);
            if (ans==IDYES)
            {
                voxels/=VOLUMES;
                SLICES/=VOLUMES;
                VOLUMES=1;
            }
            else
                return 0;
        }
        else
        {
            sprintf(txt,"Load Failed/nvoxels=%d  filesize(voxels)=%d VOLUMES=%d",voxels,(int)filesize,VOLUMES);
            MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
            return 0;
        }
    }

    ReleaseImage(image);
    memset(image,0,sizeof(struct Image));
    (*image).img=LoadTheData(filename, BITSPERPIXEL, SWAP_BYTES, DATATYPE, voxels, XPIXELS*YPIXELS, (int)vox_offset);


    if ((*image).img)
    {
        if (scale<=0.0)
            scale=1.0;                                               //in case it has not been set in the header

        fill=FillImageStruct(XPIXELS, YPIXELS, SLICES, VOLUMES, XDIM, YDIM, ZDIM, x0, y0, z0,
                             scale, offset, vox_offset, units, PatientID, Descrip, SWAP_BYTES, "", filename,
                             DATATYPE, NIFTI, method, image, StandardiseScale);
        (*image).nifti=NIFTIheader;
        return fill;
    }
    else
    {
        MessageBox(NULL,"Unable to load data","",MB_OK|MB_ICONWARNING);
        return 0;
    }


    return 0;

}


//=============================================================================================
//          Loads image data of types short int, unsigned char, float, and double.
//                            reverses the bytes is needed
//                            returns a pointer to the data
//=============================================================================================
float *LoadTheData(char file[], short int BitsPerPix, int ReverseBytes, short int datatype, int voxels, int SliceVoxels, int skip)
{


    int voxel, bytes, pixel;
    float *fimg=NULL;
    unsigned char *tmp=NULL;
    FILE *fp;
    //char txt[256];

    if (datatype==DT_BINARY)
    {
        return LoadBinaryData(file, voxels, skip);
    }

    bytes=(int)BitsPerPix/8;

    fp=fopen(file,"rb");

    //sprintf(txt,"%d",voxels*sizeof(float));
    //MessageBox(NULL,txt,"",MB_OK);

    fimg=(float *)malloc(voxels*sizeof(float));
    tmp=(unsigned char *)malloc(SliceVoxels*bytes);

    if ( fimg && tmp && fp )
    {

        memset(fimg, 0, voxels*sizeof(float));
        fseek(fp,skip,SEEK_SET);
        for (voxel=0; voxel<voxels; voxel+=SliceVoxels)
        {
            if (((int)fread(tmp,sizeof(unsigned char),bytes*SliceVoxels,fp)==bytes*SliceVoxels))
            {


                if (ReverseBytes)
                {
                    for (pixel=0; pixel<SliceVoxels; pixel++)
                        SwapBytes(&tmp[pixel*bytes], bytes);
                }

                //put the intensities in img
                for (pixel=0; pixel<SliceVoxels; pixel++)
                    fimg[voxel+pixel]=ConvertTypeTofloat(tmp, pixel, datatype, bytes);

            }

        }



    }



    if (fp)
        fclose(fp);
    if (tmp)
        free(tmp);

    return fimg;
}
//=============================================================================================
float *LoadBinaryData(char file[], int voxels, int skip)
{

    float *fimg=NULL;
    unsigned char *tmp=NULL;
    int voxel;
    FILE *fp;

    if (!( fimg=(float *)malloc(voxels*sizeof(float)))) goto END;
    if (!( tmp=(unsigned char *)malloc(voxels))) goto END;

    if ((fp=fopen(file,"rb")))
    {
        fseek(fp,skip,SEEK_SET);
        if (((int)fread(tmp,sizeof(unsigned char),voxels/8,fp)==voxels/8))
        {

         for (voxel=0;voxel<voxels;voxel++)
         {
             fimg[voxel]=(float)GetBit(tmp,voxel);
         }

        }
    }


END:
    if (fp)
        fclose(fp);
    if (tmp)
        free(tmp);

    return fimg;
}
//=============================================================================================
//convert binary image data into voxels
//binary data has 8 voxels stored in a byte
int GetBit(unsigned char bits[], int bit)
{
    int ibyte = bit/8;
    int n=bit-8*ibyte;
    return (int)(bits[ibyte]>>n)&1;
}


//=============================================================================================
//=============================================================================================
//                             return a float of the intensity
//=============================================================================================
float ConvertTypeTofloat(unsigned char cimg[], int voxel, short int datatype, int bytes)
{

    float intensity=0.0;
    double dintensity;
    float fintensity;
    short int sintensity;
    int iintensity;
    RGBQUAD rgb;

    switch(datatype)
    {
    case DT_DOUBLE:
        memcpy(&dintensity,&cimg[voxel*bytes],sizeof(double));
        intensity=(float)dintensity;
        break;
    case DT_FLOAT:
        memcpy(&fintensity,&cimg[voxel*bytes],sizeof(float));
        intensity=(float)fintensity;
        break;
    case DT_UNSIGNED_CHAR:
        intensity=(float)cimg[voxel*bytes];
        break;
    case DT_SIGNED_SHORT:
        memcpy(&sintensity, &cimg[voxel*bytes],sizeof(short int));
        intensity=(float)sintensity;
        break;
    case DT_SIGNED_INT:
        memcpy(&iintensity, &cimg[voxel*bytes],sizeof(int));
        intensity=(float)iintensity;
        break;
    case DT_RGB:                                                            //3 bytes for RGB triplet, fit into 4 bytes of the float
        rgb.rgbRed  =cimg[voxel*bytes+2];
        rgb.rgbGreen=cimg[voxel*bytes+1];
        rgb.rgbBlue =cimg[voxel*bytes];
        rgb.rgbReserved=0;
        memcpy(&intensity, &rgb, sizeof(float));
        break;
    case DT_UNSIGNED_SHORT:
        memcpy(&sintensity, &cimg[voxel*bytes],sizeof(short int));
        intensity=(float)sintensity;
        break;
    }
    if (isnan(intensity)) intensity=0.0;

    return intensity;
}











//=============================================================================================
//                             fills the image structure
//=============================================================================================
int FillImageStruct(int X, int Y, int Z, int volumes, float dx, float dy, float dz, float x0, float y0, float z0,
                    float scale, float offset, float vox_offset, char units[], char PatientID[], char descrip[], int swapbytes, char hdrname[], char filename[],
                    int datatype, int imagetype, short int NIFTImethod, struct Image *image, int StandardiseScale)
{

    float min=0.0;
    float max=0.0;
    int voxel, voxels=X*Y*Z;

    (*image).X=X;
    (*image).Y=Y;
    (*image).Z=Z;
    (*image).dx=dx;
    (*image).dy=dy;
    (*image).dz=dz;
    (*image).volumes=volumes;
    (*image).x0=fabs(x0);
    (*image).y0=fabs(y0);
    (*image).z0=fabs(z0);
    (*image).swapbytes=swapbytes;
    (*image).scale=scale;
    (*image).offset=offset;
    if (StandardiseScale)
    {
        (*image).scale=1.0;
        (*image).offset=0.0;
    }
    (*image).vox_offset=vox_offset;
    (*image).ImageType=imagetype;
    (*image).NIFTImethod=NIFTImethod;
    (*image).DataType=datatype;
    sprintf((*image).VoxUnits,"%s",units);
    sprintf((*image).filename,"%s",filename);
    sprintf((*image).headername,"%s",hdrname);
    sprintf((*image).Descrip,"%s",descrip);
    sprintf((*image).PatientID,"%s",PatientID);
    (*image).changed=0;                                  //the image is as loaded


    //make rotation matrix just identity matrix initially
    memset((*image).rotation,0,sizeof(double)*4*4);
    (*image).rotation[0]=(*image).rotation[5]=(*image).rotation[10]=(*image).rotation[15]=1.0;

    if (IsImageScalar(datatype))
    {
        ImageMinMax((*image).img, X, Y, Z, datatype, &min, &max);

        //------put any negative minimum intensity into the offset------------
        if (min>0.0)
            min=0.0;
        (*image).offset+=min*(*image).scale;
        //--------then subtract it from the image so dont deal with negatives---------
        for (voxel=0; voxel<voxels; voxel++)
        {
            (*image).img[voxel]-=min;
        }
        (*image).MaxIntensity=max-min;
        //sprintf(txt,"min %f     max %f",min,max);
        //MessageBox(NULL,txt,"",MB_OK);
    }
    else
    {
        (*image).MaxIntensity=255.0;

    }

    return 1;
}









//=============================================================================================
//                       Make an image of specified type
//                       return 1 if succeed
//                       return 0 if unsupported datatype
//                       scalar and RGB datatypes supported
//                       ASSUMES THAT THE IMAGE IS UNUSED AND UN-INITIALISED
//                       X,Y,Zpv are image dimensions in voxels
//                       volumes is the number of volumes in the image
//                       dx, dy, dz are the size of the voxels (mm)
//                       x0, y0, z0 are the image origin (set to the centre if no other pref)
//                       DataType should be one of the predefined types in the dbh.h header
//                       Intensity in each voxel is I'=offset+scale*I, if I is the value stored in the image matrix
//                       ImageType is HDR (Analyze) or NIFTI
//=============================================================================================
int MakeImage(struct Image *image, int X, int Y, int Zpv, int volumes, float dx, float dy, float dz,
              float x0, float y0, float z0, float scale, float offset, int DataType,
              int ImageType, char descrip[])
{

    if (!(IsImageScalar(DataType) || DataType==DT_RGB))
        return 0;//return 0 if not currently supported datatype

    memset(image,0,sizeof(struct Image));//************INITIALISE IMAGE TO NULL**********

    //now malloc the memory
    if (!((*image).img=(float *)malloc(X*Y*Zpv*volumes*sizeof(float))))
        return 0;


    //fill the specified structure items
    (*image).X=X;
    (*image).Y=Y;
    (*image).Z=Zpv*volumes;
    (*image).volumes=volumes;
    (*image).dx=dx;
    (*image).dy=dy;
    (*image).dz=dz;
    (*image).x0=x0;
    (*image).y0=y0;
    (*image).z0=z0;
    (*image).scale=scale;
    (*image).offset=offset;
    (*image).DataType=DataType;
    (*image).ImageType=ImageType;
    (*image).swapbytes=0;
    (*image).changed=1;
    sprintf((*image).Descrip,"%s",descrip);

    memset((*image).rotation,0,sizeof(double)*4*4);
    //make it just identity matrix initially
    (*image).rotation[0]=(*image).rotation[5]=(*image).rotation[10]=(*image).rotation[15]=1.0;

    memset((*image).img, 0, X*Y*Zpv*volumes*sizeof(float));

    return 1;
}




//=============================================================================================
//                    Reverses up to 16 bytes of data pointed to by ptr
//=============================================================================================
int SwapBytes(void *vptr, int Num)
{

    char *ptr=(char *)vptr;
    int i;
    char tmp[16];

    if (Num<=16)
    {
        memcpy(tmp, ptr, Num);
        for (i=0; i<Num; i++)
        {
            ptr[i]=tmp[Num-1-i];
        }
    }
    return 1;
}







//=============================================================================================
//                        returns the file "name" size in bytes
//							Modified to use GetFileAttributesEx 15th June 2010
//							because of issue with filename sizes using GetFileSize; apparently
//=============================================================================================
unsigned long int Get_File_Size(char name[])
{

    WIN32_FILE_ATTRIBUTE_DATA   fileInfo;
    unsigned long int size;
    DWORD tmp[2];

    if (!GetFileAttributesEx((LPCTSTR)name, GetFileExInfoStandard, (void*)&fileInfo))
        return 0;

    tmp[0]=fileInfo.nFileSizeLow;
    tmp[1]=fileInfo.nFileSizeHigh;

    memcpy(&size, tmp, sizeof(DWORD)*2);
    return size;

    //return (long)fileInfo.nFileSizeLow;

    /*
    	OFSTRUCT pof;
    	HFILE hFile;
    	DWORD size;

    	hFile=OpenFile(name,&pof,OF_READ);

    	size=GetFileSize((HANDLE)hFile, NULL);

    	_lclose(hFile);

    	return size;*/
}

























//=============================================================================================
//Routines for getting multiple file name selection
//=============================================================================================
//int GetImageFileNames(char names[]);
//int NumberOfFiles(char names[]);
//int GetNthFileName(char names[], int n, char name[]);
//=============================================================================================
//                              Get the OPEN filename(s)
//                              allows for multiple selections
//                              names must have a length at least 2*MAX_PATH
//=============================================================================================
int GetImageFileNames(char names[], int N, char Message[])
{

    OPENFILENAME fn;

    names[0]='\0';
    memset(&fn,0,sizeof(OPENFILENAME));
    fn.lStructSize=sizeof(OPENFILENAME);
    fn.hwndOwner=NULL;
    fn.lpstrFilter="Image Files\0*.img;*.nii\0\0";
    fn.lpstrCustomFilter=NULL;
    fn.nFilterIndex=1;
    fn.lpstrFile=names;
    fn.nMaxFile=N;//this needs to be long enough to contain the directory and filenames
    fn.lpstrInitialDir=NULL;
    fn.lpstrTitle=Message;
    fn.lpstrDefExt="img";
    fn.Flags=OFN_ALLOWMULTISELECT|OFN_EXPLORER;

    if (GetOpenFileName(&fn))
        return NumberOfFiles(names);

    return 0;
}
//=============================================================================================
//          count the number of files
//          output from GetImageFileNames can contain more than one file
//=============================================================================================
int NumberOfFiles(char names[])
{

    int n,pos,l;

    if (!strlen(names))
        return 0;

    pos=strlen(names)+1;

    //there should be an extra NULL character at the end of the files. Check if this is now
    if (!strlen(&names[pos]))
        return 1;//only one file
    //if here then pos points to the start of the file names without the directory


    //if the number of files is greater than 1
    //the first part of names is just the directory
    //what follows are the file names
    n=0;
    do
    {
        if ( (l=strlen(&names[pos])) )
        {
            n++;
            pos+=l+1;
        }
    }
    while(l);

    return n;
}
//=============================================================================================
//                  returns the Directory if !n
//                  Only works for multiple file format in 'names'
//                  DO NOT USE IF NumberOfFiles is 1.
//                  for the first file, n=1, second, n=2.....
//=============================================================================================
int GetNthFileName(char names[], int n, char name[])
{

    int i,pos,l;

    //return the Directory if !n
    if (n<=0)
    {
        sprintf(name,"%s",names);
        return 1;
    }

    i=0;

    pos=0;
    do
    {
        if ( (l=strlen(&names[pos])) )
        {
            i++;
            pos+=l+1;
        }
    }
    while(l && i<n);

    if (i!=n)
        return 0;

    sprintf(name,"%s\\%s",names, &names[pos]);
//	MessageBox(NULL,name,"test",MB_OK);

    return 1;
}





//=============================================================================================
//                      User selects a directory
//                      The directory is put in Directory[]
//                      instructions[] informs the user
//=============================================================================================
int GetDirectoryName(HWND hwnd, char Directory[], char instructions[])
{


    BROWSEINFO folder;
    LPITEMIDLIST pidlBrowse;

    memset(&folder,0,sizeof(BROWSEINFO));
    Directory[0]='\0';

    folder.hwndOwner=hwnd;
    folder.pszDisplayName=Directory;
    folder.lpszTitle=instructions;

    if ( (pidlBrowse=SHBrowseForFolder(&folder)) )
    {

        SHGetPathFromIDList(pidlBrowse,Directory);

        return 1;
    }


    return 0;
}



//=============================================================================================
//          Split the filename into directory and name of the file
//          Input is the complete filename, including the directory: fname[]
//          Output is an integer 'i' such that fname[i] id the last \ in the filename
//          Example:
//fname="c:\directory\file.ext"
//Output 12, so &fname[12]="\file.ext"
//=============================================================================================
int DirectoryFileDivide(char fname[])
{

    int length = strlen(fname);
    int location=length;

    if (!length)
        return 0;

    while((location>=0) && (fname[location]!='\\'))
    {
        location--;
    }
    //MessageBox(NULL,&fname[location],fname,MB_OK);

    return location;
}


