/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "display.h"
#include "autoROI.h"
#include "manualROIs.h"
#include "statusbar.h"
#include "toolbar.h"
#include "tensorROIs.h"
#include "stats.h"
#include "menuresources.h"
#include "options.h"
#include "ROIs.h"
#include "overlays.h"
#include "imageprocess.h"
#include "global.h"

int OnLoad(struct Picture *picture);
int RGBPicture(HWND hwnd, struct Picture *picture, struct Image *image);
int PictureSize(struct Picture *picture, int Orthogonal);
int ShowCrossHair(HWND hwnd, HDC hDC, struct Picture *picture);
int LocalZoomPicture(HWND hwnd, HDC hDC, struct Picture *picture);
int OrthogonalRGBPicture(HWND hwnd, struct Picture *picture, struct Image *image);
//================================================================================================
//                        Just defines an RGB colour bitmap Width by Height
//                        Width must be a multiple of 4
//================================================================================================
BITMAPINFOHEADER DefineBitmap(int Width, int Height){

	BITMAPINFOHEADER bmpRGB;

	memset(&bmpRGB,0,sizeof(BITMAPINFOHEADER));      //null the structure to start with

	if (Width%4) return bmpRGB;                          //Doesnt work if width isnt a multiple of 4

	bmpRGB.biSize=sizeof(BITMAPINFOHEADER);
	bmpRGB.biWidth=Width;
	bmpRGB.biHeight=Height;
	bmpRGB.biPlanes=1;
	bmpRGB.biXPelsPerMeter=0;
	bmpRGB.biYPelsPerMeter=0;
	bmpRGB.biClrImportant=0;


    bmpRGB.biBitCount=24;
	bmpRGB.biCompression=BI_RGB;
	bmpRGB.biSizeImage=Width*Height*sizeof(char)*3;
	bmpRGB.biClrUsed=0;

	return bmpRGB;
}









//====================================================================================================
//                     draws the bitmap defined in picture (the image information)
//                             and bmpinf, the details of the bitmap type
//                      -hDC is either set on input, and might have a clipping region
//                      -or it is retrieved, for the whole client rectangle, using GetDC
//====================================================================================================
int DrawBitmapEx(HDC hDC, HWND hwnd, struct Picture *picture, HWND hStatusBar, int Save){

	HDC hMemDC;
	HBITMAP hbmp,hOldbmp;
	int delDC=0;
    char directory[MAX_PATH];

	if (!hDC){
       hDC=GetDC(hwnd);
       delDC=1;
    }

	hMemDC=CreateCompatibleDC(hDC);

    //create device DEPENDENT bitmap from device independent specification
	hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&(*picture).bmphdr, CBM_INIT, (*picture).pict,
                               (LPBITMAPINFO)&(*picture).bmphdr, DIB_RGB_COLORS  );

	hOldbmp=SelectObject(hMemDC, hbmp);

    //-----------------process the picture----------------------------------------
    if (IsMenuItemChecked(hwnd, IDM_SHOW_CROSS)) ShowCrossHair(hwnd, hMemDC, picture);
    if (IsMenuItemChecked(hwnd, IDM_SHOW_ROIS)){
		DrawAllROIs(picture, hMemDC, (*picture).slice, 1, 1);
	}
	if (hAutoROI) DrawCurrentAutoROI(picture, hMemDC, gImage.dx, gImage.dy);
    if (hStatsDlg) DrawSelectedROI(picture, hMemDC);
	if (hTensorROI) DrawTrajectory(hMemDC, &gMainPict, &gImage, IsMenuItemChecked(hwnd, IDM_VIEW_PLANES));

    if ((*picture).LocalZoom) LocalZoomPicture(hwnd, hMemDC, picture);

	StretchBlt(hDC, (*picture).xpos, (*picture).ypos, (int)((*picture).zoom*(*picture).width), (int)((*picture).zoom*(*picture).height), hMemDC, 0,0,
                         (*picture).width, (*picture).height, SRCCOPY);


    if (IsMenuItemChecked(hwnd, IDM_SHOW_ROIS)){
    	if (IsMenuItemChecked(hwnd, IDM_SHOW_ROI_NUMBERS)) DrawAllROIsObjectNumber(picture, hDC, (*picture).xpos, (*picture).ypos, (*picture).zoom);
	}
	if (hManualROI) DrawCurrentManualROI(picture, hDC);

    if (Save==SAVE_BITMAP_AS) SaveBitmap(picture, hwnd, hMemDC, 1,"");
    if (Save==SAVE_BITMAP)
    {
        sprintf(directory,"./Bitmaps");
        CreateDirectory(directory,NULL);
        SaveBitmap(picture, hwnd, hMemDC, 0, directory);
    }

	SelectObject(hMemDC, hOldbmp);

	DeleteObject(hbmp);

	if (delDC) ReleaseDC(hwnd,hDC);
	DeleteDC(hMemDC);

	return 1;
}









//====================================================================================================
//                         Locally zoom into the picture

//====================================================================================================
int LocalZoomPicture(HWND hwnd, HDC hDC, struct Picture *picture){

    short int x, y;
    int X, Y;
    int width=(*picture).ML.x1-(*picture).ML.x0+1;
    int height=(*picture).height;

    X=(*picture).X;
    Y=(*picture).Y;

    ImageToPicture(picture, &x, &y, (*picture).x, (*picture).y, (*picture).slice);

    StretchBlt(hDC, x-X/6, y-Y/6, X/3, Y/3, hDC, x-X/10, y-Y/10, X/5, Y/5, SRCCOPY);

    if (!IsMenuItemChecked(hwnd, IDM_VIEW_PLANES)) return 1;

    x+=width;
    y=(height-(*picture).slice);
    StretchBlt(hDC, x-X/6, y-Y/6, X/3, Y/3, hDC, x-X/10, y-Y/10, X/5, Y/5, SRCCOPY);


    x=2*width+(*picture).y-(*picture).ML.y0;
    y=(height-(*picture).slice);
    StretchBlt(hDC, x-X/6, y-Y/6, X/3, Y/3, hDC, x-X/10, y-Y/10, X/5, Y/5, SRCCOPY);

    return 1;
}




//====================================================================================================
//                               Show crosshair
//====================================================================================================
int ShowCrossHair(HWND hwnd, HDC hDC, struct Picture *picture){

    int x,y,z;
    int width=(*picture).ML.x1-(*picture).ML.x0+1;
    int n=(*picture).CrossHairSize;
    COLORREF rgb=RGB(217,200,81);

    int height=(*picture).height;



    x=(*picture).x-(*picture).ML.x0;
    y=(*picture).y-(*picture).ML.y0;
    z=(*picture).slice;


    //----------------------------------left-----------------------------------
    DrawLine(hDC, x-10, height-y, x-n, height-y, rgb, 1);
    DrawLine(hDC, x+(n+1), height-y, x+11, height-y, rgb, 1);
    DrawLine(hDC, x, height-y+10, x, height-y+n, rgb, 1);
    DrawLine(hDC, x, height-y-(n+1), x, height-y-11, rgb, 1);

    if (!IsMenuItemChecked(hwnd, IDM_VIEW_PLANES)) return 1;

    //----------------------------------middle-----------------------------------
    DrawLine(hDC, width+x-10, height-z, width+x-n, height-z, rgb, 1);
    DrawLine(hDC, width+x+(n+1), height-z, width+x+11, height-z, rgb, 1);
    DrawLine(hDC, width+x, height-z+10, width+x, height-z+n, rgb, 1);
    DrawLine(hDC, width+x, height-z-(n+1), width+x, height-z-11, rgb, 1);

    //----------------------------------right-----------------------------------
    DrawLine(hDC, 2*width+y-10, height-z, 2*width+y-n, height-z, rgb, 1);
    DrawLine(hDC, 2*width+y+(n+1), height-z, 2*width+y+11, height-z, rgb, 1);
    DrawLine(hDC, 2*width+y, height-z+10, 2*width+y, height-z+n, rgb, 1);
    DrawLine(hDC, 2*width+y, height-z-(n+1), 2*width+y, height-z-11, rgb, 1);

    return 1;
}







//====================================================================================================
//                              Draw a line to handle hDC
//                              draw it in colour col
//====================================================================================================
int DrawLine(HDC hDC, int xstart, int ystart, int xend, int yend, COLORREF col, int width){

	HPEN hPen,hOldPen;

	hPen=CreatePen(PS_SOLID, width,col);

	hOldPen=SelectObject(hDC,hPen);

	MoveToEx(hDC,xstart,ystart,NULL);

	LineTo(hDC,xend,yend);

	SelectObject(hDC,hOldPen);

	DeleteObject(hPen);

	return 1;
}

//====================================================================================================
//                              Draw a rectangle to handle hDC
//                              draw it in colour col
//====================================================================================================
int DrawRectangle(HDC hDC, int left, int top, int right, int bottom, COLORREF col){

    HBRUSH hBrush, hOldBrush;

    hBrush=CreateSolidBrush( col );


	hOldBrush=SelectObject(hDC,hBrush);

    Rectangle(hDC,left,top,right,bottom);


	SelectObject(hDC,hOldBrush);

	DeleteObject(hBrush);

	return 1;
}
















//======================================================================================================
//                             fill the Picture structure
//                             action depends on image type
//======================================================================================================
int FillPictureStruct(HWND hwnd, struct Picture *picture, struct Image *image){


    if ( (!(*image).X) || (!(*image).Y) ) return 0;                                 //got to be an image to work on



    (*picture).X=(*image).X;
    (*picture).Y=(*image).Y;
    (*picture).Z=(*image).Z;
    (*picture).volumes=(*image).volumes;


    if (!(*picture).ML.valid) (*picture).ML=FindImageMatrixLimits(image);

    if ( (*picture).slice>=(*image).Z ) (*picture).slice=(*image).Z-1;


    if ( (*picture).zoom<=0.1 ) (*picture).zoom=0.1;


    return RGBPicture(hwnd, picture, image);
}













//======================================================================================================
//return an appropriate RGB value for a given voxel
//======================================================================================================
RGBQUAD PictureIntensity(HWND hwnd, int voxel, struct Picture *picture, struct Image *image, int ColBckgrnd, int ShowOverlays)
{

    RGBQUAD rgbQuad, rgb;
    float scale;
    float thresh[2]={0.0,0.0};
    float range;
    int r,g,b;
    int i,n;
    int col[MAX_OVERLAYS];

    memset(&rgbQuad,0,sizeof(RGBQUAD));

    if (ColBckgrnd && ((*image).img[voxel]<=0.0))
    {
            rgbQuad.rgbBlue=gOptions.Blue;
            rgbQuad.rgbRed=gOptions.Red;
            rgbQuad.rgbGreen=gOptions.Green;
    }
    else if ( IsImageScalar((*image).DataType) )
    {
        if (((*picture).Highlight) &&
            ((*image).img[voxel]>=(*picture).HighlightLo) &&
            (((*image).img[voxel]<=(*picture).HighlightHi)))rgbQuad.rgbRed=255;
        else
        {
            //get the slice dependent quantiles
            thresh[0]=(*image).MaxIntensity*(*picture).LowThresh;
            thresh[1]=(*image).MaxIntensity*(*picture).saturation;
            if ( (range=thresh[1]-thresh[0])<=0.0 ) return rgbQuad;

            scale=(float)MAX_INTENSITY/range;

            i=(int)(scale*((*image).img[voxel]-thresh[0]));
            if (i>=MAX_INTENSITY) i=MAX_INTENSITY-1;
            if (i<0) i=0;

            rgbQuad.rgbBlue=rgbQuad.rgbRed=rgbQuad.rgbGreen=(BYTE)i;
        }

    }
    else if ((*image).DataType==DT_RGB)
    {
        if ((*picture).saturation<=0.0) (*picture).saturation=0.001;
        memcpy(&rgb, &(*image).img[voxel], sizeof(float));
        r=rgb.rgbRed/(*picture).saturation;
        if (r>255.0) r=255.0;
        g=rgb.rgbGreen/(*picture).saturation;
        if (g>255.0) g=255.0;
        b=rgb.rgbBlue/(*picture).saturation;
        if (b>255.0) b=255.0;
        rgbQuad.rgbBlue=(BYTE)b;
        rgbQuad.rgbRed=(BYTE)r;
        rgbQuad.rgbGreen=(BYTE)g;
    }

    if (ShowOverlays && gNumberOfOverlays)
    {
        if (IsMenuItemChecked(hwnd, IDM_OVERLAY_RGB)){r=0;g=1;b=2;}
        else if (IsMenuItemChecked(hwnd, IDM_OVERLAY_RBG)){r=0;g=2;b=1;}
        else if (IsMenuItemChecked(hwnd, IDM_OVERLAY_GRB)){r=1;g=0;b=2;}
        else if (IsMenuItemChecked(hwnd, IDM_OVERLAY_GBR)){r=2;g=0;b=1;}
        else if (IsMenuItemChecked(hwnd, IDM_OVERLAY_BGR)){r=2;g=1;b=0;}
        else {r=1;g=2;b=0;}
        memset(col,0,sizeof(int)*MAX_OVERLAYS);
        n=0;
        for (i=0;i<gNumberOfOverlays;i++)
        {
            if (gOverlayImg[i].img[voxel]!=0.0)
            {
                if (IsMenuItemChecked(hwnd, IDM_SHOW_SOLID_OVERLAYS))
                {
                    if (i<MAX_OVERLAYS) col[i] += 200;
                }
                else
                {
                    memcpy(&rgb,&gOverlayImg[i].img[voxel],sizeof(RGBQUAD));
                    col[0]+=rgb.rgbRed;
                    col[1]+=rgb.rgbGreen;
                    col[2]+=rgb.rgbBlue;
                }
                n++;
            }
        }
        if (n)
        {
                rgbQuad.rgbRed=col[r]/n;
                rgbQuad.rgbGreen=col[g]/n;
                rgbQuad.rgbBlue=col[b]/n;
        }
    }



    return rgbQuad;
}


//======================================================================================================
//                         fill the picture structure for RGB images
//======================================================================================================
int RGBPicture(HWND hwnd, struct Picture *picture, struct Image *image){

    int x,y;
    int voxel;
    int x0,y0,x1,y1;
    int pixel;
    int ColBckgrnd=0, ShowOverlays=0;
    RGBQUAD rgb;



    x0=(*picture).ML.x0;
    x1=(*picture).ML.x1;
    y0=(*picture).ML.y0;
    y1=(*picture).ML.y1;

    if (IsMenuItemChecked(hwnd, IDM_COLOUR_BACKGROUND)) ColBckgrnd=1;
    if (IsMenuItemChecked(hwnd, IDM_SHOW_OVERLAYS)) ShowOverlays=1;


    //---------compute the picture for the current plane only---------------
    if (!IsMenuItemChecked(hwnd, IDM_VIEW_PLANES)){
        //PictureSize(picture, 0);

        //-----------allocate the memory for the pixel  bits----------------------
        //mod 28/07/2010
        //only malloc (*picture).pict if it isnt already malloced with the correct number of bytes; stored in (*picture).PictureBytes
        if (PictureSize(picture, 0) || !(*picture).pict || (*picture).PictureBytes!=(*picture).width*(*picture).height*3){
	        if ((*picture).pict) free((*picture).pict);
    	    if (!((*picture).pict=(unsigned char *)malloc((*picture).width*(*picture).height*3))){
        	  (*picture).width=0;                 //if its failed, then set the size of the picture to zero
	          (*picture).height=0;
	          (*picture).PictureBytes=0;
    	      return 0;
        	}
        	(*picture).PictureBytes=(*picture).width*(*picture).height*3;

		}


        memset((*picture).pict,0,(*picture).width*(*picture).height*3);
        if ( (*image).MaxIntensity<=0.0 ){
			return 0;
		}






        if ((*picture).slice<0) (*picture).slice=(*image).Z/2;
        if ((*picture).slice>=(*image).Z ) (*picture).slice=(*image).Z-1;

        if ((*picture).saturation<=0.0) (*picture).saturation=0.001;

        for (y=y0; y<y1; y++){
           for (x=x0; x<x1; x++){
               voxel=x + y*(*image).X + (*picture).slice*(*image).X*(*image).Y;
               rgb=PictureIntensity(hwnd, voxel, picture, image, ColBckgrnd, ShowOverlays);
               pixel=(x-x0)+(y-y0)*(*picture).width;
               (*picture).pict[pixel*3]    =rgb.rgbBlue;
               (*picture).pict[pixel*3+1]  =rgb.rgbGreen;
               (*picture).pict[pixel*3+2]  =rgb.rgbRed;

           }
        }



        (*picture).bmphdr=DefineBitmap((*picture).width, (*picture).height);
    }
    else OrthogonalRGBPicture(hwnd, picture, image);

    return 1;
}







//======================================================================================================
//                         fill the picture structure for Orthogonal RGB images
//mod 'oset' 28/07/2010
//======================================================================================================
int OrthogonalRGBPicture(HWND hwnd, struct Picture *picture, struct Image *image){

    int x,y,z;
    int voxel;
    int x0,y0,x1,y1;
    int pixel;
    int oset;
    int ColBckgrnd=0, ShowOverlays=0;
    RGBQUAD rgb;

    x0=(*picture).ML.x0;
    x1=(*picture).ML.x1;
    y0=(*picture).ML.y0;
    y1=(*picture).ML.y1;


    if (IsMenuItemChecked(hwnd, IDM_COLOUR_BACKGROUND)) ColBckgrnd=1;
    if (IsMenuItemChecked(hwnd, IDM_SHOW_OVERLAYS)) ShowOverlays=1;



    //-----------allocate the memory for the pixel  bits----------------------
    //mod 28/07/2010
    //only malloc (*picture).pict if it isnt already malloced with the correct number of bytes; stored in (*picture).PictureBytes
    if (PictureSize(picture, 1) || !(*picture).pict || (*picture).PictureBytes!=(*picture).width*(*picture).height*3){
	    if ((*picture).pict) free((*picture).pict);
    	if (!((*picture).pict=(unsigned char *)malloc((*picture).width*(*picture).height*3))){
	      (*picture).width=0;                        //if its failed, then set the size of the picture to zero
    	  (*picture).height=0;
    	  (*picture).PictureBytes=0;
          return 0;
    	}
    	(*picture).PictureBytes=(*picture).width*(*picture).height*3;
	}



    memset((*picture).pict,0,(*picture).width*(*picture).height*3);
    if ( (*image).MaxIntensity<=0.0 ) return 0;


    if ((*picture).x<0) (*picture).x=0;
    if ((*picture).x>=(*image).X ) (*picture).x=(*image).X-1;
    if ((*picture).y<0) (*picture).y=0;
    if ((*picture).y>=(*image).Y ) (*picture).y=(*image).Y-1;
    if ((*picture).slice<0) (*picture).slice=0;
    if ((*picture).slice>=(*image).Z ) (*picture).slice=(*image).Z-1;
    if ((*picture).saturation<=0.0) (*picture).saturation=0.001;

    for (y=y0; y<y1; y++){
        oset=y*(*image).X + (*picture).slice*(*image).X*(*image).Y;                                                      //left
        for (x=x0; x<x1; x++){
            voxel=x + oset;
            rgb=PictureIntensity(hwnd, voxel, picture, image, ColBckgrnd, ShowOverlays);
            pixel=(x-x0)+(y-y0)*(*picture).width;
            (*picture).pict[pixel*3]    =rgb.rgbBlue;
            (*picture).pict[pixel*3+1]  =rgb.rgbGreen;
            (*picture).pict[pixel*3+2]  =rgb.rgbRed;

        }
    }


    for (z=0; z<(*image).Z; z++){
        oset=(*picture).y*(*image).X + z*(*image).X*(*image).Y;                                               //middle
        for (x=x0; x<x1; x++){
            voxel=x + oset;
            rgb=PictureIntensity(hwnd, voxel, picture, image, ColBckgrnd, ShowOverlays);
            pixel=(x1-x0+1)+(x-x0)+z*(*picture).width;
            (*picture).pict[pixel*3]    =rgb.rgbBlue;
            (*picture).pict[pixel*3+1]  =rgb.rgbGreen;
            (*picture).pict[pixel*3+2]  =rgb.rgbRed;


        }
    }

    for (z=0; z<(*image).Z; z++){
        oset=(*picture).x + z*(*image).X*(*image).Y;                                              //right
        for (y=y0; y<y1; y++){
            voxel=y*(*image).X +oset;
            rgb=PictureIntensity(hwnd, voxel, picture, image, ColBckgrnd, ShowOverlays);
            pixel=2*(x1-x0+1)+(y-y0)+z*(*picture).width;
            (*picture).pict[pixel*3]    =rgb.rgbBlue;
            (*picture).pict[pixel*3+1]  =rgb.rgbGreen;
            (*picture).pict[pixel*3+2]  =rgb.rgbRed;

        }
    }

   (*picture).bmphdr=DefineBitmap((*picture).width, (*picture).height);

    return 1;
}







//======================================================================================================
//                         compute the picture width and height
//						   returns 0 if the size is unchanged
//						   returns 1 otherwise
//mod 28/07/2010
//======================================================================================================
int PictureSize(struct Picture *picture, int Orthogonal){

    int initwidth, initheight;
    int width, height;

    initwidth=(*picture).width;
    initheight=(*picture).height;

    width   =((*picture).ML.x1-(*picture).ML.x0+1);     //width determined by limited matrix
    height  =((*picture).ML.y1-(*picture).ML.y0+1);     //height determined by limited matrix


    if (!Orthogonal){
        (*picture).width=4*(width/4+1);                                         //picture width must be a multiple of 4 bytes
        (*picture).height=height;
    }
    else{
        //width should be twice the X dimension, plus the Y dimension
        (*picture).width=4*((2*width+height)/4+1);                              //picture width must be a multiple of 4 bytes
        //height should be the largest of the image Y and Z dimensions
        (*picture).height=(height > (*picture).Z) ? height:(*picture).Z;
    }

    if ((*picture).width==initwidth && (*picture).height==initheight) return 0;

    return 1;
}













//======================================================================================================
//                         Picture coordinates to image coordinates
//======================================================================================================
int PictureToImage(struct Picture *picture, short int picx, short int picy, short int *x, short int *y, short int *z,
                    int Orthogonal){

    int xpic, ypic;
    int height=(*picture).height;
    int width;

    picy=(int)(height*(*picture).zoom)-picy;//invert coordinate system because windows origin is top left
                                            //and picture origin is bottom left


    if (((*picture).zoom)<=0.0) return 0;

    if (!Orthogonal){
       (*x)=(int)((float)picx/(*picture).zoom + 0.5) + (*picture).ML.x0;      //add the matrix limit offsets
       (*y)=(int)((float)picy/(*picture).zoom + 0.5) + (*picture).ML.y0;
       (*z)=(*picture).slice;
    }
    else{
       width=((*picture).ML.x1-(*picture).ML.x0+1);         //width determined by limited matrix
       xpic=(int)((float)picx/(*picture).zoom + 0.5);
       ypic=(int)((float)picy/(*picture).zoom + 0.5);
       if (xpic<width){                                     //left
          (*x)=xpic+(*picture).ML.x0;
          (*y)=ypic+(*picture).ML.y0;
          (*z)=(*picture).slice;
       }
       else if (xpic>=width && xpic<(2*width) ){            //middle
          (*x)=xpic-width+(*picture).ML.x0;
          (*y)=(*picture).y;
          (*z)=ypic;

       }
       else{                                                //right
          (*x)=(*picture).x;
          (*y)=xpic-2*width+(*picture).ML.y0;
          (*z)=ypic;
       }

    }




    //check that we are not outside the limits of the image
    if ( (*x)>=(*picture).X ) (*x)=(*picture).X-1;
    if ( (*x)<0 ) (*x)=0;

    if ( (*y)>=(*picture).Y ) (*y)=(*picture).Y-1;
    if ( (*y)<0 ) (*y)=0;

    if ( (*z)>=(*picture).Z ) (*z)=(*picture).Z-1;
    if ( (*z)<0 ) (*z)=0;


    return 1;
}





//======================================================================================================
//                         Image coordinates to picture coordinates
//======================================================================================================
int ImageToPicture(struct Picture *picture, short int *picx, short int *picy, short int x, short int y, short int z){


    (*picx)=(x-(*picture).ML.x0);
    (*picy)=(y-(*picture).ML.y0);


    (*picy)=((*picture).height-1)-(*picy);    //invert coordinate system because windows origin is top left
                                        //and picture origin is bottom left


    return 1;
}













//======================================================================================================
//                         compute only the rectangle for the image
//                         exclude other child windows
//======================================================================================================
RECT GetImageRect(HWND hwndMain, HWND hStatus, HWND hTool){

     RECT imageRect;
     RECT rectMain, rectSB, rectTB;

     GetClientRect(hStatus,&rectSB);                                            //statusbar rectangle
     GetClientRect(hTool,&rectTB);                                              //toolbar rectangle
     GetClientRect(hwndMain,&rectMain);                                         //main window rectangle
	 imageRect.top=rectTB.bottom+3;
	 imageRect.bottom=rectMain.bottom-(rectSB.bottom-rectSB.top+2);             //rectangle to be scrolled
	 imageRect.left=rectMain.left;
     imageRect.right=rectMain.right;

     return imageRect;
}





//======================================================================================================
//                         Save a bitmap of displayed image to disk
//======================================================================================================
int SaveBitmap(struct Picture *pict, HWND hwndMain, HDC hDC, int GetName, char directory[]){

    int pixels=(*pict).width*(*pict).height;
	HDC hMemDC;
	HBITMAP hOldbmp;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap ;
	FILE *fp;
	OPENFILENAME fnamedlg;
	char txt[MAX_PATH];

	memset(txt,0,MAX_PATH);
	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=hwndMain;
	fnamedlg.lpstrFilter="Bitmap Files\0*.bmp\0\0";
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=txt;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrFileTitle=NULL;
	fnamedlg.lpstrInitialDir="./";
	fnamedlg.lpstrTitle="Select Bitmap File";
	fnamedlg.lpstrDefExt="BMP";

	//File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=(*pict).width;
	BmCoreHdr.bcHeight=(*pict).height;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	//Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=(*pict).width;
	BmInfoHdr.biHeight=(*pict).height;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;


	hMemDC=CreateCompatibleDC(hDC);


	//Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldbmp=SelectObject(hMemDC, hBitmap);


	//Now copy to the memory DC
	BitBlt(hMemDC,0,0,(*pict).width,(*pict).height,hDC, 0,0,SRCCOPY);


    if (GetName)
    {
        if (!GetSaveFileName(&fnamedlg))
        {
            MessageBox(hwndMain,"Unable to save bitmap","",MB_OK|MB_ICONWARNING);
            return 0;
        }
    }
	else sprintf(txt,"%s/slice%d.bmp",directory,(*pict).slice);


    //Now save the bitmap file
	if ( (fp=fopen(txt,"wb")) ){
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}


	SelectObject(hMemDC, hOldbmp);
	DeleteObject(hBitmap);
	DeleteDC(hMemDC);

	return 1;
}


//=======================================================================================
//                      Use PeekMessage to remove keyboard input
//                      Prevents the program from stopping responding
//=======================================================================================
int RemoveInput(HWND hwnd)
{

    MSG Msg;

    while (PeekMessage (&Msg, NULL, 0, 0, PM_REMOVE))
    {
        TranslateMessage (&Msg);
        DispatchMessage (&Msg);
    }

    //PeekMessage(&Msg, hwnd, WM_MOUSEFIRST, WM_MOUSELAST, PM_REMOVE);

    return 0;
}

//=======================================================================================
//colour map
//divides the colour space (RGB) into n*7 points
//n represents the intensity
//for each of n there are : r,g,b,r+g,r+b,g+b,r+g+b;
//returns RGBQUAD
//=======================================================================================
RGBQUAD Colours(int index, int n)
{
    RGBQUAD rgb;
    unsigned char *V=NULL;
    int i,j,step,n6;

    n6=n*6;

    memset(&rgb,0,sizeof(RGBQUAD));

    if (n<1) goto END;

    if (index>=n6) index=index%n6;

    if (!(V=(unsigned char *)malloc(n))) goto END;


    step=255/n;
    for (i=0;i<n;i++)
    {
        V[i] = 255-i*step;
    }

    i = index/6;
    j = index - i*6;

    switch(j)
    {
    case 0:
        rgb.rgbRed=V[i]; rgb.rgbGreen=0; rgb.rgbBlue=0;
        break;
    case 1:
        rgb.rgbRed=0; rgb.rgbGreen=V[i]; rgb.rgbBlue=0;
        break;
    case 2:
        rgb.rgbRed=0; rgb.rgbGreen=0; rgb.rgbBlue=V[i];
        break;
    case 3:
        rgb.rgbRed=V[i]; rgb.rgbGreen=V[i]; rgb.rgbBlue=0;
        break;
    case 4:
        rgb.rgbRed=V[i]; rgb.rgbGreen=0; rgb.rgbBlue=V[i];
        break;
    case 5:
        rgb.rgbRed=0; rgb.rgbGreen=V[i]; rgb.rgbBlue=V[i];
        break;
    }


END:
    if (V) free(V);
    return rgb;
}
