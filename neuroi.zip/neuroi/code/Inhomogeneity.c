/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "inhomogeneity.h"
#include "imageprocess.h"
#include "graphtheoryalgorithms.h"
#include "polynomial.h"
#include "classification.h"

#define SIZE 2.0//voxels will be this size as a minimum


//there are 84 terms in the ^6 3D polynomial, including the constant term
//there are 56 terms in the ^5 3D polynomial, including the constant term
//there are 35 terms in the ^4 3D polynomial, including the constant term
//there are 20 terms in the ^3 3D polynomial, including the constant term
//there are 10 terms in the ^2 3D polynomial, including the constant term
#define P_ORDER 4   //polynomial order
#define TERMS 35   //number of terms




//========================================================================================
//            Correct Gain By Classification
//========================================================================================
int CorrectInhomogeneityUsingClassification(HWND hwnd, struct Image *image, int classes, int iterations){

    float x0,y0,z0;
    float fovx,fovy,fovz;
    float dx,dy,dz;
    float *tmp=NULL;
    double Coef[TERMS], CoefSum[TERMS];
    struct Image Small;
    unsigned char *Prob=NULL;
    int x,y,z;
    int xs,ys,zs;
    int voxel,voxels;
    int iter;
    int term;
    int result=0;

    if (classes<2) goto END;

    voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;

    memset(&Small,0,sizeof(struct Image));

    if (!(Prob=(unsigned char *)malloc(voxels*classes))) goto END;
    if (!(tmp=(float *)malloc(voxels*sizeof(float)))) goto END;

    //make low resolution version of image
    if (!MakeCopyOfImage( image, &Small )) goto END;
    if (Small.dx<SIZE) dx=SIZE; else dx=Small.dx;
    if (Small.dy<SIZE) dy=SIZE; else dy=Small.dy;
    if (Small.dz<SIZE) dz=SIZE; else dz=Small.dz;
    if (!ReSizeImage(&Small, dx, dy, dz)) goto END;
    AutoRemoveNoisyBackground(hwnd, &Small,0);
    FreeROIMemory();

    fovx=Small.dx*Small.X;x0=fovx/2.0;
    fovy=Small.dy*Small.Y;y0=fovy/2.0;
    fovz=Small.dz*Small.Z;z0=fovz/2.0;

    memset(CoefSum,0,sizeof(double)*TERMS);
    iter=0;
    do{
       if (SingleVolumeClassification(&Small, classes, Prob, classes)){

          FitClassPolynomialBayes(Small.img, Prob, Small.dx, Small.dy, Small.dz, Small.X, Small.Y, Small.Z,
                                      x0, y0, z0, fovx, fovy, fovz,
                                      Coef, P_ORDER, TERMS, classes-1);//dont use the lowest class

          CorrectPolynomialGain(Small.img, Small.X, Small.Y, Small.Z, Small.dx, Small.dy, Small.dz, x0, y0, z0,
                                fovx, fovy, fovz, Coef, P_ORDER, TERMS);

          for (term=0;term<TERMS;term++) CoefSum[term] += Coef[term];
       }
       iter++;
    }
    while(iter<iterations);

    //--------Get a copy of image in tmp--------------
    //--------remove the background voxels------------
    voxel=0;
    for (z=0;z<(*image).Z;z++)
    {
        zs = (int)((*image).dz*z/Small.dz + 0.5);
        for (y=0;y<(*image).Y;y++)
        {
            ys = (int)((*image).dy*y/Small.dy + 0.5);
            for (x=0;x<(*image).X;x++)
            {
                xs = (int)((*image).dx*x/Small.dx + 0.5);
                if ((xs<Small.X) && (ys<Small.Y) && (zs<Small.Z))
                {
                  if (fabs(Small.img[xs + ys*Small.X + zs*Small.X*Small.Y])>0.0) tmp[voxel] = (*image).img[voxel];
                }
                voxel++;
            }
        }
    }

    CorrectPolynomialGain(tmp, (*image).X, (*image).Y, (*image).Z/(*image).volumes, (*image).dx, (*image).dy, (*image).dz, x0, y0, z0,
                                fovx, fovy, fovz, CoefSum, P_ORDER, TERMS);

    for (voxel=0;voxel<voxels;voxel++)
    {
        if (fabs(tmp[voxel])>0.0) (*image).img[voxel] = tmp[voxel];
    }

    result=1;
END:

    ReleaseImage(&Small);
    if (tmp) free(tmp);

    if (Prob) free(Prob);
    return result;
}


//=========================================================================
//SLICEWISE GAIN CORRECTION
//=========================================================================
int CorrectSliceIntensityInhomogeneity(struct Image *image)
{
    int X,Y,Z;
    int x,y,z;
    int voxel;
    double *means=NULL;
    int count;
    double grandmean;
    int grandcount;
    struct Image Cpy;

    memset(&Cpy,0,sizeof(struct Image));

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;

    if (!(means=(double *)calloc(Z,sizeof(double)))) goto END;
    if (!MakeCopyOfImage(image, &Cpy)) goto END;

    AutoRemoveNoisyBackground(NULL, &Cpy, 0);

    grandcount=0;
    grandmean=0.0;
    voxel=0;
    for (z=0;z<Z;z++)
    {
        count=0;
        for (y=0;y<Y;y++)
        {
            for (x=0;x<X;x++)
            {

                    if (Cpy.img[voxel]>0.0)
                    {
                        count++;
                        means[z]+=Cpy.img[voxel];
                        grandcount++;
                        grandmean+=Cpy.img[voxel];
                    }
                    voxel++;
            }
        }
        if (count)
        {
            means[z]/=count;
        }
    }
    if (grandcount)
    {
        grandmean/=grandcount;
    }


    voxel=0;
    for (z=0;z<Z;z++)
    {
        for (y=0;y<Y;y++)
        {
            for (x=0;x<X;x++)
            {
                (*image).img[voxel] *= grandmean/means[z];
            }
            voxel++;
        }
    }



END:
    if (means) free(means);
    ReleaseImage(&Cpy);

    return 0;
}





















//========================================================================================
//              Test
//========================================================================================
int TestInhomogeneity(struct Image *image){

    int x,y,z;
    int X, Y, Z;
    int voxel;
    float dx, dy, dz;
    float x0, y0,z0;
    float g;

    X=(*image).X; Y=(*image).Y; Z=(*image).Z/(*image).volumes;
    dx=(*image).dx; dy=(*image).dy;dz=(*image).dz;

    x0=dx*X/2.0;y0=dy*Y/2.0;z0=dz*Z/2.0;

    for (z=0;z<Z;z++){
        for (y=0;y<Y;y++){
            for (x=0;x<X;x++){
                voxel=x+y*X+z*X*Y;
                g=1.0+0.8*(x*dx-x0)/x0+pow((y*dy-y0)/y0,2)+pow((x*dx-x0)/x0,2)+0.5*pow((z*dz-z0)/z0,3);
                (*image).img[voxel]*=g;
            }
        }
    }


    return 1;
}




