/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include "menuresources.h"
#include "options.h"
#include "global.h"

#define SCROLL_MAX 255
#define SCROLL_MIN 0
//=============================================================================================
//                           OPTIONS dialog callback function
//=============================================================================================
INT_PTR CALLBACK OptionsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    int pos;
    char txt[256];
    HDC hDC;
    HBRUSH Brush,OldBrush;

    switch(msg) {


	case WM_CLOSE:
        SaveOptions(ExecutableDirectory, &gOptions);
        if (gOptions.UseColourBackground) CheckMenuItem(GetMenu(hwnd), IDM_COLOUR_BACKGROUND, MF_CHECKED);
        if (gOptions.standardise_scale) CheckMenuItem(GetMenu(hwnd), IDM_LOAD_WITH_STANDARD_SCALE, MF_CHECKED);
        hwndOptions=(HWND)NULL;
		EndDialog(hwnd,0);
	break;



    case WM_SHOWWINDOW:
        if (gOptions.UseColourBackground) SendMessage(GetDlgItem(hwnd,ID_COLOUR_BKGRND),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_COLOUR_BKGRND),BM_SETCHECK,BST_UNCHECKED,0);

        if (gOptions.TissueClass) SendMessage(GetDlgItem(hwnd,IDM_CLASSIFY_WM_GM_CSF),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,IDM_CLASSIFY_WM_GM_CSF),BM_SETCHECK,BST_UNCHECKED,0);
        if (gOptions.alignDWI) SendMessage(GetDlgItem(hwnd,IDM_ALIGN_DWI),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,IDM_ALIGN_DWI),BM_SETCHECK,BST_UNCHECKED,0);
        if (gOptions.SmoothDWI) SendMessage(GetDlgItem(hwnd,IDM_DWI_FILTER_RESIDUAL),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,IDM_DWI_FILTER_RESIDUAL),BM_SETCHECK,BST_UNCHECKED,0);
        if (gOptions.ExtractBrain) SendMessage(GetDlgItem(hwnd,IDM_EXTRACT_BRAIN),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,IDM_EXTRACT_BRAIN),BM_SETCHECK,BST_UNCHECKED,0);
        if (gOptions.standardise_scale) SendMessage(GetDlgItem(hwnd,IDM_LOAD_WITH_STANDARD_SCALE),BM_SETCHECK,BST_UNCHECKED,0);
        else SendMessage(GetDlgItem(hwnd,IDM_LOAD_WITH_STANDARD_SCALE),BM_SETCHECK,BST_CHECKED,0);


        sprintf(txt,"%f",gOptions.FAmin_GTmask);
        SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETPOS,(int)(gOptions.FAmin_GTmask*SCROLL_MAX),TRUE);

        sprintf(txt,"%d",gOptions.Red);
        SendMessage(GetDlgItem(hwnd,ID_RED_BKGRND_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_RED_BKGRND),SBM_SETPOS,gOptions.Red,TRUE);

        sprintf(txt,"%d",gOptions.Green);
        SendMessage(GetDlgItem(hwnd,ID_GREEN_BKGRND_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_GREEN_BKGRND),SBM_SETPOS,gOptions.Green,TRUE);

        sprintf(txt,"%d",gOptions.Blue);
        SendMessage(GetDlgItem(hwnd,ID_BLUE_BKGRND_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_BLUE_BKGRND),SBM_SETPOS,gOptions.Blue,TRUE);

        Brush=CreateSolidBrush(RGB(gOptions.Red, gOptions.Green, gOptions.Blue));
        hDC=GetDC(hwnd);
        OldBrush=SelectObject(hDC, Brush);
        Rectangle(hDC, 50, 260, 240, 290);
        SelectObject(hDC, OldBrush);
        DeleteObject(Brush);
        ReleaseDC(hwnd,hDC);

        sprintf(txt,"%d",gOptions.TensorDeflect_n);
        SendMessage(GetDlgItem(hwnd,ID_DEFLECTIONS_TEXT),WM_SETTEXT,0,(LPARAM)txt);
    break;



    case WM_INITDIALOG:
        SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);

        SendMessage(GetDlgItem(hwnd,ID_RED_BKGRND),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);

		SendMessage(GetDlgItem(hwnd,ID_GREEN_BKGRND),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);

		SendMessage(GetDlgItem(hwnd,ID_BLUE_BKGRND),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);
    break;


    case WM_HSCROLL:
  		pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		switch (LOWORD(wParam)){
			case SB_LINELEFT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-1) , TRUE);
				break;
			case SB_LINERIGHT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+1) , TRUE);
				break;
			case SB_PAGELEFT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-SCROLL_MAX/10) , TRUE);
				break;
			case SB_PAGERIGHT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+SCROLL_MAX/10) , TRUE);
				break;
			case SB_THUMBTRACK:
				SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam) , TRUE);
				break;
		}

        gOptions.Red=(int)SendMessage( GetDlgItem(hwnd,ID_RED_BKGRND), SBM_GETPOS, 0, 0);
        gOptions.Green=(int)SendMessage( GetDlgItem(hwnd,ID_GREEN_BKGRND), SBM_GETPOS, 0, 0);
        gOptions.Blue=(int)SendMessage( GetDlgItem(hwnd,ID_BLUE_BKGRND), SBM_GETPOS, 0, 0);

        gOptions.FAmin_GTmask=(float)SendMessage( GetDlgItem(hwnd,ID_FA_THRESHOLD), SBM_GETPOS, 0, 0)/SCROLL_MAX;

        SendMessage(hwnd, WM_SHOWWINDOW,0,0);
        SetFocus(GetParent(hwnd));
    break;



    case WM_COMMAND:
	  switch (LOWORD(wParam)) {

        case IDM_ALIGN_DWI:
             if (gOptions.alignDWI) gOptions.alignDWI=0;
             else gOptions.alignDWI=1;
             if (gOptions.alignDWI) SendMessage(GetDlgItem(hwnd,IDM_ALIGN_DWI),BM_SETCHECK,BST_CHECKED,0);
             else SendMessage(GetDlgItem(hwnd,IDM_ALIGN_DWI), BM_SETCHECK,BST_UNCHECKED,0);
        break;
        case IDM_DWI_FILTER_RESIDUAL:
            if (gOptions.SmoothDWI) gOptions.SmoothDWI=0;
             else gOptions.SmoothDWI=1;
             if (gOptions.SmoothDWI) SendMessage(GetDlgItem(hwnd,IDM_DWI_FILTER_RESIDUAL),BM_SETCHECK,BST_CHECKED,0);
             else SendMessage(GetDlgItem(hwnd,IDM_DWI_FILTER_RESIDUAL),BM_SETCHECK,BST_UNCHECKED,0);
        break;
        case IDM_CLASSIFY_WM_GM_CSF:
             if (gOptions.TissueClass) gOptions.TissueClass=0;
             else gOptions.TissueClass=1;
             if (gOptions.TissueClass) SendMessage(GetDlgItem(hwnd,IDM_CLASSIFY_WM_GM_CSF),BM_SETCHECK,BST_CHECKED,0);
             else SendMessage(GetDlgItem(hwnd,IDM_CLASSIFY_WM_GM_CSF),BM_SETCHECK,BST_UNCHECKED,0);
        break;
        case IDM_EXTRACT_BRAIN:
             if (gOptions.ExtractBrain) gOptions.ExtractBrain=0;
             else gOptions.ExtractBrain=1;
             if (gOptions.ExtractBrain) SendMessage(GetDlgItem(hwnd,IDM_EXTRACT_BRAIN),BM_SETCHECK,BST_CHECKED,0);
             else SendMessage(GetDlgItem(hwnd,IDM_EXTRACT_BRAIN),BM_SETCHECK,BST_UNCHECKED,0);
        break;


        case ID_COLOUR_BKGRND:
            if (gOptions.UseColourBackground) gOptions.UseColourBackground=0;
            else gOptions.UseColourBackground=1;
            if (gOptions.UseColourBackground) SendMessage(GetDlgItem(hwnd,ID_COLOUR_BKGRND),BM_SETCHECK,BST_CHECKED,0);
            else SendMessage(GetDlgItem(hwnd,ID_COLOUR_BKGRND),BM_SETCHECK,BST_UNCHECKED,0);
        break;

        case IDM_LOAD_WITH_STANDARD_SCALE:
            if (gOptions.standardise_scale) gOptions.standardise_scale=0;
            else gOptions.standardise_scale=1;
            if (gOptions.standardise_scale) SendMessage(GetDlgItem(hwnd,IDM_LOAD_WITH_STANDARD_SCALE),BM_SETCHECK,BST_UNCHECKED,0);
            else SendMessage(GetDlgItem(hwnd,IDM_LOAD_WITH_STANDARD_SCALE),BM_SETCHECK,BST_CHECKED,0);
        break;


        case ID_DEFAULT_OPTIONS:
            DefaultOptions(&gOptions);
            SendMessage(hwnd, WM_SHOWWINDOW,0,0);
        break;



		case IDOK:
	        SendMessage(GetDlgItem(hwnd,ID_DEFLECTIONS_TEXT),WM_GETTEXT, 3, (LPARAM)txt);
            gOptions.TensorDeflect_n=atoi(txt);
            if (gOptions.TensorDeflect_n<1) gOptions.TensorDeflect_n=1;
            if (gOptions.TensorDeflect_n>10) gOptions.TensorDeflect_n=10;

    		SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}





//============================================================================================================
int DefaultOptions(struct NeuRoiOptions *opt){

    (*opt).TemplateDir[0]='\0';
    (*opt).UseColourBackground=1;
    (*opt).Red=0;
    (*opt).Green=45;
    (*opt).Blue=45;
    (*opt).FAmin_GTmask=0.15;
    (*opt).TensorDeflect_n=3;
    (*opt).TissueClass=1;
    (*opt).alignDWI=1;
    (*opt).SmoothDWI=1;
    (*opt).ExtractBrain=1;
    (*opt).standardise_scale=0;
    return 1;
}



//============================================================================================================
int SaveOptions(char ExecutableDirectory[], struct NeuRoiOptions *opt){

    FILE *fp;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\options.opt",ExecutableDirectory);
    if (!(fp=fopen(fname,"wb"))) return 0;

    fwrite(opt, 1, sizeof(struct NeuRoiOptions), fp);

    fclose(fp);

    return 1;
}
//============================================================================================================
int LoadOptions(char ExecutableDirectory[], struct NeuRoiOptions *opt){

    FILE *fp;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\options.opt",ExecutableDirectory);
    if (!(fp=fopen(fname,"rb"))){
        DefaultOptions(opt);
        return 0;
    }

    if (fread(opt, 1, sizeof(struct NeuRoiOptions), fp)!=sizeof(struct NeuRoiOptions)) DefaultOptions(opt);

    //sprintf(fname,"%d %d %d %d",(*opt).TissueClass, (*opt).alignDWI, (*opt).SmoothDWI, (*opt).ExtractBrain);
    //MessageBox(NULL,fname,"",MB_OK);

    fclose(fp);
    return 1;
}
