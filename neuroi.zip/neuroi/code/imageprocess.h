/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(ImageProcess_H)
//Do Nothing
#else



#define ImageProcess_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include <limits.h>
#include "global.h"
#include "loader.h"
#include "stats.h"



#define GAUSSIAN 1       //filter types
#define MEDIAN   2
#define SOBEL2D    3
#define SOBEL3D    5
#define MAXIMALSUPRESSION 4


#define X_AXIS 1        //for rotations
#define Y_AXIS 2
#define Z_AXIS 3



struct Volume{
    float *img;
    short int X;
    short int Y;
    short int Z;
    float dx;
    float dy;
    float dz;
};

struct KeepTrack{//for fill routines such as connected object algorithms
	int PrevVoxel;
	int index;
};


struct ImagePlanes{//for maximum intensity projection
    float *plane1;
    float *plane2;
    float *plane3;
    int X;
    int Y;
    int Z;
    float max;
};

int RandomImageVoxel(float *mask, int voxels);
int TestRandomImageVoxel(struct Image *image);

double SmoothMultiVolumeResidualWeighted(struct Image *image);
double SmoothMultiVolumeDataBayes(double fy[], double fyn[], double *knowns, int rows, double *M, int neighbours);

int ComputeXYZfromVoxel(struct Image *image, int voxel, int *x, int *y, int *z);
float Intensity(struct Image *image, float I);
float ImageIntensity(struct Image *image, int x, int y, int z);
float Lagrange2D(float image[], int X, int Y, int Z, double x,double y, int zi);
float Lagrange3D(float image[], int X, int Y, int Z, double x,double y,double z);
float Lagrange3DA(float image[], int X, int Y, int Z, double x,double y,double z, float c[]);
float Lagrange3DB(unsigned char image[], int X, int Y, int Z, double x,double y,double z, float c[]);
float InterpolateImage(struct Image *image, int volume, double xf, double yf, double zf, int method);
float CubicInterpolation3D(float image[], int X, int Y, int Z, double x,double y,double z);
int Lagrange3DCoefficients(float dx, float dy, float dz, float c[]);
double GaussFilterFastEx(float image[], int X, int Y, int Z, float dx, float dy, float dz, double SD, int ThreeD);
int ImageMinMax(float *image, int X, int Y, int Z, int DataType, float *min, float *max);
float MaximumIntensity(struct Image *image);
int HistogramEqualiseImage(struct Image *image);
int Voxel(int x, int y, int z, int X, int Y, int Z);
int IsImageScalar(int DataType);
int NeighbourAverage(float *img, int X, int Y, int Z, float dx, float dy, float dz, float del, int ThreeD);
int IntensityFilter(struct Image *image, float min, float max);
int MedianImageFilter(float *image, int X, int Y, int Z, int approx);
int SobelImageFilter(float *image, int X, int Y, int Z, float dx, float dy, float dz, int Dimensions);
float MaxProjectionAlongX(float *image, int X, int Y, int Z, int xa, int xb, int y, int z);
float MaxProjectionAlongY(float *image, int X, int Y, int Z, int x, int ya, int yb, int z);
float MaxProjectionAlongZ(float *image, int X, int Y, int Z, int x, int y, int za, int zb);
int TestMaxProjections(float *image, int X, int Y, int Z);
int MaximalGradientSupression(struct Image *image);
int FilterImage(struct Image *image, int FilterType, double SD);
int Rotate90(struct Image *image, int axis);
int MakeCopyOfImage(struct Image *original, struct Image *copy);
int CreateGradImage(struct Image *image, struct Image *grad);
int InImageRange(int x,int y,int z, int X, int Y, int Z);
int DirectionFromIndexToNearestNeighbour(int index, int *x, int *y, int *z);
int IndexToNearestNeighbour(int i, int j, int k);
int IndexToNeighbour555(int i, int j, int k);
int DirectionFromIndex555(int index, int *i, int *j, int *k);

int ReSizeImage(struct Image *image, float dx, float dy, float dz);
int MirrorImage(struct Image *image);
int GetStandardizedHistogram(float *image, unsigned char mask[], int X, int Y, int Z, float scale, float offset,
                                int DataType, struct Hist *hist, float widthfraction);
int ImageCentre(struct Image *image, int *x, int *y, int *z, float *x0, float *y0, float *z0);
int XYZfromVoxelNumber(int voxel, int *x, int *y, int *z, int X, int Y, int Z);
int DilateImage2D(unsigned char bin[], int X, int Y, int Z);
int ErodeImage2D(unsigned char bin[], int X, int Y, int Z);
int DilateImage3D(unsigned char bin[], int X, int Y, int Z);
int ErodeImage3D(unsigned char bin[], int X, int Y, int Z);
int OnEdge3D(int voxel, unsigned char binimg[], int X, int Y, int Z);
int OffEdge3D(int voxel, unsigned char binimg[], int X, int Y, int Z);
int OnEdge3DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z);
int OffEdge3DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z);
int RemoveNoisyBackground(float *image, int X, int Y, int Zpv, int volumes, float min);
int AutoRemoveNoisyBackground(HWND hwnd, struct Image *image, int brain);
int ReleaseImage(struct Image *image);
int ReSampleImage(struct Image *image, float dx, float dy, float dz);
int ReleaseOverlay(struct Image *image);
int MultiVolumeSimilarityFilter(float *image, int X, int Y, int Zpv, int volumes, float dx, float dy, float dz, int iterations);
int MaxIntensityProjection(float *image, int X, int Y, int Z, struct ImagePlanes *planes);
int ConnectedObject(unsigned char bin[], int X, int Y, int Z, int x0, int y0, int z0);
int GetCentreOfImageIntensityUS(unsigned char image[], int X, int Y, int Z, double *x0, double *xSD, double *y0, double *ySD, double *z0, double *zSD);
int GetCentreOfImageIntensityF(float image[], int X, int Y, int Z, double *x0, double *xSD, double *y0, double *ySD, double *z0, double *zSD);
int ConvertToMaxIntensityProjection(struct Image *image);
double NormalizeIntensity(struct Image *A, struct Image *B);


struct ThreeVector SobelVector(float *image, int X, int Y, int Z, float dx, float dy, float dz, int x, int y, int z);
struct FourFloatVector SobelVector3D(float *image, int X, int Y, int Z, float dx, float dy, float dz, int x, int y, int z, int initialise);
int TestSobelVector3D(struct Image *image);
struct MatrixLimits FindImageMatrixLimits(struct Image *image);

int AddImages(HWND hwnd, struct Image *image);
int SeparateVolumes(struct Image *MV);
int MNI2TAL(float *x, float *y, float *z);
int Edges(struct Image *image);
int EdgesEx(struct Image *image, struct FourFloatVector *f);
int TestNeighbourVoxelDirections(void);

int SaveGreybitmap(char fname[], int width, int height, HWND hwndMain, unsigned char *pix);
int TestSaveGreybitmap(HWND hwnd);
#endif
