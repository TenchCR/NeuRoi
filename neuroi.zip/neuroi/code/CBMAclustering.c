/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "global.h"
#include "ClusterZ.h"
#include "CBMAfiles.h"
#include "graphtheoryalgorithms.h"


#define HUGE_DISTANCE 1.0e6
#define FAILED_CLUSTER -1

int AssignUnclusteredFoci(short int cluster[],
                          int Nclusters,
                          int Noverlappedfoci,
                          float Overlapping[],//[0 , Noverlappedfoci-1]
                          double dist2[],//[ {0 , Noverlappedfoci-1} x  {0 , Noverlappedfoci-1} ]
                          double mindist2,
                          int index[],
                          short int experiment[]);




int ClusterCBRESadaptive(double *distance, float *overlap, int N, int peak, float Shortest[], double CD[]);


double CoreFocusClusteringDistance(int focus,           ///candidate core focus
                                   double DM[],         ///distance matrix
                                   int Npoints,         ///number of points that makes core
                                   int Nfoci,           ///number of foci
                                   float overlap[],     ///how many experiments are overlapping focus
                                   short int experiment[],
                                   int Nexperiments,
                                   float minCD,
                                   float maxCD);

double MinPointsClusteringDistance(int focus,           ///candidate core focus
                                   double DM[],         ///distance matrix
                                   int MinPoints,       ///number of points that makes core
                                   int Nfoci,           ///number of overlapping foci
                                   short int experiment[],
                                   int Nexperiments);

int CountClustersAdaptive(double D2M[],                    ///distance squared matrix
                          short int experiment[],          ///focus belongs to this experiment
                          float overlap[],                 ///this is the overlap with other experiments
                          short int cluster[],             ///on exit this contains cluster numbers
                          int N,                           ///number of foci
                          float minCD,
                          float maxCD,                    ///the maximum clustering distance
                          int Npoints);                     ///the number of points defining a core focus






//======================================================================================================
//The clustering distance that encompasses MinPoints; including focus
//======================================================================================================
double MinPointsClusteringDistance(int focus,           ///candidate core focus
                                   double DM[],         ///distance matrix
                                   int MinPoints,       ///number of points that makes core
                                   int Nfoci,           ///number of overlapping foci
                                   short int experiment[],
                                   int Nexperiments)
{
    double CD=HUGE_DISTANCE;
    double d;
    int *sort=NULL;
    int o=focus*Nfoci;
    int experimentcount;
    int *expoverlap=NULL;
    int i;

    if (!(sort=(int *)malloc(Nfoci*sizeof(int))))
        goto END;
    if (!(expoverlap=(int *)calloc(Nexperiments+1,sizeof(int))))
        goto END;

    expoverlap[experiment[focus]]=1;///need to not include coordinates from the same experiment

    QuickSort(&DM[o],sort,Nfoci);
    experimentcount=0;
    CD=0.0;
    for (i=0; i<Nfoci && experimentcount<MinPoints; i++)
    {
        d=DM[o+sort[i]];
        if ((!expoverlap[experiment[sort[i]]]))
        {
            expoverlap[experiment[sort[i]]]=1;
            experimentcount++;
            CD=d;
        }
    }
    if (experimentcount<MinPoints)
        CD=HUGE_DISTANCE;


END:
    if (sort)
        free(sort);
    if (expoverlap)
        free(expoverlap);

    return CD;
}
//======================================================================================================
//The clustering distance for a core point
//======================================================================================================
double CoreFocusClusteringDistance(int focus,           ///candidate core focus
                                   double DM[],         ///distance matrix
                                   int Npoints,         ///number of points that makes core
                                   int Nfoci,           ///number of overlapping foci
                                   float overlap[],     ///how many experiments are overlapping focus
                                   short int experiment[],
                                   int Nexperiments,
                                   float minCD,
                                   float maxCD)
{
    double CD;

    if (overlap[focus]<Npoints)
        return HUGE_DISTANCE;

    CD=MinPointsClusteringDistance(focus, DM, Npoints, Nfoci, experiment, Nexperiments);

    if (CD>maxCD)
        CD=HUGE_DISTANCE;

    if (CD<minCD)
        CD=minCD;

    return CD;
}

//======================================================================================================
int TestCoreFocusClusteringDistance(struct Coordinates *Co, double minCD, double ClusteringDistance)
{
    double *DM=NULL;
    float *overlap=NULL;
    double *CD=NULL;
    int Nfoci=(*Co).TotalFoci;
    int focus;
    int i;
    FILE *fp=NULL;
    char fname[MAX_PATH];

    if (!(DM=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;
    Distance2Matrix((*Co).x, (*Co).y, (*Co).z, (*Co).experiment, (*Co).TotalFoci,DM);


    if (!(overlap=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
    CoordinateOverlaps(Co, DM, overlap, ClusteringDistance, 0);

    if (!(CD=(double *)malloc(Nfoci*sizeof(double))))
        goto END;

    for (i=0; i<Nfoci*Nfoci; i++)
        DM[i]=sqrt(DM[i]);

    sprintf(fname,"%s\\AdaptiveClusterDistance.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");
    for (focus=0; focus<Nfoci; focus++)
    {
        CD[focus]=CoreFocusClusteringDistance(focus, DM, 3, Nfoci,
                                              overlap, (*Co).experiment,
                                              (*Co).Nexperiments,
                                              minCD,
                                              ClusteringDistance);
        if (fp)
            fprintf(fp,"%d,%f,%f\n",focus,overlap[focus],CD[focus]);
    }


    if (fp)
        fclose(fp);


END:
    if (DM)
        free(DM);
    if (overlap)
        free(overlap);

    return 0;
}

//======================================================================================================
//count the clusters
//======================================================================================================
int CountClustersAdaptive(double D2M[],                    ///distance squared matrix
                          short int experiment[],          ///focus belongs to this experiment
                          float overlap[],                 ///this is the overlap with other experiments
                          short int cluster[],             ///on exit this contains cluster numbers
                          int N,                           ///number of foci
                          float minCD,
                          float maxCD,                    ///the maximum clustering distance
                          int Npoints)                     ///the number of points defining a core focus
{

    int Noverlapped;
    int foci, BiggestOverlap, i,j,k,o;
    int Clusters=0;
    int Count;
    int *index = NULL;
    int Nexperiments;
    short int *iexp=NULL;
    float *Overlapping = NULL;
    double *distance = NULL;
    double *CD=NULL;//the adaptive clustering distance
    float *shortest = NULL;
    float *length = NULL;


    memset(cluster,0,sizeof(short int)*N);

    if (!(index = (int *)calloc(N,sizeof(int))))
        goto END;



    //FIND ALL THE OVERLAPPING COORDINATES
    //COMPUTE A LOOKUP TABLE FOR THEM; index[]
    Noverlapped=0;
    for (foci=0; foci<N; foci++)
    {
        if ((overlap[foci]>0.0))
        {
            index[Noverlapped] = foci;
            Noverlapped++;
        }
    }



    if (!(CD = (double *)malloc(Noverlapped*sizeof(double))))
        goto END;
    if (!(distance = (double *)malloc(Noverlapped*Noverlapped*sizeof(double))))
        goto END;
    if (!(shortest = (float *)malloc(Noverlapped*sizeof(float))))
        goto END;
    if (!(Overlapping = (float *)malloc(Noverlapped*sizeof(float))))
        goto END;
    if (!(length = (float *)malloc(Noverlapped*sizeof(float))))
        goto END;
    if (!(iexp = (short int *)malloc(Noverlapped*sizeof(short int))))
        goto END;


    //COMPUTE THE DISTANCE MATRIX distance[Noverlapped*Noverlapped]
    //THIS RECORDS THE DISTANCE SQUARED BETWEEN EACH OF THE INDEXED COORDINATES
    Nexperiments=0;
    k=0;
    for (i=0; i<Noverlapped; i++)
    {
        shortest[i] = HUGE_DISTANCE;
        Overlapping[i] = overlap[index[i]];
        iexp[i] = experiment[index[i]];
        if (experiment[index[i]]>Nexperiments)
            Nexperiments=experiment[index[i]];
        o=index[i]*N;
        for (j=0; j<Noverlapped; j++)
        {
            if (experiment[index[i]]!=experiment[index[j]])
            {
                distance[k] = sqrt(D2M[o + index[j]]);
            }
            else
                distance[k]=HUGE_DISTANCE;
            k++;
        }
    }

    //compute the clustering distance for each overlapping focus
    //if the focus is not a core focus, this is not valid
    for (i=0; i<Noverlapped; i++)
    {
        CD[i] = CoreFocusClusteringDistance(i, distance, Npoints,
                                            Noverlapped, Overlapping,
                                            iexp, Nexperiments, minCD, maxCD);
    }


    do
    {
        ///choose a foci that is not already part of a cluster
        ///choose the most overlapped that overlaps by at least MIN_OVERLAP
        BiggestOverlap=Noverlapped;//start with an impossible value
        for (foci=0; foci<Noverlapped; foci++)
        {
            if ((!cluster[index[foci]]))//must not already be part of a cluster
            {
                if (BiggestOverlap == Noverlapped)
                    BiggestOverlap = foci;
                else if ((Overlapping[foci] > Overlapping[BiggestOverlap]))
                    BiggestOverlap = foci;
            }
        }


        if (BiggestOverlap<Noverlapped)
        {
            if (CD[BiggestOverlap]<=maxCD)
            {
                //we have a starting foci from which we will grow a cluster
                Clusters++;
                cluster[index[BiggestOverlap]] = Clusters;
                shortest[BiggestOverlap] = 0.0;

                if ((Count = ClusterCBRESadaptive(distance, Overlapping, Noverlapped, BiggestOverlap, length, CD))>=MIN_OVERLAP)
                {
                    ///need to know how many will join the cluster
                    ///if its not enough, dont form the cluster
                    Count=0;
                    for (foci=0; foci<Noverlapped; foci++)
                    {
                        if ((length[foci]>=0.0) && (length[foci]<shortest[foci]))
                            Count++;
                    }

                    if (Count>=MIN_OVERLAP)
                    {
                        for (foci=0; foci<Noverlapped; foci++)
                        {
                            if ((length[foci]>=0.0) && (length[foci]<shortest[foci]))
                            {
                                cluster[index[foci]] = Clusters;
                                shortest[foci] = length[foci];
                            }
                        }
                    }
                }
                ///what if this cluster failed to gather sufficient members?
                ///if this isnt tagged as failed the algorithm will continue to try
                ///and the cluster counter will keep incrementing
                if (Count<MIN_OVERLAP)
                {
                    cluster[index[BiggestOverlap]] = FAILED_CLUSTER;//dont give it a valid cluster number
                    Clusters--;//wind back the cluster counter
                }
            }
            else
                cluster[index[BiggestOverlap]] = FAILED_CLUSTER;//dont give it a valid cluster number
        }
    }
    while (BiggestOverlap<Noverlapped);


    while(AssignUnclusteredFoci(cluster, Clusters, Noverlapped,
                                Overlapping, distance,
                                maxCD, index,
                                iexp)) {}

    //must not have negative clusters
    //This might happen if there is a failed cluster
    for (foci=0; foci<N; foci++)
    {
        if (cluster[foci]<0)
            cluster[foci]=0;
    }



END:
    if (iexp)
        free(iexp);
    if (CD)
        free(CD);
    if (distance)
        free(distance);
    if (shortest)
        free(shortest);
    if (length)
        free(length);
    if (index)
        free(index);
    if (Overlapping)
        free(Overlapping);

    return Clusters;
}
//======================================================================================================
//USE SHORTEST PATH ALGORITHM TO FIND VALID FOCI CONNECTED TO A PEAK
//======================================================================================================
int ClusterCBRESadaptive(double *distance, float *overlap, int N, int peak, float Shortest[], double CD[])
{

    int i,j;
    int offset;
    int *inout;
    int *heap;
    int entered;
    float dist,newdist;
    int Count=0;


    for (i=0; i<N; i++)
        Shortest[i] = -HUGE_DISTANCE; //vary large shortest distance to start with
    if (N<=1)
        return 0;///cant cluster without multiple peaks

    inout=(int *)calloc(N,sizeof(int));
    heap=(int *)calloc(N,sizeof(int));

    if (inout && heap)
    {


        //----------------------initially there are no connections----------------------------
        entered=1;
        Count++;
        heap[entered]=peak;
        Shortest[peak]=0.0;//peaks are connected and in the Q
        inout[peak]=entered;
        //------------------------------------------------------------------------------------------


        //--------------------------Fill the Q------------------------------------------------------
        while( entered )
        {

            i=heap[1];
            entered=RemoveRootElement(Shortest, heap, entered, inout);	//take out of the Q

            offset = i*N;
            if (overlap[i]>=(float)MIN_OVERLAP)/// continue clustering only if overlap is big enough
            {
                for (j=0; j<N; j++)
                {
                    if (((dist=distance[offset + j])<=CD[i]) && (overlap[j]<=overlap[i]))
                    {

                        if (overlap[j]==overlap[peak])
                            dist=0.0;

                        //----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
                        if ((newdist=(-dist + Shortest[i]))>Shortest[j] )///filter those that can continue cluster growth
                        {
                            if (!inout[j])
                            {
                                Count++;
                                entered=NewHeapElement(Shortest, heap, entered, j, inout, newdist);		//put into the Q if not already there
                            }
                            else
                            {
                                UpdateHeap(Shortest, heap, entered, j, newdist, inout);					//if already in the Q, update connectedness
                            }
                        }
                        //-----------------------------------------------------------------------------------

                    }
                }
            }
        }
    }



    for (j=0; j<N; j++)
        Shortest[j] *= -1.0; //revert back to positive distance
    if (inout)
        free(inout);
    if (heap)
        free(heap);

    return Count;
}





//======================================================================================================
//USE SHORTEST PATH ALGORITHM TO FIND VALID FOCI CONNECTED TO A PEAK
//======================================================================================================
int ClusterCBRES(float *distance, float *overlap, int N, int peak, float Shortest[], float MinDistance)
{

    int i,j;
    int offset;
    int *inout;
    int *heap;
    int entered;
    float dist,newdist;
    int Count=0;


    for (i=0; i<N; i++)
        Shortest[i] = -HUGE_DISTANCE; //vary large shortest distance to start with
    if (N<=1)
        return 0;///cant cluster without multiple peaks

    inout=(int *)calloc(N,sizeof(int));
    heap=(int *)calloc(N,sizeof(int));

    if (inout && heap)
    {


        //----------------------initially there are no connections----------------------------
        entered=1;
        Count++;
        heap[entered]=peak;
        Shortest[peak]=0.0;//peaks are connected and in the Q
        inout[peak]=entered;
        //------------------------------------------------------------------------------------------


        //--------------------------Fill the Q------------------------------------------------------
        while( entered )
        {
            i=heap[1];
            entered=RemoveRootElement(Shortest, heap, entered, inout);	//take out of the Q

            offset = i*N;
            for (j=0; j<N; j++)
            {
                //to enter the heap overlap should be at least 3 in 3D
                if (((dist=distance[offset + j])<MinDistance) && (overlap[j]<=overlap[i]))
                {

                    if (overlap[j]==overlap[peak])
                        dist=0.0;

                    //----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
                    if ((newdist=(-dist + Shortest[i]))>Shortest[j] && overlap[j]>=(float)MIN_OVERLAP)///filter those that can continue cluster growth
                    {
                        if (!inout[j])
                        {
                            Count++;
                            entered=NewHeapElement(Shortest, heap, entered, j, inout, newdist);		//put into the Q if not already there
                        }
                        else
                        {
                            UpdateHeap(Shortest, heap, entered, j, newdist, inout);					//if already in the Q, update connectedness
                        }
                    }
                    //-----------------------------------------------------------------------------------

                }
            }
        }
    }



    for (j=0; j<N; j++)
        Shortest[j] *= -1.0; //revert back to positive distance
    if (inout)
        free(inout);
    if (heap)
        free(heap);

    return Count;
}













//======================================================================================================
//COUNT THE NUMBER OF COINCIDENT EXPERIMENTS AT EACH FOCI
//THIS SHOULD BE HIGHEST WHERE THERE ARE PEAK DENSITIES
//overlap[0..TotalFoci-1]
//EffectSignMultiplier is used to select the sign of the effect to overlap
//If EffectSignMultiplier>0 then only positive effect coordinates can overlap
//If EffectSignMultiplier<0 then only negative effect coordinates can overlap
//If EffectSignMultiplier=0 then positive and negative effect coordinates can overlap
///modified 23/01/2017 to allow sign effect size specific overlapping
//======================================================================================================
int CoordinateOverlaps(struct Coordinates *CoordinateStruct,
                       double DM2[],
                       float *overlap,
                       float ClusteringDistance,
                       int EffectSignMultiplier)
{
    int coordinate,coordinate2;
    int study;
    int TotalOverlapped=0;
    int Ncoordinates=(*CoordinateStruct).TotalFoci;
    int Nexperiments=(*CoordinateStruct).Nexperiments;
    int coordinateNcoordinates;
    int OverlappingStudies;
    float min2dist=ClusteringDistance*ClusteringDistance;
    int *StudyOverlap=NULL;

    memset(overlap,0,sizeof(float)*Ncoordinates);//A COORDINATE ON ITS OWN HAS ZERO OVERLAP
    if (!(StudyOverlap=(int *)malloc(Nexperiments*sizeof(int))))
        goto END;

    coordinateNcoordinates=0;
    for (coordinate=0; coordinate<Ncoordinates; coordinate++)
    {
        if ((*CoordinateStruct).Zsc[coordinate]*EffectSignMultiplier>=0.0)
        {

            memset(StudyOverlap, 0, sizeof(int)*Nexperiments);

            OverlappingStudies=0;
            for (coordinate2=0; coordinate2<Ncoordinates; coordinate2++)
            {
                study=(*CoordinateStruct).experiment[coordinate2];

                if ((*CoordinateStruct).Zsc[coordinate2]*EffectSignMultiplier>=0.0)
                {
                    if ( ((*CoordinateStruct).experiment[coordinate] != study) && (!StudyOverlap[study]))
                    {
                        if ( DM2[coordinate2 + coordinateNcoordinates]<=min2dist )
                        {
                            StudyOverlap[study]=1;
                            OverlappingStudies++;//the first in this study <min2dist counted
                        }
                    }
                }
            }

            ///StudyOverlapDist2 now contains the shortest distance (squared) to the nearest
            ///coordinate in another experiment
            ///This might be>min2dist
            if (OverlappingStudies>=1)
            {
                for (study=0; study<Nexperiments; study++)
                {
                    if (StudyOverlap[study])
                    {
                        overlap[coordinate] += 1.0;
                    }
                }
            }
        }
        coordinateNcoordinates += Ncoordinates;
    }

    for (coordinate=0; coordinate<Ncoordinates; coordinate++)
    {
        if (overlap[coordinate]>0.0)
            TotalOverlapped++;
    }


END:
    if (StudyOverlap)
        free(StudyOverlap);

    return TotalOverlapped;
}
//======================================================================================================
//find the closest coordinate in each study to each coordinate
//======================================================================================================
int NearestCoordinatesPerStudy(float x[], float y[], float z[], short int experiment[], int Nexperiments, int Ncoordinates, double D2[])
{
    int i;
    int coordinate1,coordinate2;
    int iexp;
    double distance2;
    double dx,dy,dz;

    for (i=0;i<Nexperiments*Ncoordinates;i++) D2[i]=DBL_MAX;

    for (coordinate1=0; coordinate1<Ncoordinates; coordinate1++)
    {
        for (coordinate2=0; coordinate2<Ncoordinates; coordinate2++)
        {
                iexp=experiment[coordinate2];

                dx=x[coordinate1] - x[coordinate2];
                dy=y[coordinate1] - y[coordinate2];
                dz=z[coordinate1] - z[coordinate2];
                distance2=dx*dx + dy*dy + dz*dz;

                if (distance2<D2[coordinate1*Nexperiments + iexp]) D2[coordinate1*Nexperiments + iexp]=distance2;

        }
    }
    return 0;
}
//======================================================================================================
//compute the coordinate overlap matrix
//float OM[Foci*Foci];
//OM[i,j]=distance2 if coordinates i,j overlap
//OM[i,j]=OM[j,i]; symmetric because if i overlaps with j then j overlaps with i
//======================================================================================================
int DistanceMatrix(float x[], float y[], float z[], short int experiment[], int Ncoordinates, double DM[])
{
    int i;
    Distance2Matrix(x, y, z, experiment, Ncoordinates, DM);
    for (i=0; i<Ncoordinates*Ncoordinates; i++)
        DM[i]=sqrt(DM[i]);
    return 1;
}
int Distance2Matrix(float x[], float y[], float z[], short int experiment[], int Ncoordinates, double DM[])
{

    int coordinate1,coordinate2;
    int rowindex1,rowindex2;
    double dx,dy,dz;
    double distance2;

    rowindex1=0;
    for (coordinate1=0; coordinate1<Ncoordinates; coordinate1++)
    {
        DM[coordinate1 + coordinate1*Ncoordinates]=0.0;//added 29/7/2020

        rowindex2=(coordinate1+1)*Ncoordinates;
        for (coordinate2=coordinate1+1; coordinate2<Ncoordinates; coordinate2++)
        {
            if ( (experiment[coordinate1] != experiment[coordinate2]) )
            {
                dx=x[coordinate1] - x[coordinate2];
                dy=y[coordinate1] - y[coordinate2];
                dz=z[coordinate1] - z[coordinate2];
                distance2=dx*dx + dy*dy + dz*dz;

                DM[coordinate1 + rowindex2]=distance2;
                DM[coordinate2 + rowindex1]=distance2;
                //DM[coordinate2 + coordinate1*Ncoordinates]=distance2;
                //DM[coordinate2*Ncoordinates + coordinate1]=distance2;
            }
            else
            {
                DM[coordinate1 + rowindex2]=HUGE_DISTANCE;//impossibly large value between coordinates in
                DM[coordinate2 + rowindex1]=HUGE_DISTANCE;//same experiment
                //DM[coordinate2 + coordinate1*Ncoordinates]=HUGE_DISTANCE;
                //DM[coordinate2*Ncoordinates + coordinate1]=HUGE_DISTANCE;
            }
            rowindex2 += Ncoordinates;
        }
        rowindex1 += Ncoordinates;
    }

    return 1;
}

//======================================================================================================
//find all the clusters
//need to first get the overlaps, then find the clusters
//======================================================================================================
int GetAllClusters(struct Coordinates *Co, double minCD, double ClusteringDistance, int MinOverlapping, int ClusterMode)
{
    int Nclusters=0, N, Np,Nm;
    int Ncoordinates=(*Co).TotalFoci;
    int coordinate;
    float *CoordOverlap=NULL;
    short int *cluster=NULL;
    double *D2M=NULL;
    float *R=NULL;

    if (!(D2M=(double *)malloc(Ncoordinates*Ncoordinates*sizeof(double))))
        goto END;
    if (!(cluster=(short int *)malloc(Ncoordinates*sizeof(short int))))
        goto END;
    if (!(CoordOverlap=(float *)malloc(Ncoordinates*sizeof(float))))
        goto END;
    if (!(R=(float *)malloc(Ncoordinates*sizeof(float))))
        goto END;
    Distance2Matrix((*Co).x, (*Co).y, (*Co).z, (*Co).experiment, (*Co).TotalFoci, D2M);

    if (ClusterMode==ID_CLUSTER_ALL)
    {
        CoordinateOverlaps(Co, D2M, CoordOverlap, ClusteringDistance, 0);

        ///FIND THE CLUSTERS GIVEN THE ClusteringDistance
        N = CountClustersAdaptive(D2M, (*Co).experiment, CoordOverlap, (*Co).cluster, Ncoordinates, minCD, ClusteringDistance, MinOverlapping);
    }
    else if (ClusterMode==ID_CLUSTER_BY_EFFECT_SIGN)
    {
        CoordinateOverlaps(Co, D2M, CoordOverlap, ClusteringDistance,1);//positive clusters

        ///FIND THE POSITIVE CLUSTERS GIVEN THE ClusteringDistance
        Np = CountClustersAdaptive(D2M, (*Co).experiment, CoordOverlap, (*Co).cluster, Ncoordinates, minCD, ClusteringDistance, MinOverlapping);

        CoordinateOverlaps(Co, D2M, CoordOverlap, ClusteringDistance,-1);//negative clusters

        ///FIND THE NEGATIVE CLUSTERS GIVEN THE ClusteringDistance
        Nm = CountClustersAdaptive(D2M, (*Co).experiment, CoordOverlap, (*Co).cluster, Ncoordinates, minCD, ClusteringDistance, MinOverlapping);

        N = Np + Nm;//sum of positive and negative clusters is the total number of clusters

        //copy the negative clusters into (*Co).cluster[]
        //change the cluster numbers to be >Np
        for (coordinate=0; coordinate<Ncoordinates; coordinate++)
        {
            if (cluster[coordinate])
                (*Co).cluster[coordinate] = Np + cluster[coordinate];
        }

    }
    else
        goto END;

    Nclusters=N;

END:
    if (CoordOverlap)
        free(CoordOverlap);
    if (cluster)
        free(cluster);
    if (R)
        free(R);
    if (D2M)
        free(D2M);

    return Nclusters;
}



//======================================================================================================
//======================================================================================================
//compute the centre of a cluster
//======================================================================================================
struct ThreeVector CentreOfCluster(struct Coordinates *Co, int cluster)
{
    struct ThreeVector V;
    int coordinate;
    int n;

    ///locate the middle of the cluster
    memset(&V,0,sizeof(struct ThreeVector));
    n=0;
    for (coordinate=0; coordinate<(*Co).TotalFoci; coordinate++)
    {
        if ((*Co).cluster[coordinate]==cluster)
        {
            V.x += (*Co).x[coordinate];
            V.y += (*Co).y[coordinate];
            V.z += (*Co).z[coordinate];
            n++;
        }
    }
    if (n)
    {
        V.x/=n;
        V.y/=n;
        V.z/=n;
    }

    return V;
}


//======================================================================================================
//generate cluster with typical characteristics
//choose minimum clustering distance that prevents it being split
//======================================================================================================
double MinClusteringDistanceNonFractureRate(int studies, double minCD, double maxCD)
{
    double sigma=3.5;//3.5mm sigma as in the Eickhoff paper
    double sigma2;
    int i,j;
    int index;
    int iter;
    int iterations=8000;
    double proportion=0.0;
    double maxCD2=maxCD*maxCD;
    double s[3];
    double mean[3]= {0.0,0.0,0.0};
    double Sigma2[9];
    float *x=NULL;
    float *y=NULL;
    float *z=NULL;
    double *D2M=NULL;
    float *overlap=NULL;
    short int *experiment=NULL;
    short int *cluster=NULL;
    int Ncl;

    if (!(x=(float *)malloc(studies*sizeof(float))))
        goto END;
    if (!(y=(float *)malloc(studies*sizeof(float))))
        goto END;
    if (!(z=(float *)malloc(studies*sizeof(float))))
        goto END;

    if (!(overlap=(float *)malloc(studies*sizeof(float))))
        goto END;
    if (!(D2M=(double *)malloc(studies*studies*sizeof(double))))
        goto END;

    if (!(cluster=(short int *)malloc(studies*sizeof(short int))))
        goto END;

    if (!(experiment=(short int *)malloc(studies*sizeof(short int))))
        goto END;

    sigma2=sigma*sigma;
    memset(Sigma2,0,sizeof(double)*9);
    Sigma2[0]=Sigma2[4]=Sigma2[8]=sigma2;

    for (iter=0; iter<iterations; iter++)
    {
        ///generate the cluster coordinates
        for (i=0; i<studies; i++)
        {
            experiment[i]=i;
            rMVnorm(s, mean, Sigma2, 3);
            x[i]=s[0];
            y[i]=s[1];
            z[i]=s[2];
        }
        Distance2Matrix(x,y,z,experiment,studies,D2M);

        ///compute the overlap
        for (i=0; i<studies; i++)
        {
            overlap[i]=0.0;
            index=i*studies;
            for (j=0; j<studies; j++)
            {
                if (i!=j)
                {
                    if (D2M[index+j]<=maxCD2)
                        overlap[i]+=1.0;
                }
            }
        }

        //RegulariseOverlap(studies, D2M, overlap, maxCD);
        //RegulariseOverlap2(x,y,z,studies,D2M,overlap);
        Ncl=CountClustersAdaptive(D2M, experiment, overlap, cluster, studies, minCD, maxCD, MIN_OVERLAP);
        if (Ncl==1)
            proportion+=1.0;
    }

    proportion/=iterations;

END:
    if (x)
        free(x);
    if (y)
        free(y);
    if (z)
        free(z);
    if (overlap)
        free(overlap);
    if (experiment)
        free(experiment);
    if (cluster)
        free(cluster);
    if (D2M)
        free(D2M);

    return proportion;
}
//======================================================================================================
//estimate the minCD
//======================================================================================================
double EstimateMinClusteringDistance(int studies, double maxCD)
{
    double proportion=0.99;
    double minCD;
    double Prop;
    double CDa,CDb;
    int getout=0;
    /*double mcd[30];
    double p[30];
    int i;
    FILE *fp=NULL;
    char fname[MAX_PATH];*/

    Prop=MinClusteringDistanceNonFractureRate(studies/2, maxCD, maxCD);
    if (Prop<proportion)
        return maxCD;

    CDa=0.0;
    CDb=maxCD;
    do
    {
        minCD=(CDa+CDb)/2;
        Prop=MinClusteringDistanceNonFractureRate(studies/2, minCD, maxCD);

        if (Prop<proportion)
            CDa=minCD;
        else
            CDb=minCD;

        //p[getout] = Prop;
        //mcd[getout] = minCD;

        getout++;
    }
    while( fabs(CDa-CDb)>0.01 && (getout<30));

    if (CDb>CDa)
        minCD=(CDa+CDb)/2;



//char txt[256];
//sprintf(txt,"%f %f",minCD,maxCD);
//MessageBox(NULL,txt,"",MB_OK);

    return minCD;
}


//======================================================================================================
//assign foci that didnt get assigned in the clustering algorithm
//Foci eligible for assignment are not already part of clusters
//They must also overlap with a focus that itself has an overlap >=MIN_OVERLAP
//assign the candidates to the nearest focus that overlaps>=MIN_OVERLAP
///THIS IS NECESSARY
//======================================================================================================
int AssignUnclusteredFoci(short int cluster[],
                          int Nclusters,
                          int Noverlappedfoci,
                          float Overlapping[],//[0 , Noverlappedfoci-1]
                          double dist2[],//[ {0 , Noverlappedfoci-1} x  {0 , Noverlappedfoci-1} ]
                          double mindist2,
                          int index[],
                          short int experiment[])
{
    int Assignments=0;
    int Ncandidates=0;
    char *candidates=NULL;
    int focus,focus2,focusNoverlappedfoci;
    int *bestcluster=NULL;
    double d2,smallestdistance2;


    if (!(candidates=(char *)calloc(Noverlappedfoci,sizeof(char))))
        goto END;
    if (!(bestcluster=(int *)calloc(Noverlappedfoci,sizeof(int))))
        goto END;

    //get the eligible foci
    for (focus=0; focus<Noverlappedfoci; focus++)
    {
        if ( cluster[index[focus]]<=0 )
        {
            focusNoverlappedfoci=focus*Noverlappedfoci;
            for (focus2=0; (focus2<Noverlappedfoci) && (!candidates[focus]) ; focus2++)
            {
                if ( cluster[index[focus2]]>0 &&
                        (dist2[focusNoverlappedfoci + focus2]<=mindist2) &&
                        (experiment[focus]!=experiment[focus2]) &&
                        (Overlapping[focus]>=(float)MIN_OVERLAP))
                {
                    candidates[focus]=1;
                    Ncandidates++;
                }
            }
        }
    }
    if (!Ncandidates)
        goto END;

    for (focus=0; focus<Noverlappedfoci; focus++)
    {
        if ( candidates[focus] )
        {
            smallestdistance2=FLT_MAX;
            focusNoverlappedfoci=focus*Noverlappedfoci;
            for (focus2=0; focus2<Noverlappedfoci ; focus2++)
            {
                if ( cluster[index[focus2]]>0 &&
                        (d2=dist2[focusNoverlappedfoci + focus2]<=mindist2) &&
                        (experiment[focus]!=experiment[focus2])  &&
                        (Overlapping[focus2]>=(float)MIN_OVERLAP))
                {
                    if (d2<smallestdistance2)
                    {
                        smallestdistance2=d2;
                        bestcluster[focus]=cluster[index[focus2]];
                    }
                }
            }
        }
    }
    for (focus=0; focus<Noverlappedfoci; focus++)
    {
        if ( candidates[focus] )
        {
            if (bestcluster[focus]>0)
            {
                Assignments++;
                cluster[index[focus]]=bestcluster[focus];
            }
        }
    }


END:
    if (bestcluster)
        free(bestcluster);
    if (candidates)
        free(candidates);
    return Assignments;
}




//======================================================================================================
int RandomiseCoordinatesForTesting(float mask[],
                                   int X, int Y, int Z,
                                   float dx, float dy, float dz,
                                   float x0, float y0, float z0,
                                   struct Coordinates *Co,
                                   double ClusteringDistance)
{

   struct Clusters cl;

    memset(&cl,0,sizeof(struct Clusters));


    FillClusterStructure(Co, &cl, SDfromClusteringDistance(ClusteringDistance));
    RandomiseFociRandomEffects(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, Co, &cl,
                               SDfromClusteringDistance(ClusteringDistance));

    FreeCluster(&cl);

    /*
    int experiment;
    for (experiment=0;experiment<(*Co).Nexperiments;experiment++)
    {
    RandomiseFociInexperiment(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, Co, experiment);
    }*/


    return 1;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================



//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================

