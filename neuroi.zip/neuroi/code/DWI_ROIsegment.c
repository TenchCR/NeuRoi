/*
Copyright 2009 - 2020 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "DWI_ROIsegment.h"
#include "ROIs.h"
#include "menuresources.h"
#include "numerical.h"

double GetErrorPartitionRoiDWI(struct Image *DWI, int VoxelCentres[], int clusters, int lookup[], int membership[], int Size);
int FindClossestVoxel(struct Image *DWI, float V[], int lookup[], int Size);




//=============================================================================================
//
//=============================================================================================
INT_PTR CALLBACK ClusterROIusingDWI(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    char txt[256];
    int clusters;

    switch(msg) {


	case WM_CLOSE:
        hDWIcluster=(HWND)NULL;
		EndDialog(hwnd,0);
	break;



    case WM_SHOWWINDOW:
        sprintf(txt,"%d",0);
        SendMessage(GetDlgItem(hwnd,ID_CLUSTERS), WM_SETTEXT, 0, (LPARAM)txt);
    break;



    case WM_INITDIALOG:

    break;





    case WM_COMMAND:
	  switch (LOWORD(wParam)) {




		case IDOK:
            SendMessage(GetDlgItem(hwnd,ID_CLUSTERS), WM_GETTEXT, 256, (LPARAM)txt);
            clusters = atoi(txt);
            if (clusters < 255) ClassifyDWIwithinROIfast(&gImage, clusters);
    		SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}








//=======================================================================================
//Given the DWI and ROIs, partition the ROIs into clusters using the within cluster
//similarity
//Save the results to a file
//TOO SLOW, BUT EXAUSTIVE SEARCH. USE AS A TEST OF A FAST VERSION
//=======================================================================================
int ClassifyDWIwithinROI(struct Image *DWI, int clusters)
{
    struct Image Class;
    unsigned char *Region = NULL;
    int X, Y, Zpv;
    int voxel, voxels;
    int result = 0;
    int Size;
    int *lookup = NULL;
    int *VoxelCentres = NULL;
    int *membership = NULL;
    int *Best = NULL;
    int *index = NULL;
    int i;
    double error, minerror;



    memset(&Class,0,sizeof(struct Image));

    if (!gNumberOfROIs) goto END;

    X = (*DWI).X;
    Y = (*DWI).Y;
    Zpv = (*DWI).Z/(*DWI).volumes;
    voxels = X*Y*Zpv;

    if (clusters > 255)
    {
        MessageBox(NULL,"Too many clusters: ClassifyDWIwithinROI","",MB_OK);
        goto END;
    }

    if (!(Region = (unsigned char *)malloc(X*Y*Zpv))) goto END;

    if ((Size = GetBinaryROImask(Region, X, Y, Zpv, 0, 0))<clusters) goto END;

    if (!(lookup = (int *)malloc(Size*sizeof(int)))) goto END;

    if (!(membership = (int *)malloc(Size*sizeof(int)))) goto END;

    if (!(VoxelCentres = (int *)malloc(clusters*sizeof(int)))) goto END;

    if (!(Best = (int *)malloc(clusters*sizeof(int)))) goto END;

    if (!(index = (int *)malloc(clusters*sizeof(int)))) goto END;


//get the lookup table of voxel numbers
    i = 0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (Region[voxel])
        {
            lookup[i] = voxel;
            i++;
        }
    }

//initialize the index to clusters-1, cluster-2, clusters-3,....,0
    for (i=0; i<clusters; i++) index[i] = clusters-i-1;

//the minerror is given by the first centre voxels
    for (i=0; i<clusters; i++) VoxelCentres[i] = lookup[index[i]];
    memcpy(Best, VoxelCentres, sizeof(int)*clusters);
    minerror = GetErrorPartitionRoiDWI(DWI, VoxelCentres, clusters, lookup, membership, Size);


    do
    {
        for (i=0; i<clusters; i++) VoxelCentres[i] = lookup[index[i]];
        error = GetErrorPartitionRoiDWI(DWI, VoxelCentres, clusters, lookup, membership, Size);
        if (error < minerror)
        {
            memcpy(Best, VoxelCentres, sizeof(int)*clusters);
            minerror = error;
        }
    }
    while (NextPermutation(index, clusters, Size-1));

    GetErrorPartitionRoiDWI(DWI, Best, clusters, lookup, membership, Size);

//make the Class image for saving
    if (!MakeImage(&Class, X, Y, Zpv, 1, (*DWI).dx, (*DWI).dy, (*DWI).dz,
                   (*DWI).x0, (*DWI).y0, (*DWI).z0, 1.0, 0.0, DT_SIGNED_SHORT,
                   NIFTI, "ROI clustering using DWI")) goto END;


    for (i=0; i<Size; i++) Class.img[lookup[i]] = membership[i];
    SaveAs(&Class);


    result = 1;
END:
    if (Region) free(Region);
    if (lookup) free(lookup);
    if (VoxelCentres) free(VoxelCentres);
    if (Best) free(Best);
    if (index) free(index);
    if (membership) free(membership);

    ReleaseImage(&Class);

    return result;
}

//=======================================================================================
//Given the DWI and ROIs, partition the ROIs into clusters using the within cluster
//similarity
//Save the results to a file
//=======================================================================================
int ClassifyDWIwithinROIfast(struct Image *DWI, int clusters)
{
    struct Image Class;
    unsigned char *Region = NULL;
    int X, Y, Zpv;
    int voxel, voxels;
    int vol;
    int result = 0;
    int Size;
    int *lookup = NULL;
    int *VoxelCentres = NULL;
    int *membership = NULL;
    int *Best = NULL;
    int i,n;
    int iter;
    int cluster;
    double error, minerror;
    float *V = NULL;

    memset(&Class,0,sizeof(struct Image));

    if (!gNumberOfROIs) goto END;

    X = (*DWI).X;
    Y = (*DWI).Y;
    Zpv = (*DWI).Z/(*DWI).volumes;
    voxels = X*Y*Zpv;

    if (clusters > 255)
    {
        MessageBox(NULL,"Too many clusters: ClassifyDWIwithinROI","",MB_OK);
        goto END;
    }

    if (!(Region = (unsigned char *)malloc(X*Y*Zpv))) goto END;

    if ((Size = GetBinaryROImask(Region, X, Y, Zpv, 0, 0))<clusters) goto END;

    if (!(lookup = (int *)malloc(Size*sizeof(int)))) goto END;

    if (!(membership = (int *)malloc(Size*sizeof(int)))) goto END;

    if (!(VoxelCentres = (int *)malloc(clusters*sizeof(int)))) goto END;

    if (!(Best = (int *)malloc(clusters*sizeof(int)))) goto END;

    if (!(V = (float *)malloc(sizeof(float)*(*DWI).volumes))) goto END;


//get the lookup table of voxel numbers
    i = 0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (Region[voxel])
        {
            lookup[i] = voxel;
            i++;
        }
    }



//initialize with a random selection of voxels from the ROIs
//try many and sellect the best
    minerror=100000000.0;
    for (iter=0; iter<2000; iter++)
    {

        memset(membership,0,Size*sizeof(int));
        for (cluster=0; cluster<clusters; cluster++)
        {
            do
            {
                i = Size*((double)rand()/RAND_MAX);
                if (i >= Size) i = Size-1;
            }
            while (membership[i]);
            membership[i] = 1;
            VoxelCentres[cluster] = lookup[i];
        }

        error = GetErrorPartitionRoiDWI(DWI, VoxelCentres, clusters, lookup, membership, Size);
        if (error<minerror)
        {
            memcpy(Best, VoxelCentres, sizeof(int)*clusters);
            minerror = error;
        }
    }
    GetErrorPartitionRoiDWI(DWI, Best, clusters, lookup, membership, Size);


    for (iter=0; iter<2000; iter++)
    {
        //get the VoxelCentres from the membership
        for (cluster=0; cluster<clusters; cluster++)
        {
            memset(V,0,sizeof(float)*(*DWI).volumes);
            n = 0;
            for (i=0; i<Size; i++)
            {
                if (membership[i] == (cluster+1))
                {
                    for (vol=0; vol<(*DWI).volumes; vol++) V[vol] += (*DWI).img[lookup[i] + vol*voxels];
                    n++;
                }
            }
            if (n)
            {
                for (vol=0; vol<(*DWI).volumes; vol++) V[vol] /= n;
                VoxelCentres[cluster] = FindClossestVoxel(DWI, V, lookup, Size);
                if (VoxelCentres[cluster] < 0) VoxelCentres[cluster] = lookup[i];
            }
        }


        error = GetErrorPartitionRoiDWI(DWI, VoxelCentres, clusters, lookup, membership, Size);
        if (error < minerror)
        {
            memcpy(Best, VoxelCentres, sizeof(int)*clusters);
            minerror = error;
        }
    }

    GetErrorPartitionRoiDWI(DWI, Best, clusters, lookup, membership, Size);

//make the Class image for saving
    if (!MakeImage(&Class, X, Y, Zpv, 1, (*DWI).dx, (*DWI).dy, (*DWI).dz,
                   (*DWI).x0, (*DWI).y0, (*DWI).z0, 1.0, 0.0, DT_SIGNED_SHORT,
                   NIFTI, "ROI clustering using DWI")) goto END;


    for (i=0; i<Size; i++) Class.img[lookup[i]] = membership[i];
    SaveAs(&Class);


    result = 1;
END:
    if (Region) free(Region);
    if (lookup) free(lookup);
    if (VoxelCentres) free(VoxelCentres);
    if (Best) free(Best);
    if (membership) free(membership);
    if (V) free(V);

    ReleaseImage(&Class);

    return result;
}



//=======================================================================================
//lookup[Size]: list of voxels in the ROI
//V[(*DWI).volumes]: vector representing the centre os a cluster
//=======================================================================================
int FindClossestVoxel(struct Image *DWI, float V[], int lookup[], int Size)
{
    int vol, volumes;
    int index;
    int voxel = -1;
    int voxelspv = (*DWI).X*(*DWI).Y*(*DWI).Z/(*DWI).volumes;
    float Error, MinError;

    volumes = (*DWI).volumes;

    MinError=0.0;
    for (vol=0; vol<volumes; vol++) MinError += pow(V[vol],2);

    for (index=0; index<Size; index++)
    {
        Error=0.0;
        for (vol=0; vol<volumes; vol++)
        {
            Error += pow(V[vol] - (*DWI).img[lookup[index] + vol*voxelspv], 2);
        }
        if (Error < MinError)
        {
            voxel = lookup[index];
            MinError = Error;
        }

    }

    return voxel;
}


//=======================================================================================
// *DWI: the diffusion weighted image
// VoxelCentres[clusters]: the voxels around which the clusters should be built
// lookup[Size]: the voxels within the ROI to be clustered
// membership[Size]: records the cluster each voxel in the ROI belongs to on exit
// Size: the number of voxels to cluster
//=======================================================================================
double GetErrorPartitionRoiDWI(struct Image *DWI, int VoxelCentres[], int clusters, int lookup[], int membership[], int Size)
{
    float *diff2 = NULL;
    float diff;
    int voxel, index;
    int X, Y, Zpv;
    int volumes, voxelspv;
    int vol;
    int centre;

    X = (*DWI).X;
    Y = (*DWI).Y;
    Zpv = (*DWI).Z/(*DWI).volumes;
    volumes = (*DWI).volumes;
    voxelspv=X*Y*Zpv;

    if (!(diff2 = (float *)malloc(Size*sizeof(float)))) return 100000000.0;



    for (index=0; index<Size; index++)
    {
        voxel=lookup[index];

        //set diff2[index] to the biggest value it should be
        diff2[index] = 0.0;
        for (vol=0; vol<volumes; vol++) diff2[index] += pow((*DWI).img[voxel + vol*voxelspv], 2);

        membership[index] = 0;
        for (centre=0; centre<clusters; centre++)
        {
            diff = 0.0;
            for (vol=0; vol<volumes; vol++)
            {
                diff += pow((*DWI).img[voxel + vol*voxelspv] - (*DWI).img[VoxelCentres[centre] + vol*voxelspv], 2);
            }
            if (diff < diff2[index])
            {
                diff2[index] = diff;
                membership[index] = centre + 1;//first cluster is 1
            }
        }
    }

    diff = 0.0;
    for (index=0; index<Size; index++) diff += diff2[index];

    if (diff2) free(diff2);

    return diff;
}
