/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "FFT.h"
#include "numerical.h"

int Power2Value(int x);
int SortArrayForFFT(short int  sort[], int N);

int CopyToComplex2D(struct Complex *Cimg, int X1, int Y1, int Z1,
                    float *img, int X, int Y, int Z, int centralise);





//=====================================================================================================
//c is an array (length N) of complex numbers
//These numbers will be reorganised so that an FFT can be performed
//N should be a power of 2, otherwise the FFT algorithm wont work
// the sort works such that 	1	2	3	4	5	6	7	8			8 points in order
//becomes						1	3	5	7	2	4	6	8			2*4	points of 4 odd and 4 even
//becomes						1	5	3	7	2	6	4	8			4*2 points dividing the previous 2*4 points into odd and even
//=====================================================================================================
int SortArrayForFFT(short int  sort[], int N){

	int divisions;
	int i,j,k,l,m;
	int offset,width;
	short int *tmp=NULL;

	if (!(tmp=(short int *)malloc(N*sizeof(short int)))) return 0;

    for (i=0;i<N;i++) sort[i]=i;

	i=0;
	do{
		memcpy(tmp, sort, sizeof(short int)*N);
		divisions=1<<i;                             //how many divisions of the data will there be
		width=N/divisions/2;						//Each division is 2*width (1 even width and 1 odd width)
		for (j=0;j<divisions;j++){
			offset=j*width*2;						//offset to current division
			for (k=0;k<width;k+=1){
				l=k+offset;
				m=2*k;
				sort[l]=tmp[m+offset];				//even part
				sort[l+width]=tmp[m+1+offset];		//odd part
			}
		}
		i++;
	}
	while (width>2);								//until its divided down to one number width

    if (tmp) free(tmp);

	return 1;
}


//=====================================================================================================
//Performs Fast Fourier Transfor on 1D D[N]
//double i determines if the routine performes FT(i=1.0) or inverse FT(i=-1.0)
//=====================================================================================================
int FFT(struct Complex D[], int N, double i){

	struct Complex tmp, W, Wdel;
	int j;
	int offset,division,length;
    int HalfLength;
    int NdivLength;

	//perform transform
	length=1;
	do{
	    HalfLength=length;
		length*=2;
		NdivLength=N/length;
		Wdel	=	ComplexExp(2.0*PI*i/length);
		for (division=0;division<NdivLength;division++){
			offset	=	division*length;
			W.r=1.0;W.i=0.0;
			for (j=0;j<HalfLength;j++){
				//W=ComplexExp(i*2.0*pi*j/length); SLOW way

				tmp.r=W.r*D[offset+HalfLength+j].r - W.i*D[offset+HalfLength+j].i;
				tmp.i=W.r*D[offset+HalfLength+j].i + W.i*D[offset+HalfLength+j].r;

				D[offset+HalfLength+j].r	=	D[offset+j].r	-	tmp.r;
				D[offset+HalfLength+j].i	=	D[offset+j].i	-	tmp.i;

				D[offset+j].r	+=	tmp.r;
				D[offset+j].i	+=	tmp.i;

				//fast way to compute W=cexp(i*2.0*pi*j/length); No sin or cos
				tmp.r	=	W.r*Wdel.r	-	W.i*Wdel.i;
				tmp.i	=	W.r*Wdel.i	+	W.i*Wdel.r;
				W=tmp;
			}
		}
	}
	while(length<N);

	return 1;

}

//=====================================================================================================
//          Get the smallest value 2^N that is >= x
//          return -1 if the number is just too big or <=0
//=====================================================================================================
int Power2Value(int x){
    int i;
    int z;

    if (x<=0) return -1;

    i=1;
    do{
        if ((z=1<<i)>=x) return z;
        i++;
    }
    while(i<32);
    return -1;
}





//=====================================================================================================
//           Copy Real image into Complex array
//           centralise will cause the transform to be centralised, so that the low frequencies
//              are in the middle (X1/2, Y1/2}
//=====================================================================================================
int CopyToComplex2D(struct Complex *Cimg, int X1, int Y1, int Z1,
                    float *img, int X, int Y, int Z, int centralise){

    int x,y,z;
    int X1Y1=X1*Y1;
    int XY=X*Y;

    memset(Cimg,0,sizeof(struct Complex)*X1*Y1*Z1);

    //copy the image data across
    for (z=0;z<Z;z++){
        for (y=0;y<Y;y++){
            for (x=0;x<X;x++){
                Cimg[x+y*X1+z*X1Y1].r=img[x+y*X+z*XY];
                if (centralise) Cimg[x+y*X1+z*X1Y1].r*=pow(-1,x+y);
            }
        }
    }

    return 1;
}


//=====================================================================================================
//          Test a 2D FFT of an image
//=====================================================================================================
int Test2Dfft(struct Image *image){

    int x,y,z;
    int X, Y, Z;
    int X1,Y1, big; //these are bigger than X,Y,Z and are a power of 2
    struct Complex *Cimg=NULL;
    struct Complex *Xt=NULL, *Yt=NULL;
    struct Complex *temp=NULL;
    short int *sort=NULL;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;

    X1=Power2Value(X);
    big=X1;
    Y1=Power2Value(Y);
    if(Y1>big) big=Y1;



    if (!(Cimg=(struct Complex *)calloc(X1*Y1*Z,sizeof(struct Complex)))) goto END;
    //these will be where the Y and Z dimension transforms are temporarily held
    if (!(Xt=(struct Complex *)calloc(X1,sizeof(struct Complex)))) goto END;
    if (!(Yt=(struct Complex *)calloc(Y1,sizeof(struct Complex)))) goto END;
    if (!(temp=(struct Complex *)calloc(big,sizeof(struct Complex)))) goto END;
    if (!(sort=(short int *)malloc(big*sizeof(short int)))) goto END;

    CopyToComplex2D(Cimg, X1, Y1, Z, (*image).img, X, Y, Z, 1);


    //do the x transformation
    SortArrayForFFT(sort, X1);
    for (z=0;z<Z;z++){
        for (y=0;y<Y1;y++){
            //memset(Xt,0,X1*sizeof(struct Complex));
            for (x=0;x<X1;x++){
                Xt[x]=Cimg[sort[x]+y*X1+z*X1*Y1];
            }

            FFT(Xt, X1, 1.0);

            for (x=0;x<X1;x++){
                Cimg[x+y*X1+z*X1*Y1]=Xt[x];
            }
        }
    }

    //do the y transformation
    SortArrayForFFT(sort, Y1);
    for (z=0;z<Z;z++){
        for (x=0;x<X1;x++){
            //memset(Yt,0,Y1*sizeof(struct Complex));
            for (y=0;y<Y1;y++){
                Yt[y]=Cimg[x+sort[y]*X1+z*X1*Y1];
            }

            FFT(Yt, Y1, 1.0);

            for (y=0;y<Y1;y++){
                Cimg[x+y*X1+z*X1*Y1]=Yt[y];
            }
        }
    }


/*
//HI PASS FILTER THE IMAGE
    for (z=0;z<Z;z++){
		for (y1=0;y1<Y1;y1++){
			for (x1=0;x1<X1;x1++){
                if ( (delx=abs(x1-X1/2)) || (dely=abs(y1-Y1/2))){
                    if ((delx*delx + dely*dely)<10) f=0.0;
                    else f=1.0;
    				Cimg[x1+y1*X1+z*X1*Y1].r*=f;
	       			Cimg[x1+y1*X1+z*X1*Y1].i*=f;
                }
			}
		}
	}
*/



    //do the x transformation
    SortArrayForFFT(sort, X1);
    for (z=0;z<Z;z++){
        for (y=0;y<Y1;y++){
            //memset(Xt,0,X1*sizeof(struct Complex));
            for (x=0;x<X1;x++){
                Xt[x]=Cimg[sort[x]+y*X1+z*X1*Y1];
            }

            FFT(Xt, X1, -1.0);

            for (x=0;x<X1;x++){
                Cimg[x+y*X1+z*X1*Y1]=Xt[x];
            }
        }
    }

    //do the y transformation
    SortArrayForFFT(sort, Y1);
    for (z=0;z<Z;z++){
        for (x=0;x<X1;x++){
            //memset(Yt,0,Y1*sizeof(struct Complex));
            for (y=0;y<Y1;y++){
                Yt[y]=Cimg[x+sort[y]*X1+z*X1*Y1];
            }

            FFT(Yt, Y1, -1.0);

            for (y=0;y<Y1;y++){
                Cimg[x+y*X1+z*X1*Y1]=Yt[y];
            }
        }
    }






    (*image).MaxIntensity=0.0;
    for (z=0;z<Z;z++){
        for (y=0;y<Y;y++){
            for (x=0;x<X;x++){
                if (fabs((*image).img[x+y*X+z*X*Y])>0.0){
                    (*image).img[x+y*X+z*X*Y]=ComplexMag(Cimg[x+y*X1+z*X1*Y1])/X1/Y1;
                    if ((*image).img[x+y*X+z*X*Y]>(*image).MaxIntensity) (*image).MaxIntensity=(*image).img[x+y*X+z*X*Y];
                }
            }
        }
    }




END:
    if (Cimg) free(Cimg);
    if (Xt) free(Xt);
    if (Yt) free(Yt);
    if (temp) free(temp);
    if (sort) free(sort);

    return 1;
}
