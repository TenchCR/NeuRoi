/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
The probability of a coordinate falling at some position depends on if it lands in a cluster or in the background.

The FWHM is the parameter, which indicates the 'volume' of a coordinate; the uncertainty in its location

Cluster probability is estimated using the ALE.

Background probability is the coordinate 'volume' (FWHM) / GM volume

Add log probabilities

This can be used to determine both the threshold ALE and the FWHM that best predicts held out studies in a leave one out analysis.
*/

#include "CoordinateProcess.h"
#include "loader.h"
#include "CoordinateProcess.h"
#include "CBMAfiles.h"
#include "graphtheoryalgorithms.h"
#include "global.h"

#define SPHERICAL 1
#define GAUSS 2
#define BETA 3
#define KERNEL_USED BETA


#define MIN_FACTOR 0.0

double MaximumLLgivenSD(char fname[], struct Coordinates *C, struct Image *ale, float *StudyEffect, double sd, double Volume, double *minALE);
double LogLikelihood(struct Coordinates *C, struct Image *ale, float *StudyEffect, int Nstudies, double *min, double sd, double Volume, char fname[], int outlier);
double ComputeLooALE(struct Image *ALE, float *StudyEffect, double min, int Studies, int LeaveOut);
int StudyEffect(int xs, int ys, int zs, float Effect[], int X, int Y, int Z, float dx, float dy, float dz, float sd, float thresh, int iterations);
int ComputeStudyEffectUsingGraphTheory(struct Coordinates *C, int study, float *kernel, float *Effect, float dx, float dy, float dz, int X, int Y, int Z, double Minimum, float sd);
double MeanALEinCluster(struct Image *ale, double MinALE, double *ClusterVolume);
//=================================================================================================================================
double KernelMaxLL(float x0, float y0, float z0, float x, float y, float z, double t, int KernelType)
{
	double d2=(x0-x)*(x0-x) + (y0-y)*(y0-y) + (z0-z)*(z0-z);
	double m,d;

	switch(KernelType)
	{
	case SPHERICAL:
		if (d2<t*t)
			return 1.0;
		else
			return 0.0;
		break;

	case GAUSS:
		return exp(-d2/2/t/t);
		break;

	case BETA:
		m=16.0;
		d=sqrt(d2)/t+0.5;
		if (d>1.0)
			return 0.0;
		return pow(d,2)*pow(1.0-d,2)*m;
		break;

	}

	return 0.0;//default
}
//=================================================================================================================================
int ComputeStudyEffectUsingGraphTheory(struct Coordinates *C, int study, float *kernel, float *Effect, float dx, float dy, float dz, int X, int Y, int Z, double Minimum, float sd)
{

	int focus;
	int Nfoci=(*C).TotalFoci;
	int voxel;
	int voxels=X*Y*Z;
	int xs, ys, zs;

	memset(Effect, 0, sizeof(float)*voxels);

	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).experiment[focus]==study)
		{
			memset(kernel,0,voxels*sizeof(float));

			XYZfromVoxelNumber((*C).voxel[focus], &xs, &ys, &zs, X, Y, Z);
			StudyEffect(xs, ys, zs, kernel, X, Y, Z, dx, dy, dz, sd, Minimum, voxels);

			for (voxel=0; voxel<voxels; voxel++)
			{
				if (kernel[voxel]>Effect[voxel])
					Effect[voxel]=kernel[voxel];
			}
		}
	}


	return 0;
}
//=================================================================================================================================
int StudyEffect(int xs, int ys, int zs, float kernel[], int X, int Y, int Z, float dx, float dy, float dz, float sd, float thresh, int iterations)
{

	int x,y,z, voxel, voxeln, voxels=X*Y*Z;
	int XY=X*Y;
	int l;
	int seed;
	int *inout;
	int *heap;
	int entered;
	int xn[6]= {-1, 1, 0, 0, 0, 0};
	int yn[6]= {0, 0, 1, -1, 0, 0};
	int zn[6]= {0, 0, 0, 0, -1, 1};
	float eff;
	int iter=0, count;
	//double norm=sd*sd*sd;
	double norm=1.0;


	inout=(int *)malloc(voxels*sizeof(int));
	heap=(int *)malloc(voxels*sizeof(int));

	seed=xs + ys*X + zs*X*Y;

	if (inout && heap)
	{
		memset(inout,0,voxels*sizeof(int));
		memset(heap,0,voxels*sizeof(int));

		//----------------------initially there are no connections----------------------------
		entered=1;
		heap[entered]=seed;
		kernel[seed]=KernelMaxLL(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, sd, KERNEL_USED)/norm;
		inout[seed]=entered;
		//------------------------------------------------------------------------------------------


		//--------------------------Fill the Q------------------------------------------------------
		iter=count=0;
		while( (kernel[heap[1]]>thresh) && (iter<iterations) && entered )
		{

			voxel=heap[1];																						//the current voxel, taken from the Q
			entered=RemoveRootElement(kernel, heap, entered, inout);	//take out of the Q


			for (l=0; l<6; l++)
			{

				XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);
				if (InImageRange(x+xn[l],y+yn[l],z+zn[l],X,Y,Z))
				{

					voxeln=voxel + xn[l] + yn[l]*X + zn[l]*XY;

					if (kernel[voxeln]<kernel[voxel]) //cant update a high kernel from a low kernel
					{

						eff=KernelMaxLL(dx*xs, dy*ys, dz*zs, dx*(x+xn[l]), dy*(y+yn[l]), dz*(z+zn[l]), sd, KERNEL_USED)/norm;

						//----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
						if ((eff>kernel[voxeln]) && (eff>thresh))
						{
							count++;

							if (!inout[voxeln])
							{
								entered=NewHeapElement(kernel, heap, entered, voxeln, inout, eff);		//put into the Q if not already there
								iter++;
							}
							else
							{
								UpdateHeap(kernel, heap, entered, voxeln, eff, inout);					//if already in the Q, update connectedness
							}
						}
						//-----------------------------------------------------------------------------------

					}//kernel in neighbour < kernel in current voxel

				}//in image range

			}//l {0<=l<6}

		}
		//-------------------------------------------------------------------------------------------


	}

	if (inout)
		free(inout);
	if (heap)
		free(heap);

	return iter;
}


//=================================================================================================================================
//computes the ALE using all studies except 1 (LeaveOut)
double ComputeLooALE(struct Image *ALE, float *StudyEffect, double min, int Studies, int LeaveOut)
{
	int voxels=(*ALE).X*(*ALE).Y*(*ALE).Z;
	int voxel;
	int study;
	int offset;
	double max=0.0;


	memset((*ALE).img, 0, voxels*sizeof(float));
	for (study=0; study<Studies; study++)
	{
		if (study != LeaveOut)
		{
			offset=study*voxels;
			for (voxel=0; voxel<voxels; voxel++)
			{
				(*ALE).img[voxel] +=  StudyEffect[offset+voxel];
			}
		}
	}


	for (voxel=0; voxel<voxels; voxel++)
	{
		(*ALE).img[voxel]  /=  (Studies-1);

		if ((*ALE).img[voxel]<=min)
			(*ALE).img[voxel] = 0.0;

		if ((*ALE).img[voxel]>max)
			max=(*ALE).img[voxel];
	}


	return max;
}

//=========================================================================================================
double MeanALEinCluster(struct Image *ale, double MinALE, double *ClusterVolume)
{
	double dV=(*ale).dx * (*ale).dy * (*ale).dz;
	double MeanALE=0.0;
	int n=0;
	int voxel;
	int voxels=(*ale).X * (*ale).Y * (*ale).Z;

	*ClusterVolume=0.0;
	for (voxel=0; voxel<voxels; voxel++)
	{
		if ((*ale).img[voxel]>MinALE)
		{
			*ClusterVolume += dV;
			MeanALE += (*ale).img[voxel];
			n++;
		}
	}

	if (n)
		return MeanALE / n;
	else
		return 0.0;
}

//=========================================================================================================
//=========================================================================================================
double LogLikelihood(struct Coordinates *C, struct Image *ale, float *StudyEffect, int Nstudies, double *min, double sd, double Volume, char fname[], int outlier)
{
	double dV=(*ale).dx * (*ale).dy * (*ale).dz;
	int study;
	int voxel;
	int voxels=(*ale).X*(*ale).Y*(*ale).Z;
	int focus, Nfoci=(*C).TotalFoci;
	double LL=0.0;
	double MeanALE;
	double ClusterVolume;
	double norm;
	double fMin;
	double tmp,sum;
	double logdv_volume=log(dV/Volume);
	//double nullLL=Nfoci*logdv_volume;
	FILE *fp;
	fp=fopen(fname,"a");


	for (study=0; study<Nstudies; study++)
	{
		ComputeStudyEffectUsingGraphTheory(C, study, (*ale).img, &StudyEffect[study*voxels], (*ale).dx, (*ale).dy, (*ale).dz, (*ale).X, (*ale).Y, (*ale).Z, 0.0, sd);
	}
	ComputeLooALE(ale, StudyEffect, 0.0, Nstudies, -1);//compute the activation distribution using all studies
	fMin=0.0;
	//get the min


		for (study=0; study<Nstudies; study++)
		{
			ComputeLooALE(ale, StudyEffect, fMin, Nstudies, study);
			MeanALE = MeanALEinCluster(ale, fMin, &ClusterVolume);
			sum=0.0;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==study)
				{
					if (ClusterVolume>=Volume)
					{
						tmp=logdv_volume;
					}
					else
					{
						norm=(fMin*(Volume-ClusterVolume) + MeanALE*ClusterVolume)/dV;
						voxel=(*C).voxel[focus];
						if ((*ale).img[voxel]>0.0)
						{
							tmp= log(((*ale).img[voxel])/norm);
						}
						else
							tmp=log(fMin/norm);
					}
					sum+=tmp;
				}
			}
			LL+=sum;
			if (fp && outlier)
            {
                fprintf(fp,"%d,%s,%f\n",study, (*C).ID[study].txt,tmp);
            }
		}


	if (fp && !outlier)
	{
		fprintf(fp,"sd=,%f,min=,%f,LL=,%f\n",sd, fMin*(Nstudies-1),LL);
	}

	if (fp) fclose(fp);
	return -LL;
}

//=========================================================================================================
int TestMaxPredALE(struct Coordinates *C)
{

    double Volume=780000.0;
	int Nstudies;
	int X,Y,Z;
	int voxel;
	int voxels;
	int study;
	int focus;
	int LeaveOut;
	float *Effect=NULL;
	float dx,dy,dz;
	double sd;
	double LL,maxLL;
	double lo;
	double min;
	double bestmin,bestsd;
	FILE *fp;
    char fname[MAX_PATH];

	X=gImage.X;
	Y=gImage.Y;
	Z=gImage.Z;
	voxels=X*Y*Z;

	dx=gImage.dx;
	dy=gImage.dy;
	dz=gImage.dz;

	MergeCoordinatesbyStudy(C);
	Nstudies=(*C).Nexperiments;

	if (!(Effect=(float *)malloc(voxels*Nstudies*sizeof(float))))
		goto END;

	sprintf(fname,"%s\\LLale.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");
	fclose(fp);

    bestmin=0.0;
    bestsd=0.0;
	maxLL=DBL_MAX;
	for (sd=10.0; sd<=35.0; sd+=5.0)
	{
		LL=LogLikelihood(C, &gImage, Effect, Nstudies, &min, sd, Volume, fname, 0);
		if (LL<maxLL)
		{
			maxLL=LL;
			bestsd=sd;
		}
	}


	lo=0.0;
	for (study=0; study<Nstudies; study++)
	{
		ComputeStudyEffectUsingGraphTheory(C, study, gImage.img, &Effect[study*voxels], dx, dy, dz, X, Y, Z, lo, bestsd);
	}

	LeaveOut=1;
	gImage.MaxIntensity=2.0*ComputeLooALE(&gImage, Effect, fabs(bestmin), Nstudies, LeaveOut);

	for (focus=0; focus<(*C).TotalFoci; focus++)
	{
		if ((*C).experiment[focus]==LeaveOut)
		{
			voxel=(*C).voxel[focus];
			gImage.img[voxel]=gImage.MaxIntensity;
		}
	}


	char txt[256];
	sprintf(txt,"min=%f\nsd=%f\n%f",bestmin*(Nstudies-1), bestsd,maxLL);
	MessageBox(NULL,txt,"",MB_OK);


END:
	if (Effect)
		free(Effect);
	fclose(fp);
	return 1;
}

/*
	for (study=0; study<Nstudies; study++)
		{
			ComputeStudyEffectUsingGraphTheory(C, study, gImage.img, &Effect[study*voxels], dx, dy, dz, X, Y, Z, MIN_EFFECT, OSD.bestsd);
		}
		gImage.MaxIntensity=ComputeLooALE(&gImage, Effect, OSD.bestmin, Nstudies, -1);
		minALE=OSD.bestmin;

    sd=OSD.bestsd;
    OSD.sd=sd;
	dsd=1.0;
	GoldenSearch(&sd, &dsd, 1, current,  LLwrapper,  &OSD, 3);
*/
