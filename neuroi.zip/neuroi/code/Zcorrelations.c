/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "global.h"
//#include <time.h>
#include "localALE.h"
#include "display.h"
#include "ROIs.h"
#include "imageprocess.h"
#include "numerical.h"
#include "options.h"
#include "loader.h"
#include <ctype.h>

#define MAX_REGIONS 10


int SaveZscoreCorrelationTable(int header, struct Coordinates *ale, int group, struct ThreeVector V[], int regions, double RegionSize, FILE *fp);
int EstimateZscoreClusterTable(struct Coordinates *Co, float *Z, int *n, int NumberOfClusters);


INT_PTR CALLBACK CorrelateZDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static struct Coordinates ale1, ale2;
    static char directory[MAX_PATH];
    char txt[256], fname[MAX_PATH];
    int tmp;
    static double distance;
    static struct ThreeVector V[MAX_REGIONS];
    static int regions;
    FILE *fp;


    switch (msg)
    {

    case WM_INITDIALOG:
        distance=20.0;
        regions=0;
        break;
    case WM_SHOWWINDOW:
        sprintf(txt,"%f",distance);
        SendMessage(GetDlgItem(hwnd,ID_REGION_EXTENT_TXT), WM_SETTEXT, 0, (LPARAM)txt);
        sprintf(txt,"%d",regions);
        SendMessage(GetDlgItem(hwnd,ID_REGION_COUNT), WM_SETTEXT, 0, (LPARAM)txt);
        break;


    case WM_CLOSE:
        if (ale1.Nexperiments) FreeCoordinates(&ale1);
        if (ale2.Nexperiments) FreeCoordinates(&ale2);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hCorrelateZ=(HWND)NULL;
        EndDialog(hwnd,0);
        break;


    case WM_COMMAND:
        switch (LOWORD(wParam))
        {


        case ID_LOAD_ACTIVATIONS:

            if (ale1.Nexperiments) FreeCoordinates(&ale1);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &ale1, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
            {
                if (!ale1.ZscoreUsed)
                {
                    MessageBox(NULL,"No Z scores in that ALE file","",MB_OK|MB_ICONWARNING);
                    FreeCoordinates(&ale1);
                    break;
                }

                tmp=DirectoryFileDivide(ale1.coordinate_file_name);
                sprintf(directory,"%s",ale1.coordinate_file_name);
                directory[tmp]='\0';

                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT), WM_SETTEXT, 0, (LPARAM)ale1.coordinate_file_name);

            }
            break;


        case ID_LOAD_ACTIVATIONS2:

            if (ale2.Nexperiments) FreeCoordinates(&ale2);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &ale2, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
            {
                if (!ale2.ZscoreUsed)
                {
                    MessageBox(NULL,"No Z scores in that ALE file","",MB_OK|MB_ICONWARNING);
                    FreeCoordinates(&ale2);
                    break;
                }

                sprintf(txt,"%f",10.0);
                SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT2), WM_SETTEXT, 0, (LPARAM)ale1.coordinate_file_name);
            }
            break;



        case ID_ADD_REGION:
            V[regions].x=gImage.dx*gMainPict.x-gImage.x0;
            V[regions].y=gImage.dy*gMainPict.y-gImage.y0;
            V[regions].z=gImage.dz*gMainPict.slice-gImage.z0;
            regions++;
            sprintf(txt,"%d",regions);
            SendMessage(GetDlgItem(hwnd,ID_REGION_COUNT), WM_SETTEXT, 0, (LPARAM)txt);
            break;


        case ID_SAVE_CORRELATIONS:
            SendMessage(GetDlgItem(hwnd,ID_REGION_EXTENT_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            distance=atof(txt);
            if (distance<=0.0) break;
            sprintf(fname,"%s//ZscoreTable.csv",directory);
            if ((fp=fopen(fname,"w")))
            {
                if (ale1.TotalFoci)
                {
                    SaveZscoreCorrelationTable(1, &ale1, 1, V, regions, distance, fp);
                    if (ale2.TotalFoci) SaveZscoreCorrelationTable(0, &ale2, 2, V, regions, distance, fp);
                }
                fclose(fp);
            }
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;


        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
    }

    return 0;
}












//======================================================================================================
// R code to visualise the scatter is
//Zcorrelations=read.table("name.txt",header=T)
//pairs(~ cluster1 + cluster2 + cluster3 +......, data = Zcorrelations)
//where Zcorrelations is the name of the matrix containing the data
//======================================================================================================
int SaveZscoreCorrelationTable(int header, struct Coordinates *Co, int group, struct ThreeVector V[],
                               int regions, double RegionSize, FILE *fp)
{

    int Ncoordinates=(*Co).TotalFoci;
    int Nstudies=(*Co).Nexperiments;
    int R;
    int study;
    int coordinate;
    double d,min_d;
    int found;
    char txt[256],nospace[256];

    if (header)
    {
        fprintf(fp,"Study,");
        fprintf(fp,"Group,");
        for (R=0; R<regions; R++)
        {
            sprintf(txt,"%f_%f_%f",V[R].x,V[R].y,V[R].z);
            fprintf(fp,"%s,",txt);
        }
        fprintf(fp,"\n");
    }


    for (study=0; study<Nstudies; study++)
    {
        NoSpaces((*Co).ID[study].txt, nospace);
        fprintf(fp,"%s,%d,",nospace,group);
        for (R=0; R<regions; R++)
        {
            min_d=100000;//something big
            found=-1;
            for (coordinate=0; coordinate<Ncoordinates; coordinate++)
            {
                if ((*Co).experiment[coordinate]==study)
                {
                    d=((*Co).x[coordinate] - V[R].x)*((*Co).x[coordinate] - V[R].x);
                    d+=((*Co).y[coordinate] - V[R].y)*((*Co).y[coordinate] - V[R].y);
                    d+=((*Co).z[coordinate] - V[R].z)*((*Co).z[coordinate] - V[R].z);
                    d=sqrt(d);
                    if ((d<RegionSize) && (d<min_d))
                    {
                        found=coordinate;
                    }

                }
            }//coordinate
            if (found>=0)//found a coordinate in the region
            {
                fprintf(fp,"%f,",(*Co).Zsc[found]/sqrt((*Co).subjects[found]));
            }
            else fprintf(fp,"NA,");
        }//R
        fprintf(fp,"\n");

    }//study


    return 1;
}


//======================================================================================================
//*Co is the coordinates file that contains the clustering
//directory is where the results should be stored
//psig is the p value threshold for the clusters to be significant
//NumberOfClusters is the total number of clusters found, including the non-significant ones
//======================================================================================================
int SaveZscoreCorrelationsForAllClusters(HWND hwnd, struct Coordinates *Co, char directory[], char file[], double psig, int NumberOfClusters)
{

    int result=0;
    int Ncoordinates=(*Co).TotalFoci;
    int Nstudies=(*Co).Nexperiments;
    int i;
    int cluster,study,coordinate;
    int *SaveCluster=NULL;
    int *n=NULL;//number of coordinates from the same study contributing to a single cluster
    float *Z=NULL;//sum of Z scores for coordinates in a single study contributing to a cluster
    FILE *fp=NULL;
    char fname[MAX_PATH];
    char nospace[256];


    if (!(Z=(float *)calloc(NumberOfClusters*Nstudies,sizeof(float)))) goto END;
    if (!(n=(int *)calloc(NumberOfClusters*Nstudies,sizeof(int)))) goto END;
    if (!(SaveCluster=(int *)calloc(NumberOfClusters,sizeof(int)))) goto END;

    //consider only significant clusters
    for (coordinate=0; coordinate<Ncoordinates; coordinate++)
    {
        if ( ((*Co).p[coordinate]<=psig) && ((*Co).cluster[coordinate]) )
        {
            SaveCluster[(*Co).cluster[coordinate]-1]=1;
        }
    }

    //get the Z scores for each cluster
    EstimateZscoreClusterTable(Co, Z, n, NumberOfClusters);




    //open the file
    sprintf(fname,"%s\\Zplot.R",directory);
    if (!(fp=fopen(fname,"w"))) goto END;
    if (!NumberOfClusters)
    {
        fprintf(fp,"No Clusters :(");
        goto END;
    }


    //fprintf the row names
    NoSpaces((*Co).ID[0].txt, nospace);
    fprintf(fp,"rownames=c(\"%s\"",nospace);
    for (study=1; study<Nstudies; study++)
    {
        NoSpaces((*Co).ID[study].txt, nospace);
        fprintf(fp,",\"%s\"",nospace);
    }
    fprintf(fp,")\n");

    //fprintf the effect sizes
    for (cluster=1; cluster<=NumberOfClusters; cluster++)
    {
        if (SaveCluster[cluster-1])
        {
            if (fabs(Z[cluster-1])>0.0) fprintf(fp,"CL%d=c(%f",cluster,Z[cluster-1]);
            else fprintf(fp,"CL%d=c(NA",cluster);
            for (study=1; study<Nstudies; study++)
            {
                if (fabs(Z[study*NumberOfClusters +cluster-1])>0.0) fprintf(fp,",%f",Z[study*NumberOfClusters +cluster-1]);
                else fprintf(fp,",NA");
            }
            fprintf(fp,")\n");
        }
    }

    //fprintf the dataframe
    fprintf(fp,"Zscores=data.frame(row.names=rownames");
    for (cluster=1; cluster<=NumberOfClusters; cluster++)
    {
        if (SaveCluster[cluster-1])
        {
            fprintf(fp,",CL%d",cluster);
        }
    }
    fprintf(fp,")\n");


    //plot the data
        fprintf(fp,"panel.cor <- function(x, y, digits = 2, prefix = \"\", cex.cor, ...) \n{\n");
        fprintf(fp,"OK <- complete.cases(x, y)\n x <- x[OK]\n y <- y[OK]\n n <- length(x)\n");
        fprintf(fp,"if (n>2)\n{\n");
        fprintf(fp,"usr <- par(\"usr\"); on.exit(par(usr))\n");
        fprintf(fp,"par(usr = c(0, 1, 0, 1))\n");
        fprintf(fp,"r <- cor.test(x, y, na.action=na.complete)\n");
        fprintf(fp,"txt <- format(c(r$estimate, 0.123456789), digits = digits)[1]\n");
        fprintf(fp,"if (r$p.value<0.0001){ txt <- paste0(txt,\"\\n\",\"***\") }\n");
        fprintf(fp,"else if (r$p.value<0.001){ txt <- paste0(txt,\"\\n\",\"**\") }\n");
        fprintf(fp,"else if (r$p.value<0.01){ txt <- paste0(txt,\"\\n\",\"*\") }\n");
        fprintf(fp,"text(0.5, 0.5, txt,cex = 1.7)\n");
        fprintf(fp,"}\n}\n");


        i=1;
        while (!SaveCluster[i-1]) i++;
        fprintf(fp,"pairs(~ CL%d",i);
        for (cluster=i+1; cluster<=NumberOfClusters; cluster++)
        {
            if (SaveCluster[cluster-1]) fprintf(fp," + CL%d",cluster);
        }
        fprintf(fp,",data = Zscores, lower.panel=panel.cor)\n");



    result=1;
END:

    if (Z) free(Z);
    if (n) free(n);
    if (fp) fclose(fp);

    return result;
}


//======================================================================================================
//Estimate a table of reported Z scores by cluster
//NumberOfClusters is the total number of clusters in coordinate file *Co
//======================================================================================================
int EstimateZscoreClusterTable(struct Coordinates *Co, float *Z, int *n, int NumberOfClusters)
{

    int Nstudies=(*Co).Nexperiments;
    int study;
    int subjects,controls;
    int coordinate,Ncoordinates=(*Co).TotalFoci;
    int cluster;
    double standardise;

    memset(Z,0,sizeof(float)*NumberOfClusters*Nstudies);
    memset(n,0,sizeof(int)*NumberOfClusters*Nstudies);

    //get the Z scores by cluster and study
    for (study=0; study<Nstudies; study++)
    {

        subjects=(*Co).SubjectsInExp[study];
        controls=(*Co).ControlsInExp[study];
        if (controls>0)
        {
            standardise=sqrt((double)controls*subjects/(controls+subjects));
        }
        else standardise=sqrt((double)subjects);

        for (coordinate=0; coordinate<Ncoordinates; coordinate++)
        {
            if ((*Co).experiment[coordinate]==study)
            {
                if (((*Co).cluster[coordinate]) && (fabs((*Co).Zsc[coordinate])!=1.0))//include coordinates that are part of clusters and have known Z scores
                {
                    Z[study*NumberOfClusters + (*Co).cluster[coordinate]-1] += (*Co).Zsc[coordinate]/standardise;
                    n[study*NumberOfClusters + (*Co).cluster[coordinate]-1] ++;
                }
            }
        }
    }



    for (study=0; study<Nstudies; study++)
    {

        for (cluster=0;cluster<NumberOfClusters;cluster++)
        {
                if (n[study*NumberOfClusters + cluster])
                {
                    Z[study*NumberOfClusters + cluster]/=n[study*NumberOfClusters + cluster];
                }

        }
    }



    return 1;
}

