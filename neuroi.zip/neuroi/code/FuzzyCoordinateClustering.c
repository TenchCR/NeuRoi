/*
Copyright 2009 - 2020 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/



double FuzzyCoordinateClustering(float x[], float y[], float z[], short int experiment[], int Nfoci, float xc[], float yc[], float zc[], int Nclusters)
{
    int cl;
    int iteration;
    double *w=NULL;

    if (!(w=(double *)malloc(Nfoci*Nclusters*sizeof(double)))) goto END;

    //Initialise the cluster centres
    for (cl=0;cl<Nclusters;cl++)
    {
        xc[cl]=150.0*rand()/RAND_MAX - 75.0;
        yc[cl]=150.0*rand()/RAND_MAX - 75.0;
        zc[cl]=150.0*rand()/RAND_MAX - 75.0;
    }

    //Assign coordinates to clusters

    //iterate clustering weights

    //select the assignments from the weights



END:
    if (w)
    {
        free(w);
    }


    return 0.0;
}

//======================================================================================
int UpdateCoordinateWeights(float x[], float y[], float z[], short int experiment[], int Nfoci, float xc[], float yc[], float zc[], int Nclusters, double *w)
{


    return 0;
}
//======================================================================================
double Distance2ToCluster(float x, float y, float z, float xc, float yc, float zc)
{
    return (x-xc)*(x-xc) + (y-yc)*(y-yc) + (z-zc)*(z-zc);
}
