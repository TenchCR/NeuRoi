/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(COREGISTER_H)
//Do Nothing
#else

#define COREGISTER_H
//--------------------------------------------------------------------------------------------
//                              routines for coregistration
//                              9th July 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "menuresources.h"
#include "loader.h"
#include "numerical.h"
#include "imageprocess.h"


//CLASSES 12 works for brains
#define CLASSES 12
//4.0mm works OK for brains.
#define PRE_PROCESS_SMOOTH 4.0
#define MAX_SAMPLE_POINTS 50000
///FOR KNEE SMOOTH 2.0 AND USE 20 CLASSES///


struct SamplePoints{
    float x[MAX_SAMPLE_POINTS];
    float y[MAX_SAMPLE_POINTS];
    float z[MAX_SAMPLE_POINTS];
    char cl[MAX_SAMPLE_POINTS];//the class at that point
    int used;
};

struct RegData{
    struct Image Match;
    struct SamplePoints Points;//the registration test points
    double x0;
    double y0;//centre of intensity
    double z0;
    double *PolyTerms;//lookup table for the registration polynomial (1 + x + y +z + ...x^n...); so it does not need computing again
    int *order;
};



//BaseDims contains the dimensions of the Base image that an image was registered to
//These are saved in the parameter files after registration
struct BaseDims{
       int X;
       int Y;
       int Zpv;
       float dx;
       float dy;
       float dz;
       float x0;
       float y0;
       float z0;
};

HWND hCoregisterDlg;
INT_PTR CALLBACK CoregisterDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ManualCoregisterDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int MultiVolumeRegistration(HWND hwnd, struct Image *image);

int RegisterTwoImagesP(HWND hwnd, struct Image *Base, struct Image *Match, double p[], int Nparameters, double SmoothWidth, unsigned char *mask, int UseMask);
int ReformatMatchImage(int BX, int BY, int BZ, float Bdx, float Bdy, float Bdz, float Bxorg, float Byorg, float Bzorg,
                        struct Image *Match, double p[], int Nparameters, int InterpolationMethod);
int ReleaseRegData(struct RegData *RD);
int InitialiseRegistrationParameters(double param[], int N);
int GetTestPoints(struct RegData *p, float *fimg, unsigned char ClassImg[], int X, int Y, int Z, float dx, float dy, float dz, unsigned char *mask, int UseMask);
double MinimiseRegistrationError(HWND hWnd, HWND hwnddlgitm, double V[], int Nparameters, struct RegData *dat);
float GetTransformedVoxelCoordinates(float *x, float *y, float *z, float x0, float y0, float z0, float dx, float dy, float dz, struct AffineMatrix *M, double p[],
                                                         double *poly, int Nparameters);
float GetTransformedCoordinates(float *x, float *y, float *z, float x0, float y0, float z0, float dx, float dy, float dz,
                                     struct AffineMatrix *M, double p[], double *poly, int Nparameters);
int MatchPositionFromBaseVoxel(struct Image *Match, struct Image *Base, int voxelB, float *xm, float *ym, float *zm, struct AffineMatrix *M,
                                                    double p[], int Nparameters, int PolyOrder);
int ShowBaseMatchMix(HWND hwnd, struct Image *Base, struct Image *Match, int slice,
                     double p[], int Nparameters, double fraction, float saturation);
int SaveRegisteredImage(struct Image *Base, struct Image *Match, double p[], int Nparameters, int SAVEAS, int InterpolationMethod);
int TransformROIs(HWND hwnd, struct Image *image);
int TestDWI_COV(struct Image *DWI);
int LoadParameters(double p[], int N, struct BaseDims *bd);
int ProcessForRegistration(struct Image *image, double SmoothWidth, int Classes);
double DeviationFromIndependence(double p[], int parameters, void *regdata);
int SaveParameters(char imagename[], double p[], int N, struct Image *Base);
#endif
