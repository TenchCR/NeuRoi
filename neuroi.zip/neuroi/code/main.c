/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/




#include <ole2.h>
#include "global.h"
//#include <time.h>

int OnExit(void);


/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);



/*  Make the class name into a global variable  */
char szClassName[ ] = CLASSNAME;










//====================================================================================================
//                             MAIN WINDOW FUNCTION
//====================================================================================================
int WINAPI WinMain (HINSTANCE hThisInstance, HINSTANCE hPrevInstance,LPSTR lpszArgument,int nFunsterStil){

    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */
    char title[256];
    char txt[MAX_PATH];
    int texty;
    int pos;
    HDC hDC;
    TEXTMETRIC tm;
    COLORREF textcol;


    //this is an output file that functions can report current updates too
#ifdef DEVELOP
    FILE *fp;
    if ((fp=fopen(REPORT_FILE,"w"))) fclose(fp);
#endif // DEVELOP

    //put the compile date on the title bar so that I know something (but not much) about the version running
    sprintf(title,"NeuRoi");
#ifdef __DATE__
    sprintf(title,"NeuRoi        compiled on %s at %s", __DATE__, __TIME__ );
#endif


    //fixes a bug associated with the GetOpen/SaveFileName function (include ole2.h and libole32.lib)
	//this bug relates to some versions of adobe 7 according to internet
	//remove this line, and the associated OleUninitialize, to reproduce the bug
    OleInitialize(NULL);




    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);


    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (hThisInstance, MAKEINTRESOURCE(ID_NEUROI_ICON));
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */

    /* Use Windows's default color as the background of the window */
    wincl.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;


    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                                                                   /* Extended possibilites for variation */
           szClassName,                                                         /* Classname */
           title,                                                               /* Title Text */
           WS_OVERLAPPEDWINDOW|WS_VSCROLL|WS_HSCROLL,                           /* default window with scroll*/
           80,                                                                  /* Windows position */
           0,                                                                   /* top left of the screen */
           X_SCREEN_SIZE,                                                       /* The programs width */
           Y_SCREEN_SIZE,                                                       /* and height in pixels */
           HWND_DESKTOP,                                                        /* The window is a child-window to desktop */
           LoadMenu(hThisInstance,MAKEINTRESOURCE(IDMAINMENU)),                 /* Menu Resources */
           hThisInstance,                                                       /* Program Instance handler */
           NULL                                                                 /* No Window Creation data */
           );

    /*            Register the status bar               */
    hStatusBar=RegisterStatusWindow(hwnd, hThisInstance);
//GetWindowLongPtr( hwnd, GWLP_HINSTANCE); will get the instance if not otherwise available

    /*       Register the Tool bar             */
    hToolBar=CreateToolBar(hwnd, hThisInstance);

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nFunsterStil);

    //show the licence notice
    hDC=GetDC(hwnd);
    GetTextMetrics(hDC, &tm);
    textcol=GetTextColor(hDC);
    texty=80;
    sprintf(txt,"NeuRoi. Copyright 2009 - 2021 Christopher Tench");
    TextOut(hDC,10,texty,txt,strlen(txt));
    sprintf(txt,"This program comes with ABSOLUTELY NO WARRANTY.");
    texty+=tm.tmHeight*1.5;
    TextOut(hDC,10,texty,txt,strlen(txt));
    sprintf(txt,"This is free software, and you are welcome to redistribute it under certain conditions.");
    texty+=tm.tmHeight*1.5;
    TextOut(hDC,10,texty,txt,strlen(txt));
    sprintf(txt,"See included gpl.txt file for details.");
    texty+=tm.tmHeight*1.5;
    TextOut(hDC,10,texty,txt,strlen(txt));

    SetTextColor(hDC,RGB(255,0,0));
    sprintf(txt,"**************DO NOT USE THIS PROGRAM TO STUDY ANIMALS*******************");
    texty+=tm.tmHeight*1.5+20;
    TextOut(hDC,10,texty,txt,strlen(txt));
    SetTextColor(hDC,textcol);



    //-------------LOAD THE SETTINGS------------------------
    //GetCurrentDirectory(MAX_PATH, ExecutableDirectory);
    GetModuleFileName(NULL, ExecutableDirectory, MAX_PATH);
    pos=DirectoryFileDivide(ExecutableDirectory);
    ExecutableDirectory[pos]='\0';
    //MessageBox(NULL,ExecutableDirectory,"",MB_OK);
    LoadOptions(ExecutableDirectory, &gOptions);
    if (gOptions.UseColourBackground) CheckMenuItem(GetMenu(hwnd), IDM_COLOUR_BACKGROUND, MF_CHECKED);
    if (gOptions.standardise_scale) CheckMenuItem(GetMenu(hwnd), IDM_LOAD_WITH_STANDARD_SCALE, MF_CHECKED);
    if ( strlen(gOptions.TemplateDir) ){
        sprintf(txt,"Template directory:");
        texty+=tm.tmHeight*1.5+20;
        TextOut(hDC,10,texty,txt,strlen(txt));
        texty+=tm.tmHeight*1.5;
        TextOut(hDC,10,texty,gOptions.TemplateDir,strlen(gOptions.TemplateDir));
    }




    ReleaseDC(hwnd,hDC);

    memset(&gImage,0,sizeof(struct Image));

//MessageBox(NULL,REPORT_FOLDER,"",MB_OK);


    //if the commandline indicates an image, load it
    if (strlen(lpszArgument)){
//MessageBox(NULL,"Loading Image","",MB_OK);
        sprintf(txt,"%s",&lpszArgument[1]);
        txt[strlen(txt)-1]='\0';
        //MessageBox(NULL,txt,"",MB_OK);
//MessageBox(NULL,txt,"",MB_OK);
        if (LoadFromFileName(hwnd, txt, &gImage, gOptions.standardise_scale)){

                //Enable the menu items
                SetMenuItemState(hwnd, MF_ENABLED);
                InitialisePicture(hwnd, &gImage, &gMainPict);
                SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);

                //add buttons to the ToolBar now that an image has been loaded
                AddToolbarButtons(hToolBar, hThisInstance);
                EnableMainMenuItem(hwnd);
        }
    }




    srand ( time(NULL) );

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0)){
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }


    OleUninitialize( );

    SaveOptions(ExecutableDirectory, &gOptions);

    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}









//====================================================================================================
//           This function is called by the Windows function DispatchMessage()
//====================================================================================================
LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){

    int pos;
	PAINTSTRUCT PaintStruct;
    RECT Rect=GetImageRect(hwnd, hStatusBar, hToolBar);
    HDC hDC;
    TCHAR chKey;


    switch (message){                                                           /* handle the messages */


        case WM_CREATE:
             //--------set up the scroll bars----------------------
			 SetScrollRange(hwnd,SB_HORZ,0,10*X_SCREEN_SIZE,FALSE);
			 SetScrollPos(hwnd,SB_HORZ,0,TRUE);
			 SetScrollRange(hwnd,SB_VERT,0,10*Y_SCREEN_SIZE,FALSE);
			 SetScrollPos(hwnd,SB_VERT,0,TRUE);
		break;


        case WM_VSCROLL:
        case WM_HSCROLL:                                                        //respond to scroll bar actions
			 if (message==WM_VSCROLL){
    			 pos=GetScrollPos(hwnd,SB_VERT);
	    		 if (LOWORD(wParam)==SB_LINEUP)                 SetScrollPos(hwnd,SB_VERT,pos-10,TRUE);
		      	 else if (LOWORD(wParam)==SB_LINEDOWN)          SetScrollPos(hwnd,SB_VERT,pos+10,TRUE);
          		 else if (LOWORD(wParam)==SB_PAGEUP)            SetScrollPos(hwnd,SB_VERT,pos-40,TRUE);
		      	 else if (LOWORD(wParam)==SB_PAGEDOWN)          SetScrollPos(hwnd,SB_VERT,pos+40,TRUE);
		       	 else if (LOWORD(wParam)==SB_THUMBTRACK)        SetScrollPos(hwnd,SB_VERT,HIWORD(wParam),TRUE);
                 gMainPict.ypos=-GetScrollPos(hwnd,SB_VERT)+Y_ORIGIN;
                 ScrollWindow(hwnd,0,pos-GetScrollPos(hwnd,SB_VERT),&Rect,&Rect);//scroll only the client rect above the statuswindow
             }
             else{
                 pos=GetScrollPos(hwnd,SB_HORZ);
                 if (LOWORD(wParam)==SB_LINELEFT)               SetScrollPos(hwnd,SB_HORZ,pos-10,TRUE);
			     else if (LOWORD(wParam)==SB_LINERIGHT)         SetScrollPos(hwnd,SB_HORZ,pos+10,TRUE);
			     else if (LOWORD(wParam)==SB_PAGELEFT)          SetScrollPos(hwnd,SB_HORZ,pos-40,TRUE);
			     else if (LOWORD(wParam)==SB_PAGERIGHT)         SetScrollPos(hwnd,SB_HORZ,pos+40,TRUE);
			     else if (LOWORD(wParam)==SB_THUMBTRACK)        SetScrollPos(hwnd,SB_HORZ,HIWORD(wParam),TRUE);
                 gMainPict.xpos=-GetScrollPos(hwnd,SB_HORZ)+X_ORIGIN;
                 ScrollWindow(hwnd,pos-GetScrollPos(hwnd,SB_HORZ),0,&Rect,&Rect);//scroll only the client rect above the statuswindow
             }
             UpdateWindow(hwnd);
		break;


		case WM_SIZE:
            SendMessage(hToolBar,message,wParam,lParam);
			SendMessage(hStatusBar,WM_SIZE,0,0);
		break;

        case WM_COPYDATA://copy data between NeuROI programs
            if (IsMenuItemChecked(hwnd, IDM_LINK_PROGRAMS) && LOWORD(wParam)==ID_SET_ORTHOGONAL_COORDINATES)
                                    return SetOrthogonalPlanesFromExternalCall(hwnd, Rect, &gMainPict, &gImage, (PCOPYDATASTRUCT) lParam);
            break;

		case WM_COMMAND:                                                        //menu commands,

             WMcommandFunc(hwnd, wParam, lParam);
        break;

		case WM_KEYDOWN:                                                        //handle the key input
             WMcommandKeyFuncs(hwnd, hStatusBar, message, wParam, lParam, &gMainPict, &gImage);
        break;
        case WM_CHAR:
            chKey=(TCHAR)wParam;
            if (chKey==(TCHAR)'X'  && !hCoregisterDlg) SendMessage(hwnd, WM_COMMAND, IDM_ROTATE_X, 0);
            if (chKey==(TCHAR)'Y'  && !hCoregisterDlg) SendMessage(hwnd, WM_COMMAND, IDM_ROTATE_Y, 0);
            if (chKey==(TCHAR)'Z'  && !hCoregisterDlg) SendMessage(hwnd, WM_COMMAND, IDM_ROTATE_Z, 0);
        break;

        case WM_MOUSEMOVE:                                                      //mouse input
        case WM_LBUTTONDOWN:
        case WM_LBUTTONUP:
        case WM_RBUTTONDOWN:
        case WM_MBUTTONDOWN:
		case WM_LBUTTONDBLCLK:
        case WM_MOUSEWHEEL:
             ProcessWMmouseFuncs(hwnd, hStatusBar, message, wParam, lParam, &gMainPict, &gImage);
        break;

        case WM_PAINT:
			hDC=BeginPaint(hwnd, &PaintStruct);
			DrawBitmapEx(hDC, hwnd, &gMainPict, hStatusBar, 0);
			gMainPict.NeedsRedraw=0;                                            //Next slice can be drawn now this has been displayed
            EndPaint(hwnd, &PaintStruct);
            InvalidateRect(hToolBar, NULL,1);                                   //in case we accidentally overwrite these
            InvalidateRect(hStatusBar, NULL,1);
			return 0;
		break;

        case WM_DESTROY:
            OnExit();
            PostQuitMessage (0);                                                // send a WM_QUIT to the message queue
        break;



        default:                                                                // for messages that we don't deal with
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}








//=======================================================================================
//                      Free Memory On Exit
//=======================================================================================
int OnExit(void){
    FreeROIMemory();
    ReleaseImage(&gImage);
    if (gMainPict.pict) free(gMainPict.pict);
    return 1;
}



