/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(Tensor_H)
//Do Nothing
#else

#define Tensor_H
//--------------------------------------------------------------------------------------------
//                              routines for Tensors
//                              4th June 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "numerical.h"
#include "loader.h"


//---eigenvalue order-----
#define HIGH 2
#define MID 1
#define LOW 0

//----Scalars-------------
#define RA 1
#define FA 2
#define TRACE 3
#define EVALS 4


//-----index to the 3x3 diffusion tensor elements-----
#define Dxx 0
#define Dyy 1
#define Dzz 2
#define Dxy 3
#define Dxz 4
#define Dyz 5


#define DTI_TRACTOGRAPHY 1
#define FODF_TRACTOGRAPHY 2

#define MAX_DIFFUSION_DIRECTIONS 512


struct Tractography{
    float *tnsr;                    //this is a 6 volume image with the tensor elements
    float *fa;                      //allows fa stopping
    float *fODF;                    //if doing fODF tractography, need this instead of *tnsr
    struct ThreeVector *directions; //directions needed for fODF tractography |V[i]|=1
    struct ThreeVector InitDir;     //initial direction
    int idirections;
    int X;
    int Y;
    int Zpv;
    int volumes;
    float dx;
    float dy;
    float dz;
    float offset;
    float scale;
    float direction;                //this determines which direction to do tractography in {-1, +1}
    float MinFA;
    float Mindp;                    //minimum dot product between successive vectors
    int n;                          //determines how many times the tensor will be applied to the vector
};                                  //the bigger n the closer to conventional tractography



struct bMatrix{
	double b[3][3];								//b matrix
	double bValue;								//b value
};


#define MAX_TRAJECTORY_LENGTH 512//step size is ~1mm, so this allows trajectory up to 0.5m!
struct Trajectory{
    float xyz[MAX_TRAJECTORY_LENGTH*3];     //the points along the trajectory through the image
    int length;                             //index length-1 is last valid index in xyz
    int seed;                               //index to the seed in xyz[]
    struct ThreeVector SeedVector;
};

struct FourVector{
    signed char x;
    signed char y;
    signed char z;
    unsigned char mag;
};


int Process2volumeDWscan(HWND hwnd, struct Image *DWI, struct bMatrix B[]);
int ProcessDWI(HWND hwnd, struct Image *DWI);
int ProcessDWIGivenBmatAndV(HWND hwnd, struct Image *DWI, struct bMatrix B[], struct ThreeVector V[]);
int RearrangeDWI(struct Image *DWI);

int LoadDirections(struct ThreeVector V[], char filename[]);
int LoadAcquisitionBvalues(float bvals[]);
int LoadbMatrices(struct bMatrix B[], int volumes, int Rearranging);
int LoadbMatricesGivenFileName(struct bMatrix B[], int volumes, char fname[]);
int LoadAcquisitionDirections(struct ThreeVector xyz[]);
int LoadAcquisitionDirectionsGivenFileName(struct ThreeVector xyz[], char fname[]);
int SaveBmatrices(char fname[], struct bMatrix *B, int N);
int SaveBvalues(char fname[], float *bvals, int N);
int SaveGradientVectors(char fname[], struct ThreeVector *V, int N);
int CreateBmatrixFile(void);

double FracAnisotropy(double e1, double e2, double e3);
double RelAnisotropy(double e1, double e2, double e3);
double DTtrace(double e1, double e2, double e3);

double InterpolateTensorImage(double T[], double *fa, float *Timage, float *faimg, int X, int Y, int Zpv,
                            float dx, float dy, float dz, float x, float y, float z, float scale, float offset);
double TensorDeflection(void *Tim, float P[], int n, float K[]);
int TensorDeflectVector(double T[], float V[]);

double FodfDeflectionTractography(void *Tim, float P[], int n, float K[]);
struct ThreeVector FodfDeflection(float fODF[], int directions, struct ThreeVector Vectors[], struct ThreeVector InitDir);
int FitTensorModel(float DWI[], int X, int Y, int Zpv, int volumes, float *DT, struct bMatrix B[]);
int ComputeTensor(float DWI[], int X, int Y, int Zpv, int volumes, int voxel, double Xinv[], float *tnsr, struct bMatrix B[]);
int EigenSolutionsForDTI(struct Image *DT, int voxel, double evals[], double V[]);

int ConvertDWItoTensor(struct Image *DWI);
int ConvertDWItoTensorGivenBmatrices(struct Image *DWI, struct bMatrix B[]);
int ConvertTensorToPrincipalEvector(struct Image *DT);
int ConvertTensorToScalar(struct Image *DT, int SCALAR);

int GetMatrixFromTensor(double M[], float tens[], int X, int Y, int Zpv, int voxel, float scale, float offset);

int GetTrajectory(struct Trajectory *traj, struct Tractography *tractog, float x, float y, float z, int mode);
int TestGetTrajectory( struct Tractography *tractography);

double TensorODF(double T[], struct ThreeVector V);

double SmoothDWIresidualWeighted(struct Image *image);
int TestFitDWIquadratic(struct Image *image, int x, int y, int z);
int OrthogonalVectors(double V[]);
double AttenuationSymmetric(double bvalue, double evalue1, double evalue2, struct ThreeVector principal, struct ThreeVector acquisition);
int GenerateDiffusionSignal(int Tensors, struct ThreeVector principal[], double volume[], float e1, float e2,
                            float bval, struct ThreeVector Vdirs[], int directions, double S[]);

int ConvertFSL_V_to_RGB(HWND hwnd, struct Image *image);
#endif
