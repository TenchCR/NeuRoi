/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#define MAX_TALAIRACH_LABEL 1200

#include "CBMAfiles.h"
#include "display.h"

//======================================================================================================
int TestPCA_CBMA(struct Coordinates *C)
{

    int Nstudies=(*C).Nexperiments;
    double *TalVectors=NULL;
    double *CVM=NULL;//the covariance matrix
    double *evals=NULL;
    double *PCs=NULL;//principle coordinates

    if (!(TalVectors=(double *)calloc(MAX_TALAIRACH_LABEL*Nstudies,sizeof(double)))) goto END;

    if (!(CVM=(double *)malloc(Nstudies*Nstudies*sizeof(double)))) goto END;

    if (!(evals=(double *)malloc(Nstudies*sizeof(double)))) goto END;

    if (!(PCs=(double *)malloc(Nstudies*Nstudies*sizeof(double)))) goto END;

    GetTalairachLabels(C);

    //GetTalairachVectors(C, TalVectors);

    //GetCovarianceMatrix(TalVectors, CVM, Nstudies, MAX_TALAIRACH_LABEL);


    //JacobiEigenSystemSolver(CVM, PCs, evects, Nstudies, 1);

END:
    if (TalVectors)
    {
        free(TalVectors);
    }
    if (CVM)
    {
        free (CVM);
    }
    if (evals)
    {
        free(evals);
    }
    if (PCs)
    {
        free(PCs);
    }
    return 0;
}
