/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "display.h"
#include "imageprocess.h"
#include "CBMAN.h"
#include "numerical.h"
#include "ClusterZ.h"
#include "CoordinateProcess.h"
#include "MeanShiftCoordinateClustering.h"

#define CBMAN_PERMUTATIONS 5000

///integration
#define MAX_INTEGRATION_POINTS 1000
#define INTEGRATION_ERROR 1.0e-5//1.0e-5

///PARAMETERS
#define MEANX   0
#define MEANY   1
#define VARX    2
#define VARY    3
#define RHO     4
#define RHO2    5



///HOW MANY VALID (UNCENSORED) POINTS SHOULD THERE BE BEFORE THE BIVARIATE FIT IS CONSIDERED VALID?
#define MIN_VALID_POINTS 5///5 because thats the minimum number where pvalue substantially<<0.05 is possible

///MINIMUM NUMBER OF EXPERIMENTS DEFINING A CLUSTER
#define MINIMUM_EXPERIMENTS 4


///THERE ARE TWO ANALYSIS OPTIONS: SINGLE GROUP, COMPARE GROUP
///SINGLE GROUP HAS TWO VARIANCES, TWO MEANS, ONE COVARIANCE
///COMPARING GROUPS ALLOWS FOR TWO VARIANCES, TWO MEANS, AND ONE OR TWO (NULL OR ALTERNATIVE RESPECTIVELY) COVARIANCES
#define CBMAN_PARAMETERS 5
#define CBMAN_PARAMETERS_GROUPS 6


struct BVNintegration
{
	double mx;
	double my;
	double vx;
	double vy;
	double rho;
	double CensorLevel;
	int CensorType;
};


int ForestPlotRCBMAN(struct Coordinates *c, struct BivariateSample *BV, int cluster1, char directory[]);

int TestFittingBivariateNormSymmetry(int Nsamples);

double PvalueOfConnectionUsingAllPermutations(double P[], struct BivariateSample *BV, int SamplesToPermute);
int PermuteBivariateNormal(struct BivariateSample *BV);

int rMVNwithintol(double MV[], double mean[], double Sigma[], int n, int samples);


int SaveCorrelationMatrixPlot(HWND hwndMain,
                              double *MinPcluster,
                              double cor[],
                              double Pmat[],
                              double critical,
                              int Nclusters,
                              char directory[]);

int SavePrincipalCoordinateAnalysis(int Nclusters,
                                    double *R, //correlation matrix [Nclusters x Nclusters]
                                    char directory[]) ;

int SaveiGraph(int Nclusters,
               double *MinPcluster,//minimum pvalue for a cluster; must be <=critical
               double *R, //correlation matrix [Nclusters x Nclusters]
               double *p, //p value  matrix [Nclusters x Nclusters]
               int *valid,//valid  matrix [Nclusters x Nclusters]
               double critical, //p value threshold for significance
               char directory[]);


int ToTest(struct Coordinates *Co, int CL1, int CL2);
;


double IntegrateBVNwrapper(double y, void *BVN);

double MaximumLogLikelihood(struct Coordinates *Co,
                            struct BivariateSample *BV,
                            int cluster1, int cluster2,
                            char directory[]);
double MaximumLogLikelihoodGroup(struct Coordinates *Co,
                                 struct BivariateSample *BV,
                                 int cluster1, int cluster2,
                                 char directory[]) ;


int SetValidCoordinatePvalues(struct Coordinates *Co, double Pmat[], double Pclust[], int Nclusters, int valid[]);
int GenerateExperiments(struct Image *mask);
int Paper_netork_examples(struct Coordinates *Co, struct Image *mask, int Studies, int Subjects, double Zcensor,
                          double SDcoord, struct ThreeVector V[], int nClusters, int nRandomCoordinates,
                          double mean[], double Sigma[]);
int GenerateGroupExperiments(struct Image *mask);
int Paper_netork_groups_examples(struct Coordinates *Co,
                                 struct Image *mask,
                                 int StudiesA, int StudiesB, int Subjects,
                                 double Zcensor,
                                 double SDcoord,
                                 struct ThreeVector V[],
                                 int nClusters, int nRandomCoordinates,
                                 double meanA[], double SigmaA[],
                                 double meanB[], double SigmaB[]);


int SaveTalairachNetworkProjection(HWND hwndMain,
                                   struct Coordinates *Co,
                                   double cor[],
                                   double Pmat[],
                                   int valid[],
                                   double critical,
                                   float xp[],float yp[], float zp[],
                                   int Nclusters,
                                   char directory[]) ;
int SaveTalairachCoordinateProjection(HWND hwndMain,
                                      float x[], float y[], float z[], int N, short int col[], int Ncolours,
                                      char name[], char directory[]);

int SaveNetworkProjection(HWND hwndMain,
                          struct Image *mask,
                          struct Coordinates *Co,
                          double cor[],
                          double Pmat[],
                          int valid[],
                          double critical,
                          float xp[],float yp[], float zp[],
                          int Nclusters,
                          char directory[]);

///paper test functions
int TestNullDistribution(int Nstudies, int Nsubjects, double mean, double sd);

int TestFittingBivariateNormGroups(int Nsamples);
int TestCBMANwithRandomCoordinates(HWND hwnd,
                                   struct Image *image,
                                   double critical,
                                   struct Coordinates *Co,
                                   int MarkerSize,
                                   char directory[]);

//=============================================================================================
//                           ClusterZ callback function
//=============================================================================================
INT_PTR CALLBACK CBMAN_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	static struct Coordinates CoordinateStruct;
	static char directory[MAX_PATH];
	static double pvalue;
	static int MarkerSize;
	static int MergeStudies;
	char txt[256];
	int tmp;
	HCURSOR hourglass;
	HCURSOR	PrevCursor;

	switch (msg)
	{
	case WM_CLOSE:
		if (CoordinateStruct.Nexperiments)
			FreeCoordinates(&CoordinateStruct);
		SetMenuItemState(GetParent(hwnd), MF_ENABLED);
		hCBMAN=(HWND)NULL;
		EndDialog(hwnd,0);
		break;

	case WM_SHOWWINDOW:
		sprintf(txt,"%3.2f",pvalue);
		SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
		sprintf(txt,"%d",MarkerSize);
		SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_SETTEXT, 0, (LPARAM)txt);
		SendMessage(GetDlgItem(hwnd,ID_FWER), WM_SETTEXT, 0, (LPARAM)txt);
		if (MergeStudies)
			SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_CHECKED,0);
		else
			SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_UNCHECKED,0);
		break;

	case WM_INITDIALOG:
		memset(&CoordinateStruct,0,sizeof(struct Coordinates));
		srand ( time(NULL) );
		SetMenuItemState(GetParent(hwnd), MF_GRAYED);
		pvalue=0.05;
		MergeStudies=1;
		MarkerSize=DEFAULT_MARKER_SIZE;
		break;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{

		case ID_LOAD_ACTIVATIONS:
			EnableWindow(GetDlgItem(hwnd,ID_LOAD_ACTIVATIONS),FALSE);
			if (CoordinateStruct.Nexperiments) FreeCoordinates(&CoordinateStruct);
			if (LoadExperimentsCOORDINATES(GetParent(hwnd), &CoordinateStruct, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
			{
				if (MessageBox(NULL,"Are you sure studies using the same subjects have the same studyID?","IMPORTANT!",MB_YESNO|MB_ICONWARNING)==IDNO)
				{
					MessageBox(NULL,"Please edit the coordinate file to correct this.\nStudies using the same subjects must have the same studyID or the results will not be valid.\nMinimizing within-experiment and within-group effects in Activation Likelihood Estimation meta-analyses\nTurkeltaub PE","INVALID META-ANALYSIS",MB_OK|MB_ICONWARNING);
					SendMessage(hwnd, WM_CLOSE,0,0);
					EnableWindow(GetDlgItem(hwnd,ID_LOAD_ACTIVATIONS),TRUE);
					break;
				}

				hourglass=LoadCursor(NULL,IDC_WAIT);
				PrevCursor=SetCursor(hourglass);

				tmp=DirectoryFileDivide(CoordinateStruct.coordinate_file_name);
				sprintf(directory,"%s",CoordinateStruct.coordinate_file_name);
				directory[tmp]='\0';

				CheckForCoordinateDuplication(&CoordinateStruct, "_Z", directory);

				SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT), WM_SETTEXT, 0, (LPARAM)CoordinateStruct.coordinate_file_name);

				sprintf(txt,"NA");
				SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);

				SetCursor(PrevCursor);
				EnableWindow(GetDlgItem(hwnd,ID_LOAD_ACTIVATIONS),TRUE);
			}
			break;



		case ID_TEST_CLUSTERZ:
			hourglass=LoadCursor(NULL,IDC_WAIT);
			PrevCursor=SetCursor(hourglass);

            EnableWindow(GetDlgItem(hwnd,ID_TEST_CLUSTERZ),FALSE);


			//GenerateGroupExperiments(&gImage);

			//RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0, &CoordinateStruct, 10.0);



			if (CoordinateStruct.TotalFoci>0)
			TestCBMANwithRandomCoordinates(GetParent(hwnd), &gImage, 0.05,
			                               &CoordinateStruct, 3, directory);


			///test networks
			//GenerateExperiments(&gImage);
			//GenerateGroupExperiments(&gImage);

			///Test the permutation doesnt change parameters other than rho?
			//TestNullDistribution(20, 30, 1.0, 0.5);
			//TestNullDistribution(20, 20, 1.0, 0.5);

			///test parameter estimation
			//TestFittingBivariateNorm(30);//20 and 50 used in paper
			//TestFittingBivariateNorm(50);
			//TestFittingBivariateNormGroups(20);
			//TestFittingBivariateNormGroups(50);

			EnableWindow(GetDlgItem(hwnd,ID_TEST_CLUSTERZ),TRUE);
			SetCursor(PrevCursor);
			break;



		case ID_CBMAN:
			if (CoordinateStruct.TotalFoci<=0)
			{
				MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
				break;
			}


			SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
			MarkerSize=atoi(txt);
			if (MarkerSize<0)
				MarkerSize=DEFAULT_MARKER_SIZE;


			SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
			pvalue=atof(txt);
			if (pvalue<=0.0)
			{
				MessageBox(NULL,"Please specify pvalue (>0.0)","",MB_OK|MB_ICONWARNING);
				break;
			}

			hourglass=LoadCursor(NULL,IDC_WAIT);
			PrevCursor=SetCursor(hourglass);


			EnableWindow(GetDlgItem(hwnd,ID_CBMAN),FALSE);
			CBMAN(GetParent(hwnd), &gImage, pvalue, &CoordinateStruct, 0, MarkerSize, directory);

			SetCursor(PrevCursor);
			SendMessage(hwnd, WM_CLOSE,0,0);
			break;


		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
			break;

		}
		break;
	}
	return 0;
}


//======================================================================================================
//======================================================================================================
int TestCBMANwithRandomCoordinates(HWND hwnd,
                                   struct Image *image,
                                   double critical,
                                   struct Coordinates *Co,
                                   int MarkerSize,
                                   char directory[])

{
    int Nfoci=(*Co).TotalFoci;
	int X, Y, Z;
	float dx, dy, dz;
	float x0,y0,z0;
	double p;
	int iter;
	int focus;
	FILE *fp;
	char fname[MAX_PATH];
	float xc[1000];
	float yc[1000];
	float zc[1000];
	char txt[256];

	sprintf(fname,"%s\\RandomTestCBMAN.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");
	if (fp)
		fclose(fp);

	X=(*image).X;
	Y=(*image).Y;
	Z=(*image).Z;
	dx=(*image).dx;
	dy=(*image).dy;
	dz=(*image).dz;
	x0=(*image).x0;
	y0=(*image).y0;
	z0=(*image).z0;

	for (iter=0; iter<100; iter++)
	{
		///****************************************************************************************************************
		RandomiseCoordinatesForTesting((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, Co, 10.0);
		///****************************************************************************************************************

		for (focus=0;focus<Nfoci;focus++)
        {
            (*Co).voxel[focus] = FociVoxelALE((*Co).x[focus], (*Co).y[focus], (*Co).z[focus], (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0);
        }

		p=CBMAN(hwnd,image,critical,Co,0,MarkerSize,directory);
		sprintf(txt,"%d %d",iter,GetClusters(image, Co, xc, yc, zc,4, 1, DONT_SAVE, directory));
		//MessageBox(NULL,txt,"",MB_OK);

		if ((fp=fopen(fname,"a")))
		{
			fprintf(fp,"%d,%f\n",iter,p);
			fclose(fp);
		}
	}

	return 1;
}
//======================================================================================================
//======================================================================================================
int PCoA(struct Coordinates *Co, int Nclusters);

double CBMAN(HWND hwnd,
             struct Image *image,
             double critical,
             struct Coordinates *Co,
             int CompareGroups,
             int MarkerSize,
             char directory[])
{
	double result=-1.0;
	int Nclusters;
	int Nfoci;
	int *valid=NULL;
	double *Aij=NULL;
	double *Pmat=NULL;
	double Pthreshold;
	float *xc=NULL;
	float *yc=NULL;
	float *zc=NULL;
	struct Coordinates CoCpy;
	char directoryCBMAN[MAX_PATH];

	sprintf(directoryCBMAN,"%s\\CBMAN",directory);
	CreateDirectory(directoryCBMAN, NULL);

	memset(&CoCpy,0,sizeof(struct Coordinates));

	///pre-process: merge studies and get Talairach labels
	if (!CopyCoordinates(Co, &CoCpy))
		goto END;
	if (!MergeCoordinatesbyStudy(&CoCpy))
		goto END;
	Nfoci=CoCpy.TotalFoci;
	CensorLevels(&CoCpy);

	GetTalairachLabels(&CoCpy);

	if (!(xc=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(yc=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(zc=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;


//RandomiseCoordinatesForTesting((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0, &CoCpy, 10.0);
	///===========FIND THE CLUSTERS GIVEN THE ClusteringDistance================
	//Nclusters=GetClusterCentres(image, &CoCpy, xc, yc, zc, MINIMUM_EXPERIMENTS, directoryCBMAN);
	Nclusters=GetClusters(image, &CoCpy, xc, yc, zc,MIN_VALID_POINTS, 1, SAVE, directoryCBMAN);
	//Nclusters=ClusterAllUsingMeanShift(image, &CoCpy, xc, yc, zc,  MINIMUM_EXPERIMENTS, directoryCBMAN);
	///==================================================================


	///allocate memory
	if (!(Aij=(double *)malloc(sizeof(double)*Nclusters*Nclusters)))
		goto END;
	if (!(Pmat=(double *)malloc(sizeof(double)*Nclusters*Nclusters)))
		goto END;
	if (!(valid=(int *)malloc(Nclusters*Nclusters*sizeof(int))))
		goto END;

	///get the correlations, and p-values
	FillEdgeMatrix(hwnd, &CoCpy, Nclusters, Aij, valid, Pmat, CompareGroups, directoryCBMAN, SAVE);

	///Save the results
	Pthreshold=SaveNetworkResults(image, hwnd, &CoCpy, Aij, Pmat, valid, Nclusters,
	                              xc, yc, zc, critical, directoryCBMAN, MarkerSize);

	result=Pthreshold;
END:
	FreeCoordinates(&CoCpy);
	if (Aij)
		free(Aij);
	if (Pmat)
		free(Pmat);
	if (valid)
		free(valid);
	if (xc)
		free(xc);
	if (yc)
		free(yc);
	if (zc)
		free(zc);

	return result;
}


//==========================================================================
double SaveNetworkResults(struct Image *image, HWND hwnd, struct Coordinates *Co, double Aij[], double Pmat[], int valid[], int Nclusters,
                          float xc[], float yc[], float zc[], double critical, char directoryCBMAN[], int MarkerSize)
{
	double Pthreshold;
	int i,j,k;
	int X, Y, Z;
	int Nvalid, Ntests;
	float dx, dy, dz;
	float x0,y0,z0;
	double expected;
	double *Pfdr=NULL;
	double *Pclust=NULL;
	int *sort=NULL;
	char fname[MAX_PATH];
	char fnameRGB[MAX_PATH];
	char fnameSignRGB[MAX_PATH];
	FILE *fp=NULL;

	X=(*image).X;
	Y=(*image).Y;
	Z=(*image).Z;
	dx=(*image).dx;
	dy=(*image).dy;
	dz=(*image).dz;
	x0=(*image).x0;
	y0=(*image).y0;
	z0=(*image).z0;

	if (!(Pfdr=(double *)malloc((Nclusters*Nclusters-Nclusters)*sizeof(double)/2)))
		goto END;
	if (!(sort=(int *)malloc((Nclusters*Nclusters-Nclusters)*sizeof(int)/2)))
		goto END;
	if (!(Pclust=(double *)malloc(sizeof(double)*Nclusters)))
		goto END;


	///set the coordinate p-values so the results are saved correctly
	SetValidCoordinatePvalues(Co, Pmat, Pclust, Nclusters, valid);

	///save the correlation matrix
	sprintf(fname,"%s\\correlation matrix.csv",directoryCBMAN);
	if ((fp=fopen(fname,"w")))
	{
		for (i=1; i<=Nclusters; i++)
		{
			for (j=1; j<=Nclusters; j++)
			{
				if (valid[ (i-1)*Nclusters + j-1 ])
					fprintf(fp,"%f,",Aij[(i-1)*Nclusters+j-1]);
				else
					fprintf(fp,"*,");
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}
	///save the valid edge matrix
	sprintf(fname,"%s\\ValidEdges.csv",directoryCBMAN);
	if ((fp=fopen(fname,"w")))
	{
		for (i=1; i<=Nclusters; i++)
		{
			for (j=1; j<=Nclusters; j++)
			{
				fprintf(fp,"%d,",valid[(i-1)*Nclusters + j-1]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}
	///save the edge p-values
	sprintf(fname,"%s\\EdgePvalues.csv",directoryCBMAN);
	if ((fp=fopen(fname,"w")))
	{
		for (i=1; i<=Nclusters; i++)
		{
			for (j=1; j<=Nclusters; j++)
			{
				fprintf(fp,"%f,",Pmat[(i-1)*Nclusters + j-1]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}

///collect p-values for FDR calculation
	///Count the number of tests
	Nvalid=0;
	Ntests=0;
	for (i=1; i<=Nclusters; i++)
	{
		for (j=i+1; j<=Nclusters; j++)
		{
			if (ToTest(Co, i,j))
				Ntests++;///get the number of connections
			if (valid[(i-1)*Nclusters + j-1])
			{
				Pfdr[Nvalid] = Pmat[(i-1)*Nclusters + j-1];
				Nvalid++;
			}
		}
	}


	if (Nvalid>0)
		Pthreshold = FDRext(critical, Pfdr, Nvalid, Ntests);
	else
		Pthreshold=0.0;

	///save the number of significant edges for a useful range of FDR
	QuickSort(Pfdr, sort, Nvalid);
	sprintf(fname,"%s\\FDR.csv",directoryCBMAN);
	if ((fp=fopen(fname,"w")))
	{
		fprintf(fp,"p,FDR,#edges\n");
		for (k=0; k<Nvalid && Pfdr[sort[k]]<0.1; k++)
		{
			expected=Pfdr[sort[k]]*Ntests;
			j=0;
			for (i=0; i<Nvalid; i++)
			{
				if (Pfdr[sort[i]]<=Pfdr[sort[k]])
					j++;
			}
			fprintf(fp,"%f,%f,%d\n",Pfdr[sort[k]], expected/j, j);

		}
		fclose(fp);
	}

	///save the bitmap of the network
	SaveTalairachNetworkProjection(hwnd, Co, Aij, Pmat, valid, Pthreshold, xc, yc, zc, Nclusters, directoryCBMAN);

	///binary connection matrix
	sprintf(fname,"%s\\Adjacency.txt",directoryCBMAN);
	if ((fp=fopen(fname,"w")))
	{
		for (i=1; i<=Nclusters; i++)
		{
			if (Pclust[i-1]<=Pthreshold)
				fprintf(fp,"%d ",i);
		}
		fprintf(fp,"\n");

		for (i=1; i<=Nclusters; i++)
		{
			if (Pclust[i-1]<=Pthreshold)
			{
				for (j=1; j<=Nclusters; j++)
				{
					if (Pclust[j-1]<=Pthreshold)
					{
						if ((i!=j) && Pmat[(i-1)*Nclusters + j-1]<=Pthreshold)
							fprintf(fp,"1 ");
						else
							fprintf(fp,"0 ");
					}
				}
				fprintf(fp,"\n");
			}
		}
		fclose(fp);
	}


	SaveiGraph(Nclusters, Pclust, Aij, Pmat, valid, Pthreshold, directoryCBMAN);



	sprintf(fname,"%s\\Full Network.nii",directoryCBMAN);
	sprintf(fnameRGB,"%s\\Significant NetworkRGB.nii",directoryCBMAN);
	sprintf(fnameSignRGB,"%s\\NetworkSign.nii",directoryCBMAN);
	SaveSignificantEffectClusters(Pthreshold, X, Y, Z, dx, dy, dz, x0, y0, z0,
	                              Co, fname, fnameRGB, fnameSignRGB,
	                              MarkerSize);



	ReportClustersCBMAN(hwnd, Co,
	                    directoryCBMAN, "\\ClustersReport.csv",
	                    X, Y, Z, z0,
	                    dx, dy, dz,
	                    Pthreshold,
	                    xc, yc, zc, Nclusters);

	SaveSignificantClusterDensity2(image, Co, Pthreshold, (*Co).Nexperiments, directoryCBMAN);
	SaveSignificantClusterMeanConnectivity(image, Co, Pthreshold, (*Co).Nexperiments, Aij, valid, xc, yc, zc, Nclusters, directoryCBMAN);


	//SaveCorrelationMatrixPlot(hwnd, Pclust, Aij, Pmat, Pthreshold, Nclusters, directoryCBMAN);
END:
	if (Pfdr)
		free(Pfdr);
	if (sort)
		free(sort);
	if (Pclust)
		free(Pclust);

	return Pthreshold;
}


//==========================================================================
int PCoA(struct Coordinates *Co, int Nclusters)
{
	int study,study2, cl;
	int focus;
	int *studyclust=NULL;//study x Nclusters matrix
	double *sim=NULL;//similarity matrix
	FILE *fp;

	if (!(studyclust=(int *)calloc((*Co).Nexperiments*Nclusters,sizeof(int))))
		goto END;
	if (!(sim=(double *)calloc((*Co).Nexperiments*(*Co).Nexperiments,sizeof(double))))
		goto END;

	for (focus=0; focus<(*Co).TotalFoci; focus++)
	{
		study=(*Co).experiment[focus];
		cl=(*Co).cluster[focus];

		if (cl<=Nclusters)
			studyclust[study*Nclusters + cl-1]=1;
	}

	for (study2=0; study2<(*Co).Nexperiments; study2++)
	{
		for (study=study2+1; study<(*Co).Nexperiments; study++)
		{
			for (cl=0; cl<Nclusters; cl++)
			{
				sim[study*(*Co).Nexperiments + study2]+=(double)studyclust[study*Nclusters + cl]*studyclust[study2*Nclusters+cl];
				sim[study2*(*Co).Nexperiments + study]+=sim[study*(*Co).Nexperiments + study2];
			}
		}
	}
	for (study2=0; study2<(*Co).Nexperiments; study2++)
	{
		for (study=0; study<(*Co).Nexperiments; study++)
		{
			if (study!=study2)
			{
				sim[study*(*Co).Nexperiments+study2]=1.0/(1.0+sim[study*(*Co).Nexperiments+study2]);
				sim[study2*(*Co).Nexperiments + study]=sim[study*(*Co).Nexperiments + study2];
			}
		}
	}

	if ((fp=fopen("c:\\temp\\PCoA.R","w")))
	{
		fprintf(fp,"pcoa<-matrix(c(");


		for (study2=0; study2<(*Co).Nexperiments; study2++)
		{
			if (!study2)
				fprintf(fp,"%5.4f",sim[study2*(*Co).Nexperiments]);
			else
				fprintf(fp,",%5.4f",sim[study2*(*Co).Nexperiments]);
			for (study=1; study<(*Co).Nexperiments; study++)
			{
				fprintf(fp,",%5.4f",sim[study2*(*Co).Nexperiments + study]);
			}
			fprintf(fp,"\n");
		}
		fprintf(fp,"),nrow=%d,ncol=%d)\n",(*Co).Nexperiments,(*Co).Nexperiments);

		fprintf(fp,"loc <- cmdscale(pcoa)\n");
		fprintf(fp,"x <- loc[, 1]\n");
		fprintf(fp,"y <- -loc[, 2]\n");

		fprintf(fp,"rownames(loc)<-seq(from=0,to=%d,by=1)\n",(*Co).Nexperiments-1);
		fprintf(fp,"plot(x, y, type=\"n\")\n");
		fprintf(fp,"text(x, y, rownames(loc), cex = 1)\n");

		fclose(fp);
	}

END:
	if (studyclust)
		free(studyclust);
	if (sim)
		free(sim);

	return 1;
}

//==========================================================================
//==========================================================================
int ToTest(struct Coordinates *Co, int CL1, int CL2)
{
	int count;
	char *c1=NULL;
	char *c2=NULL;
	int study;
	int Nstudies=(*Co).Nexperiments;
	int focus;
	int Nfoci=(*Co).TotalFoci;

	if (!(c1=(char *)calloc(Nstudies,1)))
		goto END;
	if (!(c2=(char *)calloc(Nstudies,1)))
		goto END;

	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*Co).cluster[focus]==CL1)
			c1[(*Co).experiment[focus]]=1;
		if ((*Co).cluster[focus]==CL2)
			c2[(*Co).experiment[focus]]=1;
	}
	count=0;
	for (study=0; study<Nstudies; study++)
	{
		if (c1[study] && c2[study])
		{
			count++;
			if (count>=2)
				goto END;
		}
	}

END:
	if (c1)
		free(c1);
	if (c2)
		free(c2);
	if (count>=2)
		return 1;
	else
		return 0;
}


//======================================================================================================
//is a BivariateSample valid?
//valid where two clusters have at least N uncensored contributing studies in common
//if this were only two, with all others having some censoring, then might get high correlation
//Correlation is perfect between two points!
//======================================================================================================
int IsBVvalid(struct BivariateSample *BV, int CompareGroups)
{
	int counter=0;
	int counter2=0;
	int sample;

		for (sample=0; sample<(*BV).Samples; sample++)
		{

			if ((!(*BV).censor1[sample]) && (!(*BV).censor2[sample]))
            {
                if (!(*BV).covariate[sample]) counter++;
                else counter2++;
            }

		}
		if (!CompareGroups)
        {
                if ((counter+counter2)<MIN_VALID_POINTS) return 0;
        }
		else
        {
               if (counter<MIN_VALID_POINTS || counter2<MIN_VALID_POINTS) return 0;
        }

	return 1;
}


//======================================================================================================
//======================================================================================================
int SetValidCoordinatePvalues(struct Coordinates *Co, double Pmat[], double Pclust[], int Nclusters, int valid[])
{
	int cl1,cl2;
	int focus;
	int TotalFoci=(*Co).TotalFoci;
	double p;
	double minP;

	//initialise p values to something known and not significant
	for (focus=0; focus<TotalFoci; focus++)
		(*Co).p[focus]=1.0;

	for (cl1=1; cl1<=Nclusters; cl1++)
	{
		minP=1.0;
		for (cl2=1; cl2<=Nclusters; cl2++)
		{
			p=Pmat[(cl1-1)*Nclusters + cl2-1];
			if ((valid[(cl1-1)*Nclusters + cl2-1]) && (cl1!=cl2) && (p<minP) )
				minP=p;
		}
		for (focus=0; focus<TotalFoci; focus++)
		{
			if ((*Co).cluster[focus]==cl1)
				(*Co).p[focus]=minP;
		}
		Pclust[cl1-1]=minP;
	}

	return 1;
}

//======================================================================================================
//SAVE DATA FOR A FOREST PLOT FOR CBMAN
/*

struct BivariateSample {
	short int Samples;
	double *d1;//effect sizes of sample 1
	double *d2;//effect sizes of sample 2
	double *V;//The within study variance 1/N.
	double *CensorLevel;//This is normalised absolute value and could be the minimum magnitude Z from a study, or a reported threshold, or other...
	short int *censor1;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
	short int *censor2;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
	double *LogLike;
	double p;//the p value
	double mean1;//bivariate parameters:
	double mean2;
	double var1;
	double var2;
	double rho;
	double mean12;
	double mean22;//parameters for group comparisons
	double rho2;
	float *covariate;
	};
*/
//======================================================================================================
int ForestPlotRCBMAN(struct Coordinates *c, struct BivariateSample *BV, int cluster1, char directory[])
{
	char fname[MAX_PATH];
	int result=0;
	int study;
	int NotVOIcensored;
	float Min,Max;
	float MaxLength;
	double SampleSD;
	FILE *fp;

	sprintf(fname,"%s\\Forest_%d.R",directory,cluster1);
	if (!(fp=fopen(fname,"w")))
		goto END;

	//margins
	MaxLength=0.0;
	for (study=0; study<(*c).Nexperiments; study++)
		if (strlen((*c).ID[study].txt)>(int)MaxLength)
		{
			MaxLength=(float)strlen((*c).ID[study].txt);
		}
	fprintf(fp,"#CBMAN Forest plot produced by %s\n",(*c).coordinate_file_name);
	fprintf(fp,"#Alter font size and main title scale here\n");
	fprintf(fp,"ForestFontsize = 10\n");
	fprintf(fp,"ForestMainScale = 1.3\n");
	fprintf(fp,"par(ps=ForestFontsize, cex.main=ForestMainScale, mar=c(4.5, %f, 2, 1))\n",MaxLength/1.5);

	//x axis
	Min=1000.0;
	Max=-1000.0;
	fprintf(fp,"x=c(");
	for (study=0; study<(*c).Nexperiments; study++)
	{
		SampleSD=sqrt((*BV).V[study]);

		switch((*BV).censor1[study])
		{
		case NOT_CENSORED:
		case INTERVAL_CENSORED:
			if ((!study))
				fprintf(fp,"%f",(*BV).d1[study]);
			else
				fprintf(fp,",%f",(*BV).d1[study]);
			break;
		case LEFT_CENSORED:
			if (!study)
				fprintf(fp,"%f",-(*BV).CensorLevel[study]);
			else
				fprintf(fp,",%f",-(*BV).CensorLevel[study]);
			break;
		case RIGHT_CENSORED:
			if (!study)
				fprintf(fp,"%f",(*BV).CensorLevel[study]);
			else
				fprintf(fp,",%f",(*BV).CensorLevel[study]);
			break;
		}


		if ((*BV).d1[study]+1.96*SampleSD>Max)
			Max=(*BV).d1[study]+1.96*SampleSD;
		if ((*BV).d1[study]-1.96*SampleSD<Min)
			Min=(*BV).d1[study]-1.96*SampleSD;

	}
	fprintf(fp,")\n");


	//y axis
	NotVOIcensored=0;
	fprintf(fp,"y=c(");
	for (study=1; study<=(*c).Nexperiments; study++)
	{
		if ((*BV).censor1[study]!=VOI_CENSORED)
		{
			NotVOIcensored++;
			if (NotVOIcensored>1)
				fprintf(fp,",");
			fprintf(fp,"%d",NotVOIcensored);
		}
	}
	fprintf(fp,")\n");

	//plot
	fprintf(fp,"plot(x,y,xlab=\"Effect Size\",ylab=\"\",axes=FALSE,xlim=c(%f,%f),pch=c(",Min,Max);
	for (study=0; study<=(*c).Nexperiments; study++)
	{
		if ((*BV).censor1[study]!=VOI_CENSORED)
		{
			if (study>0)
				fprintf(fp,",");
			fprintf(fp,"%d",fabs((*BV).d1[study])>0.0 ? 20:1);
		}
	}
	fprintf(fp,"))\n");


	//y axis labels
	NotVOIcensored=0;
	for (study=0; study<(*c).Nexperiments; study++)
		if ((*BV).censor1[study]!=VOI_CENSORED)
		{
			NotVOIcensored++;
		}
	fprintf(fp,"axis(2,1:%d,c(",NotVOIcensored);
	for (study=0; study<(*c).Nexperiments; study++)
	{
		if ((*BV).censor1[study]!=VOI_CENSORED)
		{
			if (study>0)
				fprintf(fp,",");
			fprintf(fp,"\"%s\"",(*c).ID[study].txt);
		}

	}
	fprintf(fp,"),col=NA,las=1)\n");


	//x axis labels
	fprintf(fp,"axis(1, seq(%d,%f,0.1))\n",(int)(Min-0.5),Max);

	//main title
	fprintf(fp,"#########CHANGE PLOT TITLE HERE#########\n");
	fprintf(fp,"title(main=\"CBMAN\")\n");

	//error bars
	NotVOIcensored=0;
	for (study=0; study<(*c).Nexperiments; study++)
	{
		if ((*BV).censor1[study]!=VOI_CENSORED)
			NotVOIcensored++;
		switch((*BV).censor1[study])
		{
		case NOT_CENSORED:
			if ((*BV).censor1[study]==NOT_CENSORED)
				fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=1, lwd=2,col=\"black\")\n",(*BV).d1[study]-1.96*SampleSD,
				        (*BV).d1[study]+1.96*SampleSD, NotVOIcensored,NotVOIcensored);
			break;
		case INTERVAL_CENSORED:
			fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2,col=\"black\")\n",-(*BV).CensorLevel[study],
			        (*BV).CensorLevel[study], NotVOIcensored,NotVOIcensored);
			break;
		case LEFT_CENSORED:
			fprintf(fp,"lines(c(%d,%f),c(%d,%d),lty=3, lwd=2,col=\"black\")\n",(int)(Min-0.5),-(*BV).CensorLevel[study], NotVOIcensored,NotVOIcensored);
			break;
		case RIGHT_CENSORED:
			fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2,col=\"black\")\n",(*BV).CensorLevel[study],Max, NotVOIcensored,NotVOIcensored);
			break;
		}
	}


	fclose(fp);

	result=1;
END:

	return result;
}


//======================================================================================================
//======================================================================================================
int FillEdgeMatrix(HWND hwnd, struct Coordinates *Co,
                   int Nclusters,
                   double Edges[],
                   int valid[],
                   double pvalue[],
                   int CompareGroups,
                   char directory[],
                   int save)
{
	struct BivariateSample BV;
	int cl1,cl2;
	int result=0;
	double correlation;
	double p;
	HDC hDC=GetDC(hwnd);
	char txt[256];

	memset(&BV,0,sizeof(struct BivariateSample));
	memset(valid,0,sizeof(int)*Nclusters*Nclusters);

	//make struct BivariateSample
	if (!MakeStructBivariateSample(&BV, (*Co).Nexperiments))
		goto END;

	for (cl1=1; cl1<=Nclusters; cl1++)
	{

		Edges[(cl1-1)*Nclusters + (cl1-1)]=1.0;
		pvalue[(cl1-1)*Nclusters + (cl1-1)]=1.0;
		valid[(cl1-1)*Nclusters + (cl1-1)]=0;

		for (cl2=cl1+1; cl2<=Nclusters; cl2++)
		{
			if (EscapePressed(hwnd))
				goto END;
			RemoveInput(hwnd);

			sprintf(txt,"Clusters   %d & %d     ",cl1,cl2);
			TextOut(hDC,100,100,txt,strlen(txt));
			UpdateWindow(hwnd);

			if (!FillBivariateSampleStructure(&BV, Co, cl1, cl2, directory, save))
				goto END;

			valid[(cl1-1) + (cl2-1)*Nclusters]=IsBVvalid(&BV, CompareGroups);
			valid[(cl2-1) + (cl1-1)*Nclusters]=valid[(cl1-1) + (cl2-1)*Nclusters];

			if ( valid[(cl1-1) + (cl2-1)*Nclusters] )
			{
				if (!CompareGroups)
				{
					MaximumLogLikelihood(Co, &BV, cl1, cl2, directory);
					correlation=BV.rho;//single study
				}
				else//This is for comparing groups
				{
					MaximumLogLikelihoodGroup(Co, &BV, cl1, cl2, directory);
					correlation=BV.rho-BV.rho2;//single study
				}
				p=BV.p;
			}
			else
			{
				correlation=0.0;
				p=1.0;
			}

			//use symmetry
			Edges[(cl1-1) + (cl2-1)*Nclusters] = correlation;
			Edges[(cl2-1) + (cl1-1)*Nclusters] = correlation;

			pvalue[(cl1-1) + (cl2-1)*Nclusters] = p;
			pvalue[(cl2-1) + (cl1-1)*Nclusters] = p;
		}
		//ForestPlotRCBMAN(Co, &BV, cl1, directory);
	}

	result=1;
END:

	//Free Bivariate Sample
	FreeStructBivariateSample(&BV);
	ReleaseDC(hwnd, hDC);


	return result;
}



//======================================================================================================
/*
struct BivariateSample
{
    short int Samples;
    double *d1;//effect sizes of sample 1
    double *d2;//effect sizes of sample 2
    double *V1;//The within study variance 1/N.
    double *V2;//The within study variance 1/N.
    double *CensorLevel;//This is normalised absolute value and could be the minimum magnitude Z from a study, or a reported threshold, or other...
    short int *censor1;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
    short int *censor2;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
    double *LogLike;
    double p;//the p value
    double mean1;//bivariate parameters:
    double mean2;
    double var1;
    double var2;
    double rho;
    double mean12;
    double mean22;//parameters for group comparisons
    double rho2;
    float *covariate;
};
*/
//========================================s==============================================================
int MakeStructBivariateSample(struct BivariateSample *BV, int samples)
{
	int result=0;

	memset(BV,0,sizeof(struct BivariateSample));

	if (!((*BV).d1=(double *)calloc(samples,sizeof(double))))
		goto END;
	if (!((*BV).d2=(double *)calloc(samples,sizeof(double))))
		goto END;
	if (!((*BV).V=(double *)calloc(samples,sizeof(double))))
		goto END;
	if (!((*BV).CensorLevel=(double *)calloc(samples,sizeof(double))))
		goto END;
	if (!((*BV).LogLike=(double *)calloc(samples,sizeof(double))))
		goto END;
	if (!((*BV).censor1=(short int *)calloc(samples,sizeof(short int))))
		goto END;
	if (!((*BV).censor2=(short int *)calloc(samples,sizeof(short int))))
		goto END;
	if (!((*BV).covariate=(float *)calloc(samples,sizeof(float))))
		goto END;

	(*BV).Samples=samples;

	result=1;
END:

	return result;
}


//======================================================================================================
//======================================================================================================
int FreeStructBivariateSample(struct BivariateSample *BV)
{
	if ((*BV).d1)
		free((*BV).d1);
	if ((*BV).d2)
		free((*BV).d2);
	if ((*BV).V)
		free((*BV).V);
	if ((*BV).CensorLevel)
		free((*BV).CensorLevel);
	if ((*BV).LogLike)
		free((*BV).LogLike);
	if ((*BV).censor1)
		free((*BV).censor1);
	if ((*BV).censor2)
		free((*BV).censor2);
	if ((*BV).covariate)
		free((*BV).covariate);

	memset(BV,0,sizeof(struct BivariateSample));
	return 0;
}


//======================================================================================================
//fill the bivariate sample structure given two coordinate clusters
/*
#define NOT_CENSORED 0
#define LEFT_CENSORED 1
#define RIGHT_CENSORED 2
#define INTERVAL_CENSORED 3*/
//======================================================================================================
int FillBivariateSampleStructure(struct BivariateSample *BV,
                                 struct Coordinates *Co,
                                 int cl1, int cl2,
                                 char directory[], int save)
{
	int study;
	int coordinate;
	int contrast=IsContrastStudy(Co);
	int sss,ssc;
	int nCL1;
	int nCL2;
	struct TextLabel censortxt[4];
	FILE *fp=NULL;
	char fname[MAX_PATH];

	sprintf(censortxt[0].txt,"NOT_CENSORED");
	sprintf(censortxt[1].txt,"LEFT_CENSORED");
	sprintf(censortxt[2].txt,"RIGHT_CENSORED");
	sprintf(censortxt[3].txt,"INTERVAL_CENSORED");

	for (study=0; study<(*Co).Nexperiments; study++)
	{
		nCL1=nCL2=0;
		sss=(*Co).SubjectsInExp[study];///subject numbers determine variance
		ssc=(*Co).ControlsInExp[study];
		(*BV).censor1[study]=(*BV).censor2[study]=NOT_CENSORED;///by default assume not censored

		(*BV).d1[study] = (*BV).d2[study] = 0.0;///default effect size 0

		///check the number of controls is appropriate for contrast studies
		if (!contrast)
			ssc=0;//there is no second study group
		else if (!(*Co).ControlsInExp[study])
			return 0;

		(*BV).CensorLevel[study] = EffectSize((*Co).Zcensor[study], sss, ssc, 0);

		for (coordinate=0; coordinate<(*Co).TotalFoci; coordinate++)
		{
			if ((*Co).experiment[coordinate] == study)
			{
				if ((*Co).cluster[coordinate] == cl1)   ///CLUSTER CL1
				{
					if ((*Co).Zsc[coordinate]==1.0)
						(*BV).censor1[study]=RIGHT_CENSORED;
					else if ((*Co).Zsc[coordinate]==-1.0)
						(*BV).censor1[study]=LEFT_CENSORED;
					else
					{
						(*BV).d1[study]+=EffectSize((*Co).Zsc[coordinate],sss,ssc,0);
						nCL1++;
					}
				}
				if ((*Co).cluster[coordinate] == cl2)   ///CLUSTER CL2
				{
					if ((*Co).Zsc[coordinate]==1.0)
						(*BV).censor2[study]=RIGHT_CENSORED;
					else if ((*Co).Zsc[coordinate]==-1.0)
						(*BV).censor2[study]=LEFT_CENSORED;
					else
					{
						(*BV).d2[study]+=EffectSize((*Co).Zsc[coordinate],sss,ssc,0);
						nCL2++;
					}
				}
			}//study
		}//coordinate

		if (nCL1)
			(*BV).d1[study]/=nCL1;
		if (nCL2)
			(*BV).d2[study]/=nCL2;

		if ( ((*BV).d1[study]==0.0) && (!(*BV).censor1[study]) )
		{
			(*BV).censor1[study]=INTERVAL_CENSORED;
			if ((*Co).VOI[study])
				(*BV).censor1[study] = VOI_CENSORED;
		}

		if ( ((*BV).d2[study]==0.0) && (!(*BV).censor2[study]) )
		{
			(*BV).censor2[study]=INTERVAL_CENSORED;
			if ((*Co).VOI[study])
				(*BV).censor2[study] = VOI_CENSORED;
		}


		(*BV).V[study] = pow(WithinStudyStandardDeviation(sss, ssc, 0),2);

		(*BV).covariate[study]=(*Co).covariate[study];///this is where the group indicator is stored
	}
	(*BV).Samples=(*Co).Nexperiments;


	if (save==SAVE /*&& IsBVvalid(BV,CompareGroups)*/)
	{
		sprintf(fname,"%s\\BVstruct %d %d.csv",directory,cl1,cl2);
		if ((fp=fopen(fname,"w")))
		{
			fprintf(fp,"StudyID,ES1,ES2,censorES,censoring1,censoring2,covariate\n");
			for (study=0; study<(*Co).Nexperiments; study++)
			{
				fprintf(fp,"%s,%f,%f,%f,%s,%s,%f\n",(*Co).ID[study].txt,
				        (*BV).d1[study],
				        (*BV).d2[study],
				        (*BV).CensorLevel[study],
				        censortxt[(*BV).censor1[study]].txt, censortxt[(*BV).censor2[study]].txt,
				        (*BV).covariate[study]);
			}
			fclose(fp);
		}
	}

	return 1;
}


//======================================================================================================
//compute the negative log likelihood of bivariate normal parameters given the censored data
//The log likelihood is to be maximised, so negative log likelihood is to be minimised
//There are three types of censor: (1) Not censored; N, (2)interval;I, (3)Left or Right; LR
//There are 9 combinations of these to consider: (N,N) (N,I) (N,LR) (I,N) (I,I), (I,LR) (LR,N) (LR,I) (LR,LR)
///HOWEVER, some of these combinations are impossible; LR cannot be combined with anything except LR for example
///because LR only occurs if the study does not report effect sizes
///THEREFORE, (N, LR), (LR, N) are not possible because they imply reported effect sizes
///and unreported effect sizes from the same study
/*
struct BVNintegration
{
    double mx;
    double my;
    double vx;
    double vy;
    double rho;
    double CensorLevel;
    int CensorType;
};
*/
//======================================================================================================
double IntegrateBVNalongXgivenY(double y, double CensorLevel, int CensorType, double mx, double my, double Vx, double Vy, double rho);
double IntegrateBVNalongYgivenX(double x, double CensorLevel, int CensorType, double mx, double my, double Vx, double Vy, double rho);
///two distributions
double NegativeBVNloglikelihood(double P[], int Nparameters, void *BVN)
{
	struct BivariateSample *BV=(struct BivariateSample *)BVN;
	struct BVNintegration BVI;
	double l,Ll=0.0;
	double x,y;
	double meanx,meany;
	double rho;
	int sample;

	memset(&BVI,0,sizeof(struct BVNintegration));

	///the random variance
	if ( P[VARX]<=0.0 || P[VARY]<=0.0 )
		return 10000.0;

	for (sample=0; sample<(*BV).Samples; sample++)
	{


		meanx=P[MEANX];
		meany=P[MEANY];
		rho=Sigmoidpm1(P[RHO]);

		//exchange RHO for group 2 if comparing
		if (Nparameters==CBMAN_PARAMETERS_GROUPS && (*BV).covariate[sample])
		{
			rho=Sigmoidpm1(P[RHO2]);
		}

		if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)   /// (N,N)
		{
			l=BivariateNormal((*BV).d1[sample], (*BV).d2[sample], meanx, meany, P[VARX], P[VARY], rho);
		}
		else if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==INTERVAL_CENSORED)   /// (N, I)
		{
			x=(*BV).d1[sample];
			l=IntegrateBVNalongYgivenX(x, (*BV).CensorLevel[sample], INTERVAL_CENSORED, meanx, meany, P[VARX], P[VARY], rho);
		}
		else if ((*BV).censor1[sample]==INTERVAL_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)   /// (I, N)
		{
			y=(*BV).d2[sample];
			l=IntegrateBVNalongXgivenY(y, (*BV).CensorLevel[sample], INTERVAL_CENSORED, meanx, meany, P[VARX], P[VARY], rho);
		}
		else if ((*BV).censor1[sample]==INTERVAL_CENSORED && (*BV).censor2[sample]==INTERVAL_CENSORED)   /// (I,I)
		{
			BVI.CensorType=INTERVAL_CENSORED;
			BVI.CensorLevel=(*BV).CensorLevel[sample];
			BVI.mx=meanx;
			BVI.my=meany;
			BVI.vx=P[VARX];
			BVI.vy=P[VARY];
			BVI.rho=rho;
			l=Integrate(-BVI.CensorLevel, BVI.CensorLevel, MAX_INTEGRATION_POINTS, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);
		}
		else if ((*BV).censor1[sample]==LEFT_CENSORED || (*BV).censor1[sample]==RIGHT_CENSORED)   ///
		{
			if ((*BV).censor2[sample]==INTERVAL_CENSORED)   /// (LR, I)
			{
				BVI.CensorType=(*BV).censor1[sample];
				BVI.CensorLevel=(*BV).CensorLevel[sample];
				BVI.mx=meanx;
				BVI.my=meany;
				BVI.vx=P[VARX];
				BVI.vy=P[VARY];
				BVI.rho=rho;
				l=Integrate(-BVI.CensorLevel, BVI.CensorLevel, MAX_INTEGRATION_POINTS, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);
			}
			else if ((*BV).censor2[sample]==LEFT_CENSORED)   /// (LR, L)
			{
				BVI.CensorType=(*BV).censor1[sample];
				BVI.CensorLevel=(*BV).CensorLevel[sample];
				BVI.mx=meanx;
				BVI.my=meany;
				BVI.vx=P[VARX];
				BVI.vy=P[VARY];
				BVI.rho=rho;
				l=Integrate(-5.0-BVI.CensorLevel, -BVI.CensorLevel, MAX_INTEGRATION_POINTS, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);
			}
			else if ((*BV).censor2[sample]==RIGHT_CENSORED)   /// (LR, R)
			{
				BVI.CensorType=(*BV).censor1[sample];
				BVI.CensorLevel=(*BV).CensorLevel[sample];
				BVI.mx=meanx;
				BVI.my=meany;
				BVI.vx=P[VARX];
				BVI.vy=P[VARY];
				BVI.rho=rho;
				l=Integrate(BVI.CensorLevel, 5.0+BVI.CensorLevel, MAX_INTEGRATION_POINTS, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);
			}
		}
		else if ((*BV).censor2[sample]==LEFT_CENSORED || (*BV).censor2[sample]==RIGHT_CENSORED)   /// (I, LR); cant be (N, LR) or (LR,LR) because these are done above
		{
			BVI.CensorType=(*BV).censor2[sample];
			BVI.CensorLevel=(*BV).CensorLevel[sample];
			BVI.mx=meany;
			BVI.my=meanx;
			BVI.vx=P[VARY];
			BVI.vy=P[VARX];
			BVI.rho=rho;
			l=Integrate(-BVI.CensorLevel, BVI.CensorLevel, MAX_INTEGRATION_POINTS, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);
		}
		else if ((*BV).censor2[sample]==VOI_CENSORED || (*BV).censor2[sample]==VOI_CENSORED)
			l=1.0;///doesn't add anything to the log likelihood


		if (l>DBL_MIN)
			l= log(l);
		else
			l=log(DBL_MIN);

		Ll+=l;
		(*BV).LogLike[sample]=l;
	}//sample

	return -Ll;
}
//=====================================================================================================================
//=====================================================================================================================
double IntegrateBVNalongYgivenX(double x, double CensorLevel, int CensorType,
                                double mx, double my, double Vx, double Vy, double rho)
{
	return IntegrateBVNalongXgivenY(x, CensorLevel, CensorType, my, mx, Vy, Vx, rho);
}
//=====================================================================================================================
//CENSOR TYPE CAN ONLY BE INTERVAL, LEFT, OR RIGHT
//=====================================================================================================================
double IntegrateBVNalongXgivenY(double y, double CensorLevel, int CensorType,
                                double mx, double my, double Vx, double Vy, double rho)
{
	double I=0.0;
	double mnx,vnx, a;
	double sigmax;

	if (!BivariateNormXgivenY(y, mx, my, Vx, Vy, rho, &mnx, &vnx, &a))
		return 0.0;

	sigmax=sqrt(vnx);

	switch (CensorType)
	{
	case INTERVAL_CENSORED:
		I=a*(NormalCDF(CensorLevel, mnx, sigmax) - NormalCDF(-CensorLevel, mnx, sigmax));
		break;
	case LEFT_CENSORED:
		I=a*NormalCDF(-CensorLevel, mnx, sigmax);
		break;
	case RIGHT_CENSORED:
		I=a*(1.0-NormalCDF(CensorLevel, mnx, sigmax));
		break;
	}

	return I;
}
//=====================================================================================================================
//wrapper for integration function
//=====================================================================================================================
double IntegrateBVNwrapper(double y, void *BVN)
{
	struct BVNintegration *BVI=(struct BVNintegration *)BVN;
	return IntegrateBVNalongXgivenY(y,
	                                (*BVI).CensorLevel,
	                                (*BVI).CensorType,
	                                (*BVI).mx, (*BVI).my,
	                                (*BVI).vx, (*BVI).vy,
	                                (*BVI).rho);
}


//=====================================================================================================================
int TestBivariateNormalIntegration(void)
{
	double mx,my,sx,sy,rho;
	double l,m;
	struct BVNintegration BVI;
	char txt[256];

	memset(&BVI,0,sizeof(struct BVNintegration));

	mx=1.0;
	my=-1.0;
	sx=1.0;
	sy=1.5;
	rho=-0.8;

	BVI.CensorType=INTERVAL_CENSORED;

	BVI.mx=mx;
	BVI.my=my;
	BVI.vx=sx*sx;
	BVI.vy=sy*sy;
	BVI.rho=rho;
	BVI.CensorLevel=0.3;
	l=Integrate(-5.0, 5.0, 100, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);

	//now transpose to check getting the same answer
	BVI.mx=my;
	BVI.my=mx;
	BVI.vx=sy*sy;
	BVI.vy=sx*sx;
	BVI.CensorLevel=5.0;
	m=Integrate(-0.3, 0.3, 100, INTEGRATION_ERROR, IntegrateBVNwrapper, &BVI);

	sprintf(txt,"%f %f",l,m);
	MessageBox(NULL,txt,"",MB_OK);

	return 0;
}



//=====================================================================================================================
//find the maximum likelihood of bivariate normal fit
//=====================================================================================================================
double EstimateRho(double P[], struct BivariateSample *BV);
double MaximumLogLikelihood(struct Coordinates *Co,
                            struct BivariateSample *BV,
                            int cluster1, int cluster2,
                            char directory[])
{
	double P[CBMAN_PARAMETERS];//maximum number of parameters
	double Lla;
	double pvalue=1.0;
	double rho;
	double L;
	FILE *fp=NULL;
	char fname[MAX_PATH];

	rho=0.0;//default

	sprintf(fname,"%s\\ConnectionDetails.txt",directory);

	memset(P,0,sizeof(double)*CBMAN_PARAMETERS);


	///Estimate parameters using least squares

	GetInitialEstimates(P, BV);
	Lla=MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, BV);
	do
	{
		L=Lla;
		Lla=MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, BV);
	}
	while (Lla-L>0.001);

	rho=Sigmoidpm1(P[RHO]);
	pvalue = PvalueOfConnectionUsingPermutation(P, BV, CBMAN_PERMUTATIONS,7);

	if ((fp=fopen(fname,"a")))
	{
		fprintf(fp,"Clusters: %d %d\nLog Likelihood: %f\nMeans: %f %f \nVars: %f %f \nRHO: %f \npvalue: %f\n\n\n",
		        cluster1,cluster2,
		        Lla,
		        P[MEANX],P[MEANY],
		        P[VARX],P[VARY],
		        rho,
		        pvalue);
		fclose(fp);
	}

	///store the parameter estimates under the alternative
	(*BV).mean1 =   P[MEANX];
	(*BV).mean2 =   P[MEANY];
	(*BV).var1 =    P[VARX];
	(*BV).var2 =    P[VARY];
	(*BV).rho =     rho;
	(*BV).p = pvalue;

	return Lla;
}


//=======================================================================================================================
//=======================================================================================================================
double MaximumLogLikelihoodGroup(struct Coordinates *Co,
                                 struct BivariateSample *BV,
                                 int cluster1, int cluster2,
                                 char directory[])
{
	double P[CBMAN_PARAMETERS_GROUPS];//maximum number of parameters
	double Ll0,Lla;
	double pvalue=1.0;
	double rho,rho2;
	double L;
	double D;
	FILE *fp=NULL;
	char fname[MAX_PATH];

	rho=rho2=0.0;//default

	sprintf(fname,"%s\\ConnectionDetailsCompare.txt",directory);

	memset(P,0,sizeof(double)*CBMAN_PARAMETERS_GROUPS);


	///Estimate parameters using least squares
	GetInitialEstimates(P, BV);

	Ll0=MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, BV);
	do
	{
		L=Ll0;
		Ll0=MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, BV);
	}
	while (Ll0-L>0.0001);



	//Set the initial RHO & RHO2 parameters to be equal
	P[RHO2] = P[RHO];

	//get the estimates for the alternative
	Lla=MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS_GROUPS, BV);

	rho=Sigmoidpm1(P[RHO]);
	rho2=Sigmoidpm1(P[RHO2]);

	//Likelihood Ratio Test
	D = 2.0*(Lla - Ll0);
	if ( (!isinf(Lla)) && (!isinf(Ll0))  )
	{
		pvalue = ChiSquaredPvalue(1.0, D);
	}
	else
	{
		if (isinf(Ll0))
			pvalue = 0.0;
	}



	if ((fp=fopen(fname,"a")))
	{
		fprintf(fp,"Clusters: %d %d\nLog Likelihood: %f\nMeans: %f %f \nVars: %f %f \nRHO: %f %f\npvalue: %f\n\n\n",
		        cluster1,cluster2,
		        Lla,
		        P[MEANX],P[MEANY],
		        P[VARX],P[VARY],
		        rho,rho2,
		        pvalue);
		fclose(fp);
	}

	///store the parameter estimates under the alternative
	(*BV).mean1 =   P[MEANX];
	(*BV).mean2 =   P[MEANY];
	(*BV).var1 =    P[VARX];
	(*BV).var2 =    P[VARY];
	(*BV).rho =       rho;
	(*BV).rho2 =     rho2;
	(*BV).p = pvalue;

	return Lla;
}

//=======================================================================================================================
//=======================================================================================================================
//=======================================================================================================================
double PvalueOfConnectionUsingAllPermutations(double P[], struct BivariateSample *BV, int SamplesToPermute)
{
	int C[7]= {0,0,0,0,0,0,0};
	int i,j;
	int sample;
	double *Rho=NULL;//only need 5040 (7!) for 7 samples
	int Npermutations;
	int permuted;
	double pvalue=1;
	int permute[7]= {0,1,2,3,4,5,6};
	int permutation;
	double d[7];



	if (!(Rho=(double *)malloc(5050*sizeof(double))))
		goto END;

	j=0;
	for (sample=0; sample<(*BV).Samples; sample++)
	{
		if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)
		{
			d[j]=(*BV).d2[sample];
			j++;
		}
	}

	Rho[0]=Sigmoidpm1(P[RHO]);
	i=0;
	Npermutations=1;
	while((permuted=PermutationList(SamplesToPermute, permute, &C[i], &i))>=0)
	{
		if (permuted==1)
		{
			j=0;
			for (sample=0; sample<(*BV).Samples; sample++)
			{
				if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)
				{
					(*BV).d2[sample]=d[ permute[j] ];
					j++;
				}
			}

			Rho[Npermutations]=EstimateRho(P,BV);

			Npermutations++;
		}
	}

	pvalue=1.0;
	for (permutation=0; permutation<Npermutations; permutation++)
	{

		if (Rho[0]>0.0)
		{
			if (Rho[permutation]>=Rho[0])
				pvalue+=1.0;
		}
		else
		{
			if (Rho[permutation]<=Rho[0])
				pvalue+=1.0;
		}
	}
	pvalue/=Npermutations;


END:
	if (Rho)
		free(Rho);

	return pvalue;
}
//=======================================================================================================================
//=======================================================================================================================
double PvalueOfConnectionUsingPermutation(double P[], struct BivariateSample *BV, int MaxPermutations, int MinSamplesToPermute)
{
	double pvalue;
	double Rho0,Rho;
	double p,sd,r;
	int permutation;
	int SamplesToPermute;
	int sample;

	//count the number of samples that are not censored in either cluster
	//these are the only ones to be permuted
	SamplesToPermute=0;
	for (sample=0; sample<(*BV).Samples; sample++)
	{
		if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)
			SamplesToPermute++;
	}


	//if the number of samples to be permuted is <=MinSamplesToPermute, then its faster to do all possible permutations
	if (SamplesToPermute<=MinSamplesToPermute)
		return PvalueOfConnectionUsingAllPermutations(P, BV, SamplesToPermute);



	//otherwise, just do lots of random permutations
	Rho0=Sigmoidpm1(P[RHO]);
	pvalue=0.0;
	permutation=1;
	do
	{
		PermuteBivariateNormal(BV);
		Rho=EstimateRho(P,BV);

		if (Rho0>0.0)
		{
			if (Rho>=Rho0)
				pvalue+=1.0;
		}
		else
		{
			if (Rho<=Rho0)
				pvalue+=1.0;
		}

		p=pvalue/permutation;
		sd=sqrt(p*(1.0-p)/permutation);

		if (p>0.0)
			r=sd/p;
		else
			r=1.0;

		permutation++;
	}
	while (permutation<MaxPermutations && (permutation<1000 || r>0.01));
	pvalue/=permutation;

	return pvalue;
}
//=======================================================================================================================
//=======================================================================================================================
//=======================================================================================================================
//=====================================================================================================================
//This function provides initial estimates the parameters from the data
int GetInitialEstimates(double P[], struct BivariateSample *BV)
{
	int Nsamples=(*BV).Samples;
	double *a=NULL;
	double *b=NULL;
	int Ncor,Na,Nb;
	int sample;

	memset(P,0,sizeof(double)*CBMAN_PARAMETERS);

	if (!(a=(double *)calloc(Nsamples,sizeof(double))))
		goto END;
	if (!(b=(double *)calloc(Nsamples,sizeof(double))))
		goto END;

	//first get the samples uncensored in both clusters for correlating
	Ncor=0;
	for (sample=0; sample<Nsamples; sample++)
	{
		if ( (*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED )
		{
			a[Ncor]=(*BV).d1[sample];
			b[Ncor]=(*BV).d2[sample];
			Ncor++;
		}
	}

	Na=Nb=Ncor;
	for (sample=0; sample<Nsamples; sample++)
	{
		if ( (*BV).censor1[sample] == NOT_CENSORED && (*BV).censor2[sample] != NOT_CENSORED )
		{
			a[Na]=(*BV).d1[sample];
			Na++;
		}
		if ( (*BV).censor1[sample] != NOT_CENSORED && (*BV).censor2[sample] == NOT_CENSORED )
		{
			b[Nb]=(*BV).d2[sample];
			Nb++;
		}
	}

	P[VARX] = Var(a, Na);
	P[VARY] = Var(b, Nb);
	P[MEANX] = MeanValueDouble(Na, a);
	P[MEANY] = MeanValueDouble(Nb, b);
	P[RHO] = InvSigmoidpm1(Pearsons(a, b, Ncor));


END:
	if (a)
		free(a);
	if (b)
		free(b);
	return 0;
}
//=====================================================================================================================
//=====================================================================================================================
double EstimateRho(double P[], struct BivariateSample *BV)
{

	double scale[CBMAN_PARAMETERS];

	memset(scale,0,sizeof(double)*CBMAN_PARAMETERS);
	scale[RHO]=1.0;
	//Search along one dimension only

	GoldenSearch(P, scale, CBMAN_PARAMETERS, NegativeBVNloglikelihood(P,CBMAN_PARAMETERS,BV),
	             NegativeBVNloglikelihood, BV,20);


	return Sigmoidpm1(P[RHO]);
}
//=====================================================================================================================
//given the starting point for the optimisation; in P
//maximise the log likelihood
//CompareGroups READY
//=====================================================================================================================
double MaximumLogLikelihoodGivenStartingPoint(double P[], int parameters, struct BivariateSample *BV)
{
    int shrinks;
	double scale[CBMAN_PARAMETERS_GROUPS];

	if (parameters==CBMAN_PARAMETERS) shrinks=30;
	else shrinks=50;

	scale[MEANX]=0.1;
	scale[MEANY]=0.1;
	scale[VARX]=0.05;
	scale[VARY]=0.05;
	scale[RHO]=0.5;
	scale[RHO2]=0.5;

	return -DownHillSimplex(P, parameters, scale,1, NegativeBVNloglikelihood, BV, shrinks);

}
//======================================================================================================
//======================================================================================================
int PermuteBivariateNormal(struct BivariateSample *BV)
{

	int Nsamples=(*BV).Samples;
	int Npermute;
	int sample;
	int *sort=NULL;
	double *d=NULL;
	double *r=NULL;



	if (!(sort=(int *)malloc(Nsamples*sizeof(int))))
		goto END;
	if (!(d=(double *)malloc(Nsamples*sizeof(double))))
		goto END;
	if (!(r=(double *)malloc(Nsamples*sizeof(double))))
		goto END;


	//first cluster
	Npermute=0;
	for (sample=0; sample<Nsamples; sample++)
	{
		if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)
		{
			d[Npermute]=(*BV).d2[sample];
			r[Npermute]=(double)rand();

			Npermute++;
		}
	}

	if (Npermute)
	{
		QuickSort(r,sort,Npermute);

		Npermute=0;
		for (sample=0; sample<Nsamples; sample++)
		{
			if ((*BV).censor1[sample]==NOT_CENSORED && (*BV).censor2[sample]==NOT_CENSORED)
			{
				(*BV).d2[sample]=d[sort[Npermute]];
				Npermute++;
			}
		}
	}


END:
	if (d)
		free(d);
	if (sort)
		free(sort);
	if (r)
		free(r);

	return Npermute;
}

//======================================================================================================
//======================================================================================================
//                         Save a bitmap of a network projection
//======================================================================================================
int SaveNetworkProjection(HWND hwndMain,
                          struct Image *mask,
                          struct Coordinates *Co,
                          double cor[],
                          double Pmat[],
                          int valid[],
                          double critical,
                          float xp[],float yp[], float zp[],
                          int Nclusters,
                          char directory[])
{

	float I;
	char Ic;
	int del=2;//size of the circles projected
	int scale=20;//increase the size of the bitmap
	int penwidth;
	int X,Y,Z;
	int x,y,z, x1, y1, z1;
	int voxel, focus, cluster, cl, index;
	int ColourLevels;
	int ValidNode;
	double *p=NULL;
	int *sort=NULL;
	int *PeakVoxel=NULL;
	RECT r;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap, hOldObj;
	int width,height, pixels;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	RGBQUAD rgb;
	HBRUSH hBrush, hOldBrush;
	HPEN hPen, hOldPen;
	FILE *fp;
	char txt[MAX_PATH];


	if (!(p=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	if (!(sort=(int *)malloc(Nclusters*sizeof(int))))
		goto END;
	if (!(PeakVoxel=(int *)malloc(Nclusters*sizeof(int))))
		goto END;

	//get the cluster p-values and voxels
	for (cluster=1; cluster<=Nclusters; cluster++)
	{
		p[cluster-1]=1.0;
		for (focus=0; focus<(*Co).TotalFoci; focus++)
		{
			cl=(*Co).cluster[focus];
			if ((cl==cluster) && (*Co).p[focus]<p[cluster-1])
				p[cluster-1]=(*Co).p[focus];
		}

		x=(int)(0.5 + (xp[cluster-1]+(*mask).x0)/(*mask).dx);
		y=(int)(0.5 + (yp[cluster-1]+(*mask).y0)/(*mask).dy);
		z=(int)(0.5 + (zp[cluster-1]+(*mask).z0)/(*mask).dz);
		PeakVoxel[cluster-1]=x + y*(*mask).X + z*(*mask).X*(*mask).Y;
	}
	QuickSort(p,sort,Nclusters);//sort from the smallest p-value to the largest p-value

	ColourLevels = Nclusters/6+1;

	//image dimensions
	X=(*mask).X;
	Y=(*mask).Y;
	Z=(*mask).Z;
	//bitmap dimensions: two hemispheres above axial above coronal
	width=(2*Z > X) ? 2*Z:X;
	height=Y+Y+Z;
	pixels=width*height*scale*scale;

	//File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=width*scale;
	BmCoreHdr.bcHeight=height*scale;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	//Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=width*scale;
	BmInfoHdr.biHeight=height*scale;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	//Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldObj = SelectObject(chDC, hBitmap);

	///draw the background overlay
	for (z=0; z<Z; z++)
	{
		for (y=0; y<Y; y++)
		{
			I=MaxProjectionAlongX((*mask).img, X, Y, Z, 0, X/2, y, z);
			Ic=100*(I/(*mask).MaxIntensity);

			hBrush=CreateSolidBrush(RGB(Ic, Ic, Ic));
			hOldBrush = SelectObject(chDC, hBrush);

			r.left=((Z-1)-z)*scale;
			r.bottom=(height - y)*scale;
			r.right=((Z-1)-z + 1)*scale;
			r.top=(height - y +1)*scale;
			FillRect(chDC, &r, hBrush);

			r.left=(z+width/2)*scale;
			r.bottom=(height - y)*scale;
			r.right=(z + width/2 + 1)*scale;
			r.top=(height - y +1)*scale;
			FillRect(chDC, &r, hBrush);

			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);
		}
	}
	for (y=0; y<Y; y++)
	{
		for (x=0; x<X; x++)
		{
			I=MaxProjectionAlongZ((*mask).img, X, Y, Z, x, y, 0, Z-1);
			Ic=100*(I/(*mask).MaxIntensity);

			hBrush=CreateSolidBrush(RGB(Ic, Ic, Ic));
			hOldBrush = SelectObject(chDC, hBrush);
			r.left=x*scale;
			r.bottom=(height - Y - y)*scale;
			r.right=(x + 1)*scale;
			r.top=(height - Y - y + 1)*scale;
			FillRect(chDC, &r, hBrush);
			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);

		}
	}
	for (z=0; z<Z; z++)
	{
		for (x=0; x<X; x++)
		{
			I=MaxProjectionAlongY((*mask).img, X, Y, Z, x, 0, Y-1, z);
			Ic=100*(I/(*mask).MaxIntensity);

			hBrush=CreateSolidBrush(RGB(Ic, Ic, Ic));
			hOldBrush = SelectObject(chDC, hBrush);
			r.left=x*scale;
			r.bottom=(height - 2*Y - z)*scale;
			r.right=(x + 1)*scale;
			r.top=(height - 2*Y - z + 1)*scale;
			FillRect(chDC, &r, hBrush);
			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);
		}
	}

	///draw the nodes (clusters represented by circles)
	for (index=Nclusters-1; index>=0; index--)
	{

		cluster=sort[index]+1;
		///is this cluster significant?
		ValidNode=0;
		for (focus=0; focus<(*Co).TotalFoci; focus++)
		{
			cl=(*Co).cluster[focus];
			if ((cl!=cluster) && (valid[cl-1+(cluster-1)*Nclusters]))
				ValidNode=1;
		}

		if (ValidNode && p[cluster-1]<=critical)
		{
			rgb=Colours(cluster-1,ColourLevels);
			voxel = PeakVoxel[cluster-1];
			XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);

			hBrush=CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldBrush = SelectObject(chDC, hBrush);
			hPen=CreatePen(PS_SOLID, 1, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldPen = SelectObject(chDC, hPen);


			if (xp[cluster-1]<0.0)
				Ellipse(chDC, ((Z-1)-z-del)*scale, (height - y-del)*scale, ((Z-1)-z+del)*scale, (height - y+del)*scale);
			else
				Ellipse(chDC, (z+width/2-del)*scale, (height - y-del)*scale, (z+width/2+del)*scale, (height - y+del)*scale);

			Ellipse(chDC, (x-del)*scale, (height - Y - y-del)*scale, (x+del)*scale, (height - Y - y+del)*scale);
			Ellipse(chDC, (x-del)*scale, (height - 2*Y - z-del)*scale, (x+del)*scale, (height - 2*Y - z+del)*scale);
			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);
			SelectObject(chDC, hOldPen);
			DeleteObject(hPen);
		}
	}



	for (index=Nclusters-1; index>=0; index--)
	{

		cluster=sort[index]+1;
		voxel=PeakVoxel[cluster-1];
		XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);

		if (p[cluster-1]<=critical)
		{
			///now draw the connecting lines
			for (cl=1; cl<=Nclusters; cl++)
			{
				if (valid[cl-1 + (cluster-1)*Nclusters] && Pmat[cl-1+(cluster-1)*Nclusters]<=critical)
				{
					penwidth=10*pow(cor[cl-1+(cluster-1)*Nclusters],2);

					rgb=Colours(cluster-1,ColourLevels);

					voxel = PeakVoxel[cl-1];
					XYZfromVoxelNumber(voxel, &x1, &y1, &z1, X, Y, Z);

					///Draw a solid line in the colour for cluster
					hPen=CreatePen(PS_SOLID, 2*penwidth, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
					hOldPen = SelectObject(chDC, hPen);

					if (xp[cluster-1]<0.0)
						MoveToEx(chDC,((Z-1)-z)*scale,(height - y)*scale,NULL);
					else
						MoveToEx(chDC,(z+width/2)*scale,(height - y)*scale,NULL);
					if (xp[cl-1]<0.0)
						LineTo(chDC,((Z-1)-z1)*scale,(height - y1)*scale);
					else
						LineTo(chDC,(z1+width/2)*scale,(height - y1)*scale);

					MoveToEx(chDC, x*scale, (height - Y - y)*scale,NULL);
					LineTo(chDC, x1*scale, (height - Y - y1)*scale);

					MoveToEx(chDC, x*scale, (height - 2*Y - z)*scale,NULL);
					LineTo(chDC, x1*scale, (height - 2*Y - z1)*scale);

					SelectObject(chDC, hOldPen);
					DeleteObject(hPen);

					///now overwrite this with a thinner line in the colour of cluster cl
					rgb=Colours(cl-1,ColourLevels);
					hPen=CreatePen(PS_SOLID, penwidth, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
					hOldPen = SelectObject(chDC, hPen);

					if (xp[cluster-1]<0.0)
						MoveToEx(chDC,((Z-1)-z)*scale,(height - y)*scale,NULL);
					else
						MoveToEx(chDC,(z+width/2)*scale,(height - y)*scale,NULL);
					if (xp[cl-1]<0.0)
						LineTo(chDC,((Z-1)-z1)*scale,(height - y1)*scale);
					else
						LineTo(chDC,(z1+width/2)*scale,(height - y1)*scale);

					MoveToEx(chDC, x*scale, (height - Y - y)*scale,NULL);
					LineTo(chDC, x1*scale, (height - Y - y1)*scale);

					MoveToEx(chDC, x*scale, (height - 2*Y - z)*scale,NULL);
					LineTo(chDC, x1*scale, (height - 2*Y - z1)*scale);

					SelectObject(chDC, hOldPen);
					DeleteObject(hPen);
				}
			}
		}
	}

	BitBlt(hDC, 0, 0, width*scale, height*scale, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldObj);

	sprintf(txt,"%s\\network.bmp",directory);
	//Now save the bitmap file
	if ( (fp=fopen(txt,"wb")) )
	{
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}

	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

END:
	if (PeakVoxel)
		free(PeakVoxel);
	if (p)
		free(p);
	if (sort)
		free(sort);
	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}
//======================================================================================================
//======================================================================================================
//                         Save a bitmap of a network projection
//======================================================================================================
int SaveTalairachNetworkProjection(HWND hwndMain,
                                   struct Coordinates *Co,
                                   double cor[],
                                   double Pmat[],
                                   int valid[],
                                   double critical,
                                   float xp[],float yp[], float zp[],
                                   int Nclusters,
                                   char directory[])
{

	int del=24;//size of the circles projected
	int penwidth;
	int x,y, x1, y1;
	int focus, cluster, cl, index;
	int ColourLevels;
	int ValidNode;
	double *p=NULL;
	int *sort=NULL;
	int fontwidth=18;
	int fontheight=20;
	TEXTMETRIC tm;
	RECT r;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap, hOldObj;
	int width,height, pixels;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	RGBQUAD rgb,c;
	HBRUSH hBrush, hOldBrush;
	HPEN hPen, hOldPen;
	HFONT hOldFont, hFont = CreateFont(fontheight,fontwidth,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
	                                   CLIP_DEFAULT_PRECIS, 0, VARIABLE_PITCH,TEXT("Verdana"));
	char txt[256];
	FILE *fp;
	char fname[MAX_PATH];

	if (!(p=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	if (!(sort=(int *)malloc(Nclusters*sizeof(int))))
		goto END;

	//get the cluster p-values and voxels
	for (cluster=1; cluster<=Nclusters; cluster++)
	{
		p[cluster-1]=1.0;
		for (focus=0; focus<(*Co).TotalFoci; focus++)
		{
			cl=(*Co).cluster[focus];
			if ((cl==cluster) && (*Co).p[focus]<p[cluster-1])
				p[cluster-1]=(*Co).p[focus];
		}
	}
	QuickSort(p,sort,Nclusters);//sort from the smallest p-value to the largest p-value

	ColourLevels = Nclusters/6+1;

	//bitmap dimensions: two hemispheres above axial above coronal
	width=1000;
	height=1000;
	pixels=width*height;

	///File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	///Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=width;
	BmCoreHdr.bcHeight=height;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	///Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=width;
	BmInfoHdr.biHeight=height;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	///Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldObj = SelectObject(chDC, hBitmap);



	///draw the background overlay
	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	r.left=0;
	r.bottom=0;
	r.right=width;
	r.top=height;
	FillRect(chDC, &r, hBrush);///white background
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);

	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);

	ConvertTalairachToProjection(width, -1.0, 0.0, 0.0, &x, &y);
	ConvertTalairachToProjection(width, 0.0, -1.0, 0.0, &x1, &y1);
	Ellipse(chDC, x, y1, width/2 + (width/2-x), height/2 + (height/2-y1));///z=0 circle
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);

	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);
	MoveToEx(chDC,width/2,0,NULL);
	LineTo(chDC,width/2,height);
	MoveToEx(chDC,0,height/2,NULL);///x=0, y=0 axis
	LineTo(chDC,width,height/2);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);


	///Draw connecting lines
	for (cluster=1; cluster<=Nclusters; cluster++)
	{
		if (p[cluster-1]<=critical)
		{
			///now draw the connecting lines
			for (cl=1; cl<=Nclusters; cl++)
			{
				if (valid[cl-1 + (cluster-1)*Nclusters] && Pmat[cl-1+(cluster-1)*Nclusters]<=critical)
				{

					penwidth=10*pow(cor[cl-1+(cluster-1)*Nclusters],2);
					hPen=CreatePen(PS_SOLID, penwidth, RGB(200, 200, 200));
					hOldPen = SelectObject(chDC, hPen);
					if (ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0)
					{
						if (ConvertTalairachToProjection(width, xp[cl-1], yp[cl-1], zp[cl-1], &x1, &y1)>=0)
						{
							MoveToEx(chDC,x,y,NULL);
							LineTo(chDC,x1,y1);
						}
					}
					SelectObject(chDC, hOldPen);
					DeleteObject(hPen);
				}
			}
		}
	}



	hOldFont=SelectObject(chDC, hFont);
	GetTextMetrics(chDC,&tm);
	SetBkMode(chDC, TRANSPARENT);
	SetTextColor(chDC,RGB(255, 255, 255));
	///draw the nodes (clusters represented by circles)
	for (index=Nclusters-1; index>=0; index--)
	{

		cluster=sort[index]+1;
		ValidNode=0;
		for (cl=1; cl<=Nclusters; cl++)
		{
			if ((cl!=cluster) && (valid[cl-1+(cluster-1)*Nclusters]))
				ValidNode=1;
		}

		if (ValidNode && p[cluster-1]<=critical)
		{
			rgb=Colours(cluster-1,ColourLevels);

			//draw the number in black or white, depending on the colour of the ellipse
			c.rgbRed=c.rgbBlue=c.rgbGreen=( (rgb.rgbRed+rgb.rgbBlue+rgb.rgbGreen)/3>128 )?0:255;

			SetTextColor(chDC,RGB(c.rgbRed, c.rgbGreen, c.rgbBlue));

			hBrush=CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldBrush = SelectObject(chDC, hBrush);
			hPen=CreatePen(PS_SOLID, 1, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldPen = SelectObject(chDC, hPen);

			if (ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0)
			{
				Ellipse(chDC, x-del, y+del, x+del, y-del);
			}
			sprintf(txt,"%d",cluster);
			TextOut(chDC, x-tm.tmAveCharWidth*strlen(txt)/2-1, y-tm.tmHeight/2, txt,strlen(txt));

			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);
			SelectObject(chDC, hOldPen);
			DeleteObject(hPen);
		}
	}
	SelectObject(chDC, hOldFont);





	BitBlt(hDC, 0, 0, width, height, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldObj);

	///Now save the bitmap file
	sprintf(fname,"%s\\TalairachNetwork.bmp",directory);
	if ( (fp=fopen(fname,"wb")) )
	{
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}

	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

END:
	if (p)
		free(p);
	if (sort)
		free(sort);
	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}


//=============================================================================================================
//=============================================================================================================
int SaveTalairachCoordinateProjection(HWND hwndMain,
                                      float x[], float y[], float z[], int N, short int col[], int Ncolours,
                                      char name[], char directory[])
{

	int del=6;//size of the circles projected
	int coord;
	int ColourLevels;
	int xt,yt,xt1,yt1;
	RECT r;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap, hOldObj;
	int width,height, pixels;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	RGBQUAD rgb;
	HBRUSH hBrush, hOldBrush;
	HPEN hPen, hOldPen;
	FILE *fp;
	char fname[MAX_PATH];

	ColourLevels = Ncolours/6+1;

	//bitmap dimensions: two hemispheres above axial above coronal
	width=1000;
	height=1000;
	pixels=width*height;

	///File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	///Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=width;
	BmCoreHdr.bcHeight=height;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	///Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=width;
	BmInfoHdr.biHeight=height;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	///Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldObj = SelectObject(chDC, hBitmap);



	///draw the background overlay
	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	r.left=0;
	r.bottom=0;
	r.right=width;
	r.top=height;
	FillRect(chDC, &r, hBrush);///white background
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);

	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);

	ConvertTalairachToProjection(width, -1.0, 0.0, 0.0, &xt, &yt);
	ConvertTalairachToProjection(width, 0.0, -1.0, 0.0, &xt1, &yt1);
	Ellipse(chDC, xt, yt1, width/2 + (width/2-xt), height/2 + (height/2-yt1));///z=0 circle
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);

	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);
	MoveToEx(chDC,width/2,0,NULL);
	LineTo(chDC,width/2,height);
	MoveToEx(chDC,0,height/2,NULL);///x=0, y=0 axis
	LineTo(chDC,width,height/2);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);

	SetBkMode(chDC, TRANSPARENT);
	///draw the nodes (clusters represented by circles)
	for (coord=0; coord<N; coord++)
	{

		rgb=Colours(col[coord],ColourLevels);

		hBrush=CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		hOldBrush = SelectObject(chDC, hBrush);
		hPen=CreatePen(PS_SOLID, 2, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
		hOldPen = SelectObject(chDC, hPen);

		if (ConvertTalairachToProjection(width, x[coord], y[coord], z[coord], &xt, &yt)>=0)
		{
			Ellipse(chDC, xt-del, yt+del, xt+del, yt-del);
		}

		SelectObject(chDC, hOldBrush);
		DeleteObject(hBrush);
		SelectObject(chDC, hOldPen);
		DeleteObject(hPen);
	}




	BitBlt(hDC, 0, 0, width, height, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldObj);

	///Now save the bitmap file
	sprintf(fname,"%s\\%s.bmp",directory,name);
	if ( (fp=fopen(fname,"wb")) )
	{
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}

	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);


	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}
//=============================================================================================================
int ConvertTalairachToProjection(double size, float xtal, float ytal, float ztal, int *x, int *y)
{
	double scale=(double)size/150/2;
	double R=sqrt(xtal*xtal+ytal*ytal);

	ytal*=-1.0;///negative y so -y fall below axis

	if (ztal<-70.0)
		return -1;
	ztal+=70.0;//make sure the Talairach z>0
	ztal*=scale;

	(*x)=(int)(ztal*xtal/R +0.5) + size/2;
	(*y)=(int)(ztal*ytal/R +0.5) + size/2;


	if ((*x)<0 || (*x)>size || (*y)<0 || (*y)>size)
		return -1;
	return 0;
}
//======================================================================================================
//======================================================================================================
//                         Save a bitmap of a network projection
//======================================================================================================
int SaveCorrelationMatrixPlot(HWND hwndMain,
                              double *MinPcluster,
                              double cor[],
                              double Pmat[],
                              double critical,
                              int Nclusters,
                              char directory[])
{

	char I;
	int scale=20;//increase the size of the bitmap
	int cl,cl2,NsigClusters;
	int i,j,k;
	RECT r;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap, hOldObj;
	int width,height, margin, pixels;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	HBRUSH hBrush, hOldBrush;
	FILE *fp;
	char txt[MAX_PATH];

	NsigClusters=0;
	for (cl=0; cl<Nclusters; cl++)
	{
		if (MinPcluster[cl]<=critical)
			NsigClusters++;
	}
	if (!NsigClusters)
		goto END;

	height=width=NsigClusters;
	margin=3;
	pixels=(width+margin)*(height+margin)*scale*scale;

	//File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=(width+margin)*scale;
	BmCoreHdr.bcHeight=(height+margin)*scale;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	//Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=(width+margin)*scale;
	BmInfoHdr.biHeight=(height+margin)*scale;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	//Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldObj = SelectObject(chDC, hBitmap);

	k=0;
	for (cl=0; cl<Nclusters; cl++)
	{
		if (MinPcluster[cl]<=critical)
		{
			for (cl2=0; cl2<Nclusters; cl2++)
			{
				if (MinPcluster[cl2]<=critical)
				{
					j=k/NsigClusters;
					i=k-j*NsigClusters;

					if (Pmat[cl+cl2*Nclusters]<=critical)
						I=255*pow(cor[cl+cl2*Nclusters],2);
					else
						I=0;

					hBrush=CreateSolidBrush(RGB(I, I, I));
					hOldBrush = SelectObject(chDC, hBrush);
					r.left=(i + margin)*scale;
					r.bottom=(height - j-1)*scale;
					r.right=(i + 1 + margin)*scale;
					r.top=(height - j)*scale;
					FillRect(chDC, &r, hBrush);
					SelectObject(chDC, hOldBrush);
					DeleteObject(hBrush);

					k++;
				}
			}
		}
	}

	BitBlt(hDC, 0, 0, (width+margin)*scale, (height+margin)*scale, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldObj);

	sprintf(txt,"%s\\MatrixPlot.bmp",directory);
	//Now save the bitmap file
	if ( (fp=fopen(txt,"wb")) )
	{
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}

	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

END:
	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}
//======================================================================================================
//======================================================================================================



//============================================================================================================================
//save the igraph output
//============================================================================================================================
int SaveiGraph(int Nclusters,
               double *MinPcluster,
               double *R, //correlation matrix [Nclusters x Nclusters]
               double *p, //p value  matrix [Nclusters x Nclusters]
               int *valid,//valid  matrix [Nclusters x Nclusters]
               double critical, //p value threshold for significance
               char directory[])
{
	char fname[MAX_PATH];
	int first;
	int i,j,k,Nvalid,count;
	int ColourLevels = Nclusters/6+1;
	double r,g,b;
	RGBQUAD rgb;
	FILE *fp=NULL;

	sprintf(fname,"%s//igraph.R",directory);
	if (!(fp=fopen(fname,"w")))
		goto END;

	///count the number of valid clusters
	Nvalid=0;
	for (i=0; i<Nclusters; i++)
	{
		if (MinPcluster[i]<=critical)
			Nvalid++;
	}

	///library
	fprintf(fp,"library(igraph)\n");

	///matrix
	fprintf(fp,"Aa=matrix(\nc(");//correlation matrix
	first=1;
	count=0;
	for (i=0; i<Nclusters; i++)
	{
		if (MinPcluster[i]<=critical)
		{
			for (j=0; j<Nclusters; j++)
			{
				k=i+j*Nclusters;
				if (MinPcluster[j]<=critical)
				{
					if (valid[k] && p[k]<=critical)
						r=1.0;
					else
						r=0.0;
					if (first)
					{
						fprintf(fp,"%f",r);
						first=0;
					}
					else
						fprintf(fp,",%f",r);
					count++;
					if (count==Nvalid)
					{
						count=0;
						fprintf(fp,"\n");
					}
				}
			}
		}
	}
	fprintf(fp,"),nrow=%d, ncol=%d, byrow = TRUE)\n\n",Nvalid,Nvalid);

	///colours
	fprintf(fp,"nodecolours=c(");
	first=1;
	for (i=0; i<Nclusters; i++)
	{
		if (MinPcluster[i]<=critical)
		{
			rgb=Colours(i,ColourLevels);
			r=(double)rgb.rgbRed/255;
			g=(double)rgb.rgbGreen/255;
			b=(double)rgb.rgbBlue/255;
			if (first)
			{
				fprintf(fp,"rgb(%f,%f,%f)",r,g,b);
				first=0;
			}
			else
				fprintf(fp,",rgb(%f,%f,%f)",r,g,b);
		}
	}
	fprintf(fp,")\n\n");


	///line thickness
	fprintf(fp,"#####the thickness of the edge lines is R^2####\n");
	fprintf(fp,"thickness=c(");//correlation matrix

	first=1;
	for (i=0; i<Nclusters; i++)
	{
		if (MinPcluster[i]<=critical)
		{
			for (j=i+1; j<Nclusters; j++)
			{
				k=i+j*Nclusters;
				if (valid[k] && MinPcluster[j]<=critical && p[k]<=critical)
				{
					r=R[k]*R[k];
					if (first)
					{
						fprintf(fp,"%f",r);
						first=0;
					}
					else
						fprintf(fp,",%f",r);
				}
			}
		}
	}
	fprintf(fp,")\n");

	fprintf(fp,"t=10 ####increase/decrease to make lines thicker/thinner####\n");
	fprintf(fp,"thickness=thickness*t\n");

	///labels
	first=1;
	fprintf(fp,"clusters=c(");
	for (i=0; i<Nclusters; i++)
	{
		if (MinPcluster[i]<=critical)
		{
			if (first)
			{
				fprintf(fp,"%d",i+1);
				first=0;
			}
			else
				fprintf(fp,",%d",i+1);
		}
	}
	fprintf(fp,")\n\n");



	fprintf(fp,"g <- graph_from_adjacency_matrix(Aa, mode=\"undirected\")\n\n");

	///layout
	fprintf(fp,"######Uncomment the required layout######\n");
	fprintf(fp,"#lo=layout_nicely(g,dim=2)\n");
	fprintf(fp,"#lo=layout_with_kk(g)\n");
	fprintf(fp,"lo=layout_in_circle(g)\n");

	fprintf(fp,"#######Adjust node and font size here######\n");
	fprintf(fp,"FontSize=%d\n",2);
	fprintf(fp,"NodeSize=%d\n",20);

	fprintf(fp,"plot(g, vertex.color=nodecolours, \
                \nvertex.frame.color=NA, \
                \nvertex.label=clusters,          \
                \nvertex.label.cex=rep(FontSize,%d),     \
                \nvertex.size=rep(NodeSize,%d),          \
                \nvertex.label.color=\"white\",   \
                \nvertex.label.font=2,            \
                \nedge.width=thickness,           \
                \nlayout=lo)\n",Nvalid, Nvalid);

END:

	if (fp)
		fclose(fp);
	return 0;

}



//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
//          EXPERIMENTS USED IN PAPER
//=============================================================================================================
int TestNullDistribution(int Nstudies, int Nsubjects, double mean, double sd)
{

	double Rho[1001];
	double pvalue;
	struct EffectSample Es;
	struct Bivariate bv;
	struct BivariateSample BV;
	int iterations=100;
	int i,iter,permutations;
	double P[CBMAN_PARAMETERS];
	FILE *fp;
	char fname[MAX_PATH];

	memset(&BV,0,sizeof(struct BivariateSample));
	memset(&Es,0,sizeof(struct EffectSample));

	if (!MakeEffectSampleStructure(&Es, Nstudies,ID_MEANZ))
		return 0;

	sprintf(fname,"%s\\PermutationTest.csv",REPORT_FOLDER);
	if (!(fp=fopen(fname,"w")))
		return 0;


	MakeStructBivariateSample(&BV, Nstudies);


	for (i=0; i<Nstudies; i++)
	{
		rBivariateNorm(&bv, mean, mean, sd, sd, 0.7);
		BV.d1[i]=bv.x;
		BV.d2[i]=bv.y;
		BV.V[i]=0.1;
		BV.censor1[i]=NOT_CENSORED;
		BV.censor2[i]=NOT_CENSORED;
		BV.CensorLevel[i]=3.9/sqrt(Nsubjects);


		if (rand()<RAND_MAX/1000)   //introduce LR censoring to 1 in 10 studies
		{
			if ((mean>0.0) && (BV.d1[i]>=BV.CensorLevel[i]))
				BV.censor1[i]=RIGHT_CENSORED;
			else if ((mean<0.0) && (BV.d1[i]<=-BV.CensorLevel[i]))
				BV.censor1[i]=LEFT_CENSORED;
			else
				BV.censor1[i]=INTERVAL_CENSORED;


			if ((mean>0.0) && (BV.d2[i]>=BV.CensorLevel[i]))
				BV.censor2[i]=RIGHT_CENSORED;
			else if ((mean<0.0) && (BV.d2[i]<=-BV.CensorLevel[i]))
				BV.censor2[i]=LEFT_CENSORED;
			else
				BV.censor2[i]=INTERVAL_CENSORED;


			BV.d1[i]=BV.d2[i]=0.0;
		}
		else
		{
			if (fabs(bv.x)<BV.CensorLevel[i])
			{
				BV.d1[i]=0.0;
				BV.censor1[i]=INTERVAL_CENSORED;
			}
			if (fabs(bv.y)<BV.CensorLevel[i])
			{
				BV.d2[i]=0.0;
				BV.censor2[i]=INTERVAL_CENSORED;
			}
		}
	}


	///initial estimates for optimisation
	P[MEANX] = P[MEANY] = mean;
	P[VARX] = P[VARY] =sd*sd;
	P[RHO]=0.0;
	MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, &BV);
	Rho[0]=Sigmoidpm1(P[RHO]);
	fprintf(fp,"%f,%f,%f,%f,%f,*****\n",P[MEANX],P[MEANY],P[VARX],P[VARY],Sigmoidpm1(P[RHO]));
	for (iter=1; iter<=iterations; iter++)
	{
		permutations=PermuteBivariateNormal(&BV);
		Rho[iter]=EstimateRho(P,&BV);
		fprintf(fp,"%f,%f,%f,%f,%f,%d\n",P[MEANX],P[MEANY],P[VARX],P[VARY],Sigmoidpm1(P[RHO]),permutations);
	}

	pvalue=0.0;
	for (iter=1; iter<=iterations; iter++)
	{
		if (Rho[iter]>=Rho[0])
			pvalue+=1.0;
	}
	pvalue/=iterations;
	char txt[256];
	sprintf(txt,"%f %f %d",Rho[0],pvalue,permutations);
	MessageBox(NULL,txt,"",MB_OK);

	fclose(fp);
	FreeStructBivariateSample(&BV);
	return 1;
}



//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//generate samples from multivariate normal
//only return the sample if it has a high likelihood
//this is just for generating experiments with known properties
//if just generating MVN using rMVnorm the results can be very different to those specified because its high dimensional
//======================================================================================================
#define MVN_TRIES 10000
int rMVNwithintol(double MV[], double mean[], double Sigma[], int n, int samples)
{
	int result=0;
	int i,j,k;
	int iter;
	double *MVNsamples=NULL;
	double *x=NULL;
	double *y=NULL;
	double *m=NULL;
	double *v=NULL;
	double *r=NULL;
	double *dSigma=NULL;
	double diff[MVN_TRIES];
	int sort[MVN_TRIES];
	char txt[1024];

	if (!(MVNsamples=(double *)malloc(samples*n*MVN_TRIES*sizeof(double))))
		goto END;
	if (!(x=(double *)malloc(sizeof(double)*samples)))
		goto END;
	if (!(y=(double *)malloc(sizeof(double)*samples)))
		goto END;
	if (!(m=(double *)malloc(sizeof(double)*n)))
		goto END;
	if (!(v=(double *)malloc(sizeof(double)*n)))
		goto END;
	if (!(r=(double *)malloc(sizeof(double)*n*n)))
		goto END;
	if (!(dSigma=(double *)malloc(sizeof(double)*n*n)))
		goto END;


	for (iter=0; iter<MVN_TRIES; iter++)
	{
		//generate the proposed sample
		for (i=0; i<samples; i++)
			rMVnorm(&MVNsamples[iter*samples*n + i*n], mean, Sigma, n);

		//estimate the means
		txt[0]='\0';
		for (j=0; j<n; j++)
		{
			for (k=0; k<samples; k++)
				x[k] = MVNsamples[iter*samples*n + j + k*n];
			m[j] = MeanValueDouble(samples, x);
			v[j] = Var(x,samples);//difference between sample variance and true variance
			sprintf(txt,"%s%f %f \n%f %f\n",txt,mean[j],m[j],Sigma[j+j*n], v[j]);
		}
		//MessageBox(NULL,txt,"",MB_OK);


		//estimate the correlations
		txt[0]='\0';
		for (j=0; j<n; j++)
		{
			for (i=0; i<n; i++)
			{
				for (k=0; k<samples; k++)
				{
					x[k] = MVNsamples[iter*samples*n + j + k*n];
					y[k] = MVNsamples[iter*samples*n + i + k*n];
				}
				r[i+j*n]=Pearsons(x,y,samples);
				sprintf(txt,"%s %f",txt,r[i+j*n]);
			}
			sprintf(txt,"%s\n",txt);
		}
		//MessageBox(NULL,txt,"",MB_OK);


		for (j=0; j<n; j++)
		{
			for (i=0; i<n; i++)
			{
				dSigma[i+j*n] = r[i+j*n]*sqrt(v[i]*v[j])-Sigma[i+j*n];
			}
		}


		diff[iter]=0.0;
		for (j=0; j<n; j++)
		{
			for (i=0; i<n; i++)
			{
				diff[iter]+=dSigma[i+j*n]*dSigma[i+j*n];
			}
		}

	}

	QuickSort(diff,sort,MVN_TRIES);
	memcpy(MV,&MVNsamples[sort[1]*samples*n],sizeof(double)*samples*n);

	result=1;
END:
	if (x)
		free(x);
	if (y)
		free(y);
	if (m)
		free(m);
	if (v)
		free(v);
	if (r)
		free(r);
	if (dSigma)
		free(dSigma);
	if (MVNsamples)
		free(MVNsamples);

	return result;
}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//NULL coordinates and effect generator
//effects are between MinZ<=|Z|<=MaxZ
//SDcoord is the standard of the coordinates from the cluster peak
//the distribution of the effect sizes in the clusters is correlated and multivariate normal
//======================================================================================================
int Paper_netork_groups_examples(struct Coordinates *Co,
                                 struct Image *mask,
                                 int StudiesA, int StudiesB, int Subjects,
                                 double Zcensor,
                                 double SDcoord,
                                 struct ThreeVector V[],
                                 int nClusters, int nRandomCoordinates,
                                 double meanA[], double SigmaA[],
                                 double meanB[], double SigmaB[])
{
	double MaxZ=7.0;
	double MinZ=Zcensor;
	double sd=SDcoord/pow(3.0,1.0/3);//the standard deviation of the cluster size
	int study, coordinate;
	int TotalCoordinates;
	int RandomVoxel;
	int xi,yi,zi;
	int i;
	int Studies=StudiesA+StudiesB;
	double dist, MinDist;
	double Z;
	double effect=5.0;
	double s=1.0;
	double dx,dy,dz;
	double *MVa=NULL;//multivariate sample goes here
	double *MVb=NULL;//multivariate sample goes here

	if (!(MVa=(double *)malloc(StudiesA*nClusters*sizeof(double))))
		return 0;
	if (!(MVb=(double *)malloc(StudiesB*nClusters*sizeof(double))))
		return 0;

	//generate multivariate normal effect sizes
	rMVNwithintol(MVa, meanA, SigmaA, nClusters,StudiesA);
	rMVNwithintol(MVb, meanB, SigmaB, nClusters,StudiesB);

	memset(Co,0,sizeof(struct Coordinates));
	if (!MakeStructCoordinates(Co, (nRandomCoordinates+nClusters)*Studies, Studies))
		return 0;
	(*Co).ZscoreUsed=1;
	TotalCoordinates=0;
	for (study=0; study<Studies; study++)
	{
		if (study<StudiesA)
			(*Co).covariate[study]=0.0;///group A
		else (*Co).covariate[study]=1.0;///group B

		sprintf((*Co).ID[study].txt,"Study%d",study);
		(*Co).SubjectsInExp[study] = Subjects;
		(*Co).Zcensor[study] = MinZ;
		///insert the random coordinates
		for (coordinate=0; coordinate<nRandomCoordinates; coordinate++)
		{
			do
			{
				Z=GaussRandomNumber_BoxMuller(effect, s);//|Z| will be >MinZ and <=MaxZ
			}
			while ((fabs(Z)>MaxZ));

			if (fabs(Z)>MinZ)
			{
				do
				{
					RandomVoxel = RandomImageVoxel((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
					XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
					MinDist=10000000.0;
					for (i=0; i<nClusters; i++)
					{
						dist= ((*mask).dx*xi - (*mask).x0 - V[i].x)*((*mask).dx*xi - (*mask).x0 - V[i].x)+
						      ((*mask).dy*yi - (*mask).y0 - V[i].y)*((*mask).dy*yi - (*mask).y0 - V[i].y)+
						      ((*mask).dz*zi - (*mask).z0 - V[i].z)*((*mask).dz*zi - (*mask).z0 - V[i].z);
						if (dist<MinDist)
							MinDist=dist;
					}
				}
				while (MinDist<NSIGMA95*NSIGMA95*sd*sd);

				(*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
				(*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
				(*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
				(*Co).subjects[TotalCoordinates] = Subjects;
				(*Co).Zsc[TotalCoordinates] = Z;
				(*Co).experiment[TotalCoordinates] = study;
				TotalCoordinates++;
			}
		}
		///insert the clusters
		for (coordinate=0; coordinate<nClusters; coordinate++)
		{
			if (study<StudiesA)
				Z=MVa[coordinate + study*nClusters];
			else
				Z=MVb[coordinate + (study-StudiesA)*nClusters];
			if (Z>MinZ)   //not censored
			{
				do
				{
					dx=GaussRandomNumber_BoxMuller(0.0,sd);
					dy=GaussRandomNumber_BoxMuller(0.0,sd);
					dz=GaussRandomNumber_BoxMuller(0.0,sd);
				}
				while (sqrt(dx*dx + dy*dy + dz*dz)>NSIGMA95*sd);

				(*Co).x[TotalCoordinates] = V[coordinate].x + dx;
				(*Co).y[TotalCoordinates] = V[coordinate].y + dy;
				(*Co).z[TotalCoordinates] = V[coordinate].z + dz;
				(*Co).subjects[TotalCoordinates] = Subjects;
				(*Co).Zsc[TotalCoordinates] = Z;
				(*Co).experiment[TotalCoordinates] = study;
				TotalCoordinates++;
			}
		}
	}
	(*Co).TotalFoci=TotalCoordinates;

	if (MVa)
		free(MVa);
	if (MVb)
		free(MVb);

	return TotalCoordinates;

}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//generate Paper Experiments
//======================================================================================================
int GenerateGroupExperiments(struct Image *mask)
{
	struct Coordinates Co;
	int StudiesA=30;///20 is few, 50 is moderate, 100 is a lot.
	int StudiesB=30;///20 is few, 50 is moderate, 100 is a lot
	int Subjects=20;///20 is a good minimum, 50 is moderate
	double Zcensor=3.09;///typical
	int nRandomCoordinates=6;///same number of noise and cluster coordinates
	int nClusters=6;
	int cluster;
	int i,j;
	struct ThreeVector V[6];
	double meanA[6];
	double SigmaA[36];
	double meanB[6];
	double SigmaB[36];
	double v=0.3*Subjects;
	double m=5.0;///mean is average
	double rho=0.6;///moderate correlation
	char fname[MAX_PATH];

	if (!(*mask).X)
		return 0;

	memset(&Co,0,sizeof(struct Coordinates));

	V[0].x=-34.0;
	V[0].y=50.0;
	V[0].z=18.0;
	V[1].x=0.0;
	V[1].y=44.0;
	V[1].z=18.0;
	V[2].x=34.0;
	V[2].y=50.0;
	V[2].z=18.0;
	V[3].x=-56.0;
	V[3].y=-66.0;
	V[3].z=18.0;
	V[4].x=0.0;
	V[4].y=-56.0;
	V[4].z=18.0;
	V[5].x=56.0;
	V[5].y=-66.0;
	V[5].z=18.0;

	memset(SigmaA,0,sizeof(double)*36);
	memset(SigmaB,0,sizeof(double)*36);

	//set mean and diagonal of Sigma the same for groups A & B
	for (cluster=0; cluster<nClusters; cluster++)
	{
		meanA[cluster] = m;
		SigmaA[cluster + cluster*nClusters]=v;
		meanB[cluster] = m;
		SigmaB[cluster + cluster*nClusters]=v;
	}

	///experiment 1: all independent effect sizes
	Paper_netork_groups_examples(&Co, mask, StudiesA, StudiesB, Subjects, Zcensor,
	                             4.0, V, nClusters, nRandomCoordinates,
	                             meanA, SigmaA, meanB, SigmaB);
	sprintf(fname,"%s\\NetworkIndependent_groups.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 2: all independent effect sizes except between clusters 1,2
	SigmaB[1]=rho*v;
	SigmaB[6]=rho*v;
	Paper_netork_groups_examples(&Co, mask, StudiesA, StudiesB, Subjects, Zcensor,
	                             4.0, V, nClusters, nRandomCoordinates,
	                             meanA, SigmaA, meanB, SigmaB);
	sprintf(fname,"%s\\Network_rho1_groups.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 3: full network; all correlated
	for (i=0; i<6; i++)
	{
		for (j=0; j<6; j++)
		{
			if (i==j)
				SigmaB[i+6*j]=v;
			else
				SigmaB[i+6*j]=rho*v;
		}
	}
	Paper_netork_groups_examples(&Co, mask, StudiesA, StudiesB, Subjects, Zcensor,
	                             4.0, V, nClusters, nRandomCoordinates,
	                             meanA, SigmaA, meanB, SigmaB);
	sprintf(fname,"%s\\Network_full_groups.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 4: two networks
	memset(SigmaB,0,sizeof(double)*36);
	for (i=0; i<3; i++)
	{
		for (j=0; j<3; j++)
		{
			if (i==j)
				SigmaB[i+6*j]=v;
			else
				SigmaB[i+6*j]=rho*v;
		}
	}
	for (i=3; i<6; i++)
	{
		for (j=3; j<6; j++)
		{
			if (i==j)
				SigmaB[i+6*j]=v;
			else
				SigmaB[i+6*j]=rho*v;
		}
	}
	Paper_netork_groups_examples(&Co, mask, StudiesA, StudiesB, Subjects, Zcensor,
	                             4.0, V, nClusters, nRandomCoordinates,
	                             meanA, SigmaA, meanB, SigmaB);
	sprintf(fname,"%s\\Network_2networks_groups.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);



	return 0;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//NULL coordinates and effect generator
//effects are between MinZ<=|Z|<=MaxZ
//SDcoord is the standard of the coordinates from the cluster peak
//the distribution of the effect sizes in the clusters is correlated and multivariate normal
//======================================================================================================
int Paper_netork_examples(struct Coordinates *Co,
                          struct Image *mask,
                          int Studies, int Subjects,
                          double Zcensor,
                          double SDcoord,
                          struct ThreeVector V[],
                          int nClusters, int nRandomCoordinates,
                          double mean[], double Sigma[])
{
	double MaxZ=10.0;
	double MinZ=Zcensor;
	int study, coordinate;
	int TotalCoordinates;
	int RandomVoxel;
	int xi,yi,zi;
	int i;
	double MVsigma[9]= {SDcoord*SDcoord, 0.0, 0.0, 0.0, SDcoord*SDcoord,0.0,0.0,0.0,SDcoord*SDcoord};
	double MVmean[3]= {0.0,0.0,0.0};
	double MVr[3];
	double dist2, MinDist2;
	double Z;
	double effect=5.0;
	double s=1.0;
	double dx,dy,dz;
	double *MV=NULL;//multivariate sample goes here

	if (!(MV=(double *)malloc(Studies*nClusters*sizeof(double))))
		return 0;


	//get the effect sizes for the clusters
	rMVNwithintol(MV, mean, Sigma, nClusters, Studies);

	memset(Co,0,sizeof(struct Coordinates));
	if (!MakeStructCoordinates(Co, (nRandomCoordinates+nClusters)*Studies, Studies))
		return 0;
	(*Co).ZscoreUsed=1;
	TotalCoordinates=0;
	for (study=0; study<Studies; study++)
	{
		sprintf((*Co).ID[study].txt,"Study%d",study);
		(*Co).SubjectsInExp[study] = Subjects;
		(*Co).Zcensor[study] = MinZ;
		///insert the random coordinates
		for (coordinate=0; coordinate<nRandomCoordinates; coordinate++)
		{
			do
			{
				Z=GaussRandomNumber_BoxMuller(effect, s);//|Z| will be >MinZ and <=MaxZ
			}
			while ((fabs(Z)>MaxZ));

			if (fabs(Z)>MinZ)
			{

				do
				{
					RandomVoxel = RandomImageVoxel((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
					XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
					MinDist2=10000000.0;
					for (i=0; i<nClusters; i++)
					{
						dist2= ((*mask).dx*xi - (*mask).x0 - V[i].x)*((*mask).dx*xi - (*mask).x0 - V[i].x)+
						       ((*mask).dy*yi - (*mask).y0 - V[i].y)*((*mask).dy*yi - (*mask).y0 - V[i].y)+
						       ((*mask).dz*zi - (*mask).z0 - V[i].z)*((*mask).dz*zi - (*mask).z0 - V[i].z);
						if (dist2<MinDist2)
							MinDist2=dist2;
					}
				}
				while (MinDist2<50.0*50.0);

				(*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
				(*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
				(*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
				(*Co).subjects[TotalCoordinates] = Subjects;
				(*Co).Zsc[TotalCoordinates] = Z;
				(*Co).experiment[TotalCoordinates] = study;
				TotalCoordinates++;
			}
		}
		///insert the clusters

		for (coordinate=0; coordinate<nClusters; coordinate++)
		{
			Z=MV[coordinate + study*nClusters];
			if (Z>MinZ)   //not censored
			{
				do
				{
					rMVnorm(MVr, MVmean, MVsigma, 3);
					dx=MVr[0];
					dy=MVr[1];
					dz=MVr[2];
				}
				while (sqrt(dx*dx + dy*dy + dz*dz)>NSIGMA95*SDcoord);

				(*Co).x[TotalCoordinates] = V[coordinate].x + dx;
				(*Co).y[TotalCoordinates] = V[coordinate].y + dy;
				(*Co).z[TotalCoordinates] = V[coordinate].z + dz;
				(*Co).subjects[TotalCoordinates] = Subjects;
				(*Co).Zsc[TotalCoordinates] = Z;
				(*Co).experiment[TotalCoordinates] = study;
				TotalCoordinates++;
			}
		}
	}
	(*Co).TotalFoci=TotalCoordinates;

	if (MV)
		free(MV);

	return TotalCoordinates;

}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================
//generate Paper Experiments
//======================================================================================================
int GenerateExperiments(struct Image *mask)
{
	struct Coordinates Co;
	int Studies=30;///20 is few, 50 is moderate, 100 is a lot. 30 used in paper
	int Subjects=20;///20 is a good minimum, 50 is moderate
	double Zcensor=3.09;///typical
	int nRandomCoordinates=6;///same number of noise and cluster coordinates
	int nClusters=6;
	int cluster;
	int i,j;
	struct ThreeVector V[6];
	double mean[6];
	double Sigma[36];
	double v=1.0;
	double m=5.0;///mean is average
	double rho=0.707;///moderate correlation
	char fname[MAX_PATH];

	if (!(*mask).X)
		return 0;

	memset(&Co,0,sizeof(struct Coordinates));

	V[0].x=-34.0;
	V[0].y=50.0;
	V[0].z=18.0;
	V[1].x=0.0;
	V[1].y=44.0;
	V[1].z=18.0;
	V[2].x=34.0;
	V[2].y=50.0;
	V[2].z=18.0;
	V[3].x=-56.0;
	V[3].y=-66.0;
	V[3].z=18.0;
	V[4].x=0.0;
	V[4].y=-56.0;
	V[4].z=18.0;
	V[5].x=56.0;
	V[5].y=-66.0;
	V[5].z=18.0;

	memset(Sigma,0,sizeof(double)*36);
	//set mean and diagonal of Sigma
	for (cluster=0; cluster<nClusters; cluster++)
	{
		mean[cluster] = m;
		Sigma[cluster + cluster*nClusters]=v;
	}

	///experiment 1: all independent effect sizes
	Paper_netork_examples(&Co, mask, Studies, Subjects, Zcensor,
	                      4.0, V, nClusters, nRandomCoordinates,
	                      mean, Sigma);
	sprintf(fname,"%s\\NetworkIndependent.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 2: all independent effect sizes except between clusters 1,2
	Sigma[1]=rho*v;
	Sigma[6]=rho*v;
	Paper_netork_examples(&Co, mask, Studies, Subjects, Zcensor,
	                      4.0, V, nClusters, nRandomCoordinates,
	                      mean, Sigma);
	sprintf(fname,"%s\\Network_rho1.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 3: full network; all correlated
	for (i=0; i<6; i++)
	{
		for (j=0; j<6; j++)
		{
			if (i==j)
				Sigma[i+6*j]=v;
			else
				Sigma[i+6*j]=rho*v;
		}
	}
	Paper_netork_examples(&Co, mask, Studies, Subjects, Zcensor,
	                      4.0, V, nClusters, nRandomCoordinates,
	                      mean, Sigma);
	sprintf(fname,"%s\\Network_full.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);


	///experiment 4: two networks
	memset(Sigma,0,sizeof(double)*36);
	for (i=0; i<3; i++)
	{
		for (j=0; j<3; j++)
		{
			if (i==j)
				Sigma[i+6*j]=v;
			else
				Sigma[i+6*j]=rho*v;
		}
	}
	for (i=3; i<6; i++)
	{
		for (j=3; j<6; j++)
		{
			if (i==j)
				Sigma[i+6*j]=v;
			else
				Sigma[i+6*j]=rho*v;
		}
	}
	Paper_netork_examples(&Co, mask, Studies, Subjects, Zcensor,
	                      4.0, V, nClusters, nRandomCoordinates,
	                      mean, Sigma);
	sprintf(fname,"%s\\Network_2networks.txt",REPORT_FOLDER);
	SaveExperimentsALE(&Co, fname, (*mask).filename, 1.0, 0);
	FreeCoordinates(&Co);



	return 0;
}


//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//=====================================================================================================================
//test the fitting of a bivariate normal distribution
//first sample from a BVnorm with known parameters
//fit using maximum likelihood

//=====================================================================================================================

int TestFittingBivariateNorm(int Nsamples)
{
	struct Bivariate bv;
	struct BivariateSample BV;
	double *x=NULL;
	double *y=NULL;
	int i,iter;
	int iterations=50;
	int censored1,censored2;
	int intint=0;
	int result=0;
	int study;
	double mx,my,sx,sy,rho;
	double emx,emy,esx,esy,erho;
	double P[8];
	double p,pperm;
	FILE *fp;
	FILE *fp1;
	char fname[MAX_PATH];
	char fname1[MAX_PATH];

	memset(P,0,sizeof(double)*8);
	if (!(x=(double *)malloc(Nsamples*sizeof(double))))
		goto END;
	if (!(y=(double *)malloc(Nsamples*sizeof(double))))
		goto END;

	memset(&BV,0,sizeof(struct BivariateSample));


	sprintf(fname,"%s/CBMANtest/BVNfit_%d.csv",REPORT_FOLDER,Nsamples);
	if (!(fp=fopen(fname,"w")))
		return 0;

	MakeStructBivariateSample(&BV, Nsamples);

	fprintf(fp,"iter,p,ppermutation,mx,emx,my,emy,sx,esx,sy,esy,rho,erho,censored1,censored2,lsmx,lsmy,lssx,lssy,lsrho\n");
	for (iter=0; iter<iterations; iter++)
	{

		censored1=censored2=0;

		mx=0.6+(double)rand()/RAND_MAX*0.6;
		my=0.6+(double)rand()/RAND_MAX*0.6;
		sx=0.2+(double)rand()/RAND_MAX*0.4;//standard deviation
		sy=0.2+(double)rand()/RAND_MAX*0.4;//standard deviation
		rho=1.0-2.0*rand()/RAND_MAX;


		//get the sample
		for (i=0; i<Nsamples; i++)
		{
			rBivariateNorm(&bv, mx, my, sx, sy, rho);
			x[i]=bv.x;
			y[i]=bv.y;
		}
		sprintf(fname1,"%s/CBMANtest/data %d.csv",REPORT_FOLDER,iter);
		if ((fp1=fopen(fname1,"w")))
		{
			fprintf(fp1,"ES1,ES2\n");
			for (study=0; study<Nsamples; study++)
			{
				fprintf(fp1,"%f,%f\n",x[study],y[study]);
			}
			fclose(fp1);
		}
		emx=MeanValueDouble(Nsamples,x);
		emy=MeanValueDouble(Nsamples,y);
		esx=sqrt(Var(x,Nsamples));
		esy=sqrt(Var(y,Nsamples));
		erho=Pearsons(x,y,Nsamples);
		p=CorrelationPvalue(erho,Nsamples);

		for (i=0; i<Nsamples; i++)
		{
			BV.d1[i]=x[i];
			BV.d2[i]=y[i];
			BV.V[i]=0.1;
			BV.censor1[i]=NOT_CENSORED;
			BV.censor2[i]=NOT_CENSORED;
			BV.CensorLevel[i]=3.09/sqrt(20.0);


			if (rand()<RAND_MAX/10000)   //introduce LR censoring to 1 in 10 studies
			{
				if ((mx>0.0) && (BV.d1[i]>=BV.CensorLevel[i]))
					BV.censor1[i]=RIGHT_CENSORED;
				else if ((mx<0.0) && (BV.d1[i]<=-BV.CensorLevel[i]))
					BV.censor1[i]=LEFT_CENSORED;
				else
					BV.censor1[i]=INTERVAL_CENSORED;
				censored1++;

				if ((my>0.0) && (BV.d2[i]>=BV.CensorLevel[i]))
					BV.censor2[i]=RIGHT_CENSORED;
				else if ((my<0.0) && (BV.d2[i]<=-BV.CensorLevel[i]))
					BV.censor2[i]=LEFT_CENSORED;
				else
					BV.censor2[i]=INTERVAL_CENSORED;
				censored2++;

				BV.d1[i]=BV.d2[i]=0.0;
			}
			else
			{
				if (fabs(x[i])<BV.CensorLevel[i])
				{
					BV.d1[i]=0.0;
					BV.censor1[i]=INTERVAL_CENSORED;
					censored1++;
				}
				if (fabs(y[i])<BV.CensorLevel[i])
				{
					BV.d2[i]=0.0;
					BV.censor2[i]=INTERVAL_CENSORED;
					censored2++;
				}
			}

			if (BV.censor1[i]==INTERVAL_CENSORED && BV.censor2[i]==INTERVAL_CENSORED)
				intint++;
		}




		sprintf(fname1,"%s/CBMANtest/BVstruct %d.csv",REPORT_FOLDER,iter);
		if ((fp1=fopen(fname1,"w")))
		{
			fprintf(fp1,"StudyID,ES1,ES2,censorES,censoring1,censoring2,covariate\n");
			for (study=0; study<Nsamples; study++)
			{
				fprintf(fp1,"%s,%f,%f,%f,%s,%s,%f\n","",
				        BV.d1[study],
				        BV.d2[study],
				        BV.CensorLevel[study],
				        "", "",
				        BV.covariate[study]);
			}
			fclose(fp1);
		}
		///get initial estimates for optimisation
		GetInitialEstimates(P, &BV);
		P[RHO]=0.0;
		MaximumLogLikelihoodGivenStartingPoint(P, CBMAN_PARAMETERS, &BV);
		pperm=PvalueOfConnectionUsingPermutation(P, &BV, CBMAN_PERMUTATIONS, 7) ;

		fprintf(fp,"%d,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n",
		        iter,
		        p,pperm,
		        mx, P[MEANX],my, P[MEANY],
		        sx, sqrt(P[VARX]),sy, sqrt(P[VARY]),
		        rho, Sigmoidpm1(P[RHO]),100.0*censored1/Nsamples,100.0*censored2/Nsamples,
		        emx,emy,esx,esy,erho);

	}

	result=1;
END:
	if (fp)
		fclose(fp);
	FreeStructBivariateSample(&BV);

	if (x)
		free(x);
	if (y)
		free(y);

	return result;
}

//======================================================================================
int TestFittingBivariateNormSymmetry(int Nsamples)
{
	struct Bivariate bv;
	struct BivariateSample BV;
	double *x=NULL;
	double *y=NULL;
	int i;
	int censored1,censored2;
	int result=0;
	double mx,my,sx,sy,rho;
	double P1[8];
	double P2[8];
	double p1,p2;
	double rho1,rho2;
	FILE *fp;
	char fname[MAX_PATH];

	memset(P1,0,sizeof(double)*8);
	memset(P2,0,sizeof(double)*8);

	if (!(x=(double *)malloc(Nsamples*sizeof(double))))
		goto END;
	if (!(y=(double *)malloc(Nsamples*sizeof(double))))
		goto END;

	memset(&BV,0,sizeof(struct BivariateSample));


	sprintf(fname,"%s/BVNsymmetry_%d.csv",REPORT_FOLDER,Nsamples);
	if (!(fp=fopen(fname,"w")))
		return 0;

	MakeStructBivariateSample(&BV, Nsamples);

	fprintf(fp,"R, p\n");


	mx=0.8;
	my=0.8;
	sx=0.3;//standard deviation
	sy=0.3;//standard deviation
	rho=0.6;


	//get the sample
	for (i=0; i<Nsamples; i++)
	{
		rBivariateNorm(&bv, mx, my, sx, sy, rho);
		x[i]=bv.x;
		y[i]=bv.y;
	}

	censored1=censored2=0;
	//x,y
	for (i=0; i<Nsamples; i++)
	{
		BV.d1[i]=x[i];
		BV.d2[i]=y[i];
		BV.V[i]=0.0;
		BV.censor1[i]=NOT_CENSORED;
		BV.censor2[i]=NOT_CENSORED;
		BV.CensorLevel[i]=3.09/sqrt(20.0);

		if (fabs(x[i])<BV.CensorLevel[i])
		{
			BV.d1[i]=0.0;
			BV.censor1[i]=INTERVAL_CENSORED;
			censored1++;
		}
		if (fabs(y[i])<BV.CensorLevel[i])
		{
			BV.d2[i]=0.0;
			BV.censor2[i]=INTERVAL_CENSORED;
			censored2++;
		}

	}
	///get initial estimates for optimisation
	GetInitialEstimates(P1, &BV);
	P1[RHO]=0.0;
	MaximumLogLikelihoodGivenStartingPoint(P1, CBMAN_PARAMETERS, &BV);
	rho1=Sigmoidpm1(P1[RHO]);
	p1=PvalueOfConnectionUsingPermutation(P1, &BV, CBMAN_PARAMETERS, 7);

	fprintf(fp,"%f,%f,%d,%d,%f,%f\n\n",rho1,p1,censored1,censored2,P1[MEANX],P1[MEANY]);

	censored1=censored2=0;
	//y,x
	for (i=0; i<Nsamples; i++)
	{
		BV.d1[i]=y[i];
		BV.d2[i]=x[i];
		BV.V[i]=0.0;
		BV.censor1[i]=NOT_CENSORED;
		BV.censor2[i]=NOT_CENSORED;
		BV.CensorLevel[i]=3.09/sqrt(20.0);

		if (fabs(y[i])<BV.CensorLevel[i])
		{
			BV.d1[i]=0.0;
			BV.censor1[i]=INTERVAL_CENSORED;
			censored1++;
		}
		if (fabs(x[i])<BV.CensorLevel[i])
		{
			BV.d2[i]=0.0;
			BV.censor2[i]=INTERVAL_CENSORED;
			censored2++;
		}

	}
	///get initial estimates for optimisation
	GetInitialEstimates(P2, &BV);
	P2[RHO]=0.0;
	MaximumLogLikelihoodGivenStartingPoint(P2, CBMAN_PARAMETERS, &BV);
	rho2=Sigmoidpm1(P2[RHO]);
	p2=PvalueOfConnectionUsingPermutation(P2, &BV, CBMAN_PARAMETERS, 7);


	fprintf(fp,"%f,%f,%d,%d,%f,%f\n\n",rho2,p2,censored1,censored2,P2[MEANX],P2[MEANY]);


	result=1;
END:
	if (fp)
		fclose(fp);
	FreeStructBivariateSample(&BV);

	if (x)
		free(x);
	if (y)
		free(y);

	return result;
}

