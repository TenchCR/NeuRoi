/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "CoordinateDensityAnalysis.h"



/*
Correlations among Brain Gray Matter Volumes, Age,
Gender, and Hemisphere in Healthy Individuals
Yasuyuki Taki
*/
//Intracranial contents by volume (1,700 ml, 100%): brain = 1,400 ml (80%); blood = 150 ml (10%); cerebrospinal fluid = 150 ml (10%)
// (from Rengachary, S.S. and Ellenbogen, R.G., editors, Principles of Neurosurgery, Edinburgh: Elsevier Mosby, 2005)
//But used this instead:
//Brain size and grey matter volume in the healthy human brain
//Eileen Luders, Helmuth Steinmetz and Lutz Jancke
//DOI:10.1097/01.wnr.0000049603.85580.da
#define GM_VOLUME 780000.0
#define WM_VOLUME 390000.0
#define BRAIN_VOLUME (GM_VOLUME+WM_VOLUME)


#define NEAREST_TO_CLUSTER 4///NUMBER OF NEAREST NEIGHBOURS TO COORDINATE TO USE FOR DENSITY ESTIMATE
//If this is 3 then the number of coordinates (experiments) defining the volume is 4

///PARAMETERS LogOdds
#define SAMPLE_SIZE 0
#define CENSORLEVEL 1
#define COVARIANCE 2

#define BLR_PARAMETERS 3


///PARAMETERS FOR NETWORK
#define MEANX 0
#define MEANY 1
#define VARX 2
#define VARY 3
#define RHO 4
#define RHO2 5

#define EDGE_PARAMETERS 5
#define EDGE_PARAMETERS_GROUP 6

#define CLUSTERED_ONLY 1

#define MAX_FILES 20

int SaveBRLforAllClusters(struct Coordinates *C, int Nclusters, unsigned char FileNumber[], char fnames[], int Nfiles, double SD, char directory[]);
int SaveCDAM_BRLforAllClusters(struct Coordinates *C, int Nclusters, unsigned char FileNumber[], char fnames[], int Nfiles, double SD, char directory[]);
int ClusterDensityAnalysis(HWND hwnd, struct Coordinates *C, struct Image *img,
                           double volume, char coordinatedir[], double critical, int MinStudiesPerCluster);
int TestCDAwithRandom(HWND hwnd, struct Coordinates *C, struct Image *img,
                      double volume, char coordinatedir[], double critical, int MinStudiesPerCluster);

int ClusterDensityAnalysisMulti(HWND hwnd, struct Coordinates *C, int Nfiles, struct Image *img,
                                double volume, char coordinatedir[], double critical, int MinStudiesPerCluster);

int WholeBrainStudies(struct Coordinates *C);

int GetClusteringProbabilityForCoordinates(HWND hwnd, struct Coordinates *C, double volume, double critical);


double EstimateClusterRadiusforCoordinate(float xf[], float yf[], float zf[],
        short int iexp[], char VOI[], int experiment, int coordinate,
        int Nfoci, int Nexperiments, int NearestN, double MinRadius);

double HitRate(double Radius, double volume, int chances);
double PvalueOfCoordinate(int iexp, double HitProb[], char VOI[], int Nexperiments, int N);
int DesignMatrixForBLR(struct Coordinates *C, double *mat, int ParameterColumn[], double M[], double V[], unsigned char FileNumber[], int Nfiles);
int CDAMDesignMatrixForBLR(struct Coordinates *C, double *mat, int ParameterColumn[], double M[], double V[], unsigned char FileNumber[], int Nfiles);
int SaveCDAresults(struct Coordinates *C, double pthreshold, struct Image *image, char directory[], int MarkerSize);
int ReportClustersCDA(float x[], float y[], float z[], float Zsc[], short int cluster[], double p[], int Nfoci,
                      short int exprmnt[], int Nexperiments,
                      struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                      char directory[],
                      int X, int Y, int Z, float z0,
                      float dx, float dy, float dz,
                      float xc[], float yc[], float zc[], int Nclusters, double fdr, int MinStudiesPerCluster);
int SaveRGBclustersCDA(int FociVoxel[], short int cluster[], int Nfoci, struct Image *img, int Nclusters, int Marker, double kernelSD, char fname[], char directory[]);
int SaveEdgeAnalysis(HWND hwnd, struct Coordinates *C, float xp[], float yp[], float zp[], int Nclusters, int Compare, char directory[]);
int SaveTalairachNetworkProjectionCDA(HWND hwndMain,
                                      struct Coordinates *Co,
                                      double Rho[], double SE[],
                                      float xp[],float yp[], float zp[],
                                      int Nclusters,
                                      char directory[]);
int GetUncensoredData(struct Coordinates *C, int cl1, int cl2, double X[], double Y[], char directory[]);
double FillClusters(float x[], float y[], float z[], short int experiment[], short int cluster[], double p[], int Nfoci, int Nexperiments, int Nclusters, int *ClusterWith, double kernelSD, double pvalue);
double MaxDensityInExperiment(struct Coordinates *C, int iexp, int cluster, double sd, int *MostDenseCoordinate);
int ExperimentContributesToCluster(struct Coordinates *C, int iexp, int cluster);
double ClusterDensity(float x, float y, float z,float xf[], float yf[], float zf[], short int clusters[], int Nfoci,  int cluster, double sd);
int ClusterHoleFill(struct Coordinates *C, int Nclusters, double Dmax);
double CDAthreshold(struct Coordinates *C, double pvalue, int Nexpected);

int ForestPlotCDAR(struct Coordinates *c, struct EffectSample *Es, int cluster, char directory[]);
int SaveAllForestPlots(struct Coordinates *C, int Nclusters, char directory[]);

///=================================================================================================================
///=================================================================================================================
///=================================================================================================================
///=================================================================================================================
//==================================================================================================================
//==================================================================================================================
//=============================================================================================
//                         CDA dialog callback function
//=============================================================================================
INT_PTR CALLBACK CDA_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	int MarkerSize;
	double fdr;
	double volume;
	float MinStudiesProportion;
	int MinStudies;
	int Nstudies;
	static char directory[MAX_PATH];
	int i;
	static int NumberOfFiles;
	static struct Coordinates C[MAX_FILES];
	int tmp;
	char txt[256];

	switch (msg)
	{


	case WM_CLOSE:
		for (i=0; i<NumberOfFiles; i++)
		{
			if (C[i].Nexperiments)
				FreeCoordinates(&C[i]);
		}
		SetMenuItemState(GetParent(hwnd), MF_ENABLED);
		hCDAnalysis=(HWND)NULL;
		EndDialog(hwnd,0);
		break;



	case WM_SHOWWINDOW:
		//SET UP THE ROI OBJECT NUMBER SELECTION BOX
		SendMessage(GetDlgItem(hwnd,ID_COORDINATE_FILES),CB_RESETCONTENT,0,0);
		for (i=0; i<NumberOfFiles; i++)
		{
			SendMessage(GetDlgItem(hwnd,ID_COORDINATE_FILES),CB_ADDSTRING,0,(LPARAM)C[i].coordinate_file_name);
		}
		MarkerSize=3;
		sprintf(txt,"%d",MarkerSize);
		SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_SETTEXT, 0, (LPARAM)txt);
		fdr=0.05;
		sprintf(txt,"%3.2f",fdr);
		SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
		MinStudiesProportion=0.0;
		sprintf(txt,"%3.2f",MinStudiesProportion);
		SendMessage(GetDlgItem(hwnd,ID_MIN_STUDIES_TXT), WM_SETTEXT, 0, (LPARAM)txt);
		break;





	case WM_INITDIALOG:
		NumberOfFiles=0;
		sprintf(txt,"%d (GM)",(int)GM_VOLUME);
		SendMessage(GetDlgItem(hwnd,ID_TISSUE_VOLUMES),CB_ADDSTRING,0,(LPARAM)txt);
		sprintf(txt,"%d (WM)",(int)WM_VOLUME);
		SendMessage(GetDlgItem(hwnd,ID_TISSUE_VOLUMES),CB_ADDSTRING,0,(LPARAM)txt);
		sprintf(txt,"%d (WB)",(int)BRAIN_VOLUME);
		SendMessage(GetDlgItem(hwnd,ID_TISSUE_VOLUMES),CB_ADDSTRING,0,(LPARAM)txt);

		sprintf(txt,"%d",(int)GM_VOLUME);
		SendMessage(GetDlgItem(hwnd,ID_VOLUME_TXT),WM_SETTEXT,0,(LPARAM)txt);
		break;


	case WM_COMMAND:
		switch (LOWORD(wParam))
		{


		case ID_TISSUE_VOLUMES:
			i=SendMessage(GetDlgItem(hwnd,ID_TISSUE_VOLUMES),CB_GETCURSEL,0,0);
			SendMessage(GetDlgItem(hwnd,ID_TISSUE_VOLUMES),CB_GETLBTEXT,i,(LPARAM)txt);
			i=atoi(txt);
			sprintf(txt,"%6.1f",(float)i);
			if (!strlen(txt))
			{
				sprintf(txt,"%6.1f",GM_VOLUME);
			}
			SendMessage(GetDlgItem(hwnd,ID_VOLUME_TXT),WM_SETTEXT,0,(LPARAM)txt);
			break;

		case ID_ADD_COORDINATE_FILE:
			if (NumberOfFiles>=MAX_FILES)
			{
				MessageBox(NULL,"Maximum Number of files reached. Complain to Chris Tench.","",MB_OK|MB_ICONWARNING);
				break;
			}
			memset(&C[NumberOfFiles],0,sizeof(struct Coordinates));
			EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),FALSE);
			if (LoadExperimentsCOORDINATES(GetParent(hwnd), &C[NumberOfFiles], gImage.X,gImage.Y, gImage.Z,gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0))
			{
				SendMessage(GetDlgItem(hwnd,ID_COORDINATE_FILES),CB_ADDSTRING,0,(LPARAM)C[NumberOfFiles].coordinate_file_name);
				if (!NumberOfFiles)
				{
					tmp=DirectoryFileDivide(C[0].coordinate_file_name);
					sprintf(directory,"%s",C[0].coordinate_file_name);
					directory[tmp]='\0';
				}
				NumberOfFiles++;
			}
			else
			{
				MessageBox(hwnd,"Failed to add coordinate file","",MB_OK|MB_ICONWARNING);
			}
			EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),TRUE);
			break;

		case ID_RUN_DENSITY_ANALYSIS:
			EnableWindow(GetDlgItem(hwnd,ID_RUN_DENSITY_ANALYSIS),FALSE);

			SendMessage(GetDlgItem(hwnd,ID_MIN_STUDIES_TXT), WM_GETTEXT, 256, (LPARAM)txt);
			MinStudiesProportion=atof(txt);
			if (MinStudiesProportion>1.0)
			{
				EnableWindow(GetDlgItem(hwnd,ID_RUN_DENSITY_ANALYSIS),TRUE);
				MessageBox(NULL,"The study proportion should be >0.0 and <0.0", "", MB_OK);
				break;
			}
			Nstudies=0;
			for (i=0; i<NumberOfFiles; i++)
			{
				//Nstudies+=C[i].Nexperiments;
				Nstudies+=NumberOfIndependentStudies(&C[i]);
			}
			MinStudies=MinStudiesProportion*Nstudies;
			if (MinStudies<NEAREST_TO_CLUSTER+1)
			{
				MinStudies=NEAREST_TO_CLUSTER+1;
			}

			SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
			fdr=atof(txt);
			SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
			MarkerSize=atoi(txt);
			SendMessage(GetDlgItem(hwnd,ID_VOLUME_TXT), WM_GETTEXT, 256, (LPARAM)txt);
			volume=atof(txt);


			if (NumberOfFiles==1)
			{
				//TestCDAwithRandom(GetParent(hwnd), &C[0], &gImage, volume, directory, fdr,  MinStudies);
				ClusterDensityAnalysis(GetParent(hwnd), &C[0], &gImage, volume, directory, fdr, MinStudies);
			}
			else
			{
				ClusterDensityAnalysisMulti(GetParent(hwnd), C, NumberOfFiles, &gImage, volume, directory, fdr, MinStudies);
			}

			EnableWindow(GetDlgItem(hwnd,ID_RUN_DENSITY_ANALYSIS),TRUE);
			break;

		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
			break;
		}
		break;


	}
	return 0;
}

//==================================================================================================================
//==================================================================================================================
int ClusterDensityAnalysis(HWND hwnd, struct Coordinates *C, struct Image *img,
                           double volume, char coordinatedir[], double critical, int MinStudiesPerCluster)
{
	struct Coordinates CoCpy;
	int Nfoci, Nexperiments;
	int focus;
	int Nclusters=0;
	int iexp;
	unsigned char *FileNumber=NULL;
	double pvalue;
	float *xc=NULL;
	float *yc=NULL;
	float *zc=NULL;
	short int *SignificantFoci=NULL;
	char ResultName[MAX_PATH];
	char directory[MAX_PATH];
	char filename[MAX_PATH];
	int MarkerSize=DEFAULT_MARKER_SIZE;
	double width;

	///preprocess coordinates
	memset(&CoCpy,0,sizeof(struct Coordinates));
	if (!CopyCoordinates(C, &CoCpy))
	{
		goto END;
	}

	if (!MergeCoordinatesbyStudy(&CoCpy))
	{
		goto END;
	}
	sprintf(filename,"%s",(*C).coordinate_file_name);
	Nfoci=CoCpy.TotalFoci;
	Nexperiments=CoCpy.Nexperiments;
	CensorLevels(&CoCpy);
	GetTalairachLabels(&CoCpy);

	if (Nexperiments<(NEAREST_TO_CLUSTER+1) ||Nexperiments<MinStudiesPerCluster)
	{
		MessageBox(NULL,"Too few studies","",MB_OK|MB_ICONWARNING);
		goto END;
	}

	///reserve memory
	if (!(SignificantFoci=(short int *)calloc(Nfoci,sizeof(short int))))
	{
		goto END;
	}
	if (!(xc=(float *)malloc(sizeof(float)*Nfoci)))
	{
		goto END;
	}
	if (!(yc=(float *)malloc(sizeof(float)*Nfoci)))
	{
		goto END;
	}
	if (!(zc=(float *)malloc(sizeof(float)*Nfoci)))
	{
		goto END;
	}
	if (!(FileNumber=(unsigned char *)calloc(Nexperiments, sizeof(unsigned char))))
	{
		goto END;
	}

	//all experiments are from file 1 (the only file)
	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		FileNumber[iexp]=1;
	}


	sprintf(directory,"%s\\CDA",coordinatedir);
	CreateDirectory(directory,NULL);


	///preprocess
	CensorLevels(&CoCpy);

	///get the clustering probabilities
	GetClusteringProbabilityForCoordinates(hwnd, &CoCpy, volume, /*(double)MinStudiesPerCluster/Nfoci*/critical);
//memcpy((*C).p, CoCpy.p, sizeof(double)*Nfoci);

	pvalue=CDAthreshold(&CoCpy, critical, MinStudiesPerCluster);///THRESHOLD

	///CDA
	memset(CoCpy.cluster,0,sizeof(short int)*Nfoci);
	for (focus=0; focus<Nfoci; focus++)
	{
		if (CoCpy.p[focus]<=pvalue)
		{
			CoCpy.cluster[focus]=1;//needed for saving CDA results
			SignificantFoci[focus]=1;
		}
	}

	SaveCDAresults(&CoCpy, pvalue, img, directory, DEFAULT_MARKER_SIZE);


	width=OptimiseMeanShiftClusteringKernel(img, &CoCpy, SignificantFoci, xc, yc, zc, MinStudiesPerCluster, directory);

	Nclusters = GetValidMeanShiftClusters(img, &CoCpy, SignificantFoci, xc, yc, zc, MinStudiesPerCluster, width);
	//SaveClusterRadii(&CoCpy, xc, yc, zc, Nclusters);
	Nclusters=RenumberClusters2(CoCpy.cluster, CoCpy.TotalFoci, xc, yc, zc, MinStudiesPerCluster);


	//CDAprincipalComponenetAnalysis(&CoCpy, Nclusters, directory);

	//Fill the low density holes in the clusters
	ClusterHoleFill(&CoCpy, Nclusters, width);

	sprintf(ResultName,"%s//ProcessedCoordinates.txt",directory);
	SaveExperimentsALE(&CoCpy, ResultName, (*img).filename, pvalue, 1);



	ReportClustersCDA(CoCpy.x, CoCpy.y, CoCpy.z, CoCpy.Zsc, CoCpy.cluster, CoCpy.p, Nfoci,
	                  CoCpy.experiment, Nexperiments,
	                  CoCpy.ID, CoCpy.CTRST, CoCpy.CND,
	                  directory,
	                  (*img).X, (*img).Y, (*img).Z, (*img).z0,
	                  (*img).dx, (*img).dy, (*img).dz,
	                  xc, yc, zc, Nclusters, critical, MinStudiesPerCluster);



	SaveBRLforAllClusters(&CoCpy, Nclusters, FileNumber, filename,1, width, directory);
	SaveRGBclustersCDA(CoCpy.voxel, CoCpy.cluster, CoCpy.TotalFoci, img, Nclusters, MarkerSize, width, "ClustersRGB", directory);
	SaveEdgeAnalysis(hwnd, &CoCpy, xc, yc, zc, Nclusters, 0, directory);
	if (CoCpy.ZscoreUsed)
		SaveAllForestPlots(&CoCpy, Nclusters, directory);

END:
	if (SignificantFoci)
	{
		free(SignificantFoci);
	}
	if (xc)
	{
		free(xc);
	}
	if (yc)
	{
		free(yc);
	}
	if (zc)
	{
		free(zc);
	}
	if (FileNumber)
	{
		free(FileNumber);
	}
	FreeCoordinates(&CoCpy);
	return Nclusters;
}
//====================================
int TestCDAwithRandom(HWND hwnd, struct Coordinates *C, struct Image *img,
                      double volume, char coordinatedir[], double critical, int MinStudiesPerCluster)
{
	int i;
	int Nclusters;
	int Nfoci=(*C).TotalFoci;
	int focus;
	FILE *fp;
	char fname[MAX_PATH];
	struct Coordinates Cpy;
	double P[1001];

	memset(P,0,sizeof(double)*1001);

	memset(&Cpy,0,sizeof(struct Coordinates));
	CopyCoordinates(C, &Cpy);

	//do this so that the analysis is exactly on this experiment structure
	if (!MergeCoordinatesbyStudy(&Cpy))
	{
		goto END;
	}

	sprintf(fname,"%s\\randomCDA.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");
	fclose(fp);

	for (i=0; i<500; i++)
	{
		memcpy(Cpy.x, (*C).x, sizeof(float)*Nfoci);
		memcpy(Cpy.y, (*C).y, sizeof(float)*Nfoci);
		memcpy(Cpy.z, (*C).z, sizeof(float)*Nfoci);

		RandomiseCoordinatesForTesting((*img).img, (*img).X, (*img).Y, (*img).Z, (*img).dx, (*img).dy, (*img).dz, (*img).x0, (*img).y0, (*img).z0, &Cpy, 0.01);
		for (focus=0; focus<Nfoci; focus++)
		{
			Cpy.voxel[focus] = FociVoxelALE(Cpy.x[focus], Cpy.y[focus], Cpy.z[focus], (*img).X, (*img).Y, (*img).Z, (*img).dx, (*img).dy, (*img).dz, (*img).x0, (*img).y0, (*img).z0);
		}
		Nclusters=ClusterDensityAnalysis(hwnd, &Cpy, img, volume, coordinatedir, critical, MinStudiesPerCluster);

		for (focus=0; focus<Nfoci; focus++)
		{
			if (Cpy.p[focus]<0.05)
			{
				P[(int)(20000*Cpy.p[focus])]+=1.0;
			}
		}

		fp=fopen(fname,"a");
		fprintf(fp,"%d,%d\n",i,Nclusters);
		fclose(fp);
	}

	for (i=1; i<1001; i++)
	{
		P[i]+=P[i-1];
	}
	sprintf(fname,"%s\\randomCDApvalues %d.csv",REPORT_FOLDER,NEAREST_TO_CLUSTER);
	fp=fopen(fname,"w");
	for (i=1; i<1001; i++)
	{
		fprintf(fp,"%f,%f\n",0.05*i/1000, 0.05*P[i]/P[1000]);
	}
	fclose(fp);

END:
	FreeCoordinates(&Cpy);
	return 0;
}
//=================================================================================================================
//=================================================================================================================
int ClusterDensityAnalysisMulti(HWND hwnd, struct Coordinates *C, int Nfiles, struct Image *img,
                                double volume, char coordinatedir[], double critical, int MinStudiesPerCluster)
{

	int ZscoreUsed=1;
	struct  Coordinates CoApp;//the appended coordinate files
	int file;
	int TotalFoci, Nexperiments;
	int focus;
	int Nclusters;
	int tmp;
	int iexp;
	double pvalue;
	unsigned char *FileNumber=NULL;
	float *xc=NULL;
	float *yc=NULL;
	float *zc=NULL;
	short int *SignificantFoci=NULL;
	char filenames[MAX_FILES*MAX_PATH];
	char ResultName[MAX_PATH];
	char directory[MAX_PATH];
	int MarkerSize=DEFAULT_MARKER_SIZE;
	double width=0.0;


	memset(&CoApp,0,sizeof(struct Coordinates));

	if (Nfiles>MAX_FILES)
	{
		MessageBox(NULL,"Too many coordinate files. Complain to author","",MB_OK|MB_ICONWARNING);
		goto END;
	}

	//preprocess the files
	TotalFoci=0;
	for (file=0; file<Nfiles; file++)
	{
		if (!MergeCoordinatesbyStudy(&C[file]))
			goto END;

		CensorLevels(&C[file]);

		GetTalairachLabels(&C[file]);

		TotalFoci+=C[file].TotalFoci;
	}

	for (file=0; file<Nfiles; file++)
	{

		//get the clustering probabilities
		GetClusteringProbabilityForCoordinates(hwnd, &C[file], volume, critical);

		if (!C[file].ZscoreUsed)
		{
			ZscoreUsed=0;
		}

		sprintf(&filenames[file*MAX_PATH],"%s",C[file].coordinate_file_name);

	}

	//Append the coordinates into CoApp
	if (!CopyCoordinates(&C[0], &CoApp))
	{
		goto END;
	}
	for (file=1; file<Nfiles; file++)
	{
		if (!AppendCoordinates(&CoApp, &C[file]))
			goto END;
	}
	TotalFoci=CoApp.TotalFoci;
	Nexperiments=CoApp.Nexperiments;
	CoApp.ZscoreUsed=ZscoreUsed;
	if (!CoApp.ZscoreUsed)
	{
		//cant add the Zcensor to the BLR model unless all files include Z scores
		memset(CoApp.Zcensor,0,sizeof(float)*CoApp.Nexperiments);
	}

	if (!(SignificantFoci=(short int *)calloc(TotalFoci,sizeof(short int))))
	{
		goto END;
	}
	if (!(xc=(float *)malloc(sizeof(float)*TotalFoci)))
	{
		goto END;
	}
	if (!(yc=(float *)malloc(sizeof(float)*TotalFoci)))
	{
		goto END;
	}
	if (!(zc=(float *)malloc(sizeof(float)*TotalFoci)))
	{
		goto END;
	}
	if (!(FileNumber=(unsigned char *)calloc(Nexperiments, sizeof(unsigned char))))
	{
		goto END;
	}

	pvalue=CDAthreshold(&CoApp, critical, MinStudiesPerCluster);///THRESHOLD
	for (focus=0; focus<TotalFoci; focus++)
	{
		if (CoApp.p[focus]<=pvalue)
		{
			CoApp.cluster[focus]=1;
			SignificantFoci[focus]=1;
		}
		else
			CoApp.cluster[focus]=0;
	}



	//set the FileNumber array so know which experiments belong to which file
	tmp=0;
	for (file=0; file<Nfiles; file++)
	{
		for (iexp=tmp; iexp<tmp+C[file].Nexperiments; iexp++)
		{
			FileNumber[iexp] = file+1;
		}
		tmp+=C[file].Nexperiments;
	}

	sprintf(directory,"%s\\CDAM",coordinatedir);
	CreateDirectory(directory,NULL);


	SaveCDAresults(&CoApp, pvalue, img, directory, DEFAULT_MARKER_SIZE);

	width=OptimiseMeanShiftClusteringKernel(img, &CoApp, SignificantFoci, xc, yc, zc, MinStudiesPerCluster, directory);

	Nclusters = GetValidMeanShiftClusters(img, &CoApp, SignificantFoci, xc, yc, zc, MinStudiesPerCluster, width);
	Nclusters=RenumberClusters2(CoApp.cluster, CoApp.TotalFoci, xc, yc, zc, MinStudiesPerCluster);

	ClusterHoleFill(&CoApp, Nclusters, width);

	sprintf(ResultName,"%s//ProcessedCoordinates.txt",directory);
	SaveExperimentsALE(&CoApp, ResultName, (*img).filename, pvalue, 1);


	ReportClustersCDA(CoApp.x, CoApp.y, CoApp.z, CoApp.Zsc, CoApp.cluster, CoApp.p, TotalFoci,
	                  CoApp.experiment, CoApp.Nexperiments,
	                  CoApp.ID, CoApp.CTRST, CoApp.CND,
	                  directory,
	                  (*img).X, (*img).Y, (*img).Z, (*img).z0,
	                  (*img).dx, (*img).dy, (*img).dz,
	                  xc, yc, zc, Nclusters, critical, MinStudiesPerCluster);

	SaveBRLforAllClusters(&CoApp, Nclusters, FileNumber, filenames, Nfiles, width, directory);
	SaveCDAM_BRLforAllClusters(&CoApp, Nclusters, FileNumber, filenames, Nfiles, width, directory);
	SaveRGBclustersCDA(CoApp.voxel, CoApp.cluster, CoApp.TotalFoci, img, Nclusters, MarkerSize, width, "ClustersRGB", directory);
	if (CoApp.ZscoreUsed)
		SaveEdgeAnalysis(hwnd, &CoApp, xc, yc, zc, Nclusters, 0, directory);


END:
	if (SignificantFoci)
	{
		free(SignificantFoci);
	}
	if (xc)
	{
		free(xc);
	}
	if (yc)
	{
		free(yc);
	}
	if (zc)
	{
		free(zc);
	}
	if (FileNumber)
	{
		free(FileNumber);
	}
	FreeCoordinates(&CoApp);

	return 0;
}

//=================================================================================================================
//=================================================================================================================
/*
Given the coordinates and a volume, work out the clustering probability for each coordinate
*/
//=================================================================================================================
int GetClusteringProbabilityForCoordinates(HWND hwnd, struct Coordinates *C, double volume, double Pthresh)
{
	int Nexperiments=(*C).Nexperiments;
	int Nfoci=(*C).TotalFoci;
	int focus;
	int iexp;
	double Radius, Rmax;
	double *HitProb=NULL;//probability an experiment will have a hit within a radius
	int *chances=NULL;//number of coordinates; chances to fall in specified volume
	double MinRadius;
	HDC hDC=GetDC(hwnd);
	char txt[256];
//FILE *fp;


///File to confirm that Radius and p-value are monotonically related, which they are
//fp=fopen("c:\\temp\\GetClusterProb.csv","w");

	MinRadius=1.24;//THE CHARACHTERISTIC RADIUS FOR THE VOLUME OF A VOXEL 2x2x2mm
	//MinRadius=0.62;//THE CHARACHTERISTIC RADIUS FOR THE VOLUME OF A VOXEL 1x1x1mm

	if (!(HitProb=(double *)malloc(Nexperiments*sizeof(double))))
	{
		goto END;
	}
	if (!(chances=(int *)calloc(Nexperiments,sizeof(int))))
	{
		goto END;
	}


	//number of coordinates in each experiment
	for (focus=0; focus<Nfoci; focus++)
	{
		chances[(*C).experiment[focus]]++;
	}

	//Get characteristic radius estimates
	for (focus=0; focus<Nfoci; focus++)
	{
		(*C).p[focus]=1.0;
	}

	Rmax=DBL_MAX;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (!(*C).VOI[(*C).experiment[focus]])
		{

			Radius = EstimateClusterRadiusforCoordinate((*C).x, (*C).y, (*C).z,
			         (*C).experiment, (*C).VOI, (*C).experiment[focus], focus,
			         Nfoci, (*C).Nexperiments, NEAREST_TO_CLUSTER, MinRadius);

			if (Radius<Rmax)
			{
				for (iexp=0; iexp<Nexperiments; iexp++)
				{
					HitProb[iexp]=HitRate(Radius, volume, chances[iexp]);
				}


				//the probability of clustering with MORE THAN NEAREST_TO_CLUSTER
				(*C).p[focus]=PvalueOfCoordinate((*C).experiment[focus], HitProb, (*C).VOI, Nexperiments,NEAREST_TO_CLUSTER);


				//fprintf(fp,"%d,%f,%f\n ",focus, Radius, (*C).p[focus]);

				if ((*C).p[focus]>Pthresh && Radius<Rmax)
				{
					Rmax=Radius;
				}
			}
			else
			{
				(*C).p[focus]=1.0;
			}

			sprintf(txt,"%d of %d   ",focus+1, Nfoci);
			TextOut(hDC, 100,100,txt,strlen(txt));
			RemoveInput(hwnd);
			UpdateWindow(hwnd);

		}

	}

//fclose(fp);



END:

	if (HitProb)
	{
		free(HitProb);
	}
	if (chances)
	{
		free(chances);
	}
	ReleaseDC(hwnd,hDC);

	return 1;
}
//======================================================================================
//dm2[] is an NfocixNfoci matrix of squared distances
double RadiusSquared(float *xc, float *yc, float *zc, float xf[], float yf[], float zf[], int Nfoci, char VOI[], short int iexp[], int Nexperiments, int coordinate, int NearestN);
double EstimateClusterRadiusforCoordinate(float xf[], float yf[], float zf[],
        short int iexp[], char VOI[], int experiment, int coordinate,
        int Nfoci, int Nexperiments, int NearestN, double MinRadius)
{

	double Radius=0.0;
	double Radius2;
	float mx,my,mz;
	double r2A,r2B;

	mx=xf[coordinate];
	my=yf[coordinate];
	mz=zf[coordinate];

	r2A = RadiusSquared(&mx, &my, &mz, xf, yf, zf, Nfoci, VOI, iexp, Nexperiments, coordinate, NearestN);

	r2B = RadiusSquared(&mx, &my, &mz, xf, yf, zf, Nfoci, VOI, iexp, Nexperiments, coordinate, NearestN);

	if (r2B<r2A)
		Radius2=r2B;
	else
		Radius2=r2A;

	Radius=sqrt(Radius2);
	if (Radius<MinRadius)
	{
		Radius=MinRadius;
	}

	return Radius;
}
//========================================================================================
double RadiusSquared(float *xc, float *yc, float *zc, float xf[], float yf[], float zf[], int Nfoci, char VOI[], short int iexp[], int Nexperiments, int coordinate, int NearestN)
{
	int experiment=iexp[coordinate];
	int focus;
	int *sort=NULL;
	int e;
	int count;
	double *min2dist=NULL;
	double Radius2;
	double d2;
	float *x=NULL;
	float *y=NULL;
	float *z=NULL;
	double mx,my,mz;


	if (!(sort=(int *)malloc(Nexperiments*sizeof(int))))
	{
		goto END;
	}
	if (!(min2dist=(double *)malloc(Nexperiments*sizeof(double))))
	{
		goto END;
	}
	if (!(x=(float *)malloc(Nexperiments*sizeof(float))))
	{
		goto END;
	}

	if (!(y=(float *)malloc(Nexperiments*sizeof(float))))
	{
		goto END;
	}

	if (!(z=(float *)malloc(Nexperiments*sizeof(float))))
	{
		goto END;
	}

	for (e=0; e<Nexperiments; e++)
	{
		min2dist[e]=DBL_MAX;
	}

	min2dist[experiment]=0.0;
	x[experiment]=xf[coordinate];
	y[experiment]=yf[coordinate];
	z[experiment]=zf[coordinate];
	for (focus=0; focus<Nfoci; focus++)
	{
		e=iexp[focus];
		if (e!=experiment && !VOI[e])
		{
			d2=((*xc)-xf[focus])*((*xc)-xf[focus]) +
			   ((*yc)-yf[focus])*((*yc)-yf[focus]) +
			   ((*zc)-zf[focus])*((*zc)-zf[focus]);

			if (d2<min2dist[e])
			{
				min2dist[e]=d2;
				x[e]=xf[focus];
				y[e]=yf[focus];
				z[e]=zf[focus];
			}
		}
	}

	QuickSort(min2dist,sort,Nexperiments);

	mx=xf[coordinate];
	my=yf[coordinate];
	mz=zf[coordinate];
	count=1;
	for (e=0; e<Nexperiments && count<=NearestN; e++)
	{
		if (sort[e]!=experiment && !VOI[e])
		{
			mx+=x[sort[e]];
			my+=y[sort[e]];
			mz+=z[sort[e]];
			count++;
		}
	}

	mx/=(NearestN+1);
	my/=(NearestN+1);//the middle of the cluster
	mz/=(NearestN+1);
	(*xc)=mx;
	(*yc)=my;
	(*zc)=mz;

	Radius2=(mx-xf[coordinate])*(mx-xf[coordinate]) + (my-yf[coordinate])*(my-yf[coordinate]) + (mz-zf[coordinate])*(mz-zf[coordinate]);
	count=1;
	for (e=0; e<Nexperiments && count<=NearestN; e++)
	{
		if (sort[e]!=experiment && !VOI[sort[e]])
		{
			d2=(mx-x[sort[e]])*(mx-x[sort[e]]) + (my-y[sort[e]])*(my-y[sort[e]]) + (mz-z[sort[e]])*(mz-z[sort[e]]);
			if (d2>Radius2)
			{
				Radius2=d2;
			}
			count++;
		}
	}

END:

	if (sort)
	{
		free(sort);
	}
	if (min2dist)
	{
		free(min2dist);
	}
	if (x)
	{
		free(x);
	}
	if (y)
	{
		free(y);
	}
	if (z)
	{
		free(z);
	}
	return Radius2;
}
//========================================================================================
double HitRate(double Radius, double volume, int chances)
{
	double dV=4.1888*Radius*Radius*Radius;//volume of sphere

	if (dV>=volume)
		return 1.0;

	//return dV*chances/volume;
	return 1.0 - pow(1.0-dV/volume, chances);//(1-dV/volume)^chances is the probability of no hits
}
//==========================================================================================
//THIS IS THE PROBABILITY OF HAVING MORE THAN N STUDIES REPORT GIVEN THE HitProbs
double PvalueOfCoordinate(int iexp, double HitProb[], char VOI[], int Nexperiments, int N)
{
	double p;
	double *pn=NULL;
	double tmp;
	double l;
	double L_DBL_MIN=log(DBL_MIN);
	int *set=NULL;
	int e;
	int n;
	int success;
	int invalid;
	int *hit=NULL;
	double *lg_tmp=NULL;
	double *lg_1_tmp=NULL;

	/*FILE *fp;
	char fname[MAX_PATH];

	sprintf(fname,"%s//clusterprobs.csv",REPORT_FOLDER);
	if (!(fp=fopen(fname,"w")))
		goto END;*/

	if (!(set=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(hit=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(pn=(double *)calloc(Nexperiments+1,sizeof(double))))
		goto END;
	if (!(lg_tmp=(double *)malloc(Nexperiments*sizeof(double))))
		goto END;
	if (!(lg_1_tmp=(double *)malloc(Nexperiments*sizeof(double))))
		goto END;

	//lookup for speedup
	for (e=0; e<Nexperiments; e++)
	{
		tmp=HitProb[e];
		if (tmp>DBL_MIN)
		{
			lg_tmp[e]=log(tmp);
		}
		else
		{
			lg_tmp[e]=log(DBL_MIN);
		}

		if (tmp<1.0)
		{
			lg_1_tmp[e]=log(1.0-tmp);
		}
		else
		{
			lg_1_tmp[e]=L_DBL_MIN;
		}
	}
	//zero random contributions to cluster
	if (N<0)
		pn[0]=0.0;
	else
	{
		l=0.0;
		for (e=0; e<Nexperiments; e++)
		{
			//if ((e != iexp) && (!VOI[e]))
			if ((!VOI[e]))
			{
				tmp=1.0-HitProb[e];
				if (tmp>DBL_MIN)
					//l += log(tmp);
					l+=lg_1_tmp[e];
				else
					l += L_DBL_MIN;
			}
		}
		pn[0]=exp(l);
	}

	/*
		fprintf(fp,"0,");
		for (e=0; e<Nexperiments; e++)
		{
			fprintf(fp,"%f,",1.0-HitProb[e]);
		}
		for (e=0; e<Nexperiments; e++)
		{
			if (e==iexp)
				fprintf(fp,"*,");
			else
				fprintf(fp,"0,");
		}
		fprintf(fp,"\n");
	*/

	for (n=1; n<=N; n++)
	{
		memset(set,0,Nexperiments*sizeof(int));
		for (e=0; e<n; e++)
			set[e]=n-1-e;

		do
		{
			memset(hit,0,Nexperiments*sizeof(int));
			invalid=0;
			for (e=0; e<n; e++)
			{
				//if (set[e]==iexp || VOI[set[e]])//don't consider the focus experiment, or any experiment that is VOI
				if (VOI[set[e]])//don't consider the focus experiment, or any experiment that is VOI
				{
					invalid=1;
				}
				hit[set[e]]=1;
			}


			if (!invalid)
			{
				l=0.0;
				for (e=0; e<Nexperiments; e++)
				{
					//if ((e != iexp) && (!VOI[e]))
					if (!VOI[e])
					{
						tmp=HitProb[e];
						if (hit[e])
						{
							if (tmp>DBL_MIN)
								//l+=log(tmp);
								l+=lg_tmp[e];
							else
								l+=L_DBL_MIN;
						}
						else
						{
							if (tmp<1.0)
								//l+=log(1.0-tmp);
								l+=lg_1_tmp[e];
							else
								l+=L_DBL_MIN;
						}
					}
				}
				//p+=exp(l);
				pn[n]+=exp(l);
			}


			/*
						fprintf(fp,"%d,",n);
						for (e=0; e<Nexperiments; e++)
						{
							if (hit[e])
								fprintf(fp,"%f,",HitProb[e]);
							else
								fprintf(fp,"%f,",1.0-HitProb[e]);
						}
						for (e=0; e<Nexperiments; e++)
						{
							if (e==iexp)
								fprintf(fp,"*,");
							else
								fprintf(fp,"%d,",hit[e]);
						}
						fprintf(fp,"\n");
			*/

			success = NextPermutation(set, n-1, Nexperiments-1);
		}
		while (success);
	}

	p=0.0;
	for (n=N; n>=0; n--)
		p+=pn[n];


END:
	if (set)
		free(set);
	if (hit)
		free(hit);
	if (pn)
		free(pn);
	if (lg_tmp)
		free(lg_tmp);
	if (lg_1_tmp)
		free(lg_1_tmp);
	//if (fp)
	//fclose(fp);


	return 1.0-p;
}
//==============================
int TestPvalueOfCoordinate(void)
{
	double HitProb[20];
	int Nexperiments=10;
	char VOI[20];
	int N=-1;
	int iexp=-1;
	int i,j;
	double p;
	char txt[256];

	for (j=0; j<1; j++)
	{
		for (i=0; i<Nexperiments; i++)
			HitProb[i]=(double)rand()/RAND_MAX/10;

		memset(VOI,0,20);
		p=PvalueOfCoordinate(iexp, HitProb, VOI, Nexperiments, N);
		sprintf(txt,"%f",p);
		MessageBox(NULL,txt,"",MB_OK);
	}
	return 0;
}
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///=========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///========================================================================================================
///Design matrix
//mat should be (*C).Nexperiments * 4
//BLR_PARAMETERS parameters are:
/*
1) LODDS constant log odds ratio
2) SAMPLE_SIZE Sample size if not all equal
3) STATS_THRESHOLD Threshold if not all equal
4) COVARIANCE Covariance if not all equal
*/
int DesignMatrixForBLR(struct Coordinates *C, double *mat, int ParameterColumn[], double M[], double V[], unsigned char FileNumber[], int Nfiles)
{
	int Nexp=(*C).Nexperiments;
	int iexp, experiment;
	int Ncolumns=0;
	int Ncovariates;
	int CS;
	double *Ssize=NULL;
	double *Censor=NULL;
	double *COV=NULL;

	ParameterColumn[SAMPLE_SIZE]=-1;
	ParameterColumn[CENSORLEVEL]=-1;
	ParameterColumn[COVARIANCE]=-1;

	if (!(Ssize=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}

	if (!(Censor=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}

	if (!(COV=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}


	///is sample size different between studies?
	CS=IsContrastStudy(C);
	experiment=0;
	if (CS)
	{
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Ssize[experiment]=sqrt((double)(*C).SubjectsInExp[iexp]*(*C).ControlsInExp[iexp]/((*C).SubjectsInExp[iexp]+(*C).ControlsInExp[iexp]));
				experiment++;
			}
		}
	}
	else
	{
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Ssize[experiment]=sqrt((double)(*C).SubjectsInExp[iexp]);
				experiment++;
			}
		}
	}
	V[SAMPLE_SIZE]=Var(Ssize, experiment);
	if (V[SAMPLE_SIZE]>0.1)
	{
		ParameterColumn[SAMPLE_SIZE]=Ncolumns;
		Ncolumns++;
		M[SAMPLE_SIZE]=MeanValueDouble(Nexp, Ssize);
	}


	///Censor
	if ((*C).ZscoreUsed)
	{
		experiment=0;
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Censor[experiment]=(*C).Zcensor[iexp];
				experiment++;
			}
		}
		V[CENSORLEVEL]=Var(Censor, experiment);

		ParameterColumn[CENSORLEVEL]=Ncolumns;
		Ncolumns++;
		M[CENSORLEVEL]=MeanValueDouble(Nexp, Censor);
	}





	///covariate
	experiment=0;
	for (iexp=0; iexp<Nexp; iexp++)
	{
		if (!(*C).VOI[iexp])
		{
			COV[experiment]=(*C).covariate[iexp];
			experiment++;
		}
	}
	V[COVARIANCE]=Var(COV, experiment);
	if (V[COVARIANCE]>DBL_MIN)
	{
		ParameterColumn[COVARIANCE]=Ncolumns;
		Ncolumns++;
		M[COVARIANCE]=MeanValueDouble(Nexp, COV);
	}


	///Add the columns for the files
	Ncovariates=Ncolumns;
	Ncolumns+=Nfiles;

	///Fill the matrix
	//independent variables are mean centred and scaled by SD
	experiment=0;
	for (iexp=0; iexp<Nexp; iexp++)
	{
		if (!(*C).VOI[iexp])
		{

			if (ParameterColumn[SAMPLE_SIZE]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[SAMPLE_SIZE]]=(Ssize[experiment]-M[SAMPLE_SIZE])/sqrt(V[SAMPLE_SIZE]);
			}

			if (ParameterColumn[CENSORLEVEL]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[CENSORLEVEL]]=(Censor[experiment]-M[CENSORLEVEL])/sqrt(V[CENSORLEVEL]);
			}

			if (ParameterColumn[COVARIANCE]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[COVARIANCE]]=(COV[experiment]-M[COVARIANCE])/sqrt(V[COVARIANCE]);
			}

			if (FileNumber[iexp])
			{
				mat[experiment*Ncolumns + Ncovariates + FileNumber[iexp]-1]=1.0;
			}

			experiment++;
		}
	}


END:
	if (Ssize)
		free(Ssize);
	if (Censor)
		free(Censor);
	if (COV)
		free(COV);

	return Ncolumns;
}
//=============================================================================================
//=============================================================================================
int CDAMDesignMatrixForBLR(struct Coordinates *C, double *mat, int ParameterColumn[], double M[], double V[], unsigned char FileNumber[], int Nfiles)
{
	int Nexp=(*C).Nexperiments;
	int iexp, experiment;
	int Ncolumns=0;
	int Ncovariates;
	int CS;
	double *Ssize=NULL;
	double *Censor=NULL;
	double *COV=NULL;

	ParameterColumn[SAMPLE_SIZE]=-1;
	ParameterColumn[CENSORLEVEL]=-1;
	ParameterColumn[COVARIANCE]=-1;

	if (!(Ssize=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}

	if (!(Censor=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}

	if (!(COV=(double *)malloc(Nexp*sizeof(double))))
	{
		goto END;
	}


	///is sample size different between studies?
	CS=IsContrastStudy(C);
	experiment=0;
	if (CS)
	{
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Ssize[experiment]=sqrt((double)(*C).SubjectsInExp[iexp]*(*C).ControlsInExp[iexp]/((*C).SubjectsInExp[iexp]+(*C).ControlsInExp[iexp]));
				experiment++;
			}
		}
	}
	else
	{
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Ssize[experiment]=sqrt((double)(*C).SubjectsInExp[iexp]);
				experiment++;
			}
		}
	}
	V[SAMPLE_SIZE]=Var(Ssize, experiment);
	if (V[SAMPLE_SIZE]>0.1)
	{
		ParameterColumn[SAMPLE_SIZE]=Ncolumns;
		Ncolumns++;
		M[SAMPLE_SIZE]=MeanValueDouble(Nexp, Ssize);
	}


	///Censor
	if ((*C).ZscoreUsed)
	{
		experiment=0;
		for (iexp=0; iexp<Nexp; iexp++)
		{
			if (!(*C).VOI[iexp])
			{
				Censor[experiment]=(*C).Zcensor[iexp];
				experiment++;
			}
		}
		V[CENSORLEVEL]=Var(Censor, experiment);

		ParameterColumn[CENSORLEVEL]=Ncolumns;
		Ncolumns++;
		M[CENSORLEVEL]=MeanValueDouble(Nexp, Censor);
	}





	///covariate
	experiment=0;
	for (iexp=0; iexp<Nexp; iexp++)
	{
		if (!(*C).VOI[iexp])
		{
			COV[experiment]=(*C).covariate[iexp];
			experiment++;
		}
	}
	V[COVARIANCE]=Var(COV, experiment);
	if (V[COVARIANCE]>DBL_MIN)
	{
		ParameterColumn[COVARIANCE]=Ncolumns;
		Ncolumns++;
		M[COVARIANCE]=MeanValueDouble(Nexp, COV);
	}


	///Add the columns for the files
	Ncovariates=Ncolumns;
	Ncolumns+=2;

	///Fill the matrix
	//independent variables are mean centred and scaled by SD
	experiment=0;
	for (iexp=0; iexp<Nexp; iexp++)
	{
		if (!(*C).VOI[iexp])
		{

			if (ParameterColumn[SAMPLE_SIZE]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[SAMPLE_SIZE]]=(Ssize[experiment]-M[SAMPLE_SIZE])/sqrt(V[SAMPLE_SIZE]);
			}

			if (ParameterColumn[CENSORLEVEL]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[CENSORLEVEL]]=(Censor[experiment]-M[CENSORLEVEL])/sqrt(V[CENSORLEVEL]);
			}

			if (ParameterColumn[COVARIANCE]>=0)
			{
				mat[experiment*Ncolumns+ParameterColumn[COVARIANCE]]=(COV[experiment]-M[COVARIANCE])/sqrt(V[COVARIANCE]);
			}


			mat[experiment*Ncolumns + Ncovariates]=1.0;
			if (FileNumber[iexp]==1)
			{
				mat[experiment*Ncolumns + Ncovariates+1]=1.0;//the difference parameter for file 1
			}

			experiment++;
		}
	}


END:
	if (Ssize)
		free(Ssize);
	if (Censor)
		free(Censor);
	if (COV)
		free(COV);

	return Ncolumns;
}
//=============================================================================================
//=============================================================================================
//In R need '/' rather than '\' so they get exchanged here
int ConvertToFileFormat(char fname[])
{
	int i;
	char fs=92;
	char bs=47;
	for (i=0; i<strlen(fname); i++)
	{
		if (fname[i]==fs)
			fname[i]=bs;
	}
	return 0;
}
//=============================================================================================
double Residual(double *X, char resp[], double param[], int Nparams, int Nexperiments, int study)
{
	int i;
	double sum=0.0;
	double p;

	for (i=0; i<Nparams; i++)
	{
		sum += param[i]*X[study*Nparams + i];
	}
	p = InvLogOdds(sum);

	return p-resp[study];

}
//=============================================================================================
double MaxDensityInExperiment(struct Coordinates *C, int iexp, int cluster, double sd, int *MostDenseCoordinate)
{
	int focus;
	double D, maxD=0.0;
	int Nfoci=(*C).TotalFoci;
	float xf,yf,zf;

	(*MostDenseCoordinate)=-1;

	for (focus=0; focus<Nfoci; focus++)
	{
		xf=(*C).x[focus];
		yf=(*C).y[focus];
		zf=(*C).z[focus];
		if ((*C).experiment[focus]==iexp && ((*C).cluster[focus]==cluster || !(*C).cluster[focus]))
		{
			D=ClusterDensity(xf,yf,zf,(*C).x, (*C).y, (*C).z, (*C).cluster, Nfoci,cluster,sd);
			if (D>maxD)
			{
				maxD=D;
				(*MostDenseCoordinate) = focus;
			}
		}
	}
	return maxD;
}
//=============================================================================================
double ClusterDensity(float x, float y, float z,float xf[], float yf[], float zf[], short int clusters[], int Nfoci, int cluster, double sd)
{
	double D;
	double d2;
	double spread2=2.0*sd*sd;
	int focus;

	D=0.0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (clusters[focus]==cluster)
		{
			d2=(x-xf[focus])*(x-xf[focus]) + (y-yf[focus])*(y-yf[focus]) + (z-zf[focus])*(z-zf[focus]);
			D+=exp(-d2/spread2);
		}
	}
	return D;
}
//=============================================================================================
int SaveBRLforAllClusters(struct Coordinates *C, int Nclusters, unsigned char FileNumber[], char fnames[], int Nfiles, double SD, char directory[])
{
	int result=0;
	int Nstudies=WholeBrainStudies(C);
	int cluster;
	double tmp;
	double *residuals=NULL;
	double *X=NULL;
	char *resp=NULL;
	int *NonVOIexperiment=NULL;
	int ParameterColumn[BLR_PARAMETERS];
	int NwholeBrain;
	int Nparams, maxk;
	int i,j,k;
	int NonVOI;
	int iexp;
	int dummy;
	double sd;
	double se[BLR_PARAMETERS+MAX_FILES];
	double M[BLR_PARAMETERS];
	double V[BLR_PARAMETERS];
	double param[BLR_PARAMETERS+MAX_FILES];
	struct TextLabel TL[BLR_PARAMETERS];
	struct TextLabel hdr[BLR_PARAMETERS];
	char txt[MAX_PATH];
	char fname[MAX_PATH];
	FILE *fp;


	sprintf(TL[SAMPLE_SIZE].txt,"Sample Size parameter");
	sprintf(TL[CENSORLEVEL].txt,"censor level parameter");
	sprintf(TL[COVARIANCE].txt,"Covariate parameter");

	sprintf(hdr[SAMPLE_SIZE].txt,"SqrtSampleSze");
	sprintf(hdr[CENSORLEVEL].txt,"CensorLevel");
	sprintf(hdr[COVARIANCE].txt,"Covariate");

	sprintf(fname,"%s//BLRclusters.txt",directory);
	if (!(fp=fopen(fname,"w")))
	{
		goto END;
	}
	fclose(fp);
	sprintf(fname,"%s//BLRclusters.R",directory);
	if (!(fp=fopen(fname,"w")))
	{
		goto END;
	}
	fclose(fp);


	///allocate memory
	if (!(X=(double *)calloc((BLR_PARAMETERS+Nfiles)*Nstudies,sizeof(double))))
	{
		goto END;
	}
	if (!(resp=(char *)calloc(Nstudies,sizeof(char))))
	{
		goto END;
	}
	if (!(NonVOIexperiment=(int *)calloc((*C).Nexperiments,sizeof(int))))
	{
		goto END;
	}
	if (!(residuals=(double *)calloc((*C).Nexperiments,sizeof(double))))
	{
		goto END;
	}

	Nparams=DesignMatrixForBLR(C, X, ParameterColumn, M, V, FileNumber, Nfiles);


	NonVOI=0;
	for (iexp=0; iexp<(*C).Nexperiments; iexp++)
	{
		if (!((*C).VOI[iexp]))
		{
			NonVOIexperiment[NonVOI]=iexp;//record the list of whole brain studies
			NonVOI++;
		}
	}
	NwholeBrain=NonVOI;


	for (cluster=1; cluster<=Nclusters; cluster++)
	{

		///get the responses
		memset(resp,0,Nstudies);
		for (iexp=0; iexp<NwholeBrain; iexp++)
		{
			resp[iexp] = ExperimentContributesToCluster(C, NonVOIexperiment[iexp], cluster);
		}


		BinaryLogisticRegressionIRLS(resp, X, param, se, Nparams, Nstudies);///Solve the BLR problem


		///SAVE THE DESIGN MATRIX
		sprintf(fname,"%s//Design%d.csv",directory,cluster);
		if ((fp=fopen(fname,"w")))
		{
			fprintf(fp,"Study,Response");
			for (k=0; k<BLR_PARAMETERS; k++)
			{
				if (ParameterColumn[k]>=0)
				{
					fprintf(fp,",%s",hdr[k].txt);
				}
			}
			for (j=0; j<Nfiles; j++)
			{
				fprintf(fp,",file%d",j+1);
			}
			fprintf(fp,",Residual,Density\n");
			for (iexp=0; iexp<NwholeBrain; iexp++)
			{
				fprintf(fp,"%s,%d",(*C).ID[iexp].txt, resp[iexp]);
				maxk=0;
				for (j=0; j<BLR_PARAMETERS; j++)
				{
					k=ParameterColumn[j];
					if (k>=0)
					{
						fprintf(fp,",%f",X[iexp*Nparams+k]*sqrt(V[j]));
					}
					if (k>maxk)
					{
						maxk=k;
					}
				}
				for (j=1; j<=Nfiles; j++)
				{
					fprintf(fp,",%f", X[iexp*Nparams + maxk + j]);
				}
				fprintf(fp,",%f,%f\n",Residual(X, resp, param, Nparams, (*C).Nexperiments, NonVOIexperiment[iexp]),MaxDensityInExperiment(C, NonVOIexperiment[iexp], cluster, SD, &dummy));

			}
			fclose(fp);
		}

		sprintf(fname,"%s//BLRclusters.R",directory);
		if (!(fp=fopen(fname,"a")))
		{
			goto END;
		}
		fprintf(fp,"#Cluster %d\n",cluster);
		sprintf(txt,"X<-read.csv(\"%s\\Design%d.csv\",header=T)",directory,cluster);
		ConvertToFileFormat(txt);
		fprintf(fp,"%s\n",txt);
		sprintf(txt,"mylogit <- glm(X$Response ~ -1");
		for (i=0; i<BLR_PARAMETERS; i++)
		{
			if ((j=ParameterColumn[i])>=0)
			{
				switch (j)
				{
				case SAMPLE_SIZE:
					sprintf(txt,"%s + X$SqrtSampleSze",txt);
					break;
				case CENSORLEVEL:
					sprintf(txt,"%s +X$CensorLevel",txt);
					break;
				case COVARIANCE:
					sprintf(txt,"%s + X$Covariate",txt);
					break;
				}
			}
		}
		for (i=1; i<=Nfiles; i++)
		{
			sprintf(txt,"%s + X$file%d",txt,i);
		}
		sprintf(txt,"%s, family = \"binomial\")",txt);
		fprintf(fp,"%s\n",txt);
		fprintf(fp,"summary(mylogit) \n plot(mylogit)\n##############################\n\n\n\n");
		fclose(fp);

		///add up the squared residuals
		for (iexp=0; iexp<NwholeBrain; iexp++)
		{
			tmp=Residual(X, resp, param, Nparams, (*C).Nexperiments, NonVOIexperiment[iexp]);
			residuals[iexp]+=tmp;
		}


		///SAVE THE PARAMETERS
		sprintf(fname,"%s//BLRclusters.txt",directory);
		if (!(fp=fopen(fname,"a")))
		{
			goto END;
		}
		fprintf(fp,"Cluster %d\n",cluster);
		for (k=0; k<BLR_PARAMETERS; k++)
		{
			if ((ParameterColumn[k])>=0)
			{
				switch (k)
				{
				case SAMPLE_SIZE:
					fprintf(fp,"@Mean Sample Size measure of %f (sd=%f)\n",M[k]*M[k],sqrt(V[k]));
					break;
				case CENSORLEVEL:
					fprintf(fp,"@Mean Censor level of %f (sd=%f)\n",M[k],sqrt(V[k]));
					break;
				case COVARIANCE:
					fprintf(fp,"@Mean covariate of %f (sd=%f)\n",M[k],sqrt(V[k]));
					break;
				}
			}
		}
		maxk=0;
		for (j=0; j<BLR_PARAMETERS; j++)
		{
			if ((k=ParameterColumn[j])>=0)
			{
				sd=sqrt(V[j]);
				fprintf(fp,"%s: %f C.I.(%f , %f). OR=%f p-value=%f\n",TL[j].txt, param[k]/sd, (param[k]-2.0*se[k])/sd, (param[k]+2.0*se[k])/sd, exp(param[k]/sd), 2.0*StandardNormalTailArea(param[k]/(se[k]+DBL_MIN)/sqrt(2.0)));
				if (k>maxk)
				{
					maxk=k;
				}
			}
		}
		maxk++;
		for (i=0; i<Nfiles; i++)
		{
			fprintf(fp,"%s: %f C.I.(%f , %f). OR=%f probability=%f p-value=%f\n",&fnames[i*MAX_PATH], param[i+maxk], (param[i+maxk]-2.0*se[i+maxk]), (param[i+maxk]+2.0*se[i+maxk]), exp(param[i+maxk]), InvLogOdds(param[i+maxk]),2.0*StandardNormalTailArea(param[i+maxk]/(se[i+maxk]+DBL_MIN)/sqrt(2.0)));
		}
		fprintf(fp,"\n");
		fclose(fp);
	}


	sprintf(fname,"%s//Residual sum.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		for (iexp=0; iexp<NwholeBrain; iexp++)
		{
			NonVOI=NonVOIexperiment[iexp];
			fprintf(fp,"%s,%f\n",(*C).ID[NonVOI].txt, residuals[iexp]);
		}
		fclose(fp);
	}




	result=1;
END:
	if (X)
	{
		free(X);
	}
	if (resp)
	{
		free(resp);
	}
	if (NonVOIexperiment)
	{
		free(NonVOIexperiment);
	}
	if (residuals)
	{
		free(residuals);
	}

	return result;
}
//===============================================================================================
int SaveCDAM_BRLforAllClusters(struct Coordinates *C, int Nclusters, unsigned char FileNumber[], char fnames[], int Nfiles, double SD, char directory[])
{
	int result=0;
	int Nstudies=WholeBrainStudies(C);
	int cluster;
	double *residuals=NULL;
	double *X=NULL;
	double *pfile=NULL;
	double *Zfile=NULL;
	char *resp=NULL;
	int *NonVOIexperiment=NULL;
	int ParameterColumn[BLR_PARAMETERS];
	int NwholeBrain;
	int Nparams, maxk;
	int j,k;
	int NonVOI;
	int iexp;
	struct TextLabel hdr[BLR_PARAMETERS];
	double se[BLR_PARAMETERS+MAX_FILES];
	double M[BLR_PARAMETERS];
	double V[BLR_PARAMETERS];
	double param[BLR_PARAMETERS+MAX_FILES];
	char fname[MAX_PATH];
	FILE *fp;

	sprintf(hdr[SAMPLE_SIZE].txt,"SqrtSampleSze");
	sprintf(hdr[CENSORLEVEL].txt,"CensorLevel");
	sprintf(hdr[COVARIANCE].txt,"Covariate");

	///allocate memory
	if (!(X=(double *)calloc((BLR_PARAMETERS+2)*Nstudies,sizeof(double))))
	{
		goto END;
	}
	if (!(resp=(char *)calloc(Nstudies,sizeof(char))))
	{
		goto END;
	}
	if (!(NonVOIexperiment=(int *)calloc((*C).Nexperiments,sizeof(int))))
	{
		goto END;
	}
	if (!(residuals=(double *)calloc((*C).Nexperiments,sizeof(double))))
	{
		goto END;
	}
	if (!(pfile=(double *)malloc(Nclusters*sizeof(double))))
	{
		goto END;
	}
	if (!(Zfile=(double *)malloc(Nclusters*sizeof(double))))
	{
		goto END;
	}

	Nparams=CDAMDesignMatrixForBLR(C, X, ParameterColumn, M, V, FileNumber, Nfiles);

	NonVOI=0;
	for (iexp=0; iexp<(*C).Nexperiments; iexp++)
	{
		if (!((*C).VOI[iexp]))
		{
			NonVOIexperiment[NonVOI]=iexp;//record the list of whole brain studies
			NonVOI++;
		}
	}
	NwholeBrain=NonVOI;


	for (cluster=1; cluster<=Nclusters; cluster++)
	{

		///get the responses
		memset(resp,0,Nstudies);
		for (iexp=0; iexp<NwholeBrain; iexp++)
		{
			resp[iexp] = ExperimentContributesToCluster(C, NonVOIexperiment[iexp], cluster);
		}

		BinaryLogisticRegressionIRLS(resp, X, param, se, Nparams, Nstudies);///Solve the BLR problem

		///SAVE THE DESIGN MATRIX
		sprintf(fname,"%s//CDAMdesign%d.csv",directory,cluster);
		if ((fp=fopen(fname,"w")))
		{
			fprintf(fp,"Study,Response");
			for (k=0; k<BLR_PARAMETERS; k++)
			{
				if (ParameterColumn[k]>=0)
				{
					fprintf(fp,",%s",hdr[k].txt);
				}
			}

			fprintf(fp,",intercept, %s, Residual\n", &fnames[0]);

			for (iexp=0; iexp<NwholeBrain; iexp++)
			{
				fprintf(fp,"%s,%d",(*C).ID[iexp].txt, resp[iexp]);
				maxk=0;
				for (j=0; j<BLR_PARAMETERS; j++)
				{
					k=ParameterColumn[j];
					if (k>=0)
					{
						fprintf(fp,",%f",X[iexp*Nparams+k]*sqrt(V[j]));
					}
					if (k>maxk)
					{
						maxk=k;
					}
				}
				for (j=1; j<=2; j++)
				{
					fprintf(fp,",%f", X[iexp*Nparams + maxk + j]);
				}
				fprintf(fp,",%f\n",Residual(X, resp, param, Nparams, (*C).Nexperiments, NonVOIexperiment[iexp]));

			}

			fprintf(fp,"\n");
			for (j=0; j<Nparams; j++)
			{
				fprintf(fp,"%f,%f\n",param[j],se[j]);
			}
			fclose(fp);
		}

		///get p value for file 1
		pfile[cluster-1]=2.0*StandardNormalTailArea(param[Nparams-1]/(se[Nparams-1]+DBL_MIN)/sqrt(2.0));
		Zfile[cluster-1]=param[Nparams-1]/(se[Nparams-1]+DBL_MIN);

	}

	sprintf(fname,"%s//File1 Pvalues.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		fprintf(fp,"%s\n",&fnames[0]);
		for (cluster=1; cluster<=Nclusters; cluster++)
		{
			fprintf(fp,"Cluster %d, Zvalue=%f, pvalue=%f\n",cluster, Zfile[cluster-1], pfile[cluster-1]);
		}
		fclose(fp);
	}


	result=1;
END:
	if (X)
	{
		free(X);
	}
	if (resp)
	{
		free(resp);
	}
	if (NonVOIexperiment)
	{
		free(NonVOIexperiment);
	}
	if (residuals)
	{
		free(residuals);
	}
	if (pfile)
	{
		free(pfile);
	}
	if (Zfile)
	{
		free(Zfile);
	}

	return result;
}
//===============================================================================================
//===============================================================================================
//Fill the low density holes in the clusters
int ClusterHoleFill(struct Coordinates *C, int Nclusters, double Dmax)
{
	int added=0;
	double density;
	double *maxD=NULL;
	double *minD=NULL;
	int *PeakFocus=NULL;
	double *D=NULL;
	int *cluster=NULL;
	int iexp, Nexperiments=(*C).Nexperiments;
	int focus;
	int cl;
	int Nfoci=(*C).TotalFoci;


	/*	struct Image img;
		FILE *fp=NULL;
		char fname[MAX_PATH];
		sprintf(fname,"%s//AddedCoordinates.txt",REPORT_FOLDER);
		fp=fopen(fname,"w");

		memset(&img,0,sizeof(struct Image));
	    MakeCopyOfImage(&gImage, &img);
	    memset(img.img,0,sizeof(float)*gImage.X*gImage.Y*gImage.Z);
	    sprintf(img.filename,"%s//AddedToCluster.nii",REPORT_FOLDER);
	    img.ImageType=NIFTI;
	*/

	if (!(D=(double *)calloc(Nfoci,sizeof(double))))
		goto END;
	if (!(cluster=(int *)calloc(Nfoci, sizeof(int))))
		goto END;

	if (!(maxD=(double *)calloc(Nclusters+1,sizeof(double))))
		goto END;
	if (!(PeakFocus=(int *)calloc(Nclusters+1, sizeof(int))))
		goto END;
	if (!(minD=(double *)calloc(Nclusters+1,sizeof(double))))
		goto END;


	//find the minimum density for member coordinates in each cluster
	for (cl=0; cl<=Nclusters; cl++)
	{
		minD[cl]=(double)Nexperiments;
	}
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus])
		{
			density = ClusterDensityCDA(C, (*C).x[focus], (*C).y[focus], (*C).z[focus], (*C).cluster[focus], Dmax);
			if (density<minD[(*C).cluster[focus]])
			{
				minD[(*C).cluster[focus]]=density;//this is the cluster-wise minimum density of any cluster member
			}
		}
	}


	//what is the cluster density of those coordinates that are not currently members of a cluster?
	for (cl=1; cl<=Nclusters; cl++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if ((!ExperimentContributesToCluster(C, iexp, cl)) && (!(*C).VOI[iexp]))
			{
				for (focus=0; focus<Nfoci; focus++)
				{
					if ((*C).experiment[focus]==iexp && (!(*C).cluster[focus]))
					{
						density = ClusterDensityCDA(C, (*C).x[focus], (*C).y[focus], (*C).z[focus], cl, Dmax);
						if (density>D[focus])
						{
							D[focus]=density;
							cluster[focus]=cl;//the cluster with the highest density at this focus
						}
					}
				}
			}
		}
	}



	for (iexp=0; iexp<Nexperiments; iexp++)
	{

		memset(maxD,0,(Nclusters+1)*sizeof(double));
		for (focus=0; focus<Nfoci; focus++)
		{
			cl=cluster[focus];
			if ((*C).experiment[focus]==iexp && cl &&  D[focus]>maxD[cl])
			{
				maxD[cl]=D[focus];      //this is the focus within iexp that has maximum density in cluster cl
				PeakFocus[cl]=focus;
			}
		}

		for (cl=1; cl<=Nclusters; cl++)
		{
			if (maxD[cl]>minD[cl])
			{
				(*C).cluster[PeakFocus[cl]]=cl;
				added++;
				/*img.img[(*C).voxel[PeakFocus[cl]]]=1.0;
				if (fp)
				{
				    fprintf(fp,"%d\tfocus=%d\texp=%d\tcl=%d\tvox=%d\tmin=%f\tmax=%f\tpval=%f\n",added,PeakFocus[cl],(*C).experiment[PeakFocus[cl]],cl, (*C).voxel[PeakFocus[cl]],minD[cl],maxD[cl], (*C).p[PeakFocus[cl]]);
				}*/
			}
		}

	}

	/*if (fp) fclose(fp);

	SaveAsCharImage(&img,0);
	ReleaseImage(&img);*/


END:
	if (D)
	{
		free(D);
	}
	if (cluster)
	{
		free(cluster);
	}
	if (maxD)
	{
		free(maxD);
	}
	if (PeakFocus)
	{
		free(PeakFocus);
	}
	if (minD)
	{
		free(minD);
	}
	return added;
}
//===============================================================================================
int ExperimentContributesToCluster(struct Coordinates *C, int iexp, int cluster)
{
	int focus;
	int Nfoci=(*C).TotalFoci;

	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).experiment[focus]==iexp)
		{
			if ((*C).cluster[focus]==cluster)
			{
				return 1;
			}
		}
	}
	return 0;
}
//===============================================================================================
//===============================================================================================
int WholeBrainStudies(struct Coordinates *C)
{
	int experiment;
	int NonVOI=0;

	for (experiment=0; experiment<(*C).Nexperiments; experiment++)
	{
		if (!(*C).VOI[experiment])
			NonVOI++;
	}

	return NonVOI;
}
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
int SaveReportedStructuresCDA(struct Coordinates *C, char directory[], double pthreshold);
int SaveCDAresults(struct Coordinates *C, double pthreshold, struct Image *image, char directory[], int MarkerSize)
{
	struct Image Cpy;
	int voxel, voxels=(*image).X*(*image).Y*(*image).Z;
	int offset;
	int i,j,k;
	int xi,yi,zi;
	int focus;
	int max=0;
	double Z;


	memset(&Cpy,0,sizeof(struct Image));
	if (MakeCopyOfImage(image, &Cpy))
	{
		memset(Cpy.img,0,voxels*sizeof(float));
		for (focus=0; focus<(*C).TotalFoci; focus++)
		{

			if ((*C).p[focus]<=pthreshold)
			{
				voxel=(*C).voxel[focus];
				XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
				for (k=-MarkerSize; k<=MarkerSize; k++)
				{
					for (j=-MarkerSize; j<=MarkerSize; j++)
					{
						for (i=-MarkerSize; i<=MarkerSize; i++)
						{
							if (InImageRange(xi+i, yi+j, zi+k, (*image).X, (*image).Y, (*image).Z) && (i*i+j*j+k*k)<=MarkerSize*MarkerSize)
							{
								offset=i +j*(*image).X + k*(*image).X*(*image).Y;
								Cpy.img[voxel + offset]+=1.0;
								if (Cpy.img[voxel + offset]>255)
								{
									max=Cpy.img[voxel + offset];
								}
							}
						}
					}
				}
			}
		}
		sprintf(Cpy.filename,"%s//DenseCoordinates.nii",directory);
		Cpy.ImageType=NIFTI;
		Cpy.scale=1.0;
		Cpy.offset=0.0;
		SaveAsCharImage(&Cpy, (max>255)?1:0);

		memset(Cpy.img,0,voxels*sizeof(float));
		for (focus=0; focus<(*C).TotalFoci; focus++)
		{

			if ((*C).p[focus]<=pthreshold)
			{
				Z=Zvalue(1.0-(*C).p[focus]);
				voxel=(*C).voxel[focus];
				XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
				for (k=-MarkerSize; k<=MarkerSize; k++)
				{
					for (j=-MarkerSize; j<=MarkerSize; j++)
					{
						for (i=-MarkerSize; i<=MarkerSize; i++)
						{
							if (InImageRange(xi+i, yi+j, zi+k, (*image).X, (*image).Y, (*image).Z) && (i*i+j*j+k*k)<=MarkerSize*MarkerSize)
							{
								if (Z>Cpy.img[voxel + i +j*(*image).X + k*(*image).X*(*image).Y])
								{
									Cpy.img[voxel + i +j*(*image).X + k*(*image).X*(*image).Y]=Z;
								}
							}
						}
					}
				}
			}
		}
		sprintf(Cpy.filename,"%s//DenseCoordinates Z threshold.nii",directory);
		Cpy.ImageType=NIFTI;
		Cpy.scale=1.0;
		Cpy.offset=0.0;
		SaveAsCharImage(&Cpy, 1);
		ReleaseImage(&Cpy);

	}

	SaveReportedStructuresCDA(C, directory, pthreshold);


	return 0;
}
//======================================================================================================
int SaveReportedStructuresCDA(struct Coordinates *C, char directory[], double pthreshold)
{
	struct Image TalImg;
	int result=0;
	char fname[MAX_PATH];
	char *labels=NULL;
	char *b;
	int LengthLabels;
	int Nlabels;
	int st;
	int focus;
	int lab;
	char shortlabel[256];
	short int *reported=NULL;
	short int *studies=NULL;
	FILE *fp;

	memset(&TalImg,0,sizeof(struct Image));
	sprintf(fname,"%s\\Talairach\\talGMmerged.nii", ExecutableDirectory);
	if (!LoadFromFileName(NULL, fname, &TalImg, 0))
	{
		MessageBox(NULL,"Not available without downloading the Talairach image file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
		goto END;
	}
	labels=LoadTalairachLabels(&LengthLabels);
	if (LengthLabels<=0)
	{
		MessageBox(NULL,"Not available without downloading the Talairach labels file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
		goto END;
	}
	Nlabels=BiggestTalairachLabel(labels, LengthLabels);

	GetTalairachLabelsEx(C, &TalImg);

	if (!(reported=(short int *)malloc(sizeof(short int)*(Nlabels+1))))
		goto END;
	if (!(studies=(short int *)malloc(sizeof(short int)*(Nlabels+1))))
		goto END;

	memset(studies,0,sizeof(short int)*(Nlabels+1));
	for (st=0; st<(*C).Nexperiments; st++)
	{
		memset(reported,0,sizeof(short int)*(Nlabels+1));
		for (focus=0; focus<(*C).TotalFoci; focus++)
		{
			if ((*C).p[focus]<=pthreshold && (*C).experiment[focus]==st)
				reported[(*C).TalLabel[focus]]++;
		}
		for (lab=0; lab<=Nlabels; lab++)
		{
			if (reported[lab])
				studies[lab]++;
		}
	}

	sprintf(fname,"%s//Reported Structures.csv", directory);
	if ( (fp=fopen(fname,"w")) )
	{
		fprintf(fp,"Talairach,,,,,,Proportion reporting, Number reporting\n");
		for (lab=0; lab<=Nlabels; lab++)
		{
			if (studies[lab])
			{
				b=FindEntryInTalairachLabels(labels, LengthLabels, lab);
				ShortTalairachLabel(b, shortlabel, ".");
				fprintf(fp,"%s,%s,%f,%d\n",&b[1],shortlabel,(double)studies[lab]/(*C).Nexperiments,studies[lab]);
			}
		}
		fprintf(fp,"\n\n\n\n");
		for (focus=0; focus<(*C).TotalFoci; focus++)
		{
			if ((*C).p[focus]<=pthreshold)
			{
				st=(*C).experiment[focus];
				b=FindEntryInTalairachLabels(labels, LengthLabels, (*C).TalLabel[focus]);
				fprintf(fp,"%s, %f,%f,%f,%f,%s\n",(*C).ID[st].txt, (*C).x[focus], (*C).y[focus], (*C).z[focus], (*C).p[focus],b);
			}
		}
		fclose (fp);
	}

	result=1;
END:
	ReleaseImage(&TalImg);
	if (reported)
		free(reported);
	if (studies)
		free(studies);

	return result;
}

//==============================================================================================
//==============================================================================================
//==============================================================================================
int SaveRGBclustersCDA(int FociVoxel[], short int cluster[], int Nfoci, struct Image *img, int Nclusters, int Marker, double kernelSD, char fname[], char directory[])
{
	struct Image RGBimg;
	int coordinate;
	int x,y,z;
	int voxel;
	int voxels;
	int X,Y,Z,XY;
	int cl;
	RGBQUAD rgb;
	int ColourLevels;

	X=(*img).X;
	Y=(*img).Y;
	Z=(*img).Z;
	XY=X*Y;
	voxels=X*Y*Z;

	ColourLevels = Nclusters/6+1;

	memset(&RGBimg,0,sizeof(struct Image));

	if (!(MakeCopyOfImage(img, &RGBimg)))
		return 0;
	memset(RGBimg.img,0,sizeof(float)*voxels);

	for (coordinate=0; coordinate<Nfoci; coordinate++)
	{
		for (z=-Marker; z<=Marker; z++)
		{
			for (y=-Marker; y<=Marker; y++)
			{
				for (x=-Marker; x<=Marker; x++)
				{

					voxel = FociVoxel[coordinate] + x + X*y + XY*z;
					if ((voxel>=0) && (voxel<voxels))
					{

						if ((cluster[coordinate]>0))
						{

							if ( (x*x + y*y + z*z)<=Marker*Marker )
							{
								cl=cluster[coordinate];

								if (cl)
								{
									rgb=Colours(cl-1,ColourLevels);
									memcpy(&RGBimg.img[voxel], &rgb, sizeof(float));
								}

							}
						}
					}
				}
			}
		}
	}

	RGBimg.DataType=DT_RGB;
	RGBimg.ImageType=NIFTI;
	sprintf(RGBimg.filename, "%s//%s %5.2f.nii",  directory, fname,kernelSD);
	Save(&RGBimg);
	ReleaseImage(&RGBimg);

	return 1;
}
//==============================================================================================
//==============================================================================================
//==============================================================================================
int ReportClustersCDA(float x[], float y[], float z[], float Zsc[], short int cluster[], double p[], int Nfoci,
                      short int exprmnt[], int Nexperiments,
                      struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                      char directory[],
                      int X, int Y, int Z, float z0,
                      float dx, float dy, float dz,
                      float xc[], float yc[], float zc[], int Nclusters, double fdr, int MinStudiesPerCluster)
{
	char fname[MAX_PATH];
	FILE *fp;
	int cl;
	int *experiments=NULL;      //how many experiments contribute to the clusters
	int NsignificantFoci;
	int foci, iexp, FoundContributor;
	int xi,yi,zi;
	float xf,yf,zf;
	char *labels=NULL;
	char *b=NULL;
	int Nentries,Nl;
	struct Image Tal;
	char shortlabel[256];


	memset(&Tal,0,sizeof(struct Image));

//LOAD THE TALAIRACH DATA
	sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
	LoadFromFileName(NULL, fname, &Tal, 0);
	labels=LoadTalairachLabels(&Nl);
	Nentries=BiggestTalairachLabel(labels, Nl);
	RemoveNonGM(&Tal, labels, Nl,Nentries);

//count the number of significant foci
	NsignificantFoci=0;
	for (foci=0; foci<Nfoci; foci++)
	{
		if (cluster[foci])
			NsignificantFoci++;
	}




//count the number of significant studies contributing to each cluster
	if (!(experiments=(int *)malloc((Nclusters+1)*sizeof(int))))
		goto END;
	memset(experiments,0,(Nclusters+1)*sizeof(int));
	for (cl=1; cl<=Nclusters; cl++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			FoundContributor=0;
			for (foci=0; foci<Nfoci; foci++)
			{
				if ((exprmnt[foci] == iexp) &&
				        (cluster[foci] == cl))
					FoundContributor=1;
			}
			if (FoundContributor)
				experiments[cl]++;
		}
	}




	sprintf(fname,"%s\\ClusterReport.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		fprintf(fp,"Number of foci, %d\n", Nfoci);
		fprintf(fp,"Number of studies, %d\n", Nexperiments);
		fprintf(fp,"Min Studies Per Cluster, %d\n", MinStudiesPerCluster);
		fprintf(fp,"FDR control, %f\n", fdr);
		fprintf(fp,"Talairach report, , , , , Cluster{x y z},Number Of significant Studies,Slice,Studies,,,,,Nearest GM\n\n");
		for (cl=1; cl<=Nclusters; cl++)
		{
			if (experiments[cl])
			{

				if (fp)
					fprintf(fp,"cluster %d\n",cl);

				xf=xc[cl-1];
				yf=yc[cl-1];
				zf=zc[cl-1];

				xi=(int)((xf+Tal.x0)/Tal.dx+0.5);
				yi=(int)((yf+Tal.y0)/Tal.dy+0.5);
				zi=(int)((zf+Tal.z0)/Tal.dz+0.5);

				if (labels && Tal.img)
				{
					b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
					if (fp)
						fprintf(fp,"%s,",&b[1]);
				}

				zi=(int)((zf+z0)/dz+0.5);
				if (fp)
					fprintf(fp," (%5.1f  %5.1f  %5.1f),%d,%d,", xf, yf, zf,experiments[cl], zi);

				//list each experiment that contributes to this cluster
				//report the lowest p value for the experiment, and indicate if it is significant
				for (iexp=0; iexp<Nexperiments; iexp++)
				{
					for (foci=0; foci<Nfoci; foci++)
					{
						if ((cluster[foci]==cl) && (exprmnt[foci] == iexp))
						{

							if (fp)
								fprintf(fp,"%s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
								        StudyID[exprmnt[foci]].txt,
								        ctrst[exprmnt[foci]].txt,
								        cnd[exprmnt[foci]].txt,
								        x[foci],y[foci],z[foci],Zsc[foci]);

							if (labels && Tal.img)
							{
								xi=(int)((x[foci]+Tal.x0)/Tal.dx+0.5);
								yi=(int)((y[foci]+Tal.y0)/Tal.dy+0.5);
								zi=(int)((z[foci]+Tal.z0)/Tal.dz+0.5);
								b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
								ShortTalairachLabel(b, shortlabel, ".");
								if (fp)
									fprintf(fp,"%s\n , , , , ,  , , ,",shortlabel);
							}
						}
					}

				}

				if (fp)
					fprintf(fp,"\n");
			}
		}
		fclose(fp);
	}


END:
	if (labels)
		free(labels);
	if (experiments)
		free(experiments);
	ReleaseImage(&Tal);

	return Nclusters;
}
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
int SaveTalairachNetworkProjectionCDA(HWND hwndMain,
                                      struct Coordinates *Co,
                                      double Rho[], double SE[],
                                      float xp[],float yp[], float zp[],
                                      int Nclusters,
                                      char directory[])
{

	int del=24;//size of the circles projected
	int penwidth;
	int x,y, x1, y1;
	int cluster, cl;
	int ColourLevels;
	int fontwidth=18;
	int fontheight=20;
	float red,blue;
	TEXTMETRIC tm;
	RECT r;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	HBITMAP hBitmap, hOldObj;
	int width,height, pixels;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	RGBQUAD rgb,c;
	HBRUSH hBrush, hOldBrush;
	HPEN hPen, hOldPen;
	HFONT hOldFont, hFont = CreateFont(fontheight,fontwidth,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
	                                   CLIP_DEFAULT_PRECIS, 0, VARIABLE_PITCH,TEXT("Verdana"));
	char txt[256];
	FILE *fp;
	char fname[MAX_PATH];


	/*
	//Save a file for StereoProjection program
		sprintf(fname,"%s//network.txt",REPORT_FOLDER);
		fp=fopen(fname,"w");
		fprintf(fp,"%d\n",Nclusters);
	    fprintf(fp,"%f\n",0.5);
		for (cl=0;cl<Nclusters;cl++)
	    {
	        fprintf(fp,"%f %f %f\n",xp[cl], yp[cl], zp[cl]);
	    }
	    for (cl=0;cl<Nclusters;cl++)
	    {
	        for (cluster=0;cluster<Nclusters;cluster++)
	        {
	            fprintf(fp,"%f\n",Rho[cl+cluster*Nclusters]);
	        }
	    }
		fclose(fp);
	*/

	ColourLevels = Nclusters/6+1;

	//bitmap dimensions: two hemispheres above axial above coronal
	width=1000;
	height=1000;
	pixels=width*height;

	///File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	///Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=width;
	BmCoreHdr.bcHeight=height;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	///Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=width;
	BmInfoHdr.biHeight=height;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	///Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldObj = SelectObject(chDC, hBitmap);


	///draw the background overlay
	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	r.left=0;
	r.bottom=0;
	r.right=width;
	r.top=height;
	FillRect(chDC, &r, hBrush);///white background
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);

	hBrush=CreateSolidBrush(RGB(255, 255, 255));
	hOldBrush = SelectObject(chDC, hBrush);
	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);

	ConvertTalairachToProjection(width, -1.0, 0.0, 0.0, &x, &y);
	ConvertTalairachToProjection(width, 0.0, -1.0, 0.0, &x1, &y1);
	Ellipse(chDC, x, y1, width/2 + (width/2-x), height/2 + (height/2-y1));///z=0 circle
	SelectObject(chDC, hOldBrush);
	DeleteObject(hBrush);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);

	hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
	hOldPen = SelectObject(chDC, hPen);
	MoveToEx(chDC,width/2,0,NULL);
	LineTo(chDC,width/2,height);
	MoveToEx(chDC,0,height/2,NULL);///x=0, y=0 axis
	LineTo(chDC,width,height/2);
	SelectObject(chDC, hOldPen);
	DeleteObject(hPen);


	///Draw connecting lines
	for (cluster=1; cluster<=Nclusters; cluster++)
	{
		///now draw the connecting lines
		for (cl=cluster+1; cl<=Nclusters; cl++)
		{
			if (cluster!=cl)
			{

				if (SE[cl-1+(cluster-1)*Nclusters]>0.0)
				{
					penwidth=(int)(1.0/(SE[cl-1+(cluster-1)*Nclusters]+0.01));
				}
				else
				{
					penwidth=0;
				}


				//red if +ve Rho
				red=Rho[cl-1+(cluster-1)*Nclusters]*fabs(Rho[cl-1+(cluster-1)*Nclusters])*255;
				if (red<0.0)
					red=0.0;
				//blue if -ve Rho
				blue=-Rho[cl-1+(cluster-1)*Nclusters]*fabs(Rho[cl-1+(cluster-1)*Nclusters])*255;
				if (blue<0.0)
					blue=0.0;

				hPen=CreatePen(PS_SOLID, penwidth, RGB((unsigned char)red, 0, (unsigned char)blue));

				hOldPen = SelectObject(chDC, hPen);
				if (penwidth>0 && ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0)
				{
					if (ConvertTalairachToProjection(width, xp[cl-1], yp[cl-1], zp[cl-1], &x1, &y1)>=0)
					{
						MoveToEx(chDC,x,y,NULL);
						LineTo(chDC,x1,y1);
					}
				}
				SelectObject(chDC, hOldPen);
				DeleteObject(hPen);
			}
		}

	}



	hOldFont=SelectObject(chDC, hFont);
	GetTextMetrics(chDC,&tm);
	SetBkMode(chDC, TRANSPARENT);
	SetTextColor(chDC,RGB(255, 255, 255));
	///draw the nodes (clusters represented by circles)
	for (cluster=Nclusters; cluster>=1; cluster--)
	{

		if (cl!=cluster)
		{
			rgb=Colours(cluster-1,ColourLevels);

			//draw the number in black or white, depending on the colour of the ellipse
			c.rgbRed=c.rgbBlue=c.rgbGreen=( (rgb.rgbRed+rgb.rgbBlue+rgb.rgbGreen)/3>128 )?0:255;

			SetTextColor(chDC,RGB(c.rgbRed, c.rgbGreen, c.rgbBlue));

			hBrush=CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldBrush = SelectObject(chDC, hBrush);
			hPen=CreatePen(PS_SOLID, 1, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
			hOldPen = SelectObject(chDC, hPen);

			if (ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0)
			{
				Ellipse(chDC, x-del, y+del, x+del, y-del);
			}
			sprintf(txt,"%d",cluster);
			TextOut(chDC, x-tm.tmAveCharWidth*strlen(txt)/2-1, y-tm.tmHeight/2, txt,strlen(txt));

			SelectObject(chDC, hOldBrush);
			DeleteObject(hBrush);
			SelectObject(chDC, hOldPen);
			DeleteObject(hPen);
		}
	}
	SelectObject(chDC, hOldFont);


	BitBlt(hDC, 0, 0, width, height, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldObj);

	///Now save the bitmap file
	sprintf(fname,"%s\\TalairachNetwork.bmp",directory);
	if ( (fp=fopen(fname,"wb")) )
	{
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
	}

	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}
//==========================================================================================================
//==========================================================================================================
//==========================================================================================================
int SaveEdgeAnalysis(HWND hwnd, struct Coordinates *C, float xp[], float yp[], float zp[], int Nclusters, int Compare, char directory[])
{

	double *Rho=NULL;
	double *SE=NULL;
	double hi,lo,sd;
	double *X=NULL;
	double *Y=NULL;
	int CL1,CL2;
	int N;
	FILE *fp;
	char fname[MAX_PATH];


	if (Compare)
	{
		MessageBox(NULL,"Not yet implemented","SaveEdgeAnalysis",MB_OK);
		return 0.0;
	}
	if (!(Rho=(double *)calloc(Nclusters*Nclusters,sizeof(double))))
	{
		goto END;
	}
	if (!(SE=(double *)calloc(Nclusters*Nclusters,sizeof(double))))
	{
		goto END;
	}
	if (!(X=(double *)malloc((*C).Nexperiments*sizeof(double))))
	{
		goto END;
	}
	if (!(Y=(double *)malloc((*C).Nexperiments*sizeof(double))))
	{
		goto END;
	}

	for (CL1=1; CL1<=Nclusters; CL1++)
	{
		for (CL2=CL1+1; CL2<=Nclusters; CL2++)
		{
			N=GetUncensoredData(C, CL1, CL2, X, Y, directory);
			if (N>=4)
			{
				Rho[(CL1-1)*Nclusters+CL2-1]=PearsonsBootstrap(X, Y, N, &lo, &hi, 0.95, &sd, 1000);

				SE[(CL1-1)*Nclusters+CL2-1]=sd;

			}
		}
	}

	sprintf(fname,"%s//Rho.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		for (CL1=1; CL1<=Nclusters; CL1++)
		{
			fprintf(fp,"%f",Rho[(CL1-1)*Nclusters]);
			for (CL2=2; CL2<=Nclusters; CL2++)
			{
				fprintf(fp,",%f",Rho[(CL1-1)*Nclusters+CL2-1]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}
	sprintf(fname,"%s//RhoSE.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		for (CL1=1; CL1<=Nclusters; CL1++)
		{
			fprintf(fp,"%f",Rho[(CL1-1)*Nclusters]);
			for (CL2=2; CL2<=Nclusters; CL2++)
			{
				fprintf(fp,",%f",SE[(CL1-1)*Nclusters+CL2-1]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}

	SaveTalairachNetworkProjectionCDA(hwnd, C, Rho, SE, xp, yp, zp, Nclusters, directory);

END:

	if (Rho)
	{
		free(Rho);
	}
	if (SE)
	{
		free(SE);
	}
	if (X)
	{
		free(X);
	}
	if (Y)
	{
		free(Y);
	}

	return 0;
}
//===============================================================================================
//===============================================================================================
//===============================================================================================
int GetUncensoredData(struct Coordinates *C, int cl1, int cl2, double X[], double Y[], char directory[])
{
	int study, Nstudies=(*C).Nexperiments;
	int focus, Nfoci=(*C).TotalFoci;
	int N=0;
	int i;
	int f1,f2;
	int iexp1,iexp2;
	FILE *fp;
	char fname[MAX_PATH];

	for (study=0; study<Nstudies; study++)
	{
		f1=f2=-1;
		for (focus=0; focus<Nfoci &&(f1<0 || f2<0); focus++)
		{
			if ((*C).experiment[focus]==study && ((*C).cluster[focus]==cl1 || (*C).cluster[focus]==cl2))
			{
				if ((*C).cluster[focus]==cl1)
				{
					f1=focus;
				}
				else
				{
					f2=focus;
				}
			}
		}
		if (f1>=0 && f2>=0 && fabs((*C).Zsc[f1])>1.0 && fabs((*C).Zsc[f2])>1.0)
		{
			iexp1=(*C).experiment[focus];
			X[N]=EffectSize((*C).Zsc[f1], (*C).SubjectsInExp[iexp1], (*C).ControlsInExp[iexp1], 0);
			iexp2=(*C).experiment[focus];
			Y[N]=EffectSize((*C).Zsc[f2], (*C).SubjectsInExp[iexp2], (*C).ControlsInExp[iexp2], 0);
			N++;
		}
	}

	sprintf(fname,"%s//Uncensored %d %d.csv",directory, cl1,cl2);
	if ((fp=fopen(fname,"w")))
	{
		for (i=0; i<N; i++)
		{
			fprintf(fp,"%f,%f\n",X[i],Y[i]);
		}
		fclose(fp);
	}


	return N;
}



//==============================================================================================
//this finds a threshold that controls the expected number of false positives to be less than a fixed value
//or to control the FDR, whichever is most conservative
//11/1/2021 changed to adaptive
double CDAthreshold(struct Coordinates *C, double fdr, int Nexpected)
{
	double critical=-1.0;
	int *sort=NULL;
	int Nfoci=(*C).TotalFoci;
	int n;
	int focus;
	int expected;
	double Pfdr=FDR((*C).p,Nfoci, fdr);

	if (!(sort=(int *)malloc(Nfoci*sizeof(int))))
		goto END;

	QuickSort((*C).p, sort, Nfoci);


	//many of the rejected will be true positives. Want the number of rejections controlled to be from the null coordinates, of which there are Nfoci-rejected+p*Nfoci
	n=0;
	while (n<Nfoci && (*C).p[sort[n]]<=fdr)
	{
		focus=sort[n];
		expected=(*C).p[focus]*Nfoci;
		if (expected<Nexpected && (*C).p[focus]<=Pfdr)
		{
			critical = (*C).p[focus];
		}
		n++;
	}



END:
	if (sort)
	{
		free(sort);
	}
	return critical;
}

//==============================================================================================
//======================================================================================================
//SAVE DATA FOR A FOREST PLOT
//modified for subanalysis 12/04/2017
//======================================================================================================
int ForestPlotCDAR(struct Coordinates *c, struct EffectSample *Es, int cluster, char directory[])
{
	char fname[MAX_PATH];
	int result=0;
	int study;
	float Min,Max;
	float MaxLength;
	FILE *fp;

	sprintf(fname,"%s\\Forest%d.R",directory,cluster);
	if (!(fp=fopen(fname,"w")))
		goto END;

	//margins
	MaxLength=0.0;
	for (study=0; study<(*c).Nexperiments; study++)
		if (strlen((*c).ID[study].txt)>(int)MaxLength)
		{
			MaxLength=(float)strlen((*c).ID[study].txt);
		}
	if (fp)
		fprintf(fp,"#Forest plot produced by %s\n",(*c).coordinate_file_name);
	if (fp)
		fprintf(fp,"#Alter font size and main title scale here\n");
	if (fp)
		fprintf(fp,"ForestFontsize = 10\n");
	if (fp)
		fprintf(fp,"ForestMainScale = 1.3\n");
	if (fp)
		fprintf(fp,"par(ps=ForestFontsize, cex.main=ForestMainScale, mar=c(4.5, %f, 2, 1))\n",MaxLength/1.5);

	//x axis
	Min=1000.0;
	Max=-1000.0;
	if (fp)
		fprintf(fp,"x=c(");
	for (study=0; study<(*c).Nexperiments; study++)
	{
		switch((*Es).censor[study])
		{
		case NOT_CENSORED:
		case INTERVAL_CENSORED:
			if ((!study) && (fp))
				fprintf(fp,"%f",(*Es).d[study]);
			else if (fp)
				fprintf(fp,",%f",(*Es).d[study]);
			break;
		case LEFT_CENSORED:
			if (!study)
				fprintf(fp,"%f",-(*Es).CensorLevel[study]);
			else if (fp)
				fprintf(fp,",%f",-(*Es).CensorLevel[study]);
			break;
		case RIGHT_CENSORED:
			if (!study)
				fprintf(fp,"%f",(*Es).CensorLevel[study]);
			else if (fp)
				fprintf(fp,",%f",(*Es).CensorLevel[study]);
			break;
		}

		if ((*Es).d[study]+1.96*(*Es).SampleSD[study]>Max)
			Max=(*Es).d[study]+1.96*(*Es).SampleSD[study];
		if ((*Es).d[study]-1.96*(*Es).SampleSD[study]<Min)
			Min=(*Es).d[study]-1.96*(*Es).SampleSD[study];

	}
	if (fp)
		fprintf(fp,")\n");


	//y axis
	if (fp)
		fprintf(fp,"y=c(%d",1);
	for (study=2; study<=(*c).Nexperiments; study++)
		if (fp)
			fprintf(fp,",%d",study);
	if (fp)
		fprintf(fp,")\n");

	//plot
	if (fp)
		fprintf(fp,"plot(x,y,xlab=\"Effect Size\",ylab=\"\",axes=FALSE,xlim=c(%f,%f),pch=c(%d",Min,Max,fabs((*Es).d[0])>0.0 ? 20:1);
	for (study=1; study<(*c).Nexperiments; study++)
	{
		if (fp)
			fprintf(fp,",%d",fabs((*Es).d[study])>0.0 ? 20:1);
	}
	if (fp)
		fprintf(fp,"))\n");


	//y axis labels
	if (fp)
		fprintf(fp,"axis(2,1:%d,c(\"%s\"",(*Es).Samples,(*c).ID[0].txt);///print the start from the first valid study
	for (study=1; study<(*c).Nexperiments; study++)
		if (fp)
			fprintf(fp,",\"%s\"",(*c).ID[study].txt);
	if (fp)
		fprintf(fp,"),las=1)\n");


	//x axis labels
	if (fp)
		fprintf(fp,"axis(1, seq(%d,%f,0.1))\n",(int)(Min-0.5),Max);


	//error bars
	for (study=0; study<(*c).Nexperiments; study++)
	{
		switch((*Es).censor[study])
		{
		case NOT_CENSORED:
			if ((*Es).censor[study]==NOT_CENSORED)
				if (fp)
					fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=1, lwd=2)\n",(*Es).d[study]-1.96*(*Es).SampleSD[study],
					        (*Es).d[study]+1.96*(*Es).SampleSD[study], study+1,study+1);
			break;
		case INTERVAL_CENSORED:
			if (fp)
				fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2)\n",-(*Es).CensorLevel[study],
				        (*Es).CensorLevel[study], study+1,study+1);
			break;
		case LEFT_CENSORED:
			if (fp)
				fprintf(fp,"lines(c(%d,%f),c(%d,%d),lty=3, lwd=2)\n",(int)(Min-0.5),-(*Es).CensorLevel[study], study+1,study+1);
			break;
		case RIGHT_CENSORED:
			if (fp)
				fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2)\n",(*Es).CensorLevel[study],Max, study+1,study+1);
			break;
		}
	}


	if (fp)
		fclose(fp);

	result=1;
END:

	return result;
}
//==============================================================================================
int SaveAllForestPlots(struct Coordinates *C, int Nclusters, char directory[])
{

	struct EffectSample Es;
	int Nstudies=(*C).Nexperiments;
	int cl;
	int contrast=IsContrastStudy(C);

	memset(&Es, 0, sizeof(struct EffectSample));

	MakeEffectSampleStructure(&Es, Nstudies, ID_MEANZ);


	for (cl=1; cl<=Nclusters; cl++)
	{
		FillEffectStructureWithCluster(&Es, cl, C, contrast, ID_MEANZ, 0, directory, 0,0);

		ForestPlotCDAR(C, &Es, cl, directory);

	}


	FreeEffectSampleStructure(&Es);

	return 0;
}
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================
///==============================================================================================

