/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "CBMAfiles.h"
#include "CBclustering2.h"
#include "talairachfunctions.h"
#include "CBMAN.h"
#include "numerical.h"

int ClusterAllUsingMeanShift(struct Image *img, struct Coordinates *C, float xc[], float yc[], float zc[], int MinNeighbours, char directory[]);
double HighestDensityKernel(struct Coordinates *C, double min, double max, int MinStudies, char directory[]);
double OptimiseMeanShiftClusteringKernel(HWND hwnd, struct Image *img, struct Coordinates *C, double critical, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, double MaxWidth, char directory[]);
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], char excluded[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width);



int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double sd);

int TestCrossValidateClusters(struct Image *image, struct Coordinates *C);
