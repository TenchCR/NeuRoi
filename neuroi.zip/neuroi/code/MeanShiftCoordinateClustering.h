/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "CBMAfiles.h"
#include "CBclustering2.h"
#include "talairachfunctions.h"
#include "CBMAN.h"
#include "numerical.h"


double OptimiseMeanShiftClusteringKernel(struct Image *img, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[]);
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double width);


int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[],int MinStudies, double sd);
double ClusterDensityCDA(struct Coordinates *C, float x, float y, float z, int cluster, double Dmax);

double ROCcurveForWidth(struct Image *img, struct Coordinates *C, short int TruePositives[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[]);

int SaveClusterRadii(struct Coordinates *C, float xc[], float yc[], float zc[], int NvalidClusters);

int CDAprincipalComponenetAnalysis(struct Coordinates *C, int Nclusters, char directory[]);

int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double sd);

int TestCrossValidateClusters(struct Image *image, struct Coordinates *C);
