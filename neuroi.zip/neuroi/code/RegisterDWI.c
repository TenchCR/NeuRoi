/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


//==================================================================================================================================
//==================================================================================================================================
//BASED ON Motion correction and registration of high b-value diffusion weighted images, mrm, 2012, Jones
//==================================================================================================================================
//==================================================================================================================================



#include "registerDWI.h"
#include "tensor.h"
#include "coregister.h"
#include "sphericalharmonicfunctions.h"
#include "imageprocess.h"

struct BaseMatch
{
    float *Base;
    float *Match;
    int X;
    int Y;
    int Z;
    float dx;
    float dy;
    float dz;
};


int InitialiseDwiRegParameters(double *Reg, int Nparameters);
double DifferenceBetweenImages(double p[], int Nparameters, void *DWIvols);
double MinimiseDifference(float *Base, float *Match, float dx, float dy, float dz, int X, int Y, int Z, double param[], int Nparams);
int GetFittedImage(float *dwi, float *fit, int X, int Y, int Z, float dx, float dy, float dz, int directions, double *SH, double *InvSH,
                   double parameters[], int Nparams);
int ReformatDWIvolume(float dwi[], float rdwi[], int X, int Y, int Z, float dx, float dy, float dz, double param[], int Nparams, int LAGRANGE);
//=============================================================================================
//Use the residuals from a spherical harmonic fit to register the DWI volumes
//=============================================================================================



#define ORDER 2
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
int AllignDWIimages(HWND hwnd, struct Image *DWI, struct ThreeVector xyz[])
{

    struct Image SHfit, smoothed;
    double *Reg=NULL;
    double *SH=NULL, *InvSH=NULL;
    double diff;
    float sum,sum2;
    int voxel,voxels=(*DWI).X*(*DWI).Y*(*DWI).Z/(*DWI).volumes;
    int vol, volumes=(*DWI).volumes;
    int iter;
    int result=0;
    int Nsh=NumberSHs(ORDER);
    int dir;
    HDC hDC=GetDC(hwnd);
    char txt[256];
    unsigned char dummy;


    memset(&SHfit,0,sizeof(struct Image));
    memset(&smoothed,0,sizeof(struct Image));

    if (!(SH=(double *)malloc(Nsh*(volumes-1)*sizeof(double)))) goto END;
    if (!(InvSH=(double *)malloc(Nsh*(volumes-1)*sizeof(double)))) goto END;
    if (!(Reg=(double *)malloc(DWI_REG_PARAMETERS*volumes*sizeof(double)))) goto END;

//INITIALISE THE REGISTRATION PARAMETERS
    for (vol=0; vol<volumes; vol++) InitialiseRegistrationParameters(&Reg[vol*DWI_REG_PARAMETERS], DWI_REG_PARAMETERS);



//Psuedo Inverse Matrix
    for (dir=0; dir<volumes-1; dir++)
    {
        SHgivenDirection(&SH[dir*Nsh], ORDER, &xyz[dir+1]);
    }
    memcpy(InvSH,SH,sizeof(double)*Nsh*(volumes-1));
    if (!PsuedoInverse(InvSH, volumes-1, Nsh)) goto END;




//create the fitted image
    if (!MakeCopyOfImage(DWI, &SHfit)) goto END;





//create a smoothed DWI image to help registration
    if (!MakeCopyOfImage(DWI, &smoothed)) goto END;
    FilterImage(&smoothed, GAUSSIAN, 2.0);



//ALLIGN THE DWI IMAGES, BUT NOT THE T2 IMAGE
    for (iter=0; iter<5; iter++)
    {
        //compute SHfit image
        GetFittedImage(&(*DWI).img[voxels], &SHfit.img[voxels], (*DWI).X, (*DWI).Y, (*DWI).Z/(*DWI).volumes,
                       (*DWI).dx, (*DWI).dy, (*DWI).dz, volumes-1, SH, InvSH, &Reg[DWI_REG_PARAMETERS], DWI_REG_PARAMETERS);

        for (vol=1; vol<volumes; vol++)
        {
            //compute best parameters for vol
            diff=MinimiseDifference(&SHfit.img[vol*voxels], &smoothed.img[vol*voxels], SHfit.dx, SHfit.dy, SHfit.dz,
                                    SHfit.X, SHfit.Y, SHfit.Z/SHfit.volumes,
                                    &Reg[vol*DWI_REG_PARAMETERS], DWI_REG_PARAMETERS);

            RemoveInput(hwnd);
            sprintf(txt,"Register DWI. Iteration=%d volume=%d Difference=%f   ",iter,vol,diff);
            TextOut(hDC,100,150,txt,strlen(txt));
            UpdateWindow(hwnd);
        }

    }


//memcpy(&Reg[DWI_REG_PARAMETERS*(volumes-1)], &Reg[DWI_REG_PARAMETERS*(volumes-2)], sizeof(double)*DWI_REG_PARAMETERS);

/*
int i;
FILE *fp;
if ((fp=fopen("c://temp//regparams.txt","w")))
{
    for (vol=1; vol<volumes; vol++)
    {
        fprintf(fp,"Volume %d\n",vol);
        for (i=0;i<DWI_REG_PARAMETERS;i++)
        {
            fprintf(fp,"%f\n",Reg[vol*DWI_REG_PARAMETERS + i]);
        }
    }
    fclose(fp);
}
*/





    for (vol=1; vol<volumes; vol++)
    {
        //Reformat vol according to registration parameters
        ReformatDWIvolume(&(*DWI).img[vol*voxels], &smoothed.img[vol*voxels], (*DWI).X, (*DWI).Y, (*DWI).Z/(*DWI).volumes,
                          (*DWI).dx, (*DWI).dy, (*DWI).dz, &Reg[vol*DWI_REG_PARAMETERS], DWI_REG_PARAMETERS, 1);
    }
    memcpy(&(*DWI).img[voxels], &smoothed.img[voxels], voxels*sizeof(float)*(volumes-1));
    //goto END;

//MAKE A CONTRAST IMAGE BASED ON MEAN OF THE SIGNAL OVER DIRECTIONS
    for (voxel=0; voxel<voxels; voxel++)
    {
        sum=sum2=0;
        for (vol=1; vol<volumes; vol++)
        {
            sum+=smoothed.img[vol*voxels+voxel];
            sum2+=smoothed.img[vol*voxels+voxel]*smoothed.img[vol*voxels+voxel];
        }
        smoothed.img[voxel]=sum/volumes;
        //if (sum2>=sum*sum/(volumes-1)) SHfit.img[voxel]=sqrt(sum2-sum*sum/(volumes-1));
        //else SHfit.img[voxel]=0.0;
    }


    //REGISTER T2 TO THE CONTRAST IMAGE AND REFORMAT
    RegisterTwoImagesP(hwnd, &smoothed, DWI, Reg, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);
    ReformatDWIvolume((*DWI).img, smoothed.img, (*DWI).X, (*DWI).Y, (*DWI).Z/(*DWI).volumes,
                          (*DWI).dx, (*DWI).dy, (*DWI).dz, Reg, DWI_REG_PARAMETERS, 0);







END:
    ReleaseImage(&SHfit);
    ReleaseImage(&smoothed);
    if (Reg) free(Reg);
    if (SH) free(SH);
    if (InvSH) free(InvSH);
    ReleaseDC(hwnd,hDC);

    return result;
}
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
int TestAllignDWI(HWND hwnd, struct Image *DWI)
{
    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];
    if (!LoadAcquisitionDirections(V)) return 0;

    AllignDWIimages(hwnd, DWI, V);
    return 1;
}


//=============================================================================================
//					Compute the difference between images
//					This is to attempt a transofrmation in DWI images
//					which are difficult to register
//=============================================================================================
double DifferenceBetweenImages(double p[], int Nparameters, void *DWIvols)
{

    struct BaseMatch *MB=(struct BaseMatch *)DWIvols;
    double diff=0.0;
    double *poly=NULL;
    struct AffineMatrix M;
    float x,y,z;
    float x0,y0,z0;
    float Base;
    float I;
    float xb,yb,zb;//base coordinates
    int *polyorder=NULL;
    int xi,yi,zi;
    int X,Y,Z,XY,yX,zXY;
    int xv,yv,zv;
    int voxel;
    int norm=0;

    if (!(poly=(double *)malloc(sizeof(double)*DWI_REG_PARAMETERS))) goto END;
    if (!(polyorder=(int *)malloc(sizeof(int)*DWI_REG_PARAMETERS))) goto END;


    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6) M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);

    x0=(*MB).dx*(*MB).X/2.0;
    y0=(*MB).dy*(*MB).Y/2.0;
    z0=(*MB).dz*(*MB).Z/2.0;

    X=(*MB).X;
    Y=(*MB).Y;
    Z=(*MB).Z;
    XY=X*Y;

    for (zi=0; zi<Z; zi+=4)
    {
        zXY=zi*XY;
        zb=(*MB).dz*zi-z0;
        for (yi=0; yi<Y; yi+=4)
        {
            yX=yi*X;
            yb=(*MB).dy*yi-y0;
            for (xi=0; xi<X; xi+=3)
            {
                xb=(*MB).dx*xi-x0;
                voxel=xi+yX+zXY;
                if ((Base=(*MB).Base[voxel])>0.0)
                {

                    x=xb;
                    y=yb;
                    z=zb;

                    if (Nparameters>AFFINE12) PolynomialRegressors3DTermOrderSorted(x,y,z,poly,polyorder,DWI_REG_ORDER);
                    GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0,(*MB).dx, (*MB).dy, (*MB).dz, &M, p, poly, Nparameters);

                    xv=(int)(x+0.5);
                    yv=(int)(y+0.5);
                    zv=(int)(z+0.5);


                    if (InImageRange(xv,yv,zv,X,Y,Z))
                    {
                        voxel=xv + yv*X + zv*XY;
                        I=(*MB).Match[voxel];
                        if (I>0.0)
                        {
                            diff += (Base+I)*(Base-I)*(Base-I);//squared difference weighted by Base+Match intensity (to reduce influence of noisy voxels)
                            norm++;
                        }
                    }

                    /*I=Lagrange3D((*MB).Match, X, Y, Z, (double)x, (double)y, (double)z);
                    if (I>0.0)
                    {
                        diff += (Base+I)*(Base-I)*(Base-I);//squared difference weighted by Base+Match intensity (to reduce influence of noisy voxels)
                        norm++;
                    }*/
                }
            }
        }
    }

END:
    if (poly) free(poly);
    if (polyorder) free(polyorder);

    if (norm) return diff/norm;
    else return 0.0;
}

//=============================================================================================
//MINIMISE THE DIFFERENCE BETWEEN TWO VOLUMES
//=============================================================================================
double MinimiseDifference(float *Base, float *Match, float dx, float dy, float dz, int X, int Y, int Z, double param[], int Nparams)
{
    double scale[DWI_REG_PARAMETERS];
    struct BaseMatch BM;
    double E0,E;
    int i;

    memset(&BM,0,sizeof(struct BaseMatch));
    BM.Base=Base;
    BM.Match=Match;
    BM.X=X;
    BM.Y=Y;
    BM.Z=Z;
    BM.dx=dx;
    BM.dy=dy;
    BM.dz=dz;


    memset(scale,0,sizeof(double)*DWI_REG_PARAMETERS);
    scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=0.5;
    scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=PI/180.0;
    if (Nparams>RIGID6)
    {
        scale[SCALE]=scale[SCALE+1]=scale[SCALE+2]=0.05;
        scale[SHEAR]=scale[SHEAR+1]=scale[SHEAR+2]=0.05;//x-y shear

        for (i=AFFINE12; i<Nparams; i++)
        {
            scale[i]=0.05;
        }
    }
    E0=DifferenceBetweenImages(param, Nparams, &BM);
    E=DownHillSimplex(param, Nparams, scale, 1,DifferenceBetweenImages, &BM, 20);
    //E=PowellsBrentsMethod(param, Nparams, scale, 1, DifferenceBetweenImages, &BM, 1.0e-2);

    return E-E0;
}


//=============================================================================================
//FIT SPHERICAL HARMONICS THEN PRODUCE AN IMAGE OF THE FITTED VALUES
//=============================================================================================
int GetFittedImage(float *dwi, float *fit, int X, int Y, int Z, float dx, float dy, float dz, int directions, double *SH, double *InvSH,double parameters[], int Nparams)
{
    int N=NumberSHs(ORDER);
    int row,col,i,dir,DirVoxels,DirN,ColN,ColVoxels;
    int result=0;
    int voxel,voxels=X*Y*Z;
    int volume;
    double *coef=NULL;



    if (!(coef=(double *)malloc(sizeof(double)*N))) goto END;

//FIRST APPLY TRANSFORMATION TO dwi IMAGE AND PUT IN fit
    for (volume=0; volume<directions; volume++)
    {
        ReformatDWIvolume(&dwi[volume*voxels], &fit[volume*voxels], X, Y, Z, dx, dy, dz, &parameters[volume*DWI_REG_PARAMETERS], Nparams,1);
    }



    for (voxel=0; voxel<voxels; voxel++)
    {
        //get the expansion coefficients
        for (row=0; row<N; row++)
        {
            coef[row]=0.0;
            ColN=ColVoxels=0;
            for (col=0; col<directions; col++)
            {
                coef[row] += InvSH[ColN+row]*fit[ColVoxels+voxel];
                ColN += N;
                ColVoxels += voxels;
            }
        }

        //get the fit
        for (dir=0; dir<directions; dir++)
        {
            DirVoxels=dir*voxels;
            DirN=dir*N;
            fit[voxel+dir*voxels]=0.0;
            for (i=0; i<N; i++)
            {
                fit[voxel+DirVoxels] += SH[i+DirN]*coef[i];
            }
        }

    }



    result=1;
END:
    if (coef) free(coef);

    return result;
}

//=============================================================================================
//REFORMAT A DWI VOLUME GIVEN THE PARAMETERS
//p0[] are the parameters for registration to the T2 image and must be applied second
//=============================================================================================
int ReformatDWIvolume(float dwi[], float rdwi[], int X, int Y, int Z, float dx, float dy, float dz, double param[], int Nparams, int LAGRANGE)
{
    double *p=param;
    struct AffineMatrix M;
    double *poly=NULL;
    int *polyorder=NULL;
    int x,y,z,voxel;
    int result=0;
    float xf,yf,zf;
    float yb,zb;
    float x0,y0,z0;



    if (!(poly=(double *)malloc(sizeof(double)*DWI_REG_PARAMETERS))) goto END;
    if (!(polyorder=(int *)malloc(sizeof(int)*DWI_REG_PARAMETERS))) goto END;



    x0=dx*X/2.0;
    y0=dy*Y/2.0;
    z0=dz*Z/2.0;

    M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);

    voxel=0;
    for (z=0; z<Z; z++)
    {
        zb=dz*z-z0;
        for (y=0; y<Y; y++)
        {
            yb=dy*y-y0;
            for (x=0; x<X; x++)
            {


                xf=dx*x-x0;
                yf=yb;
                zf=zb;

                //transform to the model image
                if (Nparams>AFFINE12) PolynomialRegressors3DTermOrderSorted(xf,yf,zf,poly,polyorder,DWI_REG_ORDER);
                GetTransformedVoxelCoordinates(&xf, &yf, &zf, x0, y0, z0,dx, dy, dz, &M, p, poly, Nparams);


                if (LAGRANGE) rdwi[voxel]=Lagrange3D(dwi, X, Y, Z, (double)xf,(double)yf, (double)zf);
                else rdwi[voxel]=CubicInterpolation3D(dwi, X, Y, Z, (double)xf,(double)yf, (double)zf);


                voxel++;
            }
        }
    }

    result = 1;
END:
    if (poly) free(poly);
    if (polyorder) free(polyorder);

    return result;
}
