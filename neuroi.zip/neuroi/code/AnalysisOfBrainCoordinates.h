/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(CDA_H)
//Do Nothing
#else
#define CDA_H


#include "MeanShiftCoordinateClusteringABC.h"
#include "CBclustering2.h"
#include "ClusterZ.h"
#include "talairachfunctions.h"
#include "CBMAN.h"
#include "numerical.h"
#include "localALE.h"


#define GM_VOLUME 780000.0
#define WM_VOLUME 390000.0
#define BRAIN_VOLUME (GM_VOLUME+WM_VOLUME)



HWND hABC;

INT_PTR CALLBACK ABC_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
double GetClusteringProbabilityForCoordinates(HWND hwnd, struct Coordinates *C, char exclude[], double volume, double Pthresh, int NumberOfNearest);
double ABCthreshold(struct Coordinates *C, double fdr, int Nexpected, double *Pfdr);

int SaveEdgeAnalysis(HWND hwnd, struct Coordinates *C, float xp[], float yp[], float zp[], int Nclusters, int Compare, char directory[]);

int SaveBetweenStudyCorrelation(struct Coordinates *C, struct Image *mask, char directory[], int FileIndex);

int SaveStudyContributions(struct Coordinates *C, unsigned char FileNumber[], int UseFileNumber, char directory[]);
int SaveBRLforAllClusters(struct Coordinates *C, int Nclusters, unsigned char FileNumber[], char fnames[], int Nfiles, double SD, char directory[]);
int SaveTalairachNetworkProjectionABC(HWND hwndMain,
                                      struct Coordinates *Co,
                                      double Rho[], double SE[],
                                      float xp[],float yp[], float zp[],
                                      int Nclusters,
                                      char directory[], char name[]);
int ContributionImageABC(HWND hwndMain,
                         struct Coordinates *Co,
                         float xp[],float yp[], float zp[],
                         int Nclusters,
                         char directory[], char name[]);

int ClusterAssociationTable(int *a, int *b, int *c, int *d, struct Coordinates *C, int cl1, int cl2);
#endif
