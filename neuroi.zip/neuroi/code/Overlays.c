/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "overlays.h"
#include "imageprocess.h"
#include "display.h"

RGBQUAD ColourMap(int col, int intensity);
//===============================================================================================================================
//load overlay images up to MAX_OVERLAYS
//make sure they have the same image dimensions as *image
//===============================================================================================================================
int LoadOverlayImage(HWND hwnd, int AddImage, struct Image *image)
{
    RGBQUAD rgbQuad;
    int X,Y,Z;
    int i;
    int voxel,voxels;


        //if the maximum number of overlays is already loaded
        //load it into the last overlay
        if (AddImage && (gNumberOfOverlays>=MAX_OVERLAYS))
        {
            ReleaseImage(&gOverlayImg[MAX_OVERLAYS-1]);
            gNumberOfOverlays=MAX_OVERLAYS-1;
        }
        else if (!AddImage) ReleaseOverlays();


        if (LoadAnalyzeOrNifti(hwnd, &gOverlayImg[gNumberOfOverlays], 1))
        {
            X=gOverlayImg[gNumberOfOverlays].X;
            Y=gOverlayImg[gNumberOfOverlays].Y;
            Z=gOverlayImg[gNumberOfOverlays].Z;
            voxels=X*Y*Z;
            //check for correct dimensions
            if ((X!=(*image).X) || (Y!=(*image).Y) || (Z!=(*image).Z))
            {
                ReleaseImage(&gOverlayImg[gNumberOfOverlays]);
                return 0;
            }

            //convert scalars into RGB
            if ( IsImageScalar(gOverlayImg[gNumberOfOverlays].DataType) )
            {
                for (voxel=0;voxel<voxels;voxel++)
                {
                    i=MAX_INTENSITY*(gOverlayImg[gNumberOfOverlays].img[voxel]/gOverlayImg[gNumberOfOverlays].MaxIntensity);
                    if (i>=MAX_INTENSITY) i=MAX_INTENSITY-1;
                    if (i<0) i=0;

                    rgbQuad=ColourMap(gNumberOfOverlays, i);
                    memcpy(&gOverlayImg[gNumberOfOverlays].img[voxel], &rgbQuad, sizeof(float));
                }
            }
            gNumberOfOverlays++;
        }
        else return 0;

        return 1;
}
//===============================================================================================================================
//colour map
//===============================================================================================================================
RGBQUAD ColourMap(int col, int intensity)
{
    RGBQUAD rgb;
    memset(&rgb,0,sizeof(RGBQUAD));
    double f=(double)intensity/MAX_INTENSITY;

    if (f>1.0) f=1.0;

    //intensity=MAX_INTENSITY*f*f;

    if (col==0)
    {
        if (intensity<MAX_INTENSITY/2) rgb.rgbRed=2*intensity;
        else rgb.rgbRed=MAX_INTENSITY;
        if (intensity>MAX_INTENSITY/2)
        {
            rgb.rgbGreen=(intensity-MAX_INTENSITY/2)*2;
            rgb.rgbBlue=(intensity-MAX_INTENSITY/2)*2;
        }
    }
    else if (col==1)
    {
        if (intensity<MAX_INTENSITY/2) rgb.rgbGreen=2*intensity;
        else rgb.rgbGreen=MAX_INTENSITY;
        if (intensity>MAX_INTENSITY/2)
        {
            rgb.rgbRed=(intensity-MAX_INTENSITY/2)*2;
            rgb.rgbBlue=(intensity-MAX_INTENSITY/2)*2;
        }
    }
    else if (col==2)
    {
        if (intensity<MAX_INTENSITY/2) rgb.rgbBlue=2*intensity;
        else rgb.rgbBlue=MAX_INTENSITY;
        if (intensity>MAX_INTENSITY/2)
        {
            rgb.rgbRed=(intensity-MAX_INTENSITY/2)*2;
            rgb.rgbGreen=(intensity-MAX_INTENSITY/2)*2;
        }
    }
    return rgb;
}

//===============================================================================================================================
//release the overlay images
//===============================================================================================================================
int ReleaseOverlays(void)
{
    int overlay;

    for (overlay=0; overlay<gNumberOfOverlays; overlay++)
    {
        ReleaseImage(&gOverlayImg[overlay]);
    }
    gNumberOfOverlays=0;

    return 1;
}
