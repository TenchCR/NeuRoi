/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

//==============================================================================
//              Fit the equation s_i=s0(1-Fexp(-TI_i/T1))
//              The TI_i is the ith inversion time
//              s0 is the proton density, but not quantitative
//==============================================================================

//#include <time.h>
#include "fitT1.h"
#include "display.h"
#include "numerical.h"
#include "menuresources.h"
#include "global.h"





#define PT1 0
#define PF  1
#define SIGMA2 2
#define PM0 3


#define MAXT1  7000.0

//a structure that contains the fitted parameters
struct T1parameters
{
    double T1;
    double M0;
    double F;
    double SSresiduals;//sum of squared residuals for (N-1) TI points; (N-1) because null must be removed
};

struct T1dat
{
    double *y;
    double *TI;
    int N;
    double sigma2;
};




double T1RecoveryCurve(double T1, double F, double M0, double t);
double M0Estimate(double Si[], double TIs[], int N_TIs, double T1, double F);
double M0EstimateEx(double Si[], double Fit[], double TIs[], int N_TIs, double T1, double F);
double GetMeasuredSignal(double y[], int N, int voxel, double threshold);
double T1GoodnessOfFit(double p[], int params, void *dat);
double T1Likelihood(double p[], int params, void *dat);
int LoadInversionImages(HWND hwnd, char directory[], int StandardiseScale);
double GetInversionTime(struct Image *image);
double ExplainedVariance(double y[], double TI[], int N, double T1, double S0, double F);

struct T1parameters FitT1Param(double y[], double TIs[], int N_TIs, int MLE);
struct T1parameters OptimiseT1Fit(double y[], double TIs[], int N_TIs, double T1, double F);

int SaveT1(struct Image *T1image, char directory[]);

//==============================================================================
//                  Fit T1 and M0 and F to TI data
//==============================================================================
int FitT1ToIR(HWND hwnd, struct Image *image, int smooth, int StandardiseScale, int MLE, int loaded)
{

    double TIs[MAX_TIs];
    double y[MAX_TIs], yfit[MAX_TIs];
    double F;
    double T1;
    double maxint;
    double ExplVar;
    float min;
    float M0mean;
    int i;
    int voxel;
    int X, Y, Z, volumes, voxelspv;
    int counter=0;
    int removeinputcounter;
    float dx, dy, dz, x0, y0, z0;
    struct T1parameters t1parameters;
    char txt[1024];
    char directory[MAX_PATH];
    unsigned char *cmask=NULL;
    HDC hDC;

    memset(directory,0,MAX_PATH);
    if (!loaded)
    {
        memset(&T1mask,0,sizeof(struct Image));
        if ((loaded=LoadInversionImages(hwnd, directory, StandardiseScale))<=2) goto END;
        if (!LoadAnalyzeOrNiftiEx(hwnd, &T1mask, "Load the mask", 0)) goto END;
    }
    else
    {
        sprintf(directory,"%s",TIimages[0].filename);
        directory[DirectoryFileDivide(TIimages[0].filename)]='\0';
    }


    //maxint determines a threshold to remove noise
    maxint=0.0;
    for (i=0; i<loaded; i++)
    {
        if (TIimages[i].MaxIntensity>maxint) maxint=TIimages[i].MaxIntensity;
        TIs[i]=GetInversionTime(&TIimages[i]);
        if (!TIs[i]) goto END;
    }


    X=TIimages[0].X;
    Y=TIimages[0].Y;
    Z=TIimages[0].Z;
    volumes=TIimages[0].volumes;
    voxelspv=X*Y*Z/volumes;
    dx=TIimages[0].dx;
    dy=TIimages[0].dy;
    dz=TIimages[0].dz;
    x0=TIimages[0].x0;
    y0=TIimages[0].y0;
    z0=TIimages[0].z0;



    //get the mask, which can be used to stop calculation outside brain and speed things up
    if (!((T1mask.X==X) && (T1mask.Y==Y) && (T1mask.Z/T1mask.volumes==Z/volumes))) goto END;
    if (!(cmask=(unsigned char *)malloc(voxelspv))) goto END;
    memset(cmask,1,voxelspv);
    for (voxel=0; voxel<voxelspv; voxel++) if (T1mask.img[voxel]<=0.0) cmask[voxel]=0;
    ReleaseImage(&T1mask);



    ReleaseImage(image);
    if (!MakeImage(image, X, Y, Z/volumes, 4, dx, dy, dz, x0, y0, z0, 1.0, 0.0, DT_FLOAT, HDR, "T1 image")) goto END;
    memset((*image).img, 0, sizeof(float)*voxelspv*4);
    sprintf((*image).PatientID,"%s", TIimages[0].PatientID);
    if (smooth) sprintf((*image).Descrip,"%s|smooth",(*image).Descrip);
    if (MLE) sprintf((*image).Descrip,"%s|MLE",(*image).Descrip);




    removeinputcounter=0;
    counter=0;
    for (voxel=0; voxel<voxelspv; voxel++)
    {
        if (cmask[voxel])
        {
            removeinputcounter++;
            if (removeinputcounter>1000)
            {
                if (EscapePressed(hwnd)) goto END;
                RemoveInput(hwnd);
                removeinputcounter=0;
            }

            if ((GetMeasuredSignal(y, loaded, voxel, maxint*0.001))>0.0)
            {
                t1parameters=FitT1Param(y, TIs, loaded, MLE);
                // t1parameters=FitT1Param(y, TIs, loaded, loaded+1, MLE);

                ExplVar=ExplainedVariance(y, TIs, loaded, t1parameters.T1, t1parameters.M0, t1parameters.F);

                if ((t1parameters.T1>0.0) && (t1parameters.F>0.0))
                {

                    (*image).img[voxel]=t1parameters.T1;
                    (*image).img[voxel+voxelspv]=t1parameters.M0;
                    (*image).img[voxel+2*voxelspv]=t1parameters.F;
                    (*image).img[voxel+3*voxelspv]=1000.0*ExplVar;

                    if (counter>=1000)
                    {
                        for (i=0; i<loaded; i++)
                        {
                            yfit[i]=T1RecoveryCurve(t1parameters.T1, t1parameters.F, t1parameters.M0, TIs[i]);
                        }
                        PlotFittedRecoveryCurve(hwnd, yfit, y, TIs, loaded);
                        counter=0;

                    }
                    counter++;
                }
            }
        }
    }//voxel





    //if we are going to smooth the image and do a constrained 2 parameter fit
    if (smooth && (!MLE))
    {

        //Smooth the image
        hDC=GetDC(hwnd);
        sprintf(txt,"Smoothing                  ");
        TextOut(hDC, 50,50,txt,strlen(txt));
        ReleaseDC(hwnd, hDC);

        //smooth T1 and the F value
        GaussFilterFastEx((*image).img, X, Y, Z/volumes, dx, dy, dz, 2.0, 0);
        GaussFilterFastEx(&(*image).img[2*voxelspv], X, Y, Z/volumes, dx, dy, dz, 2.0, 0);

        //use the smoothed images to initialise a 2 parameter fit
        counter=removeinputcounter=0;
        for (voxel=0; voxel<voxelspv; voxel++)
        {
            if (cmask[voxel] && (GetMeasuredSignal(y, loaded, voxel, maxint*0.01))>0.0)
            {
                removeinputcounter++;
                if (removeinputcounter>1000)
                {
                    if (EscapePressed(hwnd)) goto END;
                    RemoveInput(hwnd);
                    removeinputcounter=0;
                }

                T1=(*image).img[voxel];
                F=(*image).img[2*voxelspv+voxel];

                if (T1>0.0)
                {
                    t1parameters=OptimiseT1Fit(y, TIs, loaded, T1, F);
                    ExplVar=ExplainedVariance(y, TIs, loaded, t1parameters.T1, t1parameters.M0, t1parameters.F);
                }
                else
                {
                    memset(&t1parameters,0,sizeof(struct T1parameters));
                    ExplVar=0.0;
                }

                if ((T1>0.0) && (t1parameters.T1>0.0) && (F>0.0))
                {
                    (*image).img[voxel]=t1parameters.T1;
                    (*image).img[voxel+voxelspv]=t1parameters.M0;
                    (*image).img[voxel+2*voxelspv]=F;
                    (*image).img[voxel+3*voxelspv]=1000.0*ExplVar;
                }
                else
                {
                    (*image).img[voxel]=0.0;
                    (*image).img[voxel+voxelspv]=0.0;
                    (*image).img[voxel+2*voxelspv]=0.0;
                    (*image).img[voxel+3*voxelspv]=1000.0*ExplVar;
                }
            }
            else
            {
                (*image).img[voxel]=0.0;
                (*image).img[voxel+voxelspv]=0.0;
                (*image).img[voxel+2*voxelspv]=0.0;
                (*image).img[voxel+3*voxelspv]=0.0;
            }

            if (counter>=5000)
            {
                for (i=0; i<loaded; i++)
                {
                    yfit[i]=T1RecoveryCurve(t1parameters.T1, t1parameters.F, t1parameters.M0, TIs[i]);
                }
                PlotFittedRecoveryCurve(hwnd, yfit, y, TIs, loaded);
                counter=0;
            }
            counter++;
        }

    }//smooth








    //normalise the different volumes
    M0mean=0.0;
    counter=0;
    for (voxel=0; voxel<voxelspv; voxel++)
    {
        if (cmask[voxel])
        {
            M0mean+=(*image).img[voxel+voxelspv];
            counter++;
        }
    }
    if (counter && (M0mean>0.0))
    {
        M0mean/=counter;
        for (voxel=0; voxel<voxelspv; voxel++)
        {
            (*image).img[voxel+voxelspv]*=(1000.0/M0mean);
            (*image).img[voxel+2*voxelspv]*=1000.0;
        }
    }
    ImageMinMax((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).DataType, &min, &(*image).MaxIntensity);
    SaveT1(image, directory);




END:

    if (cmask) free(cmask);
    InvalidateRect(hwnd, NULL,1);
    UpdateWindow(hwnd);

    if (loaded<0) loaded*=-1;
    for (i=0; i<loaded; i++) ReleaseImage(&TIimages[i]);

    return 1;
}




//==============================================================================
//                      Fit the T1, s0, and F value to the data
//                      y[] are the measured values
//                      TIs[] are the inversion times
//                      N_TIs is the number of inversion times
//==============================================================================
struct T1parameters FitT1Param(double y[], double TIs[], int N_TIs, int MLE)
{

    struct T1parameters result;
    struct T1dat T1d;
    double SSresiduals, var;
    double p[3],scale[3];
    double T1,F;
    double Error, MinError;
    double dT1, dF;

    dT1=200.0;
    dF=0.2;

    T1d.y=y;
    T1d.TI=TIs;
    T1d.N=N_TIs;

    T1=p[PT1]=1500.0;
    F=p[PF]=1.8;
    MinError=T1GoodnessOfFit(p, 2, &T1d);
    for (p[PF]=1.0; p[PF]<=2.0; p[PF]+=dF)
    {
        for (p[PT1]=500.0; p[PT1]<MAXT1; p[PT1]+=dT1)
        {
            Error=T1GoodnessOfFit(p, 2, &T1d);
            if (Error<MinError)
            {
                T1=p[PT1];
                F=p[PF];
                MinError=Error;
            }
        }
    }

    scale[PT1]=100.0;
    scale[PF]=0.2;
    p[PT1]=T1;
    p[PF]=F;

    SSresiduals=DownHillSimplex(p, 2, scale, 1, T1GoodnessOfFit, &T1d, 20);
    var=SSresiduals/(N_TIs-1);

//Do the MLE if requested
    if (MLE)
    {
        p[SIGMA2]=var;
        scale[SIGMA2]=var/10.0;
        scale[PT1]=10.0;
        scale[PF]=0.02;
        DownHillSimplex(p, 3, scale, 1, T1Likelihood, &T1d, 20);
    }


    //send results back in *result
    result.M0=M0Estimate(y, TIs, N_TIs, p[PT1], p[PF]);
    result.T1=p[PT1];
    result.F=p[PF];
    result.SSresiduals=SSresiduals;

    return result;
}


//==============================================================================
//          Fit T1 given F
//==============================================================================
struct T1parameters OptimiseT1Fit(double y[], double TIs[], int N_TIs, double T1, double F)
{

    struct T1parameters result;
    double p[3];
    double miny, maxy;
    double Ea, Eb, Ec;
    double T1a, T1b, T1c;
    double x,L, GS=0.38197;
    struct T1dat T1d;
    int i;

    miny=maxy=y[0];
    for (i=1; i<N_TIs; i++)
    {
        if (y[i]<miny) miny=y[i];
        if (y[i]>maxy) maxy=y[i];
    }

    p[PF]=F;


    T1d.y=y;
    T1d.TI=TIs;
    T1d.N=N_TIs;

    T1a=T1-100.0;
    p[PT1]=T1a;
    Ea=T1GoodnessOfFit(p, 2, &T1d);

    T1b=T1;
    p[PT1]=T1b;
    Eb=T1GoodnessOfFit(p, 2, &T1d);

    T1c=T1+100.0;
    p[PT1]=T1c;
    Ec=T1GoodnessOfFit(p, 2, &T1d);


    do
    {

        if ((Ea<Eb) && (Ea<Ec))
        {
            x=1.618*(T1a-T1b)+T1a;
            Ec=Eb;
            T1c=T1b;
            Eb=Ea;
            T1b=T1a;
            T1a=x;
            p[PT1]=T1a;
            Ea=T1GoodnessOfFit(p, 2, &T1d);
        }
        else if ((Ec<Ea) && (Ec<Eb))
        {
            x=1.618*(T1c-T1b)+T1c;
            Ea=Eb;
            T1a=T1b;
            Eb=Ec;
            T1b=T1c;
            T1c=x;
            p[PT1]=T1c;
            Ec=T1GoodnessOfFit(p, 2, &T1d);
        }
        else
        {
            if ((T1b-T1a)>(T1c-T1b))
            {
                L=(T1b-T1a);
                Ec=Eb;
                T1c=T1b;
                T1b=T1a+L*GS;
                p[PT1]=T1b;
                Eb=T1GoodnessOfFit(p, 2, &T1d);
            }
            else
            {
                L=(T1c-T1b);
                Ea=Eb;
                T1a=T1b;
                T1b+=L*GS;
                p[PT1]=T1b;
                Eb=T1GoodnessOfFit(p, 2, &T1d);
            }
        }
    }
    while((T1c-T1a)>1.0);


    //send results back in *result
    result.M0=M0Estimate(y, TIs, N_TIs, T1b, F);
    result.T1=T1b;
    result.F=F;
    result.SSresiduals=Eb;

    return result;
}







//==============================================================================
//              Given T1, M0, F, and t
//              Return the inversion recovery curve value
//==============================================================================
double T1RecoveryCurve(double T1, double F, double M0, double t)
{
    if (T1<=0.0) return 0.0;
    //return M0*fabs(1.0-F*Padexp4(-t/T1));
    return M0*fabs(1.0-F*exp(-t/T1));
}

//==============================================================================
//            Given parameters T1 and F, estimate parameter M0
//            Si are the absolute values of the measurements
//            null is the null measurement; smallest measurement, assumed to be noise
//==============================================================================
double M0Estimate(double Si[], double TIs[], int N_TIs, double T1, double F)
{

    double A,B;
    double yi;
    int i;


    A=B=0.0;
    for (i=0; i<N_TIs; i++)
    {

        yi=T1RecoveryCurve(T1, F, 1.0, TIs[i]);
        A+=Si[i]*yi;
        B+=yi*yi;

    }

    if (B>0.0) return A/B;
    else return 0.0;
}
//==============================================================================
//            Given parameters T1 and F, estimate parameter M0
//            Si are the absolute values of the measurements
//            Fit[] is the fitted model
//            null is the null measurement; smallest measurement, assumed to be noise
//==============================================================================
double M0EstimateEx(double Si[], double Fit[], double TIs[], int N_TIs, double T1, double F)
{

    double A,B;
    double yi;
    int i;


    A=B=0.0;
    for (i=0; i<N_TIs; i++)
    {

        yi=Fit[i];
        A+=Si[i]*yi;
        B+=yi*yi;

    }

    if (B>0.0) return A/B;
    else return 0.0;
}


//==============================================================================
//                  Get Goodness Of Fit using sum of Absolute of residual
//==============================================================================
double T1GoodnessOfFit(double p[], int params, void *dat)
{

    struct T1dat *T1d=(struct T1dat *)dat;
    int TI;
    double residual=0.0;
    double M0,T1,F;
    double r;
    double Fit[MAX_TIs];

    T1=p[PT1];
    F=p[PF];



    //if the parameters are out of range, return the variance of the unfitted data
    if ((T1<=0.0) || (T1>=MAXT1) || (F<=0.0) || (F>2.0))
    {
        for (TI=0; TI<(*T1d).N; TI++)
        {
            residual+=pow((*T1d).y[TI],2);
        }
        return residual;
    }

    for (TI=0; TI<(*T1d).N; TI++) Fit[TI]=T1RecoveryCurve(T1, F, 1.0, (*T1d).TI[TI]);

    M0=M0EstimateEx((*T1d).y, Fit, (*T1d).TI, (*T1d).N, T1, F);
    for (TI=0; TI<(*T1d).N; TI++)
    {
        r=(*T1d).y[TI] - M0*Fit[TI];
        residual+=pow( r ,2 );
    }

    return residual;
}

//==============================================================================
//         Get the likelihood assuming Rician distribution of noise
//==============================================================================
double T1Likelihood(double p[], int params, void *dat)
{

    struct T1dat *T1d=(struct T1dat *)dat;
    int TI;
    double residual=0.0;
    double T1,F, M0, sigma2;
    double L=1.0;
    double Fit[MAX_TIs];

    T1=p[PT1];
    F=p[PF];
    sigma2=(*T1d).sigma2;//sigma2 is known



    //if the parameters are out of range, return the variance of the unfitted data
    if ((T1<=0.0) || (T1>=MAXT1) || (F<=0.0) || (F>2.0))
    {
        for (TI=0; TI<(*T1d).N; TI++)
        {
            residual+=pow((*T1d).y[TI],2);
        }
        return residual;
    }


    for (TI=0; TI<(*T1d).N; TI++) Fit[TI]=T1RecoveryCurve(T1, F, 1.0, (*T1d).TI[TI]);
    M0=M0EstimateEx((*T1d).y, Fit, (*T1d).TI, (*T1d).N, T1, F);
    for (TI=0; TI<(*T1d).N; TI++)
    {
        L*=Rician(M0*Fit[TI], (*T1d).y[TI], sigma2);
    }

    return -L;
}


//==============================================================================
//              Get the measured values
//              the *max is the scale factor on return
//              At least one of the y[] must be above threshold
//              *null is the index to the lowest data point
//==============================================================================
double GetMeasuredSignal(double y[], int N, int voxel, double threshold)
{

    int i;
    float max=TIimages[0].img[voxel]*TIimages[0].scale;
    //char txt[256];

    y[0]=max;
    for (i=1; i<N; i++)
    {
        y[i]=TIimages[i].img[voxel]*TIimages[i].scale;
        if (y[i]>max) max=y[i];
    }

    /*if (max>threshold){
    sprintf(txt,"%f %f",threshold, max);
    MessageBox(NULL,txt,"",MB_OK);
    }*/

    if ( max>threshold ) return max;
    else return 0.0;

}


//==============================================================================
//                      Load the multiple inversion time images
//                      return the number of TI images loaded (must be >2)
//                      if there is an error in loading, return -i,
//                          the number loaded before the error
//==============================================================================
int LoadInversionImages(HWND hwnd, char directory[], int StandardiseScale)
{

    int nImages;
    char ImageNames[MAX_PATH*MAX_TIs];



    memset(ImageNames, 0, MAX_PATH*MAX_TIs);
    nImages=GetImageFileNames(ImageNames, MAX_PATH*MAX_TIs, "Select Inversion Images");

    return LoadInversionImagesGivenNames(hwnd, directory, StandardiseScale, ImageNames, nImages);
}


//==============================================================================
//                      Load the multiple inversion time images
//                      return the number of TI images loaded (must be >2)
//                      if there is an error in loading, return -i,
//                          the number loaded before the error
//==============================================================================
int LoadInversionImagesGivenNames(HWND hwnd, char directory[], int StandardiseScale, char ImageNames[], int nImages)
{

    float MaxScale;
    int i;
    double TIs[MAX_TIs];
    short int X, Y, Z;
    char name[MAX_PATH];
    char filetitle[MAX_PATH];
    char txt[256];
    HDC hDC=GetDC(hwnd);


    memset(TIs,0,MAX_TIs*sizeof(double));

    if (nImages>=MAX_TIs)
    {
        MessageBox(NULL,"Too many TI images","",MB_OK|MB_ICONWARNING);
        return 0;
    }


    if (nImages<2)
    {
        MessageBox(NULL,"To fit T1 there must be a minimum of 2 images","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    //GET THE DIRECTORY
    GetNthFileName(ImageNames, 0, directory);


    GetNthFileName(ImageNames, 1, name);
    if (!LoadFromFileName(hwnd, name, &TIimages[0], StandardiseScale))
    {
        MessageBox(hwnd,"Failed to load files","",MB_OK|MB_ICONWARNING);
        return 0;
    }
    //get the TI for this image
    TIs[0]=GetInversionTime(&TIimages[0]);
    if (!TIs[0]) return 0;

    X=TIimages[0].X;
    Y=TIimages[0].Y;
    Z=TIimages[0].Z;




    GetFileTitle(name, filetitle, MAX_PATH);
    TextOut(hDC,10,100,filetitle,strlen(filetitle));
    sprintf(txt,"TI=%f",TIs[0]);
    TextOut(hDC,10,120,txt,strlen(txt));
    UpdateWindow(hwnd);


    for (i=1; i<nImages; i++)
    {
        GetNthFileName(ImageNames, i+1, name);

        if (!LoadFromFileName(hwnd, name, &TIimages[i], StandardiseScale))
        {
            sprintf(txt,"Cant load image %s",name);
            MessageBox(NULL,txt,"",MB_OK);
            return -i;
        }

        if ((TIimages[i].X!=X) || (TIimages[i].Y!=Y) || (TIimages[i].Z!=Z))
        {
            MessageBox(NULL,"Images must all be of the same dimensions","",MB_OK|MB_ICONWARNING);
            ReleaseDC(hwnd, hDC);
            return -i;
        }


        //get the TI for this image
        TIs[i]=GetInversionTime(&TIimages[i]);
        if (!TIs[i])
        {
            MessageBox(NULL,"Need TI for this image","",MB_OK|MB_ICONWARNING);
            return -i;
        }
        GetFileTitle(name, filetitle, MAX_PATH);
        TextOut(hDC,10,100,filetitle,strlen(filetitle));
        sprintf(txt,"TI=%f",TIs[i]);
        hDC=GetDC(hwnd);
        TextOut(hDC,10,120,txt,strlen(txt));
        ReleaseDC(hwnd, hDC);
        UpdateWindow(hwnd);

    }

    //normalise the scales to a maximum of 1.0
    MaxScale=0.0;
    for (i=0; i<nImages; i++)
    {
        if (TIimages[i].scale>MaxScale) MaxScale=TIimages[i].scale;
    }
    if (MaxScale>0.0)
    {
        for (i=0; i<nImages; i++)
        {
            TIimages[i].scale/=MaxScale;
        }
    }
    else
    {
        for (i=0; i<nImages; i++) TIimages[i].scale=1.0;
    }

//sprintf(txt,"%d",nImages);
//MessageBox(NULL,txt,"",MB_OK);

    ReleaseDC(hwnd,hDC);
    return nImages;
}



//==============================================================================
//                  Get the TI from the header Descrip
//==============================================================================
double GetInversionTime(struct Image *image)
{

    char *txt;
    double TI=0.0;

    txt=(char *)strstr((*image).Descrip, "TI");

    if (txt) TI=(double)atof(&txt[2]);
    if (txt && !TI) TI=(double)atof(&txt[3]);

    if (TI<0.0) return 0.0;
    return TI;
}
//==============================================================================
//                  Get explained variance %
//==============================================================================
double ExplainedVariance(double y[], double TI[], int N, double T1, double M0, double F)
{

    double X,X2,Y,Y2;
    double var,resvar;
    double E;
    int i;

    if (N<=0) return 0;

    X=X2=Y=Y2=0.0;
    for (i=0; i<N; i++)
    {
        Y+=y[i];
        Y2+=y[i]*y[i];
        if (T1>=0.0) E=Padexp4(-TI[i]/T1);
        else E=0.0;
        X+=y[i] - fabs(M0*(1.0-F*E));
        X2+=pow(y[i] - fabs(M0*(1.0-F*E)),2);
    }

    var=Y2/N-Y/N*Y/N;
    resvar=X2/N-X/N*X/N;

    if (var>=resvar) return 1.0-resvar/var;

    return 0.0;
}


//================================================================================
//          Plot the fitted and the original data
//================================================================================
int PlotFittedRecoveryCurve(HWND hwnd, double yfit[], double ydat[], double TIs[], int N_TIs)
{

    POINT p;
    HDC hDC;
    HPEN hPen,hOldPen;
    HBRUSH hbrsh=GetStockObject(GRAY_BRUSH);
    RECT r, r2;
    int Xsize, Ysize;
    int TI;
    int sort[MAX_TIs];
    double tscale, yscale;
    double MaxY;
    char txt[256];


    //the data have to be sorted such that the lowest TI is first
    QuickSort(TIs, sort, N_TIs);


    //create pen
    hDC=GetDC(hwnd);
    hPen=CreatePen(PS_SOLID, 1,RGB(255,0,0));
    hOldPen=SelectObject(hDC,hPen);


    //get plot scale
    GetClientRect(hwnd,&r);
    Xsize=0.5*(r.right-r.left);
    Ysize=0.5*(r.bottom-r.top);
    r2=r;


    MaxY=ydat[0];
    for (TI=1; TI<N_TIs; TI++)
    {
        if (ydat[TI]>MaxY) MaxY=ydat[TI];
    }
    if (MaxY<=0.0 || TIs[N_TIs-1]<=0.0) return 0;

    tscale=Xsize/TI[TIs-1];
    yscale=Ysize/MaxY;


    FillRect(hDC, &r2, hbrsh);

    //plot the fitted curve
    MoveToEx(hDC,TIs[sort[0]]*tscale, 100+(MaxY-yfit[sort[0]])*yscale, &p);
    for (TI=1; TI<N_TIs; TI++)
    {
        LineTo(hDC,TIs[sort[TI]]*tscale, 100+(MaxY-yfit[sort[TI]])*yscale);
    }

    //draw the data curve
    for (TI=0; TI<N_TIs; TI++)
    {
        Ellipse(hDC, TIs[sort[TI]]*tscale-2, 100+(MaxY-ydat[sort[TI]])*yscale+2, TIs[sort[TI]]*tscale+2, 100+(MaxY-ydat[sort[TI]])*yscale-2);
    }

    sprintf(txt,"Press escape to exit.");
    TextOut(hDC,100,100,txt,strlen(txt));



    SelectObject(hDC,hOldPen);
    DeleteObject(hPen);
    ReleaseDC(hwnd, hDC);

    return 1;
}

//==============================================================================
//                  Save the T1 image with unique filename
//==============================================================================
int SaveT1(struct Image *T1image, char directory[])
{

    FILE *fp;
    int id;
    char name[MAX_PATH];

    id=0;

    sprintf(name,"%s\\T1image_%d.img",directory,id);

    while(id<100 && (fp=fopen(name,"r")))
    {
        id++;
        sprintf(name,"./T1image_%d.img",id);
        fclose(fp);
    }
    if (id<100)
    {
        sprintf((*T1image).filename,"%s\\T1image_%d.img",directory,id);
        sprintf((*T1image).headername,"%s\\T1image_%d.hdr",directory,id);

        return Save(T1image);
    }
    else return 0;
}


















int CalibrateT1Image(double p[]);
int SaveCalibration(double p[]);
int LoadCalibration(double p[]);
//=============================================================================================
//                           Calibrate T1 values Dialog
//=============================================================================================
INT_PTR CALLBACK CalibrateT1(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    double p[6];            //THE PARAMETERS
    char txt[256];


    switch(msg)
    {




    case WM_CLOSE:
        EndDialog(hwnd,0);
        break;




    case WM_INITDIALOG:
        sprintf(txt,"%f",1.0);
        SendMessage(GetDlgItem(hwnd,ID_T1),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",0.0);
        SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_F),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_T1_F),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_T12),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetDlgItem(hwnd,ID_F2),WM_SETTEXT,0,(LPARAM)txt);
        break;




    case WM_COMMAND:
        switch (LOWORD(wParam))
        {

        case ID_SAVE_CALIBRATION:
            p[0]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T1),WM_GETTEXT,256,(LPARAM)txt);
            p[1]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_F),WM_GETTEXT,256,(LPARAM)txt);
            p[2]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T1_F),WM_GETTEXT,256,(LPARAM)txt);
            p[3]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T12),WM_GETTEXT,256,(LPARAM)txt);
            p[4]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_F2),WM_GETTEXT,256,(LPARAM)txt);
            p[5]=atof(txt);
            SaveCalibration(p);
            break;

        case ID_LOAD_CALIBRATION:
            if (LoadCalibration(p))
            {
                sprintf(txt,"%f",p[0]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
                sprintf(txt,"%f",p[1]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
                sprintf(txt,"%f",p[2]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
                sprintf(txt,"%f",p[3]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
                sprintf(txt,"%f",p[4]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
                sprintf(txt,"%f",p[5]);
                SendMessage(GetDlgItem(hwnd,ID_C),WM_SETTEXT,256,(LPARAM)txt);
            }
            break;

        case ID_CALIBRATE:
            if (gImage.volumes!=4)
            {
                MessageBox(NULL,"Please load a valid T1 image","",MB_OK|MB_ICONWARNING);
                break;
            }
            SendMessage(GetDlgItem(hwnd,ID_C),WM_GETTEXT,256,(LPARAM)txt);
            p[0]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T1),WM_GETTEXT,256,(LPARAM)txt);
            p[1]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_F),WM_GETTEXT,256,(LPARAM)txt);
            p[2]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T1_F),WM_GETTEXT,256,(LPARAM)txt);
            p[3]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_T12),WM_GETTEXT,256,(LPARAM)txt);
            p[4]=atof(txt);
            SendMessage(GetDlgItem(hwnd,ID_F2),WM_GETTEXT,256,(LPARAM)txt);
            p[5]=atof(txt);
            sprintf(txt,"%f %f %f %f %f %f",p[0],p[1],p[2],p[3],p[4],p[5]);
            MessageBox(NULL,txt,"",MB_OK);
            CalibrateT1Image(p);

            break;



        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;
    }
    return 0;
}





//=============================================================================================
//              Calibrate the T1
//=============================================================================================
int CalibrateT1Image(double p[])
{

    int X, Y, Z;
    int voxel,voxels;
    float T1, F;
    float min;

    X=gImage.X;
    Y=gImage.Y;
    Z=gImage.Z/gImage.volumes;
    voxels=X*Y*Z;

    for (voxel=0; voxel<voxels; voxel++)
    {
        T1=gImage.img[voxel];
        F=gImage.img[voxel+2*voxels];
        gImage.img[voxel]=p[0] + p[1]*T1 + p[2]*F + p[3]*T1*F + p[4]*T1*T1 + p[5]*F*F;
        if (gImage.img[voxel]<0.0) gImage.img[voxel]=0.0;
    }
    ImageMinMax(gImage.img, gImage.X, gImage.Y, gImage.Z, gImage.DataType, &min, &gImage.MaxIntensity);

    return 1;
}



//=============================================================================================
//                  Save calibration parameters
//=============================================================================================
int SaveCalibration(double p[])
{

    FILE *fp;
    int result=0;
    int i;
    OPENFILENAME fn;
    char name[MAX_PATH];

    name[0]='\0';
    memset(&fn,0,sizeof(OPENFILENAME));
    fn.lStructSize=sizeof(OPENFILENAME);
    fn.hwndOwner=NULL;
    fn.lpstrFilter="Text Files\0*.txt\0\0";
    fn.lpstrCustomFilter=NULL;
    fn.nFilterIndex=1;
    fn.lpstrFile=name;
    fn.nMaxFile=MAX_PATH;//this needs to be long enough to contain the directory and filenames
    fn.lpstrInitialDir="./";
    fn.lpstrTitle="Select Calibration file";
    fn.lpstrDefExt="txt";

    if (GetSaveFileName(&fn))
    {
        if ( (fp=fopen(name,"w")) )
        {
            for (i=0; i<6; i++)
            {
                fprintf(fp,"%f\n",p[i]);
            }
            result=1;
            fclose(fp);
        }
    }


    return result;
}

//=============================================================================================
//                  Load calibration parameters
//=============================================================================================
int LoadCalibration(double p[])
{

    FILE *fp;
    int result=0;
    int i;
    OPENFILENAME fn;
    char name[MAX_PATH];
    char txt[256];

    name[0]='\0';
    memset(&fn,0,sizeof(OPENFILENAME));
    fn.lStructSize=sizeof(OPENFILENAME);
    fn.hwndOwner=NULL;
    fn.lpstrFilter="Text Files\0*.txt\0\0";
    fn.lpstrCustomFilter=NULL;
    fn.nFilterIndex=1;
    fn.lpstrFile=name;
    fn.nMaxFile=MAX_PATH;//this needs to be long enough to contain the directory and filenames
    fn.lpstrInitialDir=NULL;
    fn.lpstrTitle="Select Calibration file";
    fn.lpstrDefExt="txt";

    if (GetOpenFileName(&fn))
    {
        if ( (fp=fopen(name,"r")) )
        {
            for (i=0; i<6; i++)
            {
                if (!feof(fp))
                {
                    fscanf(fp,"%s",txt);
                    p[i]=atof(txt);
                }
            }
            result=1;
            fclose(fp);
        }
    }


    return result;
}














//===========================================================================================
/*
FITTING JUST TWO PARAMETERS LEAVES NOTCHES IN THE HISTOGRAM
EVEN WITH NO NOISE
T1 IS ALSO NOT CORRECTLY COMPUTED
3 PARAMETERS IS REQUIRED
*/


/*

struct T1dat
{
    double *y;
    double *TI;
    int N;
    int null;
    double sigma2;
};*/
/*
double T1GoodnessOfFit3param(double T1, double f, double y[], double TI[], int N);
#define SAMPLES 5
int T1experiment(HWND hwnd)
{
    double M[SAMPLES];
    double T[SAMPLES]= {150.0, 550.0, 900.0, 1300.0, 1700.0};
    double T1, M0, F;
    double t1,t1bestA, f, t1bestB;
    double r,rbest;
    int TI;
    FILE *fp;


    if ((fp=fopen("c:\\temp\\t1.txt","w")))
    {
        F=1.5;
        M0=1.0;
        for (T1=200.0; T1<1500.0; T1+=10.0)
        {
            //get the signal
            for (TI=0; TI<SAMPLES; TI++) M[TI]=fabs(M0*(1.0-F*exp(-T[TI]/T1)) + GaussRandomNumber_BoxMuller(0.0, M0/10.0));

            rbest=100000000.0;
            for (t1=50.0; t1<2000.0; t1+=1.0)
            {
                r=T1GoodnessOfFit3param(t1, 2.0, M, T, SAMPLES);
                if (r<rbest)
                {
                    rbest=r;
                    t1bestA=t1;
                }
            }

            rbest=100000000.0;
            for (f=1.0; f<=2.0; f+=0.01)
            {
                for (t1=50.0; t1<2000.0; t1+=1.0)
                {
                    r=T1GoodnessOfFit3param(t1, f, M, T, SAMPLES);
                    if (r<rbest)
                    {
                        rbest=r;
                        t1bestB=t1;
                    }
                }

            }



            fprintf(fp,"%f %f %f\n",T1,t1bestA, t1bestB);
        }
        fclose(fp);
    }

    return 1;
}
//===========================================================================================
double T1GoodnessOfFit3param(double T1, double f, double y[], double TI[], int N)
{

    int ti;
    double r;
    double Fit[MAX_TIs];
    double M0;

    //if the parameters are out of range, return 0.0
    if ((T1<=0.0) || (T1>=MAXT1))
    {
        r=0.0;
        for (ti=0; ti<N; ti++) r+=pow(y[ti],2);
        return r;
    }

    for (ti=0; ti<N; ti++) Fit[ti]=fabs(1.0-f*exp(-TI[ti]/(T1)));

    r=0.0;
    M0=M0EstimateEx(y, Fit, TI, N, T1, f);
    for (ti=0; ti<N; ti++)
    {
        r+=pow(y[ti] - M0*Fit[ti],2);
    }

    return r;
}
*/
