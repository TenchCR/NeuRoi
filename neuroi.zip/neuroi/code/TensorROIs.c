/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "tensorROIs.h"
#include "tensor.h"
#include "imageprocess.h"
#include "numerical.h"
#include "options.h"
#include "global.h"
#include "graphtheoryalgorithms.h"

#define SCROLL_MAX 100
#define SCROLL_MIN 1

#define NEIGHBOURS 49

struct TwoTrajectories{
       struct Trajectory T1;
       struct Trajectory T2;
};


double GetDistance(int i1, int i2, struct TwoTrajectories *Tr);
double GetClosestPoint(struct TwoTrajectories *Tr2, int *i1, int *i2);
double CorrelateTrajectories(struct TwoTrajectories *Tr2, int i1, int i2);
int DrawMaxIntensityProjection(HWND hwnd, struct ImagePlanes *fa, struct ImagePlanes *current, struct ImagePlanes *accepted,
                                    int x, int y, int z, float thresh);
int GetTrajectoryOverlapLimits(int *a, int *b, struct TwoTrajectories *Tr2, int i1, int i2);
int GetConnectedObject(struct Trajectory *T, struct Tractography *tract,
                        unsigned char object[], int X, int Y, int Z, int x0, int y0, int z0, double MinCorrelation);
int GetConnectedObjectFODF(struct Trajectory *T, struct Tractography *tract,
                        unsigned char object[], int X, int Y, int Z, int x0, int y0, int z0, double MinCorrelation);
int TensorObjectProjection(unsigned char *object, int X, int Y, int Z, struct ImagePlanes *planes);
int ReverseTrajectory(struct Trajectory *T, struct Trajectory *RevT);
struct ThreeVector MaxFODFdirection(struct ThreeVector directions[], float *fodf, int X, int Y, int Zpv, int volumes,
                                    int voxel, int idirections);

struct Image Tensor;                    //store the original tensor here
struct Image fODFbackup;                 //store the original fODF here
struct Image FAimg;                     //store the FA image here
struct Image trace;                     //store the TRACE image here
struct Image RGBevect;                  //Store the RGB principal evect image here
struct Image Affinities;                //3 volumes of affinity
struct Trajectory gCurrentTrajectory;   //the seed trajectory
struct ImagePlanes FAplanes;            //Max intensity projection of FA
struct ImagePlanes R2planes;            //Max intensity projection of correlation coefficient squared
struct ImagePlanes accepted;            //Max intensity projection of accepted region
unsigned char *R2;                               //the correlation coeficient squared*100
unsigned char *R2accepted;                       //the correlation coeficient squared*100
//=============================================================================================
//                           Tensor based ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK TensorROIsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    struct Hist hist;
    struct DescriptiveStats DS;
    static float FAthresh=0.15;
    static float ANGLEthresh=20.0;
    static float R2thresh=0.95;
    static struct Tractography tract;
    static short int xseed, yseed, zseed;
    struct Image Binary;
    int pos;
    int voxel;
    char txt[256];
    static HCURSOR hourglass;
    HCURSOR	PrevCursor;

    switch(msg) {




	case WM_CLOSE:
        MakeCopyOfImage(&Tensor, &gImage);
        ReleaseImage(&Tensor);
        ReleaseImage(&FAimg);
        ReleaseImage(&RGBevect);
        if (FAplanes.plane1){ free(FAplanes.plane1); FAplanes.plane1=NULL;}
        if (FAplanes.plane2){ free(FAplanes.plane2); FAplanes.plane2=NULL;}
        if (FAplanes.plane3){ free(FAplanes.plane3); FAplanes.plane3=NULL;}
        if (R2planes.plane1){ free(R2planes.plane1); R2planes.plane1=NULL;}
        if (R2planes.plane2){ free(R2planes.plane2); R2planes.plane2=NULL;}
        if (R2planes.plane3){ free(R2planes.plane3); R2planes.plane3=NULL;}
        if (R2) free(R2);
        if (R2accepted) free(R2accepted);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hTensorROI=(HWND)NULL;
        SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
        EndDialog(hwnd,0);
	break;





    case WM_SHOWWINDOW:
        SendMessage(GetDlgItem(hwnd,ID_SHOW_RGB_EVECT),BM_SETCHECK,BST_CHECKED,0);
    break;





    case WM_INITDIALOG:
        hourglass=LoadCursor(NULL,IDC_WAIT);
        if (!MakeCopyOfImage(&gImage, &Tensor)) SendMessage(hwnd, WM_CLOSE,0,0);
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        if (gImage.volumes!=6){
            MessageBox(NULL,"Volumes must be 6 for a tensor image", "", MB_OK|MB_ICONWARNING);
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;
        }
        SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETPOS,SCROLL_MAX*FAthresh,TRUE);
		sprintf(txt,"%f",FAthresh);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);

		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD),SBM_SETPOS,SCROLL_MAX*ANGLEthresh/90.0,TRUE);
		sprintf(txt,"%f",ANGLEthresh);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);

		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD),SBM_SETPOS,SCROLL_MAX*R2thresh,TRUE);
		sprintf(txt,"%f",R2thresh);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);


        if (!MakeCopyOfImage(&gImage, &FAimg)){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        if (!MakeCopyOfImage(&gImage, &trace)){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        if (!MakeCopyOfImage(&gImage, &RGBevect)){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        ConvertTensorToScalar(&FAimg, FA);
        ConvertTensorToScalar(&trace, TRACE);
        //get the max intensity projecttion of the FA
        MaxIntensityProjection(FAimg.img, FAimg.X, FAimg.Y, FAimg.Z, &FAplanes);
        ConvertTensorToPrincipalEvector(&RGBevect);
        //show RGB figure initially
        if (!MakeCopyOfImage(&RGBevect, &gImage)){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,0);
        //Initialize the tractography structure
        tract.tnsr=Tensor.img;
        tract.fa=FAimg.img;
        tract.X=Tensor.X;
        tract.Y=Tensor.Y;
        tract.Zpv=Tensor.Z/6;
        tract.dx=Tensor.dx;
        tract.dy=Tensor.dy;
        tract.dz=Tensor.dz;
        tract.scale=Tensor.scale;
        tract.offset=Tensor.offset;
        tract.MinFA=FAthresh;
        tract.Mindp=cos(ANGLEthresh*PI/180.0);
        tract.n=gOptions.TensorDeflect_n;
        //allocate memory for the correlation coefficient squared
        if (!(R2=(unsigned char *)malloc(tract.X*tract.Y*tract.Zpv))){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        if (!(R2accepted=(unsigned char *)malloc(tract.X*tract.Y*tract.Zpv))){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        memset(R2,0,tract.X*tract.Y*tract.Zpv);
        TensorObjectProjection(R2, FAimg.X, FAimg.Y, FAimg.Z, &R2planes);
        memset(R2accepted,0,tract.X*tract.Y*tract.Zpv);
        TensorObjectProjection(R2accepted, FAimg.X, FAimg.Y, FAimg.Z, &accepted);
    break;



    case WM_HSCROLL:

		pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		switch (LOWORD(wParam)){
			case SB_LINELEFT:
                pos--;
				break;
			case SB_LINERIGHT:
                pos++;
				break;
			case SB_PAGELEFT:
                pos-=SCROLL_MAX/10;
				break;
			case SB_PAGERIGHT:
                pos+=SCROLL_MAX/10;
				break;
			case SB_THUMBTRACK:
                pos=HIWORD(wParam);
				break;
		}
        SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)pos, TRUE);

        FAthresh    = (float)SendMessage( GetDlgItem(hwnd,ID_FA_THRESHOLD), SBM_GETPOS, 0, 0)/SCROLL_MAX;
		ANGLEthresh = (float)SendMessage( GetDlgItem(hwnd,ID_ANGLE_THRESHOLD), SBM_GETPOS, 0, 0)*90/SCROLL_MAX;
        R2thresh    = (float)SendMessage( GetDlgItem(hwnd,ID_R2_THRESHOLD), SBM_GETPOS, 0, 0)/SCROLL_MAX;

		sprintf(txt,"%f",FAthresh);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		sprintf(txt,"%f",ANGLEthresh);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		sprintf(txt,"%f",R2thresh);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		tract.MinFA=FAthresh;
		tract.Mindp=cos(ANGLEthresh*PI/180.0);
        SetFocus(GetParent(hwnd));
    break;




    case WM_LBUTTONDOWN:                                                        //mouse input
        PictureToImage(&gMainPict, (int)LOWORD(lParam)-gMainPict.xpos, (int)HIWORD(lParam)-gMainPict.ypos, &xseed, &yseed, &zseed,
                    IsMenuItemChecked(GetParent(hwnd), IDM_VIEW_PLANES));
        memset(&gCurrentTrajectory.xyz,0,sizeof(float)*3*MAX_TRAJECTORY_LENGTH);
        gCurrentTrajectory.length=0;
        GetTrajectory(&gCurrentTrajectory, &tract, gImage.dx*xseed, gImage.dy*yseed, gImage.dz*zseed, DTI_TRACTOGRAPHY);
        DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
    break;



    case WM_COMMAND:
	  switch (LOWORD(wParam)) {


        case ID_SHOW_RGB_EVECT:
            MakeCopyOfImage(&RGBevect, &gImage);
            SetFocus(GetParent(hwnd));
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,0);
        break;
        case ID_SHOW_FA:
            MakeCopyOfImage(&FAimg, &gImage);
            SetFocus(GetParent(hwnd));
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,0);
        break;


        case ID_FIND_REGION:
            PrevCursor=SetCursor(hourglass);
            memset(R2, 0, FAimg.X*FAimg.Y*FAimg.Z);
            GetConnectedObject(&gCurrentTrajectory, &tract, R2, FAimg.X, FAimg.Y, FAimg.Z, xseed, yseed, zseed, sqrt(R2thresh));
            TensorObjectProjection(R2, FAimg.X, FAimg.Y, FAimg.Z, &R2planes);
            DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
            SetCursor(PrevCursor);
        break;


        case ID_ACCEPT_REGION:
            for (voxel=0;voxel<FAimg.X*FAimg.Y*FAimg.Z;voxel++){
                if (R2[voxel]>R2accepted[voxel]) R2accepted[voxel]=R2[voxel];
            }
            TensorObjectProjection(R2accepted, FAimg.X, FAimg.Y, FAimg.Z, &accepted);
            DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
            //---------------------------get the statistics for the FA-------------------------------------------
            GetStandardizedHistogram(FAimg.img, R2accepted, gImage.X, gImage.Y, gImage.Z/gImage.volumes, 1.0, 0.0,
                                        DT_FLOAT, &hist, 0.01);
            //get the statistics
            DS=GetDescriptiveStatsFromHistogram(&hist);
            sprintf(txt,"%f",DS.median);
            SendMessage(GetDlgItem(hwnd,ID_MEDIAN_FA),WM_SETTEXT,0,(LPARAM)txt);
            //---------------------------get the statistics for the TRACE-------------------------------------------
            GetStandardizedHistogram(trace.img, R2accepted, gImage.X, gImage.Y, gImage.Z/gImage.volumes, 1.0, 0.0,
                                        DT_FLOAT, &hist, 0.01);
            //get the statistics
            DS=GetDescriptiveStatsFromHistogram(&hist);
            sprintf(txt,"%f",DS.median);
            SendMessage(GetDlgItem(hwnd,ID_MEDIAN_TRACE),WM_SETTEXT,0,(LPARAM)txt);
        break;


        case ID_CLEAR_REGION:
            memset(R2accepted,0,tract.X*tract.Y*tract.Zpv);
            TensorObjectProjection(R2accepted, FAimg.X, FAimg.Y, FAimg.Z, &accepted);
        break;


        case ID_SAVE_OBJECT:
            memset(&Binary,0,sizeof(struct Image));
            if (MakeImage(&Binary, tract.X, tract.Y, tract.Zpv, 1, tract.dx, tract.dy, tract.dz,
                     tract.X*tract.dx/2, tract.Y*tract.dy/2, tract.Zpv*tract.dz/2, 1.0, 0.0, DT_UNSIGNED_CHAR,
                     HDR, "Binary tract image")){
                for (voxel=0;voxel<tract.X*tract.Y*tract.Zpv;voxel++){
                    if (R2accepted[voxel]) Binary.img[voxel]=R2accepted[voxel];
                }
                SaveAs(&Binary);
                ReleaseImage(&Binary);
            }
        break;

		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}

//=============================================================================================
//                           fODF tractography based ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK FodfROIsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    struct Hist hist;
    struct DescriptiveStats DS;
    static float FAthresh=0.15;
    static float ANGLEthresh=20.0;
    static float R2thresh=0.95;
    static struct Tractography tract;
    static struct ThreeVector Directions[NEIGHBOURS];
    static short int xseed, yseed, zseed;
    struct Image Binary;
    static struct Image FracAn;
    int pos;
    int voxel;
    char txt[256];
    static HCURSOR hourglass;
    HCURSOR	PrevCursor;

    switch(msg) {




	case WM_CLOSE:
        MakeCopyOfImage(&fODFbackup, &gImage);
        ReleaseImage(&fODFbackup);
        if (FAplanes.plane1){ free(FAplanes.plane1); FAplanes.plane1=NULL;}
        if (FAplanes.plane2){ free(FAplanes.plane2); FAplanes.plane2=NULL;}
        if (FAplanes.plane3){ free(FAplanes.plane3); FAplanes.plane3=NULL;}
        if (R2planes.plane1){ free(R2planes.plane1); R2planes.plane1=NULL;}
        if (R2planes.plane2){ free(R2planes.plane2); R2planes.plane2=NULL;}
        if (R2planes.plane3){ free(R2planes.plane3); R2planes.plane3=NULL;}
        if (R2) free(R2);
        if (R2accepted) free(R2accepted);
        if (FracAn.X) ReleaseImage(&FracAn);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hTensorROI=(HWND)NULL;
        SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
        EndDialog(hwnd,0);
	break;





    case WM_SHOWWINDOW:
        SendMessage(GetDlgItem(hwnd,ID_SHOW_FA),BM_SETCHECK,BST_CHECKED,0);
    break;





    case WM_INITDIALOG:
        memset(&FracAn,0,sizeof(struct Image));
        LoadAnalyzeOrNiftiEx(GetParent(hwnd), &FracAn, "Load FA image", 0);
        //get the max intensity projecttion of the FA
        MaxIntensityProjection(FracAn.img, FracAn.X, FracAn.Y, FracAn.Z/FracAn.volumes, &FAplanes);

        tract.idirections=GetNNeighourDirections(Directions, gImage.dx, gImage.dy, gImage.dz,NEIGHBOURS);
        hourglass=LoadCursor(NULL,IDC_WAIT);
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        if (gImage.volumes<NEIGHBOURS){
            MessageBox(NULL,"Volumes must be 49 for an fODF image", "", MB_OK|MB_ICONWARNING);
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;
        }
        SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD),SBM_SETPOS,SCROLL_MAX*FAthresh,TRUE);
		sprintf(txt,"%f",FAthresh);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);

		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD),SBM_SETPOS,SCROLL_MAX*ANGLEthresh/90.0,TRUE);
		sprintf(txt,"%f",ANGLEthresh);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);

		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD),SBM_SETPOS,SCROLL_MAX*R2thresh,TRUE);
		sprintf(txt,"%f",R2thresh);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);

//backup the original fODF image
        if (!MakeCopyOfImage(&gImage, &fODFbackup)){ SendMessage(hwnd, WM_CLOSE,0,0); break;}

//Release the global image (gImage) and make it the FA
        ReleaseImage(&gImage);
        LoadAnalyzeOrNiftiEx(GetParent(hwnd), &gImage, "Load PVECT image", 0);

		SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,0);




//Initialize the tractography structure
        tract.directions=Directions;
        tract.fa=FracAn.img;
        tract.fODF=&fODFbackup.img[fODFbackup.X * fODFbackup.Y * fODFbackup.Z/fODFbackup.volumes];
        tract.X=fODFbackup.X;
        tract.Y=fODFbackup.Y;
        tract.Zpv=fODFbackup.Z/fODFbackup.volumes;
        tract.volumes=fODFbackup.volumes-1;
        tract.dx=fODFbackup.dx;
        tract.dy=fODFbackup.dy;
        tract.dz=fODFbackup.dz;
        tract.MinFA=FAthresh;
        tract.Mindp=cos(ANGLEthresh*PI/180.0);
        tract.n=3;
//allocate memory for the correlation coefficient squared
        if (!(R2=(unsigned char *)malloc(tract.X*tract.Y*tract.Zpv))){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        if (!(R2accepted=(unsigned char *)malloc(tract.X*tract.Y*tract.Zpv))){ SendMessage(hwnd, WM_CLOSE,0,0); break;}
        memset(R2,0,tract.X*tract.Y*tract.Zpv);
        TensorObjectProjection(R2, tract.X, tract.Y, tract.Zpv, &R2planes);
        memset(R2accepted,0,tract.X*tract.Y*tract.Zpv);
        TensorObjectProjection(R2accepted, tract.X, tract.Y, tract.Zpv, &accepted);
    break;



    case WM_HSCROLL:

		pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		switch (LOWORD(wParam)){
			case SB_LINELEFT:
                pos--;
				break;
			case SB_LINERIGHT:
                pos++;
				break;
			case SB_PAGELEFT:
                pos-=SCROLL_MAX/10;
				break;
			case SB_PAGERIGHT:
                pos+=SCROLL_MAX/10;
				break;
			case SB_THUMBTRACK:
                pos=HIWORD(wParam);
				break;
		}
        SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)pos, TRUE);

        FAthresh    = (float)SendMessage( GetDlgItem(hwnd,ID_FA_THRESHOLD), SBM_GETPOS, 0, 0)/SCROLL_MAX;
		ANGLEthresh = (float)SendMessage( GetDlgItem(hwnd,ID_ANGLE_THRESHOLD), SBM_GETPOS, 0, 0)*90/SCROLL_MAX;
        R2thresh    = (float)SendMessage( GetDlgItem(hwnd,ID_R2_THRESHOLD), SBM_GETPOS, 0, 0)/SCROLL_MAX;

		sprintf(txt,"%f",FAthresh);
		SendMessage(GetDlgItem(hwnd,ID_FA_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		sprintf(txt,"%f",ANGLEthresh);
		SendMessage(GetDlgItem(hwnd,ID_ANGLE_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		sprintf(txt,"%f",R2thresh);
		SendMessage(GetDlgItem(hwnd,ID_R2_THRESHOLD_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		tract.MinFA=FAthresh;
		tract.Mindp=cos(ANGLEthresh*PI/180.0);
        SetFocus(GetParent(hwnd));
    break;




    case WM_LBUTTONDOWN:                                                        //mouse input
        PictureToImage(&gMainPict, (int)LOWORD(lParam)-gMainPict.xpos, (int)HIWORD(lParam)-gMainPict.ypos, &xseed, &yseed, &zseed,
                    IsMenuItemChecked(GetParent(hwnd), IDM_VIEW_PLANES));
        memset(&gCurrentTrajectory.xyz,0,sizeof(float)*3*MAX_TRAJECTORY_LENGTH);
        gCurrentTrajectory.length=0;
        voxel=xseed+yseed*tract.X+zseed*tract.X*tract.Y;
        tract.InitDir=MaxFODFdirection(Directions, tract.fODF, tract.X, tract.Y, tract.Zpv, tract.volumes,
                                        voxel,NEIGHBOURS);
        GetTrajectory(&gCurrentTrajectory, &tract, gImage.dx*xseed, gImage.dy*yseed, gImage.dz*zseed, FODF_TRACTOGRAPHY);
        DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
    break;



    case WM_COMMAND:
	  switch (LOWORD(wParam)) {

        case ID_FIND_REGION:
            PrevCursor=SetCursor(hourglass);
            memset(R2, 0, tract.X*tract.Y*tract.Zpv);
            GetConnectedObjectFODF(&gCurrentTrajectory, &tract, R2, tract.X, tract.Y, tract.Zpv, xseed, yseed, zseed, sqrt(R2thresh));
            TensorObjectProjection(R2, tract.X, tract.Y, tract.Zpv, &R2planes);
            DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
            SetCursor(PrevCursor);
        break;


        case ID_ACCEPT_REGION:
            for (voxel=0;voxel<tract.X*tract.Y*tract.Zpv;voxel++){
                if (R2[voxel]>R2accepted[voxel]) R2accepted[voxel]=R2[voxel];
            }
            TensorObjectProjection(R2accepted, tract.X, tract.Y, tract.Zpv, &accepted);
            DrawMaxIntensityProjection(hwnd, &FAplanes, &R2planes, &accepted, gMainPict.x, gMainPict.y, gMainPict.slice,FAthresh);
            //---------------------------get the statistics for the FA-------------------------------------------
            GetStandardizedHistogram(gImage.img, R2accepted, gImage.X, gImage.Y, gImage.Z, 1.0, 0.0,
                                        DT_FLOAT, &hist, 0.01);
            //get the statistics
            DS=GetDescriptiveStatsFromHistogram(&hist);
            sprintf(txt,"%f",DS.median);
            SendMessage(GetDlgItem(hwnd,ID_MEDIAN_FA),WM_SETTEXT,0,(LPARAM)txt);

        break;


        case ID_CLEAR_REGION:
            memset(R2accepted,0,tract.X*tract.Y*tract.Zpv);
            TensorObjectProjection(R2accepted, tract.X, tract.Y, tract.Zpv, &accepted);
        break;


        case ID_SAVE_OBJECT:
            memset(&Binary,0,sizeof(struct Image));
            if (MakeImage(&Binary, tract.X, tract.Y, tract.Zpv, 1, tract.dx, tract.dy, tract.dz,
                     tract.X*tract.dx/2, tract.Y*tract.dy/2, tract.Zpv*tract.dz/2, 1.0, 0.0, DT_UNSIGNED_CHAR,
                     HDR, "Binary tract image")){
                for (voxel=0;voxel<tract.X*tract.Y*tract.Zpv;voxel++){
                    if (R2accepted[voxel]) Binary.img[voxel]=R2accepted[voxel];
                }
                SaveAs(&Binary);
                ReleaseImage(&Binary);
            }
        break;

		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}











//=============================================================================================
//                         -Draw the trajectory
//                         -Uses the global gCurrentTrajectory; the seed trajectory
//=============================================================================================
int DrawTrajectory(HDC hDC, struct Picture *pict, struct Image *image, int threeplane){

    int x0,y0;
    int x1,y1;
    int height=(*pict).height;
    int width=(*pict).ML.x1-(*pict).ML.x0+1;
    int xim,yim,zim;
    int i;
    COLORREF col=RGB(200,200,200);


    //if viewing the FA image, then make the trajectory RED
    if (hTensorROI && SendMessage(GetDlgItem(hTensorROI,ID_SHOW_RGB_EVECT),BM_GETCHECK,0,0)==BST_UNCHECKED){
        col=RGB(255,0,0);
    }


    for (i=1;i<gCurrentTrajectory.length-1;i++){

        //----------------focal image plane----------
        xim=gCurrentTrajectory.xyz[i*3]/(*image).dx;
        yim=gCurrentTrajectory.xyz[i*3+1]/(*image).dy;

        x0=(xim-(*pict).ML.x0);
        y0=(height-1)-(yim-(*pict).ML.y0);


        xim=gCurrentTrajectory.xyz[(i+1)*3]/(*image).dx;
        yim=gCurrentTrajectory.xyz[(i+1)*3+1]/(*image).dy;

        x1=(xim-(*pict).ML.x0);
        y1=(height-1)-(yim-(*pict).ML.y0);


        DrawLine(hDC, x0, y0, x1, y1, col, 1);
        //-------------------------------------------

        //---------Other image planes----------------
        if (threeplane){
            xim=gCurrentTrajectory.xyz[i*3]/(*image).dx;
            //yim=gCurrentTrajectory.xyz[i*3+1]/(*image).dy;
            zim=gCurrentTrajectory.xyz[i*3+2]/(*image).dz;

            x0=(xim-(*pict).ML.x0)+width;
            y0=height-zim;


            xim=gCurrentTrajectory.xyz[(i+1)*3]/(*image).dx;
            //yim=gCurrentTrajectory.xyz[i*3+1]/(*image).dy;
            zim=gCurrentTrajectory.xyz[(i+1)*3+2]/(*image).dz;

            x1=(xim-(*pict).ML.x0)+width;
            y1=height-zim;

            DrawLine(hDC, x0, y0, x1, y1, col, 1);


            //xim=gCurrentTrajectory.xyz[i*3]/(*image).dx;
            yim=gCurrentTrajectory.xyz[i*3+1]/(*image).dy;
            zim=gCurrentTrajectory.xyz[i*3+2]/(*image).dz;

            x0=(yim-(*pict).ML.y0)+2*width;
            y0=height-zim;


            //xim=gCurrentTrajectory.xyz[(i+1)*3]/(*image).dx;
            yim=gCurrentTrajectory.xyz[(i+1)*3+1]/(*image).dy;
            zim=gCurrentTrajectory.xyz[(i+1)*3+2]/(*image).dz;

            x1=(yim-(*pict).ML.y0)+2*width;
            y1=height-zim;

            DrawLine(hDC, x0, y0, x1, y1, col, 1);


        }

    }


    return 1;
}











//=============================================================================================
//                      -Draw the maximum intensity projection
//                      -x,y,z is the current seedpoint
//                      -*FA is the max intensity projection of FA
//                      -current is the projected object you just created
//                      -accepted is the accepted object projected
//=============================================================================================
#define GRAY_MAX 85
#define PICT_SIZE 250
int DrawMaxIntensityProjection(HWND hwnd, struct ImagePlanes *fa, struct ImagePlanes *current, struct ImagePlanes *accepted,
                                    int x, int y, int z, float thresh){
	struct BITMAPINFO256 bmpinf;
	int X,Y,Z;
	int width,height;
	int icol;
	int i,j;
    unsigned char *pict;
    float scale, f;
	HDC hMemDC, hDC=GetDC(hwnd);
    HBITMAP hbmp,hOldbmp;


    if ((*fa).max<=0.0) return 0;

    X=(*fa).X;Y=(*fa).Y;Z=(*fa).Z;

    hMemDC=CreateCompatibleDC(hDC);

	memset(&bmpinf,0,sizeof(struct BITMAPINFO256));      //null the structure to start with

	bmpinf.bmiHdr.biSize=sizeof(BITMAPINFOHEADER);
	bmpinf.bmiHdr.biPlanes=1;
	bmpinf.bmiHdr.biBitCount=8;
	bmpinf.bmiHdr.biCompression=BI_RGB;
	bmpinf.bmiHdr.biClrUsed=256;


	//--------arrange the grayscale part of the colour map---------
	for (icol=0;icol<GRAY_MAX;icol++){
        bmpinf.bmicolours[icol].rgbRed=icol*255/GRAY_MAX;
		bmpinf.bmicolours[icol].rgbGreen=icol*255/GRAY_MAX;
		bmpinf.bmicolours[icol].rgbBlue=icol*255/GRAY_MAX;
    }

	//--------arrange the colour (RED and BLUE) part of the colour map---------
	for (icol=0;icol<GRAY_MAX;icol++){
        //bmpinf.bmicolours[icol+GRAY_MAX].rgbRed=255*icol/GRAY_MAX+GRAY_MAX;
		//bmpinf.bmicolours[icol+2*GRAY_MAX].rgbBlue=255*icol/GRAY_MAX+2*GRAY_MAX;
		bmpinf.bmicolours[icol+GRAY_MAX].rgbRed=((icol+GRAY_MAX)>255) ? 255:(icol+GRAY_MAX);
		bmpinf.bmicolours[icol+2*GRAY_MAX].rgbBlue=((icol+2*GRAY_MAX)>255) ? 255:(icol+2*GRAY_MAX);
    }


    //-------draw the first of the projections--------
    width=X+(4-X%4);
    height=Y;
    scale=(width>height) ? (float)PICT_SIZE/width:(float)PICT_SIZE/height;
    bmpinf.bmiHdr.biWidth=width;
	bmpinf.bmiHdr.biHeight=height;
	bmpinf.bmiHdr.biSizeImage=width*height*sizeof(char);
	if ( (pict=(unsigned char *)malloc(width*height)) ){
       memset(pict, 0, width*height);
	   for (j=0;j<Y;j++){
           for (i=0;i<X;i++){
               if ( (f=(*fa).plane1[i+j*X])>thresh ){
                  pict[i+j*width]=(GRAY_MAX-1)*f/(*fa).max;
                  if (pict[i+j*width]>=GRAY_MAX) pict[i+j*width]=GRAY_MAX-1;
                  if ((*current).plane1[i+j*X]) pict[i+j*width]=GRAY_MAX+(GRAY_MAX*(*current).plane1[i+j*X])/Z;
                  if ((*accepted).plane1[i+j*X]) pict[i+j*width]=2*GRAY_MAX+(GRAY_MAX*(*accepted).plane1[i+j*X])/Z;
               }
               else pict[i+j*width]=0;
           }
       }
       hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&bmpinf.bmiHdr, CBM_INIT, pict,
                               (LPBITMAPINFO)&bmpinf, DIB_RGB_COLORS  );
       hOldbmp=SelectObject(hMemDC, hbmp);

       StretchBlt(hDC, 0, 250, (int)(scale*width), (int)(scale*height), hMemDC, 0,0, width, height, SRCCOPY);

       SelectObject(hMemDC, hOldbmp);
       DeleteObject(hbmp);
       free(pict);
       Ellipse(hDC, scale*(x-2),250+scale*((Y-y)-2),scale*(x+2),250+scale*((Y-y)+2));
    }


    //-------draw the second of the projections--------
    width=X+(4-X%4);
    height=Z;
    scale=(width>height) ? (float)PICT_SIZE/width:(float)PICT_SIZE/height;
    bmpinf.bmiHdr.biWidth=width;
	bmpinf.bmiHdr.biHeight=height;
	bmpinf.bmiHdr.biSizeImage=width*height*sizeof(char);
	if ( (pict=(unsigned char *)malloc(width*height)) ){
       memset(pict, 0, width*height);
	   for (j=0;j<Z;j++){
           for (i=0;i<X;i++){
               if ( (f=(*fa).plane2[i+j*X])>thresh ){
                  pict[i+j*width]=(GRAY_MAX-1)*f/(*fa).max;
                  if (pict[i+j*width]>=GRAY_MAX) pict[i+j*width]=GRAY_MAX-1;
                  if ((*current).plane2[i+j*X]) pict[i+j*width]=GRAY_MAX+(GRAY_MAX*(*current).plane2[i+j*X])/Y;
                  if ((*accepted).plane2[i+j*X]) pict[i+j*width]=2*GRAY_MAX+(GRAY_MAX*(*accepted).plane2[i+j*X])/Y;
               }
               else pict[i+j*width]=0;
           }
       }
       hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&bmpinf.bmiHdr, CBM_INIT, pict,
                               (LPBITMAPINFO)&bmpinf, DIB_RGB_COLORS  );
       hOldbmp=SelectObject(hMemDC, hbmp);

       StretchBlt(hDC, PICT_SIZE, 250, (int)(scale*width), (int)(scale*height), hMemDC, 0,0, width, height, SRCCOPY);

       SelectObject(hMemDC, hOldbmp);
       DeleteObject(hbmp);
       free(pict);
       Ellipse(hDC, PICT_SIZE+scale*(x-2),250+scale*((Z-z)-2),PICT_SIZE+scale*(x+2),250+scale*((Z-z)+2));
    }


    //-------draw the third of the projections--------
    width=Y+(4-Y%4);
    height=Z;
    scale=(width>height) ? (float)PICT_SIZE/width:(float)PICT_SIZE/height;
    bmpinf.bmiHdr.biWidth=width;
	bmpinf.bmiHdr.biHeight=height;
	bmpinf.bmiHdr.biSizeImage=width*height*sizeof(char);
	if ( (pict=(unsigned char *)malloc(width*height)) ){
       memset(pict, 0, width*height);
	   for (j=0;j<Z;j++){
           for (i=0;i<Y;i++){
               if ( (f=(*fa).plane3[i+j*Y])>thresh ){
                  pict[i+j*width]=(GRAY_MAX-1)*f/(*fa).max;
                  if (pict[i+j*width]>=GRAY_MAX) pict[i+j*width]=GRAY_MAX-1;
                  if ((*current).plane3[i+j*Y]) pict[i+j*width]=GRAY_MAX+(GRAY_MAX*(*current).plane3[i+j*Y])/X;
                  if ((*accepted).plane3[i+j*X]) pict[i+j*width]=2*GRAY_MAX+(GRAY_MAX*(*accepted).plane3[i+j*X])/X;
               }
               else pict[i+j*width]=0;
           }
       }
       hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&bmpinf.bmiHdr, CBM_INIT, pict,
                               (LPBITMAPINFO)&bmpinf, DIB_RGB_COLORS  );
       hOldbmp=SelectObject(hMemDC, hbmp);

       StretchBlt(hDC, 0, 250+PICT_SIZE, (int)(scale*width), (int)(scale*height), hMemDC, 0,0, width, height, SRCCOPY);

       SelectObject(hMemDC, hOldbmp);
       DeleteObject(hbmp);
       free(pict);
       Ellipse(hDC, scale*(y-2),PICT_SIZE+250+scale*((Z-z)-2),scale*(y+2),PICT_SIZE+250+scale*((Z-z)+2));
    }



    //cleanup
	DeleteDC(hMemDC);
	ReleaseDC(hwnd, hDC);
	return 1;
}















//=============================================================================================
//              -Get the distance between points on two different trajectories
//              -The points to be used are given by i1 (trajectory 1) and i2 (trajectory 2)
//=============================================================================================
double GetDistance(int i1, int i2, struct TwoTrajectories *Tr){

       float x1,y1,z1;
       float x2,y2,z2;


       //make sure these points are in range
       if (i1<0) i1=0;
       if (i1>=(*Tr).T1.length) i1=(*Tr).T1.length-1;
       if (i2<0) i2=0;
       if (i2>=(*Tr).T2.length) i2=(*Tr).T2.length-1;


       //find the points
       x1=(*Tr).T1.xyz[i1*3];
       y1=(*Tr).T1.xyz[i1*3+1];
       z1=(*Tr).T1.xyz[i1*3+2];

       x2=(*Tr).T2.xyz[i2*3];
       y2=(*Tr).T2.xyz[i2*3+1];
       z2=(*Tr).T2.xyz[i2*3+2];


       //return the distance
       return pow(x1-x2,2) + pow(y1-y2,2) + pow(z1-z2,2);
}









//=============================================================================================
//                  -Find the point where the two trajectories are closest
//                  -Tr2 contains the 2 trajectories and their detail
//                  -i1 and i2 will be the result, pointing to the part of
//                      the trajectories that pass closest
//                  -This function is not perfect, but is much more efficient
//                      than an exhaustive search
//=============================================================================================
double GetClosestPoint(struct TwoTrajectories *Tr2, int *i1, int *i2){

    double mindist,dist;
    int s1,f1,s2,f2;
    int i,j, ibest, jbest;
    int skip=32;

    s1=0;s2=0;
    f1=(*Tr2).T1.length;
    f2=(*Tr2).T2.length;

    mindist=10000.0;
    ibest=jbest=0;
    do{
        for (j=s2; j<f2; j+=skip){
            for (i=s1; i<f1; i+=skip){
                dist=GetDistance(i,j, Tr2);
                if (dist<mindist){
                    mindist=dist;
                    ibest=i;
                    jbest=j;
                }
            }
        }
        s1=( (ibest-2*skip)>0 ) ? (ibest-2*skip):0;
        s2=( (jbest-2*skip)>0 ) ? (jbest-2*skip):0;
        f1=( (ibest+2*skip)<(*Tr2).T1.length ) ? (ibest+2*skip):(*Tr2).T1.length-1;
        f2=( (jbest+2*skip)<(*Tr2).T2.length ) ? (jbest+2*skip):(*Tr2).T2.length-1;
        skip/=2;
    }
    while(skip);

    (*i1)=ibest;
    (*i2)=jbest;

    return mindist;
}







//=============================================================================================
//                  -Get the limits of the overlap between the 2 traajectories
//                  -i1 and i2 are the points along the trajectories that minimise
//                      the distance between the trajectories
//                  -a nd b are the limits so trajectory 1 runs from i1-a to i1+b
//                  -returns the overlap length
//=============================================================================================
int GetTrajectoryOverlapLimits(int *a, int *b, struct TwoTrajectories *Tr2, int i1, int i2){

    (*a)=(i1<i2) ? i1:i2;
    (*b)=(((*Tr2).T1.length-1-i1)<((*Tr2).T2.length-1-i2)) ? ((*Tr2).T1.length-1-i1):((*Tr2).T2.length-1-i2);

    return (*a)+(*b)+1;
}













//=============================================================================================
//                      -compute the correlation coefficient between trajectories
//                      -i1 and i2 are the points along the trajectories that minimise
//                          the distance between the trajectories
//=============================================================================================
double CorrelateTrajectories(struct TwoTrajectories *Tr2, int i1, int i2){

    int a,b;
    int i;
    struct ThreeVector sumX, sumY;
    float sumXY, sumX2, sumY2;
    float x1,y1,z1,x2,y2,z2;
    double A,B,R2;
    int N;


    N=GetTrajectoryOverlapLimits(&a, &b, Tr2, i1, i2);

    if (N<5) return 0.0;

    sumXY=sumX2=sumY2=0.0;
    memset(&sumX,0,sizeof(struct ThreeVector));
    memset(&sumY,0,sizeof(struct ThreeVector));
    for (i=-a;i<=b;i++){
        x1=(*Tr2).T1.xyz[(i+i1)*3];
        y1=(*Tr2).T1.xyz[(i+i1)*3+1];
        z1=(*Tr2).T1.xyz[(i+i1)*3+2];
        sumX.x+=x1;
        sumX.y+=y1;
        sumX.z+=z1;

        x2=(*Tr2).T2.xyz[(i+i2)*3];
        y2=(*Tr2).T2.xyz[(i+i2)*3+1];
        z2=(*Tr2).T2.xyz[(i+i2)*3+2];
        sumY.x+=x2;
        sumY.y+=y2;
        sumY.z+=z2;

        sumX2+=x1*x1 + y1*y1 + z1*z1;
        sumY2+=x2*x2 + y2*y2 + z2*z2;

        sumXY+=x1*x2 + y1*y2 + z1*z2;
    }

    A=sumXY-(sumX.x*sumY.x + sumX.y*sumY.y + sumX.z*sumY.z)/N;
    B=(sumX2-(sumX.x*sumX.x + sumX.y*sumX.y + sumX.z*sumX.z)/N)*
        (sumY2-(sumY.x*sumY.x + sumY.y*sumY.y + sumY.z*sumY.z)/N);


    if (B<=0.0) return 0.0;

    R2=A/sqrt(B);

    if (R2>1.0) R2=1.0;

    return R2;
}
















//==============================================================================
//Finds the object connected to {x0,y0,z0}
//can be fairly fast, but use lots of memory
//return value is the number of voxels in the found object
//==============================================================================
#define CONNECTED 6
#define MINLENGTH 10
int GetConnectedObject(struct Trajectory *T, struct Tractography *tract,
                        unsigned char object[], int X, int Y, int Z, int x0, int y0, int z0, double MinCorrelation){

    struct TwoTrajectories Tr2;
    struct Trajectory Trev;//the reverse trajectory to T; the seed trajectory
	struct KeepTrack *track=NULL;
	double correlation;
	int voxel, voxel_n, total_voxels=X*Y*Z;
	int found;
	int x[6]={-1,1,0,0,0,0};
	int y[6]={0,0,-1,1,0,0};
	int z[6]={0,0,0,0,-1,1};
	int size=0;
	int i1,i2;
	int inrange;
	int length;

	if (!InImageRange(x0,y0,z0,X,Y,Z) || ((*T).length<MINLENGTH)) return 0;

	if ( !(track=(struct KeepTrack *)malloc(X*Y*Z*sizeof(struct KeepTrack))) ) return 0;
	memset(track,0,X*Y*Z*sizeof(struct KeepTrack));

    //start with a blank object
    memset(object, 0, X*Y*Z);


    //save reverse seed trajectory
    ReverseTrajectory(T, &Trev);


	voxel=x0+y0*X+z0*X*Y;
	object[voxel]=100;//the seed voxel is certainly connected
	track[voxel].PrevVoxel=voxel;


    memcpy(&Tr2.T1, T, sizeof(struct Trajectory));//make trajectory 1 the seed trajectory
	do{

		do{

			voxel_n=voxel + x[track[voxel].index] + y[track[voxel].index]*X + z[track[voxel].index]*X*Y;
			XYZfromVoxelNumber(voxel_n, &x0, &y0, &z0, X, Y, Z);

            found=0;
			if ((inrange=InImageRange(x0,y0,z0,X,Y,Z)) && !object[voxel_n]
                && ((*tract).fa[voxel_n]>(*tract).MinFA)){

               memset(&Tr2.T2,0,sizeof(struct Trajectory));
	           length=GetTrajectory(&Tr2.T2, tract, x0*(*tract).dx, y0*(*tract).dy, z0*(*tract).dz, DTI_TRACTOGRAPHY);
               if (length>MINLENGTH){
                    GetClosestPoint(&Tr2, &i1, &i2);
                    correlation=CorrelateTrajectories(&Tr2, i1, i2);

                    if (correlation<MinCorrelation){
                        //reverse the seed trajectory and try the correlation again
                        memcpy(&Tr2.T1, &Trev, sizeof(struct Trajectory));
                        i1=(*T).length-1-i1;
                        correlation=CorrelateTrajectories(&Tr2, i1, i2);
                        memcpy(&Tr2.T1, T, sizeof(struct Trajectory));//back to the original seed trajectory
                    }
               }
               else correlation=0.0;

               if ((correlation>=MinCorrelation) && !track[voxel_n].index){
                    object[voxel_n]=(char)(pow(correlation,2)*100);
                    found=1;
               }
			}

			track[voxel].index++;

		}
		while((track[voxel].index<CONNECTED) && !found);


		if (found){
			track[voxel_n].PrevVoxel=voxel;
			voxel=voxel_n;
		}
		else voxel=track[voxel].PrevVoxel;
	}
	while(!(track[voxel].PrevVoxel==voxel && track[voxel].index>=CONNECTED));


    //count voxels in the object
	size=0;
	for (voxel=0;voxel<total_voxels;voxel++){
		if (!track[voxel].index) object[voxel]=0;
		else if (object[voxel]) size++;
	}

	free(track);

	return size;

}

//==============================================================================
//Finds the object connected to {x0,y0,z0}
//can be fairly fast, but use lots of memory
//return value is the number of voxels in the found object
//==============================================================================
#define CONNECTED 6
#define MINLENGTH 10
int GetConnectedObjectFODF(struct Trajectory *T, struct Tractography *tract,
                        unsigned char object[], int X, int Y, int Z, int x0, int y0, int z0, double MinCorrelation){

    struct TwoTrajectories Tr2;
    struct Trajectory Trev;//the reverse trajectory to T; the seed trajectory
	struct KeepTrack *track=NULL;
	struct ThreeVector *Vimage=NULL;//used to store the intial directions voxel by voxel
	double correlation;
    int voxel, voxel_n, total_voxels=X*Y*Z;
	int found;
	int x[6]={-1,1,0,0,0,0};
	int y[6]={0,0,-1,1,0,0};
	int z[6]={0,0,0,0,-1,1};
	int size=0;
	int i1,i2;
	int inrange;
	int length;

	if (!InImageRange(x0,y0,z0,X,Y,Z) || ((*T).length<MINLENGTH)) return 0;

	if ( !(track=(struct KeepTrack *)malloc(X*Y*Z*sizeof(struct KeepTrack))) ) goto END;
	memset(track,0,X*Y*Z*sizeof(struct KeepTrack));

	if ( !(Vimage=(struct ThreeVector *)malloc(X*Y*Z*sizeof(struct ThreeVector))) ) goto END;
	memset(Vimage,0,X*Y*Z*sizeof(struct ThreeVector));


    //start with a blank object
    memset(object, 0, X*Y*Z);


    //save reverse seed trajectory
    ReverseTrajectory(T, &Trev);


	voxel=x0+y0*X+z0*X*Y;
	object[voxel]=100;//the seed voxel is certainly connected
	track[voxel].PrevVoxel=voxel;

    //find the maximum direction in the fODF, and use as the initial direction
	Vimage[voxel]=MaxFODFdirection((*tract).directions, (*tract).fODF, X, Y, Z, (*tract).volumes, voxel,
                                        (*tract).idirections);


    memcpy(&Tr2.T1, T, sizeof(struct Trajectory));//make trajectory 1 the seed trajectory
	do{

		do{

			voxel_n=voxel + x[track[voxel].index] + y[track[voxel].index]*X + z[track[voxel].index]*X*Y;
			XYZfromVoxelNumber(voxel_n, &x0, &y0, &z0, X, Y, Z);

            found=0;
			if ((inrange=InImageRange(x0,y0,z0,X,Y,Z)) && !object[voxel_n]
                && ((*tract).fa[voxel_n]>(*tract).MinFA)){

               memset(&Tr2.T2,0,sizeof(struct Trajectory));

               //initialise the direction of the trajectory
               (*tract).InitDir=Vimage[voxel];
	           length=GetTrajectory(&Tr2.T2, tract, x0*(*tract).dx, y0*(*tract).dy, z0*(*tract).dz, FODF_TRACTOGRAPHY);
               if (length>MINLENGTH){
                    GetClosestPoint(&Tr2, &i1, &i2);
                    correlation=CorrelateTrajectories(&Tr2, i1, i2);

                    if (correlation<MinCorrelation){
                        //reverse the seed trajectory and try the correlation again
                        memcpy(&Tr2.T1, &Trev, sizeof(struct Trajectory));
                        i1=(*T).length-1-i1;
                        correlation=CorrelateTrajectories(&Tr2, i1, i2);
                        memcpy(&Tr2.T1, T, sizeof(struct Trajectory));//back to the original seed trajectory
                    }
               }
               else correlation=0.0;

               if ((correlation>=MinCorrelation) && !track[voxel_n].index){
                    object[voxel_n]=(char)(pow(correlation,2)*100);
                    found=1;
               }
			}

			track[voxel].index++;

		}
		while((track[voxel].index<CONNECTED) && !found);


		if (found){
			track[voxel_n].PrevVoxel=voxel;
			voxel=voxel_n;
			Vimage[voxel]=(*tract).InitDir;//update the starting vector in this voxel
		}
		else voxel=track[voxel].PrevVoxel;
	}
	while(!(track[voxel].PrevVoxel==voxel && track[voxel].index>=CONNECTED));


    //count voxels in the object
	size=0;
	for (voxel=0;voxel<total_voxels;voxel++){
		if (!track[voxel].index) object[voxel]=0;
		else if (object[voxel]) size++;
	}

END:

	if (track) free(track);
	if (Vimage) free(Vimage);

	return size;

}


//==============================================================================
//                  Obtain the direction of Max FODF
//==============================================================================
struct ThreeVector MaxFODFdirection(struct ThreeVector directions[], float *fodf, int X, int Y, int Zpv, int volumes,
                                    int voxel, int idirections){

    int i,imax;
    struct ThreeVector zero;

    zero.x=zero.y=zero.z=0.0;

    imax=0;
    for (i=1;i<volumes;i++){//max from 2nd volume onwards
        if (fodf[voxel+i*X*Y*Zpv]>fodf[voxel+imax*X*Y*Zpv]){
            imax=i;
        }
    }

    if (fodf[voxel+imax*X*Y*Zpv]>0.0) return directions[imax];
    else return zero;
}















//==============================================================================
//              Reverse the trajectory *T
//              Put the result in *RevT
//==============================================================================
int ReverseTrajectory(struct Trajectory *T, struct Trajectory *RevT){

    int i;

    for (i=0; i<(*T).length; i++){
        (*RevT).xyz[i*3]=(*T).xyz[((*T).length-1-i)*3];
        (*RevT).xyz[i*3+1]=(*T).xyz[((*T).length-1-i)*3+1];
        (*RevT).xyz[i*3+2]=(*T).xyz[((*T).length-1-i)*3+2];
    }
    (*RevT).seed=(*T).length-1-(*T).seed;
    (*RevT).length=(*T).length;

    return 1;
}





//==============================================================================
//              -Get a depth intensity projection onto 3 planes
//              -output is in plane1[X*Y], plane2[X*Z], and plane3[Y*Z]
//==============================================================================
int TensorObjectProjection(unsigned char *object, int X, int Y, int Z, struct ImagePlanes *planes){

    int x,y,z;
    int voxel;

    if ((*planes).plane1) free((*planes).plane1);
    if ((*planes).plane2) free((*planes).plane2);
    if ((*planes).plane3) free((*planes).plane3);

    (*planes).plane1=(float *)malloc(X*Y*sizeof(float));//axial
    (*planes).plane2=(float *)malloc(X*Z*sizeof(float));//coronal
    (*planes).plane3=(float *)malloc(Y*Z*sizeof(float));//sagittal

    if ((*planes).plane1 && (*planes).plane2 && (*planes).plane3){
        memset((*planes).plane1,0,sizeof(float)*X*Y);
        memset((*planes).plane2,0,sizeof(float)*X*Z);
        memset((*planes).plane3,0,sizeof(float)*Y*Z);
        (*planes).X=X;(*planes).Y=Y;(*planes).Z=Z;
        (*planes).max=0.0;
        for (z=0;z<Z;z++){
            for (y=0;y<Y;y++){
                for (x=0;x<X;x++){
                    voxel=x+y*X+z*X*Y;
                    if (object[voxel]){
                        if (z>(int)(*planes).plane1[x+y*X]) (*planes).plane1[x+y*X]=(float)(Z-1-z);
                        if (y>(int)(*planes).plane2[x+z*X]) (*planes).plane2[x+z*X]=(float)y;
                        if (x>(int)(*planes).plane3[y+z*Y]) (*planes).plane3[y+z*Y]=(float)x;
                    }
                }
            }
        }
    }
    else{
        if ((*planes).plane1) free((*planes).plane1);
        if ((*planes).plane2) free((*planes).plane2);
        if ((*planes).plane3) free((*planes).plane3);
        return 0;
    }

    (*planes).max=(X>Y) ? (float)(X-1):(float)(Y-1);
    (*planes).max=((*planes).max>(float)(Z-1)) ? (float)(Z-1):(*planes).max;

    return 1;
}






















