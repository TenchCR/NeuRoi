/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"
#include "CoordinateProcess.h"
#include "CBMAfiles.h"

//======================================================================================================
//kernels
//======================================================================================================
double KernelCBMA(double dist, double maxdist, int kerneltype)
{

	double x=dist/maxdist;
	double y;

	switch (kerneltype)
	{
    case COSINE_KERNEL:
        if (dist>=maxdist) return 0.0;
        return 0.5*(cos(3.1415926*x/2)+1.0);
        break;

    case QUADRATIC_KERNEL:
        if (dist>=maxdist) return 0.0;
        return (1.0-x*x);
        break;

    case BETA_KERNEL:
        if (dist>=maxdist) return 0.0;
        y=0.5+x/2;
        return y*y*(1.0-y)*(1.0-y);
        break;

    case SPHERE_KERNEL:
        if (dist>=maxdist) return 0.0;
        return 1.0;
        break;

    case GAUSSIAN_KERNEL:
        return exp(-x*x/2);
        break;
	}

	return 0.0;
}
//=============================================================================
int TestKernelShape(int kernel_type)
{
	double x;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	sprintf(fname,"%s//kernelshape.csv",REPORT_FOLDER);

	if ((fp=fopen(fname,"w")))
	{
		for (x=0.0; x<10.0; x+=0.1)
		{
			fprintf(fp,"%f,%f\n",x,KernelCBMA(x,10.0, kernel_type));
		}

		fclose(fp);
	}
	return 0.0;
}
//======================================================================================================
//compute distance between two coordinates
//======================================================================================================
double ActivationSeparation(struct Coordinates *Co, int i, int j)
{
    return sqrt( ActivationSeparation2(Co, i, j) );
}
//======================================================================================================
//compute distance between two coordinates
//======================================================================================================
double ActivationSeparation2(struct Coordinates *Co, int i, int j)
{
    float a,b,c;
    a=(*Co).x[i]-(*Co).x[j];
    b=(*Co).y[i]-(*Co).y[j];
    c=(*Co).z[i]-(*Co).z[j];

    return a*a + b*b + c*c;
}
//======================================================================================================
//test if the experiments are whole brain or ROI
//======================================================================================================
int IsWBStudy(struct Coordinates *c)
{
    int study;

    for (study=0; study<(*c).Nexperiments; study++)
    {
        if ((*c).VOI[study]==1) return 0;
    }
    return 1;
}
//======================================================================================================
//How many coordinates in a study?
//======================================================================================================
int CoordinatesInStudy(struct Coordinates *C, int s)
{
    int Nfoci=(*C).TotalFoci;
    int i;
    int count=0;
    for (i=0;i<Nfoci;i++)
        {
            if ((*C).experiment[i]==s) count++;
        }
    return count;
}
//======================================================================================================
int CoordinateDistance2Matrix(float x[], float y[], float z[], short int iexp[], double dist2[], int Nfoci)
{
	int i,j;

	for (j=0; j<Nfoci; j++)
	{
	    for (i=j; i<Nfoci; i++)
			{
                dist2[i+j*Nfoci]=DBL_MAX;
                dist2[j+i*Nfoci]=DBL_MAX;
			}
	}

	for (j=0; j<Nfoci; j++)
	{
			for (i=j; i<Nfoci; i++)
			{
				if (iexp[i] != iexp[j])
				{
					dist2[i +j*Nfoci] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);
					dist2[j +i*Nfoci] = dist2[i +j*Nfoci];
				}
			}
	}

	return 0;
}
//========================================================================================================
//======================================================================================================
int CoordinateDistance2MatrixNoStudies(float x[], float y[], float z[], double dist2[], int Nfoci, double mindist2)
{
	int i,j;
	int index_i;
	int index_j;

	index_j=0;
	for (j=0; j<Nfoci; j++)
	{
            index_i=j*Nfoci;
			for (i=j; i<Nfoci; i++)
			{

					dist2[i + index_j] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);

					if (dist2[i + index_j]<mindist2)
                    {
                        dist2[i + index_j]=mindist2;
                    }

					dist2[j + index_i] = dist2[i + index_j];

					index_i+=Nfoci;
			}
        index_j+=Nfoci;
	}

	return 0;
}
//======================================================================================================
//compute a matrix of squared distances between any coordinate with pvalue<=critical and any significant coordinate
int CoordinateDistance2MatrixWithSignificance(float x[], float y[], float z[], short int iexp[], double pvalue[], double critical, double dist2[], int Nfoci)
{
	int i,j;

	//initialise
	for (j=0; j<Nfoci; j++)
	{
	    for (i=j; i<Nfoci; i++)
			{
                dist2[i+j*Nfoci]=DBL_MAX;
                dist2[j+i*Nfoci]=DBL_MAX;
			}
	}

	for (j=0; j<Nfoci; j++)
	{
		if (pvalue[j]<=critical)
		{
			for (i=j; i<Nfoci; i++)
			{
				if (pvalue[j]<=critical && iexp[i]!=iexp[j])
				{
					dist2[i + j*Nfoci] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);
					dist2[j + i*Nfoci] = dist2[i + j*Nfoci];
				}
			}
		}
	}

	return 0;
}
//======================================================================================================
//compute the voxel from the foci
//======================================================================================================
int FociToVoxel(float x, float y, float z, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0)
{

    int voxel;
    int xi,yi,zi;
    //char txt[256];

    xi=(x+x0)/dx+0.5;
    yi=(y+y0)/dy+0.5;//nearest integer
    zi=(z+z0)/dz+0.5;

    voxel=xi+yi*X+zi*X*Y;
    if ((voxel<X*Y*Z) && (voxel>=0)) return voxel;
    else return 0;
}










/*
int EliminateDuplicateEffects(struct Coordinates *C);
//======================================================================================================
//cluster the coordinates using MeanShift LOO method and look for instances of studies contributing multiple coordinates to clusters
//this can occur if authors report multiple peaks close to each other, or when experiments within study are merged
//======================================================================================================
int EliminateDuplicateEffects(struct Coordinates *C)
{
    int result=0;
    float *xc=NULL;
    float *yc=NULL;
    float *zc=NULL;
    int Nfoci=(*C).TotalFoci;
    int Nstudies=(*C).Nexperiments;
    int study;
    int cluster;
    int focus;
    struct MeanShiftResult R;
    struct Coordinates Copy;
    char fname[MAX_PATH];
    int L;
    int *N=NULL;
    struct ThreeVector *V=NULL;
    double *Z=NULL;
    FILE *fp;



    sprintf(fname,"%s",(*C).coordinate_file_name);
    L=strlen(fname);
    fname[L-4]='\0';
    sprintf(fname,"%s_processed.txt",fname);

    if (!(fp=fopen(fname,"w"))) goto END;

    memset(&Copy,0,sizeof(struct Coordinates));

    if (!(xc=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(yc=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(zc=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(CopyCoordinates(C, &Copy))) goto END;

    R = FindBestKernel(&Copy, 4, xc, yc, zc, 8.0, 1.0, 3.0, (FILE *)NULL);

    if (!(V=(struct ThreeVector *)malloc((R.Nclusters+1)*sizeof(struct ThreeVector)))) goto END;
    if (!(N=(int *)malloc((R.Nclusters+1)*sizeof(int)))) goto END;
    if (!(Z=(double *)malloc((R.Nclusters+1)*sizeof(double)))) goto END;

    //find those foci within study that contribute to clusters
    //average those that contribute multiple times
    if (Copy.ZscoreUsed) fprintf(fp,"//4COLUMN\n\n");

    for (study=0;study<Nstudies;study++)
    {
        fprintf(fp,"//STUDYID %s\n",Copy.ID[study].txt);

        if (Copy.corrected[study])
			fprintf(fp,"//CORRECTED\n");
		else
			fprintf(fp,"//UNCORRECTED\n");

		switch(Copy.modality[study])
		{
		case PET_STUDY:
			fprintf(fp,"//PET\n");
			break;
		case FMRI_STUDY:
			fprintf(fp,"//FMRI\n");
			break;
		case STRUCTURAL_STUDY:
			fprintf(fp,"//STRUCTURAL\n");
			break;
		case SPECT_STUDY:
			fprintf(fp,"//SPECT\n");
			break;
		}

		if (Copy.subanalysis[study])
			fprintf(fp,"//SUBANALYSIS\n");
		if (Copy.VOI[study])
			fprintf(fp,"//VOI\n");
		else
			fprintf(fp,"//WB\n");

        fprintf(fp,"//CENSOR=%f\n",Copy.Zcensor[study]);
		fprintf(fp,"//COVARIATE=%f\n",Copy.covariate[study]);
		fprintf(fp,"//DESCRIPTION %s\n",Copy.DESC[study].txt);
		fprintf(fp,"//CONDITIONID %s\n",Copy.CND[study].txt);
		fprintf(fp,"//CONTRASTID %s\n",Copy.CTRST[study].txt);
		fprintf(fp,"//controls=%d\n",Copy.ControlsInExp[study]);
		fprintf(fp,"//subjects=%d\n",Copy.SubjectsInExp[study]);

        memset(V,0,(R.Nclusters+1)*sizeof(struct ThreeVector));
        memset(N,0,(R.Nclusters+1)*sizeof(int));
        memset(Z,0,(R.Nclusters+1)*sizeof(double));
        for (focus=0;focus<Nfoci;focus++)
        {
            if (Copy.experiment[focus]==study)
            {
                if ((cluster=Copy.cluster[focus]))
                {
                V[cluster].x += Copy.x[focus];
                V[cluster].y += Copy.y[focus];
                V[cluster].z += Copy.z[focus];
                Z[cluster] += Copy.Zsc[focus];
                N[cluster]++;
                }
                else
                {
                    //save those not clustered
                    if (Copy.ZscoreUsed) fprintf(fp,"%f %f %f %f\n",Copy.x[focus], Copy.y[focus], Copy.z[focus], Copy.Zsc[focus]);
                    else fprintf(fp,"%f %f %f\n",Copy.x[focus], Copy.y[focus], Copy.z[focus]);
                }
            }
        }//focus
       //save the clustered
       for (cluster=1;cluster<=R.Nclusters;cluster++)
       {
           if (N[cluster])
           {
               if (Copy.ZscoreUsed) fprintf(fp,"%f %f %f %f\n",V[cluster].x/N[cluster], V[cluster].y/N[cluster], V[cluster].z/N[cluster], Z[cluster]/N[cluster]);
                else fprintf(fp,"%f %f %f\n",V[cluster].x/N[cluster], V[cluster].y/N[cluster], V[cluster].z/N[cluster]);
           }
       }

       fprintf(fp,"\n\n\n");
    }


    result=1;
END:

    FreeCoordinates(&Copy);

     if (fp)
        fclose(fp);

    if (V) free(V);

    if (xc)
    {
        free(xc);
    }
    if (yc)
    {
        free(yc);
    }
    if (zc)
    {
        free(zc);
    }
    return result;
}
*/
