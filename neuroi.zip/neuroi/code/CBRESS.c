/*
Copyright 2009 - 2020 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

///CBRESS

/*
An update to CBRES. Instead of using randomisation so that it does not assume fixed spatial effect
allow the effect size to have two possible distributions.

Distribution 0: this is truncated Normal between +-alpha, where alpha is the threshold effect size

Distribution 1: this is Normal

Random spatial effects  fall into distribution 0 and 1
Fixed spatial effects fall only into distribution 1

INTERVAL_CENSORED data can be from either distribution

LEFT_ RIGHT_ and NOT_CENSORED can only be from distribution 1
*/

///***********************QUESTIONS**************************

#include "ClusterZ.h"
#include "global.h"



//===========================================================================================
double L_EffectDistribution(double P[], int N, void *E)
{
    struct EffectSample *Es=(struct EffectSample *)E;
    double LL=0.0;
    double L;
    int study;
    int studies=(*Es).Samples;
    double censorlevel;
    double mean,sigma, sigma0,f;
    double sd0,sd;
    double d;
    double zero,nonzero;

    mean=P[CBRESS_MEAN];
    sigma0=P[CBRESS_SD0];
    sigma=P[CBRESS_SD];
    f=Sigmoid(P[CBRESS_FRACTION]);

    for (study=0; study<studies; study++)
    {
        //study specific values
        censorlevel=(*Es).CensorLevel[study];
        sd0=sqrt(sigma0*sigma0 + (*Es).SampleSD[study]*(*Es).SampleSD[study]);
        sd=sqrt(sigma*sigma + (*Es).SampleSD[study]*(*Es).SampleSD[study]);
        d=(*Es).d[study];

        switch((*Es).censor[study])
        {

        case NOT_CENSORED:
            zero=NormalDistribution(0.0, sd0*sd0, d);
            nonzero=NormalDistribution(mean, sd*sd, d);
            break;

        case INTERVAL_CENSORED:
            zero=NormalCDF(censorlevel,0.0,sd0);
            nonzero=NormalCDF(censorlevel,fabs(mean),sd);
            break;
        case LEFT_CENSORED:
            zero=NormalCDF(-censorlevel,0.0,sd0);
            nonzero=NormalCDF(-censorlevel,mean,sd);
            break;
        case RIGHT_CENSORED:
            zero=1.0-NormalCDF(censorlevel,0.0,sd0);
            nonzero=1.0-NormalCDF(censorlevel,mean,sd);
            break;
        }
        L=(1.0-f)*zero + f*nonzero;
        if (L>DBL_MIN)
            LL += log(L);
        else
            LL+=log(DBL_MIN);
    }

    return exp(LL);
}





//======================================================================================================
//======================================================================================================
///A FUNCTION TO PRODUCE TEST DATA
/*
Make an effect sample structure then fill it with data
The data are bimodal such that there are NullStudies data drawn from a normal with mean 0 and within study variance
There are then Nstudies-NullStudies drawn from a normal with mean Zmean/sqrt(subjects) and variance Zsd*Zsd+1/subjects
Non of the data are censored here; there is another function for that (CensorTheTestData)
*/
//======================================================================================================
struct EffectSample FillEffectStructureWithUncensoredTestData(int Nstudies, int NullStudies, int Nsubjects, double Zmean, double Zsd, double NullSigma)
{
    struct EffectSample Es;
    double d;
    int i,subjects;
    double nullSD;

    memset(&Es,0,sizeof(struct EffectSample));

    if (!MakeEffectSampleStructure(&Es, Nstudies, ID_MEANZ))
    {
        FreeEffectSampleStructure(&Es);
        return Es;
    }

    //Null study effects
    for (i=0; i<NullStudies; i++)
    {
        subjects=Nsubjects;
        Es.SampleSD[i] = sqrt(1.0/subjects);
        nullSD=sqrt(NullSigma*NullSigma+1.0/subjects);
        Es.d[i]=GaussRandomNumber_BoxMuller(0.0,nullSD);
        Es.CensorLevel[i] = 0.0;
        Es.censor[i] = NOT_CENSORED;
    }

    //Non-Null study effects
    for (i=NullStudies; i<Nstudies; i++)
    {
        subjects=Nsubjects;
        d=GaussRandomNumber_BoxMuller(Zmean,Zsd)*sqrt(1.0/subjects);
        Es.d[i]=GaussRandomNumber_BoxMuller(d,sqrt(1.0/subjects));
        Es.SampleSD[i] = sqrt(1.0/subjects);
        Es.CensorLevel[i] = 0.0;
        Es.censor[i] = NOT_CENSORED;
    }

    return Es;
}
//=======================================================================
int CensorTheTestData(struct EffectSample *Es, double Zthreshold)
{
    int Nstudies=(*Es).Samples;
    int i;
    int censored=0;

    for (i=0; i<Nstudies; i++)
    {
        if ((*Es).d[i]<fabs(Zthreshold)*(*Es).SampleSD[i])
        {
            (*Es).d[i]=0.0;
            (*Es).CensorLevel[i] = fabs(Zthreshold)*(*Es).SampleSD[i];
            (*Es).censor[i] = INTERVAL_CENSORED;
            censored++;
        }
    }

    return censored;
}





