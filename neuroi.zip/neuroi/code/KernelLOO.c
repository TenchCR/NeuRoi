/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


/*
Sum over experiments the kernel estimate of the distribution of foci
Only the closest contributes
The LOO doesn't count
Choose width of kernel
Choose threshold by fraction landing where the distribution is zero
*/

#include "KernelLOO.h"





int SaveTalairachNetworkProjectionCVCA(HWND hwndMain,
                                       struct Coordinates *Co,
                                       double Connections[],
                                       float xp[],float yp[], float zp[],
                                       int Nclusters,
                                       char directory[], char name[]);


int ClusterConnectionsLeaveOneOut(HWND hwnd, struct Coordinates *C,
                                  float xc[], float yc[], float zc[],
                                  int Nclusters, char directory[]);



int FindBestClusteringSolution(struct Image *image, struct Coordinates *C,
                               float xc[], float yc[], float zc[], double dist2[], double width,
                               int Neighbours, short int valid[], char directory[]);

int AugmentClusters(struct Coordinates *C, short int augmented[], double dist2[], double width2, int Nclusters, float xc[], float yc[], float zc[]);


double GetConnections(short int cluster[], double Connections[], short int study[], int Nfoci, int Nstudies, int Nclusters, int LeaveOut);

int PermuteClusters(short int OriginalClusters[], short int PermutedClusters[],
                    short int StudyThisFocus[], int NumberOfStudies, int NumberOfClusters, int NumberOfFoci);

int CVCA(HWND hwnd, struct Coordinates *Corg, int randomfocisamples, int MarkerSize);

int ReportClustersCVCA(float x[], float y[], float z[], float Zsc[], short int cluster[], int Nfoci,
                       short int exprmnt[], int Nexperiments,
                       struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                       char directory[],
                       int X, int Y, int Z, float z0,
                       float dx, float dy, float dz,
                       float xc[], float yc[], float zc[], int Nclusters, int MinStudiesPerCluster);

double MaxKernelLOOscore(struct Coordinates *C, struct KernelMinimise *KM);
double KernelLOO(double dist, double maxdist);
double GetKernelLOOScore(struct Coordinates *C, double dist2[], double width);
double GetKernelScoreLOO(struct Coordinates *C, double dist2[], double width, int Neighbours, int *ConcordantCount);
double KernelMinimiseFunction(double *width, int N, void *KernelMin);
double KernelEstimateAtCoordinate(struct Coordinates *C, float x, float y, float z, double width, short int valid[]);
int StoreDataQuick(HWND hwnd, struct Image *image, struct Coordinates *C, double dist2[], int Neighbours, double width, char directory[], float xc[], float yc[], float zc[], int marker);
int SaveReportedStructuresCVCA(struct Coordinates *C, char directory[], short int *concordant);
//==========================================================================
//=============================================================================================
//                         CVCA dialog callback function
//=============================================================================================
INT_PTR CALLBACK CVCA_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    int MarkerSize;
    static struct Coordinates Coordinates,ContrastCoordinates;
    static int randomfocisamples;
    int tmp;
    char txt[256];
    static char directory[MAX_PATH];

    switch (msg) {


    case WM_CLOSE:
        FreeCoordinates(&Coordinates);
        FreeCoordinates(&ContrastCoordinates);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hABC=(HWND)NULL;
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:
        MarkerSize=3;
        sprintf(txt,"%d",MarkerSize);
        SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_SETTEXT, 0, (LPARAM)txt);
        sprintf(txt,"%d",randomfocisamples);
        SendMessage(GetDlgItem(hwnd,ID_RANDOMISATIONS), WM_SETTEXT, 0, (LPARAM)txt);
        break;


    case WM_INITDIALOG:
        memset(&Coordinates,0,sizeof(struct Coordinates));
        memset(&ContrastCoordinates,0,sizeof(struct Coordinates));
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        randomfocisamples=0;
        break;


    case WM_COMMAND:
        switch (LOWORD(wParam)) {



        case ID_ADD_COORDINATE_FILE:
            EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),FALSE);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &Coordinates, gImage.X,gImage.Y, gImage.Z,gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0)) {


                ///merge studies and remove any duplicates as these are not independent evidence of effect and reduce sensitivity
                MergeCoordinatesbyStudy(&Coordinates);
                RemoveWithinStudyDuplicates(&Coordinates);

                tmp=DirectoryFileDivide(Coordinates.coordinate_file_name);
                sprintf(directory,"%s",Coordinates.coordinate_file_name);
                directory[tmp]='\0';

                CheckForCoordinateDuplication(&Coordinates,txt, directory);

                SendMessage(GetDlgItem(hwnd,ID_COORDINATE_FILES), WM_SETTEXT, 0, (LPARAM)Coordinates.coordinate_file_name);
                EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_ANALYSIS),TRUE);
            } else {
                MessageBox(hwnd,"Failed to add coordinate file","",MB_OK|MB_ICONWARNING);
            }
            break;



        case ID_RUN_CVCA_ANALYSIS:
            EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_ANALYSIS),FALSE);
            EnableWindow(GetDlgItem(hwnd,IDOK),FALSE);

            SendMessage(GetDlgItem(hwnd,ID_RANDOMISATIONS), WM_GETTEXT, 256, (LPARAM)txt);
            randomfocisamples=atoi(txt);

            SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
            MarkerSize=atoi(txt);

            CVCA(GetParent(hwnd), &Coordinates, randomfocisamples, MarkerSize);

            SendMessage(hwnd, WM_CLOSE,0,0);
            break;


        case ID_ADD_CONTRAST_COORDINATE_FILE:
            EnableWindow(GetDlgItem(hwnd,ID_ADD_CONTRAST_COORDINATE_FILE),FALSE);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &ContrastCoordinates, gImage.X,gImage.Y, gImage.Z,gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0)) {

                ///merge studies and remove any duplicates as these are not independent evidence of effect and reduce sensitivity
                MergeCoordinatesbyStudy(&ContrastCoordinates);
                RemoveWithinStudyDuplicates(&ContrastCoordinates);

                CheckForCoordinateDuplication(&ContrastCoordinates,txt, directory);

                SendMessage(GetDlgItem(hwnd,ID_CONTRAST_FILES), WM_SETTEXT, 0, (LPARAM)ContrastCoordinates.coordinate_file_name);
                EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_CONTRAST),TRUE);
            }
            break;

        case ID_RUN_CVCA_CONTRAST:
            EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_ANALYSIS),FALSE);
            EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_CONTRAST),FALSE);
            EnableWindow(GetDlgItem(hwnd,IDOK),FALSE);

            SendMessage(GetDlgItem(hwnd,ID_RANDOMISATIONS), WM_GETTEXT, 256, (LPARAM)txt);
            randomfocisamples=atoi(txt);

            SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
            MarkerSize=atoi(txt);

            if (Coordinates.TotalFoci>0 && ContrastCoordinates.TotalFoci>0) {
                CompareCoordinatesUsingLOO(GetParent(hwnd), &gImage, &Coordinates, &ContrastCoordinates, randomfocisamples);
            }

            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;
        }
        break;


    }
    return 0;
}


//==========================================================================
//==========================================================================
int CVCA(HWND hwnd, struct Coordinates *Corg, int randomfocisamples, int MarkerSize)
{
    struct KernelMinimise KM;
    struct Image Cpy;
    struct Coordinates C;
    int Nfoci=(*Corg).TotalFoci;
    double *width=NULL;
    double *score=NULL;
    int *N=NULL;
    int loop;
    char txt[256];
    HDC hDC=GetDC(NULL);
    char fname[MAX_PATH];
    char directory[MAX_PATH], kerneldir[MAX_PATH];
    FILE *fp;
    int tmp;
    float *xc=NULL;
    float *yc=NULL;
    float *zc=NULL;

    //TestKernelShape();

    tmp=DirectoryFileDivide((*Corg).coordinate_file_name);
    sprintf(directory,"%s",(*Corg).coordinate_file_name);
    directory[tmp]='\0';
    sprintf(kerneldir,"%s\\CVCA",directory);
    CreateDirectory(kerneldir, NULL);


    sprintf(fname,"%s\\File Descriptions.txt",kerneldir);
    if ((fp=fopen(fname,"w"))) {
        fprintf(fp,"score.csv: This file describes the optimal score as a function of the kernel width and number of nearby studies that define concordance.\n");
        fprintf(fp,"The maximum score determines the optimal CVCA solution\n");
        fclose(fp);
    }

    memset(&C,0,sizeof(struct Coordinates));
    memset(&Cpy, 0, sizeof(struct Image));
    memset(&KM,0,sizeof(struct KernelMinimise));

    if (!(width=(double *)malloc((randomfocisamples+1)*sizeof(double))))
        goto END;

    if (!(score=(double *)malloc((randomfocisamples+1)*sizeof(double))))
        goto END;

    if (!(N=(int *)malloc((randomfocisamples+1)*sizeof(int))))
        goto END;

    if (!(xc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!(yc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!(zc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!CopyCoordinates(Corg,&C))
        goto END;

    if (!MakeCopyOfImage(&gImage, &Cpy))
        goto END;

    if (!(KM.dist2=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;


    KM.C=&C;
    sprintf(fname,"%s//score.csv",kerneldir);
    if (!(KM.fp=fopen(fname,"w")))
        goto END;


    for (loop=0; loop<=randomfocisamples; loop++) {
        score[loop] = MaxKernelLOOscore(&C, &KM);
        width[loop] = KM.width;
        N[loop] = KM.Neighbours;

        sprintf(txt,"loop:%d  Width:%f  Neighbours:%d",loop, width[loop], KM.Neighbours);
        if (hDC)
            TextOut(hDC,100,200,txt,strlen(txt));

        if (!loop) {

            StoreDataQuick(hwnd, &Cpy, &C, KM.dist2, KM.Neighbours, KM.width, kerneldir, xc, yc, zc, MarkerSize);

        }

        CopyCoordinates(Corg,&C);
        RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z,
                                       gImage.dx, gImage.dy, gImage.dz,
                                       gImage.x0, gImage.y0, gImage.z0,
                                       &C,10.0);

        if (KM.fp) {
            fclose(KM.fp);
            KM.fp=NULL;
        }
    }


    sprintf(fname,"%s\\File Descriptions.txt",kerneldir);
    if ((fp=fopen(fname,"a"))) {
        fprintf(fp,"\ninference.csv: This file records the inference on the solution.\n");
        fprintf(fp,"This includes the best score for the original data ans a set of best scores for null (randomised) data.\n");
        fprintf(fp,"The statistical significance is reported as a Z score.\n");
        fclose(fp);
    }


    sprintf(fname,"%s//inference.csv",kerneldir);
    if ((fp=fopen(fname,"w"))) {
        for (loop=0; loop<=randomfocisamples; loop++) {
            fprintf(fp,"%d,%f,%g,%d\n",loop,width[loop],score[loop],N[loop]);
        }
        fprintf(fp,",,=stdev(C2:C%d)\n",randomfocisamples+1);
        fprintf(fp,",,=average(C2:C%d)\n",randomfocisamples+1);
        fprintf(fp,",Z score=,=(C1-C%d)/C%d\n",randomfocisamples+2, randomfocisamples+1);
        fclose(fp);
    }


END:
    if (KM.dist2)
        free(KM.dist2);

    if (xc)
        free(xc);
    if (yc)
        free(yc);
    if (zc)
        free(zc);

    if (width)
        free(width);

    if (score)
        free(score);

    if (N)
        free(N);

    ReleaseDC(NULL,hDC);

    ReleaseImage(&Cpy);

    FreeCoordinates(&C);

    return 0;
}

//==========================================================================
//==========================================================================
//==========================================================================
int CVCAforCBMAN(HWND hwnd, struct Image *image, struct Coordinates *C, float xc[], float yc[], float zc[], char directory[])
{
    struct KernelMinimise KM;
    int Nclusters=0;
    int Nfoci=(*C).TotalFoci;
    short int *concordnt=NULL;



    if (!(concordnt=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;

    memset(&KM,0,sizeof(struct KernelMinimise));

    if (!(KM.dist2=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;

    KM.C=C;

    MaxKernelLOOscore(C, &KM);

    ConcordantCoordinates(Nfoci, (*C).Nexperiments, KM.dist2, (*C).experiment, KM.width, concordnt, KM.Neighbours, -1);

    Nclusters=FindBestClusteringSolution(image, C, xc, yc, zc, KM.dist2, KM.width, KM.Neighbours, concordnt, directory);

    ClusterConnectionsLeaveOneOut(hwnd, C, xc, yc, zc, Nclusters, directory);


END:
    if (KM.dist2)
        free(KM.dist2);

    if (concordnt)
        free(concordnt);

    return Nclusters;
}
//==========================================================================
double MaxKernelLOOscore(struct Coordinates *C, struct KernelMinimise *KM)
{

    int Nfoci=(*C).TotalFoci;
    double width[1];
    double d[1];
    double current;
    double score;
    int bestneighbours;
    int bestcount;
    double bestwidth;
    double maxscore;

    (*KM).C=C;
    CoordinateDistance2MatrixNoStudies((*C).x, (*C).y, (*C).z, (*KM).dist2, Nfoci, 1.0);

    bestcount=0;
    bestneighbours=0;
    bestwidth=0.0;
    maxscore=0.0;
    for ((*KM).Neighbours=4; (*KM).Neighbours<10; (*KM).Neighbours++) {

        width[0]=3.1415;
        do {
            width[0] += 3.1415;
            current=KernelMinimiseFunction(width, 1, KM);
        } while (current==0.0 && width[0]<80.0);

        d[0]=3.1415;
        score=0.0;
        if (current<0.0)
            score = -GoldenSearch(width, d, 1, current, KernelMinimiseFunction, KM, 5);

        if (bestwidth==0.0 ||score>=maxscore) {
            maxscore=score;
            bestwidth=width[0];
            bestneighbours=(*KM).Neighbours;
            bestcount=(*KM).ConcordantCount;
        }
    }

    //save results in KM
    (*KM).width=bestwidth;
    (*KM).Neighbours=bestneighbours;
    (*KM).ConcordantCount=bestcount;

    return maxscore;

}
//==========================================================================
double KernelMinimiseFunction(double *width, int N, void *KernelMin)
{
    double score=0.0;
    struct KernelMinimise *KM=(struct KernelMinimise *)KernelMin;

    score = GetKernelScoreLOO((*KM).C, (*KM).dist2, *width, (*KM).Neighbours, &(*KM).ConcordantCount);

    if ((*KM).fp) {
        fprintf((*KM).fp, "%d,%f,%f,%d\n",(*KM).Neighbours, (*width), score, (*KM).ConcordantCount);
    }

    return -score;
}
//==========================================================================

double ThisStudyDensity(int Nfoci, int LOstudy, short int study[], int Nstudies,
                        int LeaveOut, double dist2[], double width, int Neighbours,
                        short int concordant[]);
double GetKernelScoreLOO(struct Coordinates *C, double dist2[], double width, int Neighbours, int *ConcordantCount)
{

    double score=0.0;
    int Nfoci=(*C).TotalFoci;
    int NumberOfStudies=(*C).Nexperiments;
    int LeaveOutStudy;
    short int *concordant=NULL;

    *ConcordantCount=0;

    if (!(concordant=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;


    if (width<=0.0)
        return 0.0;

    //the density for each focus when one study is left out
    //the density is zero if no focus is concordant
    for (LeaveOutStudy=0; LeaveOutStudy<NumberOfStudies; LeaveOutStudy++) {

        *ConcordantCount += ConcordantCoordinates(Nfoci, NumberOfStudies, dist2, (*C).experiment, width, concordant, Neighbours, LeaveOutStudy);

        score += ThisStudyDensity(Nfoci, LeaveOutStudy, (*C).experiment, NumberOfStudies, LeaveOutStudy, dist2,  width, Neighbours, concordant);
    }


END:
    if (concordant)
        free(concordant);


    return score/pow(width,3.0);
}
//==========================================================================
//==========================================================================
//================================================================================
double ThisStudyDensity(int Nfoci, int LOstudy, short int study[], int Nstudies,
                        int LeaveOut, double dist2[], double width, int Neighbours,
                        short int concordant[])
{
    int ArrayOffset;
    int coordinate;
    int LOfocus;
    int st;
    int *NearestFocusInStudy=NULL;
    int *ConcordantCount=NULL;
    double width2=width*width;
    double *NearestKernelIntensity=NULL;
    double score=0.0;//default score
    double tmp;
    double *NearestKernelSum=NULL;

    if (!(NearestKernelSum=(double *)calloc(Nfoci,sizeof(double))))
        goto END;

    if (!(ConcordantCount=(int *)calloc(Nfoci, sizeof(int))))
        goto END;

    if (!(NearestKernelIntensity=(double *)malloc(Nstudies*sizeof(double))))
        goto END;

    if (!(NearestFocusInStudy=(int *)calloc(Nstudies, sizeof(int))))
        goto END;


    for (LOfocus=0; LOfocus<Nfoci; LOfocus++) {
        if (study[LOfocus]==LOstudy) {
            ArrayOffset=LOfocus*Nfoci;
            memset(NearestKernelIntensity,0,Nstudies*sizeof(double));
            for (coordinate=0; coordinate<Nfoci; coordinate++) {
                st=study[coordinate];
                if (concordant[coordinate] && st!=LeaveOut && dist2[ArrayOffset+coordinate]<width2) {
                    tmp=KernelCBMA(sqrt( dist2[ArrayOffset+coordinate] ), width, KERNEL_TYPE);
                    if (tmp>NearestKernelIntensity[st]) {
                        NearestKernelIntensity[st] = tmp;
                        NearestFocusInStudy[st] = coordinate;
                    }
                }
            }
            for (st=0; st<Nstudies; st++) {
                if (NearestKernelIntensity[st]>0.0) {
                    NearestKernelSum[NearestFocusInStudy[st]] += NearestKernelIntensity[st];
                    ConcordantCount[NearestFocusInStudy[st]] ++;
                }
            }
        }
    }

    for (coordinate=0; coordinate<Nfoci; coordinate++) {
        if (ConcordantCount[coordinate]) {
            score+=NearestKernelSum[coordinate]/ConcordantCount[coordinate];
        }
    }



END:
    if (NearestKernelIntensity)
        free(NearestKernelIntensity);

    if (NearestFocusInStudy)
        free(NearestFocusInStudy);

    if (NearestKernelSum)
        free(NearestKernelSum);

    if (ConcordantCount)
        free(ConcordantCount);

    return score;
}
//================================================================================
//================================================================================
/*
This function considers validity of all foci not in the LeaveOut study; Set LeaveOut to -1 (for example) for validity of all foci
The coordinates that are within width of each focus, unless they are from the LeaveOut study, are found
If they are from at least ConcordanceMinimum independent studies, the focus is considered valid
Otherwise it is not valid
*/
int ConcordantCoordinates(int Nfoci, int Nstudies, double dist2[], short int study[], double width, short int NearbyStudyCount[], int ConcordanceMinimum, int LeaveOut)
{
    int NumberOfConcordantFoci=0;
    int focus;
    int i;
    int ArrayIndex;
    int NumberOfNearbyStudies;
    int *StudyIsNear=NULL;
    double width2=width*width;

    memset(NearbyStudyCount,0,Nfoci*sizeof(short int));

    if (!(StudyIsNear=(int *)malloc(Nstudies*sizeof(int))))
        goto END;

    for (focus=0; focus<Nfoci; focus++) {
        if (study[focus] != LeaveOut) {
            memset(StudyIsNear,0,Nstudies*sizeof(int));
            ArrayIndex=focus*Nfoci;
            NumberOfNearbyStudies=1;
            for (i=0; i<Nfoci; i++) {
                if (study[i]!=study[focus] && study[i]!=LeaveOut && !StudyIsNear[study[i]]) {
                    if (dist2[ArrayIndex+i]<width2) {
                        NumberOfNearbyStudies++;
                        StudyIsNear[study[i]]=1;
                    }
                }
            }
            if (NumberOfNearbyStudies>=ConcordanceMinimum) {
                NearbyStudyCount[focus]=NumberOfNearbyStudies;
                NumberOfConcordantFoci++;
            }
        }
    }

END:
    if (StudyIsNear)
        free(StudyIsNear);

    return NumberOfConcordantFoci;
}
//======================================================================================
//==========================================================================
double KernelEstimateAtCoordinate(struct Coordinates *C, float x, float y, float z, double width, short int valid[])
{
    int Nfoci=(*C).TotalFoci;
    int Nstudies=(*C).Nexperiments;
    int focus;
    int study;
    double dist2;
    float *HighestKernelInStudy=NULL;
    double SumOverHighestKernels=0.0;
    double tmp;

    if (!(HighestKernelInStudy=(float *)calloc(Nstudies, sizeof(float))))
        goto END;


    for (focus=0; focus<Nfoci; focus++) {
        if (valid[focus]) {

            study=(*C).experiment[focus];
            dist2=(x-(*C).x[focus])*(x-(*C).x[focus]) +
                  (y-(*C).y[focus])*(y-(*C).y[focus]) +
                  (z-(*C).z[focus])*(z-(*C).z[focus]);

            tmp=KernelCBMA(sqrt( dist2 ), width, KERNEL_TYPE);

            if (tmp>HighestKernelInStudy[study])
                HighestKernelInStudy[study]=tmp;

        }
    }


    for (study=0; study<Nstudies; study++) {
        SumOverHighestKernels += HighestKernelInStudy[study];
    }

END:
    if (HighestKernelInStudy)
        free(HighestKernelInStudy);

    return SumOverHighestKernels;

}
//======================================================================================
int SaveRGBclustersKernelLOO(int FociVoxel[], short int cluster[],
                             short int study[], int Nfoci, struct Image *img,
                             int Nclusters, int Marker,
                             char directory[], char name[]);

int StoreDataQuick(HWND hwnd, struct Image *image, struct Coordinates *C, double dist2[], int Neighbours, double width, char directory[],
                   float xc[], float yc[], float zc[], int marker)
{

    int VOXELS=(*image).X*(*image).Y*(*image).Z;
    int Nfoci=(*C).TotalFoci;
    int focus;
    int Nclusters=0;
    struct Image CpyOfImage;
    short int *IsFocusConcordant=NULL;
    char fname[MAX_PATH];


    sprintf(fname,"%s//kernel",directory);

    if (!(IsFocusConcordant=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;

    ConcordantCoordinates(Nfoci, (*C).Nexperiments, dist2, (*C).experiment, width, IsFocusConcordant, Neighbours, -1);

    memset (&CpyOfImage,0,sizeof(struct Image));
    if (!MakeCopyOfImage(image, &CpyOfImage))
        goto END;

    memset(CpyOfImage.img,0,sizeof(float)*VOXELS);

    DensityImage(&CpyOfImage, C,  IsFocusConcordant, width);

    if ((*image).ImageType==HDR)
        sprintf(CpyOfImage.filename,"%s.img",fname);
    else
        sprintf(CpyOfImage.filename,"%s.nii",fname);

    SaveAsCharImage(&CpyOfImage, 1);

    Nclusters=FindBestClusteringSolution(image, C, xc, yc, zc, dist2, width, Neighbours, IsFocusConcordant, directory);

    memset(CpyOfImage.img,0,sizeof(float)*VOXELS);
    for (focus=0; focus<Nfoci; focus++) {
        if (IsFocusConcordant[focus])
            CpyOfImage.img[(*C).voxel[focus]]=2.0;
        else
            CpyOfImage.img[(*C).voxel[focus]]=1.0;
    }

    sprintf(fname,"%s//foci",directory);
    if ((*image).ImageType==HDR)
        sprintf(CpyOfImage.filename,"%s.img",fname);
    else
        sprintf(CpyOfImage.filename,"%s.nii",fname);
    SaveAsCharImage(&CpyOfImage, 1);



    SaveRGBclustersKernelLOO((*C).voxel,(*C).cluster,
                             (*C).experiment, Nfoci, &CpyOfImage,
                             Nclusters, marker,
                             directory, "ClusterRGB");


    SaveReportedStructuresCVCA(C, directory, IsFocusConcordant);

    ReportClustersCVCA((*C).x, (*C).y, (*C).z, (*C).Zsc, (*C).cluster, (*C).TotalFoci,
                       (*C).experiment, (*C).Nexperiments,
                       (*C).ID, (*C).CTRST, (*C).CND,
                       directory,
                       gImage.X, gImage.Y, gImage.Z, gImage.z0,
                       gImage.dx, gImage.dy, gImage.dz,
                       xc, yc, zc, Nclusters, Neighbours);

    ClusterConnectionsLeaveOneOut(hwnd, C, xc, yc, zc, Nclusters, directory);



    Nclusters=FindBestClusteringSolution(image, C, xc, yc, zc, dist2, width, Neighbours, IsFocusConcordant, directory);

    FILE *fp;
    sprintf(fname,"%s\\File Descriptions.txt",directory);
    if ((fp=fopen(fname,"a"))) {
        fprintf(fp,"\nfoci.*: This image file displays the location of all foci.\n");
        fprintf(fp,"\nkernel.*: This image file is the kernel estimate of the report frequency.\n");
        fprintf(fp,"\nClusterRGB.*: This image file is the clustering of the estimated report frequency.\n");
        fprintf(fp,"\nClusterReport: This file details the clusters shown in ClusterRGB.*.\n");
        fprintf(fp,"\nReportedStructures: This file details the Talairach regions found by the CVCA algorithm for this data.\n");
        fclose(fp);
    }
END:
    ReleaseImage(&CpyOfImage);


    if (IsFocusConcordant)
        free(IsFocusConcordant);

    return Nclusters;
}

//======================================================================================
int FindBestClusteringSolution(struct Image *image, struct Coordinates *C,
                               float xc[], float yc[], float zc[], double dist2[], double width,
                               int Neighbours, short int valid[], char directory[])
{
    char fname[MAX_PATH];
    int Nfoci=(*C).TotalFoci;
    int Nstudies=(*C).Nexperiments;
    int cluster1;
    int cluster2;
    int Nclusters=0;
    int focus1;
    int focus2;
    int ArrayOffset;
    double smooth;
    double bestsmooth;
    double *NeighbourCoordinates=NULL;
    double width2=width*width;
    int MaxQualityCount;
    int ClusterQualityCount;
    char *ClusterMembers=NULL;
    short int *ClusterExtras=NULL;
    FILE *fp;

    //allocate max required size (Nfoci*Nstudies)
    if (!(ClusterMembers=(char *)malloc(Nfoci*Nstudies)))
        goto END;

    if (!(NeighbourCoordinates=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;

    if (!(ClusterExtras=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;

    //connection matrix based on width
    CoordinateDistance2Matrix((*C).x, (*C).y, (*C).z, (*C).experiment, dist2, Nfoci);
    for (focus1=0; focus1<Nfoci; focus1++) {
        ArrayOffset=Nfoci*focus1;
        for (focus2=0; focus2<Nfoci; focus2++) {
            if (dist2[ArrayOffset+focus2]>width2)
                NeighbourCoordinates[ArrayOffset+focus2]=0.0;//includes coordinates in the same experiment
            else
                NeighbourCoordinates[ArrayOffset+focus2]=1.0;
        }
    }

    sprintf(fname,"%s//smooth.csv",directory);
    if ((fp=fopen(fname,"w"))) {
        MaxQualityCount=-1000;
        for (smooth=1.0; smooth<2.0*width; smooth+=0.1) {

            Nclusters = GetValidMeanShiftClusters(C, xc, yc, zc, Neighbours, valid, smooth);

            memset(ClusterMembers,0,Nfoci*Nstudies);
            for (focus1=0; focus1<Nfoci; focus1++) {
                if ( (cluster1=(*C).cluster[focus1]) ) {
                    ClusterMembers[(cluster1-1)*Nstudies + (*C).experiment[focus1]]=1;
                }
            }

            ClusterQualityCount=0;
            for (focus1=0; focus1<Nfoci; focus1++) {
                if ( (cluster1=(*C).cluster[focus1]) ) {
                    ArrayOffset=Nfoci*focus1;
                    for (focus2=0; focus2<Nfoci; focus2++) {
                        if ( (cluster2=(*C).cluster[focus2]) ) {
                            if (NeighbourCoordinates[ArrayOffset+focus2]>0.0) {
                                if (cluster1==cluster2)
                                    ClusterQualityCount++;//two different experiments in the same cluster is good
                                else if (cluster2!=cluster1 && !ClusterMembers[(cluster1-1)*Nstudies + (*C).experiment[focus2]])
                                    ClusterQualityCount--;//could have been in same cluster but aren't in any cluster
                            }
                        }
                    }
                }
            }
            if (ClusterQualityCount>MaxQualityCount) {
                MaxQualityCount=ClusterQualityCount;
                bestsmooth=smooth;
            }
            fprintf(fp,"%f,%d\n",smooth,ClusterQualityCount);

        }
        fclose(fp);
    }
    Nclusters = GetValidMeanShiftClusters(C, xc, yc, zc, Neighbours, valid, bestsmooth);

    while(AugmentClusters(C, ClusterExtras, dist2, width2, Nclusters, xc, yc, zc)) {
        for (focus1=0; focus1<Nfoci; focus1++) {
            if (!(*C).cluster[focus1] && ClusterExtras[focus1]) {
                (*C).cluster[focus1] = ClusterExtras[focus1];
            }
        }
    }

END:
    if (ClusterMembers)
        free(ClusterMembers);

    if (NeighbourCoordinates)
        free(NeighbourCoordinates);

    if (ClusterExtras)
        free(ClusterExtras);

    return Nclusters;
}
//======================================================================================
//this needs to consider intensities more
int DensityImage(struct Image *image, struct Coordinates *C, short int IsFocusConcordant[], double width)
{
    int result=0;
    int ListPosition, LastInList;
    int focus;
    int voxel;
    int a,b,c;
    int neighbour;
    int xi,yi,zi;
    int Nfoci=(*C).TotalFoci;
    int *ProcessedVoxelList=NULL;
    int IMAGE_VOXELS=(*image).X*(*image).Y*(*image).Z;
    float xf,yf,zf;
    double Kernel;

    if (!(ProcessedVoxelList=(int *)calloc(IMAGE_VOXELS,sizeof(int))))
        goto END;

    memset((*image).img,0,sizeof(float)*IMAGE_VOXELS);

    ListPosition=0;
    for (focus=0; focus<Nfoci; focus++) {
        if (IsFocusConcordant[focus]) {
            voxel = (*C).voxel[focus];
            XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
            xf=(*image).dx*xi - (*image).x0;
            yf=(*image).dy*yi - (*image).y0;
            zf=(*image).dz*zi - (*image).z0;

            Kernel=KernelEstimateAtCoordinate(C, xf, yf, zf, width, IsFocusConcordant);

            if (ListPosition<IMAGE_VOXELS) {
                (*image).img[voxel] = Kernel;
                ProcessedVoxelList[ListPosition] = voxel;
                ListPosition++;
            }
        }
    }



    LastInList=ListPosition;
    ListPosition=0;
    while (ListPosition<LastInList) {
        voxel=ProcessedVoxelList[ListPosition];
        XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
        for (c=-1; c<=1; c++) {
            for (b=-1; b<=1; b++) {
                for (a=-1; a<=1; a++) {
                    if ((a||b||c) && InImageRange(xi+a, yi+b, zi+c, (*image).X, (*image).Y, (*image).Z)) {
                        neighbour=voxel + a + b*(*image).X + c*(*image).X*(*image).Y;
                        if ((*image).img[neighbour]==0.0) {
                            xf=(*image).dx*(xi+a) - (*image).x0;
                            yf=(*image).dy*(yi+b) - (*image).y0;
                            zf=(*image).dz*(zi+c) - (*image).z0;
                            Kernel=KernelEstimateAtCoordinate(C, xf, yf, zf, width, IsFocusConcordant);

                            if (LastInList<IMAGE_VOXELS) {
                                if (Kernel<=0.0) {
                                    (*image).img[neighbour]=-1;
                                } else {
                                    ProcessedVoxelList[LastInList]=neighbour;
                                    (*image).img[neighbour]=Kernel;
                                    LastInList++;
                                }
                            }
                        }
                    }
                }
            }
        }
        ListPosition++;
    }


    for(voxel=0; voxel<IMAGE_VOXELS; voxel++) {
        if ((*image).img[voxel]<0.0)
            (*image).img[voxel]=0.0;
    }

END:
    if (ProcessedVoxelList)
        free(ProcessedVoxelList);

    return result;
}

//======================================================================================
int SaveRGBclustersKernelLOO(int FociVoxel[], short int cluster[],
                             short int study[], int Nfoci, struct Image *img,
                             int Nclusters, int Marker,
                             char directory[], char name[])
{
    struct Image RGBimg;
    int coordinate;
    int x_marker,y_marker,z_marker;
    int voxel;
    int IMAGE_VOXELS;
    int X,Y,Z,XY;
    int ThisFocusCluster;
    RGBQUAD rgb;
    int ColourLevels;
    int Marker2=Marker*Marker;

    X=(*img).X;
    Y=(*img).Y;
    Z=(*img).Z;
    XY=X*Y;
    IMAGE_VOXELS=X*Y*Z;

    ColourLevels = Nclusters/6+1;

    memset(&RGBimg,0,sizeof(struct Image));


    if (!(MakeCopyOfImage(img, &RGBimg)))
        goto END;

    memset(RGBimg.img,0,sizeof(float)*IMAGE_VOXELS);

    for (coordinate=0; coordinate<Nfoci; coordinate++) {
        if ((ThisFocusCluster=cluster[coordinate])>0 && ThisFocusCluster<=Nclusters) {

            for (z_marker=-Marker; z_marker<=Marker; z_marker++) {
                for (y_marker=-Marker; y_marker<=Marker; y_marker++) {
                    for (x_marker=-Marker; x_marker<=Marker; x_marker++) {

                        voxel = FociVoxel[coordinate] + x_marker + X*y_marker + XY*z_marker;
                        if ((voxel>=0) && (voxel<IMAGE_VOXELS)) {
                            if ( (x_marker*x_marker + y_marker*y_marker + z_marker*z_marker)<=Marker2  && !RGBimg.img[voxel]) {
                                rgb=Colours(ThisFocusCluster-1,ColourLevels);

                                memcpy(&RGBimg.img[voxel], &rgb, sizeof(float));
                            }
                        }
                    }
                }
            }
        }

    }

    RGBimg.DataType=DT_RGB;
    RGBimg.ImageType=NIFTI;
    sprintf(RGBimg.filename, "%s//%s.nii",  directory,name);
    Save(&RGBimg);

END:

    ReleaseImage(&RGBimg);


    return 1;
}
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
int KernelLOOfigures(HWND hwnd, struct Coordinates *Corg)
{
    double *dist2=NULL;
    struct Coordinates C;
    int Nfoci=(*Corg).TotalFoci;
    double width;
    int Neighbours;
    float *xc=NULL;
    float *yc=NULL;
    float *zc=NULL;


    if (!(xc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;
    if (!(yc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;
    if (!(zc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;



    memset(&C,0,sizeof(struct Coordinates));

    if (!CopyCoordinates(Corg, &C))
        goto END;

    if (!(dist2=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;

    CoordinateDistance2MatrixNoStudies(C.x, C.y, C.z, dist2, Nfoci, 1.0);

    /*
    	RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z,
    		                               gImage.dx, gImage.dy, gImage.dz,
    		                               gImage.x0, gImage.y0, gImage.z0,
    		                               C,10.0);
    */

    Neighbours=6;
    width=11;
    StoreDataQuick(hwnd, &gImage, &C, dist2, Neighbours, width, REPORT_FOLDER, xc, yc, zc,1);



END:
    if (dist2)
        free(dist2);

    FreeCoordinates(&C);

    if (xc)
        free(xc);

    if (yc)
        free(yc);

    if (zc)
        free(zc);

    return 0;
}
//======================================================================================
//======================================================================================
#define SAMPLEMVN 200
int TestDensity()
{
    double d2[SAMPLEMVN*SAMPLEMVN];
    double D[SAMPLEMVN];
    double score[20];
    int i,j,k;
    double x[SAMPLEMVN],y[SAMPLEMVN],z[SAMPLEMVN];
    int count[20];
    double d;
    FILE *fp;
    char fname[MAX_PATH];

    for (i=0; i<SAMPLEMVN; i++) {
        x[i] = GaussRandomNumber_BoxMuller(0,1.0);
        y[i] = GaussRandomNumber_BoxMuller(0,1.0);
        z[i] = GaussRandomNumber_BoxMuller(0,1.0);
    }

    for (i=0; i<SAMPLEMVN; i++) {
        for (j=0; j<SAMPLEMVN; j++) {
            d2[i*SAMPLEMVN+j]=(x[i] - x[j])*(x[i] - x[j])+
                              (y[i] - y[j])*(y[i] - y[j])+
                              (z[i] - z[j])*(z[i] - z[j]);
        }
    }



    k=0;
    memset(count,0,sizeof(int)*20);
    memset(score,0,20*sizeof(double));
    for (d=0.0; d<2.0; d+=0.1) {
        memset(D,0,SAMPLEMVN*sizeof(double));
        for (i=0; i<SAMPLEMVN; i++) {
            for (j=0; j<SAMPLEMVN; j++) {
                if (i!=j && d2[i*SAMPLEMVN+j]<d*d) {
                    D[i] += KernelCBMA(sqrt(d2[i*SAMPLEMVN+j]), d, KERNEL_TYPE);
                }
            }
        }


        for (i=0; i<SAMPLEMVN; i++) {
            for (j=0; j<SAMPLEMVN; j++) {
                if (i!=j && d2[i*SAMPLEMVN+j]<d*d) {
                    count[k]++;
                    score[k]+=D[i];
                }
            }
        }
        k++;
    }

    sprintf(fname,"%s//density.csv",REPORT_FOLDER);
    if ((fp=fopen(fname,"w"))) {

        for (i=0; i<20; i++) {
            fprintf(fp,"%f,%f,%d\n",0.1*i,score[i],count[i]);
        }
        fclose(fp);
    }

    return 0;
}
//======================================================================================
int ReportClustersCVCA(float x[], float y[], float z[], float Zsc[], short int ClusterLabel[], int Nfoci,
                       short int ThisFocusStudy[], int Nexperiments,
                       struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                       char directory[],
                       int X, int Y, int Z, float z0,
                       float dx, float dy, float dz,
                       float xc[], float yc[], float zc[], int Nclusters, int MinStudiesPerCluster)
{
    char fname[MAX_PATH];
    FILE *fp;
    int cluster;
    int *StudiesInClusterCount=NULL;      //how many experiments contribute to the clusters
    int foci, study, FoundContributorToCluster;
    int xi,yi,zi;
    float xf,yf,zf;
    char *TalairachLabels=NULL;
    char *b=NULL;
    int NumberOfTalairachLabels,Nl;
    struct Image Talairach;
    char shortlabel[256];

    memset(&Talairach,0,sizeof(struct Image));

//LOAD THE TALAIRACH DATA
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    if (!LoadFromFileName(NULL, fname, &Talairach, 0)) {
        MessageBox(NULL,"Failed to load Talairach","",MB_OK);
    }
    TalairachLabels=LoadTalairachLabels(&Nl);
    if (!TalairachLabels) {
        MessageBox(NULL,"Failed to load Talairach labels","",MB_OK);
    }
    NumberOfTalairachLabels=BiggestTalairachLabel(TalairachLabels, Nl);
    RemoveNonGM(&Talairach, TalairachLabels, Nl,NumberOfTalairachLabels);



//count the number of significant studies contributing to each cluster
    if (!(StudiesInClusterCount=(int *)malloc((Nclusters+1)*sizeof(int))))
        goto END;


    memset(StudiesInClusterCount,0,(Nclusters+1)*sizeof(int));
    for (cluster=1; cluster<=Nclusters; cluster++) {
        for (study=0; study<Nexperiments; study++) {
            FoundContributorToCluster=0;
            for (foci=0; foci<Nfoci; foci++) {
                if ((ThisFocusStudy[foci] == study) && (ClusterLabel[foci] == cluster))
                    FoundContributorToCluster=1;
            }
            if (FoundContributorToCluster)
                StudiesInClusterCount[cluster]++;
        }
    }



    sprintf(fname,"%s\\ClusterReport.csv",directory);
    if ((fp=fopen(fname,"w"))) {

        fprintf(fp,"Number of foci, %d\n", Nfoci);
        fprintf(fp,"Number of studies, %d\n", Nexperiments);
        fprintf(fp,"Min Studies Per Cluster, %d\n", MinStudiesPerCluster);
        fprintf(fp,"Talairach report, , , , , Cluster{x y z},Number Of Studies,Slice,Studies,,,,,Nearest GM\n\n");
        for (cluster=1; cluster<=Nclusters; cluster++) {
            if (StudiesInClusterCount[cluster]) {

                if (fp)
                    fprintf(fp,"cluster %d\n",cluster);

                xf=xc[cluster-1];
                yf=yc[cluster-1];
                zf=zc[cluster-1];

                xi=(int)((xf+Talairach.x0)/Talairach.dx+0.5);
                yi=(int)((yf+Talairach.y0)/Talairach.dy+0.5);
                zi=(int)((zf+Talairach.z0)/Talairach.dz+0.5);
                if (TalairachLabels && Talairach.img) {

                    b=FindEntryInTalairachLabels(TalairachLabels, Nl, NearestGM(Talairach.img, Talairach.X, Talairach.Y, Talairach.Z, xi, yi, zi));
                    if (fp)
                        fprintf(fp,"%s,",&b[1]);
                }

                zi=(int)((zf+z0)/dz+0.5);
                if (fp)
                    fprintf(fp," (%5.1f  %5.1f  %5.1f),%d,%d,", xf, yf, zf,StudiesInClusterCount[cluster], zi);

                //list each experiment that contributes to this cluster
                //report the lowest p value for the experiment, and indicate if it is significant
                for (study=0; study<Nexperiments; study++) {
                    for (foci=0; foci<Nfoci; foci++) {
                        if ((ClusterLabel[foci]==cluster) && (ThisFocusStudy[foci] == study)) {

                            if (fp)
                                fprintf(fp,"%s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
                                        StudyID[ThisFocusStudy[foci]].txt,
                                        ctrst[ThisFocusStudy[foci]].txt,
                                        cnd[ThisFocusStudy[foci]].txt,
                                        x[foci],y[foci],z[foci],Zsc[foci]);

                            if (TalairachLabels && Talairach.img) {
                                xi=(int)((x[foci]+Talairach.x0)/Talairach.dx+0.5);
                                yi=(int)((y[foci]+Talairach.y0)/Talairach.dy+0.5);
                                zi=(int)((z[foci]+Talairach.z0)/Talairach.dz+0.5);
                                b=FindEntryInTalairachLabels(TalairachLabels, Nl, NearestGM(Talairach.img, Talairach.X, Talairach.Y, Talairach.Z, xi, yi, zi));
                                ShortTalairachLabel(b, shortlabel, ".");
                                if (fp)
                                    fprintf(fp,"%s\n , , , , ,  , , ,",shortlabel);
                            }
                        }
                    }

                }

                if (fp)
                    fprintf(fp,"\n");
            }
        }
        fclose(fp);
    }


END:
    if (TalairachLabels)
        free(TalairachLabels);

    if (StudiesInClusterCount)
        free(StudiesInClusterCount);

    ReleaseImage(&Talairach);

    return Nclusters;
}

//======================================================================================
//======================================================================================================
int SaveReportedStructuresCVCA(struct Coordinates *C, char directory[], short int *concordant)
{
    char fname[MAX_PATH];
    sprintf(fname,"%s//Reported Structures.csv",directory);

    return SaveReportedStructuresCVCAfilename(C, fname, concordant);
}
int SaveReportedStructuresCVCAfilename(struct Coordinates *C, char fname[], short int *concordant)
{
    struct Image TalImg;
    int result=0;
    char *TalairachLabels=NULL;
    char *b;
    int LengthLabels;
    int NumberOfTalairachLabels;
    int study;
    int focus;
    int label;
    char Talfilename[MAX_PATH];
    char shortlabel[256];
    short int *LabeIsReported=NULL;
    short int *TotalLabelsReported=NULL;
    short int *StudiesWithTalairachLabel=NULL;
    struct ThreeVector *StructureCentroid=NULL;
    FILE *fp;

    memset(&TalImg,0,sizeof(struct Image));
    sprintf(Talfilename,"%s\\Talairach\\talGMmerged.nii", ExecutableDirectory);
    if (!LoadFromFileName(NULL, Talfilename, &TalImg, 0)) {
        MessageBox(NULL,"Not available without downloading the Talairach image file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    TalairachLabels=LoadTalairachLabels(&LengthLabels);
    if (LengthLabels<=0) {
        MessageBox(NULL,"Not available without downloading the Talairach labels file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    NumberOfTalairachLabels=BiggestTalairachLabel(TalairachLabels, LengthLabels);

    GetTalairachLabelsEx(C, &TalImg);

    if (!(LabeIsReported=(short int *)malloc(sizeof(short int)*(NumberOfTalairachLabels+1))))
        goto END;
    if (!(TotalLabelsReported=(short int *)malloc(sizeof(short int)*(NumberOfTalairachLabels+1))))
        goto END;
    if (!(StudiesWithTalairachLabel=(short int *)malloc(sizeof(short int)*(NumberOfTalairachLabels+1))))
        goto END;
    if (!(StructureCentroid=(struct ThreeVector *)malloc(sizeof(struct ThreeVector)*(NumberOfTalairachLabels+1))))
        goto END;

    memset(StudiesWithTalairachLabel,0,sizeof(short int)*(NumberOfTalairachLabels+1));
    memset(StructureCentroid,0,sizeof(struct ThreeVector)*(NumberOfTalairachLabels+1));
    memset(TotalLabelsReported,0,sizeof(short int)*(NumberOfTalairachLabels+1));
    for (study=0; study<(*C).Nexperiments; study++) {
        memset(LabeIsReported,0,sizeof(short int)*(NumberOfTalairachLabels+1));
        for (focus=0; focus<(*C).TotalFoci; focus++) {
            if (concordant[focus] && (*C).experiment[focus]==study)
            {
                label=(*C).TalLabel[focus];
                LabeIsReported[label]++;
                TotalLabelsReported[label]++;
                StructureCentroid[label].x+=(*C).x[focus];
                StructureCentroid[label].y+=(*C).y[focus];
                StructureCentroid[label].z+=(*C).z[focus];
            }

        }
        for (label=0; label<=NumberOfTalairachLabels; label++) {
            if (LabeIsReported[label])
            {
                StudiesWithTalairachLabel[label]++;
            }
        }
    }
    for (label=0; label<=NumberOfTalairachLabels; label++) {
            if (TotalLabelsReported[label])
            {
                StructureCentroid[label].x/=TotalLabelsReported[label];
                StructureCentroid[label].y/=TotalLabelsReported[label];
                StructureCentroid[label].z/=TotalLabelsReported[label];
            }
    }

    if ( (fp=fopen(fname,"w")) ) {
        fprintf(fp,"Talairach,,,,,,Proportion reporting, Number reporting, x, y, z\n");
        for (label=0; label<=NumberOfTalairachLabels; label++) {
            if (StudiesWithTalairachLabel[label]) {
                b=FindEntryInTalairachLabels(TalairachLabels, LengthLabels, label);
                ShortTalairachLabel(b, shortlabel, ".");
                fprintf(fp,"%s,%s,%f,%d,%f,%f,%f\n",&b[1],shortlabel,(double)StudiesWithTalairachLabel[label]/(*C).Nexperiments,
                                                            StudiesWithTalairachLabel[label], StructureCentroid[label].x,StructureCentroid[label].y,StructureCentroid[label].z);
            }
        }

        fclose(fp);
    }

    result=1;
END:
    ReleaseImage(&TalImg);
    if (LabeIsReported)
        free(LabeIsReported);

    if (TotalLabelsReported)
        free(TotalLabelsReported);

    if (StudiesWithTalairachLabel)
        free(StudiesWithTalairachLabel);

    if (TalairachLabels)
        free(TalairachLabels);

    if (StructureCentroid)
        free(StructureCentroid);

    return result;
}






//======================================================================================
double GetConnections(short int ThisFocusCluster[], double CoConnectionCounts[], short int study[], int NumberOfFoci, int NumberOfStudies, int NumberOfClusters, int LeaveOutStudy)
{
    int cluster1,cluster2;
    int focus1,focus2;
    double MaxCoConnections=0;

    memset(CoConnectionCounts,0,NumberOfClusters*NumberOfClusters*sizeof(double));

    for (focus1=0; focus1<NumberOfFoci; focus1++) {
        cluster1=ThisFocusCluster[focus1];
        if ( cluster1>0 && cluster1<=NumberOfClusters && study[focus1]!=LeaveOutStudy ) {
            for (focus2=0; focus2<NumberOfFoci; focus2++) {
                cluster2=ThisFocusCluster[focus2];
                if ( cluster2>0 && cluster2<=NumberOfClusters  && study[focus2]!=LeaveOutStudy ) {
                    if ( (cluster1 != cluster2) && (study[focus1] == study[focus2]) ) {
                        CoConnectionCounts[(cluster1-1)*NumberOfClusters + cluster2-1] += 1.0;

                        if (CoConnectionCounts[(cluster1-1)*NumberOfClusters + cluster2-1]>MaxCoConnections)
                            MaxCoConnections=CoConnectionCounts[(cluster1-1)*NumberOfClusters + cluster2-1];
                    }
                }
            }
        }
    }

    return MaxCoConnections;
}
//======================================================================================
//===============================================================================================
//======================================================================================
//======================================================================================
/*
Use leave one out to optimise a threshold on connectivities between clusters
*/
double GetLeaveOneOutConnectionScore(struct Coordinates *C, double *Connections, double minconnections, int Nclusters, int LeaveOut);
int ClusterConnectionsLeaveOneOut(HWND hwnd, struct Coordinates *C,
                                  float xc[], float yc[], float zc[],
                                  int NumberOfClusters, char directory[])
{

    int focus;
    int NumberOfFoci=(*C).TotalFoci;
    int NumberOfStudies=(*C).Nexperiments;
    int LeaveOut;
    double *ConnectionsMatrix=NULL;
    double minconnection, bestmin;
    double score, bestscore;
    int cluster,cl1,cl2;
    int *IsClusterConnected=NULL;
    FILE *fp=NULL;
    char fname[MAX_PATH];

    sprintf(fname,"%s//minconnections.csv",directory);
    fp=fopen(fname,"w");

    //is a cluster significant
    if (!(IsClusterConnected=(int *)calloc(NumberOfClusters,sizeof(int))))
        goto END;

    //the observed connections between clusters
    if (!(ConnectionsMatrix=(double *)calloc(NumberOfClusters*NumberOfClusters,sizeof(double))))
        goto END;

    bestscore=0.0;
    for (minconnection=1.0; minconnection<=NumberOfStudies; minconnection+=1.0) {

        score=0.0;
        for (LeaveOut=0; LeaveOut<NumberOfStudies; LeaveOut++) {
            GetConnections((*C).cluster, ConnectionsMatrix, (*C).experiment, NumberOfFoci, NumberOfStudies, NumberOfClusters,LeaveOut);
            score += GetLeaveOneOutConnectionScore(C, ConnectionsMatrix, minconnection, NumberOfClusters, LeaveOut);
        }

        if (score>bestscore) {
            bestscore=score;
            bestmin=minconnection;
        }

        if (fp) {
            fprintf(fp,"%f,%f,%f\n",minconnection,score,bestscore);
        }
    }

    GetConnections((*C).cluster, ConnectionsMatrix, (*C).experiment, NumberOfFoci, NumberOfStudies, NumberOfClusters,-1);


    for (cl1=0; cl1<NumberOfClusters; cl1++) {
        for (cl2=cl1+1; cl2<NumberOfClusters; cl2++) {
            if (ConnectionsMatrix[cl1 + cl2*NumberOfClusters]>=bestmin) {
                IsClusterConnected[cl1]=1;
                IsClusterConnected[cl2]=1;
            } else {
                ConnectionsMatrix[cl1 + cl2*NumberOfClusters]=0;
                ConnectionsMatrix[cl2 + cl1*NumberOfClusters]=0;
            }
        }
    }


    //get rid of non significant clusters
    for (focus=0; focus<NumberOfFoci; focus++) {
        cluster=(*C).cluster[focus];
        if (cluster && !IsClusterConnected[cluster-1])
            (*C).cluster[focus]=0;
    }


    SaveRGBclustersKernelLOO((*C).voxel, (*C).cluster, (*C).experiment, (*C).TotalFoci, &gImage, NumberOfClusters, 3, directory, "LeaveOneOutConnectionsRGB");


    SaveTalairachNetworkProjectionCVCA(hwnd,
                                       C,
                                       ConnectionsMatrix,
                                       xc, yc, zc,
                                       NumberOfClusters,
                                       directory, "NetworkLOO.bmp");


END:
    if (ConnectionsMatrix)
        free(ConnectionsMatrix);

    if (IsClusterConnected)
        free(IsClusterConnected);

    if (fp)
        fclose(fp);

    return NumberOfClusters;
}
//======================================================================================
double GetLeaveOneOutConnectionScore(struct Coordinates *C, double *ConnectionsBetweenClusters, double MinimumConnectionsBetweenClusters, int Nclusters, int LeaveOut)
{
    double score=0.0;
    int focus1,focus2;
    int cluster1,cluster2;
    int NumberOfFoci=(*C).TotalFoci;
    int NumberOfClustersInLeaveOutStudy=0;
    int *ClusterInLeaveOutStudy=NULL;

    if (!(ClusterInLeaveOutStudy=(int *)calloc(Nclusters+1,sizeof(int))))
        goto END;


    for (focus1=0; focus1<NumberOfFoci; focus1++) {
        if ((*C).experiment[focus1]==LeaveOut && (cluster1=(*C).cluster[focus1])) {
            for (focus2=0; focus2<NumberOfFoci; focus2++) {
                if (focus1!=focus2 && (*C).experiment[focus2]==LeaveOut && (cluster2=(*C).cluster[focus2])) {
                    if (cluster1!=cluster2 && ConnectionsBetweenClusters[(cluster1-1) + (cluster2-1)*Nclusters]>=MinimumConnectionsBetweenClusters) {
                        score += MinimumConnectionsBetweenClusters;
                        if (!ClusterInLeaveOutStudy[cluster1]) {
                            ClusterInLeaveOutStudy[cluster1]=1;
                            NumberOfClustersInLeaveOutStudy++;
                        }
                    }
                }
            }
        }

    }
    if (NumberOfClustersInLeaveOutStudy)
        score /= NumberOfClustersInLeaveOutStudy;



END:
    if (ClusterInLeaveOutStudy)
        free(ClusterInLeaveOutStudy);

    return score;
}
//======================================================================================
int PermuteClusters(short int OriginalClusters[], short int PermutedClusters[],
                    short int StudyThisFocus[], int NumberOfStudies, int NumberOfClusters, int NumberOfFoci)
{
    int *ClusterDistribution=NULL;
    int *ClusterAlreadyInStudy=NULL;
    int focus;
    int RandomCluster;
    int PeakOfDistribution;
    int study;
    double UniformRandomNumber;

    memset(PermutedClusters,0,NumberOfFoci*sizeof(short int));

    if (!(ClusterDistribution=(int *)calloc(NumberOfClusters+1, sizeof(int))))
        goto END;
    if (!(ClusterAlreadyInStudy=(int *)malloc((NumberOfClusters+1)*sizeof(int))))
        goto END;

    PeakOfDistribution=0;
    for (focus=0; focus<NumberOfFoci; focus++) {
        if (OriginalClusters[focus]) {
            ClusterDistribution[OriginalClusters[focus]]++;
            if (ClusterDistribution[OriginalClusters[focus]]>PeakOfDistribution) {
                PeakOfDistribution=ClusterDistribution[OriginalClusters[focus]];
            }
        }
    }

    for (study=0; study<NumberOfStudies; study++) {
        memset(ClusterAlreadyInStudy,0,(NumberOfClusters+1)*sizeof(int));
        for (focus=0; focus<NumberOfFoci; focus++) {
            if (StudyThisFocus[focus]==study && OriginalClusters[focus]) {
                do {
                    UniformRandomNumber=(double)rand()/RAND_MAX;
                    RandomCluster=rand()%NumberOfClusters+1;
                } while(ClusterAlreadyInStudy[RandomCluster] &&
                        (double)ClusterDistribution[RandomCluster]/PeakOfDistribution>UniformRandomNumber);
                ClusterAlreadyInStudy[RandomCluster]=1;
                PermutedClusters[focus]=RandomCluster;
            }
        }
    }

END:

    if (ClusterDistribution)
        free(ClusterDistribution);

    if (ClusterAlreadyInStudy)
        free(ClusterAlreadyInStudy);

    return 0;
}
//======================================================================================
int AugmentClusters(struct Coordinates *C, short int augmented[], double dist2[], double width2, int NumberOfClusters, float xc[], float yc[], float zc[])
{
    int NumberOfFoci=(*C).TotalFoci;
    int NumberOfStudies=(*C).Nexperiments;
    double *DistanceToClusterCentre=NULL;
    int *BestFocusInStudyForCluster=NULL;
    int focus, focus2;
    int cluster,study;
    int NearestCluster;
    int i;
    double MinSquaredDistance,dc2;
    int NumberAugmented=0;

    //find the studies contributing to each cluster
    if (!(DistanceToClusterCentre=(double *)malloc((NumberOfClusters+1)*NumberOfStudies*sizeof(double))))
        goto END;

    //best focus from each study contributing to cluster
    if (!(BestFocusInStudyForCluster=(int *)malloc((NumberOfClusters+1)*NumberOfStudies*sizeof(int))))
        goto END;

    //default distance
    for (i=0; i<(NumberOfClusters+1)*NumberOfStudies; i++) {
        DistanceToClusterCentre[i]=DBL_MAX;
        BestFocusInStudyForCluster[i]=-1;//default to no focus
    }

    //enter the foci already contributing to the clusters
    for (focus=0; focus<NumberOfFoci; focus++) {
        if ((*C).cluster[focus]) {
            DistanceToClusterCentre[(*C).experiment[focus] + (*C).cluster[focus]*NumberOfStudies]=0.0;//this experiment already in cluster
            BestFocusInStudyForCluster[(*C).experiment[focus] + (*C).cluster[focus]*NumberOfStudies]=focus;
        }
    }




    for (focus=0; focus<NumberOfFoci; focus++) {
        if (!(*C).cluster[focus]) {

            MinSquaredDistance=DBL_MAX;
            NearestCluster=0;
            for (focus2=0; focus2<NumberOfFoci; focus2++) {
                if ((*C).cluster[focus2]) {
                    if (dist2[focus2 + focus*NumberOfFoci]<MinSquaredDistance) {
                        MinSquaredDistance=dist2[focus2 + focus*NumberOfFoci];
                        NearestCluster=(*C).cluster[focus2];
                    }
                }
            }

            if (NearestCluster && MinSquaredDistance<width2) {

                dc2=((*C).x[focus] - xc[NearestCluster-1])*((*C).x[focus] - xc[NearestCluster-1]) +
                    ((*C).y[focus] - yc[NearestCluster-1])*((*C).y[focus] - yc[NearestCluster-1]) +
                    ((*C).z[focus] - zc[NearestCluster-1])*((*C).z[focus] - zc[NearestCluster-1]);


                if (dc2<DistanceToClusterCentre[(*C).experiment[focus] + NearestCluster*NumberOfStudies]) {
                    BestFocusInStudyForCluster[(*C).experiment[focus]+ NearestCluster*NumberOfStudies] = focus;
                    DistanceToClusterCentre[(*C).experiment[focus] + NearestCluster*NumberOfStudies]=dc2;
                }
            }

        }
    }



    memset(augmented, 0, sizeof(short int)*NumberOfFoci);
    for (study=0; study<NumberOfStudies; study++) {
        for (cluster=1; cluster<=NumberOfClusters; cluster++) {
            if (BestFocusInStudyForCluster[study + cluster*NumberOfStudies]>0) {
                augmented[ BestFocusInStudyForCluster[study + cluster*NumberOfStudies] ]=cluster;
                if (!(*C).cluster[BestFocusInStudyForCluster[study + cluster*NumberOfStudies]])
                    NumberAugmented++;
            }
        }
    }


END:
    if (DistanceToClusterCentre)
        free(DistanceToClusterCentre);

    if (BestFocusInStudyForCluster)
        free(BestFocusInStudyForCluster);


    return NumberAugmented;
}
//======================================================================================
//======================================================================================
//==============================================================================================
int SaveTalairachNetworkProjectionCVCA(HWND hwndMain,
                                       struct Coordinates *Co,
                                       double Connections[],
                                       float xp[],float yp[], float zp[],
                                       int Nclusters,
                                       char directory[], char name[])
{

    int del=24;//size of the circles projected
    int penwidth;
    int x,y, x1, y1;
    int cluster, cl;
    int ColourLevels;
    int fontwidth=18;
    int fontheight=20;
    int draw;
    float red,blue;
    TEXTMETRIC tm;
    RECT r;
    BITMAPFILEHEADER BmFileHdr;
    BITMAPINFOHEADER BmInfoHdr;
    unsigned char  *pBits ;
    HBITMAP hBitmap, hOldObj;
    int width,height, pixels;
    HDC hDC=GetDC(hwndMain);
    HDC chDC=CreateCompatibleDC(hDC);
    RGBQUAD rgb,c;
    HBRUSH hBrush, hOldBrush;
    HPEN hPen, hOldPen;
    HFONT hOldFont, hFont = CreateFont(fontheight,fontwidth,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
                                       CLIP_DEFAULT_PRECIS, 0, VARIABLE_PITCH,TEXT("Verdana"));
    char txt[256];
    FILE *fp;
    char fname[MAX_PATH];

    ColourLevels = Nclusters/6+1;

    //bitmap dimensions: two hemispheres above axial above coronal
    width=1000;
    height=1000;
    pixels=width*height;

    ///File header structure
    memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
    BmFileHdr.bfType=0x4D42;//=BM
    BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
    BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

    ///Bitmap info header
    memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
    BmInfoHdr.biWidth=width;
    BmInfoHdr.biHeight=height;
    BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
    BmInfoHdr.biPlanes=1;
    BmInfoHdr.biBitCount=24;
    BmInfoHdr.biCompression=BI_RGB;

    ///Create the DIB bitmap section
    hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
    hOldObj = SelectObject(chDC, hBitmap);


    ///draw the background overlay
    hBrush=CreateSolidBrush(RGB(255, 255, 255));
    hOldBrush = SelectObject(chDC, hBrush);
    r.left=0;
    r.bottom=0;
    r.right=width;
    r.top=height;
    FillRect(chDC, &r, hBrush);///white background
    SelectObject(chDC, hOldBrush);
    DeleteObject(hBrush);

    hBrush=CreateSolidBrush(RGB(255, 255, 255));
    hOldBrush = SelectObject(chDC, hBrush);
    hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
    hOldPen = SelectObject(chDC, hPen);

    ConvertTalairachToProjection(width, -1.0, 0.0, 0.0, &x, &y);
    ConvertTalairachToProjection(width, 0.0, -1.0, 0.0, &x1, &y1);
    Ellipse(chDC, x, y1, width/2 + (width/2-x), height/2 + (height/2-y1));///z=0 circle
    SelectObject(chDC, hOldBrush);
    DeleteObject(hBrush);
    SelectObject(chDC, hOldPen);
    DeleteObject(hPen);

    hPen=CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
    hOldPen = SelectObject(chDC, hPen);
    MoveToEx(chDC,width/2,0,NULL);
    LineTo(chDC,width/2,height);
    MoveToEx(chDC,0,height/2,NULL);///x=0, y=0 axis
    LineTo(chDC,width,height/2);
    SelectObject(chDC, hOldPen);
    DeleteObject(hPen);


    ///Draw connecting lines
    for (cluster=1; cluster<=Nclusters; cluster++) {
        for (cl=cluster+1; cl<=Nclusters; cl++) {



            if (Connections[cl-1+(cluster-1)*Nclusters]>0.0) {
                penwidth=(int)(Connections[cl-1 + (cluster-1)*Nclusters]);
            } else {
                penwidth=0;
            }
            if (penwidth>10)
                penwidth=10;

            red=255;
            blue=0;


            hPen=CreatePen(PS_SOLID, penwidth, RGB((unsigned char)red, 0, (unsigned char)blue));

            hOldPen = SelectObject(chDC, hPen);
            if (penwidth>0 && ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0) {
                if (ConvertTalairachToProjection(width, xp[cl-1], yp[cl-1], zp[cl-1], &x1, &y1)>=0) {
                    MoveToEx(chDC,x,y,NULL);
                    LineTo(chDC,x1,y1);
                }
            }
            SelectObject(chDC, hOldPen);
            DeleteObject(hPen);

        }

    }



    hOldFont=SelectObject(chDC, hFont);
    GetTextMetrics(chDC,&tm);
    SetBkMode(chDC, TRANSPARENT);
    SetTextColor(chDC,RGB(255, 255, 255));

    ///draw the nodes (clusters represented by circles)
    for (cluster=Nclusters; cluster>=1; cluster--) {
        draw=0;
        for (cl=1; cl<=Nclusters && !draw; cl++) {
            if (Connections[cl-1+(cluster-1)*Nclusters])
                draw=1;
        }

        if (draw) {
            rgb=Colours(cluster-1,ColourLevels);

            //draw the number in black or white, depending on the colour of the ellipse
            c.rgbRed=c.rgbBlue=c.rgbGreen=( (rgb.rgbRed+rgb.rgbBlue+rgb.rgbGreen)/3>128 )?0:255;

            SetTextColor(chDC,RGB(c.rgbRed, c.rgbGreen, c.rgbBlue));

            hBrush=CreateSolidBrush(RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
            hOldBrush = SelectObject(chDC, hBrush);
            hPen=CreatePen(PS_SOLID, 1, RGB(rgb.rgbRed, rgb.rgbGreen, rgb.rgbBlue));
            hOldPen = SelectObject(chDC, hPen);

            if (ConvertTalairachToProjection(width, xp[cluster-1], yp[cluster-1], zp[cluster-1], &x, &y)>=0) {
                Ellipse(chDC, x-del, y+del, x+del, y-del);
            }
            sprintf(txt,"%d",cluster);
            TextOut(chDC, x-tm.tmAveCharWidth*strlen(txt)/2-1, y-tm.tmHeight/2, txt,strlen(txt));

            SelectObject(chDC, hOldBrush);
            DeleteObject(hBrush);
            SelectObject(chDC, hOldPen);
            DeleteObject(hPen);
        }
    }
    SelectObject(chDC, hOldFont);
    DeleteObject(hFont);

    BitBlt(hDC, 0, 0, width, height, chDC, 0, 0, SRCCOPY);
    SelectObject(chDC, hOldObj);

    ///Now save the bitmap file
    sprintf(fname,"%s\\%s.bmp",directory,name);
    if ( (fp=fopen(fname,"wb")) ) {
        SaveRGBbitmapAs8bit(&BmFileHdr, &BmInfoHdr, pBits, pixels, width, height, fp);
        fclose(fp);
    }

    SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

    DeleteObject(hBitmap);
    ReleaseDC(hwndMain, hDC);
    DeleteDC(chDC);

    return 1;
}
//==================================================================================
