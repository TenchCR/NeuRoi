/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


/*
Sum over experiments the kernel estimate of the distribution of foci
Only the closest contributes
The LOO doesn't count
Choose width of kernel
Choose threshold by fraction landing where the distribution is zero
*/

#include "KernelLOO.h"




struct KernelMinimise
{
    double width;
    double *dist2;
    struct Coordinates *C;
    FILE *fp;
    int Neighbours;
    int ConcordantCount;//number of concordant foci, used to determine number of neighbours needed for concordance
};


int CVCA(struct Coordinates *Corg, int randomfocisamples);

int ReportClustersCVCA(float x[], float y[], float z[], float Zsc[], short int cluster[], int Nfoci,
                       short int exprmnt[], int Nexperiments,
                       struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                       char directory[],
                       int X, int Y, int Z, float z0,
                       float dx, float dy, float dz,
                       float xc[], float yc[], float zc[], int Nclusters, int MinStudiesPerCluster);

double MaxKernelLOOscore(struct Coordinates *C, struct KernelMinimise *KM);
double KernelLOO(double dist, double maxdist);
double GetKernelLOOScore(struct Coordinates *C, double dist2[], double width);
double GetKernelScoreLOO(struct Coordinates *C, double dist2[], double width, int Neighbours, int *ConcordantCount);
double KernelMinimiseFunction(double *width, int N, void *KernelMin);
double KernelEstimateAtCoordinate(struct Coordinates *C, float x, float y, float z, double width, short int valid[]);
int StoreImageQuick(struct Image *image, struct Coordinates *C, double dist2[], int Neighbours, double width, char directory[], float xc[], float yc[], float zc[], int marker);
int DensityImage(struct Image *image, struct Coordinates *C, short int valid[], double width);
int SaveReportedStructuresCVCA(struct Coordinates *C, char directory[], short int *concordant);
//==========================================================================
//=============================================================================================
//                         CVCA dialog callback function
//=============================================================================================
INT_PTR CALLBACK CVCA_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    int MarkerSize;
    static char directory[MAX_PATH];
    static struct Coordinates C;
    static int randomfocisamples;
    char txt[256];

    switch (msg)
    {


    case WM_CLOSE:
        FreeCoordinates(&C);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hABC=(HWND)NULL;
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:
        //SET UP THE ROI OBJECT NUMBER SELECTION BOX
        MarkerSize=3;
        sprintf(txt,"%d",MarkerSize);
        SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_SETTEXT, 0, (LPARAM)txt);
        sprintf(txt,"%d",randomfocisamples);
        SendMessage(GetDlgItem(hwnd,ID_RANDOMISATIONS), WM_SETTEXT, 0, (LPARAM)txt);
        break;


    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        randomfocisamples=0;
        break;


    case WM_COMMAND:
        switch (LOWORD(wParam))
        {



        case ID_ADD_COORDINATE_FILE:
            memset(&C,0,sizeof(struct Coordinates));
            EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),FALSE);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &C, gImage.X,gImage.Y, gImage.Z,gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0))
            {

                ///merge studies and remove any duplicates as these are not independent evidence of effect and reduce sensitivity
                MergeCoordinatesbyStudy(&C);
                RemoveWithinStudyDuplicates(&C);

                CheckForCoordinateDuplication(&C,txt, directory);

                SendMessage(GetDlgItem(hwnd,ID_COORDINATE_FILES), WM_SETTEXT, 0, (LPARAM)C.coordinate_file_name);
            }
            else
            {
                MessageBox(hwnd,"Failed to add coordinate file","",MB_OK|MB_ICONWARNING);
            }
            EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),TRUE);
            break;



        case ID_RUN_CVCA_ANALYSIS:
            EnableWindow(GetDlgItem(hwnd,ID_RUN_CVCA_ANALYSIS),FALSE);
            EnableWindow(GetDlgItem(hwnd,IDOK),FALSE);
            EnableWindow(GetDlgItem(hwnd,ID_ADD_COORDINATE_FILE),FALSE);

            SendMessage(GetDlgItem(hwnd,ID_RANDOMISATIONS), WM_GETTEXT, 256, (LPARAM)txt);
            randomfocisamples=atoi(txt);

            SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
            MarkerSize=atoi(txt);

            CVCA(&C, randomfocisamples);

            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;
        }
        break;


    }
    return 0;
}


//==========================================================================
//==========================================================================
int CVCA(struct Coordinates *Corg, int randomfocisamples)
{
    struct KernelMinimise KM;
    struct Image Cpy;
    struct Coordinates C;
    int Nfoci=(*Corg).TotalFoci;
    int Nclusters;
    double *width=NULL;
    double *score=NULL;
    int *N=NULL;
    int loop;
    char txt[256];
    HDC hDC=GetDC(NULL);
    char fname[MAX_PATH];
    char directory[MAX_PATH], kerneldir[MAX_PATH];
    FILE *fp;
    int tmp;
    float *xc=NULL;
    float *yc=NULL;
    float *zc=NULL;

    //TestKernelShape();

    tmp=DirectoryFileDivide((*Corg).coordinate_file_name);
    sprintf(directory,"%s",(*Corg).coordinate_file_name);
    directory[tmp]='\0';
    sprintf(kerneldir,"%s\\kernel_LOO",directory);
    CreateDirectory(kerneldir, NULL);

    memset(&C,0,sizeof(struct Coordinates));
    memset(&Cpy, 0, sizeof(struct Image));
    memset(&KM,0,sizeof(struct KernelMinimise));

    if (!(width=(double *)malloc((randomfocisamples+1)*sizeof(double))))
        goto END;

    if (!(score=(double *)malloc((randomfocisamples+1)*sizeof(double))))
        goto END;

    if (!(N=(int *)malloc((randomfocisamples+1)*sizeof(int))))
        goto END;

    if (!(xc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!(yc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!(zc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;

    if (!CopyCoordinates(Corg,&C))
        goto END;

    if (!MakeCopyOfImage(&gImage, &Cpy))
        goto END;

    if (!(KM.dist2=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;

    /*
    	RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z,
    		                               gImage.dx, gImage.dy, gImage.dz,
    		                               gImage.x0, gImage.y0, gImage.z0,
    		                               C,10.0);
    */


    KM.C=&C;
    sprintf(fname,"%s//score.csv",kerneldir);
    if (!(KM.fp=fopen(fname,"w")))
        goto END;
/*
    ///TODO
    //figure for paper
    MaxKernelLOOscore(&C, &KM);
    Nclusters=StoreImageQuick(&Cpy, &C, KM.dist2, 4, 11.0, kerneldir, xc, yc, zc, 1);
    goto END;
*/

    for (loop=0; loop<=randomfocisamples; loop++)
    {
        score[loop] = MaxKernelLOOscore(&C, &KM);
        width[loop] = KM.width;
        N[loop] = KM.Neighbours;

        sprintf(txt,"loop:%d  Width:%f  Neighbours:%d",loop, width[loop], KM.Neighbours);
        if (hDC)
            TextOut(hDC,100,200,txt,strlen(txt));

        if (!loop)
        {
            Nclusters=StoreImageQuick(&Cpy, &C, KM.dist2, KM.Neighbours, KM.width, kerneldir, xc, yc, zc, 3);

            ReportClustersCVCA(C.x, C.y, C.z, C.Zsc, C.cluster, C.TotalFoci,
                               C.experiment, C.Nexperiments,
                               C.ID, C.CTRST, C.CND,
                               kerneldir,
                               gImage.X, gImage.Y, gImage.Z, gImage.z0,
                               gImage.dx, gImage.dy, gImage.dz,
                               xc, yc, zc, Nclusters, KM.Neighbours);
        }

        CopyCoordinates(Corg,&C);
        RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z,
                                       gImage.dx, gImage.dy, gImage.dz,
                                       gImage.x0, gImage.y0, gImage.z0,
                                       &C,10.0);

        if (KM.fp)
        {
            fclose(KM.fp);
            KM.fp=NULL;
        }
    }


    sprintf(fname,"%s//inference.csv",kerneldir);
    if (!(fp=fopen(fname,"w")))
        goto END;

    for (loop=0; loop<=randomfocisamples; loop++)
    {
        fprintf(fp,"%d,%f,%g,%d\n",loop,width[loop],score[loop],N[loop]);
    }
    fprintf(fp,",,=stdev(C2:C%d)\n",randomfocisamples+1);
    fprintf(fp,",,=average(C2:C%d)\n",randomfocisamples+1);
    fprintf(fp,",Z score=,=(C1-C%d)/C%d\n",randomfocisamples+2, randomfocisamples+1);

    fclose(fp);

END:
    if (KM.dist2)
        free(KM.dist2);

    if (xc)
        free(xc);
    if (yc)
        free(yc);
    if (zc)
        free(zc);

    if (width)
        free(width);

    if (score)
        free(score);

    if (N)
        free(N);

    ReleaseDC(NULL,hDC);

    ReleaseImage(&Cpy);

    FreeCoordinates(&C);

    return 0;
}

//==========================================================================
double MaxKernelLOOscore(struct Coordinates *C, struct KernelMinimise *KM)
{

    int Nfoci=(*C).TotalFoci;
    double width[1];
    double d[1];
    double current;
    double score;
    int bestneighbours;
    int bestcount;
    double bestwidth;
    double maxscore;

    (*KM).C=C;
    CoordinateDistance2MatrixNoStudies((*C).x, (*C).y, (*C).z, (*KM).dist2, Nfoci, 1.0);

    bestcount=0;
    bestneighbours=0;
    bestwidth=0.0;
    maxscore=0.0;
    for ((*KM).Neighbours=4; (*KM).Neighbours<10; (*KM).Neighbours++)
    {

        width[0]=3.1415;
        do
        {
            width[0] += 3.1415;
            current=KernelMinimiseFunction(width, 1, KM);
        }
        while (current==0.0 && width[0]<80.0);

        d[0]=3.1415;
        score=0.0;
        if (current<0.0)
            score = -GoldenSearch(width, d, 1, current, KernelMinimiseFunction, KM, 5);

        if (bestwidth==0.0 ||score>=maxscore)
        {
            maxscore=score;
            bestwidth=width[0];
            bestneighbours=(*KM).Neighbours;
            bestcount=(*KM).ConcordantCount;
        }
    }

    //save results in KM
    (*KM).width=bestwidth;
    (*KM).Neighbours=bestneighbours;
    (*KM).ConcordantCount=bestcount;

    return maxscore;

}
//==========================================================================
double KernelMinimiseFunction(double *width, int N, void *KernelMin)
{
    double score=0.0;
    struct KernelMinimise *KM=(struct KernelMinimise *)KernelMin;

    score = GetKernelScoreLOO((*KM).C, (*KM).dist2, *width, (*KM).Neighbours, &(*KM).ConcordantCount);

    if ((*KM).fp)
    {
        fprintf((*KM).fp, "%d,%f,%f,%d\n",(*KM).Neighbours, (*width), score, (*KM).ConcordantCount);
    }

    return -score;
}
//==========================================================================
int ConcordantCoordinates(int Nfoci, int Nstudies, double dist2[], short int study[], double width, short int concordant[], int Neighbours, int LeaveOut);
double ThisStudyDensity(int Nfoci, int LOstudy, short int study[], int Nstudies,
                        int LeaveOut, double dist2[], double width, int Neighbours,
                        short int concordant[]);
double GetKernelScoreLOO(struct Coordinates *C, double dist2[], double width, int Neighbours, int *ConcordantCount)
{

    double score=0.0;
    int Nfoci=(*C).TotalFoci;
    int Nstudies=(*C).Nexperiments;
    int LeaveOut;
    short int *concordant=NULL;
    char *used=NULL;

    *ConcordantCount=0;

    if (!(concordant=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;

    if (!(used=(char *)malloc(Nfoci*sizeof(char))))
        goto END;

    if (width<=0.0)
        return 0.0;

    //the density for each focus when one study is left out
    //the density is zero if no focus is concordant
    for (LeaveOut=0; LeaveOut<Nstudies; LeaveOut++)
    {
        memset(used,0,Nfoci*sizeof(char));
        *ConcordantCount += ConcordantCoordinates(Nfoci, Nstudies, dist2, (*C).experiment, width, concordant, Neighbours, LeaveOut);

        score += ThisStudyDensity(Nfoci, LeaveOut, (*C).experiment, Nstudies, LeaveOut, dist2,  width, Neighbours, concordant);
    }


END:
    if (concordant)
        free(concordant);

    if (used)
        free(used);

    return score/pow(width,3.0);
}
//==========================================================================
//==========================================================================
//================================================================================
double ThisStudyDensity(int Nfoci, int LOstudy, short int study[], int Nstudies,
                        int LeaveOut, double dist2[], double width, int Neighbours,
                        short int concordant[])
{
    int oset;
    int coordinate;
    int LOfocus;
    int st;
    int LOOfoci;
    int *StudyFocus=NULL;
    int *N=NULL;
    double width2=width*width;
    double *K=NULL;
    double score=0.0;//default score
    double tmp;
    double *sum=NULL;

    if (!(sum=(double *)calloc(Nfoci,sizeof(double))))
        goto END;

    if (!(N=(int *)calloc(Nfoci, sizeof(int))))
        goto END;

    if (!(K=(double *)malloc(Nstudies*sizeof(double))))
        goto END;

    if (!(StudyFocus=(int *)calloc(Nstudies, sizeof(int))))
        goto END;

    LOOfoci=0;
    for (LOfocus=0; LOfocus<Nfoci; LOfocus++)
    {
        if (study[LOfocus]==LOstudy)
        {
            LOOfoci++;// the number of foci in this study
            oset=LOfocus*Nfoci;
            memset(K,0,Nstudies*sizeof(double));
            for (coordinate=0; coordinate<Nfoci; coordinate++)
            {
                st=study[coordinate];
                if (concordant[coordinate] && st!=LeaveOut && dist2[oset+coordinate]<width2)
                {
                    tmp=KernelCBMA(sqrt( dist2[oset+coordinate] ), width, KERNEL_TYPE);
                    if (tmp>K[st])
                    {
                        K[st] = tmp;
                        StudyFocus[st] = coordinate;
                    }
                }
            }
            for (st=0; st<Nstudies; st++)
            {
                if (K[st]>0.0)
                {
                    //sum[StudyFocus[st]] += K[st]*sqrt((double)concordant[StudyFocus[st]]);
                    sum[StudyFocus[st]] += K[st];
                    N[StudyFocus[st]] ++;
                }
            }
        }
    }

    //if there is at least one concordant coordinate contributing, sum the kernels
    for (coordinate=0; coordinate<Nfoci; coordinate++)
    {
        if (N[coordinate])
        {
            score+=sum[coordinate]/N[coordinate];
        }
    }

    ///ALTERNATE SCORE DIVIDES BY NUMBER OF FOCI IN LEFT OUT STUDY
    //if (LOOfoci)
    //    score /= LOOfoci;


END:
    if (K)
        free(K);

    if (StudyFocus)
        free(StudyFocus);

    if (sum)
        free(sum);

    if (N)
        free(N);

    return score;
}
//================================================================================
//================================================================================
/*
This function considers validity of all foci not in the LeaveOut study; Set LeaveOut to -1 (for example) for validity of all foci
The coordinates that are within width of each focus, unless they are from the LeaveOut study, are found
If they are from at least Neighbours independent studies, the focus is considered valid
Otherwise it is not valid
*/
int ConcordantCoordinates(int Nfoci, int Nstudies, double dist2[], short int study[], double width, short int concordant[], int Neighbours, int LeaveOut)
{
    int Nconcordant=0;
    int focus;
    int i;
    int index;
    int count;
    int *hit=NULL;
    double width2=width*width;

    memset(concordant,0,Nfoci*sizeof(short int));

    if (!(hit=(int *)malloc(Nstudies*sizeof(int))))
        goto END;

    for (focus=0; focus<Nfoci; focus++)
    {
        if (study[focus] != LeaveOut)
        {
            memset(hit,0,Nstudies*sizeof(int));
            index=focus*Nfoci;
            count=1;
            for (i=0; i<Nfoci; i++)
            {
                if (study[i]!=study[focus] && study[i]!=LeaveOut && !hit[study[i]])
                {
                    if (dist2[index+i]<width2)
                    {
                        count++;
                        hit[study[i]]=1;
                    }
                }
            }
            if (count>=Neighbours)
            {
                concordant[focus]=count;
                Nconcordant++;
            }
        }
    }

END:
    if (hit)
        free(hit);

    return Nconcordant;
}
//======================================================================================
//==========================================================================
double KernelEstimateAtCoordinate(struct Coordinates *C, float x, float y, float z, double width, short int valid[])
{
    int Nfoci=(*C).TotalFoci;
    int Nstudies=(*C).Nexperiments;
    int focus;
    int study;
    double dist2;
    float *K=NULL;
    double SumK=0.0;
    double tmp;

    if (!(K=(float *)calloc(Nstudies, sizeof(float))))
        goto END;

    for (focus=0; focus<Nfoci; focus++)
    {
        if (valid[focus])
        {

            study=(*C).experiment[focus];

            dist2=(x-(*C).x[focus])*(x-(*C).x[focus]) +
                  (y-(*C).y[focus])*(y-(*C).y[focus]) +
                  (z-(*C).z[focus])*(z-(*C).z[focus]);

            tmp=KernelCBMA(sqrt( dist2 ), width, KERNEL_TYPE);

            if (tmp>K[study])
                K[study]=tmp;

        }

    }

    for (study=0; study<Nstudies; study++)
    {
        SumK += K[study];
    }

END:
    if (K)
        free(K);

    return SumK;

}
//======================================================================================
int SaveRGBclustersKernelLOO(int FociVoxel[], short int cluster[], float xf[], float yf[], float zf[],
                             short int study[], int Nfoci, struct Image *img,
                             int Nclusters, int Marker,
                             char directory[]);
int StoreImageQuick(struct Image *image, struct Coordinates *C, double dist2[], int Neighbours, double width, char directory[],
                    float xc[], float yc[], float zc[], int marker)
{

    int VOXELS=(*image).X*(*image).Y*(*image).Z;
    int Nfoci=(*C).TotalFoci;
    int focus,focus2;
    int Nclusters=0;
    int count,maxcount;
    int offset;
    struct Image Cpy, density;
    short int *valid=NULL;
    double smooth, bestsmooth;
    double width2=width*width;
    char fname[MAX_PATH];
    FILE *fp;

    sprintf(fname,"%s//kernel",directory);

    if (!(valid=(short int *)malloc(Nfoci*sizeof(short int))))
        goto END;


    ConcordantCoordinates(Nfoci, (*C).Nexperiments, dist2, (*C).experiment, width, valid, Neighbours, -1);

    //connection matrix based on width
    CoordinateDistance2Matrix((*C).x, (*C).y, (*C).z, (*C).experiment, dist2, Nfoci);
    for (focus=0;focus<Nfoci;focus++)
    {
        offset=Nfoci*focus;
        for (focus2=0;focus2<Nfoci;focus2++)
        {
            if (dist2[offset+focus2]>width2) dist2[offset+focus2]=0.0;
            else dist2[offset+focus2]=1.0;
        }
    }



    memset (&Cpy,0,sizeof(struct Image));
    if (!MakeCopyOfImage(image, &Cpy))
        goto END;
    memset (&density,0,sizeof(struct Image));
    if (!MakeCopyOfImage(image, &density))
        goto END;

    memset(Cpy.img,0,sizeof(float)*VOXELS);


    DensityImage(&Cpy, C,  valid, width);

    if ((*image).ImageType==HDR)
        sprintf(Cpy.filename,"%s.img",fname);
    else
        sprintf(Cpy.filename,"%s.nii",fname);

    SaveAsCharImage(&Cpy, 1);



    sprintf(fname,"%s//smooth.csv",directory);
    if ((fp=fopen(fname,"w")))
    {
        maxcount=-1000;
        for (smooth=1.0; smooth<2.0*width; smooth+=0.1)
        {
            memcpy(density.img, Cpy.img, VOXELS*sizeof(float));

            Nclusters = GetValidMeanShiftClusters(image, C, xc, yc, zc, Neighbours, valid, smooth);
            count=0;
            for (focus=0; focus<Nfoci; focus++)
            {
                offset=Nfoci*focus;
                for (focus2=focus+1; focus2<Nfoci; focus2++)
                {
                    if (dist2[offset+focus2]>0.0)
                    {
                        if ((*C).cluster[focus]  && (*C).cluster[focus]==(*C).cluster[focus2]) count++;
                        else if ((*C).cluster[focus] || (*C).cluster[focus2]) count--;
                    }
                }
            }
            if (count>maxcount)
            {
                maxcount=count;
                bestsmooth=smooth;
            }
            fprintf(fp,"%f,%d\n",smooth,count);
        }
        fclose(fp);
    }
    Nclusters = GetValidMeanShiftClusters(image, C, xc, yc, zc, Neighbours, valid, bestsmooth);

    memset(Cpy.img,0,sizeof(float)*VOXELS);
    for (focus=0; focus<Nfoci; focus++)
    {
        if (valid[focus])
            Cpy.img[(*C).voxel[focus]]=2.0;
        else
            Cpy.img[(*C).voxel[focus]]=1.0;
    }

    sprintf(fname,"%s//foci",directory);
    if ((*image).ImageType==HDR)
        sprintf(Cpy.filename,"%s.img",fname);
    else
        sprintf(Cpy.filename,"%s.nii",fname);
    SaveAsCharImage(&Cpy, 1);



    SaveRGBclustersKernelLOO((*C).voxel,(*C).cluster, (*C).x, (*C).y, (*C).z,
                             (*C).experiment, Nfoci, &Cpy,
                             Nclusters, marker,
                             directory);

    SaveReportedStructuresCVCA(C, directory, valid);

END:
    ReleaseImage(&Cpy);


    if (valid)
        free(valid);


    return Nclusters;
}

//======================================================================================
//this needs to consider intensities more
int DensityImage(struct Image *image, struct Coordinates *C, short int valid[], double width)
{
    int result=0;
    int upto, last;
    int focus;
    int voxel;
    int a,b,c;
    int neighbour;
    int xi,yi,zi;
    int Nfoci=(*C).TotalFoci;
    int *V=NULL;
    int VOXELS=(*image).X*(*image).Y*(*image).Z;
    float xf,yf,zf;
    double K;

    if (!(V=(int *)malloc(sizeof(int)*VOXELS)))
        goto END;

    memset((*image).img,0,sizeof(float)*VOXELS);

    upto=0;
    for (focus=0; focus<Nfoci; focus++)
    {
        if (valid[focus])
        {
            voxel = (*C).voxel[focus];
            XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
            xf=xi*(*image).dx - (*image).x0;
            yf=yi*(*image).dy - (*image).y0;
            zf=zi*(*image).dz - (*image).z0;

            K=KernelEstimateAtCoordinate(C, xf, yf, zf, width, valid);

            if (upto<VOXELS)
            {
                (*image).img[voxel] = K;
                V[upto] = voxel;
                upto++;
            }
        }
    }


    last=upto;
    upto=0;
    while (upto<last)
    {
        voxel=V[upto];
        XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
        for (c=-1; c<=1; c++)
        {
            for (b=-1; b<=1; b++)
            {
                for (a=-1; a<=1; a++)
                {
                    if ((a||b||c) && InImageRange(xi+a, yi+b, zi+c, (*image).X, (*image).Y, (*image).Z))
                    {
                        neighbour=voxel + a + b*(*image).X + c*(*image).X*(*image).Y;
                        if ((*image).img[neighbour]==0.0)
                        {
                            xf=(xi+a)*(*image).dx - (*image).x0;
                            yf=(yi+b)*(*image).dy - (*image).y0;
                            zf=(zi+c)*(*image).dz - (*image).z0;
                            K=KernelEstimateAtCoordinate(C, xf, yf, zf, width, valid);

                            if (last<VOXELS)
                            {
                                if (K<=0.0)
                                {
                                    (*image).img[neighbour]=-1;
                                }
                                else
                                {
                                    V[last]=neighbour;
                                    (*image).img[neighbour]=K;
                                    last++;
                                }
                            }
                        }
                    }
                }
            }
        }
        upto++;
    }


    for(voxel=0; voxel<VOXELS; voxel++)
    {
        if ((*image).img[voxel]<0.0)
            (*image).img[voxel]=0.0;
    }

END:
    if (V)
        free(V);

    return result;
}

//======================================================================================
int SaveRGBclustersKernelLOO(int FociVoxel[], short int cluster[], float xf[], float yf[], float zf[],
                             short int study[], int Nfoci, struct Image *img,
                             int Nclusters, int Marker,
                             char directory[])
{
    struct Image RGBimg;
    int coordinate;
    int x,y,z;
    int voxel;
    int voxels;
    int X,Y,Z,XY;
    int cl;
    RGBQUAD rgb;
    int ColourLevels;
    double *ClusterSize=NULL;
    int *ClusterCount=NULL;
    int *NearCluster=NULL;
    int Marker2=Marker*Marker;

    X=(*img).X;
    Y=(*img).Y;
    Z=(*img).Z;
    XY=X*Y;
    voxels=X*Y*Z;

    ColourLevels = Nclusters/6+1;

    memset(&RGBimg,0,sizeof(struct Image));

    if (!(ClusterSize=(double *)calloc((Nclusters+1),sizeof(double))))
        goto END;

    if (!(ClusterCount=(int *)calloc((Nclusters+1),sizeof(int))))
        goto END;

    if (!(NearCluster=(int *)calloc(Nfoci,sizeof(int))))
        goto END;

    if (!(MakeCopyOfImage(img, &RGBimg)))
        goto END;

    memset(RGBimg.img,0,sizeof(float)*voxels);

    for (coordinate=0; coordinate<Nfoci; coordinate++)
    {
        if ((cl=cluster[coordinate])>0 && cl<=Nclusters)
        {

            for (z=-Marker; z<=Marker; z++)
            {
                for (y=-Marker; y<=Marker; y++)
                {
                    for (x=-Marker; x<=Marker; x++)
                    {

                        voxel = FociVoxel[coordinate] + x + X*y + XY*z;
                        if ((voxel>=0) && (voxel<voxels))
                        {
                            if ( (x*x + y*y + z*z)<=Marker2  && !RGBimg.img[voxel])
                            {
                                rgb=Colours(cl-1,ColourLevels);

                                memcpy(&RGBimg.img[voxel], &rgb, sizeof(float));
                            }
                        }
                    }
                }
            }
        }

    }

    RGBimg.DataType=DT_RGB;
    RGBimg.ImageType=NIFTI;
    sprintf(RGBimg.filename, "%s//ClustersRGB.nii",  directory);
    Save(&RGBimg);

END:

    ReleaseImage(&RGBimg);

    if (ClusterSize)
        free(ClusterSize);

    if (ClusterCount)
        free(ClusterCount);

    if (NearCluster)
        free(NearCluster);

    return 1;
}
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
int KernelLOOfigures(struct Coordinates *Corg)
{
    double *dist2=NULL;
    struct Coordinates C;
    int Nfoci=(*Corg).TotalFoci;
    double width;
    int Neighbours;
    float *xc=NULL;
    float *yc=NULL;
    float *zc=NULL;


    if (!(xc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;
    if (!(yc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;
    if (!(zc=(float *)calloc(Nfoci,sizeof(float))))
        goto END;



    memset(&C,0,sizeof(struct Coordinates));

    if (!CopyCoordinates(Corg, &C))
        goto END;

    if (!(dist2=(double *)malloc(Nfoci*Nfoci*sizeof(double))))
        goto END;

    CoordinateDistance2MatrixNoStudies(C.x, C.y, C.z, dist2, Nfoci, 1.0);

    /*
    	RandomiseCoordinatesForTesting(gImage.img, gImage.X, gImage.Y, gImage.Z,
    		                               gImage.dx, gImage.dy, gImage.dz,
    		                               gImage.x0, gImage.y0, gImage.z0,
    		                               C,10.0);
    */

    Neighbours=6;
    width=11;
    StoreImageQuick(&gImage, &C, dist2, Neighbours, width, REPORT_FOLDER, xc, yc, zc,1);



END:
    if (dist2)
        free(dist2);

    FreeCoordinates(&C);

    if (xc)
        free(xc);

    if (yc)
        free(yc);

    if (zc)
        free(zc);

    return 0;
}
//======================================================================================
//======================================================================================
#define SAMPLEMVN 200
int TestDensity()
{
    double d2[SAMPLEMVN*SAMPLEMVN];
    double D[SAMPLEMVN];
    double score[20];
    int i,j,k;
    double x[SAMPLEMVN],y[SAMPLEMVN],z[SAMPLEMVN];
    int count[20];
    double d;
    FILE *fp;
    char fname[MAX_PATH];

    for (i=0; i<SAMPLEMVN; i++)
    {
        x[i] = GaussRandomNumber_BoxMuller(0,1.0);
        y[i] = GaussRandomNumber_BoxMuller(0,1.0);
        z[i] = GaussRandomNumber_BoxMuller(0,1.0);
    }

    for (i=0; i<SAMPLEMVN; i++)
    {
        for (j=0; j<SAMPLEMVN; j++)
        {
            d2[i*SAMPLEMVN+j]=(x[i] - x[j])*(x[i] - x[j])+
                              (y[i] - y[j])*(y[i] - y[j])+
                              (z[i] - z[j])*(z[i] - z[j]);
        }
    }



    k=0;
    memset(count,0,sizeof(int)*20);
    memset(score,0,20*sizeof(double));
    for (d=0.0; d<2.0; d+=0.1)
    {
        memset(D,0,SAMPLEMVN*sizeof(double));
        for (i=0; i<SAMPLEMVN; i++)
        {
            for (j=0; j<SAMPLEMVN; j++)
            {
                if (i!=j && d2[i*SAMPLEMVN+j]<d*d)
                {
                    D[i] += KernelCBMA(sqrt(d2[i*SAMPLEMVN+j]), d, KERNEL_TYPE);
                }
            }
        }


        for (i=0; i<SAMPLEMVN; i++)
        {
            for (j=0; j<SAMPLEMVN; j++)
            {
                if (i!=j && d2[i*SAMPLEMVN+j]<d*d)
                {
                    count[k]++;
                    score[k]+=D[i];
                }
            }
        }
        k++;
    }

    sprintf(fname,"%s//density.csv",REPORT_FOLDER);
    if ((fp=fopen(fname,"w")))
    {

        for (i=0; i<20; i++)
        {
            fprintf(fp,"%f,%f,%d\n",0.1*i,score[i],count[i]);
        }
        fclose(fp);
    }

    return 0;
}
//======================================================================================
int ReportClustersCVCA(float x[], float y[], float z[], float Zsc[], short int cluster[], int Nfoci,
                       short int exprmnt[], int Nexperiments,
                       struct TextLabel StudyID[], struct TextLabel ctrst[], struct TextLabel cnd[],
                       char directory[],
                       int X, int Y, int Z, float z0,
                       float dx, float dy, float dz,
                       float xc[], float yc[], float zc[], int Nclusters, int MinStudiesPerCluster)
{
    char fname[MAX_PATH];
    FILE *fp;
    int cl;
    int *experiments=NULL;      //how many experiments contribute to the clusters
    int NsignificantFoci;
    int foci, iexp, FoundContributor;
    int xi,yi,zi;
    float xf,yf,zf;
    char *labels=NULL;
    char *b=NULL;
    int Nentries,Nl;
    struct Image Tal;
    char shortlabel[256];


    memset(&Tal,0,sizeof(struct Image));

//LOAD THE TALAIRACH DATA
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    LoadFromFileName(NULL, fname, &Tal, 0);
    labels=LoadTalairachLabels(&Nl);
    Nentries=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,Nentries);

//count the number of significant foci
    NsignificantFoci=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        if (cluster[foci])
            NsignificantFoci++;
    }




//count the number of significant studies contributing to each cluster
    if (!(experiments=(int *)malloc((Nclusters+1)*sizeof(int))))
        goto END;
    memset(experiments,0,(Nclusters+1)*sizeof(int));
    for (cl=1; cl<=Nclusters; cl++)
    {
        for (iexp=0; iexp<Nexperiments; iexp++)
        {
            FoundContributor=0;
            for (foci=0; foci<Nfoci; foci++)
            {
                if ((exprmnt[foci] == iexp) &&
                        (cluster[foci] == cl))
                    FoundContributor=1;
            }
            if (FoundContributor)
                experiments[cl]++;
        }
    }




    sprintf(fname,"%s\\ClusterReport.csv",directory);
    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"Number of foci, %d\n", Nfoci);
        fprintf(fp,"Number of studies, %d\n", Nexperiments);
        fprintf(fp,"Min Studies Per Cluster, %d\n", MinStudiesPerCluster);
        fprintf(fp,"Talairach report, , , , , Cluster{x y z},Number Of Studies,Slice,Studies,,,,,Nearest GM\n\n");
        for (cl=1; cl<=Nclusters; cl++)
        {
            if (experiments[cl])
            {

                if (fp)
                    fprintf(fp,"cluster %d\n",cl);

                xf=xc[cl-1];
                yf=yc[cl-1];
                zf=zc[cl-1];

                xi=(int)((xf+Tal.x0)/Tal.dx+0.5);
                yi=(int)((yf+Tal.y0)/Tal.dy+0.5);
                zi=(int)((zf+Tal.z0)/Tal.dz+0.5);

                if (labels && Tal.img)
                {
                    b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                    if (fp)
                        fprintf(fp,"%s,",&b[1]);
                }

                zi=(int)((zf+z0)/dz+0.5);
                if (fp)
                    fprintf(fp," (%5.1f  %5.1f  %5.1f),%d,%d,", xf, yf, zf,experiments[cl], zi);

                //list each experiment that contributes to this cluster
                //report the lowest p value for the experiment, and indicate if it is significant
                for (iexp=0; iexp<Nexperiments; iexp++)
                {
                    for (foci=0; foci<Nfoci; foci++)
                    {
                        if ((cluster[foci]==cl) && (exprmnt[foci] == iexp))
                        {

                            if (fp)
                                fprintf(fp,"%s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
                                        StudyID[exprmnt[foci]].txt,
                                        ctrst[exprmnt[foci]].txt,
                                        cnd[exprmnt[foci]].txt,
                                        x[foci],y[foci],z[foci],Zsc[foci]);

                            if (labels && Tal.img)
                            {
                                xi=(int)((x[foci]+Tal.x0)/Tal.dx+0.5);
                                yi=(int)((y[foci]+Tal.y0)/Tal.dy+0.5);
                                zi=(int)((z[foci]+Tal.z0)/Tal.dz+0.5);
                                b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                                ShortTalairachLabel(b, shortlabel, ".");
                                if (fp)
                                    fprintf(fp,"%s\n , , , , ,  , , ,",shortlabel);
                            }
                        }
                    }

                }

                if (fp)
                    fprintf(fp,"\n");
            }
        }
        fclose(fp);
    }


END:
    if (labels)
        free(labels);
    if (experiments)
        free(experiments);
    ReleaseImage(&Tal);

    return Nclusters;
}

//======================================================================================
//======================================================================================================
int SaveReportedStructuresCVCA(struct Coordinates *C, char directory[], short int *concordant)
{
	struct Image TalImg;
	int result=0;
	char fname[MAX_PATH];
	char *labels=NULL;
	char *b;
	int LengthLabels;
	int Nlabels;
	int st;
	int focus;
	int lab;
	char shortlabel[256];
	short int *reported=NULL;
	short int *studies=NULL;
	FILE *fp;

	memset(&TalImg,0,sizeof(struct Image));
	sprintf(fname,"%s\\Talairach\\talGMmerged.nii", ExecutableDirectory);
	if (!LoadFromFileName(NULL, fname, &TalImg, 0))
	{
		MessageBox(NULL,"Not available without downloading the Talairach image file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
		goto END;
	}
	labels=LoadTalairachLabels(&LengthLabels);
	if (LengthLabels<=0)
	{
		MessageBox(NULL,"Not available without downloading the Talairach labels file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
		goto END;
	}
	Nlabels=BiggestTalairachLabel(labels, LengthLabels);

	GetTalairachLabelsEx(C, &TalImg);

	if (!(reported=(short int *)malloc(sizeof(short int)*(Nlabels+1))))
		goto END;
	if (!(studies=(short int *)malloc(sizeof(short int)*(Nlabels+1))))
		goto END;

	memset(studies,0,sizeof(short int)*(Nlabels+1));
	for (st=0; st<(*C).Nexperiments; st++)
	{
		memset(reported,0,sizeof(short int)*(Nlabels+1));
		for (focus=0; focus<(*C).TotalFoci; focus++)
		{
			if (concordant[focus] && (*C).experiment[focus]==st)
				reported[(*C).TalLabel[focus]]++;
		}
		for (lab=0; lab<=Nlabels; lab++)
		{
			if (reported[lab])
				studies[lab]++;
		}
	}

	sprintf(fname,"%s//Reported Structures.csv", directory);
	if ( (fp=fopen(fname,"w")) )
	{
		fprintf(fp,"Talairach,,,,,,Proportion reporting, Number reporting\n");
		for (lab=0; lab<=Nlabels; lab++)
		{
			if (studies[lab])
			{
				b=FindEntryInTalairachLabels(labels, LengthLabels, lab);
				ShortTalairachLabel(b, shortlabel, ".");
				fprintf(fp,"%s,%s,%f,%d\n",&b[1],shortlabel,(double)studies[lab]/(*C).Nexperiments,studies[lab]);
			}
		}

		fclose (fp);
	}

	result=1;
END:
	ReleaseImage(&TalImg);
	if (reported)
		free(reported);
	if (studies)
		free(studies);

	return result;
}


//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
//======================================================================================
