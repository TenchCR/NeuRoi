/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "polynomial.h"
#include "numerical.h"
#include "imageprocess.h"


//==============================================================================
//RETURNS THE NUMBER OF TERMS IN AN Nth ORDER POLYNOMIAL IN D DIMENTIONS
//That is sum_{0}^{N} (k+(D-1))!/k!/(D-1)!
//==============================================================================
int TermsInNthorderDdimensionPolynomial(int N, int D)
{
    int order;
    int terms=1;
    int a,b;
    int i;

    for (order=1; order<=N; order++)
    {
        a=1;
        for (i=order+1; i<=D-1+order; i++) a*=i;
        b=1;
        for (i=1; i<=D-1; i++) b*=i;

        terms += a/b;
    }
    return terms;
}
int TestTermsInNthorderDdimensionPolynomial(int N, int D)
{
    char txt[256];
    int terms=TermsInNthorderDdimensionPolynomial(N,D);
    sprintf(txt,"%d",terms*D);
    MessageBox(NULL,txt,"",MB_OK);
    return 1;
}


//==============================================================================
//get the regressors variables, given the TWO explanatory variables
//when the model to fit is a polynomial with highest order term N
//There are (N+2)*(N+1)/2  regressor variables
//regressors are in r[] at the end
//returns the number of terms
//**************UNTESTED*************
//==============================================================================
int PolynomialRegressors2D(double e1, double e2, double r[], int N)
{
    int *order=NULL;
    int terms=TermsInNthorderDdimensionPolynomial(N, 2);
    int l;

    if (!(order=(int *)malloc(terms*sizeof(int)))) return 0;

    l = PolynomialRegressors2DEx(e1, e2, r, order, N);//should be (N+2)*(N+1)/2
    if (order) free(order);

    return l;

}
//==============================================================================
//get the regressors variables, given the TWO explanatory variables
//when the model to fit is a polynomial with highest order term N
//There are (N+2)*(N+1)/2  regressor variables
//regressors are in r[] at the end
//returns the number of terms
//**************UNTESTED*************
//==============================================================================
int PolynomialRegressors2DEx(double e1, double e2, double r[], int order[], int N)
{

    int i,j;
    int l=0;
    double xi,yj;

    xi=1.0;//initialise at e1^0
    for (i=0; i<=N; i++)
    {
        yj=1.0;//initialise at e2^0
        for (j=0; j<=(N-i); j++)
        {
            r[l]=xi*yj;
            yj*=e2;
            order[l]=i+j;
            l++;
        }
        xi*=e1;
    }

    return l;//should be (N+2)*(N+1)/2
}



//==============================================================================
//get the regressors variables, given the THREE explanatory variables
//when the model to fit is a polynomial with highest order term N; must be <100
//There are ?????????? regressor variables
//regressors are in r[] at the end
//returns the number of terms
//==============================================================================
int PolynomialRegressors3D(double e1, double e2, double e3, double r[], int N)
{

    int order[100];

    return PolynomialRegressors3DEx(e1, e2, e3, r, order, N);
}



//==============================================================================
//get the regressors variables, given the THREE explanatory variables
//when the model to fit is a polynomial with highest order term N; must be <100
//There are ?????????? regressor variables
//regressors are in r[] at the end
//returns the number of terms
//also returns the order of the terms
//==============================================================================
int PolynomialRegressors3DEx(double e1, double e2, double e3, double r[], int order[], int N)
{


    int i,j,k;
    int term=0;
    double xiyj;
    double x[10], y[10], z[10];
    //FILE *fp=NULL;

    if (N>=10) return 0;


    x[0]=y[0]=z[0]=1.0;
    x[1]=e1; y[1]=e2; z[1]=e3;
    for (i=2; i<=N; i++)
    {
        x[i]=x[i-1]*e1;
        y[i]=y[i-1]*e2;
        z[i]=z[i-1]*e3;
    }


//fp=fopen("c:\\temp\\poly.csv","w");
//if (fp) fprintf(fp,"x,y,z\n");
    for (i=0; i<=N; i++)
    {
        for (j=0; j<=(N-i); j++)
        {
            xiyj=x[i]*y[j];
            for (k=0; k<=(N-i-j); k++)
            {
                r[term]=xiyj*z[k];
                order[term]=i+j+k;
                term++;
                //if (fp) fprintf(fp,"%d,%d,%d\n",i,j,k);
            }
        }
    }
//if (fp) fclose(fp);


    return term;//should be ???????????
}
int TestPolynomialRegressors3DEx(int N)
{
    double r[1000];
    int order[1000];
    PolynomialRegressors3DTermOrderSorted(1.0, 1.0, 1.0, r, order, N);
    return 1;
}

//==============================================================================
//get the regressors variables, given the THREE explanatory variables
//when the model to fit is a polynomial with highest order term N; must be <100
//There are ?????????? regressor variables
//regressors are in r[] at the end
//returns the number of terms
//also returns the order of the terms
//==============================================================================
int PolynomialRegressors3DTermOrderSorted(double e1, double e2, double e3, double r[], int order_of_term[], int N)
{


    int i,j,k;
    int order;
    int term=0;
    double x[10], y[10], z[10];
    //FILE *fp=NULL;

    if (N>=10) return 0;


    x[0]=y[0]=z[0]=1.0;
    for (i=1; i<=N; i++)
    {
        x[i]=x[i-1]*e1;
        y[i]=y[i-1]*e2;
        z[i]=z[i-1]*e3;
    }


//fp=fopen("c:\\temp\\poly.csv","w");
//if (fp) fprintf(fp,"x,y,z,order\n");
    for (order=0; order<=N; order++)
    {
        for (i=0; i<=N; i++)
        {
            for (j=0; j<=(N-i); j++)
            {
                k=order-i-j;
                if (k>=0)
                {
                    r[term]=x[i]*y[j]*z[k];
                    order_of_term[term]=i+j+k;
                    term++;
                    //if (fp) fprintf(fp,"%d,%d,%d,%d\n",i,j,k,i+j+k);
                }
            }
        }
    }
//if (fp) fclose(fp);


    return term;//should be TermsInNthorderDdimensionPolynomial(N, 3)
}
//==============================================================================
//get the regressors variables, given the THREE explanatory variables
//when the model to fit is a polynomial with highest order term N
//THIS FUNCTION RETURNS THE GRADIENT TERMS
//r[] is of length 3N. The gradient wrt e1 is in r[i]; i<N
//                     The gradient wrt e2 is in r[i]; N<=i<2N
//                     The gradient wrt e3 is in r[i]; 2N<=i<3N
//regressors are in r[] at the end
//returns the number of terms
//==============================================================================
int GradPolynomialRegressors3D(double e1, double e2, double e3, double r[], int N, int terms)
{


    int i,j,k;
    int term=0;
    double *x, *y, *z;

    x=(double *)malloc((N+1)*sizeof(double));
    y=(double *)malloc((N+1)*sizeof(double));
    z=(double *)malloc((N+1)*sizeof(double));
    if ((!x) || (!y) || (!z)) goto END;

    for (i=0; i<=N; i++)
    {
        x[i]=pow(e1,i);
        y[i]=pow(e2,i);
        z[i]=pow(e3,i);
    }

    for (i=0; i<=N; i++)
    {
        for (j=0; j<=(N-i); j++)
        {
            for (k=0; k<=(N-i-j); k++)
            {
                if (i>0) r[term]=i*x[i-1]*y[j]*z[k];
                else r[term]=0.0;
                if (j>0) r[term+terms]=j*x[i]*y[j-1]*z[k];
                else r[term+terms]=0.0;
                if (k>0) r[term+2*terms]=k*x[i]*y[j]*z[k-1];
                else r[term+2*terms]=0.0;
                term++;
            }
        }
    }

END:
    if (x) free(x);
    if (y) free(y);
    if (z) free(z);

    return term;//should be ???????????
}


//=========================================================================================
//               Given the parameters of a gain polynomial, correct the gain
//=========================================================================================
float CorrectPolynomialGain(float *image, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                            float fovx, float fovy, float fovz, double param[], int order, int polyterms)
{

    float change=0.0;
    double *R=NULL;
    double fitted;
    double gain;
    int x,y,z;
    int voxel;
    int i;

    if ((fovx<=0.0) || (fovy<=0.0) || (fovz<=0.0)) goto END;

    if (!(R=(double *)malloc(polyterms*sizeof(double)))) goto END;

    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {

                if (fabs(image[voxel])>0.0)
                {
                    PolynomialRegressors3D((double)(dx*x-x0)/fovx, (double)(dy*y-y0)/fovy,
                                           (double)(dz*z-z0)/fovz, R, order);

                    fitted=0.0;
                    for (i=1; i<polyterms; i++)
                    {
                        fitted+=R[i]*param[i];
                    }
                    gain=exp(-fitted);
                    image[voxel]*=gain;
                    change+=fabs(1.0-gain);
                }
                voxel++;
            }
        }
    }

END:
    if (R) free(R);
    return change;
}

//=========================================================================================
//               Given the parameters of a gain polynomial, correct the gain
//=========================================================================================
float RomoveOutliersFromPolynomialFit(float *image, int X, int Y, int Z, float dx, float dy, float dz,
                                      double param[], int order, int polyterms)
{


    float *residual = NULL;
    float tmp;
    float x0,y0,z0;
    float fovx, fovy, fovz;
    double *R=NULL;
    double poly, fitted;
    double sum,sum2,sigma=0.0;
    int x,y,z;
    int voxel, voxels=X*Y*Z;
    int i;
    int N;

    x0=dx*X/2;
    y0=dy*Y/2;
    z0=dz*Z/2;
    fovx = dx*X;
    fovy = dy*Y;
    fovz = dz*Z;

    if ((fovx<=0.0) || (fovy<=0.0) || (fovz<=0.0)) goto END;

    if (!(R=(double *)malloc(polyterms*sizeof(double)))) goto END;
    if (!(residual=(float *)malloc(X*Y*Z*sizeof(float)))) goto END;

    sum=sum2=0.0;
    N=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                voxel=x+y*X+z*X*Y;
                if (fabs(image[voxel])>0.0)
                {
                    PolynomialRegressors3D((double)(dx*x-x0)/fovx, (double)(dy*y-y0)/fovy,
                                           (double)(dz*z-z0)/fovz, R, order);

                    poly=0.0;
                    for (i=0; i<polyterms; i++)
                    {
                        poly+=R[i]*param[i];
                    }
                    fitted = exp(poly);
                    tmp = image[voxel] - fitted;
                    residual[voxel] = fabs(tmp);
                    sum += tmp;
                    sum2 += tmp*tmp;
                    N++;
                }
            }
        }
    }
    //NULL the voxels with large residuals
    if (N)
    {
        sigma = sqrt(sum2/N - sum*sum/N/N);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (residual[voxel]>2.0*sigma) image[voxel] = 0.0;
        }
    }

END:
    if (R) free(R);
    if (residual) free(residual);
    return sigma;
}

//==============================================================================
//              fit a polynomial to the image
//              Use a linear model that has a different constant for each class
//              Weight (least squares) by the probability (probs[]) of being in each class
//              Constrain the gradient of the background to be zero
//==============================================================================
int FitClassPolynomialFlatConstrained(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
                                      float x0, float y0, float z0, float fovx, float fovy, float fovz,
                                      double param[], int order, int terms, int classes)
{

    int x, y, z;
    int voxel, voxels=X*Y*Z, equations;
    int row,col;
    int count;
    int n;
    int i;
    int inc_x, inc_y, inc_z;
    int result=0;
    int cl;
    double *R=NULL;
    double *I=NULL;
    double *M=NULL;
    float weight;
    float f;
    char txt[1024];


    voxels=X*Y*Z;

    inc_x=10.0/dx;
    if (!inc_x) inc_x=1;
    inc_y=10.0/dy;
    if (!inc_y) inc_y=1;
    inc_z=10.0/dz;
    if (!inc_z) inc_z=1;

    equations=0;
    for (z=-2*inc_z; z<=Z+2*inc_z; z+=inc_z)
    {
        for (y=-2*inc_y; y<=Y+2*inc_y; y+=inc_y)
        {
            for (x=-2*inc_x; x<=X+2*inc_x; x+=inc_x)
            {
                voxel=x+y*X+z*X*Y;
                if (InImageRange(x,y,z,X,Y,Z) && (image[voxel]>0.0)) equations+=classes;//need classes equations for each non null (background) voxel
                else equations+=3;//3 gradient equations
            }
        }
    }



    if (!(M=(double *)malloc((terms+classes-1)*equations*sizeof(double)))) goto END;
    memset(M,0,(terms+classes-1)*equations*sizeof(double));

    if (!(I=(double *)malloc(equations*sizeof(double)))) goto END;
    memset(I,0,equations*sizeof(double));


    if (!(R=(double *)malloc(terms*3*sizeof(double)))) goto END;

    //check the polynomial order has been set properly
    n=PolynomialRegressors3D((double)(x0)/fovx,
                             (double)(y0)/fovy,
                             (double)(z0)/fovz, R, order);
    if (n!=terms)
    {
        sprintf(txt,"n=%d",n);
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }




    count=0;
    for (z=-2*inc_z; z<=Z+2*inc_z; z+=inc_z)
    {
        for (y=-2*inc_y; y<=Y+2*inc_y; y+=inc_y)
        {
            for (x=-2*inc_x; x<=X+2*inc_x; x+=inc_x)
            {
                voxel=x+y*X+z*X*Y;

                //image is nonzero
                if (InImageRange(x,y,z,X,Y,Z) && ((f=image[voxel])>0.0) && count<(equations-classes))
                {
                    n=PolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                             (double)(dy*y-y0)/fovy,
                                             (double)(dz*z-z0)/fovz,
                                             R, order);

                    for (cl=0; cl<classes; cl++)
                    {
                        weight=(float)probs[voxel+cl*voxels]/255.0;
                        //enter into the matrix
                        for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=R[i]*weight;
                        if (cl) M[count*(terms+classes-1)+terms-1+cl]=weight;
                        I[count]=log(f)*weight;
                        count++;
                    }

                }
                //image is zero, constrain the gradient to be zero
                else
                {
                    if (count<(equations-3))
                    {
                        n=GradPolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                                     (double)(dy*y-y0)/fovy,
                                                     (double)(dz*z-z0)/fovz,
                                                     R, order, terms);
                        weight=0.02;
                        for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i];
                        I[count]=0.0;
                        count++;
                        for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i+terms];
                        I[count]=0.0;
                        count++;
                        for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i+2*terms];
                        I[count]=0.0;
                        count++;
                    }

                }

            }
        }
    }


    if (!PsuedoInverse(M, count, (terms+classes-1))) goto END;


    //get the coefficients of the polynomial
    for (col=0; col<terms; col++)
    {
        param[col]=0.0;
        for (row=0; row<count; row++)
        {
            param[col]+=M[col+row*(terms+classes-1)]*I[row];
        }
    }


    result=1;

END:
    if (M) free(M);
    if (I) free(I);
    if (R) free(R);
    return result;
}
//==============================================================================
//              fit a polynomial to the image
//              Use a linear model that has a different constant for each class
//              Weight (least squares) by the probability (probs[]) of being in each class
//              Constrain the gradient of the background to be zero
//==============================================================================
int FitClassPolynomialFlatConstrainedBayes(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
        float x0, float y0, float z0, float fovx, float fovy, float fovz,
        double param[], int order, int terms, int classes)
{


    int x, y, z;
    int voxel, voxels=X*Y*Z, XY=X*Y, equations;
    int count;
    int n;
    int i;
    int term;
    int inc_x, inc_y, inc_z;
    int result=0;
    int cl;
    int TermOrder[100];//the polynomial order of each term
    int brain;
    double *prior_mean=NULL;
    double *prior_InvCov=NULL;
    double *R=NULL;//polynomial terms
    double *I=NULL;//log image intensity
    double *M=NULL;//Design Matrix
    double *p=NULL;//parameters
    double f;
    float weight;
    float MaxIntensity;
    char txt[1024];


    memset(param,0,sizeof(double)*terms);


    voxels=X*Y*Z;

    inc_x=10.0/dx;
    if (!inc_x) inc_x=1;
    inc_y=10.0/dy;
    if (!inc_y) inc_y=1;
    inc_z=10.0/dz;
    if (!inc_z) inc_z=1;


    equations=0;
    MaxIntensity=0.0;
    for (z=-2*inc_z; z<=Z+2*inc_z; z+=inc_z)
    {
        for (y=-2*inc_y; y<=Y+2*inc_y; y+=inc_y)
        {
            for (x=-2*inc_x; x<=X+2*inc_x; x+=inc_x)
            {
                if (InImageRange(x,y,z,X,Y,Z))
                {
                    voxel=x+y*X+z*XY;

                    brain=0;
                    for (cl=0; (cl<classes) && (!brain); cl++)
                    {
                        if (probs[voxel + cl*voxels]>0) brain=1;
                    }
                    if (brain && (image[voxel]>0.0))
                    {
                        equations+=classes;//need classes equations for each non null (background) voxel
                        if (image[voxel]>MaxIntensity) MaxIntensity=image[voxel];
                    }
                    else equations+=3;//3 gradient equations
                }

            }
        }
    }


    if (MaxIntensity<0.0) goto END;


    if (!(prior_mean=(double *)malloc(sizeof(double)*(terms+classes-1)))) goto END;
    if (!(prior_InvCov=(double *)malloc((terms+classes-1)*(terms+classes-1)*sizeof(double)))) goto END;
    if (!(p=(double *)malloc(sizeof(double)*(terms+classes-1)))) goto END;
    if (!(M=(double *)malloc((terms+classes-1)*equations*sizeof(double)))) goto END;
    memset(M,0,(terms+classes-1)*equations*sizeof(double));


    if (!(I=(double *)malloc(equations*sizeof(double)))) goto END;
    memset(I,0,equations*sizeof(double));

    if (!(R=(double *)malloc(3*terms*sizeof(double)))) goto END;



    //check the polynomial order has been set properly
    n=PolynomialRegressors3DEx((double)(x0)/fovx,
                               (double)(y0)/fovy,
                               (double)(z0)/fovz, R, TermOrder, order);
    if (n!=terms)
    {
        sprintf(txt,"n=%d",n);
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }



    //set the prior means and covariances
    memset(prior_mean,0,sizeof(double)*(terms+classes-1));
    memset(prior_InvCov,0,sizeof(double)*(terms+classes-1)*(terms+classes-1));
    for (term=1; term<terms; term++)
    {
        //prior_InvCov[(terms+classes-1)*term+term]=MaxIntensity*MaxIntensity*pow(2.0,TermOrder[term]);//reducing variance with order
        prior_InvCov[(terms+classes-1)*term+term]=1.0;
    }





    count=0;
    for (z=-2*inc_z; z<=Z+2*inc_z; z+=inc_z)
    {
        for (y=-2*inc_y; y<=Y+2*inc_y; y+=inc_y)
        {
            for (x=-2*inc_x; x<=X+2*inc_x; x+=inc_x)
            {
                if (InImageRange(x,y,z,X,Y,Z))
                {
                    voxel=x+y*X+z*XY;

                    brain=0;
                    for (cl=0; (cl<classes) && (!brain); cl++)
                    {
                        if (probs[voxel + cl*voxels]>0) brain=1;
                    }

                    //image is nonzero
                    if (((f=image[voxel])>0.0) && brain && (count<(equations-classes)))
                    {
                        n=PolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                                 (double)(dy*y-y0)/fovy,
                                                 (double)(dz*z-z0)/fovz,
                                                 R, order);

                        for (cl=0; cl<classes; cl++)
                        {
                            weight=(float)probs[voxel+cl*voxels]/255.0;
                            //enter into the matrix
                            if (weight>0.0)
                            {
                                for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=R[i]*weight;
                                if (cl) M[count*(terms+classes-1)+terms-1+cl]=weight;
                                I[count]=log(f)*weight;
                                count++;
                            }
                        }
                    }
                    //image is zero, constrain the gradient to be zero
                    else
                    {
                        if (count<(equations-3))
                        {
                            n=GradPolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                                         (double)(dy*y-y0)/fovy,
                                                         (double)(dz*z-z0)/fovz,
                                                         R, order, terms);
                            weight=0.05;
                            for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i];
                            I[count]=0.0;
                            count++;
                            for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i+terms];
                            I[count]=0.0;
                            count++;
                            for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=weight*R[i+2*terms];
                            I[count]=0.0;
                            count++;
                        }

                    }
                }
            }
        }
    }
    /*if ((fp=fopen("c:\\temp\\matrix.txt","w")))
    {
        for (i=0; i<count; i++)
        {
            for (j=0; j<(terms+classes-1); j++)
            {
                fprintf(fp,"%g   ",M[i*(terms+classes-1)+j]);
            }
            fprintf(fp,"*%g\n",I[i]);
        }

        fclose(fp);
    }*/

    //do Bayesian Regularisation
    BayesLinearRegression(I, M, p, count, (terms+classes-1), prior_InvCov, prior_mean);
    memcpy(param,p,sizeof(double)*terms);


    result=1;

END:
    if (M) free(M);
    if (p) free(p);
    if (I) free(I);
    if (R) free(R);
    if (prior_mean) free(prior_mean);
    if (prior_InvCov) free(prior_InvCov);
    return result;
}

//==============================================================================
//              fit a polynomial to the image
//              Use a linear model that has a different constant for each class
//              Weight (least squares) by the probability (probs[]) of being in each class
//              Constrain the parameters using priors
//==============================================================================
int FitClassPolynomialBayes(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
                            float x0, float y0, float z0, float fovx, float fovy, float fovz,
                            double param[], int order, int terms, int classes)
{

    int x, y, z;
    int voxel, voxels=X*Y*Z, equations;
    int count;
    int n;
    int i;
    int term;
    int inc_x, inc_y, inc_z;
    int result=0;
    int cl;
    int TermOrder[100];//the polynomial order of each term
    double *prior_mean=NULL;
    double *prior_InvCov=NULL;
    double *R=NULL;//polynomial terms
    double *I=NULL;//log image intensity
    double *M=NULL;//Design Matrix
    double *p=NULL;//parameters
    double logI;
    float weight;
    float f;
    float MaxIntensity;
    char txt[1024];


    memset(param,0,sizeof(double)*terms);


    voxels=X*Y*Z;

    inc_x=6.0/dx;
    if (inc_x<=0) inc_x=1;
    inc_y=6.0/dy;
    if (inc_y<=0) inc_y=1;
    inc_z=6.0/dz;
    if (inc_z<=0) inc_z=1;


    equations=0;
    MaxIntensity=0.0;
    for (z=0; z<Z; z+=inc_z)
    {
        for (y=0; y<Y; y+=inc_y)
        {
            for (x=0; x<X; x+=inc_x)
            {
                voxel=x+y*X+z*X*Y;
                if ((f=image[voxel]>0.0)) equations+=classes;//need classes equations for each non null (i.e. non background) voxel
                if (f>MaxIntensity) MaxIntensity=f;
            }
        }
    }
    if (MaxIntensity<=0.0) goto END;



    if (!(prior_mean=(double *)malloc(sizeof(double)*(terms+classes-1)))) goto END;
    if (!(prior_InvCov=(double *)malloc((terms+classes-1)*(terms+classes-1)*sizeof(double)))) goto END;
    if (!(p=(double *)malloc(sizeof(double)*(terms+classes-1)))) goto END;
    if (!(M=(double *)malloc((terms+classes-1)*equations*sizeof(double)))) goto END;
    memset(M,0,(terms+classes-1)*equations*sizeof(double));


    if (!(I=(double *)malloc(equations*sizeof(double)))) goto END;
    memset(I,0,equations*sizeof(double));

    if (!(R=(double *)malloc(terms*sizeof(double)))) goto END;

    //check the polynomial order has been set properly
    n=PolynomialRegressors3DEx((double)(x0)/fovx,
                               (double)(y0)/fovy,
                               (double)(z0)/fovz, R, TermOrder, order);
    if (n!=terms)
    {
        sprintf(txt,"n=%d",n);
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }

    //set the prior means and covariances
    memset(prior_mean,0,sizeof(double)*(terms+classes-1));
    memset(prior_InvCov,0,sizeof(double)*(terms+classes-1)*(terms+classes-1));
    for (term=1; term<terms; term++)
    {
        prior_InvCov[(terms+classes-1)*term+term]=200.0*fabs(log(MaxIntensity))*pow(2.0,TermOrder[term]);//reducing variance with order
        //prior_InvCov[(terms+classes-1)*term+term]=100.0;
    }





    count=0;
    for (z=0; z<Z; z+=inc_z)
    {
        for (y=0; y<Y; y+=inc_y)
        {
            for (x=0; x<X; x+=inc_x)
            {
                voxel=x+y*X+z*X*Y;

                //image is nonzero
                if (((f=image[voxel])>0.0) && count<(equations-classes))
                {
                    n=PolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                             (double)(dy*y-y0)/fovy,
                                             (double)(dz*z-z0)/fovz,
                                             R, order);

                    logI=log(f);
                    for (cl=0; cl<classes; cl++)
                    {
                        weight=(float)probs[voxel+cl*voxels]/255.0;
                        //enter into the matrix
                        for (i=0; i<terms; i++) M[count*(terms+classes-1)+i]=R[i]*weight;
                        if (cl) M[count*(terms+classes-1)+terms-1+cl]=weight;
                        I[count]=logI*weight;
                        count++;
                    }

                }
            }
        }
    }


    //do Bayesian Regularisation
    BayesLinearRegression(I, M, p, count, (terms+classes-1), prior_InvCov, prior_mean);
    memcpy(param,p,sizeof(double)*terms);

    result=1;

END:
    if (M) free(M);
    if (p) free(p);
    if (I) free(I);
    if (R) free(R);
    if (prior_mean) free(prior_mean);
    if (prior_InvCov) free(prior_InvCov);

    return result;
}
//==============================================================================
//              fit a polynomial to the image to smooth it
//              Constrain the gradient of the background to be zero
//==============================================================================
int FitPolynomialConstrainedBayes(float image[], float dx, float dy, float dz, int X, int Y, int Z,
                                  int order, int terms, double param[])
{

    int x, y, z,XY=X*Y;
    int voxel, equations;
    int count;
    int n;
    int i;
    int term;
    int inc_x, inc_y, inc_z;
    int result=0;
    int TermOrder[100];//the polynomial order of each term
    double *R=NULL;
    double *I=NULL;
    double *M=NULL;
    double *InvPriorCov=NULL;
    double *PriorMean=NULL;
    float f, MaxIntensity;
    float x0,y0,z0;
    float fovx, fovy, fovz;
    char txt[1024];

    x0=dx*X/2.0;
    x0=dy*Y/2.0;
    x0=dz*Z/2.0;
    fovx = dx*X;
    fovy = dy*Y;
    fovz = dz*Z;


    inc_x=10.0/dx;
    if (!inc_x) inc_x=1;
    inc_y=10.0/dy;
    if (!inc_y) inc_y=1;
    inc_z=10.0/dz;
    if (!inc_z) inc_z=1;

    equations=0;
    MaxIntensity=0.0;
    for (z=0; z<Z; z+=inc_z)
    {
        for (y=0; y<Y; y+=inc_y)
        {
            for (x=0; x<X; x+=inc_x)
            {
                voxel=x+y*X+z*XY;
                if ((f=image[voxel])>0.0) equations++;
                else equations+=3;//3 gradient equations
                if (f>MaxIntensity) MaxIntensity=f;
            }
        }
    }
    if (MaxIntensity<=0.0) goto END;


    x0=dx*X/2;
    y0=dy*Y/2;
    z0=dz*Z/2;

    if (!(InvPriorCov=(double *)malloc(sizeof(double)*terms*terms))) goto END;
    if (!(PriorMean=(double *)malloc(sizeof(double)*terms))) goto END;

    if (!(R=(double *)malloc(3*terms*sizeof(double)))) goto END;

    if (!(M=(double *)malloc(terms*equations*sizeof(double)))) goto END;
    memset(M,0,terms*equations*sizeof(double));

    if (!(I=(double *)malloc(equations*sizeof(double)))) goto END;
    memset(I,0,equations*sizeof(double));



    //check the polynomial order has been set properly
    n=PolynomialRegressors3DEx((double)(x0)/(dx*X),
                               (double)(y0)/(dy*Y),
                               (double)(z0)/(dz*Z),
                               R, TermOrder, order);

    if (n!=terms)
    {
        sprintf(txt,"n=%d",n);
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }



    //set the prior means and covariances
    memset(PriorMean,0,sizeof(double)*terms);
    memset(InvPriorCov,0,sizeof(double)*terms*terms);
    for (term=1; term<terms; term++)
    {
        InvPriorCov[terms*term+term]=1.0;
    }



    count=0;
    for (z=0; z<Z; z+=inc_z)
    {
        for (y=0; y<Y; y+=inc_y)
        {
            for (x=0; x<X; x+=inc_x)
            {
                voxel=x+y*X+z*X*Y;

                //image is nonzero
                if ((f=image[voxel])>0.0)
                {
                    n=PolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                             (double)(dy*y-y0)/fovy,
                                             (double)(dz*z-z0)/fovz,
                                             R, order);

                    //enter into the matrix
                    for (i=0; i<terms; i++) M[count*terms+i]=R[i];
                    I[count]=log(f);
                    count++;
                }
                //image is zero, constrain the gradient to be zero
                else
                {
                    n=GradPolynomialRegressors3D((double)(dx*x-x0)/fovx,
                                                 (double)(dy*y-y0)/fovy,
                                                 (double)(dz*z-z0)/fovz, R, order, terms);
                    for (i=0; i<terms; i++) M[count*terms+i]=0.1*R[i];
                    I[count]=0.0;
                    count++;
                    for (i=0; i<terms; i++) M[count*terms+i]=0.1*R[i+terms];
                    I[count]=0.0;
                    count++;
                    for (i=0; i<terms; i++) M[count*terms+i]=0.1*R[i+2*terms];
                    I[count]=0.0;
                    count++;

                }

            }
        }
    }


    //do Bayesian Regularisation
    BayesLinearRegression(I, M, param, count, terms, InvPriorCov, PriorMean);

    result=1;

END:
    if (M) free(M);
    if (I) free(I);
    if (R) free(R);
    if (InvPriorCov) free(InvPriorCov);
    if (PriorMean) free(PriorMean);

    return result;
}
