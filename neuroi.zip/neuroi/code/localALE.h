/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(ALE_H)
//Do Nothing
#else


#define ALE_H



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "loader.h"
#include "menuresources.h"


#define STUDYID_LABEL 0
#define CONTRAST_LABEL 1
#define CONDITION_LABEL 2

#define UNCORRECTED 0
#define CORRECTED 1


#define PET_STUDY 1
#define FMRI_STUDY 2
#define STRUCTURAL_STUDY 3
#define SPECT_STUDY 4

//percentiles, in terms of sigma, or 3D Normal
#define NSIGMA95 2.8//2.8 sigma is 95percentile
#define NSIGMA99 3.368//99th percentile
#define NSIGMA999 4.03//99.9th percentile


#define ZTYPE 1
#define PTYPE 2
#define TTYPE 3







struct KeyWord
{
    char txt[256];
};

struct Clusters{
  int TotalClusters;
  int *Nclusters;//number of clusters in experiment j = Nclusters[j]
  short int *experiment;//the experiment this cluster belongs to
  float *x;
  float *y;//coordintates of the cluster centres
  float *z;
  float *S;//spread of cluster j = S[j]
  float *MeanDist;//mean distance of foci from the centre
  int *Nfoci;//number of foci in cluster j = Nfoci[j]
};


HWND hCorrelateZ;
HWND hLocalALE;
HWND hTstatisticDOF;
HWND hClusterZ;
HWND hCBRESS;
HWND hCBMAN;



INT_PTR CALLBACK CorrelateZDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK ClusterZDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK CBRESS_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

int CountSignificantMApeaks(float x[], float y[], float z[], double p[], float ALEs[],
                            short int cluster[], int N, float sigma, double critical, int SigOnly);
int ClusterMA(float *distance, float *ALE, int N, int peak, float Shortest[], float MinDistance);




int CreateStructureMergeFile(HWND hwnd, char ExecDir[]);


struct Coordinates *CombineCoordinatess(struct Coordinates *A, struct Coordinates *B);

int ComputeDiagnosticBySpatialRandomisation(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float sigma, double critical, char directory[]);
int ComputeALEatFoci(struct Coordinates *ale, float dx, float dy, float dz, float ALEvalues[], float sigma, int StartFoci, int StopFoci);
int CreateExperimentMAmapALE(int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                             struct Coordinates *ale, int experiment, float MA[], float sigma, int UseClusters, double critical);
int ComputeCBRESdiagnosticBySpatialRandomisation(HWND hwnd, struct Coordinates *Co, float *mask, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float ClusteringDistance, char directory[]);



double EffectSize(double Z, int n1, int n2, int Use_t);




int FillClusterStructure(struct Coordinates *ale, struct Clusters *cl, float sigma);

int FreeCluster(struct Clusters *clust);
double FWHM_ALE(int Nexperiments);

int FociVoxelALE(float x, float y, float z, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0);

int IsContrastStudy(struct Coordinates *c);


int HomogeneityTest(HWND hwnd, struct Image *image);

INT_PTR CALLBACK LocalALEDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


double LateralizationTest(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float sigma, double critical, char directory[], int FCDR, int FCDRmode, double pmethod[], int SaveOutput);

double Nsigma(double percentile, double sigma);



int PaperALE_CBRES(struct Image *mask, struct Coordinates *ale, double mean, double sigma, int Studies, int Subjects, int Coordinates, double censor);
int TestPaperALE_CBRES(struct Image *mask, double mean, double sigma, int Studies, int Subjects, int Coordinates, double censor);

int RemoveNonGM(struct Image *Tal, char labels[], int LengthLabels, int BiggestLabel);
int RandomImageVoxel(float *mask, int voxels);
int RandomPointInVoxel(float *dx, float *dy, float *dz);
int TestRandomPointInVoxel(void);
int RandomiseFociInexperiment(float *mask, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, struct Coordinates *ale, int experiment);
int RandomiseFociRandomEffects(float *mask, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                                                        struct Coordinates *ale, struct Clusters *cl, float sigma);
int ReportClusters(HWND hwnd, struct Coordinates *ale, char directory[], char file[],  float ALE[], int X, int Y, int Z, float z0, float dz, float FWHM,
                   double critical, int FCDR, int MergeGroups, int Zfilter);


double SD_ALE(double FWHM);

double StudySD(double Z2sum, double Zsum, int Neffects, int Ngroup1, int Ngroup2, int contrast, int Use_t);

int SaveZscoreCorrelationsForAllClusters(HWND hwnd, struct Coordinates *ale, char directory[], char file[], double psig, int NumberOfClusters);
int SaveALE_MIP(HWND hwnd, struct Coordinates *ale, struct Image *image, char directory[], float sigma);

int Testpower_TTEST_SLR(double alpha,  double beta, int iterations, double sigmax, double sigmaerror, int samples);



//generating data for papers
int TestpClusterZ(HWND hwnd, struct Image *mask);
int PaperALEforExploringFWHM(struct Image *image, int reflect);
int PaperTestALEforROCcurve(struct Image *image, struct Coordinates *ale, int N, int save, char *TrueSig);
int TestPaperTestALEforROCcurve(HWND hwnd, struct Image *image, float fwhm, double alpha, int Computefwhm);
int TestSaveALEforROC(struct Image *image, int N);
int TestOfNullALEDifferenceSecondPlosPaper(struct Coordinates *ale, struct Image *image, int Nstudies, int Nclusters, int NfociPerStudy, int NrandomStudies);
int NullALEDifferenceSecondPlosPaper(HWND hwnd, struct Image *image);
int TestFociDistribution(struct Image *image);
int TestRandomEffectRandomisationScheme(HWND hwnd, struct Image *image);

int TestLocalALErandomExperiments(HWND hwnd, struct Image *image);
int TestLocalALEclosestFoci(HWND hwnd, struct Image *image);
int TestFillClusterStrucure(struct Image *image);
int TestLocalALErandomEffects(struct Image *image);
int TestLocalALErandomNonSignificantFoci(HWND hwnd, struct Image *image);
int TestRandomExperiment(struct Image *image);
int TestPermutations(struct Image *image);
int TestOfDifferences(struct Image *image, int Nexperiments, float sign, int fixed, int Nrandom);
int TestOfDifferences2(struct Image *image, int Nstudies, int Nclusters, int Nnull);
int TestOfDifferences3(struct Image *image, int Nstudies, int Nclusters, int Nrandom);
int TestMask(HWND hwnd, struct Image *image);
int TestVoxelWiseNullALEdistribution(HWND hwnd, struct Image *mask);
int TestVoxelWiseNullALEdistribution2(HWND hwnd, struct Image *mask);
int TestGingerAleFDR(struct Image *pimage, double q);
int TestGingerAleFDR2(struct Image *mask, double q);
int TestSDM_FDR(HWND hwnd, struct Image *mask, double q);
int TestUniformDistributionOfPvalues(HWND hwnd, struct Image *mask);
int TestSystematicAndRandomRealisationsOfALEfile(HWND hwnd, struct Image *mask);
int TestGetPvalueByPermutation(int nA, int nB, int nPos);
int TestRandomiseExperimentsIntoGroups(int nA, int nB, int pos);
int TestNumberOfOnes(int n);
int TestClusterZ(HWND hwnd, struct Image *mask, int model, int Use_t);

int TestMeanModelClusterZ(HWND hwnd, struct Image *mask);

int Test_Paper_NULL_Coordinates(struct Image *image,int Studies, int MaxCoordinates, double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor);
int TestNullRejectionOfClusterz(HWND hwnd, struct Image *image,double critical, int Studies, int MaxCoordinates, double CoordinateProportion,
                                int Subjects, int iterations, double Zthreshold, int Use_t, int SystematicClusters, double NotClustered);


#endif
