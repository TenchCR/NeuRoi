/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "coregister.h"
#include "ROIs.h"
#include "classification.h"
#include "global.h"
#include "localALE.h"

#define SCROLL_MAX 10
#define SCROLL_MIN 0




struct RegData gRegStruct;

int LoadNthMatchImage(HWND hwnd, struct Image *match, char names[], int n, int Nimages);
double DeviationFromIndependence(double p[], int parameters, void *regdata);
int SaveRegisteredImage(struct Image *Base, struct Image *Match, double p[], int Nparameters, int SAVEAS, int InterpolationMethod);
int RegCheck(double p[], struct RegData *dat, int Mode);
//=============================================================================================
//                           Coregistration dialog callback function
//                  Also uses 12 parameters for affine transformation
//=============================================================================================
INT_PTR CALLBACK CoregisterDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static double parameters[MAX_REGISTRATION_PARAMETERS];
    static int ParametersUsed;
    static int InterpolationMode;
    static int nMatchImages;
    static int SmoothImages;
    double SmoothWidth;
    double DefaultSmooth=1.0;
    int posinit,pos,im;
    static char ImageNames[MAX_PATH*5];
    static HCURSOR hourglass;
    struct BaseDims bd;
    HCURSOR	PrevCursor;
    unsigned char dummy;


    switch(msg)
        {


        case WM_CLOSE:
            SetMenuItemState(GetParent(hwnd), MF_ENABLED);

            //RELEASE MEMORY
            ReleaseRegData(&gRegStruct);

            hCoregisterDlg=(HWND)NULL;
            EndDialog(hwnd,0);
            break;


        case WM_SHOWWINDOW:
            if (SmoothImages)
                SendMessage(GetDlgItem(hwnd,ID_SMOOTH),BM_SETCHECK,BST_CHECKED,0);
            else
                SendMessage(GetDlgItem(hwnd,ID_SMOOTH),BM_SETCHECK,BST_UNCHECKED,0);
            break;


        case WM_INITDIALOG:
            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);

            SmoothImages=1;
            //PREPROCESS THE BASE IMAGE
            SmoothWidth=DefaultSmooth;///default value of smoothing
            if (SmoothImages) SmoothWidth=PRE_PROCESS_SMOOTH;
            if (!ProcessForRegistration(&gImage, SmoothWidth, CLASSES))
                SendMessage(hwnd, WM_CLOSE,0,0);

            SendMessage(GetDlgItem(hwnd,ID_RIGID),BM_SETCHECK,BST_CHECKED,0);
            ParametersUsed=RIGID6;
            InterpolationMode=ID_CUBIC;
            SendMessage(GetDlgItem(hwnd,InterpolationMode),BM_SETCHECK,BST_CHECKED,0);

            nMatchImages=0;
            SetMenuItemState(GetParent(hwnd), MF_GRAYED);


            //GET REGISTRATION SAMPLE POINTS
            if (!(gRegStruct.Points.used=GetTestPoints(&gRegStruct, gImage.img, gImage.charimg, gImage.X, gImage.Y, gImage.Z/gImage.volumes,
                                         gImage.dx, gImage.dy, gImage.dz, &dummy,0)))
                SendMessage(hwnd, WM_CLOSE,0,0);

            //INITIALISE THE PARAMETERS (zeros except for scale(=1))
            InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);

            //SETUP THE IMAGE MIX SCROLL BARS
            SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);
            SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX),SBM_SETPOS,SCROLL_MIN,TRUE);
            SetCursor(PrevCursor);
            SetFocus(GetParent(hwnd));
            break;





        case WM_HSCROLL:
            posinit = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
            switch (LOWORD(wParam))
                {
                case SB_LINELEFT:
                    SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-1), TRUE);
                    break;
                case SB_LINERIGHT:
                    SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+1), TRUE);
                    break;
                case SB_PAGELEFT:
                    SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-SCROLL_MAX/5), TRUE);
                    break;
                case SB_PAGERIGHT:
                    SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+SCROLL_MAX/5), TRUE);
                    break;
                case SB_THUMBTRACK:
                    SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam), TRUE);
                    break;
                }
            pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
            if (pos!=posinit)
                {
                    //SHOW MIXED IMAGE
                    ShowBaseMatchMix((HWND)GetParent(hwnd), &gImage, &gRegStruct.Match, gMainPict.slice,
                                     parameters, ParametersUsed, (double)pos/SCROLL_MAX, gMainPict.saturation);
                }
            SetFocus(GetParent(hwnd));
            break;





        case WM_COMMAND:
            switch (LOWORD(wParam))
                {


                case ID_SMOOTH:
                    if (SmoothImages)
                        {
                            SendMessage(GetDlgItem(hwnd,ID_SMOOTH),BM_SETCHECK,BST_UNCHECKED,0);
                            SmoothImages=0;
                            //PREPROCESS THE BASE IMAGE
                            if (!ProcessForRegistration(&gImage, DefaultSmooth, CLASSES))
                                SendMessage(hwnd, WM_CLOSE,0,0);///default smoothing
                        }
                    else
                        {
                            SendMessage(GetDlgItem(hwnd,ID_SMOOTH),BM_SETCHECK,BST_CHECKED,0);
                            SmoothImages=1;
                            //PREPROCESS THE BASE IMAGE
                            if (!ProcessForRegistration(&gImage, PRE_PROCESS_SMOOTH, CLASSES))
                                SendMessage(hwnd, WM_CLOSE,0,0);
                        }
                    //GET REGISTRATION SAMPLE POINTS
                    if (!(gRegStruct.Points.used=GetTestPoints(&gRegStruct, gImage.img, gImage.charimg, gImage.X, gImage.Y, gImage.Z/gImage.volumes,
                                                 gImage.dx, gImage.dy, gImage.dz, &dummy, 0)))
                        SendMessage(hwnd, WM_CLOSE,0,0);
                    break;

                //--------Get the Match image names-------------
                case ID_LOAD_MATCH:
                    nMatchImages=GetImageFileNames(ImageNames, MAX_PATH*5,"Select Match Image(s)");

                    if (nMatchImages)
                        {
                            if (!LoadNthMatchImage(GetParent(hwnd), &gRegStruct.Match, ImageNames, 1, nMatchImages))
                                MessageBox(NULL,"Load Failed","",MB_OK|MB_ICONWARNING);
                        }
                    SetFocus(GetParent(hwnd));
                    //sprintf(txt,"%d",nMatchImages);
                    //MessageBox(NULL,txt,"",MB_OK);
                    break;


                //--------Save the registered image-------------
                case ID_SAVE_REGISTERED:
                    PrevCursor=SetCursor(hourglass);
                    SaveRegisteredImage(&gImage, &gRegStruct.Match, parameters, ParametersUsed, 1, InterpolationMode);
                    SetCursor(PrevCursor);
                    SetFocus(GetParent(hwnd));
                    break;


                //--------Coregister----------------------------
                case ID_REGISTER:
                    EnableWindow(GetDlgItem(hwnd,ID_REGISTER),FALSE);
                    SmoothWidth=DefaultSmooth;///default value of smoothing
                    if (SmoothImages) SmoothWidth=PRE_PROCESS_SMOOTH;
                    PrevCursor=SetCursor(hourglass);
                    for (im=1; im<=nMatchImages; im++)
                        {
                            if (LoadNthMatchImage(GetParent(hwnd), &gRegStruct.Match, ImageNames, im, nMatchImages))
                                {
                                    if (ProcessForRegistration(&gRegStruct.Match, SmoothWidth, CLASSES))
                                        {
                                            MinimiseRegistrationError(GetParent(hwnd), GetDlgItem(hwnd, ID_RELATIVE_ERROR), parameters, ParametersUsed, &gRegStruct);
                                            if (nMatchImages>1)
                                                {
                                                    SaveRegisteredImage(&gImage, &gRegStruct.Match, parameters, ParametersUsed, 0, InterpolationMode);
                                                }
                                        }
                                }
                        }
                    SaveParameters("./registration parameters.txt", parameters, ParametersUsed, &gImage);
                    SetCursor(PrevCursor);
                    SetFocus(GetParent(hwnd));
                    //RegCheck(parameters, &gRegStruct, Mode);
                    EnableWindow(GetDlgItem(hwnd,ID_REGISTER),TRUE);
                    break;


                //--------Affine or Rigid-----------------------
                case ID_RIGID:
                    InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);
                    ParametersUsed=RIGID6;
                    SetFocus(GetParent(hwnd));
                    break;
                case ID_AFFINE:
                    InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);
                    ParametersUsed=AFFINE12;
                    SetFocus(GetParent(hwnd));
                    break;
                case ID_NONLINEAR:
                    InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);
                    ParametersUsed=REGISTRATION_PARAMETERS_ORDER5;
                    SetFocus(GetParent(hwnd));
                    break;

                //--------Nearest or Trilinear------------------
                case ID_CUBIC:
                case ID_TRILINEAR:
                case ID_NEAREST_NEIGHBOUR:
                    InterpolationMode=(int)LOWORD(wParam);
                    SetFocus(GetParent(hwnd));
                    break;

                //--------Reset the parameters------------------
                case ID_RESET_MATRIX:
                    InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);
                    SetFocus(GetParent(hwnd));
                    break;



                case ID_LOAD_MATRIX:
                    ParametersUsed = LoadParameters(parameters, MAX_REGISTRATION_PARAMETERS, &bd);
                    break;

                case IDOK:
                    SendMessage(hwnd, WM_CLOSE,0,0);
                    break;

                }
            break;


        }
    return 0;
}

//=============================================================================================
//release the memory allocated in struct RegData
//=============================================================================================
int ReleaseRegData(struct RegData *RD)
{
    ReleaseImage(&(*RD).Match);
    if ((*RD).PolyTerms)
        free((*RD).PolyTerms);
    if ((*RD).order)
        free((*RD).order);
    memset(RD,0,sizeof(struct RegData));

    return 1;
}




//=============================================================================================
//                      Load the nth Match image
//=============================================================================================
int LoadNthMatchImage(HWND hwnd, struct Image *match, char names[], int n, int Nimages)
{

    char name[MAX_PATH];


    if ((Nimages>1) && GetNthFileName(names, n, name))
        {
            //MessageBox(NULL,name,names,MB_OK);
            return LoadFromFileName(hwnd, name, match, 0);
        }
    else
        return LoadFromFileName(hwnd, names, match, 0);


//default
    return 0;
}
















///====================================
int GetTestPoints(struct RegData *RD, float *fimg, unsigned char ClassImg[], int X, int Y, int Zpv, float dx, float dy, float dz, unsigned char *mask, int UseMask)
{

    int voxel, voxels,n=0, Count;
    int x,y,z;
    unsigned char *points=NULL;
    double x0,y0,z0,xsd,ysd,zsd;
    float X0, Y0, Z0;
    float *filtered=NULL;

    voxels=X*Y*Zpv;

    memset(RD,0,sizeof(struct RegData));
    (*RD).PolyTerms=(double *)malloc(sizeof(double)*MAX_SAMPLE_POINTS*MAX_REGISTRATION_PARAMETERS/3);
    (*RD).order=(int *)malloc(sizeof(int)*MAX_REGISTRATION_PARAMETERS/3);
    if ((!((*RD).PolyTerms)) || (!((*RD).order)))
        {
            if ((*RD).PolyTerms)
                {
                    free((*RD).PolyTerms);
                    (*RD).PolyTerms=NULL;
                }
            if ((*RD).order)
                {
                    free((*RD).order);
                    (*RD).order=NULL;
                }
            return 0;
        }


    if (!(filtered=(float *)malloc(sizeof(float)*voxels)))
        goto END;

    memcpy(filtered,fimg,voxels*sizeof(float));


    //if a mask is being used then remove the unused voxels
    if (UseMask)
        {
            for (voxel=0; voxel<voxels; voxel++)
                {
                    if (!mask[voxel]) ClassImg[voxel]=0;
                }
        }


    for (voxel=0; voxel<voxels; voxel++)
    {
            if (!ClassImg[voxel])  filtered[voxel]=0.0;
    }

    points=(unsigned char *)malloc(voxels*sizeof(unsigned char));


    if (points)
        {

            X0=dx*X/2.0;
            Y0=dy*Y/2.0;
            Z0=dz*Zpv/2.0;

            memset(points,0,voxels);

            GetCentreOfImageIntensityF(filtered, X, Y, Zpv, &x0, &xsd, &y0, &ysd, &z0, &zsd);
            (*RD).x0=x0*dx-X0;
            (*RD).y0=y0*dy-Y0;//this is the centre of intensity
            (*RD).z0=z0*dz-Z0;


            //distribute the points randomly with gaussian distribution about the centre of intensity point
            //dont let points overlap
            n=Count=0;
            do
                {
                    x=(int)GaussRandomNumber_BoxMuller(x0, xsd);
                    y=(int)GaussRandomNumber_BoxMuller(y0, ysd);//random voxel index
                    z=(int)GaussRandomNumber_BoxMuller(z0, zsd);

                    voxel=x+y*X+z*X*Y;
                    if ((fabs(x0-x)/xsd<2.8) && (fabs(y0-y)/ysd<2.8) && (fabs(z0-z)/zsd<2.8) &&
                            InImageRange(x, y, z, X, Y, Zpv) && (!points[voxel]) && ClassImg[voxel])
                        {
                            (*RD).Points.x[n]=(dx*x-X0);
                            (*RD).Points.y[n]=(dy*y-Y0);//sample points are stored with the intensity centre as origin
                            (*RD).Points.z[n]=(dz*z-Z0);
                            (*RD).Points.cl[n]=ClassImg[voxel];

                            //pre-compute the polynomial terms for this point; these will not be changed during registration, so it speeds things up
                            //these need to be sorted with lowest order first
                            PolynomialRegressors3DTermOrderSorted((dx*x-X0), (dy*y-Y0), (dz*z-Z0),
                                                                  &(*RD).PolyTerms[n*MAX_REGISTRATION_PARAMETERS/3],
                                                                  (*RD).order, MAX_REGISTRATION_POLY_ORDER);

                            n++;
                            points[voxel]=1;
                        }
                    Count++;
                }
            while((n<MAX_SAMPLE_POINTS) && (Count<3*MAX_SAMPLE_POINTS));


//test the point selection scheme by saving points to visualise
            /* float *bak=NULL;
             bak=(float *)malloc(X*Y*Zpv*sizeof(float));
             memcpy(bak,gImage.img,X*Y*Zpv*sizeof(float));
             memset(gImage.img,0,X*Y*Zpv*sizeof(float));
             //quick test to check that the points were reasonably distributed
             for (voxel=0; voxel<voxels; voxel++)
             {
                 if (points[voxel])
                     gImage.img[voxel]=bak[voxel];
             }
             free(bak);*/



            free(points);
        }
    else
        return 0;//no points found because couldn't allocate memory



END:
    if (filtered)
        free(filtered);

    return n;
}








//=============================================================================================
//                  Get transformed coordinates
//                  given the current transformation matrix
//                  return voxel coordinates
//=============================================================================================
float GetTransformedVoxelCoordinates(float *x, float *y, float *z, float x0, float y0, float z0, float dx, float dy, float dz,
                                     struct AffineMatrix *M, double p[], double *poly, int Nparameters)
{

    float del;

    del = GetTransformedCoordinates(x, y, z, x0, y0, z0, dx, dy, dz, M, p, poly,  Nparameters);

    //convert to voxels
    (*x)=((*x)+x0)/dx;
    (*y)=((*y)+y0)/dy;
    (*z)=((*z)+z0)/dz;

    return del;
}

//=============================================================================================
//                  Get transformed coordinates
//                  given the current transformation matrix
//=============================================================================================
float GetTransformedCoordinates(float *x, float *y, float *z, float x0, float y0, float z0, float dx, float dy, float dz,
                                struct AffineMatrix *M, double p[], double *poly, int Nparameters)
{

    float del=0.0;
    float xl,yl,zl;
    int term;
    int Pterms=Nparameters/3;//there are three times as many parameters as there are polynomial terms because its 3D

    //------first have to do the affine transformation-----------
    AffineTransformCoordinates(x, y, z, M);

    xl=(*x);
    yl=(*y);
    zl=(*z);

    if (Nparameters>AFFINE12)
        {
            //------now add the nonlinear parts, using a polynomial-------
            double pterm;
            int termp;
            termp=12;
            for (term=4; term<Pterms; term++)
                {
                    pterm=poly[term];

                    (*x) += p[termp]*pterm;

                    (*y) += p[termp+1]*pterm;

                    (*z) += p[termp+2]*pterm;

                    termp += 3;
                }
            del=(xl-(*x))*(xl-(*x)) + (yl-(*y))*(yl-(*y)) + (zl-(*z))*(zl-(*z));
        }




    return del;
}






//=============================================================================================
//          Compute the voxel in the Match image space from the voxel
//              in the Base image space
//=============================================================================================
int MatchPositionFromBaseVoxel(struct Image *Match, struct Image *Base, int voxelB, float *xm, float *ym, float *zm, struct AffineMatrix *M,
                               double p[], int Nparameters, int PolyOrder)
{

    int x,y,z;
    float x0,y0,z0;
    double poly[MAX_REGISTRATION_PARAMETERS];
    int order[MAX_REGISTRATION_PARAMETERS];

    //the origin of the Match
    x0=(*Match).dx*(*Match).X/2;
    y0=(*Match).dy*(*Match).Y/2;
    z0=(*Match).dz*(*Match).Z/(*Match).volumes/2;

    //compute the voxel in the Match image space
    if (ComputeXYZfromVoxel(Base, voxelB, &x, &y, &z))
        {
            *xm=(*Base).dx*((float)x - (float)(*Base).X/2.0);
            *ym=(*Base).dy*((float)y - (float)(*Base).Y/2.0);
            *zm=(*Base).dz*((float)z - (float)(*Base).Z/(*Base).volumes/2.0);

            if (Nparameters>AFFINE12)
                PolynomialRegressors3DTermOrderSorted((*xm), (*ym), (*zm), poly, order, PolyOrder);

            GetTransformedVoxelCoordinates(xm, ym, zm, x0, y0, z0, (*Match).dx, (*Match).dy, (*Match).dz, M, p, poly, Nparameters);
        }
    return 1;
}

//=============================================================================================
//                  Process the image for registration
//                  the .img is unchanged on exit
//                  the .charimg is malloced and contains classes on exit
//=============================================================================================
int ProcessForRegistration(struct Image *image, double SmoothWidth, int Classes)
{


    int voxels=(*image).X*(*image).Y*(*image).Z;
    int voxelspv=voxels/(*image).volumes;
    int result = 0;
    float *fimg=NULL;
    double means[CLASSES];
    double max=(*image).MaxIntensity;


    if (!(*image).img)
        goto END;

//-----------------Backup the original-------------------------
    if (!(fimg=(float *)malloc(voxels*sizeof(float))))
        goto END;

    memcpy(fimg, (*image).img, voxels*sizeof(float));

    if ( (*image).charimg )
        {
            free((*image).charimg);
            (*image).charimg=NULL;
        }

    if (!((*image).charimg=(unsigned char *)malloc(voxelspv)))
        goto END;



    //----------------Smooth the image-----------------------------
    FilterImage(image, GAUSSIAN, SmoothWidth);
    (*image).MaxIntensity=max;


    //----------------Do the fuzzy clustering----------------------
    memset((*image).charimg,1,voxelspv);
    Fuzzy_cMeansClustering((*image).img, (*image).charimg, (*image).X, (*image).Y, (*image).Z/(*image).volumes,Classes, means, 100);

    //--------Replace the original image since we dont need the smoothed version-------
    memcpy((*image).img, fimg, voxels*sizeof(float));



    /*        //check the classification and smoothing
               int voxel;
                            for (voxel=0;voxel<voxels;voxel++){
                                if ((*image).charimg[voxel]) (*image).img[voxel]=(*image).charimg[voxel];
                            }
                            (*image).MaxIntensity=CLASSES;
    */

    result = 1;
END:

    if (fimg)
        free(fimg);

    return result;
}



//=============================================================================================
//                  Initialise the parameters
//=============================================================================================
int InitialiseRegistrationParameters(double param[], int N)
{

    memset(param,0,sizeof(double)*N);

    if (N>=AFFINE12)
        {
            param[SCALE]=1.0;
            param[SCALE+1]=1.0;
            param[SCALE+2]=1.0;
        }

    /*
                  param[ROTATE]=(double)PI*rand()/RAND_MAX/180.0;
                  param[ROTATE+1]=(double)PI*rand()/RAND_MAX/180.0;
                  param[ROTATE+2]=(double)PI*rand()/RAND_MAX/180.0;

                  param[TRANSLATE]=(double)2.0*rand()/RAND_MAX;
                  param[TRANSLATE+1]=(double)2.0*rand()/RAND_MAX;
                  param[TRANSLATE+2]=(double)2.0*rand()/RAND_MAX;
    */

    return 1;
}









//=============================================================================================
//                  Show mix of Base and Match Image
//                  Helps to check the register
//                  Modified 23/09/2010:
//                  Intensity normalisation changed to per slice normalisation of base and match
//=============================================================================================
#define PICT_SIZE 512
int ShowBaseMatchMix(HWND hwnd, struct Image *Base, struct Image *Match, int slice,
                     double p[], int Nparameters, double fraction, float saturation)
{

    struct BITMAPINFO256 bmpinf;
    int Xb,Yb,Zb;
    int width,height;
    int icol;
    int xi,yi;
    int Ib, Im, I;
    int checkX, checkY;
    int penX,penY;
    unsigned char *pict=NULL;
    float *MatchReg=NULL;
    float max, maxb;
    float scale;
    float dx,dy,dz;
    float xf, yf, zf;
    HDC hMemDC, hDC=GetDC(hwnd);
    HBITMAP hbmp, hOldbmp;
    struct AffineMatrix Amat;
    int *polyorder=NULL;
    double *poly=NULL;

    if ((!(*Match).X) || (!(*Match).Y) || (!(*Match).Z) || (!(*Match).volumes))
        return 0;


    if (!(poly=(double *)malloc(MAX_REGISTRATION_PARAMETERS/3*sizeof(double))))
        goto END;
    if (!(polyorder=(int *)malloc(MAX_REGISTRATION_PARAMETERS/3*sizeof(int))))
        goto END;


    memset(&Amat,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6)
        Amat=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nparameters==RIGID6)
        Amat=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);


    Xb=(*Base).X;
    Yb=(*Base).Y;
    Zb=(*Base).Z/(*Base).volumes;
    if (slice>Zb)
        slice=Zb/2;

    dx=(*Base).dx;
    dy=(*Base).dy;
    dz=(*Base).dz;

    width=Xb+(4-Xb%4);
    height=Yb;

    if (!(pict=(unsigned char *)malloc(width*height)))
        goto END;

    memset(pict,0,width*height);





    hMemDC=CreateCompatibleDC(hDC);

    memset(&bmpinf,0,sizeof(struct BITMAPINFO256));      //null the structure to start with

    bmpinf.bmiHdr.biSize=sizeof(BITMAPINFOHEADER);
    bmpinf.bmiHdr.biWidth=width;
    bmpinf.bmiHdr.biHeight=height;
    bmpinf.bmiHdr.biPlanes=1;
    bmpinf.bmiHdr.biBitCount=8;
    bmpinf.bmiHdr.biCompression=BI_RGB;
    bmpinf.bmiHdr.biClrUsed=256;


    //--------arrange the grey scale part of the colour map---------
    for (icol=0; icol<256; icol++)
        {
            bmpinf.bmicolours[icol].rgbRed=icol;
            bmpinf.bmicolours[icol].rgbGreen=icol;
            bmpinf.bmicolours[icol].rgbBlue=icol;
        }



    //GET THE RESAMPLED MATCH SLICE
    MatchReg=(float *)malloc(Xb*Yb*sizeof(float));
    max=maxb=0.0;
    if (!MatchReg)
        goto END;
    for (yi=0; yi<Yb; yi++)
        {
            for (xi=0; xi<Xb; xi++)
                {
                    xf=dx*(xi-Xb/2);
                    yf=dy*(yi-Yb/2);
                    zf=dz*(slice-Zb/2);


                    if (Nparameters>AFFINE12)
                        {
                            PolynomialRegressors3DTermOrderSorted(xf,yf,zf,poly,polyorder,MAX_REGISTRATION_POLY_ORDER);

                            GetTransformedVoxelCoordinates(&xf, &yf, &zf, (*Match).dx*(*Match).X/2.0, (*Match).dy*(*Match).Y/2.0, (*Match).dz*(*Match).Z/2.0/(*Match).volumes,
                                                           (*Match).dx, (*Match).dy, (*Match).dz, &Amat, p, poly, Nparameters);
                        }
                    else
                        GetTransformedVoxelCoordinates(&xf, &yf, &zf, (*Match).dx*(*Match).X/2.0, (*Match).dy*(*Match).Y/2.0, (*Match).dz*(*Match).Z/2.0/(*Match).volumes,
                                                       (*Match).dx, (*Match).dy, (*Match).dz, &Amat, p, poly, Nparameters);


                    MatchReg[xi+yi*Xb] = InterpolateImage(Match, 0, xf, yf, zf, ID_TRILINEAR);

                    if (MatchReg[xi+yi*Xb]>max)
                        max=MatchReg[xi+yi*Xb];
                    if ((*Base).img[xi + yi*Xb + slice*Xb*Yb]>maxb)
                        maxb=(*Base).img[xi + yi*Xb + slice*Xb*Yb];
                }
        }
    //sprintf(txt,"%f %f",max,maxb);
    //MessageBox(NULL,txt,"",MB_OK);
    if (max<=0.0)
        max=1.0;//TO PREVENT /ZERO
    if (maxb<=0.0)
        maxb=1.0;//TO PREVENT /ZERO



    checkX=checkY=penX=penY=0;
    scale=(double)PICT_SIZE/Xb;
    if (((double)PICT_SIZE/Yb)<scale)
        scale=(double)PICT_SIZE/Yb;
    if (saturation<=0.0)
        saturation=1.0;
    for (yi=0; yi<Yb; yi++)
        {
            checkX=0;
            penX=0;
            if (checkY>Yb/2)
                {
                    checkY=0;
                    penY=(penY==1)?0:1;
                }
            for (xi=0; xi<Xb; xi++)
                {

                    Im=255*MatchReg[xi+yi*Xb]/max/saturation;

                    Ib=255*(*Base).img[xi + yi*Xb + slice*Xb*Yb]/saturation/maxb;
                    I=(1.0-fraction)*Ib + fraction*Im;
                    if (I>255)
                        I=255;


                    //PRODUCES CHECKERBOARD EFFECT
                    if (checkX>Xb/2)
                        {
                            checkX=0;
                            penX=(penX==1)?0:1;
                        }

                    if (fraction<1.0e-6)//floating point fraction=0.0
                        {
                            if (penX+penY==1)
                                pict[xi+yi*width]=(char)Ib;
                            else
                                pict[xi+yi*width]=(char)Im;
                        }
                    else
                        pict[xi+yi*width]=(char)I;
                    //pict[xi+yi*width]=(char)I;

                    checkX++;
                }
            checkY++;
        }


    hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&bmpinf.bmiHdr, CBM_INIT, pict,
                          (LPBITMAPINFO)&bmpinf, DIB_RGB_COLORS  );
    hOldbmp=SelectObject(hMemDC, hbmp);


    StretchBlt(hDC, 20, 50, (int)(scale*width), (int)(scale*height), hMemDC, 0,0, width, height, SRCCOPY);

    SelectObject(hMemDC, hOldbmp);
    DeleteObject(hbmp);


END:

    if (pict)
        free(pict);

    if (MatchReg)
        free(MatchReg);

    if (poly)
        free(poly);

    if (polyorder)
        free(polyorder);

    return 1;
}









//=============================================================================================
//                  Compute the relative quality of the registration
//                  Uses P(AB)=P(A)P(B), which is true for independent random variables
//                  p[] contains the parameters for the transformation
//                  Nearest neighbour interpolation is used at the match image
//=============================================================================================
double DeviationFromIndependence(double p[], int Nparameters, void *regdata)
{

    struct RegData *dat=(struct RegData *)regdata;
    float x,y,z;
    float del=0.0;
    float x0,y0,z0;
    int xi,yi,zi, voxel, point, pointIndex, paramIndex, count;
    int RegParametersPerDimension=MAX_REGISTRATION_PARAMETERS/3;
    int Imatch,Ibase,o;
    int A[(CLASSES+1)*(CLASSES+1)];
    int Base[CLASSES+1], Match[CLASSES+1];
    int Zpv=(*dat).Match.Z/(*dat).Match.volumes;
    int XY=(*dat).Match.X*(*dat).Match.Y;
    int NonLin=(Nparameters>AFFINE12) ? 1:0;
    double Err, E_A, tmp;
    double f;
    int PointsUsed=(*dat).Points.used;
    struct AffineMatrix M;
    //FILE *fp;

    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6)
        M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nparameters==RIGID6)
        M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);


    x0=(*dat).Match.dx*(*dat).Match.X/2.0;
    y0=(*dat).Match.dy*(*dat).Match.Y/2.0;
    z0=(*dat).Match.dz*(*dat).Match.Z/2.0/(*dat).Match.volumes;

    memset(A,0,sizeof(int)*(CLASSES+1)*(CLASSES+1));
    memset(Base,0,sizeof(int)*(CLASSES+1));
    memset(Match,0,sizeof(int)*(CLASSES+1));

    count=0;
    pointIndex=0;
    paramIndex=0;
    for (point=0; point<PointsUsed; point++)
        {

            x=(*dat).Points.x[point];
            y=(*dat).Points.y[point];//random points chosen at initialisation
            z=(*dat).Points.z[point];

            if (NonLin)
                {
                    del += GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0,(*dat).Match.dx, (*dat).Match.dy, (*dat).Match.dz, &M, p,
                                                          &(*dat).PolyTerms[paramIndex], Nparameters);
                }
            else
                GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0,(*dat).Match.dx, (*dat).Match.dy, (*dat).Match.dz, &M, p,
                                               (*dat).PolyTerms, Nparameters);


            xi=(int)(x+0.5);
            yi=(int)(y+0.5);//nearest neighbour interpolation used
            zi=(int)(z+0.5);


            //this computes a table of class coincidences. If there is no relationship between the images, then this should be
            //distributed such that the classes in the match are evenly distributed over the classes in the base
            if (InImageRange(xi, yi, zi, (*dat).Match.X, (*dat).Match.Y, Zpv))
                {
                    voxel=xi + yi*(*dat).Match.X + zi*XY;
                    Ibase=(int)(*dat).Points.cl[point];
                    Imatch=(int)(*dat).Match.charimg[voxel];
                    if ((Imatch))
                        {
                            A[Ibase+Imatch*(CLASSES+1)]++;
                            Base[Ibase]++;
                            Match[Imatch]++;
                            count++;
                        }
                }

            pointIndex += RegParametersPerDimension;
            paramIndex += MAX_REGISTRATION_PARAMETERS/3;
        }

    if (!count)
        return 0.0;



    Err=0.0;
    for (Imatch=1; Imatch<=CLASSES; Imatch++)
        {
            o=Imatch*(CLASSES+1);
            f=(double)Match[Imatch]/count;
            for (Ibase=1; Ibase<=CLASSES; Ibase++)
                {

                    E_A=f*Base[Ibase];
                    //Like Pearsons chisquare statistic, which is chi^2_1 distributed
                    tmp=(double)A[Ibase + o]-E_A;
                    if (E_A>0.0)
                        {
                            Err += tmp*tmp/E_A;
                        }

                }
        }


    /*
        if ((fp=fopen("c:\\temp\\A.csv","w")))
            {
                for (Imatch=1; Imatch<=CLASSES; Imatch++)
                {
                    o=Imatch*(CLASSES+1);
                    for (Ibase=1; Ibase<=CLASSES; Ibase++)
                    {
                        fprintf(fp,"%d,",A[o + Ibase]-Match[Imatch]*Base[Ibase]/count);
                    }
                    fprintf(fp,"%d\n",Match[Imatch]);
                }
                    fclose(fp);
            }
    */


    //count=1;
    if (NonLin) return -Err/count + del/count/10;
    else return -Err/count;
}








//=============================================================================================
//                  Mode is ID_AFFINE or ID_RIGID
//                  Use down hill simplex to find registration parameters
//                  Added 23/09/2010
//=============================================================================================
double MinimiseRegistrationError(HWND hWnd, HWND hwnddlgitm, double V[], int Nparameters, struct RegData *dat)
{

    double E, Einitial, E1;
    double scale[MAX_REGISTRATION_PARAMETERS];//the maximum number of parameters
    double tmp;
    double Vtry[6];
    int i, j;
    int Nshrinks=40;
    char txt[256];

    if (!((*dat).Match.X) || !((*dat).Match.Y) || !((*dat).Match.Z) || !((*dat).Match.volumes))
        return 0.0;

    Einitial=E=DeviationFromIndependence(V, RIGID6, dat);


    //initialize the scale to describe the sort of scaling to use during the search
    memset(scale,0,sizeof(double)*MAX_REGISTRATION_PARAMETERS);



    scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=10.0;
    scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=PI/9.0;


    for (i=0; i<50; i++)
        {
            for (j=0; j<3; j++)
                {
                    Vtry[j]=V[j]  -0.3 + 0.6*rand()/RAND_MAX;
                }
            for (j=3; j<6; j++)
                {
                    Vtry[j]=V[j]  -5.0 + 10.0*rand()/RAND_MAX;
                }
            E=DeviationFromIndependence(Vtry, RIGID6, dat);
            if (E<Einitial)
                {
                    if (hWnd)
                        ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                         Vtry, RIGID6, 0.5, gMainPict.saturation);
                    Einitial=E;
                    memcpy(V,Vtry,sizeof(double)*6);
                }
        }

    //do a fast 6 parameter search first to, hopefully, get near to the minimum
    if (Nparameters>=RIGID6)
        {
            do
                {
                    E1=E;

                    E=DownHillSimplex(V, RIGID6, scale, 1,DeviationFromIndependence, dat, Nshrinks);
                    //output the error change
                    if (hwnddlgitm)
                        {
                            sprintf(txt,"%f rigid",E-Einitial);
                            SendMessage(hwnddlgitm,WM_SETTEXT,0,(LPARAM)txt);
                            UpdateWindow(hwnddlgitm);
                        }

                    if (hWnd)
                        ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                         V, RIGID6, 0.5, gMainPict.saturation);
                }
            while(E1-E>1.0e-5);
            if (hWnd)
                ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                 V, RIGID6, 0.5, gMainPict.saturation);
            //sprintf(txt,"%f rigid",E-Einitial);
            //MessageBox(NULL,txt,"",MB_OK);

        }



    if (Nparameters>=AFFINE12)//nonlinear registration bits here
        {

            scale[SCALE]=scale[SCALE+1]=scale[SCALE+2]=0.1;
            scale[SHEAR]=scale[SHEAR+1]=scale[SHEAR+2]=0.1;
            scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=5.0;
            scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=PI/36.0;

            do
                {
                    E1=E;
                    E=DownHillSimplex(V, AFFINE12, scale, 1,DeviationFromIndependence, dat, Nshrinks);
                    //output the error change
                    if (hwnddlgitm)
                        {
                            sprintf(txt,"%f affine",E-Einitial);
                            SendMessage(hwnddlgitm,WM_SETTEXT,0,(LPARAM)txt);
                            UpdateWindow(hwnddlgitm);
                        }
                    if (hWnd)
                        ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                         V, AFFINE12, 0.5, gMainPict.saturation);
                }
            while(E1-E>1.0e-5);

            if (hWnd)
                ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                 V, AFFINE12, 0.5, gMainPict.saturation);

            //sprintf(txt,"%f affine",E-Einitial);
            //MessageBox(NULL,txt,"",MB_OK);

        }




    if (Nparameters>AFFINE12)//nonlinear registration bits here
        {
            //should be reasonably close to registered now, so reset the scale
            scale[SCALE]=scale[SCALE+1]=scale[SCALE+2]=0.05;
            scale[SHEAR]=scale[SHEAR+1]=scale[SHEAR+2]=0.05;
            scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=1.0;
            scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=PI/90.0;
            //set the scale for the nonlinear parameters
            for (i=4; i<Nparameters/3; i++)
                {

                    tmp = 100.0*((*dat).order[i]+1)/pow(50.0,(*dat).order[i]+1);//this is about 1/100th the average of x^order   (2.0*\int{x^order dx}_{0}^{X/2})/X
                    scale[3*i] = tmp;
                    scale[3*i + 1] = tmp;
                    scale[3*i + 2] = tmp;
                }
            ScaleInitialisation(V, Nparameters, 0.1, scale, DeviationFromIndependence, dat);


            if (Nparameters>=REGISTRATION_PARAMETERS_ORDER2)
                {
                    E=DownHillSimplex(V, REGISTRATION_PARAMETERS_ORDER2, scale, 1,DeviationFromIndependence, dat, 10);
                    if (hwnddlgitm)
                        {
                            sprintf(txt,"%f (2)",E-Einitial);
                            SendMessage(hwnddlgitm,WM_SETTEXT,0,(LPARAM)txt);
                            UpdateWindow(hwnddlgitm);
                        }
                    if (hWnd)
                        ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                         V, REGISTRATION_PARAMETERS_ORDER2, 0.5, gMainPict.saturation);
                }
            if (Nparameters>=REGISTRATION_PARAMETERS_ORDER3)
                {
                    E=DownHillSimplex(V, REGISTRATION_PARAMETERS_ORDER3, scale, 1,DeviationFromIndependence, dat, 10);
                    if (hwnddlgitm)
                        {
                            sprintf(txt,"%f (3)",E-Einitial);
                            SendMessage(hwnddlgitm,WM_SETTEXT,0,(LPARAM)txt);
                            UpdateWindow(hwnddlgitm);
                        }
                    if (hWnd)
                        ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                         V, REGISTRATION_PARAMETERS_ORDER3, 0.5, gMainPict.saturation);
                }
            ///Final registration with all parameters
            E=DownHillSimplex(V, Nparameters, scale, 1,DeviationFromIndependence, dat, 10);

            //output the error change
            if (hwnddlgitm)
                {
                    sprintf(txt,"%f (%d)",E-Einitial, (*dat).order[Nparameters/3-1]);
                    SendMessage(hwnddlgitm,WM_SETTEXT,0,(LPARAM)txt);
                    UpdateWindow(hwnddlgitm);
                }
            if (hWnd)
                ShowBaseMatchMix(hWnd, &gImage, &gRegStruct.Match, gMainPict.slice,
                                 V, Nparameters, 0.5, gMainPict.saturation);

        }

    return E-Einitial;
}






//=============================================================================================
//              Check the error function near the optimum
//=============================================================================================
int RegCheck(double p[], struct RegData *dat, int Mode)
{

    double original[AFFINE12];
    double scale[AFFINE12];
    int params;
    int parameter, offset;
    FILE *fp;

    if (!(fp=fopen("c:/temp/regcheck.txt","w")))
        return 0;



    if (Mode==ID_AFFINE)
        params=AFFINE12;
    else
        params=RIGID6;


    memset(scale,0,sizeof(double)*AFFINE12);
    if (Mode==ID_AFFINE)
        {
            scale[SCALE]=scale[SCALE+1]=scale[SCALE+2]=0.001;
            scale[SHEAR]=scale[SHEAR+1]=scale[SHEAR+2]=0.001;
        }

    scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=0.1;
    scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=0.1*PI/180.0;


    params=RIGID6;
    memcpy(original, p, sizeof(double)*params);
    for (offset=0; offset<101; offset++)
        {
            fprintf(fp,"%d ",offset-50);
            for (parameter=0; parameter<params; parameter++)
                {
                    memcpy(p, original, sizeof(double)*params);
                    p[parameter]+=(offset-50)*10*scale[parameter];
                    //if (Mode==ID_AFFINE) M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
                    //else M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);
                    fprintf(fp,"%f ",DeviationFromIndependence(p, AFFINE12, dat));
                }
            fprintf(fp,"\n");
        }

    memcpy(p, original, sizeof(double)*params);
    fclose(fp);
    return 1;
}







//=============================================================================================
//                  Save the Registered image
//                  if SAVEAS, get the filename from the user
//                  otherwise, append the Base image name to the Match image name
//                  p[] are the parameters
//=============================================================================================
int SaveRegisteredImage(struct Image *Base, struct Image *Match, double p[], int Nparameters, int SAVEAS, int InterpolationMethod)
{

    struct Image tmp;
    char FileTitle[MAX_PATH];
    int result=0;

    memset(&tmp, 0, sizeof(struct Image));
    if (!MakeCopyOfImage(Match, &tmp))
        goto END;


    if (!ReformatMatchImage((*Base).X, (*Base).Y, (*Base).Z/(*Base).volumes, (*Base).dx, (*Base).dy, (*Base).dz,
                            (*Base).x0, (*Base).y0, (*Base).z0, &tmp, p, Nparameters, InterpolationMethod))
        goto END;

    if ((*Base).ImageType==NIFTI)
        {
            memcpy(&tmp.nifti, &(*Base).nifti, sizeof(struct nifti_1_header));
            tmp.ImageType=NIFTI;
            sprintf(tmp.Descrip,"%s_reg",tmp.Descrip);
        }

    if (SAVEAS)
        SaveAs(&tmp);
    else
        {
            //generate the filename
            GetFileTitle((*Base).filename, FileTitle, MAX_PATH);
            tmp.filename[strlen(tmp.filename)-4]='\0';
            if (tmp.ImageType==HDR)
                {
                    sprintf(tmp.filename,"%s_REG_%s.img",tmp.filename,FileTitle);
                    tmp.headername[strlen(tmp.headername)-4]='\0';
                    sprintf(tmp.headername,"%s_REG_%s.hdr",tmp.headername,FileTitle);
                }
            else
                sprintf(tmp.filename,"%s_REG_%s.nii",tmp.filename,FileTitle);
            Save(&tmp);
        }
    //Now save the parameters with the same name (but a .txt file)
    SaveParameters(tmp.filename, p, Nparameters, Base);

    result=1;
END:
    ReleaseImage(&tmp);

    return result;
}










//=============================================================================================
//                      Save the parameters to file
//                      imagename is the name of the image that has been registered
//                      the parameter filename is created from this
//=============================================================================================
int SaveParameters(char imagename[], double p[], int N, struct Image *Base)
{

    struct AffineMatrix M;
    int i,j;
    char paramfile[MAX_PATH];
    double T[4*4];
    FILE *fp;

    memset(&M,0,sizeof(struct AffineMatrix));
    if (N>RIGID6)
        M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (N==RIGID6)
        M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);

    sprintf(paramfile,"%s",imagename);
    paramfile[strlen(paramfile)-4]='\0';
    sprintf(paramfile,"%s_reg_parameters.txt",paramfile);
    if ( (fp=fopen(paramfile,"w")) )
        {
            for (i=0; i<N; i++)
                fprintf(fp,"%g\n",p[i]);
            fprintf(fp,"#\n");
            fprintf(fp,"%d\n",(*Base).X);
            fprintf(fp,"%d\n",(*Base).Y);
            fprintf(fp,"%d\n",(*Base).Z/(*Base).volumes);
            fprintf(fp,"%f\n",(*Base).dx);
            fprintf(fp,"%f\n",(*Base).dy);
            fprintf(fp,"%f\n",(*Base).dz);

            fprintf(fp,"\n\n\n");
            fprintf(fp,"Transformation matrix (transforms base image coordinates to match space)\n");
            for (j=0; j<4; j++)
                {
                    for (i=0; i<4; i++)
                        {
                            fprintf(fp,"%f ",M.M[j][i]);
                            T[i+j*4]=M.M[j][i];
                        }
                    fprintf(fp,"\n");
                }


            InvertMatrixA(T, 4);
            fprintf(fp,"\n\n\n");
            fprintf(fp,"Inverse Transformation matrix\n");
            for (j=0; j<4; j++)
                {
                    for (i=0; i<4; i++)
                        {
                            fprintf(fp,"%f ",T[j+i*4]);
                        }
                    fprintf(fp,"\n");
                }

            fclose(fp);
        }
    else
        return 0;

    return 1;
}



//=============================================================================================
//                  Load the parameters from a file
//                  N is the length of array p[]
//                  Returns the number of parameters in the file
//=============================================================================================
int LoadParameters(double p[], int N, struct BaseDims *bd)
{

    int params;
    FILE *fp;
    char filename[MAX_PATH];
    char txt[256];
    OPENFILENAME fnamedlg;

    memset(bd, 0, sizeof(struct BaseDims));
    memset(&fnamedlg,0,sizeof(OPENFILENAME));


    filename[0]='\0';


    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="text Files\0*.txt;\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=filename;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Select parameter file";
    fnamedlg.lpstrDefExt="txt";

    memset(p,0,sizeof(double)*N);
    //InitialiseRegistrationParameters(p, N);


    if(GetOpenFileName(&fnamedlg))
        {
            if ( (fp=fopen(filename,"r")) )
                {
                    params=0;
                    txt[0]='\0';
                    while((!feof(fp)) && (txt[0]!='#'))
                        {
                            fscanf(fp,"%s", txt);
                            if ((txt[0]!='#'))
                                {
                                    if (params<N)
                                        {
                                            p[params]=atof(txt);//load the parameters here only if valid
                                            params++;
                                        }
                                }
                        }
                    if (txt[0]=='#') //the base dimensions have been saved
                        {
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).X=atoi(txt);
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).Y=atoi(txt);
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).Zpv=atoi(txt);
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).dx=atof(txt);
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).dy=atof(txt);
                            if (fscanf(fp,"%s", txt)!=EOF)
                                (*bd).dz=atof(txt);
                            (*bd).x0=(*bd).X*(*bd).dx/2.0;
                            (*bd).y0=(*bd).Y*(*bd).dy/2.0;
                            (*bd).z0=(*bd).Zpv*(*bd).dz/2.0;
                            //sprintf(txt,"%d %d %d %f %f %f",(*bd).X, (*bd).Y, (*bd).Zpv, (*bd).dx, (*bd).dy, (*bd).dz);
                            //MessageBox(NULL,txt,"",MB_OK);
                        }
                    fclose(fp);
                }
            else
                return 0;
        }
    else
        return 0;

    return params;

}





//=============================================================================================
//                  Reformat the image
//                  BX, BY, BZ, etc, are the parameters of the base image
//                  Bxorg etc are the origin of the Base image origin to save in the resampled image
//                      header
//=============================================================================================
int ReformatMatchImage(int BX, int BY, int BZ, float Bdx, float Bdy, float Bdz, float Bxorg, float Byorg, float Bzorg,
                       struct Image *Match, double p[], int Nparameters, int InterpolationMethod)
{

    struct AffineMatrix M;
    struct Image tmp;
    float x0,y0,z0;
    float dx, dy, dz;
    float targdx, targdy,targdz;
    float xf,yf,zf;
    double *poly=NULL;
    int PolyOrder;
    int *polyorder=NULL;
    int x,y,z,volume, voxel, voxeltmp,volumeoffset;
    int X,Y,Z,XYZ;
    int result=0;




    //Find the order of the polynomial
    if ( (Nparameters==RIGID6) || (Nparameters==AFFINE12) )
        PolyOrder=1;
    else
        {
            PolyOrder=2;
            while( (PolyOrder<MAX_REGISTRATION_POLY_ORDER) && (Nparameters!=TermsInNthorderDdimensionPolynomial(PolyOrder, 3)) )
                {
                    PolyOrder++;
                }
        }
    if (PolyOrder>MAX_REGISTRATION_POLY_ORDER)
        goto END;




    memset(&tmp,0,sizeof(struct Image));




    if (!(poly=(double *)malloc(Nparameters/3*sizeof(double))))
        goto END;
    if (!(polyorder=(int *)malloc(Nparameters/3*sizeof(int))))
        goto END;




    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6)
        M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nparameters==RIGID6)
        M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);




    //record the origin before resampling
    dx=(*Match).dx;
    dy=(*Match).dy;
    dz=(*Match).dz;
    x0=dx*(*Match).X/2.0;
    y0=dy*(*Match).Y/2.0;
    z0=dz*(*Match).Z/2.0/(*Match).volumes;





    //Get an image to resample the Match to
    //the resampled image will be registered to the Base Image
    //Its voxel dimensions will be the smaller of the Match and Base dimensions
    targdx=( Bdx<dx ) ? Bdx:dx;
    targdy=( Bdy<dy ) ? Bdy:dy;//compute the target voxel sizes
    targdz=( Bdz<dz ) ? Bdz:dz;
    //the dimensions of the resampled image have the same FOV (or bigger) of the Base image
    X=(int)((Bdx*BX)/targdx)+1;
    Y=(int)((Bdy*BY)/targdy)+1;
    Z=(int)((Bdz*BZ)/targdz)+1;
    XYZ=X*Y*Z;
    MakeImage(&tmp, X, Y, Z, (*Match).volumes, targdx,targdy, targdz, Bxorg, Byorg, Bzorg,
              (*Match).scale, (*Match).offset, (*Match).DataType, HDR, (*Match).Descrip);
    //copy Base header to the registered image so the saved file is the same type
    tmp.ImageType=HDR;
    sprintf(tmp.PatientID,"%s",(*Match).PatientID);
    tmp.swapbytes=0;
    tmp.changed=1;//make sure the header gets updated



    //resample into the new space
    voxel=0;
    for (z=0; z<Z; z++)
        {
            for (y=0; y<Y; y++)
                {
                    for (x=0; x<X; x++)
                        {
                            //voxel=x + y*X + z*X*Y;
                            xf=targdx*x - Bdx*BX/2;
                            yf=targdy*y - Bdy*BY/2;
                            zf=targdz*z - Bdz*BZ/2;

                            if (Nparameters>AFFINE12)
                                PolynomialRegressors3DTermOrderSorted(xf,yf,zf,poly,polyorder,PolyOrder);

                            GetTransformedVoxelCoordinates(&xf, &yf, &zf, x0, y0, z0, (*Match).dx, (*Match).dy, (*Match).dz, &M, p,
                                                           poly, Nparameters);

                            volumeoffset=0;
                            for (volume=0; volume<(*Match).volumes; volume++)
                                {
                                    //lagrange interpolate
                                    tmp.img[voxel+volumeoffset]=InterpolateImage(Match, volume, xf, yf, zf, InterpolationMethod);
                                    if (tmp.img[voxel+volumeoffset]<0.0)
                                        tmp.img[voxel+volumeoffset]=0.0;
                                    volumeoffset+=XYZ;
                                }
                            voxel++;
                        }
                }
        }


    //resize this image to match the Base image
    if (InterpolationMethod==ID_NEAREST_NEIGHBOUR)
        ReSampleImage(&tmp, Bdx, Bdy, Bdz);
    else
        ReSizeImage(&tmp, Bdx, Bdy, Bdz);



    //now save the resampled tmp image to the Match image
    free( (*Match).img );
    (*Match).img=NULL;
    (*Match).img=(float *)malloc(BX*BY*BZ*(*Match).volumes*sizeof(float));
    if (!((*Match).img))
        goto END;
    (*Match).X=BX;
    (*Match).Y=BY;
    (*Match).Z=BZ*(*Match).volumes;
    (*Match).dx=Bdx;
    (*Match).dy=Bdy;
    (*Match).dz=Bdz;
    (*Match).x0=Bxorg;
    (*Match).y0=Byorg;
    (*Match).z0=Bzorg;
    (*Match).MaxIntensity=0.0;
    voxel=0;
    for (z=0; z<BZ; z++)
        {
            for (y=0; y<BY; y++)
                {
                    for (x=0; x<BX; x++)
                        {
                            //voxel=x + y*BX + z*BX*BY;
                            volumeoffset=0;
                            for (volume=0; volume<(*Match).volumes; volume++)
                                {
                                    if (InImageRange(x,y,z, tmp.X, tmp.Y, tmp.Z/tmp.volumes))
                                        {
                                            voxeltmp=x+y*tmp.X+z*tmp.X*tmp.Y;
                                            (*Match).img[voxel+volumeoffset]=tmp.img[voxeltmp+volume*tmp.X*tmp.Y*tmp.Z/tmp.volumes];
                                            if ((*Match).img[voxel+volumeoffset]>(*Match).MaxIntensity)
                                                (*Match).MaxIntensity=(*Match).img[voxel+volumeoffset];
                                            if ((*Match).img[voxel+volumeoffset]<0.0)
                                                (*Match).img[voxel+volumeoffset]=0.0;
                                        }
                                    else (*Match).img[voxel+volumeoffset]=0.0;
                                    volumeoffset+=BX*BY*BZ;
                                }
                            voxel++;
                        }
                }
        }


    result=1;
END:
    ReleaseImage(&tmp);
    if (poly)
        free(poly);
    if (polyorder)
        free(polyorder);

    return result;
}

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//=============================================================================================
//                      -Register two images together
//                      -return the transformation parameters in p[]
//=============================================================================================
int RegisterTwoImagesP(HWND hwnd, struct Image *Base, struct Image *Match, double p[], int Nparameters, double SmoothWidth, unsigned char *mask, int UseMask)
{
    int result=0;
    double Err;
    char txt[256];
    HDC hDC;
    HCURSOR hourglass, PrevCursor;

    ReleaseRegData(&gRegStruct);

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);

    if (!ProcessForRegistration(Base, SmoothWidth, CLASSES))
        goto END;

    gRegStruct.Points.used=GetTestPoints(&gRegStruct, (*Base).img, (*Base).charimg,
                                         (*Base).X, (*Base).Y, (*Base).Z/(*Base).volumes,
                                         (*Base).dx, (*Base).dy, (*Base).dz, mask,UseMask);

    if (!gRegStruct.Points.used)
        goto END;

    if ((*Base).charimg)
        {
            free((*Base).charimg);
            (*Base).charimg=NULL;
        }


    if (!MakeCopyOfImage(Match, &gRegStruct.Match))
        goto END;


    if (!ProcessForRegistration(&gRegStruct.Match, SmoothWidth, CLASSES))
        goto END;


    Err=MinimiseRegistrationError((HWND)NULL, (HWND)NULL, p, Nparameters, &gRegStruct);


    SaveParameters((*Match).filename, p, Nparameters, Base);


    //------------Report the results-------------
    sprintf(txt,"Registration Error change=%f     ",Err);
    hDC=GetDC(hwnd);
    TextOut(hDC,100,200,txt,strlen(txt));
    ReleaseDC(hwnd, hDC);


    SetCursor(PrevCursor);

    result=1;
END:
    ReleaseRegData(&gRegStruct);

    return result;
}






//==============================================================================================================
//                Apply Coordinate transform to ROIs
/*
struct BaseDims{
       int X;
       int Y;
       int Zpv;
       float dx;
       float dy;
       float dz;
       float x0;
       float y0;
       float z0;
};*/
//==============================================================================================================
int TransformROIs(HWND hwnd, struct Image *image)
{

    struct Image roiobj, roiobj2;
    struct BaseDims bd;
    int result=0;
    int X,Y,Z;
    int voxel, voxels;
    int Obj, Nobjects=gNumberOfObjects;
    int roi, Nrois;
    int Nparameters;
    double p[MAX_REGISTRATION_PARAMETERS];
    unsigned char *objects=NULL;

    memset(&roiobj,0,sizeof(struct Image));
    memset(&roiobj2,0,sizeof(struct Image));

    if (!gNumberOfROIs)
        goto END;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    if (!(Nparameters=LoadParameters(p, MAX_REGISTRATION_PARAMETERS, &bd)))
        goto END;

    if (!bd.X)
        {
            MessageBox(hwnd, "Problem with registration file. Pleas re-register","",MB_OK);
            goto END;
        }

    if (!MakeCopyOfImage(image, &roiobj))
        goto END;

//CONVERT roiobj INTO A BINARY REPRESENTATION OF THE ROI OBJECTS
    memset(roiobj.img,0,sizeof(float)*voxels);
    if (!(objects=(unsigned char *)malloc(voxels)))
        goto END;

    for (Obj=1; Obj<=Nobjects; Obj++)
        {
            GetBinaryROImask(objects, X, Y, Z, Obj, 0);
            for (voxel=0; voxel<voxels; voxel++)
                {
                    if (objects[voxel])
                        {
                            roiobj.img[voxel]=(float)Obj;
                        }
                }
        }
    roiobj.MaxIntensity=MaximumIntensity(&roiobj);
    free(objects);
    objects=NULL;

//CLEAR THE OLD ROIs
    FreeROIMemory();

//TRANSFORM roiobj
    ReformatMatchImage(bd.X, bd.Y, bd.Zpv, bd.dx, bd.dy, bd.dz, bd.x0, bd.y0, bd.z0, &roiobj, p, Nparameters, ID_NEAREST_NEIGHBOUR);


//NOW GET THE NEW DIMENSIONS OF THE TRANSFORMED IMAGE
    X=roiobj.X;
    Y=roiobj.Y;
    Z=roiobj.Z;
    voxels=X*Y*Z;


//GET THE TRANSFORMED ROIs WITH ORIGINAL OBJECT NUMBERING

    if (!MakeCopyOfImage( &roiobj, &roiobj2 ))
        goto END;

    for (Obj=1; Obj<=Nobjects; Obj++)
        {
            memset(roiobj2.img,0,voxels*sizeof(float));
            for (voxel=0; voxel<voxels; voxel++)
                {
                    if (roiobj.img[voxel]==(float)Obj)
                        {
                            roiobj2.img[voxel]=(float)Obj;
                        }
                }
            Nrois=gNumberOfROIs;
            ConvertObjectToROIs(hwnd, &roiobj2);
            for (roi=Nrois+1; roi<=gNumberOfROIs; roi++)
                {
                    ROIs[roi].object=Obj;
                }
        }
    ReleaseImage(&roiobj2);




    ReleaseImage(image);
    MakeCopyOfImage(&roiobj, image);
    result=1;
END:
    if (objects)
        free(objects);

    ReleaseImage(&roiobj);
    ReleaseImage(&roiobj2);

    return result;
}




//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//=============================================================================================
//                      To register multi volume images
//=============================================================================================
struct MultiVolumeReg
{
    struct Image image;
    struct SamplePoints *Points;
    float *Base;
    int volume;
};



double MinimiseIndependenceOfVolume(struct MultiVolumeReg *MV, int volume, struct SamplePoints *points, double P[]);
double MVDeviationFromIndependence(double p[], int parameters, void *MVreg);

double ResampleVolume(double p[], int parameters, struct Image *image, int volume);
//=============================================================================================
//                  Multi volume registration
//                  Registers all volume to the first
//                  rigid indicates if shear and scale should be parameters
//                  DWI is for reduced parameter specifically for distortion in DWI
//=============================================================================================
int MultiVolumeRegistration(HWND hwnd, struct Image *image)
{

    struct MultiVolumeReg MV;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    int voxelspv=voxels/(*image).volumes;
    int volume, volumes=(*image).volumes;
    double means[CLASSES];
    double p[RIGID6];
    double Err;
    HCURSOR hourglass=LoadCursor(NULL,IDC_WAIT);
    HCURSOR	PrevCursor=SetCursor(hourglass);
    HDC hDC=GetDC(hwnd);
    unsigned char dummy;
    char txt[256];


    memset(&MV,0,sizeof(struct MultiVolumeReg));


    if (volumes<=1)
        {
            MessageBox(NULL,"For multivolume images only.","",MB_OK|MB_ICONWARNING);
            return 0;
        }


    //-----------make a copy of the original image--------------
    memset(&MV.image, 0, sizeof(struct Image));

    if (!MakeCopyOfImage(image, &MV.image))
        goto END;


    //----------Automatically remove the background---------------------
//    AutoRemoveNoisyBackground(hwnd, &MV.image);
//    FreeROIMemory();


    //------------malloc memory for the class image----------------------
    if (!(MV.image.charimg=(unsigned char *)malloc(voxels)))
        goto END;



    //------------------------process the image----------------------------------
    FilterImage(&MV.image, GAUSSIAN, 2.0);
    //image is now filtered

    //-------------Compute the class images for the registration-----------------
    //-----------------And also compute the test points--------------------------
    memset(MV.image.charimg,1,voxels);
    for (volume=0; volume<volumes; volume++)
        {
            Fuzzy_cMeansClustering(&MV.image.img[volume*voxelspv], &MV.image.charimg[volume*voxelspv],
                                   MV.image.X, MV.image.Y, MV.image.Z/MV.image.volumes,
                                   CLASSES, means, 100);
        }
    //----------Get the test points, which requires a class image------------------------------
    gRegStruct.Points.used=GetTestPoints(&gRegStruct, MV.image.img, MV.image.charimg, MV.image.X, MV.image.Y, MV.image.Z/MV.image.volumes,
                                         MV.image.dx, MV.image.dy, MV.image.dz, &dummy,0);




    //minimise the independence between volumes 0 and n (1<=n<volumes); non-dwi only

    for (volume=1; volume<volumes; volume++)
        {

            InitialiseRegistrationParameters(p, RIGID6);//sets parameters to 0, except scale, which are set to 1

            Err=MinimiseIndependenceOfVolume(&MV, volume, &gRegStruct.Points, p);

            //resample the original given the optimised parameters
            if (Err<0.0)
                ResampleVolume(p, RIGID6, image, volume);

            sprintf(txt,"volume %d of %d. Error Change=%f    ",volume+1, volumes, Err);
            TextOut(hDC,100,100,txt,strlen(txt));
            UpdateWindow(hwnd);
        }


END:
    ReleaseRegData(&gRegStruct);
    ReleaseDC(hwnd, hDC);
    ReleaseImage(&MV.image);
    if (MV.Base)
        free(MV.Base);
    SetCursor(PrevCursor);

    return 1;
}

//=============================================================================================
//                  Minimise independence between volume n to volume 0
//                  Cant use Simplex because some of the scales are zero
//=============================================================================================
double MinimiseIndependenceOfVolume(struct MultiVolumeReg *MV, int volume, struct SamplePoints *points,double P[])
{

    double scale[RIGID6];
    double E, Einit;

    (*MV).volume=volume;

    memset(scale,0,sizeof(double)*RIGID6);
    scale[TRANSLATE]=scale[TRANSLATE+1]=scale[TRANSLATE+2]=0.05;
    scale[ROTATE]=scale[ROTATE+1]=scale[ROTATE+2]=0.1*PI/180.0;



    //what is the initial error?
    (*MV).Points=points;
    (*(*MV).Points).used=(*points).used;
    Einit=MVDeviationFromIndependence(P, RIGID6, MV);

    E=PowellMinimisation(P, RIGID6, scale, 1, MVDeviationFromIndependence, MV, 1.0e-3);

    return E-Einit;
}




//=============================================================================================
//                  Compute the relative quality of the register
//                  Uses P(AB)=P(A)P(B), which is true for independent random variables
//                  p[] contains the Nparameters parameters for the transformation
//=============================================================================================
double MVDeviationFromIndependence(double p[], int Nparameters, void *MVreg)
{

    struct MultiVolumeReg *MV=(struct MultiVolumeReg *)MVreg;
    struct SamplePoints *Points=(*MV).Points;
    struct AffineMatrix M;
    float x,y,z;
    float x0,y0,z0;
    double Err, E_A;
    double poly;
    double tmp;
    int xi,yi,zi, voxel, point, count;
    int voxelspv=(*MV).image.X*(*MV).image.Y*(*MV).image.Z/(*MV).image.volumes;
    int volume=(*MV).volume;//this is the volume to be registered to volume 0
    int volumeoffset=volume*voxelspv;
    int Imatch,Ibase;
    int A[(CLASSES+1)*(CLASSES+1)];
    int Base[CLASSES+1], Match[CLASSES+1];
    int Zpv=(*MV).image.Z/(*MV).image.volumes;
    int XY=(*MV).image.X*(*MV).image.Y;
    int PointsUsed=(*Points).used;

    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6)
        M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nparameters==RIGID6)
        M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);


    x0=(*MV).image.dx*(*MV).image.X/2.0;
    y0=(*MV).image.dy*(*MV).image.Y/2.0;
    z0=(*MV).image.dz*(*MV).image.Z/2.0/(*MV).image.volumes;

    memset(A,0,sizeof(int)*(CLASSES+1)*(CLASSES+1));
    memset(Base,0,sizeof(int)*(CLASSES+1));
    memset(Match,0,sizeof(int)*(CLASSES+1));
    count=0;



    for (point=0; point<PointsUsed; point++)
        {

            x=(*Points).x[point];
            y=(*Points).y[point];//random points chosen at initialisation
            z=(*Points).z[point];

            //get an affine transformation; nonlinear polynomial not used for multivolume registration
            GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0,(*MV).image.dx, (*MV).image.dy, (*MV).image.dz, &M, p, &poly, Nparameters);

            xi=(int)(x+0.5);
            yi=(int)(y+0.5);
            zi=(int)(z+0.5);

            if (InImageRange(xi, yi, zi, (*MV).image.X, (*MV).image.Y, Zpv))
                {
                    voxel=xi + yi*(*MV).image.X + zi*XY;
                    Ibase=(*Points).cl[point];
                    Imatch=(*MV).image.charimg[voxel+volumeoffset];
                    if (Ibase && Imatch)
                        {
                            A[Ibase+Imatch*(CLASSES+1)]++;
                            Base[Ibase]++;
                            Match[Imatch]++;
                            count++;
                        }
                }

        }

    if (!count)
        return 0.0;

    Err=0.0;
    for (Ibase=1; Ibase<=CLASSES; Ibase++)
        {
            for (Imatch=1; Imatch<=CLASSES; Imatch++)
                {
                    E_A=(double)(Match[Imatch]*Base[Ibase])/count;
                    //Like Pearsons chisquare statistic, which is chi^2_1 distributed
                    tmp = (double)A[Ibase+Imatch*(CLASSES+1)]-E_A;
                    if (E_A>0.0)
                        Err+=tmp*tmp/E_A;
                }
        }

    return -Err;

}






//=============================================================================================
//                          Resample a volume
//=============================================================================================
double ResampleVolume(double p[], int Nparameters, struct Image *image, int volume)
{

    struct AffineMatrix M;
    float x,y,z;
    float x0,y0,z0;
    float *tmp=NULL;
    double poly;
    int xi, yi, zi;
    int voxel;
    int voxelspv=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int Zpv=(*image).Z/(*image).volumes;

    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nparameters>RIGID6)
        M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nparameters==RIGID6)
        M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);


    if (!(tmp=(float *)malloc(voxelspv*sizeof(float))))
        return 0;

    x0=(*image).dx*(*image).X/2.0;
    y0=(*image).dy*(*image).Y/2.0;
    z0=(*image).dz*Zpv/2.0;

    voxel=0;
    for (zi=0; zi<Zpv; zi++)
        {
            for (yi=0; yi<(*image).Y; yi++)
                {
                    for (xi=0; xi<(*image).X; xi++)
                        {
                            //voxel=xi + yi*(*image).X + zi*(*image).X*(*image).Y;

                            x=(*image).dx*xi-x0;
                            y=(*image).dy*yi-y0;
                            z=(*image).dz*zi-z0;

                            //get an affine transformation; nonlinear polynomial not used for multivolume registration
                            GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0,(*image).dx, (*image).dy, (*image).dz, &M, p, &poly, Nparameters);

                            tmp[voxel]=InterpolateImage(image, volume, x, y, z, ID_CUBIC);

                            voxel++;
                        }
                }
        }
    memcpy(&(*image).img[voxelspv*volume],tmp,voxelspv*sizeof(float));

    free(tmp);

    return 1;
}



