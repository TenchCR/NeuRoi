/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
register the T2 to a template to get probability of WM=Pwm, probability of GM=Pgm, and probability of CSF=Pcsf

Inhomogeneity correct WM???

Use WM intensities to work out quantile of each intensity=Q

Lesion likelihood = Pwm*Q

Ideas:
remove voxels that are classified as WM, but which border voxels classed as CSF. This helps remove misclassification of WM near ventricals

Do I need to do similar for GM WM interface?

Should I also use T1 because it doesn't show the lesions so much?

*/
#include "global.h"

int Load_Template_WM(HWND hwnd, struct Image *WM);
int Load_Template_Brain(HWND hwnd, struct Image *brainstem);
//===========================================================================
int MSlesionLikelihood(HWND hwnd, struct Image *T2)
{
    int result=0;
    //struct AffineMatrix M;
    struct Image LL;
    struct Image Template;
    struct Image WM;
    double p[AFFINE12];
    unsigned char dummy;
    int voxel;
    int Nvoxels=(*T2).X*(*T2).Y*(*T2).Z;

//NULL THE IMAGE STRUCTURES
    memset (&LL,0,sizeof(struct Image));
    memset(&Template,0,sizeof(struct Image));
    memset(&WM,0,sizeof(struct Image));


//LOAD THE TEMPLATE
    if ( !(Load_Template_Brain(hwnd, &Template)) ) goto END;
    if (!(Load_Template_WM(hwnd, &WM))) goto END;

    if (!(MakeCopyOfImage(T2, &LL))) goto END;

    InitialiseRegistrationParameters(p, AFFINE12);
    RegisterTwoImagesP(hwnd,&Template, T2,	p, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);
    //M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);

///TODO
//correct inhomogeneity


    for (voxel=0;voxel<Nvoxels;voxel++)
    {
        LL.img[voxel]=0.0;

    }

    result=1;
END:
     ReleaseImage(&Template);
     ReleaseImage(&WM);
     ReleaseImage(&LL);

    return result;

}
