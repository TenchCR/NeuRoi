/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MeanShiftCoordinateClustering.h"

int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double dist2[], int Nfoci);
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double dist2[], int Nfoci, double sd);
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double sd);
double OptimiseWidth(double *width, int N, void *MS);
double LinearKernel(double dist, double maxdist);

struct MS
{
	struct Image *img;
	struct Coordinates *C;
	short int *ToCluster;
	int Nsig;
	float *xc;
	float *yc;
	float *zc;
	int MinStudiesPerCluster;
	double bestwidth;
	int bestclustered;
	int LeastClusters;
	char fname[MAX_PATH];
};


//================================================================================================================
//saves the characteristic radii of valid clusters to the temp directory
int SaveClusterRadii(struct Coordinates *C, float xc[], float yc[], float zc[], int NvalidClusters)
{
	int focus;
	int Nfoci=(*C).TotalFoci;
	int c;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	double d2,d2max;

	sprintf(fname,"%s//ClusterRadius.csv",REPORT_FOLDER);
	if ((fp=fopen(fname,"a")))
	{
		for (c=1; c<=NvalidClusters; c++)
		{
			d2max=0.0;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).cluster[focus]==c)
				{
					d2=(xc[c-1]-(*C).x[focus])*(xc[c-1]-(*C).x[focus]) + (yc[c-1]-(*C).y[focus])*(yc[c-1]-(*C).y[focus]) + (zc[c-1]-(*C).z[focus])*(zc[c-1]-(*C).z[focus]);
					if (d2>d2max)
					{
						d2max=d2;
					}
				}
			}
			if (d2max>0.0)
			{
				fprintf(fp,"%d,%f\n",c,sqrt(d2max));
			}
		}
		fclose(fp);
	}
	return 0;
}
//================================================================================================================
double OptimiseMeanShiftClusteringKernel(struct Image *img, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[])
{
	int Nfoci=(*C).TotalFoci;
	int focus;
	double width[1],dir[1];
	struct MS ms;
	memset(&ms, 0, sizeof(struct MS));
	ms.LeastClusters=Nfoci;
	FILE *fp=NULL;


	sprintf(ms.fname,"%s//WidthOpt.csv",directory);
	if ((fp=fopen(ms.fname,"w")))
	{
		fclose(fp);
	}

	//number of significant coordinates to cluster
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
			ms.Nsig++;
	}

	if (ms.Nsig<=0) return 0.0;

	ms.img=img;
	ms.C=C;
	ms.ToCluster=ToCluster;
	ms.xc=xc;
	ms.yc=yc;
	ms.zc=zc;
	ms.MinStudiesPerCluster=MinStudiesPerCluster;


	//typical radius of clusters is 6-16mm
	for (width[0]=6.0; width[0]<=16.0; width[0]+=1.0)
	{
		OptimiseWidth(width, 1, &ms);
	}
	width[0]=ms.bestwidth;
	dir[0]=-0.5;


	GoldenSearch(width, dir, 1, -ms.bestclustered/ms.Nsig, OptimiseWidth, &ms, 30);

	return ms.bestwidth;
}

//================================================================================================================
double SumSquaredDistances(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci );
double OptimiseWidth(double *width, int N, void *MS)
{
	struct MS *ms=(struct MS *)MS;
	int clustered;
	int focus;
	struct Coordinates *C=(*ms).C;
	int Nfoci=(*C).TotalFoci;
	int Nclusters;
	FILE *fp=NULL;

	fp=fopen((*ms).fname,"a");

	Nclusters = GetValidMeanShiftClusters((*ms).img, (*ms).C, (*ms).ToCluster, (*ms).xc, (*ms).yc, (*ms).zc, (*ms).MinStudiesPerCluster, (*width));

	clustered=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus])
			clustered++;
	}

	int s=0;
	if (clustered>(*ms).bestclustered)
	{
		(*ms).bestclustered=clustered;
		(*ms).bestwidth=(*width);
		(*ms).LeastClusters=Nclusters;
		s=1;
	}
	else if (clustered==(*ms).bestclustered && Nclusters<(*ms).LeastClusters)
	{
		(*ms).bestwidth=(*width);
		(*ms).LeastClusters=Nclusters;
		s=2;
	}

	if (fp)
	{
		if (s==1)
			fprintf(fp,"MORE COORDINATES,%f,%f, %f, %d,%d\n",(*width),(*ms).bestwidth,-(double)clustered/(*ms).Nsig, (*ms).bestclustered,(*ms).LeastClusters);
		else if (s==2)
			fprintf(fp,"FEWER CLUSTERS,%f,%f, %f, %d,%d\n",(*width),(*ms).bestwidth,-(double)clustered/(*ms).Nsig, (*ms).bestclustered,(*ms).LeastClusters);
		else
			fprintf(fp,",%f,%f, %f, %d,%d\n",(*width),(*ms).bestwidth,-(double)clustered/(*ms).Nsig, (*ms).bestclustered,(*ms).LeastClusters);
		fclose(fp);
	}

	return -(double)clustered/(*ms).Nsig;
}
//================================================================================================================
double SumSquaredDistances(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci )
{
	double SSD=0.0;
	int cl;
	int focus;


	for (focus=0; focus<Nfoci; focus++)
	{
		cl=cluster[focus];
		if (cl)
		{
			SSD+=(xc[cl-1] - x[focus])*(xc[cl-1] - x[focus]) +
			     (yc[cl-1] - y[focus])*(yc[cl-1] - y[focus]) +
			     (zc[cl-1] - z[focus])*(zc[cl-1] - z[focus]);
		}
	}

	return SSD;
}
//================================================================================================================
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double width)
{
	int Nfoci=(*C).TotalFoci;
	int Nexperiments=(*C).Nexperiments;
	int X=(*image).X;
	int Y=(*image).Y;
	int Z=(*image).Z;
	float x0=(*image).x0;
	float y0=(*image).y0;
	float z0=(*image).z0;
	float dx=(*image).dx;
	float dy=(*image).dy;
	float dz=(*image).dz;
	int voxels=X*Y*Z;
	int voxel;
	int focus;
	int xi,yi,zi;
	int Nclusters=0;
	int NvalidClusters=0;
	int c;
	int iexp;
	float *img=NULL;
	int *voxelnumber=NULL;
	short int *cl=NULL;
	int *Contributor=NULL;
	int ContributorCount;

	//default the cluster numbers to zero
	memset((*C).cluster,0,sizeof(short int)*Nfoci);

	if (width<=0.0)
	{
		goto END;
	}

	MeanShiftCoordinates(xc, yc, zc, C, ToCluster, width);

	if (!(img=(float *)calloc(voxels,sizeof(float))))
		goto END;
	if (!(voxelnumber=(int *)malloc(Nfoci*sizeof(int))))
		goto END;
	if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
	if (!(Contributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;

	///project the mean shifted coordinates into the image
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			xi=(int)((xc[focus] + x0)/dx+0.5);
			yi=(int)((yc[focus] + y0)/dy+0.5);
			zi=(int)((zc[focus] + z0)/dz+0.5);

			voxel=xi + yi*X + zi*X*Y;

			if (voxel>=0 && voxel<voxels)
			{
				voxelnumber[focus]=voxel;
				img[voxel]+=1.0;
			}
		}
	}

	///Save the coordinates of the cluster centres and set cluster numbers
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (img[voxel]>0.0)
		{
			XYZfromVoxelNumber(voxel, &xi, &yi, &zi, X,Y,Z);

			xc[Nclusters]=dx*xi - x0;
			yc[Nclusters]=dy*yi - y0;
			zc[Nclusters]=dz*zi - z0;

			Nclusters++;
			for (focus=0; focus<Nfoci; focus++)
			{
				if (ToCluster[focus] && voxelnumber[focus]==voxel)
				{
					cl[focus]=Nclusters;//T his can include multiple coordinates from the same study
				}
			}

		}
	}
	//at this point Nclusters could be an overestimate as not all will be valid

	///Save the cluster numbers so that only the most dense within study is part of the cluster
	for (c=1; c<=Nclusters; c++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			Contributor[iexp]=-1;
		}
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp &&  cl[focus]==c)
				{
					if (Contributor[iexp]<0)
					{
						Contributor[iexp]=focus;
					}
					else if ((*C).p[focus]<(*C).p[Contributor[iexp]])
					{
						Contributor[iexp] = focus;
					}
				}
			}
		}
		ContributorCount=0;
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (Contributor[iexp]>=0)
			{
				ContributorCount++;
			}
		}
		if (ContributorCount>=MinStudiesPerCluster)
		{
			xc[NvalidClusters]=xc[c-1];
			yc[NvalidClusters]=yc[c-1];
			zc[NvalidClusters]=zc[c-1];

			NvalidClusters++;
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (Contributor[iexp]>=0)
				{
					(*C).cluster[Contributor[iexp]] = NvalidClusters;
				}
			}
		}
	}


END:

	if (img)
		free(img);
	if (voxelnumber)
		free(voxelnumber);
	if (cl)
		free(cl);
	if (Contributor)
		free(Contributor);
	return NvalidClusters;
}
//======================================================================================================
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double sd)
{
	int Nfoci=(*C).TotalFoci;
	double *dist2=NULL;
	int iter;
	int focus;
	int result=0;
	double shift=0.0;
	float *xs=NULL;
	float *ys=NULL;
	float *zs=NULL;


	if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci)))
		goto END;
	if (!(xs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(ys=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(zs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	memcpy(xc, (*C).x, sizeof(float)*Nfoci);
	memcpy(yc, (*C).y, sizeof(float)*Nfoci);
	memcpy(zc, (*C).z, sizeof(float)*Nfoci);

	iter=0;
	do
	{
		CurrentDistanceMatrix(xc, yc, zc, (*C).experiment, ToCluster, dist2, Nfoci);

		shift=GetShifts(xs, ys, zs, xc, yc, zc, (*C).experiment, ToCluster, dist2, Nfoci, sd);

		for (focus=0; focus<Nfoci; focus++)
		{
			if (ToCluster[focus])
			{
				xc[focus]+=xs[focus];
				yc[focus]+=ys[focus];
				zc[focus]+=zs[focus];
			}
		}
		iter++;
	}
	while(iter<1000 && shift>0.001);

	result=1;
END:
	if (dist2)
	{
		free(dist2);
	}
	if (xs)
	{
		free(xs);
	}
	if (ys)
	{
		free(ys);
	}
	if (zs)
	{
		free(zs);
	}
	return result;
}
//======================================================================================================
int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double dist2[], int Nfoci)
{
	int i,j;

	for (j=0; j<Nfoci; j++)
	{
		if (ToCluster[j])
		{
			for (i=0; i<Nfoci; i++)
			{
				if (ToCluster[i] && iexp[i]!=iexp[j])
				{
					dist2[i + j*Nfoci] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);
				}
			}
		}
	}

	return 0;
}

//=======================================================================================================
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double dist2[], int Nfoci, double MaxDist)
{
	double MaxDist2=MaxDist*MaxDist;
	double norm;
	double w;
	int focus,i;
	double MaxShift=0.0;
	double shift;

	if (MaxDist<=0.0)
		return 0.0;

	for (focus=0; focus<Nfoci; focus++)
	{
		xs[focus]=ys[focus]=zs[focus]=0.0;
		if (ToCluster[focus])
		{
			norm=0.0;
			for (i=0; i<Nfoci; i++)
			{
				if (ToCluster[i] && iexp[i]!=iexp[focus] && dist2[focus*Nfoci + i]<MaxDist2)
				{
					w = LinearKernel(sqrt(dist2[focus*Nfoci + i]), MaxDist);
					if (w>0.0)
					{
						norm+=w;
						xs[focus] += w*(x[i]-x[focus]);
						ys[focus] += w*(y[i]-y[focus]);
						zs[focus] += w*(z[i]-z[focus]);
					}
				}
			}
			if (norm>0.0)
			{
				norm*=2.0;
				xs[focus]/=norm;
				ys[focus]/=norm;
				zs[focus]/=norm;
				shift=xs[focus]*xs[focus] + ys[focus]*ys[focus] + zs[focus]*zs[focus];
				if (shift>MaxShift)
				{
					MaxShift=shift;
				}
			}
		}

	}

	return MaxShift;
}
//=========================================================================================
double LinearKernel(double dist, double maxdist)
{
	return 1.0-dist/maxdist;
}
//=========================================================================================
double ClusterDensityCDA(struct Coordinates *C, float x, float y, float z, int cluster, double Dmax)
{
	int focus;
	int Nfoci=(*C).TotalFoci;
	double D=0.0;
	double d;

	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus]==cluster)
		{
			d=sqrt(
			      (x-(*C).x[focus])*(x-(*C).x[focus]) +
			      (y-(*C).y[focus])*(y-(*C).y[focus]) +
			      (z-(*C).z[focus])*(z-(*C).z[focus])
			  );
			if (d<Dmax)
			{
				D+=LinearKernel(d, Dmax);
			}
		}
	}

	return D;
}
















int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double sd)
{
	FILE *fp=NULL;
	char fname[MAX_PATH];
	int Nfoci=(*C).TotalFoci;
	int focus;
	int X=gImage.X;
	int Y=gImage.Y;
	int Z=gImage.Z;
	float x0=gImage.x0;
	float y0=gImage.y0;
	float z0=gImage.z0;
	float dx=gImage.dx;
	float dy=gImage.dy;
	float dz=gImage.dz;
	int voxels=X*Y*Z;
	int voxel;
	int x,y,z;

	sprintf(fname,"%s//meanshift.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");

	MeanShiftCoordinates(xc, yc, zc, C, ToCluster,  sd);

	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
			fprintf(fp,"%d,%d,%f,%f,%f\n",focus, (*C).experiment[focus], xc[focus],yc[focus],zc[focus]);
	}
	if (fp)
		fclose(fp);

	memset(gImage.img,0,voxels*sizeof(float));
	gImage.MaxIntensity=0.0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			x=(xc[focus] + x0)/dx;
			y=(yc[focus] + y0)/dy;
			z=(zc[focus] + z0)/dz;
			voxel=x + y*X + z*X*Y;
			if (voxel>=0 && voxel<voxels)
				gImage.img[voxel]+=1.0;
			if (gImage.img[voxel]>gImage.MaxIntensity)
				gImage.MaxIntensity=gImage.img[voxel];
		}
	}
	gImage.offset=0.0;
	gImage.scale=1.0;


	return 0;
}
//======================================================================================================
//given the true positives get the ROC curve as a function of width
//But what to do with it?
double ROCcurveForWidth(struct Image *img, struct Coordinates *C, short int TruePositives[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[])
{
	short int *ToCluster=NULL;
	int Nfoci=(*C).TotalFoci;
	int focus;
	int Tp,Fp;
	int NTP=0;
	double width;
	char fname[MAX_PATH];
	FILE *fp;

	sprintf(fname,"%s//ROC.csv",directory);
	if (!(fp=fopen(fname,"w")))
		goto END;

	if (!(ToCluster=(short int *)malloc(sizeof(short int)*Nfoci)))
		goto END;
	for (focus=0; focus<Nfoci; focus++)
	{
		ToCluster[focus]=1;//need to try and cluster all
		if (TruePositives[focus])
			NTP++;
	}

	if (!NTP)
		goto END;

	for (width=1.0; width<20.0; width+=1.0)
	{
		GetValidMeanShiftClusters(img, C, ToCluster, xc, yc, zc,MinStudiesPerCluster, width);

		//compute true positives and false positives
		Tp=Fp=0;
		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).cluster[focus])
			{
				if (TruePositives[focus])
					Tp++;
				else
					Fp++;
			}
		}

		fprintf(fp,"%f,%f,%f\n",width, (double)Fp/NTP,(double)Tp/NTP);
	}


END:
	if (ToCluster)
		free(ToCluster);
	if (fp)
		fclose(fp);

	return 0.0;
}
//============================================================================================================
//https://link.springer.com/chapter/10.1007/978-0-585-25657-3_7#:~:text=It%20turns%20out%20that%20the,a%20rather%20simple%20statistical%20interpretation.&text=Therefore%2C%20under%20the%20assumption%20of,to%20their%20expected%20joint%20probability
//cov(X,Y) = P(X=1|Y=1) - P(X=1)P(Y=1)
double CovarianceOfClusters(struct Coordinates *C, int Cluster1, int Cluster2)
{

	int Nfoci=(*C).TotalFoci;
	int Nstudies=(*C).Nexperiments;
	int nx, ny, nxy;
	int focus,focus2;
	int iexp;

	nx=ny=nxy=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		iexp=(*C).experiment[focus];

		if ((*C).cluster[focus]==Cluster1)
		{
			nx++;
		}
		if ((*C).cluster[focus]==Cluster2)
		{
			ny++;
		}
		for (focus2=0; focus2<Nfoci; focus2++)
		{
			if ((*C).experiment[focus2]==iexp)
			{
				if ((*C).cluster[focus]==Cluster1 && (*C).cluster[focus2]==Cluster2)
				{
					nxy++;
				}
			}
		}

	}


	return (double)nxy/Nstudies - (double)nx*ny/Nstudies/Nstudies;
}
//============================================================================================================
//============================================================================================================
//https://link.springer.com/chapter/10.1007/978-0-585-25657-3_7#:~:text=It%20turns%20out%20that%20the,a%20rather%20simple%20statistical%20interpretation.&text=Therefore%2C%20under%20the%20assumption%20of,to%20their%20expected%20joint%20probability
//cov(X,Y) = P(X=1|Y=1) - P(X=1)P(Y=1)
double CovarianceOfStudies(struct Coordinates *C, int Study1, int Study2, int Nclusters)
{

	int Nfoci=(*C).TotalFoci;
	int nx, ny, nxy;
	int focus,focus2;


	nx=ny=nxy=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).experiment[focus]==Study1)
		{
			if ((*C).cluster[focus])
			{
				nx++;
			}
		}
		if ((*C).experiment[focus]==Study2)
		{
			if ((*C).cluster[focus])
			{
				ny++;
			}
		}

		if ((*C).experiment[focus]==Study1)
		{
			for (focus2=0; focus2<Nfoci; focus2++)
			{
				if ((*C).experiment[focus]==Study2)
				{
					if ((*C).cluster[focus]==(*C).cluster[focus2])
					{
						nxy++;
					}
				}
			}
		}
	}

	return (double)nxy/Nclusters - (double)nx*ny/Nclusters/Nclusters;
}

//============================================================================================================
int ClusterCovarianceMatrix(struct Coordinates *C, double *CV, int Nclusters)
{
	int cl1,cl2;

	for (cl2=1; cl2<=Nclusters; cl2++)
	{
		for (cl1=1; cl1<=Nclusters; cl1++)
		{
			CV[(cl1-1)+Nclusters*(cl2-1)] = CovarianceOfClusters(C, cl1, cl2);
		}
	}
	return 1;
}
//============================================================================================================
int StudyCovarianceMatrix(struct Coordinates *C, double *CV, int Nclusters)
{
	int s1,s2;
	int Nstudies=(*C).Nexperiments;

	for (s2=0; s2<Nstudies; s2++)
	{
		for (s1=0; s1<Nstudies; s1++)
		{
			CV[s1+Nstudies*s2] = CovarianceOfStudies(C, s1, s2,Nclusters);
		}
	}
	return 1;
}
//============================================================================================================
int CDAprincipalComponenetAnalysis(struct Coordinates *C, int Nclusters, char directory[])
{

	double *e=NULL;
	double *v=NULL;
	double *CV=NULL;
	int cl1,cl2;
	char fname[MAX_PATH];
	FILE *fp;

	if (!(e=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	if (!(v=(double *)malloc(Nclusters*Nclusters*sizeof(double))))
		goto END;
	if (!(CV=(double *)malloc(Nclusters*Nclusters*sizeof(double))))
		goto END;


	ClusterCovarianceMatrix(C, CV, Nclusters);


	sprintf(fname,"%s//PCA.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		for (cl2=0; cl2<Nclusters; cl2++)
		{
			for (cl1=0; cl1<Nclusters; cl1++)
			{
				fprintf(fp,"%f,",CV[ cl1 + cl2*Nclusters]);
			}
			fprintf(fp,"\n");
		}
		fprintf(fp,"\n");
		fprintf(fp,"\n");
		fprintf(fp,"\n");
		JacobiEigenSystemSolver(CV, v, e, Nclusters, 1);
		for (cl1=0; cl1<Nclusters; cl1++)
		{
			fprintf(fp,"%f,",e[cl1]);
		}
		fprintf(fp,"\n");
		for (cl2=0; cl2<Nclusters; cl2++)
		{
			for (cl1=0; cl1<Nclusters; cl1++)
			{
				fprintf(fp,"%f,",v[ cl1 + cl2*Nclusters]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}

END:
	if (e)
		free(e);
	if (v)
		free(v);
	if (CV)
		free(CV);

	return 0;
}

























//=======================================================================================================
//Only seems to work sometimes, others it splits clusters
//Need to stop it favouring small clusters
double CrossValidateConsistentClusters(struct Image *image, struct Coordinates *C, float xc[], float yc[], float zc[], int MinStudiesPerCluster, double width)
{
	short int *ToCluster=NULL;
	int Nfoci=(*C).TotalFoci;
	int focus;
	double D=0.0;
	double densityincluster;
	double *d=NULL;
	int *cluster=NULL;
	int iexp;
	int Nexperiments=(*C).Nexperiments;
	int Nclusters;
	int cl;
	int NinCluster;

	if (!(ToCluster=(short int *)malloc(Nfoci*sizeof(short int))))
		goto END;
	if (!(d=(double *)calloc(Nfoci,sizeof(double))))
		goto END;
	if (!(cluster=(int *)calloc(Nfoci,sizeof(int))))
		goto END;

	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		for (focus=0; focus<Nfoci; focus++)
		{
			ToCluster[focus]=1;
			if ((*C).experiment[focus]==iexp)
				ToCluster[focus]=0;
		}
		Nclusters = GetValidMeanShiftClusters(image, C, ToCluster, xc, yc, zc, MinStudiesPerCluster,  width);

		///assign coordinates in iexp to cluster with highest density
		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).experiment[focus]==iexp)
			{
				d[focus]=0.0;
				for (cl=1; cl<=Nclusters; cl++)
				{
					densityincluster=ClusterDensityCDA(C, (*C).x[focus], (*C).y[focus], (*C).z[focus], cl, width);
					if (densityincluster>d[focus])
					{
						d[focus]=densityincluster;
						cluster[focus]=cl;
					}
				}
			}
		}

		///add the densities together
		for (cl=1; cl<=Nclusters; cl++)
		{
			densityincluster=0.0;
			NinCluster=0;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp && cluster[focus]==cl)
				{
					densityincluster+=d[focus];
					NinCluster++;
				}
			}
			if (NinCluster)
				D+=densityincluster/NinCluster;
		}
	}


END:
	if (ToCluster)
		free(ToCluster);
	if (cluster)
		free(cluster);
	if (d)
		free(d);

	return D/pow(width,3);
}
//========================================================================================
int SaveRGBclustersCDA(int FociVoxel[], short int cluster[], int Nfoci, struct Image *img, int Nclusters, int Marker, double kernelSD, char directory[]);
int TestCrossValidateClusters(struct Image *image, struct Coordinates *C)
{
	float *xc=NULL;
	float *yc=NULL;
	float *zc=NULL;
	int focus;
	int Nfoci=(*C).TotalFoci;
	double width;
	FILE *fp;
	char fname[MAX_PATH];
	double SS;
	double maxSS;
	short int *ToCluster=NULL;
	double bestwidth=0.0;

	if (!(ToCluster=(short int *)malloc(Nfoci*sizeof(short int))))
		goto END;
	for (focus=0; focus<Nfoci; focus++)
	{
		ToCluster[focus]=1;
	}

	if (!(xc=(float *)malloc(Nfoci*sizeof(float))))
		goto END;
	if (!(yc=(float *)malloc(Nfoci*sizeof(float))))
		goto END;
	if (!(zc=(float *)malloc(Nfoci*sizeof(float))))
		goto END;

	sprintf(fname,"%s//cross validate width.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");
	maxSS=0.0;
	for (width=1.0; width<20.0; width+=1.0)
	{
		SS=CrossValidateConsistentClusters(image, C, xc, yc, zc, 4, width);
		if (SS>maxSS)
		{
			maxSS=SS;
			bestwidth=width;
		}
		fprintf(fp,"%f,%f\n",width, SS);
	}
	fclose(fp);

	int Nclusters=GetValidMeanShiftClusters(image, C, ToCluster,xc,yc,zc,4,bestwidth);
	SaveRGBclustersCDA((*C).voxel, (*C).cluster, Nfoci, image, Nclusters, 3, bestwidth, REPORT_FOLDER);

END:
	if (xc)
		free(xc);
	if (yc)
		free(yc);
	if (zc)
		free(zc);
	if (ToCluster)
		free(ToCluster);

	return 0;
}
