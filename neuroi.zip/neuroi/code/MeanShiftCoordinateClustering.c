/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MeanShiftCoordinateClustering.h"

int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double pvalue[], double critical, double dist2[], int Nfoci);
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double p[], double critical, double dist2[], int Nfoci, double MaxDist);
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double critical, double MaxDist);
int NumberClustered(struct Image *img, struct Coordinates *C, double critical, double width, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters);
double LinearKernel(double dist, double maxdist);
double KernelNorm(double maxdist);
double SumKernelOverClustered(struct Coordinates *C, float xc[], float yc[], float zc[], double Rmax);
double ROCcurveForWidth(struct Image *img, struct Coordinates *C, double critical, short int TruePositives[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[]);


//================================================================================================================
//saves the characteristic radii of valid clusters to the temp directory
int SaveClusterRadii(struct Coordinates *C, float xc[], float yc[], float zc[], int NvalidClusters)
{
	int focus;
	int Nfoci=(*C).TotalFoci;
	int c;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	double d2,d2max;

	sprintf(fname,"%s//ClusterRadius.csv",REPORT_FOLDER);
	if ((fp=fopen(fname,"a")))
	{
		for (c=1; c<=NvalidClusters; c++)
		{
			d2max=0.0;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).cluster[focus]==c)
				{
					d2=(xc[c-1]-(*C).x[focus])*(xc[c-1]-(*C).x[focus]) + (yc[c-1]-(*C).y[focus])*(yc[c-1]-(*C).y[focus]) + (zc[c-1]-(*C).z[focus])*(zc[c-1]-(*C).z[focus]);
					if (d2>d2max)
					{
						d2max=d2;
					}
				}
			}
			if (d2max>0.0)
			{
				fprintf(fp,"%d,%f\n",c,sqrt(d2max));
			}
		}
		fclose(fp);
	}
	return 0;
}

//================================================================================================================
double SumSquaredDistances(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci );
double MeanDeviationFromCluster(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci );
double OptimiseMeanShiftClusteringKernel(HWND hwnd, struct Image *img, struct Coordinates *C, double critical, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, double MaxWidth, char directory[])
{
	int Nfoci=(*C).TotalFoci;
	int focus;
	double width;
	double bestwidth=0.0;
	int Nclustered;
	int Nclusters;
	double N;
	double Max;
	int Nsig;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	char txt[256];
	HDC hDC=GetDC(hwnd);


	sprintf(fname,"%s//WidthOpt.csv",directory);
	fp=fopen(fname,"w");


	//number of significant coordinates to cluster
	Nsig=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			Nsig++;
		}
	}

	if (Nsig<=0)
		return 0.0;


	//typical radius of clusters is 6-16mm
	if (fp)
		fprintf(fp,"Kernel Width (mm), Number Clustered, Max Clustered, Clusters\n");
	Max=0;
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClustered(img, C, critical, width, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);

		N=(double)Nclustered ;
		if (Nclusters && N>Max)
		{
			Max=N;
			bestwidth=width;
		}
		if (fp)
			fprintf(fp,"%f, %d,%f,%d\n",width, Nclustered, Max,Nclusters);


		sprintf(txt,"Optimising cluster kernel %5.3fmm (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}
	if (fp )
		fclose(fp);

	ReleaseDC(hwnd,hDC);

	return bestwidth;
}

//================================================================================================================
int NumberClustered(struct Image *img, struct Coordinates *C, double critical, double width, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters)
{

	int clustered;
	int focus;
	int Nfoci=(*C).TotalFoci;

	(*Nclusters) = GetValidMeanShiftClusters(img, C, ToCluster, xc, yc, zc, MinStudiesPerCluster, critical, width);


	clustered=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus] && ToCluster[focus])
			clustered++;
	}


	return clustered;
}
//================================================================================================================
double SumSquaredDistances(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci )
{
	double SSD=0.0;
	int cl;
	int focus;
	int i;

	SSD=0.0;
	i=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		cl=cluster[focus];
		if (cl)
		{
			SSD+=(xc[cl-1] - x[focus])*(xc[cl-1] - x[focus]) +
			     (yc[cl-1] - y[focus])*(yc[cl-1] - y[focus]) +
			     (zc[cl-1] - z[focus])*(zc[cl-1] - z[focus]);
			     i++;
		}
	}

	if (i>Nclusters) return SSD/i;
	else return 0.0;
}
//================================================================================================================
double MeanDeviationFromCluster(float xc[], float yc[], float zc[], int Nclusters, float x[], float y[], float z[], short int cluster[], int Nfoci )
{
	double mean=0.0;
	int cl;
	int focus;
	int i;

	i=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		cl=cluster[focus];
		if (cl)
		{
			mean+=sqrt(
                                    (xc[cl-1] - x[focus])*(xc[cl-1] - x[focus]) +
                                    (yc[cl-1] - y[focus])*(yc[cl-1] - y[focus]) +
                                    (zc[cl-1] - z[focus])*(zc[cl-1] - z[focus])
                                    );
			     i++;
		}
	}

	if (i>Nclusters) return mean/i;
	else return 0.0;
}

//================================================================================================================
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width)
{
	int Nfoci=(*C).TotalFoci;
	int Nexperiments=(*C).Nexperiments;
	int X=(*image).X;
	int Y=(*image).Y;
	int Z=(*image).Z;
	float x0=(*image).x0;
	float y0=(*image).y0;
	float z0=(*image).z0;
	float dx=(*image).dx;
	float dy=(*image).dy;
	float dz=(*image).dz;
	int voxels=X*Y*Z;
	int voxel;
	int focus;
	int xi,yi,zi;
	int Nclusters=0;
	int NvalidClusters=0;
	int c;
	int iexp;
	float *img=NULL;
	int *voxelnumber=NULL;
	short int *cl=NULL;
	int *Contributor=NULL;
	int *SignificantContributor=NULL;
	int SignificantContributorCount;

	//default the cluster numbers to zero
	memset((*C).cluster,0,sizeof(short int)*Nfoci);

	if (width<=0.0)
	{
		goto END;
	}

	MeanShiftCoordinates(xc, yc, zc, C, ToCluster, critical, width);

	if (!(img=(float *)calloc(voxels,sizeof(float))))
		goto END;
	if (!(voxelnumber=(int *)malloc(Nfoci*sizeof(int))))
		goto END;
	if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
	if (!(Contributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(SignificantContributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;

	///project the mean shifted coordinates into the image
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).p[focus]<=critical)
		{
			xi=(int)((xc[focus] + x0)/dx+0.5);
			yi=(int)((yc[focus] + y0)/dy+0.5);
			zi=(int)((zc[focus] + z0)/dz+0.5);

			voxel=xi + yi*X + zi*X*Y;

			if (voxel>=0 && voxel<voxels)
			{
				voxelnumber[focus]=voxel;
				if (ToCluster[focus])
					img[voxel]+=1.0;///only count the significant coordinates
			}
		}
	}


	///Save the coordinates of the cluster centres and set cluster numbers
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (img[voxel]>0.0)
		{
			XYZfromVoxelNumber(voxel, &xi, &yi, &zi, X,Y,Z);

			xc[Nclusters]=dx*xi - x0;
			yc[Nclusters]=dy*yi - y0;
			zc[Nclusters]=dz*zi - z0;

			Nclusters++;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).p[focus]<=critical && voxelnumber[focus]==voxel)
				{
					cl[focus]=Nclusters;//T his can include multiple coordinates from the same study
				}
			}

		}
	}
	//at this point Nclusters could be an overestimate as not all will be valid

	///Save the cluster numbers so that only the most dense within study is part of the cluster
	for (c=1; c<=Nclusters; c++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			Contributor[iexp]=-1;
			SignificantContributor[iexp]=-1;
		}
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp &&  cl[focus]==c)
				{
					if (Contributor[iexp]<0)
					{
						Contributor[iexp]=focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
					else if ((*C).p[focus]<(*C).p[Contributor[iexp]])
					{
						Contributor[iexp] = focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
				}
			}
		}
		SignificantContributorCount=0;
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (SignificantContributor[iexp]>=0)
			{
				SignificantContributorCount++;
			}
		}
		if (SignificantContributorCount>=MinStudiesPerCluster)
		{
			xc[NvalidClusters]=xc[c-1];
			yc[NvalidClusters]=yc[c-1];
			zc[NvalidClusters]=zc[c-1];

			NvalidClusters++;
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (Contributor[iexp]>=0)
				{
					(*C).cluster[Contributor[iexp]] = NvalidClusters;
				}
			}
		}
	}


END:

	if (img)
		free(img);
	if (voxelnumber)
		free(voxelnumber);
	if (cl)
		free(cl);
	if (Contributor)
		free(Contributor);
	if (SignificantContributor)
		free(SignificantContributor);
	return NvalidClusters;
}
//======================================================================================================
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double critical, double MaxDist)
{
	int Nfoci=(*C).TotalFoci;
	double *dist2=NULL;
	int iter;
	int focus;
	int result=0;
	double shift=0.0;
	float *xs=NULL;
	float *ys=NULL;
	float *zs=NULL;


	if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci)))
		goto END;
	if (!(xs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(ys=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(zs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	memcpy(xc, (*C).x, sizeof(float)*Nfoci);
	memcpy(yc, (*C).y, sizeof(float)*Nfoci);
	memcpy(zc, (*C).z, sizeof(float)*Nfoci);

	iter=0;
	do
	{
		CurrentDistanceMatrix(xc, yc, zc, (*C).experiment, ToCluster, (*C).p, critical, dist2, Nfoci);

		shift=GetShifts(xs, ys, zs, xc, yc, zc, (*C).experiment, ToCluster, (*C).p, critical, dist2, Nfoci, MaxDist);

		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).p[focus]<=critical)
			{
				xc[focus]+=xs[focus];
				yc[focus]+=ys[focus];
				zc[focus]+=zs[focus];
			}
		}
		iter++;
	}
	while(iter<1000 && shift>0.001);

	result=1;
END:
	if (dist2)
	{
		free(dist2);
	}
	if (xs)
	{
		free(xs);
	}
	if (ys)
	{
		free(ys);
	}
	if (zs)
	{
		free(zs);
	}
	return result;
}
//======================================================================================================
//compute a matrix of squared distances between any coordinate with pvalue<=critical and any significant coordinate
int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double pvalue[], double critical, double dist2[], int Nfoci)
{
	int i,j;

	for (j=0; j<Nfoci; j++)
	{
		if (pvalue[j]<=critical)
		{
			for (i=j; i<Nfoci; i++)
			{
				if (ToCluster[i] && iexp[i]!=iexp[j])
				{
					dist2[i + j*Nfoci] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);
					dist2[j + i*Nfoci] = dist2[i + j*Nfoci];
				}
			}
		}
	}

	return 0;
}

//=======================================================================================================
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double p[], double critical, double dist2[], int Nfoci, double MaxDist)
{
	double MaxDist2=MaxDist*MaxDist;
	double norm;
	double *w=NULL,wtmp;
	int *bestfocus=NULL;
	int Nexperiments;
	int focus,i;
	double MaxShift=0.0;
	double shift;

	Nexperiments=0;
	for (i=0; i<Nfoci; i++)
	{
		if (iexp[i]>Nexperiments)
			Nexperiments=iexp[i];
	}
	Nexperiments++;

	if (!(w=(double *)malloc(sizeof(double)*Nexperiments)))
		goto END;
	if (!(bestfocus=(int *)malloc(sizeof(int)*Nexperiments)))
		goto END;

	if (MaxDist<=0.0)
		return 0.0;

	for (focus=0; focus<Nfoci; focus++)
	{
		xs[focus]=ys[focus]=zs[focus]=0.0;
		if (p[focus]<=critical)
		{
			memset(w,0,sizeof(double)*Nexperiments);
			for (i=0; i<Nfoci; i++)
			{
				if (ToCluster[i] && iexp[i]!=iexp[focus] && dist2[focus*Nfoci + i]<MaxDist2)
				{
					wtmp = LinearKernel(sqrt(dist2[focus*Nfoci + i]), MaxDist);
					if (wtmp>w[iexp[i]])
					{
						w[iexp[i]]=wtmp;
						bestfocus[iexp[i]]=i;
					}
				}
			}
			norm=0.0;
			for (i=0; i<Nexperiments; i++)
			{
				if (w[i]>0.0)
				{
					xs[focus] += w[i]*(x[bestfocus[i]]-x[focus]);
					ys[focus] += w[i]*(y[bestfocus[i]]-y[focus]);
					zs[focus] += w[i]*(z[bestfocus[i]]-z[focus]);
					norm+=w[i];
				}
			}

			if (norm>0.0)
			{
				norm*=2.0;
				xs[focus]/=norm;
				ys[focus]/=norm;
				zs[focus]/=norm;
				shift=xs[focus]*xs[focus] + ys[focus]*ys[focus] + zs[focus]*zs[focus];
				if (ToCluster[focus] && shift>MaxShift)
				{
					MaxShift=shift;
				}
			}
		}

	}

END:
	if (w)
		free(w);
	if (bestfocus)
		free(bestfocus);

	return MaxShift;
}
//=========================================================================================
double LinearKernel(double dist, double maxdist)
{
	return 1.0-dist/maxdist;
}
//=========================================================================================
double KernelNorm(double maxdist)
{
	return 3.0/PI/pow(maxdist,3);
}
//=========================================================================================
double ClusterDensityABC(struct Coordinates *C, float x, float y, float z, int cluster, double Dmax)
{
	int focus;
	int Nfoci=(*C).TotalFoci;
	double D=0.0;
	double d;

	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus]==cluster)
		{
			d=sqrt(
			      (x-(*C).x[focus])*(x-(*C).x[focus]) +
			      (y-(*C).y[focus])*(y-(*C).y[focus]) +
			      (z-(*C).z[focus])*(z-(*C).z[focus])
			  );
			if (d<Dmax)
			{
				D+=LinearKernel(d, Dmax);
			}
		}
	}

	return D;
}

//=======================================================================================
int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double MaxWidth)
{
	FILE *fp=NULL;
	char fname[MAX_PATH];
	int Nfoci=(*C).TotalFoci;
	int focus;
	int X=gImage.X;
	int Y=gImage.Y;
	int Z=gImage.Z;
	float x0=gImage.x0;
	float y0=gImage.y0;
	float z0=gImage.z0;
	float dx=gImage.dx;
	float dy=gImage.dy;
	float dz=gImage.dz;
	int voxels=X*Y*Z;
	int voxel;
	int x,y,z;

	sprintf(fname,"%s//meanshift.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");

	MeanShiftCoordinates(xc, yc, zc, C, ToCluster, 0.05,  MaxWidth);

	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
			fprintf(fp,"%d,%d,%f,%f,%f\n",focus, (*C).experiment[focus], xc[focus],yc[focus],zc[focus]);
	}
	if (fp)
		fclose(fp);

	memset(gImage.img,0,voxels*sizeof(float));
	gImage.MaxIntensity=0.0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			x=(xc[focus] + x0)/dx;
			y=(yc[focus] + y0)/dy;
			z=(zc[focus] + z0)/dz;
			voxel=x + y*X + z*X*Y;
			if (voxel>=0 && voxel<voxels)
				gImage.img[voxel]+=1.0;
			if (gImage.img[voxel]>gImage.MaxIntensity)
				gImage.MaxIntensity=gImage.img[voxel];
		}
	}
	gImage.offset=0.0;
	gImage.scale=1.0;


	return 0;
}
//============================================================================================================
//https://link.springer.com/chapter/10.1007/978-0-585-25657-3_7#:~:text=It%20turns%20out%20that%20the,a%20rather%20simple%20statistical%20interpretation.&text=Therefore%2C%20under%20the%20assumption%20of,to%20their%20expected%20joint%20probability
//cov(X,Y) = P(X=1|Y=1) - P(X=1)P(Y=1)
double CovarianceOfClusters(struct Coordinates *C, int Cluster1, int Cluster2)
{

	int Nfoci=(*C).TotalFoci;
	int Nstudies=(*C).Nexperiments;
	int nx, ny, nxy;
	int focus,focus2;
	int iexp;

	nx=ny=nxy=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		iexp=(*C).experiment[focus];

		if ((*C).cluster[focus]==Cluster1)
		{
			nx++;
		}
		if ((*C).cluster[focus]==Cluster2)
		{
			ny++;
		}
		for (focus2=0; focus2<Nfoci; focus2++)
		{
			if ((*C).experiment[focus2]==iexp)
			{
				if ((*C).cluster[focus]==Cluster1 && (*C).cluster[focus2]==Cluster2)
				{
					nxy++;
				}
			}
		}

	}


	return (double)nxy/Nstudies - (double)nx*ny/Nstudies/Nstudies;
}
//============================================================================================================
//============================================================================================================
//https://link.springer.com/chapter/10.1007/978-0-585-25657-3_7#:~:text=It%20turns%20out%20that%20the,a%20rather%20simple%20statistical%20interpretation.&text=Therefore%2C%20under%20the%20assumption%20of,to%20their%20expected%20joint%20probability
//cov(X,Y) = P(X=1|Y=1) - P(X=1)P(Y=1)
double CovarianceOfStudies(struct Coordinates *C, int Study1, int Study2, int Nclusters)
{

	int Nfoci=(*C).TotalFoci;
	int nx, ny, nxy;
	int focus,focus2;


	nx=ny=nxy=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).experiment[focus]==Study1)
		{
			if ((*C).cluster[focus])
			{
				nx++;
			}
		}
		if ((*C).experiment[focus]==Study2)
		{
			if ((*C).cluster[focus])
			{
				ny++;
			}
		}

		if ((*C).experiment[focus]==Study1)
		{
			for (focus2=0; focus2<Nfoci; focus2++)
			{
				if ((*C).experiment[focus]==Study2)
				{
					if ((*C).cluster[focus]==(*C).cluster[focus2])
					{
						nxy++;
					}
				}
			}
		}
	}

	return (double)nxy/Nclusters - (double)nx*ny/Nclusters/Nclusters;
}

//============================================================================================================
int ClusterCovarianceMatrix(struct Coordinates *C, double *CV, int Nclusters)
{
	int cl1,cl2;

	for (cl2=1; cl2<=Nclusters; cl2++)
	{
		for (cl1=1; cl1<=Nclusters; cl1++)
		{
			CV[(cl1-1)+Nclusters*(cl2-1)] = CovarianceOfClusters(C, cl1, cl2);
		}
	}
	return 1;
}
//============================================================================================================
int StudyCovarianceMatrix(struct Coordinates *C, double *CV, int Nclusters)
{
	int s1,s2;
	int Nstudies=(*C).Nexperiments;

	for (s2=0; s2<Nstudies; s2++)
	{
		for (s1=0; s1<Nstudies; s1++)
		{
			CV[s1+Nstudies*s2] = CovarianceOfStudies(C, s1, s2,Nclusters);
		}
	}
	return 1;
}
//============================================================================================================
int CDAprincipalComponenetAnalysis(struct Coordinates *C, int Nclusters, char directory[])
{

	double *e=NULL;
	double *v=NULL;
	double *CV=NULL;
	int cl1,cl2;
	char fname[MAX_PATH];
	FILE *fp;

	if (!(e=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	if (!(v=(double *)malloc(Nclusters*Nclusters*sizeof(double))))
		goto END;
	if (!(CV=(double *)malloc(Nclusters*Nclusters*sizeof(double))))
		goto END;


	ClusterCovarianceMatrix(C, CV, Nclusters);


	sprintf(fname,"%s//PCA.csv",directory);
	if ((fp=fopen(fname,"w")))
	{
		for (cl2=0; cl2<Nclusters; cl2++)
		{
			for (cl1=0; cl1<Nclusters; cl1++)
			{
				fprintf(fp,"%f,",CV[ cl1 + cl2*Nclusters]);
			}
			fprintf(fp,"\n");
		}
		fprintf(fp,"\n");
		fprintf(fp,"\n");
		fprintf(fp,"\n");
		JacobiEigenSystemSolver(CV, v, e, Nclusters, 1);
		for (cl1=0; cl1<Nclusters; cl1++)
		{
			fprintf(fp,"%f,",e[cl1]);
		}
		fprintf(fp,"\n");
		for (cl2=0; cl2<Nclusters; cl2++)
		{
			for (cl1=0; cl1<Nclusters; cl1++)
			{
				fprintf(fp,"%f,",v[ cl1 + cl2*Nclusters]);
			}
			fprintf(fp,"\n");
		}
		fclose(fp);
	}

END:
	if (e)
		free(e);
	if (v)
		free(v);
	if (CV)
		free(CV);

	return 0;
}





//======================================================================================================
//Kernel width for CBMAN and CBRES
//Find the truely clustered coordinates using CDA model
//Find the kernel width where the rate of change of number of coordinates is bigger in true positives (according to CDA model) than negatives
//======================================================================================================
double EstimateKernelWidth(HWND hwnd, struct Image *img, struct Coordinates *C, float xc[], float yc[], float zc[], int MinStudiesPerCluster, double critical, char directory[])
{
	short int *TruePositives=NULL;
	double width=0.0;
	double p, Pfdr;
	int i;

	if (!(TruePositives=(short int *)calloc((*C).TotalFoci, sizeof(short int))))
		goto END;

	p=ABCthreshold(C, critical, MinStudiesPerCluster, &Pfdr);

	GetClusteringProbabilityForCoordinates(hwnd, C, GM_VOLUME, critical,MinStudiesPerCluster);


	for (i=0; i<(*C).TotalFoci; i++)
	{
		if ((*C).p[i]<=p)
			TruePositives[i]=1;
	}


	width=ROCcurveForWidth(img, C, critical, TruePositives, xc, yc, zc,  MinStudiesPerCluster, directory);

END:
	if (TruePositives)
		free(TruePositives);

	return width;
}
//======================================================================================================
//given the true positives get the ROC curve as a function of width
//Stop when false positive (according to CDA) clustering happens faster than true positive
double ROCcurveForWidth(struct Image *img, struct Coordinates *C, double critical, short int TruePositives[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[])
{
	short int *ToCluster=NULL;
	int Nfoci=(*C).TotalFoci;
	int focus;
	int Tp,Fp, Tpbak, Fpbak;
	int dTp,dFp, dTpbak, dFpbak;
	int NTP=0;
	double width;
	double alpha;
	char fname[MAX_PATH];
	FILE *fp;

	sprintf(fname,"%s//ROC.csv",directory);
	if (!(fp=fopen(fname,"w")))
		goto END;

	if (!(ToCluster=(short int *)malloc(sizeof(short int)*Nfoci)))
		goto END;
	for (focus=0; focus<Nfoci; focus++)
	{
		ToCluster[focus]=1;//need to try and cluster all
		if (TruePositives[focus])
			NTP++;
	}

	if (!NTP)
		goto END;

	width=0.0;
	Tpbak=Fpbak=0;
	dTp=dFp=0;
	do
	{
		width+=0.1;

		dTpbak=dTp;
		dFpbak=dFp;

		GetValidMeanShiftClusters(img, C, ToCluster, xc, yc, zc,MinStudiesPerCluster, critical, width);

		//compute true positives and false positives
		Tp=Fp=0;
		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).cluster[focus])
			{
				if (TruePositives[focus])
					Tp++;
				else
					Fp++;
			}
		}

		dTp=Tp-Tpbak;
		dFp=Fp-Fpbak;

		Tpbak=Tp;
		Fpbak=Fp;


		fprintf(fp,"%f,%f,%f\n",width, (double)Fp/NTP,(double)Tp/NTP);
	}
	while (Tp<Nfoci && dTp>=dFp && width<20.0);


	/// (1-alpha)*dTpbak + alpha*dTp = (1-alpha)*dFpbak + alpha*dFp
	///(1-alpha)*(dTpbak - dFpbak) = alpha*(dFp-dTp)
	///(dTpbak-dFbak) = alpha*[ (dFp-dTp) + (dTpbak-dFpbak) ]
	alpha = (double)(dTpbak-dFpbak)/( (dFp-dTp) + (dTpbak-dFpbak) );

	width -= (1.0-alpha);

	fprintf(fp,"%f\n",width);


END:
	if (ToCluster)
		free(ToCluster);
	if (fp)
		fclose(fp);

	return width;
}














