/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MeanShiftCoordinateClustering.h"

#define CLUSTER_TOL 0.001

#define GAUSS_LIKE 2.0
#define DOME_LIKE 1.0
#define FLAT 0.0

int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double pvalue[], double critical, double dist2[], int Nfoci);
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double p[], double critical, double dist2[], int Nfoci, double MaxDist, double shape);
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double critical, double MaxDist, double shape);
int NumberClustered(struct Image *img, struct Coordinates *C, char dummy[], double critical, double width, double shape, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters);
double MeanShiftKernel(double dist, double maxdist, double shape);
double SumKernelOverClustered(struct Coordinates *C, float xc[], float yc[], float zc[], double Rmax);
double ROCcurveForWidth(struct Image *img, struct Coordinates *C, double critical, short int TruePositives[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, char directory[]);

int AreClusterCentersTooClose(float xc[], float yc[], float zc[], int N, double TooClose);
int LabelClusters(float x[], float y[], float z[], short int c[], double pvalues[], double pmax, int Nfoci, float xc[], float yc[], float zc[]);
//================================================================================================================
//================================================================================================================
double OptimiseMeanShiftClusteringKernel(HWND hwnd, struct Image *img, struct Coordinates *C, double critical, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, double MaxWidth, double *shape, char directory[])
{
	int Nfoci=(*C).TotalFoci;
	int focus;
	double width;
	double bestwidth=0.0;
	double bestshape=2.0;
	int Nclustered;
	int Nclusters;
	char *dummy=NULL;
	int Max;
	int Nsig;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	char txt[256];
	HDC hDC=GetDC(hwnd);

	*shape=bestshape;

	if (!(dummy=(char *)calloc(Nfoci,sizeof(char)))) return 0.0; ///default width;

	sprintf(fname,"%s//WidthOpt.csv",directory);
	fp=fopen(fname,"w");


	//number of significant coordinates to cluster
	Nsig=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			Nsig++;
		}
	}

	if (Nsig<=0)
		return 0.0;



	if (fp)		fprintf(fp,"Kernel Width (mm), Shape, Number Clustered, Max Clustered, Clusters\n");

	//Gauss like kernel
	Max=0;
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClustered(img, C, dummy, critical, width, GAUSS_LIKE, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max) && !AreClusterCentersTooClose(xc, yc, zc, Nclusters, width))
		{
			Max=Nclustered;
			bestwidth=width;
			bestshape=GAUSS_LIKE;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, GAUSS_LIKE, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm shape=Gauss (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}


	//Dome like kernel
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClustered(img, C, dummy, critical, width, DOME_LIKE, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max) && !AreClusterCentersTooClose(xc, yc, zc, Nclusters, width))
		{
			Max=Nclustered;
			bestwidth=width;
            bestshape=DOME_LIKE;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, DOME_LIKE, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm  shape=dome (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}

	//Flat kernel
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClustered(img, C, dummy, critical, width, FLAT, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max) && !AreClusterCentersTooClose(xc, yc, zc, Nclusters, width))
		{
			Max=Nclustered;
			bestwidth=width;
			bestshape=FLAT;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, FLAT, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm shape=flat (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}

	if (fp) fprintf(fp,"%f,%f\n", bestwidth, bestshape);

	*shape=bestshape;

	if (fp )
		fclose(fp);

	ReleaseDC(hwnd,hDC);
    if (dummy) free(dummy);


	return bestwidth;
}

//================================================================================================================
int NumberClustered(struct Image *img, struct Coordinates *C, char dummy[], double critical, double width, double shape, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters)
{

	int clustered;
	int focus;
	int Nfoci=(*C).TotalFoci;

	(*Nclusters) = GetValidMeanShiftClusters(img, C, ToCluster, dummy, xc, yc, zc, MinStudiesPerCluster, critical, width, shape);
    if (!(*Nclusters)) return 0;

	clustered=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus])
        {
            clustered++;
        }
	}


	return clustered;
}
//================================================================================================================
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], char excluded[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width, double shape)
{
	int Nfoci=(*C).TotalFoci;
	int Nexperiments=(*C).Nexperiments;
	float *xms=NULL;
	float *yms=NULL;
	float *zms=NULL;
	int focus;
	int Nclusters=0;
	int NvalidClusters=0;
	int c;
	int iexp;
	short int *cl=NULL;
	short int *LookUp=NULL;
	int *Contributor=NULL;
	int *SignificantContributor=NULL;
	int SignificantContributorCount;

	//default the cluster numbers to zero
	memset((*C).cluster,0,sizeof(short int)*Nfoci);

	if (width<=0.0)
	{
		goto END;
	}



	if (!(xms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
    if (!(yms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
    if (!(zms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
	if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
    if (!(LookUp=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
	if (!(Contributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(SignificantContributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;


    ///shift the coordinates by mean shift clustering
	memcpy(xms, (*C).x,Nfoci*sizeof(float));
	memcpy(yms, (*C).y,Nfoci*sizeof(float));
	memcpy(zms, (*C).z,Nfoci*sizeof(float));

	MeanShiftCoordinates(xms, yms, zms, C, ToCluster, critical, width, shape);

	Nclusters = LabelClusters(xms, yms, zms, cl, (*C).p, critical, Nfoci, xc, yc, zc);

	///Save the cluster numbers so that only the most dense within study is part of the cluster
	for (c=1; c<=Nclusters; c++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			Contributor[iexp]=-1;
			SignificantContributor[iexp]=-1;
		}

		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp &&  cl[focus]==c)
				{
					if (Contributor[iexp]<0)
					{
						Contributor[iexp]=focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
					else if ((*C).p[focus]<(*C).p[Contributor[iexp]])
					{
						Contributor[iexp] = focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
				}
			}
		}
		SignificantContributorCount=0;
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (SignificantContributor[iexp]>=0)
			{
				SignificantContributorCount++;
			}
		}
		if (SignificantContributorCount>=MinStudiesPerCluster)
		{
			xc[NvalidClusters]=xc[c-1];
			yc[NvalidClusters]=yc[c-1];
			zc[NvalidClusters]=zc[c-1];

			NvalidClusters++;
			LookUp[c]=NvalidClusters;///stores true cluster numbering
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (Contributor[iexp]>=0)
				{
					(*C).cluster[Contributor[iexp]] = c;///temporary cluster number to be switched using LookUp
				}
			}
			///for valid clusters coordinates not included need the excluded flag set
            for (focus=0; focus<Nfoci; focus++)
            {
                if (cl[focus]==c && !(*C).cluster[focus]) excluded[focus]=1;
            }
		}
	}


	///change cluster numbers to consecutive numbers
	for (focus=0; focus<Nfoci; focus++)
    {
        if ((c=(*C).cluster[focus]))
        {
            (*C).cluster[focus]=LookUp[c];
        }
    }

END:

    if (xms) free(xms);
    if (yms) free(yms);
    if (zms) free(zms);
	if (cl)
		free(cl);
    if (LookUp) free(LookUp);
	if (Contributor)
		free(Contributor);
	if (SignificantContributor)
		free(SignificantContributor);
	return NvalidClusters;
}

//======================================================================================================
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], double critical, double MaxDist, double shape)
{
	int Nfoci=(*C).TotalFoci;
	double *dist2=NULL;
	int iter;
	int focus;
	int result=0;
	double shift=0.0;
	float *xs=NULL;
	float *ys=NULL;
	float *zs=NULL;


	if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci)))
		goto END;
	if (!(xs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(ys=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;
	if (!(zs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	memcpy(xc, (*C).x, sizeof(float)*Nfoci);
	memcpy(yc, (*C).y, sizeof(float)*Nfoci);
	memcpy(zc, (*C).z, sizeof(float)*Nfoci);

	iter=0;
	do
	{
		CurrentDistanceMatrix(xc, yc, zc, (*C).experiment, ToCluster, (*C).p, critical, dist2, Nfoci);

		shift=GetShifts(xs, ys, zs, xc, yc, zc, (*C).experiment, ToCluster, (*C).p, critical, dist2, Nfoci, MaxDist, shape);

		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).p[focus]<=critical)
			{
				xc[focus]+=xs[focus];
				yc[focus]+=ys[focus];
				zc[focus]+=zs[focus];
			}
		}
		iter++;
	}
	while(iter<10000 && shift>CLUSTER_TOL);

	result=1;
END:
	if (dist2)
	{
		free(dist2);
	}
	if (xs)
	{
		free(xs);
	}
	if (ys)
	{
		free(ys);
	}
	if (zs)
	{
		free(zs);
	}
	return result;
}
//======================================================================================================
//compute a matrix of squared distances between any coordinate with pvalue<=critical and any significant coordinate
int CurrentDistanceMatrix(float x[], float y[], float z[], short int iexp[], short int ToCluster[], double pvalue[], double critical, double dist2[], int Nfoci)
{
	int i,j;

	//initialise
	for (j=0; j<Nfoci; j++)
	{
	    for (i=j; i<Nfoci; i++)
			{
                dist2[i+j*Nfoci]=DBL_MAX;
			}
	}

	for (j=0; j<Nfoci; j++)
	{
		if (pvalue[j]<=critical)
		{
			for (i=j; i<Nfoci; i++)
			{
				if (pvalue[j]<=critical && iexp[i]!=iexp[j])
				{
					dist2[i + j*Nfoci] = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) + (z[i]-z[j])*(z[i]-z[j]);
					dist2[j + i*Nfoci] = dist2[i + j*Nfoci];
				}
			}
		}
	}

	return 0;
}

//=======================================================================================================
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int ToCluster[], double p[], double critical, double dist2[], int Nfoci, double MaxDist, double shape)
{
	double MaxDist2=MaxDist*MaxDist;
	double norm;
	double *w=NULL,wtmp;
	int *bestfocus=NULL;
	int Nexperiments;
	int focus,i;
	double MaxShift=0.0;
	double shift;

	Nexperiments=0;
	for (i=0; i<Nfoci; i++)
	{
		if (iexp[i]>Nexperiments)
			Nexperiments=iexp[i];
	}
	Nexperiments++;

	if (!(w=(double *)malloc(sizeof(double)*Nexperiments)))
		goto END;
	if (!(bestfocus=(int *)malloc(sizeof(int)*Nexperiments)))
		goto END;

	if (MaxDist<=0.0)
		return 0.0;

	for (focus=0; focus<Nfoci; focus++)
	{
		xs[focus]=ys[focus]=zs[focus]=0.0;
		if (p[focus]<=critical)
		{
			memset(w,0,sizeof(double)*Nexperiments);
			for (i=0; i<Nfoci; i++)
			{
				if (ToCluster[i] && iexp[i] != iexp[focus] && dist2[focus*Nfoci + i]<MaxDist2)
				{
					wtmp = MeanShiftKernel(sqrt(dist2[focus*Nfoci + i]), MaxDist, shape);
					if (wtmp>w[iexp[i]])
					{
						w[iexp[i]]=wtmp;
						bestfocus[iexp[i]]=i;
					}
				}
			}
			norm=0.0;
			for (i=0; i<Nexperiments; i++)
			{
				if (w[i]>0.0)
				{
					xs[focus] += w[i]*(x[bestfocus[i]]-x[focus]);
					ys[focus] += w[i]*(y[bestfocus[i]]-y[focus]);
					zs[focus] += w[i]*(z[bestfocus[i]]-z[focus]);
					norm+=w[i];
				}
			}

			if (norm>0.0)
			{
				norm*=2.0;
				xs[focus]/=norm;
				ys[focus]/=norm;
				zs[focus]/=norm;
				shift=xs[focus]*xs[focus] + ys[focus]*ys[focus] + zs[focus]*zs[focus];
				if (ToCluster[focus] && shift>MaxShift)
				{
					MaxShift=shift;
				}
			}
		}

	}

END:
	if (w)
		free(w);
	if (bestfocus)
		free(bestfocus);

	return MaxShift;
}
//=========================================================================================
double MeanShiftKernel(double dist, double maxdist, double shape)
{
    //beta
    double x=dist/maxdist;
	if (x<1.0) return pow(0.5 + x/2, shape)*pow(1.0-(0.5 + x/2), shape)*16;

	return 0.0;
}

//=======================================================================================
int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double MaxWidth)
{
	FILE *fp=NULL;
	char fname[MAX_PATH];
	int Nfoci=(*C).TotalFoci;
	int focus;
	int X=gImage.X;
	int Y=gImage.Y;
	int Z=gImage.Z;
	float x0=gImage.x0;
	float y0=gImage.y0;
	float z0=gImage.z0;
	float dx=gImage.dx;
	float dy=gImage.dy;
	float dz=gImage.dz;
	int voxels=X*Y*Z;
	int voxel;
	int x,y,z;

	sprintf(fname,"%s//meanshift.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");

	MeanShiftCoordinates(xc, yc, zc, C, ToCluster, 0.05,  MaxWidth, 2.0);

	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
			fprintf(fp,"%d,%d,%f,%f,%f\n",focus, (*C).experiment[focus], xc[focus],yc[focus],zc[focus]);
	}
	if (fp)
		fclose(fp);

	memset(gImage.img,0,voxels*sizeof(float));
	gImage.MaxIntensity=0.0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			x=(xc[focus] + x0)/dx;
			y=(yc[focus] + y0)/dy;
			z=(zc[focus] + z0)/dz;
			voxel=x + y*X + z*X*Y;
			if (voxel>=0 && voxel<voxels)
				gImage.img[voxel]+=1.0;
			if (gImage.img[voxel]>gImage.MaxIntensity)
				gImage.MaxIntensity=gImage.img[voxel];
		}
	}
	gImage.offset=0.0;
	gImage.scale=1.0;


	return 0;
}


//==============================================================================================
int LabelClusters(float x[], float y[], float z[], short int c[], double pvalues[], double pmax, int Nfoci, float xc[], float yc[], float zc[])
{
    int Nclusters=0;
    int focus, focus2;
    double d2, min2=1.0;
    int *CLcount=NULL;
    int cl;

    if (!(CLcount=(int *)calloc(Nfoci, sizeof(int)))) goto END;

    memset(c,0,sizeof(short int)*Nfoci);
    memset(xc, 0, sizeof(float)*Nfoci);
    memset(yc, 0, sizeof(float)*Nfoci);
    memset(zc, 0, sizeof(float)*Nfoci);

    for (focus=0;focus<Nfoci;focus++)
    {
        if (!c[focus] && pvalues[focus]<=pmax)
        {

            Nclusters++;
            c[focus]=Nclusters;

            xc[Nclusters-1] += x[focus];
            yc[Nclusters-1] += y[focus];
            zc[Nclusters-1] += z[focus];
            CLcount[Nclusters-1]++;

            for (focus2=0;focus2<Nfoci;focus2++)
            {
                if (focus!=focus2 && pvalues[focus2]<=pmax)
                {
                        d2=(x[focus]-x[focus2])*(x[focus]-x[focus2]) + (y[focus]-y[focus2])*(y[focus]-y[focus2]) + (z[focus]-z[focus2])*(z[focus]-z[focus2]);
                        if (d2<=min2)
                        {
                            c[focus2]=Nclusters;
                            CLcount[Nclusters-1]++;
                            xc[Nclusters-1] += x[focus];
                            yc[Nclusters-1] += y[focus];
                            zc[Nclusters-1] += z[focus];
                        }
                 }
            }
        }
    }

    for (cl=0;cl<Nclusters;cl++)
    {
        if (CLcount[cl])
        {
            xc[cl] /= CLcount[cl];
            yc[cl] /= CLcount[cl];
            zc[cl] /= CLcount[cl];
        }
    }

    //just check there are non that should be clustered but arent
    for (focus=0;focus<Nfoci;focus++)
    {
        if (pvalues[focus]<=pmax && !c[focus])
        {
            for (cl=0;cl<Nclusters;cl++)
            {
                d2=(x[focus]-xc[cl])*(x[focus]-xc[cl]) + (y[focus]-yc[cl])*(y[focus]-yc[cl]) + (z[focus]-zc[cl])*(z[focus]-zc[cl]);
                        if (d2<=min2)
                        {
                            c[focus]=cl+1;
                        }
            }
        }
    }


END:
    if (CLcount);
    return Nclusters;
}


//=================================================================================================================
int AreClusterCentersTooClose(float xc[], float yc[], float zc[], int N, double TooClose)
{
    int i,j;
    double d2;
    double min2=TooClose*TooClose;

    for (i=0;i<N;i++)
    {
            for (j=i+1;j<N;j++)
            {
                    d2=(xc[i]-xc[j])*(xc[i]-xc[j]) + (yc[i]-yc[j])*(yc[i]-yc[j]) + (zc[i]-zc[j])*(zc[i]-zc[j]);
                    if (d2<min2) return 1;
            }
    }
    return 0;
}













//================================================================================================================
//================================================================================================================
//================================================================================================================
//THESE FUNCTIONS CAN BE USED TO CLUSTER COORDINATES USING AN OPIMISED KERNEL WIDTH
//CURRENTLY THESE ARE NOT USED AND DO REQUIRE FURTHER VALIDATION
//================================================================================================================
//================================================================================================================
//compute the study density by adding up the kernel
//does not include the kernel for the coordinate itself
double StudyDensityABC(struct Coordinates *C, int coordinate, double dist2[], double MaxD2, double shape)
{
	int focus;
	int iexp;
	int Nfoci=(*C).TotalFoci;
	double D=0.0;
	int count=0;
	double dsqrd;
	int experiment=(*C).experiment[coordinate];
	double *d2=NULL;
	double MaxD=sqrt(MaxD2);
	double norm=1.0;

	if (norm<=0.0) return 0.0;

	if (!(d2=(double *)malloc((*C).Nexperiments*sizeof(double)))) return 0.0;

    for (iexp=0;iexp<(*C).Nexperiments;iexp++)
    {
            d2[iexp]=DBL_MAX;
    }


	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).experiment[focus]!=experiment)
        {
                dsqrd=dist2[coordinate*Nfoci + focus];
                if (dsqrd<d2[(*C).experiment[focus]])
                {
                    d2[(*C).experiment[focus]]=dsqrd;
                }
        }
	}

	for (iexp=0;iexp<(*C).Nexperiments;iexp++)
    {
            if (d2[iexp]<MaxD2)
            {
                D+=MeanShiftKernel(sqrt(d2[iexp]), MaxD, shape);
                count++;
            }
    }

    if (count<4) D=0.0;

	free(d2);
	return D*norm;
}
//==============================================================================
double HighestDensityKernel(struct Coordinates *C, double min, double max, double shape, int MinStudies, char directory[])
{
    int Nfoci=(*C).TotalFoci;
    int focus;
    double width;
    double *dist2=NULL;
    double bestwidth,highestdensity;
    double D;
    FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s//KernelWidth.csv",directory);

    fp=fopen(fname,"w");

    bestwidth=0.0;
    highestdensity=0.0;

    if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci))) goto END;

    Distance2Matrix((*C).x, (*C).y, (*C).z, (*C).experiment, Nfoci, dist2);

    for (width=min; width<max; width+=0.1)
    {
        D=0.0;
        for (focus=0;focus<Nfoci;focus++)
        {
                D+=StudyDensityABC(C, focus, dist2, width*width, shape);
        }
        if (D>highestdensity)
        {
            highestdensity=D;
            bestwidth=width;
        }

        fprintf(fp,"%f,%f\n",width, D);
    }



    END:
        if (dist2) free(dist2);
        if (fp) fclose(fp);
    return bestwidth;
}
//====================================================================================
int ClusterAllUsingMeanShift(struct Image *img, struct Coordinates *C, float xc[], float yc[], float zc[], int MinNeighbours, char directory[])
{
    int Nclusters=0;
    char *dummy=NULL;
    short int *ToCluster=NULL;
    int Nfoci=(*C).TotalFoci;
    int focus;
    double width;

    if (!(ToCluster=(short int *)malloc(Nfoci*sizeof(short int)))) goto END;
    if (!(dummy=(char *)malloc(Nfoci))) goto END;

    for (focus=0;focus<Nfoci;focus++)
    {
        ToCluster[focus]=1;
        dummy[focus]=0;
    }


    width=HighestDensityKernel(C, 1.0, 50.0, 2.0, MinNeighbours, directory);
    NumberClustered(img, C, dummy, 1.0, width, 2.0, ToCluster, xc, yc, zc, MinNeighbours, &Nclusters);

    Nclusters=RenumberClusters2((*C).cluster, (*C).TotalFoci, xc, yc, zc, 5);

    END:
        if (ToCluster) free(ToCluster);
        if (dummy) free(dummy);


        return Nclusters;
}





/*
//================================================================================================================
double OptimiseMeanShiftClusteringKernel(HWND hwnd, struct Image *img, struct Coordinates *C, double critical, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, double MaxWidth, char directory[])
{
	int Nfoci=(*C).TotalFoci;
	int focus;
	double width;
	double bestwidth=0.0;
	int Nclustered;
	int Nclusters;
	char *dummy=NULL;
	double N;
	double Max;
	int Nsig;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	char txt[256];
	HDC hDC=GetDC(hwnd);
	struct Image togetherness;
	double score,maxscore;

	memset(&togetherness,0,sizeof(struct Image));
	MakeImage(&togetherness, Nfoci, Nfoci, 1,1, 1.0,1.0,1.0,0.0,0.0,0.0,1.0,0.0,DT_FLOAT,NIFTI,"togetherness");


	if (!(dummy=(char *)calloc(Nfoci,sizeof(char)))) return 0.0; ///default width;

	sprintf(fname,"%s//WidthOpt.csv",directory);
	fp=fopen(fname,"w");


	//number of significant coordinates to cluster
	Nsig=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (ToCluster[focus])
		{
			Nsig++;
		}
	}

	if (Nsig<=0)
		return 0.0;



    for (width=3.0; width<=MaxWidth; width+=0.1)
	{
		Nclustered=NumberClustered(img, C, dummy, critical, width, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);
		AddTogetherness(C, togetherness.img, Nclustered);
	}



	//typical radius of clusters is 6-16mm
	if (fp)
		fprintf(fp,"Kernel Width (mm), Number Clustered, Max Clustered, Clusters\n");
	Max=0;
	maxscore=0.0;
	for (width=3.0; width<=MaxWidth; width+=0.05)
	{

		Nclustered=NumberClustered(img, C, dummy, critical, width, ToCluster, xc, yc, zc, MinStudiesPerCluster, &Nclusters);

		score=TogethernessScore(C, togetherness.img);

		N=(double)Nclustered ;
		if (Nclusters && (N>Max || (N==Max && score>maxscore)))
		{
			Max=N;
			maxscore=score;
			bestwidth=width;
		}


		if (fp)			fprintf(fp,"%f, %d,%f,%d\n",width, Nclustered, Max,Nclusters);
        sprintf(txt,"Optimising cluster kernel %5.3fmm (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}
	if (fp )
		fclose(fp);

	ReleaseDC(hwnd,hDC);
    if (dummy) free(dummy);


    //sprintf(togetherness.filename,"c://temp//togetherness.nii");
    //Save(&togetherness);

    ReleaseImage(&togetherness);

	return bestwidth;
}
*/
/*
//================================================================================================================
int NearestNeighbours(struct Coordinates *C, int focus, int nearest[], int N)
{
    double *d2=NULL;
    double distsq;
    int Nfoci=(*C).TotalFoci;
    int Nexperiments=(*C).Nexperiments;
    int *f=NULL;
    int *sort=NULL;
    int n;
    int i;
    int experiment=(*C).experiment[focus];
    float x,y,z;

    x=(*C).x[focus];
    y=(*C).y[focus];
    z=(*C).z[focus];

    if (!(d2=(double *)malloc(Nexperiments*sizeof(double)))) goto END;
    if (!(f=(int *)malloc(Nexperiments*sizeof(int)))) goto END;
    if (!(sort=(int *)malloc(Nexperiments*sizeof(int)))) goto END;

    for (n=0;n<Nexperiments;n++)
    {
        d2[n]=DBL_MAX;
    }

    for (i=0;i<Nfoci;i++)
    {
        if (i!=focus && experiment!=(*C).experiment[i])
        {
            distsq=(x-(*C).x[i])*(x-(*C).x[i]) + (y-(*C).y[i])*(y-(*C).y[i]) + (z-(*C).z[i])*(z-(*C).z[i]);
            if (distsq<d2[(*C).experiment[i]])
            {
                d2[(*C).experiment[i]]=distsq;
                f[(*C).experiment[i]]=i;
            }
        }
    }

    QuickSort(d2, sort, Nexperiments);

    for (i=0;i<N;i++)
    {
        nearest[i]=f[sort[i]];
    }


END:
    if (d2) free(d2);
    if (f) free(f);
    if (sort) free(sort);

    return 0;
}
*/
/*
int GetValidMeanShiftClusters(struct Image *image, struct Coordinates *C, short int ToCluster[], char excluded[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width)
{
	int Nfoci=(*C).TotalFoci;
	int Nexperiments=(*C).Nexperiments;
	int X=(*image).X;
	int Y=(*image).Y;
	int Z=(*image).Z;
	float x0=(*image).x0;
	float y0=(*image).y0;
	float z0=(*image).z0;
	float dx=(*image).dx;
	float dy=(*image).dy;
	float dz=(*image).dz;
	int XY=X*Y;
	int voxels=X*Y*Z;
	int voxel;
	int focus;
	int xi,yi,zi;
	int Nclusters=0;
	int NvalidClusters=0;
	int c;
	int iexp;
	float *img=NULL;
	int *voxelnumber=NULL;
	short int *cl=NULL;
	short int *LookUp=NULL;
	int *Contributor=NULL;
	int *SignificantContributor=NULL;
	int SignificantContributorCount;

	//default the cluster numbers to zero
	memset((*C).cluster,0,sizeof(short int)*Nfoci);

	if (width<=0.0)
	{
		goto END;
	}

	///shift the coordinates by mean shift clustering
	MeanShiftCoordinates(xc, yc, zc, C, ToCluster, critical, width);

	if (!(img=(float *)calloc(voxels,sizeof(float))))
		goto END;
	if (!(voxelnumber=(int *)malloc(Nfoci*sizeof(int))))
		goto END;
	if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
    if (!(LookUp=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;
	if (!(Contributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(SignificantContributor=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;

	///project the mean shifted coordinates into the image
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).p[focus]<=critical)
		{
			xi=(int)((xc[focus] + x0)/dx+0.5);
			yi=(int)((yc[focus] + y0)/dy+0.5);
			zi=(int)((zc[focus] + z0)/dz+0.5);

			voxel=xi + yi*X + zi*XY;

			if (voxel>=0 && voxel<voxels)
			{
				voxelnumber[focus]=voxel;
				if (ToCluster[focus])
					img[voxel]+=1.0;///only count the significant coordinates
			}
		}
	}


	///Save the coordinates of the cluster centres and set cluster numbers
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (img[voxel]>=(double)MinStudiesPerCluster)
		{
			XYZfromVoxelNumber(voxel, &xi, &yi, &zi, X,Y,Z);

			xc[Nclusters]=dx*xi - x0;
			yc[Nclusters]=dy*yi - y0;
			zc[Nclusters]=dz*zi - z0;

			Nclusters++;
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).p[focus]<=critical && voxelnumber[focus]==voxel)
				{
					cl[focus]=Nclusters;//This can include multiple coordinates from the same study
				}
			}

		}
	}
	//at this point Nclusters could be an overestimate as not all will be valid

	//Nclusters = LabelClusters(x, y, z, c, ToCluster, Nfoci, xc, yc, zc);


	///Save the cluster numbers so that only the most dense within study is part of the cluster
	for (c=1; c<=Nclusters; c++)
	{

		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			Contributor[iexp]=-1;
			SignificantContributor[iexp]=-1;
		}

		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp &&  cl[focus]==c)
				{
					if (Contributor[iexp]<0)
					{
						Contributor[iexp]=focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
					else if ((*C).p[focus]<(*C).p[Contributor[iexp]])
					{
						Contributor[iexp] = focus;
						if (ToCluster[focus])
							SignificantContributor[iexp]=focus;
					}
				}
			}
		}
		SignificantContributorCount=0;
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (SignificantContributor[iexp]>=0)
			{
				SignificantContributorCount++;
			}
		}
		if (SignificantContributorCount>=MinStudiesPerCluster)
		{
			xc[NvalidClusters]=xc[c-1];
			yc[NvalidClusters]=yc[c-1];
			zc[NvalidClusters]=zc[c-1];

			NvalidClusters++;
			LookUp[c]=NvalidClusters;///stores true cluster numbering
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (Contributor[iexp]>=0)
				{
					(*C).cluster[Contributor[iexp]] = c;///temporary cluster number to be switched using LookUp
				}
			}
			///for valid clusters coordinates not included need the excluded flag set
            for (focus=0; focus<Nfoci; focus++)
            {
                if (cl[focus]==c && !(*C).cluster[focus]) excluded[focus]=1;
            }
		}
	}


	///change cluster numbers to consecutive numbers
	for (focus=0; focus<Nfoci; focus++)
    {
        if ((c=(*C).cluster[focus]))
        {
            (*C).cluster[focus]=LookUp[c];
        }
    }

END:

	if (img)
		free(img);
	if (voxelnumber)
		free(voxelnumber);
	if (cl)
		free(cl);
    if (LookUp) free(LookUp);
	if (Contributor)
		free(Contributor);
	if (SignificantContributor)
		free(SignificantContributor);
	return NvalidClusters;
}
*/
