/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Statistics_H)
//Do Nothing
#else

#define Statistics_H 1
//--------------------------------------------------------------------------------------------
//                              routines for statistics
//                              12th Mar 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "loader.h"


#define ID_INDIVIDUAL_ROIS 1
#define ID_INDIVIDUAL_OBJECTS 2
#define ID_ALL_ROIS 3

struct Hist{
   int *H;                       //the histogram
   int N;                        //Number of Bins
   int count;                    //a normaliser; sum of entries
   float min;                    //the min intensity value
   float max;                    //the max intensity value
   float binwidth;               //the binwidth (I=min+i*binwidth+binwidth/2) 0<=i<=N
   float scale;                  //from the Image structure
   float offset;
};



struct DescriptiveStats{
  float mean;
  float min;
  float max;
  float sd;
  float median;
  float Q25;
  float Q75;
  int voxels;
};



#include "display.h"

HWND hStatsDlg;
INT_PTR CALLBACK StatsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int GetStandardizedHistogramStats(struct Image *image, unsigned char mask[], struct Hist *hist, float widthfraction);
int SaveHistogramFile(struct Hist *hist, char filename[]);
int GetHistogramFileName(char filename[], int save);
int SaveImageHistogram(struct Image *image, float widthfraction, int option);
int GetROIhistogram(struct Image *image, struct Hist *hist, int roi, float widthfraction);
int GetObjectHistogram(struct Image *image, struct Hist *hist, int object, float widthfraction);
struct DescriptiveStats GetDescriptiveStatsFromHistogram(struct Hist *hist);
int DrawSelectedROI(struct Picture *picture, HDC hDC);
int SaveROIStats(HWND hwnd, struct Image *image, int SumObjects);
int SaveWholeImageStats(struct Image *image);
int CombineHistogramFiles(void);
float IntensityOfBin(struct Hist *hist, int bin);
#endif
