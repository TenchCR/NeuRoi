/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Numerical_H)
//Do Nothing
#else


#define Numerical_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>




//Registration parameter definitions
//2, 30, 3, 60, 4, 105, 5, 168, 6, 252; orders and numbers of parameters
#define RIGID6 6
#define AFFINE12 12      //3 rotate, 3 translate, 3 scale, 3 shear
#define REGISTRATION_PARAMETERS_ORDER2 30
#define REGISTRATION_PARAMETERS_ORDER3 60
#define REGISTRATION_PARAMETERS_ORDER4 105
#define REGISTRATION_PARAMETERS_ORDER5 168
#define MAX_REGISTRATION_PARAMETERS 60//the maximum we are going to use
#define MAX_REGISTRATION_POLY_ORDER 3
#define DWI_REG_ORDER 1//MUST BE LESS THAN MAX_REGISTRATION_POLY_ORDER
#define DWI_REG_PARAMETERS 12
#define ROTATE 0
#define TRANSLATE 3
#define SCALE 6
#define SHEAR 9

#define SQRT_2PI 2.506628275
#define PI 3.14159265
#define PIx2 6.28318531


//Mann Whitney Alternatives
#define TWO_TAILED 1
#define X_GT_Y 2
#define Y_GT_X 3


struct Complex{
	float r;
	float i;
};


struct ThreeVector{
       float x;
       float y;
       float z;
};
struct FourFloatVector{
        float x;
        float y;
        float z;
        float f;
};


struct AffineMatrix{
	float M[4][4];
};


struct Spherical{
    float theta;              //0<=theta<pi
    float phi;                //0<=phi<2pi
};

struct TwoNorm
{
    double x;
    double y;
};

struct Bivariate
{
    double x;
    double y;
};

struct BinLogistic
{
    char *resp;
    double *Mat;
    int Nresp;
    int Regularise;
};

int PermutationList(int N, int permutation[], int *ci, int *i);
int TestPermutationList(void);

int EMalgorithmNormal(double member[], double mean[], double SD[], double mix[], int N, double x[], int Nx);
int TestEMalgorithm(void);


int Cholesky(double A[], int N, double L[]);
int TestCholesky(void);

int rMVnorm(double s[], double mean[], double Sigma[], int N);
int TestrMVnorm(void);

double PearsonsBootstrap(double X[], double Y[], int N, double *lo, double *hi, double confidence, double *sd, int Samples);
double Pearsons(double X[], double Y[], int N);
double CorrelationPvalue(double r, int n);

double Integrate(double A, double B, int maxevaluations, double err, double (*f)(double, void *), void *H);
int TestIntegrate(void);

int QuickSort(double *data, int sort[], int N);
int RadixSort(double data[], int sort[], int N, int dp);
int TestRadixSort(int N, int dp);
int TestQuickSort(int N);
int SortIntegers(int values[], int sort[], int N);

double MedianValueDouble(int N, double s[]);
double MedianValueDoubleEx(int N, double s[], int sort[]);
double MedianValueDoubleFastApprox(int N, double s[]);
double MeanValueDouble(int N, double s[]);
double MeanValueFloat(int N, float s[]);
double Var(double d[], int N);
double VarFloat(float d[], int N);

int ScaleInitialisation(double P0[], int N, double target, double scale[], double (*GetError)(double *, int, void *), void *H);

double PowellMinimisation(double Vbest[], int N, double scale[], int Scale,
                               double (*Get_Error)(double *, int, void *), void *H, double tol);
int TestPowell(void);

double DownHillSimplex(double P[], int N, double scale[], int Scale,
                        double (*GetError)(double *, int, void *), void *H, int Nshrinks);

double QuadraticExtrema(double a, double b, double c, double fa, double fb, double fc);

double StraightLineFit(double x[], double y[], int N, double *mu, double *beta);
int LeastSquaresFitting(double M[], double b[], double x[], int c, int r);

int SimultaneousEquationSolverPivoting(double V[], double b[], int n);

int LUfactorisationWithPivoting(double LU[], int N, int index[], double *d);
double Determinant(double A[], int n);
double DeterminantEx(double A[], int n, int index[], double *d);
int SolveLUsystem(double LU[], int N, double x[], double b[], int index[]);
int TestLU(void);

int PsuedoInverse(double M[], int rows, int cols);
int PsuedoInverseEx(double M[], double Var[], int rows, int cols);
double LinearModel(double X[], double knowns[], double params[], double V[], int Nknowns, int Nparams);
double SimpleLinearRegression(double y[], double x[], int N, double *a, double *b, double *pa, double *pb);
int TestSimpleLinearRegression(void);
int InvertMatrix(double M[], double LU[], double V[], double x[], int index[], int N);
int InvertMatrixA(double M[], int N);
int Inverse2x2OR3x3Matrix(double M[], int N);
int Inverse2x2OR3x3SymmetricMatrix(double M[], int N);
int JacobiEigenSystemSolver(double A[], double V[], double e[], int N, int evects);

int RK2(void *dat, float h, float V[], int n, int MAX, double (*func)(void *dat, float *P, int n, float *K));

float VectorLength(float v[], int n);
int AddVectors(float V1[], float V2[], int n);


struct AffineMatrix AffineTransformationMatrix(double ThetaX, double ThetaY, double ThetaZ, double x, double y, double z);
struct AffineMatrix AffineTransformationMatrix12param(double ThetaX, double ThetaY, double ThetaZ, double x, double y, double z,
														double scalex, double scaley, double scalez,
							                             double shearxy, double shearxz, double shearyz);
int AffineTransformCoordinates(float *x, float *y, float *z, struct AffineMatrix *matrix);
int PolynomialCoordinateTransformQuadratic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[]);
int PolynomialCoordinateTransformCubic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[]);
int PolynomialCoordinateTransformQuartic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[]);
int PolynomialCoordinateTransformQuintic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[]);


double TwoNormalMixtureMean(double alpha, double mean1, double mean2);
double TwoNormalMixtureVar(double alpha, double mean1, double mean2, double sigma1, double sigma2);

double GaussRandomNumber_BoxMuller(double mean, double sd);
struct TwoNorm Gauss2RandomNumbers_BoxMuller(double mean, double sd);
int TestBoxMuller(void);
int TestGauss2RandomNumbers_BoxMuller(void);

double BesselI0(double x);
double Rician(double A, double M, double sigma2);
int TestRician(double A, double sigma2);




double Sigmoid(double x);
double InvSigmoid(double s);

double Sigmoidpm1(double x);
double InvSigmoidpm1(double s);
int TestSigmoidpm1(void);

double CubicPolynomialInterpolation(double V[], double x);
double SmoothCurveFit(double V[], int N, double x);
double SmoothCurveFitPeriodic(double V[], int N, double x);
double SmoothSurfaceFit(double V[], int N, int M, double x, double y);
double SmoothPeriodicSurfaceFit(double V[], int N, int M, double x, double y);

int SmoothCurveCoefficients(double coef[], int N, double x);
int SmoothInterpolation3D(double coef[], int M, int N, int P, double x, double y, double z);


float DPThreeVector(struct ThreeVector *V1, struct ThreeVector *V2);
int NormaliseThreeVector(struct ThreeVector *V);
double LengthThreeVector(struct ThreeVector *V);
struct ThreeVector CrossProduct(struct ThreeVector V1, struct ThreeVector V2);
struct ThreeVector SubtractThreeVector(struct ThreeVector V,struct ThreeVector V1);
double AngleBetweenThreeVectors(struct ThreeVector V,struct ThreeVector V1);

double Factorial(int i);
struct Complex SphericalHarmonic(int l, int m, double theta, double phi);
double AssociatedLegendrePolynomial(int l, int m, double x);

struct Complex ComplexAdd(struct Complex c1, struct Complex c2);
struct Complex ComplexSub(struct Complex c1, struct Complex c2);
struct Complex ComplexMul(struct Complex c1, struct Complex c2);
struct Complex ComplexDiv(struct Complex c1, struct Complex c2);
struct Complex Conjugate(struct Complex c);
double ComplexMag(struct Complex c);
struct Complex ComplexExp(double x);

int Cartesian2Spherical(double x, double y, double z, double *R, double *theta, double *phi);



int Quantiles(float *data, int N, float quantiles[], int Nquantiles);

double ErrorFunction(double x);
double ErrorFunctionC_Large_x(double x);
int TestErrorFunction(void);
int TestErrorFunctionC_Large_x(void);
double StandardNormalTailArea(double x);
int TestStandardNormalTailArea(void);
double NormalCDF(double x, double mean, double sd);
double NormalDistribution(double mean, double v, double x);
double TruncatedNormal(double mean, double v, double x, double a, double b);
double TruncatedNormalCDF(double mean, double v, double x, double a, double b);
int TestNormalCDF(double x, double mean, double sd);
double BivariateNormal(double x, double y, double mx, double my, double vx, double vy, double rho);
int TestBivariateNormal(void);
int rBivariateNorm(struct Bivariate *rB, double mx, double my, double sx, double sy, double rho);
int TestrBivariateNorm(void);
double MultiVariateNormalDensity(double s[], double mean[], double Sigma[], int N);
double dNorm(double x, double m, double v);
int BivariateNormXgivenY(double y, double mx, double my, double vx, double vy, double rho,
                         double *mxGivenY, double *vxGivneY, double *prefactor);
int BivariateNormYgivenX(double x, double mx, double my, double vx, double vy, double rho,
                         double *myGivenX, double *vyGivneX, double *prefactor);
int TestBivariateNormXgivenY(void);
double GammaCDF(double x, double a, double b);
int testGammaCDF(void);
double GammaFunctionLog(double xx);
double DiGamma(double x);
double LogGammaDistribution(double x, double k, double theta);
double LogGammaDistributionAlphaBeta(double x, double alpha, double beta);
int TestGammaDistribution(void);
double IncompleteGammaLower(double a, double x);
double IncompleteGammaP(double a, double x);
int TestIncompleteGamma(void);
int TestIncompleteGammaP(void);
double IncompleteGammaQ(double a, double x);
double ChiSquaredCDF(double dof, double z);
double ChiSquaredPvalue(double dof, double z);
int TestChiSquaredCDF(void);
double BetaI(double a, double b, double x);//Inclomplete Beta Function
double BetaDistribution(double x, double a, double b);
double BetaComplete(double x, double y);
int BetaDistributionParameterEstimatesEx(double mean, double var, double *a, double *b);
int BetaDistributionParameterEstimates(double x[], int N, double *a, double *b);
int TestBetaI(void);
double TwoSidedTtest(double t, int df);
int TestTwoSidedTtest(void);
double tdist(double t, double dof);
int Test_tdist(double t, int dof);
double MannWhitney(double X[], int nX, double Y[], int nY, int Alternative);
int TestMannWhitney(void);
double CompareModels(double RSSred, int dfred, double RSSfull, int dffull);
double Fcf(int df1, int df2, double alpha);
int TestFcf(void);
int TestTvalue(void);
double Zvalue(double p);
double ZscoreFromT(double t, int df);
double Tvalue(double p, double df, int OneSided);
int TestZvalue(void);
double TstatisticFromZscore(double Z, int df);
double ZscoreFromT(double t, int df);
int TestTstatisticFromZscore(void);
int TestZscoreFromT(double t, int df);


int BayesLinearRegressionEx(double knowns[], double X[], double XtX[], double InvXtX[], double means[], int rows, int columns, double PriorInvCov[], double PriorMean[]);
int BayesLinearRegression(double knowns[], double X[], double means[], int rows, int columns, double PriorCov[], double PriorMean[]);
int BayesMVnormalKnownCovariance(double mean[], double cov[], double Pmean[], double Pcov[], int N);
double MCMCSampling(double Sample[], double currentposterior, double Proposed[], int (*Proposal)(double *), int N, double (*Posterior)(double *, int, void *), void *dat);
int PosteriorRejectionSampling(double Sample[], int (*Prior)(double *), int N, double MaxLikelihood, double (*Likelihood)(double *, int, void *), void *dat);


double FDR(double p[], int N, double critical);
double FDRext(double fdr, double p[], int Np, int Nall);
double GoldenSearch(double V[], double dir[], int n, double Ecurrent, double (*Get_Error)(double *, int, void *), void *H, int shrinks);
int EstimateFalseDiscoveryRate(double p[], double fdr[], int N);

double FishersTestOneSided(int a, int b, int c, int d);
int TestFisher(HWND hwnd);
int TestFisherForPaper(HWND hwnd, int n,int tests);
double FishersP(int a, int b, int c, int d);
double PhiCoefficient(int a, int b, int c, int d);
double PhiCoefficientBootstrap(int a, int b, int c, int d, double *se);
double LogFactorial(int n);
double Combinations(int N, int k);
int NextPermutation(int set[], int n, int N);
int TestNextPermutation(void);

double BinomialCDF(double p, int N, int n);
int TestBinomialCDF(void);
double BinomialP(double p, int N, int n);
int BinomialRandomSample(double p, int N);
int TestBinomialRandomSample(void);


double OwensTintegrand(double x, void*vh);
double OwensT(double h, double a);
int TestOwensT(double h, double a);

double LogOdds(double p);
double InvLogOdds(double LogOdds);
double RegularisedBinaryLogisticRegressionLL(char *resp, double *Mat, double *param, int Nparam, int Nresp);
double BinaryLogisticRegressionLL(char *resp, double *Mat, double *param, int Nparam, int Nresp);
double BinaryLogisticRegression(char *resp, double *Mat, double *param, int Nparam, int Nresp);
double BinaryLogisticRegressionIRLS(char *resp, double *X, double *param, double *se, int Nparam, int Nresp);
double BLRaccuracy(char *resp, double *X, double *param, int Nparam, int Nresp, double *ExpectedAccuracy);
double BLRLeaveOneOutAccuracy(char *resp, double *X, int Nparam, int Nresp, double *ExpectedAccuracy);
double ExpectedBLRaccuracy(char *resp, int Nresp);

int TestBinaryLogisticRegression(void);


#endif
