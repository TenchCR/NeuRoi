/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"
#include "talairachfunctions.h"



//================================================================================
//================================================================================
//================================================================================
//TalGM[] is an image only of GM structures from the Talairach altas
//x0,y0,z0 are the location
//find the voxel closest to {x0,y0,z0} and return (int)TalGM[voxel]
//================================================================================
//================================================================================
//================================================================================
int NearestGM(float *TalGM, int X, int Y, int Z, int x0, int y0, int z0)
{
    int x,y,z;
    int voxel;
    int nearest=0;
    int YZ, zXY;
    int entry;
    int start;
    double d,d1;
    double a,b;

    //no Talairach image loaded
    if (!X) return 0;

    start=z0;
    if (start<0) start=0;
    if (start>=Z) start=Z-1;

    d1=1000000.0;
    for (z=start; z<Z; z++)
    {
        zXY=z*X*Y;
        b=(z-z0)*(z-z0);
        if (b<d1)
        {
            for (y=0; y<Y; y++)
            {
                YZ=y*X + zXY;
                a=(y-y0)*(y-y0);
                if ((a+b)<d1)
                {
                    for (x=0; x<X; x++)
                    {
                        voxel=x + YZ;
                        if ((entry=(int)TalGM[voxel]))
                        {
                            d=(x-x0)*(x-x0) + a + b;

                            if (d<d1)
                            {
                                d1=d;
                                nearest=entry;
                            }
                        }
                    }
                }
            }
        }
    }

    for (z=start-1; z>=0; z--)
    {
        zXY=z*X*Y;
        b=(z-z0)*(z-z0);
        if (b<d1)
        {
            for (y=0; y<Y; y++)
            {
                YZ=y*X + zXY;
                a=(y-y0)*(y-y0);
                if ((a+b)<d1)
                {
                    for (x=0; x<X; x++)
                    {
                        voxel=x + YZ;
                        if ((entry=(int)TalGM[voxel]))
                        {
                            d=(x-x0)*(x-x0) + a + b;

                            if (d<d1)
                            {
                                d1=d;
                                nearest=entry;
                            }
                        }
                    }
                }
            }
        }
    }


    return nearest;
}

//================================================================================================
//================================================================================================
//================================================================================================
//get the nearest GM label given a list
//return -1 if no label found
//================================================================================================
//================================================================================================
//================================================================================================
int NearestGMlabel(struct ThreeVector *VL, int *GMlabels, int Nlabels, float Tal_x, float Tal_y, float Tal_z)
{
    int label;
    double minDist, dist;
    int NearestLabel=-1;

    minDist=100000000.0;
    for (label=0; label<Nlabels; label++)
    {
        dist = (Tal_x - VL[label].x)*(Tal_x - VL[label].x) + (Tal_y - VL[label].y)*(Tal_y - VL[label].y) + (Tal_z - VL[label].z)*(Tal_z - VL[label].z);
        if (dist<minDist)
        {
            minDist=dist;
            NearestLabel=GMlabels[label];
        }
    }
    return NearestLabel;
}

//================================================================================================
//================================================================================================
//================================================================================================
//GET A LIST OF POSITIONS OF GM LABELS IN THE TALAIRACH IMAGE
//AND A LIST OF THE LABELS
//================================================================================================
//================================================================================================
//================================================================================================
int GetGMlabelVectors(struct Image *Tal, struct ThreeVector *VL, int *GMlabels, int Nlabeled)
{
    int voxel, voxels=(*Tal).X*(*Tal).Y*(*Tal).Z;
    int L,label;
    int x,y,z;
    float dx,dy,dz;
    float x0,y0,z0;

    dx=(*Tal).dx;
    dy=(*Tal).dy;
    dz=(*Tal).dz;
    x0=(*Tal).x0;
    y0=(*Tal).y0;
    z0=(*Tal).z0;

    L=0;
    for (voxel=0; (voxel<voxels) && (L<Nlabeled); voxel++)
    {
        if ((label=(int)(*Tal).img[voxel]))
        {
            XYZfromVoxelNumber(voxel, &x, &y, &z, (*Tal).X, (*Tal).Y, (*Tal).Z);
            VL[L].x = dx*x - x0;
            VL[L].y = dy*y - y0;
            VL[L].z = dz*z - z0;
            GMlabels[L] = label;
            L++;
        }
    }

    return 1;
}


//================================================================================================
//================================================================================================
//================================================================================================
//is label GM?
//================================================================================================
//================================================================================================
//================================================================================================
//================================================================================================
int IsLabelGM(char labels[], int label, int max)
{

    char *a;

    a=FindEntryInTalairachLabels(labels, max, label);

    if (strstr(a,"Gray Matter")) return 1;

    return 0;

}
//================================================================================================
//================================================================================================
//================================================================================================
//find the number of entries in the Talairach labels DB
//also replace the carriage returns with '\0'
//================================================================================================
//================================================================================================
//================================================================================================
int BiggestTalairachLabel(char labels[], int L)
{
    int i=0, count=0;

    for (i=0; i<L; i++)
    {
        if (labels[i]=='\0')
        {
            count++;
        }
    }

    return count;
}
//================================================================================================
//================================================================================================
//================================================================================================
//Find Entry
//L is the number of characters in char array *labels
//================================================================================================
//================================================================================================
//================================================================================================
char *FindEntryInTalairachLabels(char *labels, int L, int entry)
{
    int len=0;
    int i;
    char txt[256];

    for (i=0; i<entry; i++)
    {
        if (len<L) len+=strlen(&labels[len])+1;//+1 to get beyond the '\0' end of string
    }

    if (len>=L) return labels;

    //remove the number at the beginning
    i=atoi(&labels[len]);
    sprintf(txt,"%d",i);
    len+=strlen(txt);

    return &labels[len];
}

//================================================================================================
//================================================================================================
//================================================================================================
//Are labels are matched, except for lobe and cell type; except for Brodmann areas, which must be matched
//Tissue Type
//Hemisphere
//Gyrus
//Cell type if Brodmann areas
//================================================================================================
//================================================================================================
//================================================================================================
int MatchedLevels(char labels[], int N, int l1, int l2)
{

    char *b1, *b2;
    char *e1, *e2;

    b1 = FindEntryInTalairachLabels(labels, N, l1);
    b2 = FindEntryInTalairachLabels(labels, N, l2);


    //MUST BE CEREBRUM IF L1!=0
    if (l1 && ((!strstr(b1,"Cerebrum")) || (!strstr(b2,"Cerebrum")))) return 0;




    //do the hemispheres match?
    if (l1 && (!IsMatchedString(b1, b2, 0))) return 0;//if the Hemispheres dont match, its not a match

    //match the Tissue Type, which is the Fourth comma separated column
    if (l1 && (!IsMatchedString(b1, b2, 3))) return 0;//if the Tissue Types dont match, its not a match


    //now check to see if they are both the same Brodmann areas
    //If so they must be merged
    e1 = strstr(b1, "Brodmann");
    e2 = strstr(b2, "Brodmann");
    if (e1 || e2)
    {
        if (e1 && e2)
        {
            if ((atoi(&e1[13]) == atoi(&e2[13])) && (IsMatchedString(b1, b2, 2))) return 1;
        }
        else return 0;
    }



    //merge thalamus
    e1 = strstr(b1, "Thalamus");
    e2 = strstr(b2, "Thalamus");
    if (e1 || e2)
    {
        if (e1 && e2) return 1;
        else return 0;
    }

    //merge caudate
    e1 = strstr(b1, "Caudate");
    e2 = strstr(b2, "Caudate");
    if (e1 || e2)
    {
        if (e1 && e2) return 1;
        else return 0;
    }

    //merge caudate
    e1 = strstr(b1, "Claustrum");
    e2 = strstr(b2, "Claustrum");
    if (e1 || e2)
    {
        if (e1 && e2) return 1;
        else return 0;
    }

    if (!l1)
    {
        if (strstr(b2,"Cerebrum"))
        {
            if ((IsMatchedString(b1, b2, 2) || IsMatchedString(b1, b2, 4))) return 1;
        }
        else
        {
            if (IsMatchedString(b1, b2, 2) && IsMatchedString(b1, b2, 4)) return 1;
        }
    }


    return 0;
}


//================================================================================================
//================================================================================================
//================================================================================================
//are the two strings of characters a match?
//the boundary conditions are ',' or '\0'
//column is the column in the database; 0,1,2,3,4
//================================================================================================
//================================================================================================
//================================================================================================
int IsMatchedString(char *i1, char *i2, int column)
{
    int index;
    int i;
    char *s1,*s2;

    if ((column<0) || (column>4)) return 0;


    s1=i1;
    s2=i2;

    for (i=0; i<column; i++)
    {
        s1 = strstr(&s1[1],",");
        s2 = strstr(&s2[1],",");
    }

    index = 1;
    while ((s1[index] != ',') && (s1[index] != '\0') && (s2[index] != ',') && (s2[index] != '\0'))
    {
        if ((s1[index] != s2[index])) return 0;
        index++;
    };
    if ((s1[index] != s2[index])) return 0;

    return 1;
}

//================================================================================================
//================================================================================================
//================================================================================================
//are the two strings of characters a match?
//the boundary conditions are ',' or '\0'
//column is the column in the database; 0,1,2,3,4
//================================================================================================
//================================================================================================
//================================================================================================
int IsSubLabelInLabel(char *Label, char *SubLabel, int column)
{
    int i;
    char *s;

    if ((column<0) || (column>4)) return 0;


    s=Label;

    for (i=0; i<column; i++)
    {
        s = strstr(&s[1],",");
    }
//MessageBox(NULL,&s[1],SubLabel,MB_OK);

    if (strstr(s,SubLabel)) return 1;

    return 0;
}


//================================================================================================
//================================================================================================
//================================================================================================
//remove the GM voxels from the Talairach image
//================================================================================================
//================================================================================================
//================================================================================================
int RemoveNonGM(struct Image *Tal, char labels[], int LengthLabels, int BiggestLabel)
{
    int voxel,voxels=(*Tal).X*(*Tal).Y*(*Tal).Z;
    int lab;
    char *gm=NULL;

    if (!(gm=(char *)malloc(BiggestLabel+1))) return 0;


    if (    !((*Tal).img) || !(labels)  ) return 0;

    for (lab=0; lab<=BiggestLabel; lab++)
    {
        gm[lab]=0;
        if (IsLabelGM(labels, lab, LengthLabels))
        {
            gm[lab]=1;
        }
    }

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((int)(*Tal).img[voxel]<=BiggestLabel) && (!gm[(int)(*Tal).img[voxel]]) ) (*Tal).img[voxel]=0.0;
        if ((int)(*Tal).img[voxel]>BiggestLabel) (*Tal).img[voxel]=0.0;
    }

//CHECK THIS GM ONLY IMAGE
//sprintf((*Tal).filename,"c://temp//test.nii");
//Save(Tal);

    free(gm);

    return 1;
}



//================================================================================================
//================================================================================================
//================================================================================================
//Load the labels data
//================================================================================================
//================================================================================================
//================================================================================================
char *LoadTalairachLabels(int *N)
{
    int i;
    char fname[MAX_PATH];
    char *labels=NULL;
    FILE *fp;

    *N=0;

    sprintf(fname,"%s\\Talairach\\labels.txt", ExecutableDirectory);
    if (!(i=Get_File_Size(fname))) return 0;

    if (!(labels=(char *)malloc(i))) return 0;

    if ( (fp=fopen(fname,"r")) )
    {
        (*N)=fread(labels, 1, i, fp);
        fclose (fp);
    }

    //CONVERT RETURN (\r) TO END OF STRING (\0)
    //CONVERT '.' TO ',' FOR CSV
    for (i=0; i<(*N); i++)
    {
        if (labels[i]=='\r')
        {
            labels[i]='\0';
        }
        if (labels[i]=='.')
        {
            labels[i]=',';
        }
    }

    /*fp=fopen("c://temp//test.txt","wb");
    fwrite(labels,1,i,fp);
    fclose(fp);*/

    return labels;
}

//================================================================================================
//================================================================================================
//================================================================================================
//create a cumulative histogram, normalised to 1
//There are Nlabels labels
//H[0-Nlabels+1] is the histogram
//Tal is the image to turn into the cumulative histogram, with dimensions X,Y,Z
//================================================================================================
//================================================================================================
//================================================================================================
int GetCumulativeTalairachStructureHistogram(float *Tal, int X, int Y, int Z, double *H, int Nlabels)
{

    int label;

    GetTalairachStructureHistogram(Tal, X, Y, Z, H, Nlabels);

    for (label=1; label<=Nlabels; label++) H[label]+=H[label-1];

    if (H[Nlabels])
    {
        for (label=1; label<=Nlabels; label++) H[label]/=H[Nlabels];
    }

    return 1;
}

//================================================================================================
//================================================================================================
//================================================================================================
//create a cumulative histogram, normalised to 1
//There are Nlabels labels
//H[0-Nlabels+1] is the histogram
//Tal is the image to turn into the cumulative histogram, with dimensions X,Y,Z
//================================================================================================
//================================================================================================
//================================================================================================
int GetTalairachStructureHistogram(float *Tal, int X, int Y, int Z, double *H, int Nlabels)
{
    int voxel,voxels=X*Y*Z;

    memset(H,0,(Nlabels+1)*sizeof(double));

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((int)Tal[voxel]<=Nlabels))  H[(int)Tal[voxel]]+=1.0;
    }
    H[0]=0.0;

    return 1;
}


//================================================================================================
//================================================================================================
//================================================================================================
//COMPUTE A NEAREST GM IMAGE FROM A GM MASK
//================================================================================================
//================================================================================================
//================================================================================================
int GetNearestGMimage(struct Image *GMmask, short int *nearGM, struct Image *Tal)
{
    int voxel;
    int x,y,z;
    int Xmask,Ymask,Zmask;
    float x0,y0,z0;
    int xi,yi,zi;
    int label;

    Xmask=(*GMmask).X;
    Ymask=(*GMmask).Y;
    Zmask=(*GMmask).Z;

    voxel=0;
    for (z=0; z<Zmask; z++)
    {
        for (y=0; y<Ymask; y++)
        {
            for (x=0; x<Xmask; x++)
            {
                //voxel = x+y*Xmask+z*Xmask*Ymask;
                if ((*GMmask).img[voxel])
                {
                    x0=((*GMmask).dx*x - (*GMmask).x0);
                    y0=((*GMmask).dy*y - (*GMmask).y0);
                    z0=((*GMmask).dz*z - (*GMmask).z0);

                    xi=(int)((x0+(*Tal).x0)/(*Tal).dx+0.5);
                    yi=(int)((y0+(*Tal).y0)/(*Tal).dy+0.5);
                    zi=(int)((z0+(*Tal).z0)/(*Tal).dz+0.5);

                    label=NearestGM((*Tal).img, (*Tal).X, (*Tal).Y, (*Tal).Z, xi,yi,zi);

                    nearGM[voxel]=label;
                }
                else nearGM[voxel]=0;

                voxel++;
            }
        }
    }

    return 1;
}
//=============================================================================

struct LabelTxt
{
    char lt[40];
};
int SetFirstLevel(struct LabelTxt *big, struct LabelTxt *little);
int SetSecondLevel(struct LabelTxt *big, struct LabelTxt *little);
int SetThirdLevel(struct LabelTxt *big, struct LabelTxt *little);
int SetFourthLevel(struct LabelTxt *big, struct LabelTxt *little);
int SetFifthLevel(struct LabelTxt *big, struct LabelTxt *little);

int ShortTalairachLabel(char *BigLabel, char *shortlabel, char *sep)
{
    struct LabelTxt FirstLong[7];
    struct LabelTxt FirstShort[7];
    struct LabelTxt SecondLong[12];
    struct LabelTxt SecondShort[12];
    struct LabelTxt ThirdLong[55];
    struct LabelTxt ThirdShort[55];
    struct LabelTxt FourthLong[3];
    struct LabelTxt FourthShort[3];
    struct LabelTxt FifthLong[30];
    struct LabelTxt FifthShort[30];
    int L1,L2,L3,L4,L5;
    int i;
    int BA=-1;

    SetFirstLevel(FirstLong, FirstShort);
    L1=-1;
    for (i=0;i<7 && L1<0;i++)
    {
        if (IsSubLabelInLabel(BigLabel, FirstLong[i].lt, 0)) L1=i;
    }

    SetSecondLevel(SecondLong, SecondShort);
    L2=-1;
    for (i=0;i<12 && L2<0;i++)
    {
        if (IsSubLabelInLabel(BigLabel, SecondLong[i].lt, 1)) L2=i;
    }


    SetThirdLevel(ThirdLong, ThirdShort);
    L3=-1;
    for (i=0;i<55 && L3<0;i++)
    {
        if (IsSubLabelInLabel(BigLabel, ThirdLong[i].lt, 2)) L3=i;
    }


    SetFourthLevel(FourthLong, FourthShort);
    L4=-1;
    for (i=0;i<3 && L4<0;i++)
    {
        if (IsSubLabelInLabel(BigLabel, FourthLong[i].lt, 3)) L4=i;
    }

    SetFifthLevel(FifthLong, FifthShort);
    L5=-1;
    for (i=0;i<30 && L5<0;i++)
    {
        if (IsSubLabelInLabel(BigLabel, FifthLong[i].lt, 4)) L5=i;
    }
    if (L5==3)//Brodmann Area
    {
        BA=atoi(&BigLabel[strlen(BigLabel)-2]);
    }



    shortlabel[0]='\0';
    if (L1>=0) sprintf(shortlabel,"%s",FirstShort[L1].lt);
    else sprintf(shortlabel,"*");

    if (L2>=0) sprintf(shortlabel,"%s%s%s",shortlabel,sep,SecondShort[L2].lt);
    else sprintf(shortlabel,"%s%s*",shortlabel,sep);

    if (L3>=0) sprintf(shortlabel,"%s%s%s",shortlabel,sep,ThirdShort[L3].lt);
    else sprintf(shortlabel,"%s%s*",shortlabel,sep);

    if (L4>=0) sprintf(shortlabel,"%s%s%s",shortlabel,sep,FourthShort[L4].lt);
    else sprintf(shortlabel,"%s%s*",shortlabel,sep);

    if (L5>=0) sprintf(shortlabel,"%s%s%s",shortlabel,sep,FifthShort[L5].lt);
    else sprintf(shortlabel,"%s%s*",shortlabel,sep);
    if (L5==3) sprintf(shortlabel,"%s %d",shortlabel,BA);


    return 1;
}
//==============================================================
int TestShortTalairachLabel(HWND hwnd)
{

    struct Image Tal;
    char fname[MAX_PATH];
    char *labels=NULL;
    char shortlabel[256];
    int Nl, nTalEntries;
    int i;
    FILE *fp;

    sprintf(fname,"%s//labels short.txt",REPORT_FOLDER);
    fp=fopen(fname,"w");

    memset(&Tal,0,sizeof(struct Image));

    //LOAD THE TALAIRACH DATA
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &Tal, 0)) goto END;
    labels=LoadTalairachLabels(&Nl);
    if (Nl<=0) goto END;
    nTalEntries=BiggestTalairachLabel(labels, Nl);

    for (i=0;i<=nTalEntries;i++)
    {
            ShortTalairachLabel(FindEntryInTalairachLabels(labels, Nl, i), shortlabel, ".");
            //MessageBox(NULL,FindEntryInTalairachLabels(labels, Nl, i),"",MB_OK);
            fprintf(fp,"%d\t%s\n",i,shortlabel);
    }



    fclose(fp);

END:
    ReleaseImage(&Tal);
    if (labels) free(labels);

    return 0;
}
//=============================================================
int SetFirstLevel(struct LabelTxt *big, struct LabelTxt *little)
{
    sprintf(big[0].lt,"Left Cerebrum");
    sprintf(big[1].lt,"Right Cerebrum");
    sprintf(big[2].lt,"Left Cerebellum");
    sprintf(big[3].lt,"Right Cerebellum");
    sprintf(big[4].lt,"Left Brainstem");
    sprintf(big[5].lt,"Right Brainstem");
    sprintf(big[6].lt,"Inter-Hemispheric");

    sprintf(little[0].lt,"L_Crbrum");
    sprintf(little[1].lt,"R_Crbrum");
    sprintf(little[2].lt,"L_Cbelm");
    sprintf(little[3].lt,"R_Cbelm");
    sprintf(little[4].lt,"L_BrStem");
    sprintf(little[5].lt,"R_BrStem");
    sprintf(little[6].lt,"InterHemisph");

    return 1;
}
int SetSecondLevel(struct LabelTxt *big, struct LabelTxt *little)
{


    sprintf(big[0].lt,"Anterior Lobe");
    sprintf(big[1].lt,"Frontal Lobe");
    sprintf(big[2].lt,"Frontal-Temporal Space");
    sprintf(big[3].lt,"Limbic Lobe");
    sprintf(big[4].lt,"Medulla");
    sprintf(big[5].lt,"Midbrain");
    sprintf(big[6].lt,"Occipital Lobe");
    sprintf(big[7].lt,"Parietal Lobe");
    sprintf(big[8].lt,"Pons");
    sprintf(big[9].lt,"Posterior Lobe");
    sprintf(big[10].lt,"Sub-lobar");
    sprintf(big[11].lt,"Temporal Lobe");

    sprintf(little[0].lt,"AntLobe");
    sprintf(little[1].lt,"FrntLobe");
    sprintf(little[2].lt,"Frnt-Tmp-Space");
    sprintf(little[3].lt,"LmbicLobe");
    sprintf(little[4].lt,"Medulla");
    sprintf(little[5].lt,"Midbrain");
    sprintf(little[6].lt,"OccLobe");
    sprintf(little[7].lt,"PrtalLobe");
    sprintf(little[8].lt,"Pons");
    sprintf(little[9].lt,"PostLobe");
    sprintf(little[10].lt,"SubLobar");
    sprintf(little[11].lt,"TempLobe");


    return 1;
}
int SetThirdLevel(struct LabelTxt *big, struct LabelTxt *little)
{

    sprintf(big[0].lt,"Angular Gyrus");
    sprintf(big[1].lt,"Anterior Cingulate");
    sprintf(big[2].lt,"Caudate");
    sprintf(big[3].lt,"Cerebellar Lingual");
    sprintf(big[4].lt,"Cerebellar Tonsil");
    sprintf(big[5].lt,"Cingulate Gyrus");
    sprintf(big[6].lt,"Claustrum");
    sprintf(big[7].lt,"Culmen");
    sprintf(big[8].lt,"Culmen of Vermis");
    sprintf(big[9].lt,"Cuneus");
    sprintf(big[10].lt,"Declive");
    sprintf(big[11].lt,"Declive of Vermis");
    sprintf(big[12].lt,"Extra-Nuclear");
    sprintf(big[13].lt,"Fastigium");
    sprintf(big[14].lt,"Fourth Ventricle");
    sprintf(big[15].lt,"Fusiform Gyrus");
    sprintf(big[16].lt,"Inferior Frontal Gyrus");
    sprintf(big[17].lt,"Inferior Occipital Gyrus");
    sprintf(big[18].lt,"Inferior Parietal Lobule");
    sprintf(big[19].lt,"Inferior Semi-Lunar Lobule");
    sprintf(big[20].lt,"Inferior Temporal Gyrus");
    sprintf(big[21].lt,"Insula");
    sprintf(big[22].lt,"Lateral Ventricle");
    sprintf(big[23].lt,"Lentiform Nucleus");
    sprintf(big[24].lt,"Lingual Gyrus");
    sprintf(big[25].lt,"Medial Frontal Gyrus");
    sprintf(big[26].lt,"Middle Frontal Gyrus");
    sprintf(big[27].lt,"Middle Occipital Gyrus");
    sprintf(big[28].lt,"Middle Temporal Gyrus");
    sprintf(big[29].lt,"Nodule");
    sprintf(big[30].lt,"Orbital Gyrus");
    sprintf(big[31].lt,"Paracentral Lobule");
    sprintf(big[32].lt,"Parahippocampal Gyrus");
    sprintf(big[33].lt,"Postcentral Gyrus");
    sprintf(big[34].lt,"Posterior Cingulate");
    sprintf(big[35].lt,"Precentral Gyrus");
    sprintf(big[36].lt,"Precuneus");
    sprintf(big[37].lt,"Pyramis");
    sprintf(big[38].lt,"Pyramis of Vermis");
    sprintf(big[39].lt,"Rectal Gyrus");
    sprintf(big[40].lt,"Subcallosal Gyrus");
    sprintf(big[41].lt,"Sub-Gyral");
    sprintf(big[42].lt,"Superior Frontal Gyrus");
    sprintf(big[43].lt,"Superior Occipital Gyrus");
    sprintf(big[44].lt,"Superior Parietal Lobule");
    sprintf(big[45].lt,"Superior Temporal Gyrus");
    sprintf(big[46].lt,"Supramarginal Gyrus");
    sprintf(big[47].lt,"Thalamus");
    sprintf(big[48].lt,"Third Ventricle");
    sprintf(big[49].lt,"Transverse Temporal Gyrus");
    sprintf(big[50].lt,"Tuber");
    sprintf(big[51].lt,"Tuber of Vermis");
    sprintf(big[52].lt,"Uncus");
    sprintf(big[53].lt,"Uvula");
    sprintf(big[54].lt,"Uvula of Vermis");

    sprintf(little[0].lt,"AngGyr");
    sprintf(little[1].lt,"AntCinglt");
    sprintf(little[2].lt,"Cdate");
    sprintf(little[3].lt,"CrblrLingual");
    sprintf(little[4].lt,"CrblrTonsil");
    sprintf(little[5].lt,"CngltGyr");
    sprintf(little[6].lt,"Clstrm");
    sprintf(little[7].lt,"Culmen");
    sprintf(little[8].lt,"CulmenVerms");
    sprintf(little[9].lt,"Cuneus");
    sprintf(little[10].lt,"Declive");
    sprintf(little[11].lt,"DecliveVerms");
    sprintf(little[12].lt,"ExtrNuc");
    sprintf(little[13].lt,"Fastigium");
    sprintf(little[14].lt,"4thVnt");
    sprintf(little[15].lt,"FusifrmGyr");
    sprintf(little[16].lt,"InfFrntlGyr");
    sprintf(little[17].lt,"InfOccipGyr");
    sprintf(little[18].lt,"InfPrtlLobe");
    sprintf(little[19].lt,"InfSemiLunarLobe");
    sprintf(little[20].lt,"InfTempGyr");
    sprintf(little[21].lt,"Insula");
    sprintf(little[22].lt,"LatVent");
    sprintf(little[23].lt,"LentNucl");
    sprintf(little[24].lt,"LingGyr");
    sprintf(little[25].lt,"MedlFrontGyr");
    sprintf(little[26].lt,"MidFrontGyr");
    sprintf(little[27].lt,"MidOccipGyr");
    sprintf(little[28].lt,"MidTempGyr");
    sprintf(little[29].lt,"Nodule");
    sprintf(little[30].lt,"OrbGyr");
    sprintf(little[31].lt,"ParacenLobul");
    sprintf(little[32].lt,"ParahipGyr");
    sprintf(little[33].lt,"PostcntrlGyr");
    sprintf(little[34].lt,"PostCing");
    sprintf(little[35].lt,"PrecntrlGyr");
    sprintf(little[36].lt,"Precun");
    sprintf(little[37].lt,"Pyramis");
    sprintf(little[38].lt,"PyramisVerm");
    sprintf(little[39].lt,"RectGyr");
    sprintf(little[40].lt,"SubcallosGyr");
    sprintf(little[41].lt,"SubGyral");
    sprintf(little[42].lt,"SupFrontGyr");
    sprintf(little[43].lt,"SupOccipGyr");
    sprintf(little[44].lt,"SupParietLobule");
    sprintf(little[45].lt,"SupTempGyr");
    sprintf(little[46].lt,"SupramarGyr");
    sprintf(little[47].lt,"Thal");
    sprintf(little[48].lt,"3rdVent");
    sprintf(little[49].lt,"TransvTempGyr");
    sprintf(little[50].lt,"Tuber");
    sprintf(little[51].lt,"TuberVerm");
    sprintf(little[52].lt,"Uncus");
    sprintf(little[53].lt,"Uvula");
    sprintf(little[54].lt,"UvulaVerm");

    return 1;
}
int SetFourthLevel(struct LabelTxt *big, struct LabelTxt *little)
{
    sprintf(big[0].lt,"Cerebro-Spinal Fluid");
    sprintf(big[1].lt,"Gray Matter");
    sprintf(big[2].lt,"White Matter");

    sprintf(little[0].lt,"CSF");
    sprintf(little[1].lt,"GM");
    sprintf(little[2].lt,"WM");

    return 1;
}
int SetFifthLevel(struct LabelTxt *big, struct LabelTxt *little)
{

    sprintf(big[0].lt,"Amygdala");
    sprintf(big[1].lt,"Anterior Commissure");
    sprintf(big[2].lt,"Anterior Nucleus");
    sprintf(big[3].lt,"Brodmann area");
    sprintf(big[4].lt,"Caudate Body");
    sprintf(big[5].lt,"Caudate Head");
    sprintf(big[6].lt,"Caudate Tail");
    sprintf(big[7].lt,"Corpus Callosum");
    sprintf(big[8].lt,"Dentate");
    sprintf(big[9].lt,"Hippocampus");
    sprintf(big[10].lt,"Hypothalamus");
    sprintf(big[11].lt,"Lateral Dorsal Nucleus");
    sprintf(big[12].lt,"Lateral Geniculum Body");
    sprintf(big[13].lt,"Lateral Globus Pallidus");
    sprintf(big[14].lt,"Lateral Posterior Nucleus");
    sprintf(big[15].lt,"Mammillary Body");
    sprintf(big[16].lt,"Medial Dorsal Nucleus");
    sprintf(big[17].lt,"Medial Geniculum Body");
    sprintf(big[18].lt,"Medial Globus Pallidus");
    sprintf(big[19].lt,"Midline Nucleus");
    sprintf(big[20].lt,"Optic Tract");
    sprintf(big[21].lt,"Pulvinar");
    sprintf(big[22].lt,"Putamen");
    sprintf(big[23].lt,"Red Nucleus");
    sprintf(big[24].lt,"Substania Nigra");
    sprintf(big[25].lt,"Subthalamic Nucleus");
    sprintf(big[26].lt,"Ventral Anterior Nucleus");
    sprintf(big[27].lt,"Ventral Lateral Nucleus");
    sprintf(big[28].lt,"Ventral Posterior Lateral Nucleus");
    sprintf(big[29].lt,"Ventral Posterior Medial Nucleus");

    sprintf(little[0].lt,"Amygd");
    sprintf(little[1].lt,"AntCommis");
    sprintf(little[2].lt,"AntNucl");
    sprintf(little[3].lt,"BA");
    sprintf(little[4].lt,"CaudBody");
    sprintf(little[5].lt,"CaudHead");
    sprintf(little[6].lt,"CaudTail");
    sprintf(little[7].lt,"CorpCall");
    sprintf(little[8].lt,"Dentate");
    sprintf(little[9].lt,"Hippocamp");
    sprintf(little[10].lt,"Hypothal");
    sprintf(little[11].lt,"LatDorsNucl");
    sprintf(little[12].lt,"LatGenicBody");
    sprintf(little[13].lt,"LatGlobPallidus");
    sprintf(little[14].lt,"LatPostNucl");
    sprintf(little[15].lt,"MammBody");
    sprintf(little[16].lt,"MedDorsNucl");
    sprintf(little[17].lt,"MedGenicuBody");
    sprintf(little[18].lt,"MedGlobPallidus");
    sprintf(little[19].lt,"MidlNucl");
    sprintf(little[20].lt,"OptTract");
    sprintf(little[21].lt,"Pulvinar");
    sprintf(little[22].lt,"Putamen");
    sprintf(little[23].lt,"RedNucl");
    sprintf(little[24].lt,"SubstNigra");
    sprintf(little[25].lt,"SubthalNucl");
    sprintf(little[26].lt,"VentAntNucl");
    sprintf(little[27].lt,"VentLatNucl");
    sprintf(little[28].lt,"VentPostLatNucl");
    sprintf(little[29].lt,"VentPostMedNucl");

    return 1;
}


//===============================================================================================
//===============================================================================================
//===============================================================================================
//create a Talairach image of only GM
//merge the labels
//===============================================================================================
//===============================================================================================
//===============================================================================================
int CreateMergedTalairachImage(HWND hwnd, char ExecDir[])
{
    char fname[MAX_PATH];
    struct Image TalGM, TalGMmerged;
    int Nlabels;
    int voxel, voxels;
    int *newlabel=NULL;
    int label,a,b;
    FILE *fp;

    memset(&TalGM,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\TalGM.nii", ExecDir);
    if (!LoadFromFileName(hwnd, fname, &TalGM, 0)) goto END;
    voxels = TalGM.X*TalGM.Y*TalGM.Z;


    sprintf(fname,"%s\\Talairach\\merge.txt", ExecDir);

    if ( (fp=fopen(fname,"r")) )
    {
        fscanf(fp,"%d",&Nlabels);

        if (!(newlabel = (int *)malloc(sizeof(int)*(Nlabels+1)))) goto END;
        memset(newlabel,0,sizeof(int)*(Nlabels+1));

        for (label=0; label<=Nlabels; label++)
        {
            fscanf(fp,"%d %d",&a,&b);
            newlabel[label] = b;
        }
        fclose (fp);
    }


    memset(&TalGMmerged,0,sizeof(struct Image));
    MakeCopyOfImage(&TalGM,&TalGMmerged);
    for (voxel=0; voxel<voxels; voxel++)
    {
        TalGMmerged.img[voxel] = (float)newlabel[(int)TalGM.img[voxel]];
    }
    sprintf(TalGMmerged.filename,"%s\\Talairach\\TalGMmerged.nii",ExecDir);
    Save(&TalGMmerged);


END:
    if (newlabel) free(newlabel);
    ReleaseImage(&TalGM);
    ReleaseImage(&TalGMmerged);

    return 1;

}
//===============================================================================================
//===============================================================================================
//===============================================================================================
//convert the Talairach image to an image of the size of the structures
//===============================================================================================
//===============================================================================================
//===============================================================================================
int ConvertTalairachToSize(HWND hwnd, struct Image *image, char ExecDir[])
{
    char fname[MAX_PATH];
    struct Image TalGM;
    char *labels=NULL;
    int *H=NULL;
    int Nlabels,N;
    int voxel, voxels;

    memset(&TalGM,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\TalGM.nii", ExecDir);
    if (!LoadFromFileName(hwnd, fname, &TalGM, 0)) goto END;
    voxels = TalGM.X*TalGM.Y*TalGM.Z;

    if (!(labels = LoadTalairachLabels(&N))) goto END;
    Nlabels = BiggestTalairachLabel(labels, N);

    if (!(H = (int *)malloc(sizeof(int)*(Nlabels+1)))) goto END;
    memset(H,0,sizeof(int)*(Nlabels+1));

    //GET THE HISTOGRAM OF THE GM STRUCTURES
    for (voxel=0; voxel<voxels; voxel++) H[(int)TalGM.img[voxel]]++;
    H[0] = 0;

    ReleaseImage(image);
    MakeCopyOfImage(&TalGM, image);

    for (voxel=0; voxel<voxels; voxel++)
    {
        (*image).img[voxel] = (float)H[(int)TalGM.img[voxel]];
    }

END:
    ReleaseImage(&TalGM);
    if (labels) free(labels);
    if (H) free(H);
    return 1;
}
//================================================================================================
//================================================================================================
//================================================================================================
//GET AN IMAGE OF NEAREST GM SRUCTURES
//LOAD THE TALAIRACH AND THE LABELS, COMPUTE THE NEAREST GM IMAGE, AND SAVE
//================================================================================================
//================================================================================================
//================================================================================================
int MakeNearestGMimage(HWND hwnd)
{
    struct Image Tal;
    struct Image NearGM;
    struct Image Mask;
    char *labels=NULL;
    char fname[MAX_PATH];
    int counter;
    int Nl;
    int voxel,voxels;
    int x0,y0,z0;
    char txt[256];
    HDC hDC=GetDC(hwnd);

    memset(&Tal,0,sizeof(struct Image));
    memset(&NearGM,0,sizeof(struct Image));
    memset(&Mask,0,sizeof(struct Image));

//LOAD THE TALAIRACH DATA
    sprintf(fname,"%s\\Talairach\\TalGMmerged.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &Tal, 0)) goto END;

    sprintf(fname,"%s\\Talairach\\NearGM.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &NearGM, 0))
    {
        MakeCopyOfImage(&Tal,&NearGM);
        sprintf(NearGM.filename,"%s\\Talairach\\NearGM.nii", ExecutableDirectory);
        Save(&NearGM);
    }

    sprintf(fname,"%s\\Talairach\\TalMask.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &Mask,0)) goto END;


    labels=LoadTalairachLabels(&Nl);
    if (Nl<=0) goto END;
    BiggestTalairachLabel(labels, Nl);


    voxels = Tal.X * Tal.Y * Tal.Z;


    counter=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((NearGM.img[voxel]==0.0) && (Mask.img[voxel]>0.0))
        {
            XYZfromVoxelNumber(voxel,&x0, &y0, &z0, Tal.X, Tal.Y, Tal.Z);
            NearGM.img[voxel]=(float)NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, x0, y0, z0);
            counter++;
        }
        if (EscapePressed(hwnd))
        {
            Save(&NearGM);
            goto END;
        }
        if (counter>=1000)
        {
            counter=0;
            sprintf(txt,"%d %d",voxel,voxels);
            TextOut(hDC,100,100,txt,strlen(txt));
            RemoveInput(hwnd);
            Save(&NearGM);
        }

    }


    Save(&NearGM);


END:
    ReleaseImage(&Tal);
    ReleaseImage(&NearGM);
    ReleaseImage(&Mask);
    if (labels) free(labels);

    ReleaseDC(hwnd,hDC);

    return 1;
}

//================================================================================
//================================================================================
//================================================================================
//MAKE GM HISTOGRAM
//SAVE IT TO DISK
//ONE TIME ONLY USE TO GENERATE HISTOGRAM
//================================================================================
//================================================================================
//================================================================================
int CreateTalGMhistogram(HWND hwnd, char ExecDir[])
{
    char fname[MAX_PATH];
    struct Image TalNearGM;
    FILE *fp;
    int *H=NULL;
    int voxel,voxels;
    int max;
    int i, N;
    char *labels, *b;

    memset(&TalNearGM,0,sizeof(struct Image));

    if (!(labels=LoadTalairachLabels(&N))) goto END;

    sprintf(fname,"%s\\Talairach\\NearGM.nii", ExecDir);
    if (!LoadFromFileName(hwnd, fname, &TalNearGM, 0)) goto END;

    voxels = TalNearGM.X*TalNearGM.Y*TalNearGM.Z;

    max=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (TalNearGM.img[voxel]>max) max = (int)TalNearGM.img[voxel];
    }

    if (!(H = (int *)malloc(sizeof(int)*(max+1)))) goto END;
    memset(H,0,sizeof(int)*(max+1));
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (TalNearGM.img[voxel]>0.0) H[(int)TalNearGM.img[voxel]]++;
    }

    //sprintf(fname,"%s\\Talairach\\TalGMhist.txt", ExecDir);
    sprintf(fname,"c:\\temp\\TalGMhist.csv");
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"%d\n",max);
        for (i=0; i<=max; i++)
        {
            b=FindEntryInTalairachLabels(labels, N, i);
            fprintf(fp,"%d, %d, %s\n",i,H[i], &b[1]);
        }
        fclose(fp);
    }


END:
    ReleaseImage(&TalNearGM);
    if (H) free(H);
    if (labels) free(labels);

    return 1;

}

