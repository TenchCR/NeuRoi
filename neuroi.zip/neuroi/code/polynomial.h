/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(Polynomial_H)
//Do Nothing
#else


#define Polynomial_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>


int PolynomialRegressors2D(double e1, double e2, double r[], int N);
int PolynomialRegressors2DEx(double e1, double e2, double r[], int order[], int N);
int PolynomialRegressors3D(double e1, double e2, double e3, double r[], int N);
int PolynomialRegressors3DEx(double e1, double e2, double e3, double r[], int order[], int N);
int PolynomialRegressors3DTermOrderSorted(double e1, double e2, double e3, double r[], int order_of_term[], int N);
int GradPolynomialRegressors3D(double e1, double e2, double e3, double r[], int N, int terms);
float CorrectPolynomialGain(float *image, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                    float fovx, float fovy, float fovz, double param[], int order, int polyterms);
float RomoveOutliersFromPolynomialFit(float *image, int X, int Y, int Z, float dx, float dy, float dz,
                                      double param[], int order, int polyterms);
int FitClassPolynomialFlatConstrained(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
                             float x0, float y0, float z0, float fovx, float fovy, float fovz,
                             double param[], int order, int terms, int classes);
int FitClassPolynomialFlatConstrainedBayes(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
                             float x0, float y0, float z0, float fovx, float fovy, float fovz,
                             double param[], int order, int terms, int classes);
int FitClassPolynomialBayes(float *image, unsigned char probs[], float dx, float dy, float dz, int X, int Y, int Z,
                             float x0, float y0, float z0, float fovx, float fovy, float fovz,
                             double param[], int order, int terms, int classes);
int FitPolynomialConstrainedBayes(float image[], float dx, float dy, float dz, int X, int Y, int Z,
                                  int order, int terms, double param[]);

int TermsInNthorderDdimensionPolynomial(int N, int D);
int TestTermsInNthorderDdimensionPolynomial(int N, int D);
int TestPolynomialRegressors3DEx(int N);
#endif




