/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"

int RenumberClusters2(short int cluster[], int TotalFoci, float xc[], float yc[], float zc[], int MinExperiments);
int GetValidClusters(struct Image *img, float x[], float y[], float z[], int voxel[],short int cluster[],short int experiment[], char voi[], int Nfoci, int Nexperiments,
                     float xc[], float yc[], float zc[], int MinStudiesExternal, double kernelSD, int save, char directory[], int ClusteredOnly, int closest);
double ExperimentDensityEstimate2(float x[], float y[], float z[], short int cluster[], short int experiment[], char voi[], int Nfoci, int Nexperiments,
                                  float xc, float yc, float zc, double kernelSD, int ClusteredOnly);;
