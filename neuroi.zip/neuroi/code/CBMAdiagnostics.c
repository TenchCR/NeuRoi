/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "display.h"
#include "imageprocess.h"
#include "CoordinateProcess.h"
#include "ClusterZ.h"



//======================================================================================================
//PRODUCE DIAGNOSTIC COMPATABILITY VALUE FOR EACH EXPERIMENT AND SAVE TO DISK
//FOR LocalALE
//======================================================================================================
int ComputeDiagnosticBySpatialRandomisation(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float sigma, double critical, char directory[])
{
    struct Coordinates ALEcopy;
    int iter, iterations=500;
    int foci, iexp;
    int result = 0;
    int start,stop;
    float dc = 1.0/iterations;
    float *ALEvalues=NULL;
    float *comp=NULL;//the compatibility we are trying to measure
    float *ObsSum = NULL, sum;
    char fname[MAX_PATH],txt[256];
    FILE *fp;
    HDC hDC=GetDC(hwnd);


    if (!(comp = (float *)calloc((*ale).Nexperiments,sizeof(float)))) goto END;
    if (!(ObsSum = (float *)calloc((*ale).Nexperiments,sizeof(float)))) goto END;
    if (!(ALEvalues = (float *)malloc(sizeof(float)*(*ale).TotalFoci))) goto END;

    ComputeALEatFoci(ale, dx, dy, dz, ALEvalues, sigma, 0, (*ale).TotalFoci-1);
    for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
    {
        //the summed ALE values for the observed foci
        ObsSum[iexp] = 0.0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ((*ale).experiment[foci] == iexp) ObsSum[iexp] += ALEvalues[foci];
        }
    }



    memset(&ALEcopy,0,sizeof(struct Coordinates));

    for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
    {
        CopyCoordinates(ale, &ALEcopy);

        start=(*ale).TotalFoci;
        for (foci=0; foci<(*ale).TotalFoci; foci++) if ((*ale).experiment[foci]==iexp && (foci<start)) start=foci;
        stop=0;
        for (foci=0; foci<(*ale).TotalFoci; foci++) if ((*ale).experiment[foci]==iexp && (foci>=stop)) stop=foci;

        //ALE values for randomised experiments
        for (iter=1; iter<=iterations; iter++)
        {
            RandomiseFociInexperiment(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &ALEcopy, iexp);
            ComputeALEatFoci(&ALEcopy, dx, dy, dz, ALEvalues, sigma, start, stop);


            sum=0.0;
            for (foci=0; foci<(*ale).TotalFoci; foci++)
            {
                if ((*ale).experiment[foci] == iexp) sum += ALEvalues[foci];
            }

            if (ObsSum[iexp]>sum) comp[iexp] += dc;
        }

        RemoveInput(hwnd);
        sprintf(txt,"experiment %d of %d : %f     ",iexp+1, (*ale).Nexperiments, comp[iexp]);
        TextOut(hDC,100,100,txt,strlen(txt));
        UpdateWindow(hwnd);
    }


    sprintf(fname,"%s\\ExperimentCompatibility.csv",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
        {
            fprintf(fp,"%s, %f\n",(*ale).ID[iexp].txt, comp[iexp]);
        }
        fclose(fp);
    }

    result = 1;
END:
    if (ALEvalues) free(ALEvalues);
    if (comp) free(comp);
    if (ObsSum) free(ObsSum);
    FreeCoordinates(&ALEcopy);
    ReleaseDC(hwnd,hDC);

    return result;
}




//======================================================================================================
//PRODUCE DIAGNOSTIC COMPATABILITY VALUE FOR EACH CBRES EXPERIMENT AND SAVE TO DISK
//FOR ClusterZ
//======================================================================================================
int ComputeCBRESdiagnosticBySpatialRandomisation(HWND hwnd, struct Coordinates *Co, float *mask, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float ClusteringDistance, char directory[])
{
    struct Coordinates CoCopy;
    int iter, iterations=500;
    int foci, iexp;
    int result = 0;
    int start,stop;
    int Nfoci=(*Co).TotalFoci;
    float dc = 1.0/iterations;
    float *OverlapValues=NULL;
    float *comp=NULL;//the compatibility we are trying to measure
    float *ObsSum = NULL, sum;
    char fname[MAX_PATH],txt[256];
    double *DM=NULL;
    FILE *fp;
    HDC hDC=GetDC(hwnd);


    if (!(comp = (float *)calloc((*Co).Nexperiments,sizeof(float)))) goto END;
    if (!(ObsSum = (float *)calloc((*Co).Nexperiments,sizeof(float)))) goto END;
    if (!(OverlapValues = (float *)malloc(sizeof(float)*(*Co).TotalFoci))) goto END;
    if (!(DM=(double *)malloc(Nfoci*Nfoci*sizeof(double)))) goto END;

    Distance2Matrix((*Co).x, (*Co).y, (*Co).z, (*Co).experiment, (*Co).TotalFoci, DM);
    CoordinateOverlaps(Co, DM, OverlapValues, ClusteringDistance, 0);
    for (iexp=0; iexp<(*Co).Nexperiments; iexp++)
    {
        //the summed overlap values for the observed foci
        ObsSum[iexp] = 0.0;
        for (foci=0; foci<(*Co).TotalFoci; foci++)
        {
            if ((*Co).experiment[foci] == iexp) ObsSum[iexp] += OverlapValues[foci];
        }
    }



    memset(&CoCopy,0,sizeof(struct Coordinates));

    for (iexp=0; iexp<(*Co).Nexperiments; iexp++)
    {
        CopyCoordinates(Co, &CoCopy);

        start=(*Co).TotalFoci;
        for (foci=0; foci<(*Co).TotalFoci; foci++) if ((*Co).experiment[foci]==iexp && (foci<start)) start=foci;
        stop=0;
        for (foci=0; foci<(*Co).TotalFoci; foci++) if ((*Co).experiment[foci]==iexp && (foci>=stop)) stop=foci;

        //OVERLAP values for randomised experiments
        for (iter=1; iter<=iterations; iter++)
        {
            RandomiseFociInexperiment(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &CoCopy, iexp);
            Distance2Matrix(CoCopy.x, CoCopy.y, CoCopy.z, CoCopy.experiment, CoCopy.TotalFoci, DM);
            CoordinateOverlaps(&CoCopy, DM, OverlapValues, ClusteringDistance, 0);

            sum=0.0;
            for (foci=0; foci<(*Co).TotalFoci; foci++)
            {
                if ((*Co).experiment[foci] == iexp) sum += OverlapValues[foci];
            }

            if (ObsSum[iexp]>sum) comp[iexp] += dc;
        }

        RemoveInput(hwnd);
        sprintf(txt,"experiment %d of %d : %f     ",iexp+1, (*Co).Nexperiments, comp[iexp]);
        TextOut(hDC,100,100,txt,strlen(txt));
        UpdateWindow(hwnd);
    }


    sprintf(fname,"%s\\ExperimentCompatibilityZ.csv",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        for (iexp=0; iexp<(*Co).Nexperiments; iexp++)
        {
            fprintf(fp,"%s, %f\n",(*Co).ID[iexp].txt, comp[iexp]);
        }
        fclose(fp);
    }

    result = 1;
END:
    if (OverlapValues) free(OverlapValues);
    if (comp) free(comp);
    if (ObsSum) free(ObsSum);
    if (DM) free(DM);
    FreeCoordinates(&CoCopy);
    ReleaseDC(hwnd,hDC);

    return result;
}





//======================================================================================================
//save a bitmap of MIPs of ALE for each study
//======================================================================================================
int SaveALE_MIP(HWND hwnd, struct Coordinates *ale, struct Image *image, char directory[], float sigma)
{
    int pX,pY;
    int X, Y, Z;
    int x,y,voxels,voxel;
    int iexp;
    float *MA=NULL;
    float dx,dy,dz,x0,y0,z0;
    struct ImagePlanes planes, planes2;
    struct Image im;
    HDC hDC=GetDC(hwnd);
    char txt[256];


    sprintf(txt,"   Saving MIPS   ");
    TextOut(hDC,100,100,txt,strlen(txt));
    UpdateWindow(hwnd);


    memset(&planes,0,sizeof(struct ImagePlanes));
    memset(&planes2,0,sizeof(struct ImagePlanes));
    memset(&im,0,sizeof(struct Image));


    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    x0=(*image).x0;
    y0=(*image).y0;
    z0=(*image).z0;
    voxels=X*Y*Z;


    if (!(MA = (float *)malloc(voxels*sizeof(float)))) goto END;
    memcpy(MA,(*image).img, voxels*sizeof(float));
    MaxIntensityProjection(MA, X, Y, Z, &planes2);



    CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, ale, 0, MA, sigma, 0, 1.0);
    MaxIntensityProjection(MA, X, Y, Z, &planes);

    pX = (X>Y) ? X:Y;
    pY = (Y>Z) ? Y:Z;

    if (!MakeImage(&im, 2*pX, 2*pY, (*ale).Nexperiments, 1, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, DT_FLOAT, NIFTI, "bitmap of ALE")) goto END;


    for (voxel=0; voxel< 2*pX*2*pY*(*ale).Nexperiments; voxel++)
    {
        im.img[voxel]=0.001;
    }


    for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
    {

        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, ale, iexp, MA, sigma, 0, 1.0);
        MaxIntensityProjection(MA, X, Y, Z, &planes);

        for (x=0; x<pX; x++)
        {
            for (y=0; y<pY; y++)
            {
                if ((x<X) && (y<Y)) im.img[x + y*2*pY + iexp*2*pX*2*pY] = planes.plane1[x+y*X];
                if ((x<X) && (y<Y) && (planes2.plane1[x+y*X]<=0.0) && (im.img[x + y*2*pY + iexp*2*pX*2*pY]<=0.0)) im.img[x + y*2*pY + iexp*2*pX*2*pY] = 0.001;

                if ((x<X) && (y<Z)) im.img[pX + x + y*2*pY + iexp*2*pX*2*pY] = planes.plane2[x+y*X];
                if ((x<X) && (y<Z) && (planes2.plane2[x+y*X]<=0.0) && (im.img[pX + x + y*2*pY + iexp*2*pX*2*pY]<=0.0)) im.img[pX + x + y*2*pY + iexp*2*pX*2*pY] = 0.001;

                if ((x<Y) && (y<Z)) im.img[2*pX*pY + x + y*2*pY + iexp*2*pX*2*pY] = planes.plane3[x+y*Y];
                if ((x<Y) && (y<Z) && (planes2.plane3[x+y*Y]<=0.0) && (im.img[2*pX*pY + x + y*2*pY + iexp*2*pX*2*pY]<=0.0)) im.img[2*pX*pY + x + y*2*pY + iexp*2*pX*2*pY] = 0.001;
            }
        }
    }



    im.MaxIntensity=1.0;

    sprintf(im.filename,"%s\\maMIPS.nii",directory);
    Save(&im);


    sprintf(txt,"        Finished Saving MIPS        ");
    TextOut(hDC,100,100,txt,strlen(txt));
    UpdateWindow(hwnd);


END:
    if (MA) free(MA);
    if (planes.plane1) free(planes.plane1);
    if (planes.plane2) free(planes.plane2);
    if (planes.plane3) free(planes.plane3);
    if (planes2.plane1) free(planes2.plane1);
    if (planes2.plane2) free(planes2.plane2);
    if (planes2.plane3) free(planes2.plane3);


    ReleaseImage(&im);
    ReleaseDC(hwnd,hDC);

    return 0;
}

//======================================================================================================
//CHECK FOR COINCIDENCE OF COORDINATES
//THIS IS IMPORTANT FOR PREVENTING DUPLICATE DATA
//======================================================================================================
int CheckForCoordinateDuplication(struct Coordinates *Co, char ext[], char directory[])
{
    int Nstudies=(*Co).Nexperiments;
    int Ncoord=(*Co).TotalFoci;
    int s1,s2;
    int c1,c2;
    int coincidences;
    FILE *fp=NULL;
    char fname[MAX_PATH];
    int result=0;

    if (!Nstudies) goto END;
    if (!Ncoord) goto END;

    sprintf(fname,"%s\\DuplicationCheck%s.csv",directory,ext);
    if (!(fp=fopen(fname,"w"))) goto END;

    for (s1=0; s1<Nstudies; s1++)
    {
        for (s2=s1+1; s2<Nstudies; s2++)
        {
            coincidences=0;
            for (c1=0; c1<Ncoord; c1++)
            {
                if ( ((*Co).experiment[c1]==s1) )
                {
                    for (c2=0; c2<Ncoord; c2++)
                    {
                        if ( ((*Co).experiment[c2]==s2) )
                        {
                            if ( (*Co).voxel[c1] == (*Co).voxel[c2] ) coincidences++;
                        }
                    }
                }
            }

            fprintf(fp,"%s,%s,%d\n",(*Co).ID[s1].txt, (*Co).ID[s2].txt,coincidences);
        }
    }

    result=1;
END:

    if (fp) fclose(fp);

    return result;
}
