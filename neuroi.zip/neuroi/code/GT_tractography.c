/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "GT_tractography.h"
#include "ROIs.h"
#include "display.h"
#include "tensor.h"
#include "numerical.h"
#include "graphtheoryalgorithms.h"
#include "menuresources.h"
#include "options.h"
#include "imageprocess.h"
#include "stats.h"
#include "mostprobpathtract.h"

#define NULL_SAMPLES 1000//the number of NULL samples used to do the statistics

#define LOOKUP_VOLS 49	//The affinity lookup table volumes

#define COS_ANGLE 0.5


#define GM_WEIGHT 0.0//COULD BE ADJUSTED TO ALLOW TRACTOGRAPHY INTO THE GREY MATTER 0.0<=GM_WEIGHT<=1

//#define TESTING_GT

float TensorAffinity(struct Image *tensor, int voxel, float affinity[]);

int GetFODFAffinityLookUp(struct Image *fODF, unsigned char *LookUp, float *WMprob);
int GetWMprob(HWND hwnd, char filename[], float *WMprob, int X, int Y, int Zpv, float GMweight);
int GTconnectivities(HWND hwnd, struct Image *connectivities, float *WMprob, unsigned char *ODFlookUp, int ConvertToProb);
float NullStrengthSample(float Connectivities[], int Length, int voxel, double LengthCorrect);
int CorrectConnectionStrengthGaps(float C[], int X, int Y, int Z, char *prev, float WMprob[]);
int GetTractProbabilities(char *prev, float *connectivities, float *prob,  int X, int Y, int Z, double minconnectivity);
//==============================================================================
//              Given the tensor or fODF do GT based tractography
//==============================================================================
int GTtractography(HWND hwnd, struct Image *image, int mode)
{

    unsigned char *ODFlookUp=NULL;         //this contains the integrals over the ODF
    struct Image Connectivities;
    int objects;
    int X, Y, Zpv;
    int result=0;
    float dx, dy, dz;
    float *WMprob=NULL;
    HCURSOR hourglass=LoadCursor(NULL,IDC_WAIT);
    HCURSOR	PrevCursor;

    memset(&Connectivities,0,sizeof(struct Image));


    //INITIAL CHECKS
    if ((mode==TENSOR_MODE) && ((*image).volumes!=6))
    {
        MessageBox(hwnd, "Tensor image should have 6 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }
    else if ((mode==FODF_MODE) && ((*image).volumes!=(LOOKUP_VOLS+1)))
    {
        MessageBox(hwnd, "fODF image should have 50 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }



    //preliminary operations
    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;



    //WM probability mask
    if (!(WMprob=(float *)malloc(X*Y*Zpv*sizeof(float)))) goto END;
    if (!GetWMprob(hwnd, (*image).filename, WMprob, X, Y, Zpv, GM_WEIGHT)) goto END;





    PrevCursor=SetCursor(hourglass);


    //allocate memory for ODF lookup image
    if (!(ODFlookUp=(unsigned char *)calloc(X*Y*Zpv*LOOKUP_VOLS,1))) goto END;
    if (mode==TENSOR_MODE) GetTensorAffinityLookUp(image, ODFlookUp, WMprob);
    else if (mode==FODF_MODE) GetFODFAffinityLookUp(image, ODFlookUp, WMprob);
    else goto END;



    //Allocate memory for Connectivities image. It has the same number of volumes as there are ROI objects
    objects=(gNumberOfObjects>1) ? gNumberOfObjects:1;
    if (!MakeImage(&Connectivities, X, Y, Zpv, objects, dx, dy, dz, 0.0, 0.0, 0.0, 1.0, 0.0, DT_FLOAT, HDR, "Connectivities")) goto END;

    //DO THE TRACTOGRAPHY
    if (GTconnectivities(hwnd, &Connectivities, WMprob, ODFlookUp, 0))
    {

        ReleaseImage(image);
        MakeCopyOfImage(&Connectivities, image);

        (*image).MaxIntensity=1.0;
        (*image).scale=1.0;
        (*image).offset=0.0;
    }

    SetCursor(PrevCursor);

END:
    if (ODFlookUp) free(ODFlookUp);
    ReleaseImage(&Connectivities);
    if (WMprob) free(WMprob);

    return result;
}



//==============================================================================
//          Get Connectivities from ROI seeds
//          Need a mask to remove non white matter
//          Need the ODF integral looukup image
//          Need an image to put the connectivities in to
//          Runs each voxel in turn, then gets the max for the overall connectivity
//==============================================================================
int GTconnectivities(HWND hwnd, struct Image *connectivities, float *WMprob, unsigned char *ODFlookUp, int ConvertToProb)
{

    int index;
    int object;
    int Nseeds;
    int *SeedVoxels=NULL;
    int X, Y, Zpv;
    int voxel, voxels;
    int result=0;
    float *connectivity=NULL;
    float dx,dy,dz;
    char *prev=NULL;
    unsigned char *seeds=NULL;


    X=(*connectivities).X;
    Y=(*connectivities).Y;
    Zpv=(*connectivities).Z/(*connectivities).volumes;
    voxels=X*Y*Zpv;
    dx=(*connectivities).dx;
    dy=(*connectivities).dy;
    dz=(*connectivities).dz;

    //allocate memory
    if (!(seeds=(unsigned char *)malloc(voxels))) goto END;
    if (!(prev=(char *)malloc(voxels))) goto END;
    if (!(connectivity=(float *)malloc(voxels*sizeof(float)))) goto END;
    if (!(SeedVoxels=(int *)malloc(voxels*sizeof(int)))) goto END;

    memset((*connectivities).img,0,sizeof(float)*voxels*(*connectivities).volumes);

    //Get connectivities from ROIs
    for (object=1; object<=gNumberOfObjects; object++)
    {
        index=(object-1)*voxels;
        Nseeds=GetBinaryROImask(seeds, X, Y, Zpv, object, 0);

        //do all seeds simultaneously
        Nseeds=0;
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (seeds[voxel] && WMprob[voxel])
            {
                SeedVoxels[Nseeds]=voxel;
                Nseeds++;
            }
        }
        if (Nseeds)
        {
            MaxLikelyhoodWithMemory(FibreProbability, WMprob, ODFlookUp, SeedVoxels, Nseeds, connectivity, prev,
                                    X, Y, Zpv, dx, dy, dz, COS_ANGLE, hwnd, 0.02);

            for (voxel=0; voxel<voxels; voxel++)
            {
                (*connectivities).img[index+voxel]=connectivity[voxel];
                if (seeds[voxel]) prev[voxel]=-1;//make sure prev is not valid at the seed
            }

            CorrectConnectionStrengthGaps(&(*connectivities).img[index], X, Y, Zpv, prev, WMprob);
        }

        if (ConvertToProb)
        {
            GetTractProbabilities(prev,&(*connectivities).img[index], &(*connectivities).img[index],  X, Y, Zpv, 0.02);
        }
    }

    result=1;
END:

    if (seeds) free(seeds);
    if (prev) free(prev);
    if (connectivity) free(connectivity);
    if (SeedVoxels) free(SeedVoxels);

    return result;
}

//=====================================================================================================
//GET THE PROBABILITY FROM THE CONNECTIVITIES AND THE PREVIOUS IMAGES
//THE PROBABILITY IS THE RELATIVE CONNECTION STRENGTH GIVEN THE PATH LENGTH
#define MAX_TRACT_LENGTH 300
#define CONNECTIVITY_BINS 200
//=====================================================================================================
int TractLength(int voxel, char *prev, int *L, int X, int Y, int Z);
int GetTractProbabilities(char *prev, float *connectivities, float *prob,  int X, int Y, int Z, double minconnectivity)
{
	int result=0;
	int voxel, voxels=X*Y*Z;
	double *hist=NULL;
	int *L=NULL;
	int length;
	int index;
	float c;
	int cbin;
	double max;

	//memset(prob,0,sizeof(float)*voxels);
	if (!(hist=(double *)calloc(MAX_TRACT_LENGTH*CONNECTIVITY_BINS,sizeof(double))))
		goto END;
	if (!(L=(int *)calloc(voxels,sizeof(int))))
		goto END;

	///get the tract lengths; voxel-wise
	for (voxel=0; voxel<voxels; voxel++)
	{
		if ((c=connectivities[voxel])>=minconnectivity && (!L[voxel]))
		{
			TractLength(voxel, prev, L, X, Y, Z);
		}
	}

	///get the connectivity histograms by tract length
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (L[voxel])
		{
			length=L[voxel];
			if (length>=0 && length<MAX_TRACT_LENGTH)
			{
				cbin=c*(CONNECTIVITY_BINS-1);
				hist[length*CONNECTIVITY_BINS + cbin]+=1.0;
			}
		}
	}

	///convert to cumulative histograms
	for (length=0; length<MAX_TRACT_LENGTH; length++)
	{
		index=length*CONNECTIVITY_BINS;
		for (cbin=1; cbin<CONNECTIVITY_BINS; cbin++)
		{
			hist[index + cbin]+=hist[index + cbin-1];
		}
		if ((max=hist[index + CONNECTIVITY_BINS-1])>0.0)
		{
			for (cbin=0; cbin<CONNECTIVITY_BINS; cbin++)
			{
				hist[index + cbin]/=max;
			}
		}
	}

	///save probabilities to *prob
    for (voxel=0; voxel<voxels; voxel++)
	{
		if ((c=connectivities[voxel])>=minconnectivity)
		{
			length = L[voxel];
			cbin=c*(CONNECTIVITY_BINS-1);

			if (length>=0 && length<MAX_TRACT_LENGTH) prob[voxel] = hist[length*CONNECTIVITY_BINS + cbin];
		}
	}


	result=1;
END:
	if (hist)
		free(hist);
	if (L)
		free(L);

	return result;
}
//=================================================================================================
int TractLength(int voxel, char *prev, int *L, int X, int Y, int Z)
{
	int path[MAX_TRACT_LENGTH];
	int i,j,k;
	int N=0;
	int StartLen;

	if (L[voxel])	return L[voxel];

	do
	{
        i=j=k=0;
        if (voxel>=0 && voxel<X*Y*Z)
        {
		path[N]=voxel;

		if (prev[voxel]>=0 && prev[voxel]<125) DirectionFromIndex555((int)prev[voxel], &i, &j, &k);
        else i=j=k=0;

        voxel += (i + j*X + k*X*Y);
        if (i||j||k) N++;


		if (voxel>=0 && voxel<X*Y*Z) StartLen=L[voxel];
        }
	}
	while ((N<MAX_TRACT_LENGTH) && (i||j||k) && (!StartLen));

	for (i=0; i<=N; i++)
	{
	if (path[i]>=0 && path[i]<X*Y*Z)L[path[i]]=N - i + StartLen;
	}

	return N;

}




//==============================================================================
//==============================================================================
//==============================================================================
//==============================================================================
//==============================================================================


int RandomWMseed(float *WMprob, int voxels);
float ConnectionMap(float WMprob[], float *ConnectionMap, float *Connectivities, char *prev, int X, int Y, int Zpv, float dx, float dy, float dz, int A, int B);
int ConnectingPaths(float Connectivities[], float paths[], char *prev, int X, int Y, int Z, unsigned char seeds[], double LengthCorrect);
int GetNullSamples(HWND hwnd, float Connectivities[], int X, int Y, int Z, float WMprob[], char prev[], double C[], double *LengthCorrection, int Nseeds);
int GetGT2ROIconnections(HWND hwnd, float *connectivities, char *prev, float *WMmask,
                         unsigned char *ODFlookUp, unsigned char seeds[], int object, float thresh,
                         int X, int Y, int Zpv, float dx, float dy, float dz);


//==============================================================================
//              Given the tensor/fODF do GT based tractography to connect 2 ROIs
//              Use the tensor ODF, or the FODF, depending on mode
//              Directions for integration of ODF are in ExecutableDirectory/directions
//==============================================================================
int GT_ConnectROIs(HWND hwnd, struct Image *image, int mode)
{

    unsigned char *ODFlookUp=NULL;
    unsigned char *seeds=NULL;
    struct Image Connectivities;
    int voxel, voxels;
    int X, Y, Zpv;
    int result=0;
    int Nseeds;
    int sample;
    float dx, dy, dz;
    float *WMprob=NULL;
    float thresh;
    float sum;
    double samples[NULL_SAMPLES];
    double LengthCorrection;
    char *prev=NULL;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;
    FILE *fp;


    if (gNumberOfObjects<2)
    {
        MessageBox(NULL,"Please define two object ROIs","",MB_OK);
        return 0;
    }

    hourglass=LoadCursor(NULL,IDC_WAIT);

    memset(&Connectivities,0,sizeof(struct Image));

    //INITIAL CHECKS
    if ((mode==TENSOR_MODE) && ((*image).volumes!=6))
    {
        MessageBox(hwnd, "Tensor image should have 6 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }
    else if ((mode==FODF_MODE) && ((*image).volumes!=(LOOKUP_VOLS+1)))
    {
        MessageBox(hwnd, "fODF image should have 50 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }



    //preliminary operations
    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;



    if (!(seeds=(unsigned char *)malloc(voxels))) goto END;
    if (!(WMprob=(float *)malloc(X*Y*Zpv*sizeof(float)))) goto END;
    if (!GetWMprob(hwnd, (*image).filename, WMprob, X, Y, Zpv, GM_WEIGHT)) goto END;

    PrevCursor=SetCursor(hourglass);

    //allocate memory for ODF lookup image
    if (!(ODFlookUp=(unsigned char *)calloc(X*Y*Zpv*LOOKUP_VOLS, 1))) goto END;
    if (mode==TENSOR_MODE)
    {
        thresh=0.01;
        GetTensorAffinityLookUp(image, ODFlookUp, WMprob);
    }
    else if (mode==FODF_MODE)
    {
        thresh=0.01;
        GetFODFAffinityLookUp(image, ODFlookUp, WMprob);
    }
    else goto END;



    if (!(prev=(char *)malloc(voxels*2))) goto END;

    //Allocate memory for Connectivities image. It has four volumes
    //one volume for each ROI, and two the path connecting the two ROIs
    if (!MakeImage(&Connectivities, X, Y, Zpv, 4, dx, dy, dz, 0.0, 0.0, 0.0, 1.0, 0.0, DT_FLOAT, HDR, "Connectivities")) goto END;



//now get the connectivities for each of the ROIs
    if (!(Nseeds=GetBinaryROImask(seeds, X, Y, Zpv, 1, 0))) goto END;
    if (!GetGT2ROIconnections(hwnd, &Connectivities.img[voxels], prev, WMprob, ODFlookUp, seeds, 0, thresh, X, Y, Zpv, dx, dy, dz)) goto END;

    if (!(Nseeds=GetBinaryROImask(seeds, X, Y, Zpv, 2, 0))) goto END;
    if (!GetGT2ROIconnections(hwnd, &Connectivities.img[voxels], prev, WMprob, ODFlookUp, seeds, 1, thresh, X, Y, Zpv, dx, dy, dz)) goto END;



//COMPUTE THE CONNECTIONS IMAGE; FIRST VOLUME OF Connectivities
    ConnectionMap(WMprob, Connectivities.img, &Connectivities.img[voxels], prev, X, Y, Zpv, dx, dy, dz, 0, 1);



//COMPUTE THE NULL DISTRIBUTION.
    GetNullSamples(hwnd, &Connectivities.img[voxels], X,Y,Zpv, WMprob, prev, samples, &LengthCorrection, Nseeds);



//COMPUTE THE DIRECT PATHS CONNECTING ROI1 TO ROI 2
    ConnectingPaths(&Connectivities.img[voxels], &Connectivities.img[3*voxels], prev, X, Y, Zpv, seeds, LengthCorrection);


//HERE CAN COMPARE THE CONNECTIVITY VALUES TO A NULL DISTRIBUTION
    //convert the connection strengths to probability of being connection
    fp=fopen("c:/temp/significance.txt","w");
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (Connectivities.img[voxel+3*voxels])
        {
            sum=0.0;
            for (sample=0; sample<NULL_SAMPLES; sample++)
            {
                if (Connectivities.img[voxel+3*voxels]>samples[sample]) sum+=1.0;
            }
            Connectivities.img[voxel+3*voxels]=sum/NULL_SAMPLES;

#if defined (TESTING_GT)
            if (fp) fprintf(fp,"%f\n",Connectivities.img[voxel+3*voxels]);
#endif

        }
    }
    if (fp) fclose(fp);


    //Now fill in the ROIs, which are zero in the Connectivity image because of the algorithm
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (WMprob[voxel])
        {
            if (((Connectivities.img[voxel+voxels]==1.0) || (Connectivities.img[voxel+2*voxels]==1.0)) &&
                    (!Connectivities.img[voxel]))
            {
                Connectivities.img[voxel]=1.0;
            }
        }
    }


    ReleaseImage(image);
    MakeCopyOfImage(&Connectivities, image);


    (*image).MaxIntensity=1.0;
    (*image).scale=1.0;
    (*image).offset=0.0;

    SetCursor(PrevCursor);

END:
    if (ODFlookUp) free(ODFlookUp);
    ReleaseImage(&Connectivities);
    if (prev) free(prev);
    if (WMprob) free(WMprob);
    if (seeds) free(seeds);

    return result;
}



//==============================================================================
//          Get Connectivities from ROI seeds
//          Need a mask to remove non white matter
//          Need the ODF integral looukup image
//          Need an image to put the connectivities in to
//          Runs each voxel in turn, then gets the max for the overall connectivity
//==============================================================================
int GetGT2ROIconnections(HWND hwnd, float *connectivities, char *prev, float *WMmask,
                         unsigned char *ODFlookUp, unsigned char seeds[], int object, float thresh,
                         int X, int Y, int Zpv, float dx, float dy, float dz)
{

    int result = 0;
    int Nseeds;
    int voxel, voxels;
    int *Seeds=NULL;
    char *pr=NULL;
    float *connectivity=NULL;

    voxels=X*Y*Zpv;

    //allocate mask memory
    if (!(connectivity=(float *)malloc(voxels*sizeof(float)))) goto END;
    if (!(pr=(char *)malloc(voxels))) goto END;
    if (!(Seeds=(int *)malloc(voxels*sizeof(float)))) goto END;


//all seeds done simultaneously
    Nseeds=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (seeds[voxel] && WMmask[voxel])
        {
            Seeds[Nseeds]=voxel;
            Nseeds++;
        }
    }
    MaxLikelyhoodWithMemory(FibreProbability, WMmask, ODFlookUp, Seeds, Nseeds, connectivity, pr, X, Y, Zpv, dx, dy, dz, COS_ANGLE,hwnd, thresh);
    for (voxel=0; voxel<voxels; voxel++)
    {
        connectivities[object*voxels+voxel]=connectivity[voxel];
        prev[object*voxels+voxel]=pr[voxel];
        if (seeds[voxel]) prev[object*voxels+voxel]=-1;//make sure prev is not valid at the seed
    }

    result=1;

END:
    if (connectivity) free(connectivity);
    if (pr) free(pr);
    if (Seeds) free(Seeds);

    return result;
}







//==============================================================================
//
//use the dot product between prev directions to get the connections map between ROIs
//The two volumes to find the connection map for are A and B
//==============================================================================
float ConnectionMap(float WMprob[], float *ConnectionMap, float *Connectivities, char *prev, int X, int Y, int Zpv, float dx, float dy, float dz, int A, int B)
{

    struct ThreeVector V1,V2;
    float max;
    float dp;
    int i,j,k;
    int voxel,voxels;


    voxels=X*Y*Zpv;


    max=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (WMprob[voxel])
        {
            DirectionFromIndex555((int)prev[voxel + A*voxels], &i, &j, &k);
            V1.x=dx*i;
            V1.y=dy*j;
            V1.z=dz*k;
            NormaliseThreeVector(&V1);
            DirectionFromIndex555((int)prev[voxel+B*voxels], &i, &j, &k);
            V2.x=dx*i;
            V2.y=dy*j;
            V2.z=dz*k;
            NormaliseThreeVector(&V2);
            dp=-DPThreeVector(&V1, &V2);
            if (dp<=0.0)
            {
                dp=0.0;
                ConnectionMap[voxel]=0.0;
            }
            else
            {
                ConnectionMap[voxel]=Connectivities[voxel+A*voxels]*Connectivities[voxel+B*voxels];
            }

            if (ConnectionMap[voxel]>max) max=ConnectionMap[voxel];
        }
    }

    return max;
}
//==============================================================================
//             Fix Connectivities when using the 98 neighbourhood
//             Voxels can be leap froged
//
//==============================================================================
int CorrectConnectionStrengthGaps(float C[], int X, int Y, int Z, char *prev, float WMprob[])
{

    int x,y,z;
    int i,j,k;
    int voxel,voxels;
    float *tmp=NULL;

    voxels=X*Y*Z;

    //correct the connections when the path leaps voxels
    if ((tmp=(float *)malloc(voxels*sizeof(float))))
    {
        memcpy(tmp,C,voxels*sizeof(float));
        for (voxel=0; voxel<voxels; voxel++)
        {
            XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);
            if (WMprob[voxel])
            {
                DirectionFromIndex555((int)prev[voxel], &i, &j, &k);
                if ((abs(i)==2) || (abs(j)==2) || (abs(k)==2))
                {
                    i/=2;
                    j/=2;
                    k/=2;
                    if (InImageRange(x+i, y+j, z+k, X, Y, Z))
                    {
                        if (tmp[voxel]>C[voxel+i+j*X+k*X*Y] && WMprob[voxel+i+j*X+k*X*Y])
                        {
                            C[voxel+i+j*X+k*X*Y]=tmp[voxel];
                        }
                    }
                }
            }
        }
        free(tmp);
    }
    else return 0;

    return 1;

}






//==============================================================================
//
//Use the Connectivities to compute the path strength to voxel
//Correct for length
//Correct for the maximum null sample strength if it was > 1.0
//==============================================================================
float NullStrengthSample(float Connectivities[], int Length, int voxel, double LengthCorrect)
{
    return (float)exp(-LengthCorrect*Length)*Connectivities[voxel];
}



//==============================================================================
//      Find the connecting paths and the strengths
//
//==============================================================================
int ConnectingPaths(float Connectivities[], float paths[], char *prev, int X, int Y, int Z, unsigned char seeds[], double LengthCorrect)
{

    int x,y,z;
    int i,j,k;
    int l,m,n;
    int seed;
    int voxel, voxel2, voxels;
    int Length;
    float maxconnectivity=0.0;
    double curvature;
    float Connectivity;
    float conn;
    FILE *fp;

    voxels=X*Y*Z;

    fp=fopen("c:/temp/connections.txt","w");

    memset(paths, 0, sizeof(float)*voxels);
    for (seed=0; seed<voxels; seed++)
    {
        if (seeds[seed])
        {
            PathsLengthAndCurvature(prev, X, Y, Z, seed, &Length, &curvature);
            Connectivity=NullStrengthSample(Connectivities, Length, seed, LengthCorrect);

#if defined (TESTING_GT)
            if (fp) fprintf(fp,"length=%f Lcorrection=%f (%f)\n ",(float)Length, LengthCorrect, LengthCorrect*Length);
#endif

            paths[seed]=Connectivity;
            if (Connectivity>maxconnectivity) maxconnectivity=Connectivity;


            //track backwards from the seed voxel to the start ROI
            voxel=seed;
            do
            {
                XYZfromVoxelNumber( voxel, &x, &y, &z, X, Y, Z );

                conn=0.0;
                if (InImageRange(x, y, z, X, Y, Z))
                {


                    DirectionFromIndex555((int)prev[voxel], &i, &j, &k);
                    if ((i||j||k) && InImageRange(x-i, y-j, z-k, X, Y, Z))
                    {

                        voxel=(x-i) + (y-j)*X + (z-k)*X*Y;
                        conn=Connectivities[voxel];

                        if (paths[voxel]<Connectivity)
                        {
                            paths[voxel]=Connectivity;
                        }

                        //fill in the blanks when jumping two voxels
                        if ( (abs(i)==2) || (abs(j)==2) || (abs(k)==2) )
                        {
                            l=(int)(i/2);
                            m=(int)(j/2);
                            n=(int)(k/2);
                            if ((l||m||n) && InImageRange(x-l, y-m, z-n, X, Y, Z))
                            {
                                voxel2=(x-l) + (y-m)*X + (z-n)*X*Y;
                                if (paths[voxel2]<Connectivity)
                                {
                                    paths[voxel2]=Connectivity;
                                }
                            }
                        }
                    }
                }
            }
            while(conn>0.0);
        }
    }
    if (fp) fclose(fp);


    return (int)100*maxconnectivity;
}




//==============================================================================
// Find a random white matter seed
//==============================================================================
int RandomWMseed(float *WMprob, int voxels)
{

    int voxel;
    double n=((double)voxels/(RAND_MAX+1));

    do
    {
        voxel=(int)(((double)rand() + (double)rand()/(RAND_MAX+1))*n);
    }
    while ((voxel>=voxels) || (WMprob[voxel]<0.5));

    return voxel;

}


//==============================================================================
//    Compute the NULL distribution from the Connectivities image; volume 0
//    Compute the cdf of the NULL distribution; cdf[] has N elements
//    Estimate a correction for length
//==============================================================================
int GetNullSamples(HWND hwnd, float Connectivities[], int X, int Y, int Z, float WMprob[], char prev[], double C[], double *LengthCorrection, int Nseeds)
{

    //FILE *fp;
    double distance[1331];
    static int offset[1331];
    static int sort[1331];
    static int initialized=0;
    int x,y,z;
    int i,j,k,index;
    int sample;
    int voxel,SeedVoxel, BestSeed;
    int steps;
    int voxels=X*Y*Z;
    double L[NULL_SAMPLES];
    double mu, beta;
    double curvature;
    float maxconnectivity;

    //find the distances to the nearest 1331 neighbours
    //then sort them, smallest first
    //only do this the first time as the results are stored in statics
    if (!initialized)
    {
        index=0;
        for (k=-5;k<=5;k++)
        {
            for (j=-5;j<=5;j++)
            {
                for (i=-5;i<=5;i++)
                {
                    distance[index]=(double)(i*i + j*j + k*k);
                    offset[index]=i + j*X + k*X*Y;
                    index++;
                }
            }
        }
        QuickSort(distance,sort,1331);
        initialized=1;
    }

    memset(L,0,sizeof(double)*NULL_SAMPLES);
    memset(C,0,sizeof(double)*NULL_SAMPLES);


//COLECT THE SAMPLES
    for (sample=0; sample<NULL_SAMPLES; sample++)
    {

        do
        {
            //get the seed
            do
            {
                SeedVoxel=RandomWMseed(WMprob, voxels);
            }
            while ((Connectivities[SeedVoxel]<0.0) || (Connectivities[SeedVoxel]>1.0));


            BestSeed=SeedVoxel;
            maxconnectivity=Connectivities[SeedVoxel];
            index=1;
            while ( (index<1331) && (index<Nseeds) )
            {
                voxel=SeedVoxel + offset[sort[index]];
                XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);
                if (InImageRange(x, y, z, X, Y, Z) && (WMprob[voxel]>0.0))
                {
                    if (Connectivities[voxel]>maxconnectivity){BestSeed=voxel; maxconnectivity=Connectivities[voxel];}
                }
                index++;
            }


            //use the log length so can fit exponential model
            if (maxconnectivity<=0.0) maxconnectivity=1.0e-6;
            C[sample] = log(maxconnectivity);
            PathsLengthAndCurvature(prev, X, Y, Z, BestSeed, &steps, &curvature);


        }
        while(!steps);

        L[sample] = (double)steps;           //LENGTH TERM

    }




    //Fit a straight line through the log data; do an exponential fit
    //This is used to correct the connectivities for length
    //model C(length)=exp(b*length)*C0

    StraightLineFit(L, C, NULL_SAMPLES, &mu, &beta);

    *LengthCorrection=beta;

#if defined (TESTING_GT)
    if ((fp=fopen("c:/temp/NullSamples.txt","w")))
    {
        for (sample=0; sample<NULL_SAMPLES; sample++)
        {
            fprintf(fp,"%f %f %f \n",L[sample], exp(C[sample]), exp(C[sample]- L[sample]*(*LengthCorrection)));
        }
        fclose(fp);
    }
#endif


    //compute the distribution from the valid samples
    //samples are corrected for length
    for (sample=0; sample<NULL_SAMPLES; sample++)
    {
        C[sample] = exp(C[sample] - L[sample]*(*LengthCorrection));//corrected for length
    }


    return 1;
}





//==============================================================================
//==============================================================================
//==============================================================================

//==============================================================================
//          Get the white matter probability
//          Load the class image and use that
//          If that doesnt exist, try to load the FA
//          filename[] is the filename, including path, of the tensor or fODF image
//          GMweight is used to make the WMprob image a combintaion of WM and GM probabiity
//                   0<=GMweight<=1
//==============================================================================
int GetWMprob(HWND hwnd, char filename[], float *WMprob, int X, int Y, int Zpv, float GMweight)
{

    struct Image ClassImage;
    struct Image fa;
    HDC hDC;
    char txt[256];
    char directory[MAX_PATH];
    char fname[MAX_PATH];
    char *c;
    int voxel, voxels=X*Y*Zpv;

    if (GMweight<0.0) GMweight=0.0;
    if (GMweight>1.0) GMweight=1.0;

    //get the directory path from the original image filename
    sprintf(directory,"%s",filename);
    c=directory;
    while (strstr(&c[1], "\\"))
    {
        c=strstr(&c[1],"\\");
    }
    *c='\0';
    //directory now only includes the path


    memset(&ClassImage,0,sizeof(struct Image));
    memset(&fa,0,sizeof(struct Image));


    sprintf(fname,"%s\\class.img",directory);
    //MessageBox(NULL,fname,"",MB_OK);
    if (LoadFromFileName(hwnd, fname, &ClassImage, 0))
    {
        hDC=GetDC(hwnd);
        sprintf(txt,"Loaded WM probabilities   ");
        TextOut(hDC,100,70,txt,strlen(txt));
        ReleaseDC(hwnd,hDC);

        for (voxel=0; voxel<voxels; voxel++)
        {
            WMprob[voxel]=((ClassImage.img[voxels+voxel] + GMweight*ClassImage.img[2*voxels+voxel]));
            //if (WMprob[voxel]>=0.33) WMprob[voxel]=1.0;
            //else WMprob[voxel]=0.0;
        }
        ReleaseImage(&ClassImage);
    }
    else
    {
        //use the fa if it can be found
        memset(&fa,0,sizeof(struct Image));
        sprintf(fname,"%s\\fa.img",directory);
        if (!LoadFromFileName(hwnd, fname, &fa, 0))
        {
            //if it cant be found in the same directory, ask user
            if (!LoadAnalyzeOrNiftiEx(hwnd, &fa, "Please select FA image", 0)) return 0;
        }
        hDC=GetDC(hwnd);
        sprintf(txt,"Using FA, with threshold=%f, as white matter mask    ",gOptions.FAmin_GTmask);
        TextOut(hDC,100,70,txt,strlen(txt));
        ReleaseDC(hwnd,hDC);
        memcpy(WMprob, fa.img, voxels*sizeof(float));
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (WMprob[voxel]<gOptions.FAmin_GTmask) WMprob[voxel]=0.0;//WMprob is just an FA threshold
            else WMprob[voxel]=1.0;
        }
        ReleaseImage(&fa);
    }

    return 1;
}







//==============================================================================
//          Create LookUp of affinities
//          Only have nonzero affinities where the white matter probability>0.05
//==============================================================================
int GetFODFAffinityLookUp(struct Image *fODF, unsigned char *LookUp, float *WMprob)
{

    int voxel,voxels,vol;
    int X,Y,Zpv;
    float affinity[LOOKUP_VOLS];
    float max;

    X=(*fODF).X;
    Y=(*fODF).Y;
    Zpv=(*fODF).Z/(*fODF).volumes;
    voxels=X*Y*Zpv;

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (WMprob[voxel])
        {

            for (vol=1; vol<=LOOKUP_VOLS; vol++)
            {
                affinity[vol-1]=(*fODF).img[vol*voxels+voxel];
            }

            max=0.0;
            for (vol=1; vol<=LOOKUP_VOLS; vol++)
            {
                if (affinity[vol-1]>max) max=affinity[vol-1];
            }
            if (max<=0.0) max=1.0;
            for (vol=0; vol<LOOKUP_VOLS; vol++)
            {
                LookUp[voxel+vol*voxels]=(unsigned char)(255*(affinity[vol]/max));
            }
        }
    }

    return 1;
}

//==============================================================================
//          Create LookUp of affinities
//          Only have nonzero affinities where the white matter probability>0.05
//==============================================================================
int GetTensorAffinityLookUp(struct Image *tensor, unsigned char *LookUp, float *WMprob)
{

    int voxel,voxels,vol;
    int X,Y,Zpv;
    float affinity[LOOKUP_VOLS];
    float max;

    X=(*tensor).X;
    Y=(*tensor).Y;
    Zpv=(*tensor).Z/6;
    voxels=X*Y*Zpv;

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (WMprob[voxel])
        {
            max=TensorAffinity(tensor, voxel, affinity);
            if (max>0.0)
            {
                if (max<=0.0) max=1.0;
                for (vol=0; vol<LOOKUP_VOLS; vol++)
                {
                    LookUp[voxel+vol*voxels]=255*(affinity[vol]/max); //the LookUp is normalised
                }
            }
        }
    }

    return 1;
}


//==============================================================================
//        Get the affinity
//        *tensor is the tensor image
//        Return the affinity values in affinity[LOOKUP_VOLS], values 1..LOOKUP_VOLS
//==============================================================================
float TensorAffinity(struct Image *tensor, int voxel, float affinity[])
{

    double M[9];
    double max;
    float dx, dy, dz;
    int i,j,k,l;
    int X, Y, Zpv;
    struct ThreeVector V;


    memset(affinity,0,sizeof(float)*LOOKUP_VOLS);

    X=(*tensor).X;
    Y=(*tensor).Y;
    Zpv=(*tensor).Z/6;
    dx=(*tensor).dx;
    dy=(*tensor).dy;
    dz=(*tensor).dz;

    //get the tensor at this voxel
    GetMatrixFromTensor(M, (*tensor).img, X, Y, Zpv, voxel, (*tensor).scale, (*tensor).offset);

    //invert the matrix
    if (!InvertMatrixA(M, 3))
    {
        //MessageBox(NULL,"invert fail","",MB_OK);
        return 0;
    }



    max=0.0;
    for (k=-2; k<=2; k++)
    {
        for (j=-2; j<=2; j++)
        {
            for (i=-2; i<=2; i++)
            {
                l=IndexToNeighbour555(i,j,k);
                if (l>=0) //the neighbour voxel {i,j,k} is ahead of the current voxel
                {
                    V.x=dx*i;
                    V.y=dy*j;
                    V.z=dz*k;
                    NormaliseThreeVector(&V);
                    affinity[l]=TensorODF(M, V);
                    if (affinity[l]>max) max=affinity[l];
                }
            }
        }
    }



    return max;
}







int TestGTconnectivities(HWND hwnd, struct Image *connectivities, float *WMprob,
                         unsigned char *ODFlookUp, int Seed1, int Seed2);
//==============================================================================
//              Given the tensor or fODF do GT based tractography
//==============================================================================
int TestGTtractography(HWND hwnd, struct Image *image, int mode)
{

    unsigned char *ODFlookUp=NULL;         //this contains the integrals over the ODF
    struct Image Connectivities;
    int voxels;
    int X, Y, Zpv;
    int result=0;
    int i;
    int Seed1, Seed2;
    int count;
    float dx, dy, dz;
    float *WMprob=NULL;
    char txt[256];
    HCURSOR hourglass=LoadCursor(NULL,IDC_WAIT);
    HCURSOR	PrevCursor;


    memset(&Connectivities,0,sizeof(struct Image));



    //INITIAL CHECKS
    if ((mode==TENSOR_MODE) && ((*image).volumes!=6))
    {
        MessageBox(hwnd, "Tensor image should have 6 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }
    else if ((mode==FODF_MODE) && ((*image).volumes!=(LOOKUP_VOLS+1)))
    {
        MessageBox(hwnd, "fODF image should have 50 volumes","",MB_OK|MB_ICONWARNING);
        return 0;
    }



    //preliminary operations
    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;



    //WM probability mask
    if (!(WMprob=(float *)malloc(X*Y*Zpv*sizeof(float)))) goto END;
    if (!GetWMprob(hwnd, (*image).filename, WMprob, X, Y, Zpv, GM_WEIGHT)) goto END;


    PrevCursor=SetCursor(hourglass);


    //allocate memory for ODF lookup image
    if (!(ODFlookUp=(unsigned char *)calloc(X*Y*Zpv*LOOKUP_VOLS,1))) goto END;
    if (mode==TENSOR_MODE) GetTensorAffinityLookUp(image, ODFlookUp, WMprob);
    else if (mode==FODF_MODE) GetFODFAffinityLookUp(image, ODFlookUp, WMprob);
    else goto END;



    //Allocate memory for Connectivities image. It has the same number of volumes as there are ROI objects
    if (!MakeImage(&Connectivities, X, Y, Zpv, 2, dx, dy, dz, 0.0, 0.0, 0.0, 1.0, 0.0, DT_FLOAT, HDR, "Connectivities")) goto END;


    count=0;
    for (i=0; i<100; i++)
    {
        Seed1=RandomWMseed(WMprob, voxels);
        Seed2=RandomWMseed(WMprob, voxels);
        if (TestGTconnectivities(hwnd, &Connectivities, WMprob, ODFlookUp, Seed1, Seed2))
        {
            if (fabs(Connectivities.img[Seed2]-Connectivities.img[Seed1+voxels])>0.0001) count++;
            //sprintf(txt,"%f %f",Connectivities.img[Seed2],Connectivities.img[Seed1+voxels]);
            //MessageBox(NULL,txt,"",MB_OK);
        }
    }
    sprintf(txt,"%d",count);
    MessageBox(NULL,txt,"",MB_OK);


    SetCursor(PrevCursor);

END:
    if (ODFlookUp) free(ODFlookUp);
    ReleaseImage(&Connectivities);
    if (WMprob) free(WMprob);

    return result;
}



//==============================================================================
//          Get Connectivities from ROI seeds
//          Need a mask to remove non white matter
//          Need the ODF integral looukup image
//          Need an image to put the connectivities in to
//          Runs each voxel in turn, then gets the max for the overall connectivity
//==============================================================================
int TestGTconnectivities(HWND hwnd, struct Image *connectivities, float *WMprob,
                         unsigned char *ODFlookUp, int Seed1, int Seed2)
{

    int X, Y, Zpv;
    int voxel, voxels;
    int result=0;
    unsigned char *seeds=NULL;
    float *connectivity=NULL;
    float dx,dy,dz;
    char *prev=NULL;


    X=(*connectivities).X;
    Y=(*connectivities).Y;
    Zpv=(*connectivities).Z/(*connectivities).volumes;
    voxels=X*Y*Zpv;
    dx=(*connectivities).dx;
    dy=(*connectivities).dy;
    dz=(*connectivities).dz;

    //allocate memory
    if (!(seeds=(unsigned char *)malloc(voxels))) goto END;
    if (!(prev=(char *)malloc(voxels))) goto END;
    if (!(connectivity=(float *)malloc(voxels*sizeof(float)))) goto END;

    memset((*connectivities).img,0,sizeof(float)*voxels*(*connectivities).volumes);



    FuzzyConnectednessWithMemory5x5x5(FibreProbability, WMprob,ODFlookUp, Seed1,
                                      connectivity, prev,X, Y, Zpv, dx, dy, dz, COS_ANGLE,
                                      hwnd, 0.02, 10*X*Y*Zpv);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (connectivity[voxel]>(*connectivities).img[voxel])
        {
            (*connectivities).img[voxel]=connectivity[voxel];
        }
    }

    FuzzyConnectednessWithMemory5x5x5(FibreProbability, WMprob,ODFlookUp, Seed2,
                                      connectivity, prev,X, Y, Zpv, dx, dy, dz, COS_ANGLE,
                                      hwnd, 0.02, 10*X*Y*Zpv);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (connectivity[voxel]>(*connectivities).img[voxel+voxels])
        {
            (*connectivities).img[voxel+voxels]=connectivity[voxel];
        }
    }

    result=1;
END:

    if (seeds) free(seeds);
    if (prev) free(prev);
    if (connectivity) free(connectivity);

    return result;
}



