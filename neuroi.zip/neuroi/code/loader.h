/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(Loader_H)
//Do Nothing
#else
#define Loader_H
//--------------------------------------------------------------------------------------------
//                routines for loading (and saving) analyze and nifti images
//                              19th Feb 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <shlobj.h>
#include <limits.h>
#include "dbh.h"
#include "nifti1.h"

#define HDR 1
#define NIFTI 2

struct MatrixLimits{
    int x0;
    int x1;
    int y0;
    int y1;
    int valid;
};


//structure to put all image data into
struct Image{
       float *img;
       float *floatimg;               //For general use
       unsigned char *charimg;        //store classes, for example
       short int X;
       short int Y;                   //image matrix dimensions
       short int Z;                   //Z is the total number of slices in the multi volume image
       short int volumes;             //number of volumes (must be at least 1)
       int swapbytes;                 //are the bytes swaped in the image files?
       float dx;
       float dy;                      //voxel dimensions (positive)
       float dz;
       char VoxUnits[4];
       float x0;
       float y0;                      //image (single volume) origin in the same units as dx, dy, and dz
       float z0;
       float scale;                   //intensity scale
       float offset;                  //intensity offset
       float MaxIntensity;            //the image maximum intensity
       float vox_offset;
       double rotation[16];           //keep the rotations in here in case needed
       char filename[MAX_PATH];
       char headername[MAX_PATH];
       short int DataType;            //Currently: unsigned char, signed short, float, double
       short int ImageType;           //Analyze or NIFTI
       short int NIFTImethod;
       char PatientID[256];
       char Descrip[256];
       struct dsr hdr;
       struct nifti_1_header nifti;
       int changed;
};


struct Image gImage;                            //the loaded image for display
int SwapBytes(void *ptr, int Num);
int LoadAnalyzeOrNifti(HWND hwnd, struct Image *image, int StandardiseScale);
int LoadAnalyzeOrNiftiEx(HWND hwnd, struct Image *image, char message[], int StandardiseScale);
int LoadFromFileName(HWND hwnd, char name[], struct Image *image, int StandardiseScale);
float *LoadBinaryData(char file[], int voxels, int skip);
int GetBit(unsigned char bits[], int bit);
int SaveBinary(float img[], int voxels, FILE *fp);
int MakeImage(struct Image *image, int X, int Y, int Zpv, int volumes, float dx, float dy, float dz,
                     float x0, float y0, float z0, float scale, float offset, int DataType,
                     int ImageType, char descrip[]);
int SaveAs(struct Image *image);
int Save(struct Image *image);
int SaveNiftiImage(struct Image *image, char filename[]);
int SaveAnalyzeImage(struct Image *image, char headername[], char filename[]);
int SaveAsCharImage(struct Image *image, int Scale);
int BitsPerPixel(short int datatype);
unsigned long int Get_File_Size(char name[]);
int GetImageFileNames(char names[], int N, char Message[]);
int NumberOfFiles(char names[]);
int GetFileName(char name[]);
int GetFileNameTitle(char name[], char title[]);
int GetNthFileName(char names[], int n, char name[]);
int GetDirectoryName(HWND hwnd, char Directory[], char instructions[]);
int DirectoryFileDivide(char fname[]);
#endif
