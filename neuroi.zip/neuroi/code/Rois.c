/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "ROIs.h"
#include "numerical.h"


int IsInsideROI(struct ROIedge ROI[], int Xseed, int Yseed, int length);
int GetStraightLine(int x0, int y0, int x1, int y1, struct ROIedge roi[], int initlength);
//============================================================================================
//                      grows a region from the seed Xseed,Yseed
//                      image intensity must be within range MIN-MAX
//                      Region can be limited by Limit
//============================================================================================
int FloodFillLimited(float image[], unsigned char result[], unsigned char Limit[], int X, int Y,
                     int Xseed, int Yseed, float MIN, float MAX)
{

    struct XY *list=NULL;
    int current, upto;
    int x,y,i,j;
    int xmin,xmax,ymin,ymax;
    float I;

    xmin=0;
    ymin=0;
    xmax=X-1;
    ymax=Y-1;

    //outside image
    if ((Xseed<xmin) || (Xseed>xmax) || (Yseed<ymin) || (Yseed>ymax)) return 0;

    //outside intensity ADDED 15/MAY/2013
    i = Xseed + Yseed*X;
    I = image[i];
    if ((I<MIN) || (I>MAX)) return 0;

    list=(struct XY *)malloc(X*Y*sizeof(struct XY));
    if (!list)
    {
        MessageBox(NULL,"No memory allocated: FloodFillLimited","",MB_OK);
        return 0;
    }


    memset(list,0,X*Y*sizeof(struct XY));

    current=upto=0;
    list[current].x=Xseed;
    list[current].y=Yseed;
    result[Xseed+Yseed*X]=FILL;

    do
    {
        x=list[current].x;
        y=list[current].y;
        for (i=-1; i<=1; i++)
        {
            for (j=-1; j<=1; j++)
            {
                if ( (i && !j) || (j && !i) )
                {
                    if ( ((x+i)>=xmin) && ((x+i)<=xmax) && ((y+j)>=ymin) && ((y+j)<=ymax) )
                    {
                        I=image[x+i + (y+j)*X];
                        if ((I>=MIN) && (I<=MAX) && (!result[x+i + (y+j)*X]) && Limit[x+i + (y+j)*X])
                        {
                            upto++;
                            list[upto].x=(x+i);
                            list[upto].y=(y+j);
                            result[x+i + (y+j)*X]=FILL;
                        }
                    }
                }
            }
        }
        current++;
    }
    while(upto<(X*Y-1) && current<=upto);

    if (list) free(list);
    return upto+1;
}

//============================================================================================
//                      grows a region from the seed Xseed,Yseed
//                      image intensity must be within range MIN-MAX
//============================================================================================
int FloodFillImage(float image[], unsigned char result[], int X, int Y,
                   int Xseed, int Yseed, float MIN, float MAX)
{

    struct XY *list=NULL;
    int current, upto;
    int x,y,i,j,index;
    int xmin,xmax,ymin,ymax;
    float I;

    xmin=0;
    ymin=0;
    xmax=X-1;
    ymax=Y-1;

    //outside image
    if ((Xseed<xmin) || (Xseed>xmax) || (Yseed<ymin) || (Yseed>ymax)) return 0;

    //outside intensity
    i = Xseed + Yseed*X;
    I = image[i];
    if ((I<MIN) || (I>MAX)) return 0;


    list=(struct XY *)malloc(X*Y*sizeof(struct XY));
    if (!list)
    {
        MessageBox(NULL,"No memory allocated: FloodFillImage","",MB_OK);
        return 0;
    }


    memset(list,0,X*Y*sizeof(struct XY));

    current=upto=0;
    list[current].x=Xseed;
    list[current].y=Yseed;
    result[Xseed+Yseed*X]=FILL;

    do
    {
        x=list[current].x;
        y=list[current].y;
        for (i=-1; i<=1; i++)
        {
            for (j=-1; j<=1; j++)
            {
                if ( (i && !j) || (j && !i) )
                {
                    if ( (x+i)>=xmin && (x+i)<=xmax && (y+j)>=ymin && (y+j)<=ymax )
                    {
                        index=x+i + (y+j)*X;
                        I=image[index];
                        if (I>=MIN && I<=MAX && !result[index])
                        {
                            upto++;
                            list[upto].x=(x+i);
                            list[upto].y=(y+j);
                            result[index]=FILL;
                        }
                    }
                }
            }
        }
        current++;
    }
    while(upto<(X*Y-1) && current<=upto);

    if (list) free(list);
    return upto+1;
}


//============================================================================================
//                      grows a region from the seed Xseed,Yseed
//                      image intensity must be within range MIN-MAX
//============================================================================================
int FloodFillImage3D(float image[], unsigned char result[], int X, int Y, int Z,
                     int Xseed, int Yseed, int Zseed, float MIN, float MAX)
{

    struct XYZ *list=NULL;
    int current, upto;
    int x,y,z,i,j,k;
    int xmin,xmax,ymin,ymax;
    int XY=X*Y;
    int voxels=X*Y*Z;
    int voxel;
    float I;

    xmin=2;
    ymin=2;
    xmax=X-2;
    ymax=Y-2;

    memset(result,0,voxels);

    //outside image
    if ((Xseed<xmin) || (Xseed>xmax) || (Yseed<ymin) || (Yseed>ymax) || (Zseed<0) || (Zseed>=Z)) return 0;

    //outside intensity
    i = Xseed + Yseed*X;
    I = image[i];
    if ((I<MIN) || (I>MAX)) return 0;


    list=(struct XYZ *)malloc(voxels*sizeof(struct XYZ));
    if (!list)
    {
        MessageBox(NULL,"No memory allocated: FloodFillImage3D","",MB_OK);
        return 0;
    }


    memset(list,0,voxels*sizeof(struct XYZ));

    current=upto=0;
    list[current].x=Xseed;
    list[current].y=Yseed;
    list[current].z=Zseed;
    result[Xseed+Yseed*X+Zseed*XY]=FILL;

    do
    {
        x=list[current].x;
        y=list[current].y;
        z=list[current].z;
        for (k=-1; k<=1; k++)
        {
            for (j=-1; j<=1; j++)
            {
                for (i=-1; i<=1; i++)
                {
                    if ( (abs(i)+abs(j)+abs(k)==1) )
                    {
                        if ( ((x+i)>=xmin) && ((x+i)<=xmax) && ((y+j)>=ymin) && ((y+j)<=ymax) && ((z+k)>=0) && ((z+k)<Z))
                        {
                            voxel=x+i + (y+j)*X + (z+k)*XY;
                            I=image[voxel];
                            if ((I>=MIN) && (I<=MAX) && (!result[voxel]))
                            {
                                upto++;
                                list[upto].x=(x+i);
                                list[upto].y=(y+j);
                                list[upto].z=(z+k);
                                result[voxel]=FILL;
                            }
                        }
                    }
                }
            }
        }
        current++;
    }
    while(upto<(voxels-1) && current<=upto);

    if (list) free(list);
    return upto+1;
}







//============================================================================================
//                       Fill a mask using a ROI
//                       The output will be the mask with the ROI
//                       edge defined as EDGE
//                       all voxels within the ROI will be FILL
//                       voxels outside of the ROI will be unchanged
//                       length is the length of the ROI
//                       X,Y are the dimensions of the mask image
//                       returns the number of FILLed voxels
//============================================================================================
int FloodFillROI(unsigned char mask[], int X, int Y, struct ROIedge ROI[], int length)
{

    struct FillList *list=NULL;
    int x0,y0,l, N, pixels;
    unsigned char *outside=NULL;
//    char txt[256];


    if ((ROI[0].x!=ROI[length-1].x) || (ROI[0].y!=ROI[length-1].y)) return 0;           //The ROI must be closed


    pixels=X*Y;
    if (!(outside=(unsigned char *)calloc(pixels,1))) return 0;

    memset(&list,0,sizeof(struct FillList));
    if (!(list = (struct FillList *)malloc(sizeof(struct FillList)*pixels))) return 0;



    for (l=0; l<length; l++)
    {
        if ((ROI[l].x>=0) && (ROI[l].x<X) && (ROI[l].y>=0) && (ROI[l].y<Y))
        {
            mask[ROI[l].x+ROI[l].y*X]=EDGE;
            outside[ROI[l].x+ROI[l].y*X]=EDGE;
        }

    }


    for(l=0; l<length; l+=3) //to speed up the process, increment l faster
    {
        for (y0=-1; y0<=1; y0++)
        {
            for (x0=-1; x0<=1; x0++)
            {
                if ((x0 || y0))
                {
                    if (  ((ROI[l].x+x0)>=0) && ((ROI[l].x+x0)<X) && ((ROI[l].y+y0)>=0) && ((ROI[l].y+y0)<Y)
                            && (!mask[ (ROI[l].x+x0) + (ROI[l].y+y0)*X  ]) && (!outside[ (ROI[l].x+x0) + (ROI[l].y+y0)*X  ]))
                    {
                        if (IsInsideROI(ROI,(ROI[l].x+x0), (ROI[l].y+y0), length)) FloodFillToRegionEdgeFast(mask, X, Y, ROI[l].x+x0, ROI[l].y+y0, list);
                        else FloodFillToRegionEdgeFast(outside, X, Y, ROI[l].x+x0, ROI[l].y+y0,list);//if we fill the outside, wont need to check if the voxel is inside the ROI so often
                    }
                }
            }
        }
    }


    N=0;
    for (l=0; l<pixels; l++)
    {
        if (mask[l]==FILL) N++;                                             //count the number of FILLed (not EDGE) voxels
    }

    if (list) free(list);

    if (outside) free(outside);

    return N;
}






//============================================================================================
//                        Get whole image ROI mask (binary)
//                        object indicates what object to include
//                        if object == 0 then all objects will be included
//============================================================================================
int GetBinaryROImask(unsigned char mask[], int X, int Y, int Z, int object, int IncludeEdge)
{

    int roi;
    int count=0;
    int pixel;
    int voxels=X*Y*Z;
    int XY=X*Y;
    unsigned char *slice=NULL;

    memset(mask,0,X*Y*Z);
    slice=(unsigned char *)malloc(X*Y);
    if (!slice) return 0;


    for (roi=1; roi<=gNumberOfROIs; roi++)
    {
        if (((ROIs[roi].object==object) || !object) && !ROIs[roi].removed && (ROIs[roi].slice<Z))
        {
            memset(slice,0,XY);
            FloodFillROI(slice, X, Y, ROIs[roi].roi, ROIs[roi].length);
            for (pixel=0; pixel<XY; pixel++)
            {
                if ((slice[pixel]==FILL) || ((slice[pixel]==EDGE) && IncludeEdge)) mask[pixel+ROIs[roi].slice*XY]=1;
            }
        }
    }

    for (pixel=0; pixel<voxels; pixel++) if (mask[pixel]) count++;

    free(slice);

    return count;
}
//============================================================================================
//                        Get whole image ROI mask (with ROI numbers)
//                        object indicates what object to include
//                        if object == 0 then all objects will be included
//============================================================================================
int GetROInumberMask(short int mask[], int X, int Y, int Z, int object, int IncludeEdge)
{

    int roi;
    int count=0;
    int pixel;
    int voxels=X*Y*Z;
    int XY=X*Y;
    unsigned char *slice=NULL;

    memset(mask,0,X*Y*Z*sizeof(short int));
    slice=(unsigned char *)malloc(XY);
    if (!slice) return 0;


    for (roi=1; roi<=gNumberOfROIs; roi++)
    {
        if (((ROIs[roi].object==object) || !object) && (!ROIs[roi].removed))
        {
            memset(slice,0,XY);
            FloodFillROI(slice, X, Y, ROIs[roi].roi, ROIs[roi].length);
            for (pixel=0; pixel<XY; pixel++)
            {
                if ((slice[pixel]==FILL) || ((slice[pixel]==EDGE) && IncludeEdge)) mask[pixel+ROIs[roi].slice*XY]=(short int)roi;
            }
        }
    }

    for (pixel=0; pixel<voxels; pixel++) if (mask[pixel]) count++;

    free(slice);

    return count;
}

//============================================================================================
//                      Renumber All ROIs into seperate 3D objects
//============================================================================================
int ReNumberROIObjects(HWND hwnd, struct Image *image)
{

    short int *mask=NULL;
    short int *Objects=NULL;
    unsigned char *object=NULL;
    int ObjCount=0;
    int X, Y, Z, XY;
    int voxel, voxel2,voxels;
    int xs, ys, zs;
    int roi, obj;
    char txt[256];
    HDC hDC=GetDC(hwnd);

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    XY=X*Y;
    voxels=X*Y*Z;

    if (!(mask=(short int *)malloc(sizeof(short int)*voxels))) goto END;
    if (!(object=(unsigned char *)malloc(voxels))) goto END;
    if (!(Objects=(short int *)malloc(voxels*sizeof(int)))) goto END;





//get all the ROIs as an image of ROI numbers. This image does not include the ROI lines
    GetROInumberMask(mask, X, Y, Z, 0, 0);//mask contains the ROIs as ROI numbers now.


//Get the numbered objects
    memset(Objects,0,voxels*sizeof(short int));
    for (zs=0; zs<Z; zs++)
    {
        for (ys=0; ys<Y; ys++)
        {
            for (xs=0; xs<X; xs++)
            {
                voxel=xs + ys*X + zs*XY;
                if ((mask[voxel]) && (!Objects[voxel]))
                {
                    memset(object,0,voxels);
                    for (voxel2=0; voxel2<voxels; voxel2++) if (mask[voxel2])
                        {
                            object[voxel2]=1;
                        }
                    if (ConnectedObject(object, X, Y, Z, xs, ys, zs))
                    {
                        ObjCount++;
                        sprintf(txt,"object %d   ",ObjCount);
                        TextOut(hDC,100,100,txt,strlen(txt));
                        for (voxel2=0; voxel2<voxels; voxel2++)
                        {
                            if (object[voxel2]) Objects[voxel2]=ObjCount;
                        }
                    }
                }
            }
        }
    }




//Now re-number the ROI objects
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((roi=mask[voxel]) && (obj=Objects[voxel]))
        {
            ROIs[roi].object=obj;
        }
    }

    if (gNumberOfObjects<ObjCount) gNumberOfObjects=ObjCount;


END:
    if (mask) free(mask);
    if (object) free(object);
    if (Objects) free(Objects);

    ReleaseDC(hwnd,hDC);

    return 1;
}
/*

//============================================================================================
//                      Renumber All ROIs into seperate 3D objects
//============================================================================================
int ReNumberROIObjects(HWND hwnd, struct Image *image){

    unsigned char *mask=NULL;
    unsigned char *object=NULL;
    int *Objects=NULL;
    int ObjCount=0;
    int X, Y, Z;
    int voxel, voxel2,voxels;
    int xs, ys, zs;
    int roi, l;
    char txt[256];
    HDC hDC=GetDC(hwnd);

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    if (!(mask=(unsigned char *)malloc(voxels))) goto END;
    if (!(object=(unsigned char *)malloc(voxels))) goto END;
    if (!(Objects=(int *)malloc(voxels*sizeof(int)))) goto END;

    memset(mask,0,voxels);
    memset(object,0,voxels);
    memset(Objects,0,voxels*sizeof(int));

//get all the ROIs as a binary image. This image does not include the ROI lines
    GetBinaryROImask(mask, X, Y, Z, 0, 0);//mask contains the ROIs as objects (1) now.

//Now put the ROI lines back
    for (roi=1;roi<=gNumberOfROIs;roi++){
		if ( !ROIs[roi].removed ){
	        for (l=0;l<ROIs[roi].length;l++) mask[ROIs[roi].roi[l].x + ROIs[roi].roi[l].y*X + ROIs[roi].slice*X*Y]=1;
		}
    }


//Get the numbered objects
    for (zs=0;zs<Z;zs++){
        for (ys=0;ys<Y;ys++){
            for (xs=0;xs<X;xs++){
                voxel=xs + ys*X + zs*X*Y;
                if (mask[voxel] && !Objects[voxel]){
                   memcpy(object, mask, voxels);
                   if (ConnectedObject(object, X, Y, Z, xs, ys, zs)){
                      ObjCount++;
                      sprintf(txt,"object %d   ",ObjCount);
                      TextOut(hDC,100,100,txt,strlen(txt));
                      for (voxel2=0;voxel2<voxels;voxel2++){
                          if (object[voxel2]) Objects[voxel2]=ObjCount;
                      }
                   }
                }
            }
        }
    }

//Now re-number the ROI objects
    for (roi=1;roi<=gNumberOfROIs;roi++){
		if ( !ROIs[roi].removed ){
	        ROIs[roi].object=Objects[ROIs[roi].roi[0].x+ROIs[roi].roi[0].y*X + ROIs[roi].slice*X*Y];
		}
    }

    if (gNumberOfObjects<ObjCount) gNumberOfObjects=ObjCount;


END:
    if (mask) free(mask);
    if (object) free(object);
    if (Objects) free(Objects);

    ReleaseDC(hwnd,hDC);

    return 1;
}
*/


//============================================================================================
//         Convert an image of objects to a set of ROIs
//============================================================================================
int ConvertObjectToROIs(HWND hwnd, struct Image *image)
{

    int X,Y,Z;
    int voxel, voxel2, voxels;
    int x,y,z, slice;
    int ObjCount=1;
    int length;
    int ObjSize;
    unsigned char *mask=NULL;
    unsigned char *object=NULL;
    unsigned char *Objects=NULL;
    struct ROIedge ROI[MAX_ROI_LENGTH];
    HDC hDC=GetDC(hwnd);
    char txt[256];
    HCURSOR hourglass, PrevCursor;

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    mask=(unsigned char *)malloc(voxels);
    object=(unsigned char *)malloc(voxels);
    Objects=(unsigned char *)malloc(voxels);
    if (!mask || !object || !Objects) goto END;

    memset(mask,0,voxels);
    memset(object,0,voxels);
    memset(Objects,0,voxels);

    for (voxel=0; voxel<voxels; voxel++) if ((*image).img[voxel]) mask[voxel]=1;

    //DilateImage2D(mask, X, Y, Z);


    //Get the numbered objects
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                voxel=x + y*X + z*X*Y;
                if ((mask[voxel]) && (!Objects[voxel]))
                {
                    memcpy(object, mask, voxels);


                    if (ConnectedObject(object, X, Y, Z, x, y, z))
                    {

                        ObjSize=0;
                        GetBinaryROImask(Objects, X, Y, Z, 0, 1);
                        for (voxel2=0; voxel2<voxels; voxel2++)
                        {
                            //cant include the voxels already in Objects
                            if (Objects[voxel2]) object[voxel2]=0;
                            if (object[voxel2]) ObjSize++;
                        }

                        if (ObjSize)
                        {

                            for (slice=0; slice<Z; slice++)
                            {
                                length=RegionEdgeDetect(&object[slice*X*Y], X, Y, ROI, MAX_ROI_LENGTH);
                                if (length) gNumberOfROIs=AcceptROI(X, Y, ROI, length, 0, 0, slice, gNumberOfROIs, ObjCount, AUTO);
                            }

                        }
                        else
                        {
                            ObjCount++;
                            sprintf(txt,"object %d   ",ObjCount);
                            TextOut(hDC,100,100,txt,strlen(txt));
                        }

                    }
                }
            }
        }
    }
    SaveROIs(1, gMainPict.X, gMainPict.Y, gMainPict.Z);//backup the ROIs
    /*
    //a check that the objects are being captured by ConnectedObject function
    for (voxel2=0;voxel2<voxels;voxel2++){
        if (!Objects[voxel2]) (*image).img[voxel]=0.0;
    }*/

    gNumberOfObjects=ObjCount;
END:
    if (mask) free(mask);
    if (object) free(object);
    if (Objects) free(Objects);
    ReleaseDC(hwnd,hDC);
    SetCursor(PrevCursor);

    return ObjCount;
}


//============================================================================================
//         Convert an image of objects to an image of object sizes
//If CountLabel, the objects are not labeled by size, but by a unique value
//============================================================================================
int GetSizedObjectsImage(HWND hwnd, float *SizedObjects, int X, int Y, int Z, int CountLabel)
{

    int voxel, voxel2, voxels;
    int x,y,z;
    int ObjCount=0;
    int ObjSize;
    float label;
    unsigned char *mask=NULL;
    unsigned char *object=NULL;
    HDC hDC=GetDC(hwnd);

    voxels=X*Y*Z;

    mask=(unsigned char *)malloc(voxels);
    object=(unsigned char *)malloc(voxels);
    if (!mask || !object) goto END;


    memset(mask,0,voxels);
    memset(object,0,voxels);


    for (voxel=0; voxel<voxels; voxel++) if (SizedObjects[voxel]>0.0)
        {
            mask[voxel]=1;
        }
    memset(SizedObjects,0,sizeof(float)*voxels);

    //Get the numbered objects
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                voxel=x + y*X + z*X*Y;
                if ((mask[voxel]) && (SizedObjects[voxel]<=0.0))
                {
                    memcpy(object, mask, voxels);

                    if ( (ObjSize=ConnectedObject(object, X, Y, Z, x, y, z)) )
                    {
                        ObjCount++;

                        if (CountLabel) label=(float)ObjCount;
                        else label=(float)ObjSize;

                        for (voxel2=0; voxel2<voxels; voxel2++) if (object[voxel2]) SizedObjects[voxel2]=label;


                    }
                }
            }
        }
    }


END:
    if (mask) free(mask);
    if (object) free(object);
    ReleaseDC(hwnd,hDC);

    return ObjCount;
}




//============================================================================================
//						Compare ROI objects masks
//						Image dimensions must be the same
//============================================================================================
int CompareROIobjectMasks(HWND hwnd, struct Image *ROIobj1)
{

    struct Image ROIobj2;
    int X,Y,Z;
    int voxel, voxels;
    int i,j;
    int *M=NULL;
    int max1,max2;
    int rows,columns;
    int result=0;
    int EmptyCols, EmptyRows;
    int *marginal1=NULL, *marginal2=NULL;
    FILE *fp;


    X=(*ROIobj1).X;
    Y=(*ROIobj1).Y;
    Z=(*ROIobj1).Z;
    voxels=X*Y*Z;

    memset(&ROIobj2,0,sizeof(struct Image));
    if (!LoadAnalyzeOrNiftiEx(hwnd, &ROIobj2, "Load second ROI object image", 0)) goto END;

    if ((ROIobj2.X!=X) || (ROIobj2.Y!=Y) || (ROIobj2.Z!=Z))
    {
        MessageBox(NULL,"Image dimentions must be equal to compare","",MB_OK|MB_ICONWARNING);
        goto END;
    }

    //maximum determines the matrix size
    max1=max2=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((int)(*ROIobj1).img[voxel])>max1) max1=(int)(*ROIobj1).img[voxel];
        if (((int)ROIobj2.img[voxel])>max2) max2=(int)ROIobj2.img[voxel];
    }

    columns=max1+2;
    rows=max2+2;
    if (!(M=(int *)malloc(sizeof(int)*rows*columns))) goto END;
    memset(M,0,sizeof(int)*rows*columns);

    if (!(marginal1=(int *)malloc(columns*sizeof(int)))) goto END;
    memset(marginal1,0,columns*sizeof(int));
    if (!(marginal2=(int *)malloc(rows*sizeof(int)))) goto END;
    memset(marginal2,0,rows*sizeof(int));


    for (i=1; i<=max1; i++) M[i]=i;
    for (i=1; i<=max2; i++) M[i*columns]=i;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((i=(int)(*ROIobj1).img[voxel])) M[i+(rows-1)*columns]++;
        if ((j=(int)ROIobj2.img[voxel])) M[j*columns+(columns-1)]++;
        if (i&&j)
        {
            M[i+j*columns]++;
            marginal1[i]++;
            marginal2[j]++;
        }
    }

    EmptyRows=EmptyCols=0;
    for (j=1; j<=max1; j++)
    {
        if (!marginal1[j]) EmptyCols++;
    }
    for (j=1; j<=max2; j++)
    {
        if (!marginal2[j]) EmptyRows++;
    }



    if ((fp=fopen("./ROIoverlap.csv","w")))
    {
        fprintf(fp,"Rows: %s\n",(*ROIobj1).filename);
        fprintf(fp,"Columns: %s\n\n",ROIobj2.filename);
        for (j=0; j<rows; j++)
        {
            for (i=0; i<columns; i++)
            {
                if (j==(rows-1) && i==0) fprintf(fp,"Totals,");
                else if (j==0 && i==(columns-1)) fprintf(fp,"Totals,");
                else fprintf(fp,"%d,",M[i+j*columns]);
            }
            fprintf(fp,"\n");
        }
        fprintf(fp,"\n\n Empty rows=%d \n Empty columns=%d\n",EmptyRows,EmptyCols);
        fclose(fp);
    }



END:
    if (M) free(M);
    ReleaseImage(&ROIobj2);
    return result;
}





//============================================================================================
//                      Save a binary ROI object for all ROIs
//                      binary indicates if the image saved should be binary (0 OR 100)
//                          or have ROI object numbers
//                      If ROIs overlap, the highest object number wins
//============================================================================================
int SaveROIobject(struct Image *image, int binary)
{

    unsigned char *object=NULL;
    short int *full=NULL;
    int X, Y, Z;
    int voxel, voxels;
    int Obj;
    int result=0;
    struct Image ROIobject;
    HCURSOR hourglass, PrevCursor;

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);

    memset(&ROIobject,0,sizeof(struct Image));

    if (!MakeCopyOfImage(image, &ROIobject)) goto END;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    if (!(object=(unsigned char *)malloc(voxels))) goto END;
    if (!(full=(short int *)malloc(voxels*sizeof(short int)))) goto END;

    memset(full, 0, sizeof(short int)*voxels);
    for (Obj=1; Obj<=gNumberOfObjects; Obj++)
    {
        GetBinaryROImask(object, X, Y, Z, Obj, 0);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (object[voxel])
            {
                if (binary) full[voxel]=100;
                else full[voxel]=Obj;
            }
        }
    }


    for (voxel=0; voxel<voxels; voxel++)
    {
        ROIobject.img[voxel]=full[voxel];
    }

    if ( !SaveAs(&ROIobject) ) goto END;


    result=1;
END:
    SetCursor(PrevCursor);
    ReleaseImage(&ROIobject);
    if (object) free(object);
    if (full) free(full);

    return result;
}










/*
//============================================================================================
//                       Compute the angle enclosed by the ROI
//                       the return should be 0..2PI
//============================================================================================
int IsInsideROI(struct ROIedge ROI[], int Xseed, int Yseed, int length)
{

    int Xstart,Ystart;
    int i;
    double norm1,norm2;
    double x1,y1,x2,y2,a;
    double theta=0.0,dtheta, sign;

    Xstart=ROI[0].x;
    Ystart=ROI[0].y;


    x2=(double)(Xseed-ROI[0].x);
    y2=(double)(Yseed-ROI[0].y);
    norm2=sqrt(x2*x2+y2*y2);
    i=1;
    do
    {
        x1=(double)(Xseed-ROI[i].x);
        y1=(double)(Yseed-ROI[i].y);
        norm1=sqrt(x1*x1+y1*y1);

        if ((x1*y2-y1*x2)>0.0) sign=1.0;      //cross product gives sign
        else sign=-1.0;


        if (norm1 && norm2)
        {
            a=(x1*x2+y1*y2)/norm1/norm2;
            if (a>=1.0) dtheta=0.0;
            else //Use dot product to get angle
            {
                if (a>0.97)  dtheta=sign*sqrt(2.0-2.0*a);//small angle approx solution to make things a bit quicker
                else dtheta=sign*acos( a );
            }
        }
        else dtheta=0.0;

        theta+=dtheta;


        x2=x1;
        y2=y1;
        norm2=norm1;
        i++;
    }
    while( (i<length) && !(ROI[i].x==Xstart && ROI[i].y==Ystart));

    if (fabs(theta)>PI) return 1;
    return 0;
}
int TestROIenclosedAngle(struct Image *image)
{
    int x,y,z;
    int X,Y;
    float angle;

    if (!gNumberOfROIs) return 0;

    X=(*image).X;
    Y=(*image).Y;

    for (z=0; z<1; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                angle=IsInsideROI(ROIs[1].roi, x, y, ROIs[1].length);
                (*image).img[x + y*X + z*X*Y]=angle;
            }
        }
    }

    (*image).MaxIntensity=7.0;

    return 1;
}
*/
//============================================================================================
//TEST IF A POINT IS INSIDE AN ROI
//IF IT IS IT WILL CROSS THE Yseed POINT AN ODD NUMBER OF TIMES, AT x>Xseed
//A CROSS IS: GOING FROM >Yseed TO <Yseed, OR <Yseed TO >Yseed WITH X>Xseed
//============================================================================================
int IsInsideROI(struct ROIedge ROI[], int Xseed, int Yseed, int length)
{
    int i,previous,next;
    int crossings=0;
    int wrapcrossings=0;//its possible for a crossing around ROI[0] is counted twice
    //char txt[256];
    //FILE *fp=NULL;

    //fp=fopen("c:\\temp\\inside.csv","w");

    //if its not closed, its not inside
    if ( (ROI[0].x!=ROI[length-1].x) || (ROI[0].y!=ROI[length-1].y) ) return 0;

    //if the seed is on the ROI line, its considered outside
    for (i=0; i<length; i++)
    {
        if ( (ROI[i].x==Xseed) && (ROI[i].y==Yseed)) return 0;
    }

    //because the first and last points are duplicates, reduce length by 1
    length--;

    i=0;
    do
    {
        previous=next=0;
        if ((ROI[i].y == Yseed) && (ROI[i].x>Xseed))
        {
            //find the previous point that does not have y=Yseed
            previous=i-1;
            if (previous<0) previous=length-1;
            while ((previous>=0) && (ROI[previous].y == Yseed))
            {
                previous--;
            }
            //find the next point that does not have y=Yseed
            next=i+1;
            if (next>=length) next=0;
            while ((next<length) && (ROI[next].y == Yseed))
            {
                next++;
            }

            if ( ((ROI[previous].y>Yseed) && (ROI[next].y<Yseed)) || ((ROI[previous].y<Yseed) && (ROI[next].y>Yseed)) )
            {
                if (previous>next) wrapcrossings++;
                crossings++;
            }

            while ( (i<length) && (ROI[i].y == Yseed)) i++;

        }
        //if (fp) fprintf(fp,"yprev=%d, ynext=%d, yi=%d, crossings=%d,  prev=%d, i=%d, next=%d, wrapcrossings=%d\n",ROI[previous].y,ROI[next].y,ROI[i].y,crossings, previous, i, next, wrapcrossings);

        i++;
    }
    while (i<length);

    //if (fp) fclose(fp);

    if (wrapcrossings>1) crossings--;

    return crossings%2;
}



//============================================================================================
//                       Fill a closed region in Mask
//                       Starting at a seed point {Xseed, Yseed}
//                       the return indicates the size of the filled area
//============================================================================================

int FloodFillToRegionEdge(unsigned char Mask[], int X, int Y, int Xseed, int Yseed)
{

    struct FillList *list=NULL;
    int filled;
    int xmin,xmax,ymin,ymax;
    int pixels=X*Y;

    xmin=0;
    ymin=0;
    xmax=X-1;
    ymax=Y-1;

    if ((Xseed<xmin) || (Xseed>xmax) || (Yseed<ymin) || (Yseed>ymax)) return 0;


    if ( (list=(struct FillList *)malloc(pixels*sizeof(struct FillList)) ) )
    {
        filled=FloodFillToRegionEdgeFast(Mask, X, Y, Xseed, Yseed, list);
        free(list);
        return filled;
    }

    return 0;
}



//============================================================================================
//                       Fill a closed region in Mask
//                       Starting at a seed point {Xseed, Yseed}
//                       The fill list is provided so it doesnt have to be malloced each time
//                       the return indicates the size of the filled area
//============================================================================================
int FloodFillToRegionEdgeFast(unsigned char Mask[], int X, int Y, int Xseed, int Yseed, struct FillList *list)
{

    int current, upto;
    int x,y,i,j;
    int xmin,xmax,ymin,ymax;
    int pixels=X*Y;

    xmin=0;
    ymin=0;//crashes if these limits are placed on the edge
    xmax=X-1;
    ymax=Y-1;

    if ((Xseed<xmin) || (Xseed>xmax) || (Yseed<ymin) || (Yseed>ymax)) return 0;

    if (Mask[Xseed+Yseed*X]) return 0;//moved, to after the preceding line, to avoid potential access outside array limit 10/06/2015

    memset(list,0,pixels*sizeof(struct FillList));

    current=upto=0;
    list[current].x=Xseed;
    list[current].y=Yseed;
    Mask[Xseed+Yseed*X]=FILL;

    do
    {
        x=list[current].x;
        y=list[current].y;
        for (j=-1; j<=1; j++)
        {
            for (i=-1; i<=1; i++)
            {
                if ( (abs(i)+abs(j))==1 )
                {
                    if ( (x+i)>=xmin && (x+i)<=xmax && (y+j)>=ymin && (y+j)<=ymax)
                    {
                        if (!Mask[x+i + (y+j)*X])
                        {
                            upto++;
                            list[upto].x=(x+i);
                            list[upto].y=(y+j);
                            Mask[x+i + (y+j)*X]=FILL;
                        }
                    }
                }
            }
        }
        current++;
    }
    while((upto<pixels) && (current<=upto));

    return upto+1;
}






//============================================================================================
//                         DILATE a filled region
//                         return the number of new EDGE voxels
//============================================================================================
int Grow2Dregion(unsigned char mask[], int X, int Y)
{

    int j,k;
    int xi,yi;
    int xmin,xmax,ymin,ymax;
    int n=0;

    xmin=2;
    ymin=2;
    xmax=X-2;
    ymax=Y-2;

    for (xi=xmin; xi<=xmax; xi++)
    {
        for (yi=ymin; yi<=ymax; yi++)
        {
            if (mask[xi + yi*X]==FILL)
            {
                for (j=-1; j<=1; j++)
                {
                    for (k=-1; k<=1; k++)
                    {
                        if ( (j||k) && !mask[xi+j + (yi+k)*X])
                        {
                            mask[xi+j + (yi+k)*X]=EDGE;
                            n++;
                        }
                    }
                }
            }
        }
    }

    return n;
}







//============================================================================================
//       given an image (dimensions XP, YP) with a single region, detect the edge
//       L is the length of the ROI[] array
//       ROI is filled with the edge on exit
//       first and last elements of ROI are equal on exit
//       return the length of the ROI
//============================================================================================
int RegionEdgeDetect(unsigned char image[], int XP, int YP, struct ROIedge ROI[], int L)
{

    int X,Y,xstart,ystart;
    int x[8]= {0,-1,-1,-1,0,1,1,1};//changed from x[4] search 15/may/2013
    int y[8]= {-1,-1,0,1,1,1,0,-1};
    int dir;
    int found=0;
    int index=0;
    int Counter;
    //char txt[256];
    //FILE *fp;

    memset(ROI,0,L*sizeof(struct ROIedge));

    xstart=ystart=0;
    for (X=0; (X<XP) && !found; X++)                                              //find the first point
    {
        for (Y=0; (Y<YP) && !found; Y++)
        {
            if (image[X+Y*XP])
            {
                found=1;
                xstart=X;
                ystart=Y;
            }
        }
    }
    if (!found)
    {
        return 0;    //cant find the edge
    }


    ROI[index].x=xstart;                                                        //the first point
    ROI[index].y=ystart-1;
    index++;

    X=xstart;
    Y=ystart;

    dir = 0;
    Counter = 0;
    do
    {

        if (((X+x[dir])>=0) && ((X+x[dir])<XP) && ((Y+y[dir])>=0) && ((Y+y[dir])<YP) && (image[X+x[dir] + (Y+y[dir])*XP]))
        {
            //THE POINT IS INSIDE THE IMAGE RANGE, AND THE IMAGE IS TRUE
            //LOOKING FOR NEXT PIXEL THAT IS NOT TRUE
            X += x[dir];
            Y += y[dir];
            if (abs(x[dir]) + abs(y[dir]) == 2) dir += 5;
            else dir += 6;
            dir = dir%8;

        }
        else
        {
            if ( (index<L-1) &&  ((ROI[index-1].x != X+x[dir]) || (ROI[index-1].y != Y+y[dir])) )
            {
                ROI[index].x=X+x[dir];
                ROI[index].y=Y+y[dir];
                index++;
            }
            dir++;
        }

        Counter++;

        if (dir<0) dir=7;
        if (dir>7) dir=0;
    }
    while((Counter<8) || (!((X==xstart) && (Y==ystart))));

    ROI[index].x=ROI[0].x;
    ROI[index].y=ROI[0].y;
    index++;

    if ((index<7) || (index>=L))
    {
        /*if (fp=fopen("c:/temp/roi.txt","w"))
        {
            for (i=0; i<index; i++)
            {
                fprintf(fp,"%d %d %d\n",i,ROI[i].x, ROI[i].y);
            }
            fclose(fp);
        }*/
        return 0;
    }


    return index;                                                               //the last point in the ROI is ROI[index-1]
}




//============================================================================================
//                           Accept the ROI into memory
//                           length is the length of the ROI
//                           In closed rois the length includes the end point
//                              which is the same as the start point
//                           numrois is how many have currently been accepted
//                           object lets us know to which object the ROI belongs
//============================================================================================
int AcceptROI(int X, int Y, struct ROIedge ROI[], int length, int Xseed, int Yseed, int slice, int numrois, int object, char ROItype)
{


    int roi, x,y,i,j;
    //char txt[256];



    //MAKE SURE THAT THE SEED IS WITHIN THE ROI
    if ((ROItype!=LIMIT) && (!IsInsideROI(ROI, Xseed, Yseed, length)))
    {

        //THE SEED SEEMS TO BE OUTSIDE THE ROI SO FIND A NEW SEED
        Xseed=Yseed=-10;
        for (roi=0; (roi<length) && (Xseed==-10); roi++)
        {
            for (j=-1; j<=1; j++)
            {
                for (i=-1; i<=1; i++)
                {
                    x=ROI[roi].x+i;
                    y=ROI[roi].y+j;

                    //CHECK IF THIS IS A VALID SEED
                    if (IsInsideROI(ROI, x, y, length))
                    {
                        Xseed=x;
                        Yseed=y;
                    }

                }
            }
        }
    }


    if (Xseed==-10) return numrois;


    if ((roi=IsROIrepeated(X, Y, ROI, slice, Xseed, Yseed, length)))
    {
        MessageBox(NULL,"ROI already defined. It will not be redifined.","Warning",MB_OK|MB_ICONWARNING);
        return numrois;
    }

    if ((ROItype==AUTO) || (ROItype==SQUARE) || (ROItype==CLOSED))                             //these ROIs must be closed
    {
        if (ROI[0].x!=ROI[length-1].x || ROI[0].y!=ROI[length-1].y)
        {
            MessageBox(NULL,"AcceptROI: ROI not closed","",MB_OK|MB_ICONWARNING);
            return numrois;
        }
    }

    if (length>=MAX_ROI_LENGTH || (numrois+1)>=MAX_ROIS) return numrois;        //check the limits

    ROIs[numrois+1].roi=(struct ROIedge *)malloc(length*sizeof(struct ROIedge));//memory for the ROI
    memcpy(ROIs[numrois+1].roi, ROI, length*sizeof(struct ROIedge));

    ROIs[numrois+1].object=object;
    ROIs[numrois+1].Xseed=Xseed;
    ROIs[numrois+1].Yseed=Yseed;
    ROIs[numrois+1].slice=slice;
    ROIs[numrois+1].length=length;
    ROIs[numrois+1].type=ROItype;

    return numrois+1;
}




//======================================================================================================
//                             Draw ALL ROIs
//======================================================================================================
int DrawAllROIs(struct Picture *picture, HDC hDC, int slice, int width, int DrawLimits)
{

    int i;


    for (i=1; i<=gNumberOfROIs; i++)
    {
        if (!(ROIs[i].type==LIMIT && (!DrawLimits)))
        {
            if (!(ROIs[i].removed) && (slice==ROIs[i].slice || ROIs[i].type==LIMIT))
            {
                DrawROI(picture, hDC,  ROIs[i].roi, ROIs[i].length, Colour(ROIs[i].object), width);
            }
        }
    }
    return 1;
}




//======================================================================================================
//                             Draw ALL ROIs Text
//======================================================================================================
int DrawAllROIsObjectNumber(struct Picture *picture, HDC hDC, int x0, int y0, float zoom)
{

    int i;
    short int xim, yim;
    char txt[256];
    HFONT hOldFont, hFont = CreateFont(15+(int)zoom,10+(int)zoom,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_OUTLINE_PRECIS,
                                       CLIP_DEFAULT_PRECIS, 0, VARIABLE_PITCH,TEXT("Times New Roman"));


    hOldFont=SelectObject(hDC, hFont);



    SetBkMode(hDC, OPAQUE);
    SetBkColor(hDC, RGB(255,255,255));
    for (i=1; i<=gNumberOfROIs; i++)
    {
        if (!(ROIs[i].removed) && ((*picture).slice==ROIs[i].slice || ROIs[i].type==LIMIT))
        {
            if (ROIs[i].type==AUTO || ROIs[i].type==SQUARE || ROIs[i].type==CLOSED)
            {
                SetTextColor(hDC,Colour(ROIs[i].object));

                sprintf(txt,"%d",ROIs[i].object);
                ImageToPicture(picture, &xim, &yim, ROIs[i].roi[0].x, ROIs[i].roi[0].y, (*picture).slice);
                TextOut(hDC,x0+(xim+1)*zoom, y0+(yim+1)*zoom,txt,strlen(txt));
            }
        }
    }

    SelectObject(hDC, hOldFont);
    DeleteObject(hFont);
    return 1;
}




//======================================================================================================
//                    Find the ROI that has the closest
//                    seed point to {x,y,slice}
//                    return the roi number, or 0 if not found
//======================================================================================================
int GetNearestROI(int x, int y, int slice)
{

    int i, closest=0;
    int dx,dy;
    int dist2;
    int mindist2=INT_MAX;

    for (i=1; i<=gNumberOfROIs; i++)
    {
        if (!(ROIs[i].removed) && slice==ROIs[i].slice)
        {
            if ((ROIs[i].type==AUTO) || (ROIs[i].type==SQUARE) || (ROIs[i].type==ELLIPSE)|| (ROIs[i].type==CLOSED))
            {
                dx=x-ROIs[i].Xseed;
                dy=y-ROIs[i].Yseed;
                dist2=dx*dx + dy*dy;
                if (dist2<mindist2)
                {
                    closest=i;
                    mindist2=dist2;
                }
            }
        }
    }
    return closest;
}













//======================================================================================================
//                               Draw ROI on device
//                               can be used for any device context
//                               col tells us the colour
//======================================================================================================
int DrawROI(struct Picture *picture, HDC hDC, struct ROIedge ROI[], int length, COLORREF col, int width)
{

    int i;
    short int x1,y1,x2,y2;

    for (i=0; i<length-1; i++)
    {

        ImageToPicture(picture, &x1, &y1, ROI[i].x, ROI[i].y, (*picture).slice);
        ImageToPicture(picture, &x2, &y2, ROI[i+1].x, ROI[i+1].y, (*picture).slice);

        DrawLine(hDC, x1, y1, x2, y2, col, width);
    }


    return 1;
}












//======================================================================================================
//                               define 10 colours
//                               given n>0 return one of the colours
//======================================================================================================
COLORREF Colour(int n)
{
    int col=n-10*(n/10);

    if (col<=0) return RGB(200,0,0);
    if (col==1) return RGB(0,255,0);
    if (col==2) return RGB(0,0,255);
    if (col==3) return RGB(155,100,0);
    if (col==4) return RGB(100,155,0);
    if (col==5) return RGB(100,0,155);
    if (col==6) return RGB(255,100,100);
    if (col==7) return RGB(100,255,100);
    if (col==8) return RGB(100,100,255);
    else return RGB(255,0,255);
}






//======================================================================================================
//                             Save the ROIs to disk
//                             X, Y, Z are the image dimensions
//======================================================================================================
int SaveROIs(int BackUp, int X, int Y, int Z)
{

    FILE *fp;
    int i,j;
    char ROI_File[MAX_PATH];
    OPENFILENAME fnameROI;
    BOOL GSF=0;

    if (!BackUp)
    {
        memset(&fnameROI,0,sizeof(OPENFILENAME));
        ROI_File[0]='\0';

        fnameROI.lStructSize=sizeof(OPENFILENAME);
        fnameROI.hwndOwner=NULL;
        fnameROI.lpstrFilter="ROI Files\0*.ROI\0\0";
        fnameROI.lpstrCustomFilter=NULL;
        fnameROI.nFilterIndex=1;
        fnameROI.lpstrFile=ROI_File;
        fnameROI.nMaxFile=MAX_PATH;
        fnameROI.lpstrFileTitle=NULL;
        fnameROI.lpstrInitialDir="./";
        fnameROI.lpstrTitle="Select ROI File name";
        fnameROI.lpstrDefExt="ROI";

        GSF=GetSaveFileName(&fnameROI);
    }
    else sprintf(ROI_File,"./ROI_backup.roi");


    if ( GSF || BackUp )
    {

        if ( (fp=fopen(ROI_File,"w")) )
        {
            fprintf(fp,"%d %d\n",X, Y);
            for (i=1; i<=gNumberOfROIs; i++)
            {
                if (!ROIs[i].removed)
                {

                    fprintf(fp,"%d %d %d %d %d %d %d\n",ROIs[i].length,ROIs[i].Xseed,ROIs[i].Yseed,ROIs[i].slice,
                            ROIs[i].type,ROIs[i].object,ROIs[i].removed);
                    for (j=0; j<ROIs[i].length; j++)	fprintf(fp,"%d %d\n",ROIs[i].roi[j].x,ROIs[i].roi[j].y);

                }
            }
            fclose(fp);
        }
        else MessageBox(NULL,"Failed to save ROIs","",MB_OK|MB_ICONWARNING);
    }

    return 1;
}








//==================================================================================
//                        Load ROIs from disk
//                        The current image has dimensions X, Y, Z
//                        The saved ROIs must have been defined on an
//                        image of these dimensions
//File format:
//  X and Y dimensions of image
//  length xseed yseed slice Type object removed
//  x0 y0
//  x1 y1
//  .  .
//  xlength-1 ylength-1
//  REPEAT (without the X and Y)
//
//xlength-1=x0 and ylength-1=y0
//If xlength-1!=x0 OR ylength-1!=y0 then this might be the old NeuRoi1 format
//To fix this load one more line and increment length
//ALSO the removed indicator is the binary complement of that used in NeuRoi1
//==================================================================================
int LoadROIs(int X, int Y, int Z)
{

    char ROI_File[MAX_PATH];
    OPENFILENAME fnameROI;
    FILE *fp;
    int j,count=0;
    int xpix,ypix;
    int x,y;
    int roi;
    int length, xseed, yseed, slice, Type, object, removed;

    memset(&fnameROI,0,sizeof(OPENFILENAME));

    ROI_File[0]='\0';

    fnameROI.lStructSize=sizeof(OPENFILENAME);
    fnameROI.hwndOwner=NULL;
    fnameROI.lpstrFilter="ROI Files\0*.ROI\0\0";
    fnameROI.lpstrCustomFilter=NULL;
    fnameROI.nFilterIndex=1;
    fnameROI.lpstrFile=ROI_File;
    fnameROI.nMaxFile=MAX_PATH;
    fnameROI.lpstrFileTitle=NULL;
    fnameROI.lpstrInitialDir=NULL;
    fnameROI.lpstrTitle="Select ROI File name";
    fnameROI.lpstrDefExt="ROI";


    if ( !GetOpenFileName(&fnameROI) )	return 0;


    if ( (fp=fopen(ROI_File,"r")) )
    {

        //free the ROIs
        for (roi=1; roi<=gNumberOfROIs; roi++)
        {
            if (ROIs[roi].roi) free(ROIs[roi].roi);
            memset(&ROIs[roi],0,sizeof(struct ROI));
        }

        fscanf(fp,"%d %d",&xpix, &ypix);

        if (xpix==X && ypix==Y)
        {
            count=1;
            gNumberOfObjects=0;
            do
            {
                fscanf(fp,"%d %d %d %d %d %d %d",&length,&xseed,&yseed,&slice,&Type,&object,&removed);
                ROIs[count].length=length;
                ROIs[count].Xseed=xseed;
                ROIs[count].Yseed=yseed;
                ROIs[count].slice=slice;
                ROIs[count].object=object;
                ROIs[count].removed=removed;
                ROIs[count].type=Type;

                if (ROIs[count].object>gNumberOfObjects) gNumberOfObjects=ROIs[count].object;
                if (!feof(fp))
                {
                    ROIs[count].roi=(struct ROIedge *)malloc( (ROIs[count].length+1)*sizeof(struct ROIedge) );
                    for (j=0; j<ROIs[count].length && !feof(fp); j++)
                    {
                        fscanf(fp,"%d %d",&x, &y);
                        ROIs[count].roi[j].x=x;
                        ROIs[count].roi[j].y=y;
                    }
                    CheckAndRepairROI(&ROIs[count]);
                    count++;
                }
            }
            while(count<MAX_ROIS && !feof(fp));
            fclose(fp);
            gNumberOfROIs=count-1;
        }
        else MessageBox(NULL,"You cannot load this ROI file because the image dimensions are not compatible","",MB_OK);

    }
    else return 0;


    return 1;
}



//==================================================================================
//          Check the ROIs
//          Closed, Square, and Auto must be closed so that there last poit=first point
//          Steps should also be to neighbours
//==================================================================================
int CheckAndRepairROI(struct ROI *ROI)
{

    int NewLength;
    int i, length;
    int changed=0;
    struct ROIedge Edge[MAX_ROI_LENGTH];
    struct ROIedge Edge1[MAX_ROI_LENGTH];

    //PLACE THE ROI EDGE INTO TEMPORARY Edge
    memcpy(Edge, (*ROI).roi, sizeof(struct ROIedge)*(*ROI).length);
    NewLength=(*ROI).length;

    //THE ROIS SHOULD BE CLOSED
    if ( ((*ROI).type==SQUARE) || ((*ROI).type==CLOSED) || ((*ROI).type==AUTO) )
    {
        if ( (Edge[0].x != Edge[NewLength-1].x) ||
                (Edge[0].y != Edge[NewLength-1].y) )
        {

            Edge[NewLength].x=Edge[0].x;
            Edge[NewLength].y=Edge[0].y;
            NewLength++;
            changed=1;//the roi has been changed
        }
    }


    //THEY SHOULD BE CONTINUOUS, SO THAT SUBSEQUENT POINTS ARE NEIGHBOURS
    length=0;
    for (i=0; i<NewLength-1; i++)
    {
        length=GetStraightLine(Edge[i].x, Edge[i].y, Edge[i+1].x, Edge[i+1].y, &Edge1[length], length);
    }
    length++;//the length initially points to the final element in the list, so increment by 1

    if (length != NewLength)
    {
        memcpy(Edge, Edge1, sizeof(struct ROIedge)*length);
        NewLength=length;
        changed=2;
    }




    //IF THE ROI HAS BEEN CHANGED THEN SAVE THE CHANGES
    if (changed)
    {
        if ( (*ROI).roi ) free((*ROI).roi);
        if ( ((*ROI).roi=(struct ROIedge *)malloc(sizeof(struct ROIedge)*NewLength)) )
        {
            memcpy((*ROI).roi, Edge, sizeof(struct ROIedge)*NewLength);
            (*ROI).length=NewLength;
        }
        else
        {
            (*ROI).length=0;
            (*ROI).removed=1;
        }
    }


    return changed;
}




//==================================================================================
//               check if the ROI has been repeated previously
//               if it has return 1
//               else return 0
//==================================================================================
int IsROIrepeated(int X, int Y, struct ROIedge ROI[], int slice, int XSEED, int YSEED, int length)
{

    int roi,l;
    int x,y;
    int match=0;
    unsigned char *mask1=NULL, *mask2=NULL;


    mask1=(unsigned char *)malloc(sizeof(unsigned char)*X*Y);
    mask2=(unsigned char *)malloc(sizeof(unsigned char)*X*Y);

    if (mask1 && mask2)
    {

        memset(mask1,0,sizeof(BYTE)*X*Y);
        for (l=0; l<length; l++)
        {
            if ((ROI[l].x>=0) && (ROI[l].x<X) && (ROI[l].y>=0) && (ROI[l].y<Y))   mask1[ROI[l].x+ROI[l].y*X]=EDGE;
        }


        for (roi=1; (roi<=gNumberOfROIs) && (!match); roi++)
        {
            match=roi;
            if ((ROIs[roi].slice==slice) && (!ROIs[roi].removed) && (length==ROIs[roi].length))
            {

                memset(mask2,0,sizeof(BYTE)*X*Y);
                for (l=0; l<ROIs[roi].length; l++)
                {
                    if ((ROIs[roi].roi[l].x>=0) && (ROIs[roi].roi[l].x<X) && (ROIs[roi].roi[l].y>=0) && (ROIs[roi].roi[l].y<Y))
                        mask2[ROIs[roi].roi[l].x+ROIs[roi].roi[l].y*X]=EDGE;
                }

                for (y=0; y<Y && match; y++)
                {
                    for (x=0; x<X && match; x++)
                    {
                        if (mask1[x+y*X]!=mask2[x+y*X]) match=0;
                    }
                }

            }
            else match=0;
        }

    }

    if (mask1) free(mask1);
    if (mask2) free(mask2);
    return match;
}




//==================================================================================
//                        Convert to ROI
//                        any set of points, that dont have to be neighbours,
//                        converted to larger set of points, where adjacent points
//                        in the list are neighbours
//==================================================================================
int ConvertToROI(struct ROIedge init[], int initlength, struct ROIedge final[])
{

    int length=0;
    int i;

    for (i=0; i<initlength-1; i++)
    {
        length=GetStraightLine(init[i].x, init[i].y, init[i+1].x, init[i+1].y, &final[length], length);
    }
    length++;//the length initially points to the final element in the list, so increment by 1


    return length;
}





//==================================================================================
//                Save ROI centroids and characteristic sizes
//==================================================================================
int SaveROIcentroidsAndCharaceristicSizes(struct Image *image)
{

    struct ThreeVector centroids[MAX_ROIS];
    float sizes[MAX_ROIS];
    float X0, Y0, Z0;
    int result=0;
    int X,Y,Z;
    int x,y,z, voxel;
    int obj;
    unsigned char *mask=NULL;
    char filename[MAX_PATH];
    FILE *fp;
    OPENFILENAME fnamedlg;

    filename[0]='\0';
    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="text Files\0*.txt;\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=filename;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir="./";
    fnamedlg.lpstrTitle="Select Output file";
    fnamedlg.lpstrDefExt="txt";

    if(!GetSaveFileName(&fnamedlg)) goto END;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;

    X0=X*(*image).dx/2.0;
    Y0=Y*(*image).dy/2.0;
    Z0=Z*(*image).dz/2.0;

    if (!(mask=(unsigned char *)malloc(X*Y*Z))) goto END;
    memset(centroids,0,sizeof(struct ThreeVector)*MAX_ROIS);
    memset(sizes,0,sizeof(float)*MAX_ROIS);


    if ( (fp=fopen(filename, "w")) )
    {
        fprintf(fp,"%d\n",gNumberOfObjects);
        for (obj=1; obj<=gNumberOfObjects; obj++)
        {
            if (GetBinaryROImask(mask, X, Y, Z, obj, 0))
            {
                for (z=0; z<Z; z++)
                {
                    for (y=0; y<Y; y++)
                    {
                        for (x=0; x<X; x++)
                        {
                            voxel=x+y*X+z*X*Y;
                            if (mask[voxel])
                            {
                                //coordinates relative to {X0, Y0, Z0}
                                centroids[obj].x+=(*image).dx*x-X0;
                                centroids[obj].y+=(*image).dy*y-Y0;
                                centroids[obj].z+=(*image).dz*z-Z0;

                                sizes[obj]+=1.0;//just number of voxels at this stage
                            }
                        }
                    }
                }
                if (sizes[obj]>0.0)
                {
                    centroids[obj].x/=sizes[obj];
                    centroids[obj].y/=sizes[obj];
                    centroids[obj].z/=sizes[obj];
                    //convert the sizes into characteristic sizes
                    sizes[obj]*=( (*image).dx * (*image).dy * (*image).dz );
                    sizes[obj]=(0.75/PI)*pow(sizes[obj], 1.0/3.0);
                }

                fprintf(fp,"%f %f %f %f\n",centroids[obj].x,centroids[obj].y,centroids[obj].z,sizes[obj]);
            }
        }


        fclose (fp);
    }

    result=1;
END:
    if (mask) free(mask);

    return result;
}











//==================================================================================
//                        given start and end points, find
//                        the straight line of points between them
//==================================================================================
int GetStraightLine(int x0, int y0, int x1, int y1, struct ROIedge roi[], int initlength)
{

    int length=0;
    double max;
    double dx,dy;
    double x,y;


    dx=(double)(x1-x0);
    dy=(double)(y1-y0);
    max=(fabs(dx)>fabs(dy)) ? fabs(dx):fabs(dy);


    roi[0].x=(int)(x0);
    roi[0].y=(int)(y0);

    if ((abs(x0-x1) + abs(y0-y1))==1)                               //if {x0,y0} neighbours {x1,y1}
    {
        roi[1].x=x1;
        roi[1].y=y1;
        return initlength+1;
    }

    if (max)
    {
        dx/=(10*max);
        dy/=(10*max);

        x=(double)x0;
        y=(double)y0;
        roi[0].x=x0;
        roi[0].y=y0;
        do
        {
            while((roi[length].x==(int)(x+0.5)) && (roi[length].y==(int)(y+0.5)))
            {
                if ((int)(x+0.5)!=x1) x+=dx;
                if ((int)(y+0.5)!=y1) y+=dy;
            }


            length++;
            roi[length].x=(int)(x+0.5);
            roi[length].y=(int)(y+0.5);
        }
        while ((roi[length].x!=x1) || (roi[length].y!=y1));
    }

    return initlength+length;
}




//==================================================================================
//                            free ROI memory
//==================================================================================
int FreeROIMemory(void)
{

    int i;

    for (i=1; i<=gNumberOfROIs; i++)
    {
        if (ROIs[i].roi)
        {
            free(ROIs[i].roi);
            ROIs[i].roi=NULL;
        }
    }
    gNumberOfROIs=0;
    gNumberOfObjects=0;

    return 1;
}
