/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Display_H)
//Do Nothing
#else

#define Display_H
//--------------------------------------------------------------------------------------------
//                              routines for displaying images
//                              19th Feb 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "loader.h"
//more includes at bottom





#define GREY_SCALE 0
#define RGB_COLOUR 1                           //what type of bitmaps are supported
#define COLOUR_MAP 2


#define MAX_INTENSITY 200                      //defines the maximum intensity for the grey scale display
#define RED   (MAX_INTENSITY+1)                //pixels with this value should be red
#define GREEN (MAX_INTENSITY+2)                //pixels with this value should be greeen
#define BLUE  (MAX_INTENSITY+3)                //pixels with this value should be blue

#define X_SCREEN_SIZE 800                     //default X Screen size
#define Y_SCREEN_SIZE 800                     //default Y Screen size

#define PLANE_1 0
#define PLANE_2 1
#define PLANE_3 2

#define SAVE_BITMAP_AS 1
#define SAVE_BITMAP 2

//bitmap structure with colour table
struct BITMAPINFO256{
	BITMAPINFOHEADER bmiHdr;
	RGBQUAD	bmicolours[256];
};


struct Picture{                                          //structure containing the picture to be displayed
       unsigned char *pict;                              //to cope with colour images, this may be a single byte per pixel, or 3 bytes per pixel depending on the bitmap type
       short int width;                                  //dimensions of the picture; x must be a multiple of 4
       short int height;
       short int x;
       short int y;                                      //the orthogonal slices to display
       short int slice;
       short int X;
       short int Y;                                      //the original image dimensions
       short int Z;
       short int volumes;
       short int FocalPlane;
       struct MatrixLimits ML;                           //limit the matrix
       int PictureBytes;
       int xpos;                                         //the screen origin
       int ypos;
       int CrossHairSize;
       char Highlight;                                   //highlight a range of intensities
       char LocalZoom;                                   //zoom the image locally
       char NeedsRedraw;                                 //true if the picture needs to be redrawn, otherwise false
       float HighlightLo;
       float HighlightHi;
       float saturation;                                 //change the intensity on screen
       float LowThresh;
       float zoom;                                       //zoom the picture (fraction of normal size)
       BITMAPINFOHEADER bmphdr;
};






#include "imageprocess.h"





struct Picture gMainPict;                      //this is the main picture to be displayed, there can be others
int CurrentSlice;                              //this is the current slice to work with


BITMAPINFOHEADER DefineBitmap(int Width, int Height);
int DrawBitmapEx(HDC hDC, HWND hwnd, struct Picture *picture, HWND hStatusBar, int Save);
int FillPictureStruct(HWND hwnd, struct Picture *picture, struct Image *image);
int PictureToImage(struct Picture *picture, short int picx, short int picy,
                    short int *x, short int *y, short int *z,int Orthogonal);
int ImageToPicture(struct Picture *picture, short int *picx, short int *picy, short int x, short int y, short int z);

RECT GetImageRect(HWND hwndMain, HWND hStatusBar, HWND hTool);
int SaveBitmap(struct Picture *pict, HWND hwndMain, HDC hDC, int GetName, char directory[]);

int DrawLine(HDC hDC, int xstart, int ystart, int xend, int yend, COLORREF col, int width);
int DrawRectangle(HDC hDC, int left, int top, int right, int bottom, COLORREF col);
RGBQUAD PictureIntensity(HWND hwnd, int voxel, struct Picture *picture, struct Image *image, int ColBckgrnd, int ShowOverlays);
RGBQUAD Colours(int index, int n);
int RemoveInput(HWND hwnd);
int SaveRGBbitmapAs8bit(BITMAPFILEHEADER *BmFileHdr, BITMAPINFOHEADER *BmInfoHdr, unsigned char  *pBits, int pixels, int width, int height, FILE *fp);
#endif


