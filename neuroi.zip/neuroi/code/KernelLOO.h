/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(CVCA_H)
//Do Nothing
#else
#define CVCA_H



#include "global.h"
#include "CBMAfiles.h"
#include "CoordinateProcess.h"
#include "numerical.h"
#include "CBMAN.h"
#include "MeanShiftCoordinatesLOO.h"


#define KERNEL_TYPE BETA_KERNEL
//#define KERNEL_TYPE COSINE_KERNEL
//#define KERNEL_TYPE SPHERE_KERNEL
//#define KERNEL_TYPE QUADRATIC_KERNEL



struct KernelMinimise {
    double width;
    double *dist2;
    struct Coordinates *C;
    FILE *fp;
    int Neighbours;
    int ConcordantCount;//number of concordant foci, used to determine number of neighbours needed for concordance
};

INT_PTR CALLBACK CVCA_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


HWND hKernelLoo;
int SaveReportedStructuresCVCAfilename(struct Coordinates *C, char fname[], short int *concordant);
double MaxKernelLOOscore(struct Coordinates *C, struct KernelMinimise *KM);
int DensityImage(struct Image *image, struct Coordinates *C, short int valid[], double width);
int CompareCoordinatesUsingLOO(HWND hwnd, struct Image *image, struct Coordinates *CA, struct Coordinates *CB, int NumberOfRandomisations);
double CVCAcompare(HWND hwnd, struct Image *image, struct Coordinates *CA, struct Coordinates *CB, char directory[], int save);
int ConcordantCoordinates(int Nfoci, int Nstudies, double dist2[], short int study[], double width, short int concordant[], int Neighbours, int LeaveOut);
#endif

