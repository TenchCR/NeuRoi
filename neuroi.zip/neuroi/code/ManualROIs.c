/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "manualROIs.h"
#include "menuresources.h"
#include "loader.h"
#include "ROIs.h"
#include "global.h"

#define SCROLL_MAX 1000
#define SCROLL_MIN 1

struct ROIedge ROI[MAX_ROI_LENGTH];
int gLength;                           //length of the currently defined ROI
int gSlice;                            //slice of the currently defined ROI

int HandleMouseInputManualROI(HWND hwndManual, UINT msg, WPARAM wParam, LPARAM lParam, int slice, int mode, struct ROIedge ROI[],
                              int *length, int X, int Y, int x0, int y0, float zoom);

int CreateEllipseROI(struct ROIedge *roi);
//=============================================================================================
//                           Auto ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK ManualROIsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static char current_selection[256]="new";
    static int Mode;                             //mode selected ID_ROI_SEED, ID_ROI_LIMIT
    int i, object;
    int roitype;
    struct ROIedge ROI1[MAX_ROI_LENGTH];
    char txt[256];


    switch(msg)
    {


    case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        EndDialog(hwnd,0);
        hManualROI=(HWND)NULL;
        break;





    case WM_SHOWWINDOW:
        //SET UP THE ROI OBJECT NUMBER SELECTION BOX
        if ( SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_FINDSTRING,-1,(LPARAM)current_selection)==CB_ERR)
        {
            sprintf(current_selection,"new");
        }
        SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_RESETCONTENT,0,0);
        SendDlgItemMessage(hwnd,ID_SELECT_OBJECT,CB_ADDSTRING,(WPARAM)0,(LPARAM)"new");
        for (i=1; i<=gNumberOfObjects; i++)
        {
            sprintf(txt,"%d",i);
            SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)txt);
        }
        SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_SELECTSTRING ,-1,(LPARAM)current_selection);
        SendMessage(GetDlgItem(hwnd,Mode),BM_SETCHECK,BST_CHECKED,0);
        break;





    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        /*if (!IsImageScalar(gImage.DataType)){
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
            SendMessage(hwnd, WM_CLOSE,0,0);
        }*/
        memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
        Mode=ID_ROI_SQUARE;
        break;



    case WM_MOUSEMOVE:                                                          //mouse input
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONDOWN:
    case WM_MBUTTONDOWN:
        HandleMouseInputManualROI(hwnd, msg, wParam, lParam, gMainPict.slice, Mode, ROI, &gLength, gMainPict.X, gMainPict.Y,
                                  gMainPict.xpos, gMainPict.ypos, gMainPict.zoom);
        break;




    case WM_COMMAND:
        switch (LOWORD(wParam))
        {



        case ID_ACCEPT_ROI:
            roitype=NOROI;
            if ((Mode==ID_ROI_SQUARE) || (Mode==ID_ROI_ELLIPSE) || (Mode==ID_ROI_CLOSED) || (Mode==ID_ROI_POLY))
            {
                switch (Mode)
                {
                case ID_ROI_SQUARE:
                    roitype=SQUARE;
                    break;
                case ID_ROI_ELLIPSE:
                    roitype=ELLIPSE;
                    break;
                case ID_ROI_CLOSED:
                case ID_ROI_POLY:
                    roitype=CLOSED;
                    break;
                }

                i=SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_GETCURSEL,0,0);
                SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_GETLBTEXT,i,(LPARAM)current_selection);
                if (strstr("new",current_selection))
                {
                    gNumberOfObjects++;
                    object=gNumberOfObjects;
                    sprintf(current_selection,"%d",object);
                    SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)current_selection);
                }
                else object=atoi(current_selection);
            }
            if (gLength && (roitype!=NOROI))
            {
                if (roitype==ELLIPSE) gLength=CreateEllipseROI(ROI);

                memcpy(ROI1, ROI, gLength*sizeof(struct ROIedge));
                gLength=ConvertToROI(ROI1, gLength, ROI);                     //convert to roi line
                gNumberOfROIs=AcceptROI(gImage.X, gImage.Y, ROI, gLength, gMainPict.x, gMainPict.y, gMainPict.slice,
                                        gNumberOfROIs, object, roitype);

                //sprintf(txt,"%d %d %d %d",ROI[0].x,ROI[gLength-1].x,ROI[0].y,ROI[gLength-1].y);
                //MessageBox(NULL,txt,"",MB_OK);

                gLength=0;
                memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
                SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
                SaveROIs(1, gMainPict.X, gMainPict.Y, gMainPict.Z);
            }
            break;


        case VK_ESCAPE:
            gLength=0;
            memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;
        case VK_DELETE:
            if (Mode!=ID_ROI_POLY) break;
            if (gLength<=3)
            {
                gLength=0;
                memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
                SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
                break;
            }
            ROI[gLength-2].x=ROI[gLength-1].x;
            ROI[gLength-2].y=ROI[gLength-1].y;
            ROI[gLength-1].x=ROI[gLength].x;
            ROI[gLength-1].y=ROI[gLength].y;
            gLength--;
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;



        case ID_ROI_SQUARE:
        case ID_ROI_ELLIPSE:
        case ID_ROI_CLOSED:
        case ID_ROI_POLY:
        case ID_ROI_DELETE:
        case ID_ROI_RENUMBER:
            gLength=0;
            memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
            Mode=(int)LOWORD(wParam);
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;


        case ID_GOTO_AUTO:
            SendMessage(hwnd, WM_CLOSE,0,0);
            SendMessage(GetParent(hwnd),WM_COMMAND, IDM_AUTO_ROIS, 0);
            break;



        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;
    }
    return 0;
}




/*
//=============================================================================================
//                           Show the current ROI
//                           Also show dimensions for SQUARE ROIs
//                           Use the global variables ROI & gLength
//=============================================================================================
int DrawCurrentManualROI_old(struct Picture *picture, HDC hDC){

    short int xim, yim;
    int delx,dely;
    char txt[256];
    TEXTMETRIC tm;
    if (!gLength || (*picture).slice!=gSlice) return 0;

   	GetTextMetrics(hDC,&tm);

    ImageToPicture(picture, &xim, &yim, ROI[0].x, ROI[0].y, (*picture).slice);

    delx=abs(ROI[0].x-ROI[1].x)-1;
    if (delx<0) delx=0;
    dely=abs(ROI[0].y-ROI[2].y)-1;
    if (dely<0) dely=0;
    sprintf(txt,"%dx%d",delx,dely);
    if (SendMessage(GetDlgItem(hManualROI,ID_ROI_SQUARE),BM_GETCHECK,0,0)==BST_CHECKED)
            TextOut(hDC, xim, yim-tm.tmHeight, txt,strlen(txt));
    DrawROI(picture, hDC, ROI, gLength, Colour(0), 1);

    return 1;
}*/
//=============================================================================================
//                          GENERATE POINTS ON AN ELLIPSE
//=============================================================================================
int CreateEllipseROI(struct ROIedge *roi)
{
    double a,b;
    double x0,y0;
    int N=36;
    int i;

    a=fabs(roi[1].x - roi[0].x)/2.0;
    b=fabs(roi[2].y - roi[1].y)/2.0;

    x0=fabs(roi[1].x + roi[0].x)/2.0;
    y0=fabs(roi[2].y + roi[1].y)/2.0;

    for (i=0;i<N;i++)
    {
        roi[i].x=x0 + a*sin(i*360/N * 3.1415926/180.0);
        roi[i].y=y0 + b*cos(i*360/N * 3.1415926/180.0);
    }
    roi[N].x=roi[0].x;
    roi[N].y=roi[0].y;


    return N+1;
}

//=============================================================================================
//                           Show the current ROI
//                           Also show dimensions for SQUARE ROIs
//                           Use the global variables ROI & gLength
//=============================================================================================
int DrawCurrentManualROI(struct Picture *picture, HDC hDC)
{

    int x0=(*picture).xpos, y0=(*picture).ypos;
    int i;
    int width=((int)(*picture).zoom>=1) ? (int)(*picture).zoom:1;
    short int x1,y1,x2,y2;
    int delx,dely;
    char txt[256];
    float dx,dy;
    HFONT hOldFont, hFont = CreateFont(15+(int)(*picture).zoom,10+(int)(*picture).zoom,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                                       OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, 0, VARIABLE_PITCH,TEXT("Times New Roman"));

    hOldFont=SelectObject(hDC, hFont);

    SetBkMode(hDC, OPAQUE);
    SetBkColor(hDC, RGB(255,255,255));
    SetTextColor(hDC, RGB(0,0,0));

    if (!gLength || (*picture).slice!=gSlice) return 0;




    if ((SendMessage(GetDlgItem(hManualROI,ID_ROI_SQUARE),BM_GETCHECK,0,0)==BST_CHECKED) || (SendMessage(GetDlgItem(hManualROI,ID_ROI_ELLIPSE),BM_GETCHECK,0,0)==BST_CHECKED))
    {
        delx=abs(ROI[0].x-ROI[1].x)-1;
        if (delx<0) delx=0;
        dely=abs(ROI[0].y-ROI[2].y)-1;
        if (dely<0) dely=0;
        sprintf(txt," %dx%d ",delx,dely);
        //ImageToPicture(picture, &x1, &y1, ROI[0].x, ROI[0].y, (*picture).slice);
        ImageToPicture(picture, &x1, &y1, 10, 0, (*picture).slice);
        TextOut(hDC,x0+x1*(*picture).zoom, y0+(y1)*(*picture).zoom-(15+(int)(*picture).zoom),txt,strlen(txt));
    }

    if ((gLength>2) && (SendMessage(GetDlgItem(hManualROI,ID_ROI_POLY),BM_GETCHECK,0,0)==BST_CHECKED))
    {
        delx=abs(ROI[gLength-3].x-ROI[gLength-2].x)-1;
        if (delx<0) delx=0;
        dely=abs(ROI[gLength-3].y-ROI[gLength-2].y)-1;
        if (dely<0) dely=0;
        dx=gImage.dx;
        dy=gImage.dy;
        sprintf(txt," %5.1f(mm) ",sqrt(delx*delx*dx*dx + dely*dely*dy*dy));
        //ImageToPicture(picture, &x1, &y1, ROI[gLength-3].x, ROI[gLength-3].y, (*picture).slice);
        ImageToPicture(picture, &x1, &y1, 10, 0, (*picture).slice);
        TextOut(hDC,x0+x1*(*picture).zoom, y0+(y1)*(*picture).zoom-(15+(int)(*picture).zoom),txt,strlen(txt));
    }




    for (i=0; i<gLength-1; i++)
    {
        ImageToPicture(picture, &x1, &y1, ROI[i].x, ROI[i].y, (*picture).slice);
        ImageToPicture(picture, &x2, &y2, ROI[i+1].x, ROI[i+1].y, (*picture).slice);
        DrawLine(hDC, x0+x1*(*picture).zoom+width/2, y0+y1*(*picture).zoom+width/2, x0+x2*(*picture).zoom+width/2, y0+y2*(*picture).zoom+width/2, RGB(255,0,0), width);
    }

    if (SendMessage(GetDlgItem(hManualROI,ID_ROI_ELLIPSE),BM_GETCHECK,0,0)==BST_CHECKED)
    {
        ImageToPicture(picture, &x1, &y1, ROI[0].x, ROI[0].y, (*picture).slice);
        ImageToPicture(picture, &x2, &y2, ROI[2].x, ROI[2].y, (*picture).slice);
        Ellipse(hDC,x0 + x1*(*picture).zoom+width/2,y0 + y1*(*picture).zoom+width/2,x0 + x2*(*picture).zoom+width/2,y0 + y2*(*picture).zoom+width/2);
    }



    SelectObject(hDC, hOldFont);
    DeleteObject(hFont);

    return 1;
}





//=============================================================================================
//                        Handle all the mous inputs for ManualROI
//Mode will be one of the Manual ROI dialog box modes (square or closed ROI, delete, or renumber)
//x0 and y0 are the scroll offsets; the user scroll the image around
//=============================================================================================
int HandleMouseInputManualROI(HWND hwndManual, UINT msg, WPARAM wParam, LPARAM lParam, int slice, int mode, struct ROIedge roi[],
                              int *length, int X, int Y, int x0, int y0, float zoom)
{

    int i;
    short int xim, yim, zim;
    int sellected=0;
    static int current;
    static int pendown;
    char txt[256];

    if (!zoom) return 0;


    PictureToImage(&gMainPict, (int)LOWORD(lParam)-x0, (int)HIWORD(lParam)-y0, &xim, &yim, &zim,
                   IsMenuItemChecked(GetParent(hwndManual), IDM_VIEW_PLANES));
    if (xim<0) xim=0;
    if (yim<0) yim=0;
    if (xim>=X) xim=X-1;
    if (yim>=Y) yim=Y-1;

    switch (msg)
    {

    case WM_LBUTTONUP:
        pendown=0;
        if (mode==ID_ROI_CLOSED)
        {
            roi[(*length)].x=roi[0].x;
            roi[(*length)].y=roi[0].y;
            (*length)++;
            SendMessage(GetParent(hwndManual), WM_COMMAND, ID_REFRESH,0);
        }

        break;




    case WM_LBUTTONDOWN:
        if ((mode==ID_ROI_POLY) && (xim>=0) && (yim>=0) && (xim<X) && (yim<Y))
        {
            if (!(*length))
            {
                roi[0].x=roi[1].x=roi[2].x=xim;
                roi[0].y=roi[1].y=roi[2].y=yim;
                (*length)=3;
            }
            else
            {
                roi[(*length)-2].x=roi[(*length)-1].x=xim;
                roi[(*length)-2].y=roi[(*length)-1].y=yim;
                roi[(*length)].x=roi[0].x;
                roi[(*length)].y=roi[0].y;
                (*length)++;
                /*sprintf(txt,"");
                for (i=0;i<(*length);i++)
                {
                    sprintf(txt,"%s %d %d\n",txt,roi[i].x,roi[i].y);
                }
                sprintf(txt,"%s %d\n",txt,(*length));
                MessageBox(NULL,txt,"",MB_OK);*/
            }
        }
        if (((mode==ID_ROI_CLOSED) || (mode==ID_ROI_SQUARE) || (mode==ID_ROI_ELLIPSE)) && xim>=0 && yim>=0 && xim<X && yim<Y)
        {
            roi[0].x=xim;
            roi[0].y=yim;
            (*length)=1;
            pendown=1;
        }
        if (mode==ID_ROI_DELETE && current)
        {
            ROIs[current].removed=1;
            current=0;
            (*length)=0;
        }
        if (mode==ID_ROI_RENUMBER && current)
        {
            i=SendMessage(GetDlgItem(hwndManual,ID_SELECT_OBJECT),CB_GETCURSEL,0,0);
            SendMessage(GetDlgItem(hwndManual,ID_SELECT_OBJECT),CB_GETLBTEXT,i,(LPARAM)txt);
            if (strstr("new",txt))
            {
                gNumberOfObjects++;
                ROIs[current].object=gNumberOfObjects;
                sprintf(txt,"%d",gNumberOfObjects);
                SendMessage(GetDlgItem(hwndManual,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)txt);
            }
            else ROIs[current].object=atoi(txt);
        }
        break;




    case WM_MOUSEMOVE:
        if ( (((mode==ID_ROI_CLOSED) || (mode==ID_ROI_SQUARE)  || (mode==ID_ROI_ELLIPSE))&&pendown) ||
                ((mode==ID_ROI_POLY)&&(*length) && (xim>=0) && (yim>=0) && (xim<X) && (yim<Y)) )
        {
            gSlice=slice;
            if ((xim!=roi[(*length)-1].x) || (yim!=roi[(*length)-1].y))
            {
                if (mode==ID_ROI_CLOSED)
                {
                    roi[(*length)].x=xim;
                    roi[(*length)].y=yim;
                    (*length)++;
                }
                else if ((mode==ID_ROI_SQUARE) || (mode==ID_ROI_ELLIPSE))
                {
                    roi[1].x=xim;
                    roi[1].y=roi[0].y;
                    roi[2].x=xim;
                    roi[2].y=yim;
                    roi[3].x=roi[0].x;
                    roi[3].y=yim;
                    roi[4].x=roi[0].x;
                    roi[4].y=roi[0].y;
                    (*length)=5;
                }
                else if (mode==ID_ROI_POLY)
                {
                    roi[(*length)-2].x=xim;
                    roi[(*length)-2].y=yim;
                }
                SendMessage(GetParent(hwndManual), WM_COMMAND, ID_REFRESH,0);
            }
        }
        sellected=GetNearestROI(xim, yim, slice);
        if (sellected>0 && sellected!=current && (mode==ID_ROI_DELETE || mode==ID_ROI_RENUMBER))
        {
            gSlice=slice;
            (*length)=ROIs[sellected].length;
            memcpy(roi, ROIs[sellected].roi, (*length)*sizeof(struct ROIedge));
            SendMessage(GetParent(hwndManual), WM_COMMAND, ID_REFRESH,0);
            current=sellected;
        }
        break;

    }


    return 1;
}









