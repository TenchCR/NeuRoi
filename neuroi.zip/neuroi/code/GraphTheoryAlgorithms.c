/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "graphtheoryalgorithms.h"
#include "generatedirections.h"
#include "imageprocess.h"


//====================================================================================
//==========================Binary heap code================================================
//===================sorts and adds and deletes elements to and from the heap==============================
//====================See http://en.wikipedia.org/wiki/Binary_heap for explaination=============================
//====================================================================================
int Parent(int i)
{
	//return i/2;
	return i>>1;
}
int LeftChild(int i)
{
	//return 2*i;
	return i<<1;
}
int RightChild(int i)
{
	//return 2*i+1;
	return (i<<1)+1;
}

//=========================================================================================================
//enter a voxel into the ordered heap
//Add the element to the bottom of the heap
//move up, replacing its parent untill it can go any higher
int NewHeapElement(float weights[], int heap[], int entered, int voxel, int node[], float NewWeight)
{

	int i;

	weights[voxel]=NewWeight;

	entered++;

	//put the element at the end of the heap
	heap[entered]=voxel;
	node[voxel]=entered;

	i=entered;
	while( i )
	{

		i=HeapBackShift(weights, heap, i, node);

	};

	return entered;
}
//=========================================================================================================
//Remove the top element of the heap (biggest wieght in the heap)
int RemoveRootElement(float weights[], int heap[], int entered, int node[])
{

	int i;

	node[heap[1]]=0;//node no longer in the heap
	node[heap[entered]]=1;//move the bottom in the heap to the top

	heap[1]=heap[entered];
	heap[entered]=0;
	entered--;

	i=1;
	while ( i && (LeftChild(i)<=entered) )
	{

		i=HeapForwardShift(weights, heap, i, node);

	}

	return entered;
}
//=========================================================================================================
//shift element current of the heap towards the root
//Compare the weight of the current element with its parent
//If the weight is greater than the parent, then exchange with parent
int HeapBackShift(float weights[], int heap[], int current, int node[])
{

	int v,n;

	if (!Parent(current))
		return 0;

	if ( weights[heap[current]]>weights[heap[Parent(current)]])
	{
		n=node[heap[current]];
		node[heap[current]]=node[heap[Parent(current)]];
		node[heap[Parent(current)]]=n;

		v=heap[Parent(current)];
		heap[Parent(current)]=heap[current];
		heap[current]=v;


		return Parent(current);
	}
	else
		return 0;

}
//=========================================================================================================
//shift element i down the heap
//exchange with the child of i that has the greater weight
int HeapForwardShift(float weights[], int heap[], int i, int node[])
{

	int voxel;
	int n;

	if (weights[heap[LeftChild(i)]]>weights[heap[RightChild(i)]])
	{
		if (weights[heap[i]]<weights[heap[LeftChild(i)]])
		{
			n=node[heap[LeftChild(i)]];
			node[heap[LeftChild(i)]]=node[heap[i]];
			node[heap[i]]=n;

			voxel=heap[LeftChild(i)];
			heap[LeftChild(i)]=heap[i];
			heap[i]=voxel;
			return LeftChild(i);
		}
	}
	else
	{
		if (weights[heap[i]]<weights[heap[RightChild(i)]])
		{
			n=node[heap[RightChild(i)]];
			node[heap[RightChild(i)]]=node[heap[i]];
			node[heap[i]]=n;

			voxel=heap[RightChild(i)];
			heap[RightChild(i)]=heap[i];
			heap[i]=voxel;
			return RightChild(i);
		}
	}
	return 0;
}
//=========================================================================================================
//update the heap if one of the priorities has changed
int UpdateHeap(float weights[], int heap[], int entered, int voxel, float NewWeight, int node[])
{

	int i;

	i=node[voxel];

	//if the connectedness is higher than the parrent connectedness then update the heap
	weights[voxel]=NewWeight;
	if (weights[heap[i]]>weights[heap[Parent(i)]])
	{
		while( (i=HeapBackShift(weights, heap, i, node)) ) {};
	}

	return 1;
}


//=========================================================================================================
//=============================FUZZY CONNECTEDNESS ALGORITHM===============================================

#define NOCONNECTION 0.0
#define NEIGHBOURS 26













//=========================================================================================================
//conventional algorithm with binary heap sorted affinities
//given affinities compute fuzzy connectedness
//GetAffinity(void image[], int X, int Y, int Z,  int voxel, int i, int j, int k, float connectivity, void *P) with i,j,k being the voxel to connect to
//=========================================================================================================
int FuzzyConnectedness(float (*GetAffinity)(void *image, int, int, int, int, int, int, int, float, void *),
                       void *P,void *image, int Seed, float Connectedness[], int X, int Y, int Z,
                       HWND hwnd, float thresh, int iterations)
{

	int x,y,z, voxel, voxeln, voxels=X*Y*Z;
	int i,j,k,l;
	int *inout;
	int *heap;
	int entered;
	int xn[NEIGHBOURS], yn[NEIGHBOURS], zn[NEIGHBOURS];
	float affinity;
	char txt[1024];
	HDC hDC=GetDC(hwnd);
	int iter=0, count;

	inout=(int *)malloc(voxels*sizeof(int));
	heap=(int *)malloc(voxels*sizeof(int));


	if (inout && heap)
	{
		memset(inout,0,voxels*sizeof(int));
		memset(heap,0,voxels*sizeof(int));



		//---------------------------Get neighbours----------------------------
		l=0;
		for (k=-1; k<=1; k++)
		{
			for (j=-1; j<=1; j++)
			{
				for (i=-1; i<=1; i++)
				{
					if ((i||j||k) && l<NEIGHBOURS)
					{
						xn[l]=i;
						yn[l]=j;
						zn[l]=k;
						l++;
					}
				}
			}
		}
		//---------------------------------------------------------------------






		//----------------------initially there are no connections----------------------------
		entered=1;
		memset(Connectedness,0,sizeof(float)*voxels);
		heap[entered]=Seed;
		Connectedness[Seed]=1.0;//seeds are connected and in the Q
		inout[Seed]=entered;
		//------------------------------------------------------------------------------------------


		//--------------------------Fill the Q------------------------------------------------------
		iter=count=0;
		while( (Connectedness[heap[1]]>thresh) && (iter<iterations) && entered )
		{

			voxel=heap[1];																						//the current voxel, taken from the Q
			entered=RemoveRootElement(Connectedness, heap, entered, inout);	//take out of the Q


			for (l=0; l<NEIGHBOURS; l++)
			{



				XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);
				if (InImageRange(x+xn[l],y+yn[l],z+zn[l],X,Y,Z))
				{

					voxeln=voxel + xn[l] + yn[l]*X + zn[l]*X*Y;

					if (Connectedness[voxeln]<Connectedness[voxel]) //cant update a highly connected voxel from a low connected voxel
					{

						affinity=GetAffinity(image, X, Y, Z, voxel, xn[l], yn[l], zn[l], Connectedness[voxel], P);

						if (affinity>Connectedness[voxel])
							affinity=Connectedness[voxel];// cant connect stronger than current connectedness

						//----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
						if ((affinity>Connectedness[voxeln]) && (affinity>thresh))
						{
							count++;

							if (count>1000)
							{
								sprintf(txt,"%d %d %f %f       ", entered,voxel,Connectedness[voxel], affinity);
								TextOut(hDC,100,100,txt,strlen(txt));
								count=0;
							}

							if (!inout[voxeln])
							{
								entered=NewHeapElement(Connectedness, heap, entered, voxeln, inout, affinity);		//put into the Q if not already there
								iter++;
							}
							else
							{
								UpdateHeap(Connectedness, heap, entered, voxeln, affinity, inout);					//if already in the Q, update connectedness
							}
						}
						//-----------------------------------------------------------------------------------

					}//connectedned in neighbour < connectedness in current voxel

				}//in image range

			}//l {0<=l<26}

		}
		//-------------------------------------------------------------------------------------------


	}

	if (inout)
		free(inout);
	if (heap)
		free(heap);

	ReleaseDC(hwnd, hDC);

	return iter;
}






//=========================================================================================================
//          Only propagate forwards by keeping track of the previous neighbour
int FuzzyConnectednessWithMemory5x5x5(float (*GetAffinity)(void *image, int, int, int, int, int, int, int, float, float *), void *P,
                                      void *image, int Seed, float Connectedness[], char prev[],
                                      int X, int Y, int Z, float dx, float dy, float dz, float CosAngle,
                                      HWND hwnd, float thresh, int iterations)
{

	int x,y,z, voxel, voxeln, voxels=X*Y*Z;
	int l;
	static int Nneighbours=0;
	int *inout=NULL;
	int *heap=NULL;
	int entered;
	int xn, yn, zn, xnp, ynp, znp;
	float dp;                                            //dp between direction and previous direction
	float affinity;                                  //keep track of the previous direction
	float norm1, norm2;
	float dx2=dx*dx,dy2=dy*dy,dz2=dz*dz;
	char txt[1024];
	HDC hDC=GetDC(hwnd);
	int iter, count;

	inout=(int *)malloc(voxels*sizeof(int));
	heap=(int *)malloc(voxels*sizeof(int));


	if (inout && heap)
	{
		memset(inout,0,voxels*sizeof(int));
		memset(heap,0,voxels*sizeof(int));
		memset(prev,0,voxels);



		//---------------------------Get neighbours----------------------------
		Nneighbours=98;
		//---------------------------------------------------------------------






		//----------------------initially there are no connections----------------------------
		memset(Connectedness,0,sizeof(float)*voxels);
		entered=1;
		heap[entered]=Seed;
		Connectedness[Seed]=1.0;//seeds are connected and in the Q
		inout[Seed]=entered;
		for (voxel=0; voxel<voxels; voxel++)
			prev[voxel]=-1;//no previous direction to start with
		//------------------------------------------------------------------------------------------


		//--------------------------Fill the Q------------------------------------------------------
		iter=count=0;
		while( (Connectedness[heap[1]]>thresh) && (iter<iterations) && entered )
		{

			voxel=heap[1];
			XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);																						//the current voxel, taken from the Q
			entered=RemoveRootElement(Connectedness, heap, entered, inout);	//take out of the Q

			DirectionFromIndex555(prev[voxel], &xnp, &ynp, &znp);
			norm1=sqrt((double)(xnp*xnp*dx2 +ynp*ynp*dy2 + znp*znp*dz2));


			for (l=0; l<Nneighbours; l++)
			{

				DirectionFromIndex555(l, &xn, &yn, &zn);
				norm2=sqrt((double)(xn*xn*dx2 +yn*yn*dy2 + zn*zn*dz2));

				//get the dot product between the current direction and previous direction
				dp=(float)xnp*xn*dx2 + (float)ynp*yn*dy2 + (float)znp*zn*dz2;


				if ((voxel==Seed) || (dp>norm1*norm2*CosAngle))
				{

					if (InImageRange(x+xn,y+yn,z+zn,X,Y,Z))
					{

						voxeln=voxel + xn + yn*X + zn*X*Y;

						if (Connectedness[voxeln]<=Connectedness[voxel]) //cant update a highly connected voxel from a low connected voxel
						{

							affinity=GetAffinity(image, X, Y, Z, voxel, xn, yn, zn, Connectedness[voxel], P);

							if (affinity>Connectedness[voxel])
								affinity=Connectedness[voxel];// cant connect stronger than current connectedness

							//----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
							if ((affinity>=Connectedness[voxeln]))
							{
								count++;

								if (count>1000)
								{
									sprintf(txt,"%d %d %f %f       ", entered,voxel,Connectedness[voxel], affinity);
									TextOut(hDC,100,100,txt,strlen(txt));
									count=0;
								}

								if (!inout[voxeln])
								{
									entered=NewHeapElement(Connectedness, heap, entered, voxeln, inout, affinity);		//put into the Q if not already there
								}
								else
								{
									UpdateHeap(Connectedness, heap, entered, voxeln, affinity, inout);					//if already in the Q, update connectedness
								}
								if (voxeln!=Seed)
									prev[voxeln]=l;//update the previous direction indicator
							}
							//-----------------------------------------------------------------------------------

						}//connectedned in neighbour < connectedness in current voxel

					}//in image range
				}//dp>0
			}//l {0<=l<Nneighbours}


		}
		//-------------------------------------------------------------------------------------------

		iter++;
	}

	if (inout)
		free(inout);
	if (heap)
		free(heap);

	ReleaseDC(hwnd, hDC);

	return iter;
}



//========================================================================================
//          Compute the ThreeVectors to the valid neighbours
//          the voxel dimensions are dx, dy, dz
//========================================================================================
int GetNNeighourDirections(struct ThreeVector Vneighbour[], float dx, float dy, float dz, int N)
{

	int i,j,k;
	int index;

	index=0;
	for (k=-2; k<=2; k++)
	{
		for (j=-2; j<=2; j++)
		{
			for (i=-2; i<=2; i++)
			{
				if ((index<N) && (IndexToNeighbour555(i, j, k)>=0))
				{
					Vneighbour[index].x=dx*i;
					Vneighbour[index].y=dy*j;
					Vneighbour[index].z=dz*k;
					NormaliseThreeVector(&Vneighbour[index]);
					index++;
				}
			}
		}
	}
	return index;//the total number of vectors
}

//========================================================================================
//          Compute the ThreeVectors to the valid neighbours
//          the voxel dimensions are dx, dy, dz
//========================================================================================
int GetNeighourDirections(struct ThreeVector Vneighbour[], float dx, float dy, float dz)
{

	int i,j,k;
	int index;
	int max=0;


	for (k=-2; k<=2; k++)
	{
		for (j=-2; j<=2; j++)
		{
			for (i=-2; i<=2; i++)
			{
				index=IndexToNeighbour555(i, j, k);
				if (index>=0)
				{
					Vneighbour[index].x=dx*i;
					Vneighbour[index].y=dy*j;
					Vneighbour[index].z=dz*k;
					NormaliseThreeVector(&Vneighbour[index]);
					if (index>max)
						max=index;
				}
			}
		}
	}
	return max+1;//the total number of vectors
}
int TestGetNeighourDirections(HWND hwnd, char execdir[])
{

	int triangles;
	int Tmax;
	int vector;
	int vectors;
	struct Triangle *T=NULL;
	struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];
	char txt[256], fname[MAX_PATH];
	FILE *fp;

	vectors=GetNeighourDirections(V, 1.0, 1.0, 1.0);
	//sprintf(txt,"%d",vectors);
	//MessageBox(NULL,txt,"",MB_OK);

	Tmax=10*vectors;
	if (!(T=(struct Triangle *)malloc(Tmax*sizeof(struct Triangle))))
		goto END;
	memset(T,0,Tmax*sizeof(struct Triangle));

	for (vector=0; vector<vectors; vector++)
	{
		NormaliseThreeVector(&V[vector]);
		V[vector+vectors].x=-V[vector].x;
		V[vector+vectors].y=-V[vector].y;
		V[vector+vectors].z=-V[vector].z;
	}

	sprintf(fname,"%s/misc/triangles5x5x5.tri",execdir);
	//MessageBox(hwnd,fname,"",MB_OK);
	sprintf(txt,"%d",(triangles=GetTrianglesFromVectors(hwnd, V, 2*vectors, T, Tmax)));
	MessageBox(hwnd,txt,"",MB_OK);
	fp=fopen(fname,"wb");
	fwrite(T, sizeof(struct Triangle),triangles,fp);


END:
	if (T)
		free(T);
	return 1;
}










//==============================================================================
//      Find the connecting paths and their lengths and curvatures
//
//==============================================================================
int PathsLengthAndCurvature(char *prev, int X, int Y, int Z, int start, int *steps, double *curvature)
{

	int x,y,z;
	int i,j,k;
	int l,m,n;
	int voxel;
	double dp;

	*steps=0;
	*curvature=0.0;


	voxel=start;
	DirectionFromIndex555((int)prev[voxel], &i, &j, &k);
	while((i||j||k))
	{

		XYZfromVoxelNumber( voxel, &x, &y, &z, X, Y, Z );
		if (InImageRange(x-i, y-j, z-k, X, Y, Z))
		{
			voxel=(x-i) + (y-j)*X + (z-k)*X*Y;
			if (DirectionFromIndex555((int)prev[voxel], &l, &m, &n))
			{
				if ((i||j||k) && (l||m||n))
				{
					dp=(double)(i*l + j*m + k*n)/sqrt((double)(i*i + j*j + k*k)*(l*l + m*m + n*n));
					if (dp>=0.0)
						(*curvature)+=1.0-fabs(dp);
				}
				i=l;
				j=m;
				k=n;
				(*steps)++;
			}
			else
			{
				i=j=k=0;
			}
		}
		else
		{
			i=j=k=0;
		}
	}


	return (*steps);
}

