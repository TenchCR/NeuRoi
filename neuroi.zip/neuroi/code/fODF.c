/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

//========================================================================================
//          Compute the fODF using a linear model
//          Si=sum_j aj*Rj
//          where Si is the signal in direction i
//          and Rj is the response of a single fibre with degenerate 2nd and 3rd evals
//          aj are the unknowns, constrained such that they are >=0.0
//          aj are further constrained by being required to be similar between neighbours
//Tried using spherical harmonics instead of aj, but there has to be a lot to describe
//a sharp fODF
//========================================================================================

#include "fODF.h"
#include "numerical.h"
#include "graphtheoryalgorithms.h"
#include "generatedirections.h"
#include "imageprocess.h"

#define NEIGHBOURS 49           // there are 49 independent neighbours in the 2x2x2 neighbourhood
#define TRIANGLES 192           //number of triangles formed by the NEIGHBOURS
#define WEIGHT 1.0
#define EVAL1 (1.6e-3)
#define EVAL2 (0.4e-3)

int FillFODFdesignMatrix(double *M, struct ThreeVector Vacq[], int directions, double bvalue, float dx, float dy, float dz);
double UpdateConstrainedFODF(double *M, struct Image *DWI, struct Image *fODF, int iter);
int FillKnownsVector(double *knowns, struct Image *DWI, int voxel, int voxelspv, struct Image *fODF);
double ComputeUpdatedFODF(struct Image *fODF, int directions, double *M, double *knowns, int voxelspv, int voxel);
//========================================================================================
//          Compute the fODF given the DWI and acquisition vectors
//          Returns the fODF image if successful
//          The fODF has 50 volumes:
//              The first volume is the constant term; which could be negative
//              The subsequent volumes are the strengths of the fODF in the directions
//                  to the 49 nearest neighbours
//========================================================================================
int ComputeFODF(HWND hwnd, struct Image *DWI, struct ThreeVector Vacq[], struct bMatrix B[])
{

    struct Image fODF;
    double *M = NULL;//the design matrix for the problem
    double initial, change;
    int iter;
    int rows;
    int columns = NEIGHBOURS + 1;//allow for a constant independent term in the model
    int directions = (*DWI).volumes - 1;
    int result = 0;
    int X,Y,Zpv;
    HDC hDC;
    char txt[256];

    X=(*DWI).X;
    Y=(*DWI).Y;
    Zpv=(*DWI).Z/(*DWI).volumes;

//CREATE THE FODF IMAGE; FIRST VOLUME IS THE CONSTANT, THEN FODF DIRECTIONS TO NEIGHBOURS
    memset(&fODF,0,sizeof(struct Image));
    if (!MakeImage(&fODF, X, Y, Zpv, NEIGHBOURS + 1, (*DWI).dx, (*DWI).dy, (*DWI).dz, (*DWI).x0, (*DWI).y0, (*DWI).z0,
                   1.0, 0.0, DT_FLOAT, HDR, "fODF image")) goto END;


    rows = directions + (NEIGHBOURS + 1);//the number of constraints
    if (!(M=(double *)malloc(columns*rows*sizeof(double)))) goto END;

//FILL THE DESIGN MATRIX
    FillFODFdesignMatrix(M, &Vacq[1], directions, B[1].bValue, (*DWI).dx, (*DWI).dy, (*DWI).dz);
    if (!PsuedoInverse(M, rows, columns))
    {
        hDC=GetDC(hwnd);
        RemoveInput(hwnd);
        sprintf(txt,"          Matrix didnt invert: ComputeFODF        ");
        TextOut(hDC,100,250,txt,strlen(txt));
        ReleaseDC(hwnd,hDC);
        goto END;
    }

//ITERATE THE FODF COMPUTATION
    iter = 0;
    initial=UpdateConstrainedFODF(M, DWI, &fODF, 0);
    hDC = GetDC(hwnd);
    do
    {
        change = UpdateConstrainedFODF(M, DWI, &fODF, iter);
        iter++;

        sprintf(txt,"fODF calculation. Iteration %d  ", iter);
        TextOut(hDC,100,150,txt,strlen(txt));

    }
    while((iter < 10) && (change >= initial/10));
    ReleaseDC(hwnd,hDC);

//fODF should now contain the constrained fODF. The values should be>=0.0
    ReleaseImage(DWI);
    MakeCopyOfImage(&fODF, DWI);
    (*DWI).MaxIntensity=MaximumIntensity(DWI);

    result=1;
END:
    if (M) free(M);
    ReleaseImage(&fODF);

    return result;
}





//========================================================================================
//              Fill the design matrix for computing the constrained fODF
//              It has as many rows as acquisition directions plus NEIGHBOURS+1 rows
//                  for contraining the solution to be similar across neighbours
//========================================================================================
int FillFODFdesignMatrix(double *M, struct ThreeVector Vacq[], int directions, double bvalue, float dx, float dy, float dz)
{

    int dir;
    int neighbour;
    struct ThreeVector Vneighbour[NEIGHBOURS];
    //FILE *fp=NULL;

    memset(M,0,sizeof(double)*(NEIGHBOURS + 1)*(directions + NEIGHBOURS + 1));

    GetNNeighourDirections(Vneighbour, dx, dy, dz,NEIGHBOURS);

    //first the eplanatory response variables
    for (dir=0; dir<directions; dir++)
    {
        M[dir*(NEIGHBOURS + 1)]=1.0;
        for (neighbour=0; neighbour<NEIGHBOURS; neighbour++)
        {
            M[(neighbour + 1) + dir*(NEIGHBOURS + 1)] =
                AttenuationSymmetric(bvalue, EVAL1, EVAL2, Vneighbour[neighbour], Vacq[dir]);
        }
    }

    //now the constraints
    for (dir=directions; dir<(directions + NEIGHBOURS + 1); dir++)
    {
        M[(dir - directions) + dir*(NEIGHBOURS + 1)]=WEIGHT;
    }

    /*    fp=fopen("c:/temp/matrix.txt","w");
        for (row=0;row<(directions+NEIGHBOURS+1);row++){
            for (col=0;col<(NEIGHBOURS+1);col++){
                fprintf(fp,"%f ",M[row*(NEIGHBOURS+1)+col]);
            }
            fprintf(fp,"\n");
        }
        fclose(fp);
    */

    return 1;
}





//========================================================================================
//          Update the current fODF estimates
//          if !iter, then the current estimate is zero
//========================================================================================
double UpdateConstrainedFODF(double *M, struct Image *DWI, struct Image *fODF, int iter)
{

    double change = 0.0;
    double *knowns = NULL;
    double *unknowns = NULL;
    int directions = (*DWI).volumes - 1;
    int X,Y,Zpv,voxelspv;
    int voxel;

    X=(*DWI).X;
    Y=(*DWI).Y;
    Zpv=(*DWI).Z/(*DWI).volumes;
    voxelspv=X*Y*Zpv;


    if (!(knowns=(double *)malloc((directions + NEIGHBOURS + 1)*sizeof(double)))) goto END;
    if (!(unknowns=(double *)malloc((NEIGHBOURS + 1)*sizeof(double)))) goto END;

    if (iter) SmoothMultiVolumeResidualWeighted(fODF);

    for (voxel=0; voxel<voxelspv; voxel++)
    {
        if ((*DWI).img[voxel]>0.0)
        {
            //FILL THE KNOWNS
            if (FillKnownsVector(knowns, DWI, voxel, voxelspv, fODF))
            {
                //COMPUTE THE UNKNOWNS
                change += ComputeUpdatedFODF(fODF, directions, M, knowns, voxelspv, voxel);
            }
        }
    }

END:
    if (knowns) free(knowns);
    if (unknowns) free(unknowns);

    return change;
}


//========================================================================================
//          Fill the knowns vector with neighbour constraints and measurements
//========================================================================================
int FillKnownsVector(double *knowns, struct Image *DWI, int voxel, int voxelspv, struct Image *fODF)
{

    int i;
    int directions = (*DWI).volumes - 1;
    float T2;


    if ((T2 = (*DWI).img[voxel])<=0.0) return 0;

    //measurements first
    for (i=0; i<directions; i++)
    {
        knowns[i] = (*DWI).img[voxel + (i + 1)*voxelspv]/T2;
    }

    //now neighbour constraints
    for (i=directions; i<(directions + NEIGHBOURS + 1); i++)
    {
        knowns[i] = WEIGHT*(*fODF).img[(i - directions)*voxelspv + voxel];
    }

    return 1;
}


//========================================================================================
//          Finally compute the updated fODF
//          Constrain the fODF to be >=0.0
//========================================================================================
double ComputeUpdatedFODF(struct Image *fODF, int directions, double *M, double *knowns, int voxelspv, int voxel)
{

    double change = 0.0;
    double update;
    int rows = (directions + NEIGHBOURS + 1);
    int columns = NEIGHBOURS + 1;
    int row,col,oset,oset2;

    oset2=0;
    for (col=0; col<columns; col++)
    {
        update=0.0;
        oset=0;
        for (row=0; row<rows; row++)
        {
            update += M[col + oset]*knowns[row];
            oset+=columns;
        }
        if ( /*(col>0) &&*/ (update<0.0)) update = 0.0;//CONSTRAINT THAT THE FODF MUST BE >= 0
        change += fabs(update - (*fODF).img[voxel + oset2]);
        (*fODF).img[voxel + oset2] = update;
        oset2+=voxelspv;
    }

    return change;
}


