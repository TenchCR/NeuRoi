/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "global.h"
#include "toolbar.h"



//============================================================================================
//============================================================================================
HWND CreateToolBar(HWND hwndMain, HINSTANCE hInst){

	HWND hwndTB;
	TBADDBITMAP tbab;
	TBBUTTON tbb;
	int index;
	INITCOMMONCONTROLSEX icc;

    memset(&tbb,0,sizeof(TBBUTTON));
    memset(&tbab,0,sizeof(TBADDBITMAP));

	// Ensure that the common control DLL is loaded.
	memset(&icc, 0, sizeof(INITCOMMONCONTROLSEX));
	icc.dwSize=sizeof(INITCOMMONCONTROLSEX);
	icc.dwICC=ICC_BAR_CLASSES;
	InitCommonControlsEx(&icc);

	hwndTB = CreateWindowEx(0, TOOLBARCLASSNAME, (LPSTR) NULL,
	    WS_CHILD|WS_BORDER|CCS_ADJUSTABLE,
	    0, 0, 0, 0, hwndMain, (HMENU) ID_TOOLBAR, hInst, NULL);

	// Send the TB_BUTTONSTRUCTSIZE message, which is required for
	// backward compatibility.
	SendMessage(hwndTB, TB_BUTTONSTRUCTSIZE,(WPARAM) sizeof(TBBUTTON), 0);

	// Add the bitmap containing button images to the toolbar.
	tbab.hInst = HINST_COMMCTRL;
	tbab.nID   = IDB_STD_SMALL_COLOR;
	SendMessage(hwndTB, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);



	//ADD BUTTONS
	index = SendMessage(hwndTB,TB_ADDSTRING,0,(LPARAM)"Open");
	tbb.iString = index;
	tbb.iBitmap = STD_FILEOPEN;
	tbb.idCommand = IDM_FILE_OPEN;
	tbb.fsState = TBSTATE_ENABLED;
	tbb.fsStyle = TBSTYLE_BUTTON;


	SendMessage(hwndTB,TB_ADDBUTTONS,1,(LPARAM)&tbb);
	ShowWindow(hwndTB,SW_SHOW);
	SendMessage(hwndTB, TB_AUTOSIZE, 0, 0);
	return hwndTB;
}





//============================================================================================
//============================================================================================
#define NUM_OF_BUTTONS 7
int AddToolbarButtons(HWND hwndToolBar, HINSTANCE hInst){

	static BOOL BUTTONS_ADDED;
	TBADDBITMAP tbab;
	TBBUTTON tbb[NUM_OF_BUTTONS];
	int index, zoom_index,ROI_numbers_index, Show_ROIs_index, Cross_Hair_index, Set_Origin_index;




	if (!BUTTONS_ADDED){

        memset(&tbab,0,sizeof(TBADDBITMAP));
        memset(tbb,0,sizeof(TBBUTTON)*NUM_OF_BUTTONS);

    	tbab.hInst = hInst;
		tbab.nID   = ID_ZOOM_BITMAP;
		zoom_index=SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);


		tbab.hInst = hInst;
		tbab.nID   = ID_ROIs_BITMAP;
		Show_ROIs_index=SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);



		tbab.hInst = hInst;
		tbab.nID   = ID_ROI_NUMBERS_BITMAP;
		ROI_numbers_index=SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);


        tbab.hInst = hInst;
		tbab.nID   = ID_CROSS_BITMAP;
		//tbab.nID   = 0;
		Cross_Hair_index=SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);


		tbab.hInst = hInst;
		tbab.nID   = ID_SET_ORIGIN;
		Set_Origin_index=SendMessage(hwndToolBar, TB_ADDBITMAP, (WPARAM) 1,(LPARAM) &tbab);


		//ADD BUTTONS
		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"Save As");
		tbb[0].iString = index;
		tbb[0].iBitmap = STD_FILESAVE;
		tbb[0].idCommand = IDM_FILE_SAVEAS;
		tbb[0].fsState = TBSTATE_ENABLED;
		tbb[0].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"Zoom+");
		tbb[1].iString = index;
		tbb[1].iBitmap = zoom_index;
		tbb[1].idCommand = ID_ZOOM_UP;
		tbb[1].fsState = TBSTATE_ENABLED;
		tbb[1].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"Zoom-");
		tbb[2].iString = index;
		tbb[2].iBitmap = zoom_index;
		tbb[2].idCommand = ID_ZOOM_DOWN;
		tbb[2].fsState = TBSTATE_ENABLED;
		tbb[2].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"Show/Hide ROIs");
		tbb[3].iString = index;
		tbb[3].iBitmap = Show_ROIs_index;
		tbb[3].idCommand = IDM_SHOW_ROIS;
		tbb[3].fsState = TBSTATE_ENABLED;
		tbb[3].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"ROI #");
		tbb[4].iString = index;
		tbb[4].iBitmap = ROI_numbers_index;
		tbb[4].idCommand = IDM_SHOW_ROI_NUMBERS;
		tbb[4].fsState = TBSTATE_ENABLED;
		tbb[4].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"+size");
		tbb[5].iString = index;
		tbb[5].iBitmap = Cross_Hair_index;
		tbb[5].idCommand = IDM_CROSS_HAIR;
		tbb[5].fsState = TBSTATE_ENABLED;
		tbb[5].fsStyle = TBSTYLE_BUTTON;

		index = SendMessage(hwndToolBar,TB_ADDSTRING,0,(LPARAM)"Set Origin");
		tbb[6].iString = index;
		tbb[6].iBitmap = Set_Origin_index;
		tbb[6].idCommand = ID_SET_ORIGIN;
		tbb[6].fsState = TBSTATE_ENABLED;
		tbb[6].fsStyle = TBSTYLE_BUTTON;


		SendMessage(hwndToolBar,TB_ADDBUTTONS,NUM_OF_BUTTONS,(LPARAM) &tbb);
		BUTTONS_ADDED=TRUE;
	}
	return 1;
}

