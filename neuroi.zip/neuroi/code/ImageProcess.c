/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "display.h"
#include "menuresources.h"
#include "imageprocess.h"
#include "numerical.h"
#include "classification.h"
#include "interleave.h"




float Xintegral(float image[], int X, int Y, int Z, double x, int yi, int zi, double dx);
float Yintegral(float image[], int X, int Y, int Z, int xi, double y, int zi, double dy);
float Zintegral(float image[], int X, int Y, int Z, int xi, int yi, double z, double dz);
float InterpolateX(float image[], int X, int Y, int Z, float x,int yi,int zi);
float InterpolateY(float image[], int X, int Y, int Z, int xi,float y,int zi);
float InterpolateZ(float image[], int X, int Y, int Z, int xi,int yi,float z);
int ReSizeVolume(struct Volume *vol, float dx, float dy, float dz);
float GetDifference(float *image, int voxel, int voxeln, int voxels, int volumes);


//==============================================================================
//==============================================================================
int RandomImageVoxel(float *mask, int voxels)
{

    int voxel;
    int n=(voxels/(RAND_MAX+1))+1;

    do
    {
        voxel=n*rand() + rand()%n;
    }
    while ((voxel>=voxels) || (fabs(mask[voxel])<=0.0));

    return voxel;
}
int TestRandomImageVoxel(struct Image *image)
{
    int voxels = (*image).X*(*image).Y*(*image).Z;
    int i, voxel;
    float *img=NULL;

    img=(float *)calloc(voxels,sizeof(float));
    if (!img) return 0;

    for (i=0; i<50000000; i++)
    {
        voxel = RandomImageVoxel((*image).img, voxels);
        img[voxel] +=1.0;
    }
    memcpy((*image).img, img, voxels*sizeof(float));
    free(img);
    return 1;
}
//==============================================================================
//                 Image intensity after scaling and offset
//==============================================================================
float Intensity(struct Image *image, float I)
{
    return (*image).offset + (*image).scale*I;
}
//======================================================================================================
//======================================================================================================
int ImageCentre(struct Image *image, int *x, int *y, int *z, float *x0, float *y0, float *z0) {

	int X,Y,Z;

	X=(*image).X;
	Y=(*image).Y;
	Z=(*image).Z;
	(*x)=X/2;
	(*y)=Y/2;
	(*z)=Z/2;
	(*x0)=(*image).dx*(*x);
	(*y0)=(*image).dy*(*y);
	(*z0)=(*image).dz*(*z);

	return 1;
	}

//==============================================================================
//                 Image intensity after scaling and offset
//                 Given x, y, z
//==============================================================================
float ImageIntensity(struct Image *image, int x, int y, int z)
{

    int voxel;
    if ((x>=(*image).X) || (x<0) || (y>=(*image).Y) || (y<0) || (z>=(*image).Z) || (z<0)) return 0.0;

    voxel=x + y*(*image).X + z*(*image).X*(*image).Y;
    return Intensity(image, (*image).img[voxel]);
}

//==============================================================================
//                  Obtain the maximum intensity of an image
//==============================================================================
float MaximumIntensity(struct Image *image)
{

    int voxel, voxels;
    float max=0.0;

    voxels=(*image).X*(*image).Y*(*image).Z;

    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]>max) max=(*image).img[voxel];
    }
    return max;
}


//==============================================================================
//                 Separate multi-volume image into multiple volumes
//                 Save the results in a folder
//==============================================================================
int SeparateVolumes(struct Image *MV)
{

    int X, Y, Zpv;
    int vol, volumes;
    int i;
    struct Image image;
    char dir[MAX_PATH];
    char directory[MAX_PATH];
    char fname[MAX_PATH];
    char *p=NULL;

    X=(*MV).X;
    Y=(*MV).Y;
    Zpv=(*MV).Z/(*MV).volumes;
    volumes=(*MV).volumes;

    memset(&image,0,sizeof(struct Image));
    if (!MakeImage(&image, X, Y, Zpv, 1, (*MV).dx, (*MV).dy, (*MV).dz, (*MV).x0, (*MV).y0, (*MV).z0, (*MV).scale, (*MV).offset,
                   (*MV).DataType, (*MV).ImageType, (*MV).Descrip)) return 0;


    sprintf(dir,"%s",(*MV).filename);
    i=DirectoryFileDivide(dir);
    if (i)
    {
        p=&dir[i+1];
        dir[i]='\0';
    }
    else return 0;
    if ((i=strlen(p))>3) p[i-4]='\0';
    sprintf(directory,"%s\\SingleVolume_%s",dir, p);
    CreateDirectory(directory,NULL);

    memcpy(fname,p,strlen(p));
    fname[strlen(p)-4]='\0';
    for (vol=0; vol<volumes; vol++)
    {
        if ((*MV).ImageType==HDR)
        {
            sprintf(image.filename,"%s/%s_%d.img",directory,fname,vol);
            sprintf(image.headername,"%s/%s_%d.hdr",directory,fname,vol);
        }
        else sprintf(image.filename,"%s/%s_%d.nii",directory,fname,vol);

        memcpy(image.img, &(*MV).img[vol*X*Y*Zpv], sizeof(float)*X*Y*Zpv);
        Save(&image);
    }



    ReleaseImage(&image);

    return volumes;
}



//==============================================================================
//                 Add images
//                 put the result in *image
//				   Added volumes must be of the same dimensions as *image
//				   Return number of added images
//==============================================================================
int AddImages(HWND hwnd, struct Image *image)
{

    int images_added=0;
    int voxels, voxel;
    int X, Y, Z;
    char fname[MAX_PATH];
    struct Image loaded;
    float max=0.0;

    memset(&loaded,0,sizeof(struct Image));

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;


    while(GetAnImageFileName(fname))
    {
        if (LoadFromFileName(hwnd, fname, &loaded, 0))
        {
            if ((X==loaded.X) && (Y==loaded.Y) && (Z==loaded.Z) && IsImageScalar((*image).DataType))
            {

                //ADD THE IMAGE TO THE CURRENT
                for (voxel=0; voxel<voxels; voxel++)
                {
                    (*image).img[voxel]+=loaded.img[voxel];
                    if ((*image).img[voxel]>max) max=(*image).img[voxel];
                }

                free(loaded.img);
                memset(&loaded,0,sizeof(struct Image));

                images_added++;
            }
            else MessageBox(NULL,"Dimensions of each image should be the same.","",MB_OK);

        }
        else MessageBox(NULL,"Load failed, Please try again","",MB_OK);
    }

    if (((*image).DataType!=DT_FLOAT) && ((*image).DataType!=DT_DOUBLE)) (*image).DataType=DT_FLOAT;


    (*image).changed=1;

    if (max) (*image).MaxIntensity=max;


    return images_added;
}














//==============================================================================
//                         find the maximum/minimum of the image
//==============================================================================
int ImageMinMax(float *image, int X, int Y, int Z, int DataType, float *min, float *max)
{

    int x,y,z;
    int voxel;
    RGBQUAD *Irgb;

    (*max)=0.0;
    (*min)=0.0;//only looking for minimum if its < 0
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                voxel=Voxel(x,y,z, X, Y, Z);
                if ( IsImageScalar(DataType) )
                {
                    if ( image[voxel]>(*max) ) (*max)=image[voxel];
                    if ( image[voxel]<(*min) ) (*min)=image[voxel];
                }
                if ( DataType==DT_RGB )
                {
                    Irgb=(RGBQUAD *)&image[voxel];
                    if ( (float)(*Irgb).rgbRed>(*max) )   (*max)=(float)(*Irgb).rgbRed;
                    if ( (float)(*Irgb).rgbGreen>(*max) ) (*max)=(float)(*Irgb).rgbGreen;
                    if ( (float)(*Irgb).rgbBlue>(*max) )  (*max)=(float)(*Irgb).rgbBlue;
                    (*min)=0.0;
                }

            }
        }
    }

    return 1;
}



//==============================================================================
//                     compute the voxel number
//==============================================================================
int Voxel(int x, int y, int z, int X, int Y, int Z)
{
    return x + y*X + z*X*Y;
}



//==============================================================================
//                     Is Image type scalar?
//==============================================================================
int IsImageScalar(int DataType)
{
    if ( ((DataType==DT_UNSIGNED_CHAR) ||
          (DataType==DT_SIGNED_SHORT) ||
          (DataType==DT_SIGNED_INT) ||
          (DataType==DT_FLOAT) ||
          (DataType==DT_DOUBLE) ||
          (DataType==DT_UNSIGNED_SHORT) ||
          (DataType==DT_BINARY) ) ) return 1;
    return 0;
}





//==============================================================================
//                    Average amongst non null neighbours
//                    Averages over x and y only, unless ThreeD
//==============================================================================
int NeighbourAverage(float *img, int X, int Y, int Z, float dx, float dy, float dz, float del, int ThreeD)
{

    int result=0;
    int voxels=X*Y*Z;
    int voxel,voxeln;
    int x,y,z;
    int zXY, yX, XY=X*Y;
    int l;
    int nx,ny,nz;
    float *wX=NULL, *wY=NULL, *wZ=NULL;//weights
    float *norm=NULL, *norm2=NULL;
    short int i;
    float *smooth=NULL;

    if (dx<=0.0 || dy<=0.0 || dz<=0.0) goto END;

    if (!(wX=(float *)malloc(X*sizeof(float)))) goto END;

    if (!(wY=(float *)malloc(Y*sizeof(float)))) goto END;

    if (!(wZ=(float *)malloc(Z*sizeof(float)))) goto END;

    if (!(norm=(float *)malloc(voxels*sizeof(float)))) goto END;

    if (!(norm2=(float *)malloc(voxels*sizeof(float)))) goto END;

    if (!(smooth=(float *)malloc(voxels*sizeof(float)))) goto END;
    result=1;

    nx=ny=nz=0;
    if (dx) nx=(del/dx+0.5);
    if (dy) ny=(del/dy+0.5);
    if (dz) nz=(del/dz+0.5);
    if (nx<0) nx=1;
    if (nx>=X) nx=X;
    if (ny<0) ny=1;
    if (ny>=X) ny=Y;
    if (nz<0) nz=1;
    if (nz>=X) nz=Z;


    for (i=0; i<X; i++)
    {
        if (i<nx) wX[i]=(float)(nx-i)/nx;
        //a=(float)i/nx;
        //if (i<nx) wX[i]=exp(-a*a/2);
        //if (i<=nx) wX[i]=1.0;
        else wX[i]=0.0;
    }
    for (i=0; i<Y; i++)
    {
        if (i<ny) wY[i]=(float)(ny-i)/ny;
        //a=(float)i/ny;
        //if (i<ny) wY[i]=exp(-a*a/2);
        //if (i<=ny) wY[i]=1.0;
        else wY[i]=0.0;
    }
    for (i=0; i<Z; i++)
    {
        if (i<nz) wZ[i]=(float)(nz-i)/nz;
        //a=(float)i/nz;
        //if (i<nz) wZ[i]=exp(-a*a/2);
        //if (i<=nz) wZ[i]=1.0;
        else wZ[i]=0.0;
    }



    for (z=0; z<Z; z++)
    {
        zXY=z*XY;
        for (y=0; y<Y; y++)
        {
            yX=y*X;
            for (x=0; x<X; x++)
            {
                voxel=x+yX+zXY;
                norm[voxel]=0.0;
                smooth[voxel]=0.0;
                if (img[voxel]!=0.0)
                {
                    for (i=-nx; i<=nx; i++)
                    {
                        voxeln=voxel+i;
                        l=abs(i);
                        if ((wX[l]>0.0) && ((x+i)>=0) && ((x+i)<X) && (img[voxeln]!=0.0))
                        {
                            smooth[voxel]+=wX[l]*img[voxeln];
                            norm[voxel]+=wX[l];
                        }
                    }
                }
            }
        }
    }
    memcpy(img,smooth,sizeof(float)*voxels);


    for (z=0; z<Z; z++)
    {
        zXY=z*XY;
        for (y=0; y<Y; y++)
        {
            yX=y*X;
            for (x=0; x<X; x++)
            {
                voxel=x+yX+zXY;
                if (img[voxel]!=0.0)
                {
                    smooth[voxel]=0.0;
                    norm2[voxel]=0.0;
                    for (i=-ny; i<=ny; i++)
                    {
                        voxeln=voxel+i*X;
                        l=abs(i);
                        if ((wY[l]>0.0) && ((y+i)>=0) && ((y+i)<Y) && (img[voxeln]!=0.0))
                        {
                            smooth[voxel]+=wY[l]*img[voxeln];
                            norm2[voxel]+=wY[l]*norm[voxeln];
                        }
                    }
                }
            }
        }
    }
    memcpy(img,smooth,sizeof(float)*voxels);

    if (ThreeD)
    {
        memcpy(norm,norm2,sizeof(float)*voxels);


        for (z=0; z<Z; z++)
        {
            zXY=z*XY;
            for (y=0; y<Y; y++)
            {
                yX=y*X;
                for (x=0; x<X; x++)
                {
                    voxel=x+yX+zXY;
                    if (img[voxel]!=0.0)
                    {
                        smooth[voxel]=0.0;
                        norm2[voxel]=0.0;
                        for (i=-nz; i<=nz; i++)
                        {
                            voxeln=voxel+i*XY;
                            l=abs(i);
                            if ((wZ[l]>0.0) && ((z+i)>=0) && ((z+i)<Z) && (img[voxeln]!=0.0))
                            {
                                smooth[voxel]+=wZ[l]*img[voxeln];
                                norm2[voxel]+=wZ[l]*norm[voxeln];
                            }
                        }
                    }
                }
            }
        }
        memcpy(img,smooth,sizeof(float)*voxels);
    }//ThreeD

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (norm2[voxel]) img[voxel]/=norm2[voxel];
    }



END:
    if (smooth) free(smooth);

    if (norm) free(norm);

    if (norm2) free(norm2);

    if (wX) free(wX);

    if (wY) free(wY);

    if (wZ) free(wZ);

    return result;
}






//==============================================================================
//                       Gauss filter the image
//==============================================================================
#define MAX_SAMPLEPOINTS 101
double GaussFilterFastEx(float image[], int X, int Y, int Z, float dx, float dy, float dz, double SD, int ThreeD)
{


    double Xweights[MAX_SAMPLEPOINTS],Yweights[MAX_SAMPLEPOINTS], Zweights[MAX_SAMPLEPOINTS];
    double normX, normY, normZ, f;
    float *smoothed=NULL;
    float I;
    int xmin,xmax,ymin,ymax,zmin,zmax;
    int i,n,voxel, voxels=X*Y*Z;
    int x,y,z, tmp;
    int offset;
    int XY=X*Y;
    int Samples;

    Samples = (int)(6*SD);
    if (Samples<3) Samples=3;
    if (Samples>MAX_SAMPLEPOINTS) Samples=MAX_SAMPLEPOINTS;


    if (SD<=0.0) return 1.0;

    xmin=ymin=zmin=Samples;
    xmax=ymax=zmax=0;
    normX=normY=normZ=0.0;
    for (i=0; i<Samples; i++)
    {

        if ((f=fabs(dx*(i-Samples/2)))<(2.0*SD))
        {
            Xweights[i]=exp(-f*f/2.0/SD/SD);
            normX+=Xweights[i];
            if (i<xmin) xmin=i;
            if (i>xmax) xmax=i;
        }
        else Xweights[i]=0.0;

        if ((f=fabs(dy*(i-Samples/2)))<(2.0*SD))
        {
            Yweights[i]=exp(-f*f/2.0/SD/SD);
            normY+=Yweights[i];
            if (i<ymin) ymin=i;
            if (i>ymax) ymax=i;
        }
        else Yweights[i]=0.0;

        if ((f=fabs(dz*(i-Samples/2)))<(2.0*SD))
        {
            Zweights[i]=exp(-f*f/2.0/SD/SD);
            normZ+=Zweights[i];
            if (i<zmin) zmin=i;
            if (i>zmax) zmax=i;
        }
        else Zweights[i]=0.0;

    }

    if (normX<=0.0 || normY<=0.0) return 1.0;
    if (ThreeD && (normZ<=0.0)) return 1.0;

    smoothed=(float *)malloc(voxels*sizeof(float));

    if (smoothed)
    {
        memset(smoothed,0,voxels*sizeof(float));

        voxel=0;
        for (z=0; z<Z; z++)
        {
            for (y=0; y<Y; y++)
            {
                offset=y*X + z*XY;
                for (x=0; x<X; x++)
                {
                    tmp=x-Samples/2;
                    for (i=xmin; i<=xmax; i++)
                    {
                        if (((n=(i+tmp))>=0) && (n<X) && ((I=image[n + offset])!=0.0))
                        {
                            smoothed[voxel]+=Xweights[i]*I;
                        }
                    }
                    smoothed[voxel]/=normX;
                    voxel++;
                }
            }
        }

        memcpy(image, smoothed, voxels*sizeof(float));
        memset(smoothed,0,voxels*sizeof(float));



        voxel=0;
        for (z=0; z<Z; z++)
        {
            for (y=0; y<Y; y++)
            {
                tmp=y-Samples/2;
                for (x=0; x<X; x++)
                {
                    offset = x + z*XY;
                    for (i=ymin; i<=ymax; i++)
                    {
                        if ((n=(i+tmp))>=0 && (n<Y) && ((I=image[n*X + offset])!=0.0))
                        {
                            smoothed[voxel]+=Yweights[i]*I;
                        }
                    }
                    smoothed[voxel]/=normY;
                    voxel++;
                }
            }
        }
        memcpy(image, smoothed, voxels*sizeof(float));
        memset(smoothed,0,voxels*sizeof(float));

        if (ThreeD)
        {
            voxel=0;
            for (z=0; z<Z; z++)
            {
                tmp=z-Samples/2;
                for (y=0; y<Y; y++)
                {
                    for (x=0; x<X; x++)
                    {
                        offset = x + y*X;
                        for (i=zmin; i<=zmax; i++)
                        {
                            if ((n=(i+tmp))>=0 && (n<Z) && ((I=image[n*XY+offset])!=0.0))
                            {
                                smoothed[voxel]+=Zweights[i]*I;
                            }
                        }
                        smoothed[voxel]/=normZ;
                        voxel++;
                    }
                }
            }
            memcpy(image, smoothed, voxels*sizeof(float));
        }//if (ThreeD)

        free(smoothed);
    }//if (smoothed)

    return 0.0;
}




//==============================================================================
//                         Median Filter 2D
//                         if approx, a faster version is used
//==============================================================================
int MedianImageFilter(float *image, int X, int Y, int Z, int approx)
{

    int x,y,z;
    int i,j;
    int count;
    int sort[9];
    float *image2=NULL;
    double v[9];

    if (!(image2=(float *)calloc(X*Y*Z,sizeof(float)))) return 0;

    for (z=0; z<Z; z++)
    {
        for (y=1; y<Y-1; y++)
        {
            for (x=1; x<X-1; x++)
            {


                if (x==1)
                {
                    count=0;
                    for (j=-1; j<=1; j++) //at the begining of an image row, all elements of v need to be changed
                    {
                        for (i=-1; i<=1; i++)
                        {
                            v[count]=(double)image[Voxel(x+i, y+j, z, X, Y, Z)];
                            count++;
                        }
                    }
                }
                else
                {
                    if (count>=3) count=0;
                    v[count]=(double)image[Voxel(x+1, y-1, z, X, Y, Z)];
                    v[count+3]=(double)image[Voxel(x+1, y, z, X, Y, Z)];//6 of the 9 elements dont need to be changed. Update only those that need it (the last column)
                    v[count+6]=(double)image[Voxel(x+1, y+1, z, X, Y, Z)];
                    count++;
                }
                if (!approx) image2[Voxel(x, y, z, X, Y, Z)]=(float)MedianValueDoubleEx(9, v, sort);
                else image2[Voxel(x, y, z, X, Y, Z)]=MedianValueDoubleFastApprox(9, v);

            }
        }
    }
    memcpy(image,image2,sizeof(float)*X*Y*Z);

    if (image2) free(image2);
    return 1;
}






//==============================================================================
//                         Sobel vector in 2D
//                         return V.x and V.y the vector components
//                         V.z is magnitude of Vx and Vy
//==============================================================================
struct ThreeVector SobelVector(float *image, int X, int Y, int Z, float dx, float dy, float dz, int x, int y, int z)
{

    struct ThreeVector V;
    float N,NE,E,SE,S,SW,W,NW;
    int voxel=Voxel(x,y,z,X,Y,Z);


    N=NE=E=SE=S=SW=W=NW=0.0;

    memset(&V,0,sizeof(struct ThreeVector));
    if ( (dx<=0.0) || (dy<=0.0) ) return V;


    if (y<(Y-1)) N=image[voxel+X];
    if (y>=1)    S=image[voxel-X];

    if (x<(X-1)) E=image[voxel+1];
    if (x>=1)    W=image[voxel-1];

    if ((y<(Y-1)) && (x<(X-1))) NE=image[voxel+X+1];
    if ((y>=1) && (x>=1))       SW=image[voxel-X-1];

    if ((y<(Y-1)) && (x>=1)) NW=image[voxel-1+X];
    if ((y>=1) && (x<(X-1))) SE=image[voxel+1-X];

    V.x=( (NE + 2.0*E + SE) - (NW + 2.0*W + SW) )/dx/4.0;
    V.y=( (NE + 2.0*N + NW) - (SE + 2.0*S + SW) )/dy/4.0;




    V.z=sqrt(V.x*V.x + V.y*V.y);

    return V;
}


//==============================================================================
//==============================================================================
//                         Sobel vector in 3D
//                         return V.x,V.y, and V.z the vector components
//                         MUST BE INITIALISED BECAUSE OF THE STATIC LOOKUP TABLE
//==============================================================================
struct FourFloatVector SobelVector3D(float *image, int X, int Y, int Z, float dx, float dy, float dz, int x, int y, int z, int initialise)
{

    int XY=X*Y;
    int i,j,k;
    int voxel=Voxel(x,y,z,X,Y,Z), voxeln;
    static double w[3][3][3];
    double weight;
    static double Xnorm,Ynorm,Znorm;
    struct FourFloatVector V;

    memset(&V,0,sizeof(struct FourFloatVector));



    if (initialise)
    {
        Xnorm=Ynorm=Znorm=0.0;

        //PRE COMPUTE THE WEIGHTS
        for (k=-1; k<=1; k++)
        {
            for (j=-1; j<=1; j++)
            {
                for (i=-1; i<=1; i++)
                {
                    if (i||j||k)
                    {
                        w[i+1][j+1][k+1]=exp(-(dx*dx*i*i + dy*dy*j*j + dz*dz*k*k));

                        if (i>0) Xnorm+=w[i+1][j+1][k+1];
                        if (j>0) Ynorm+=w[i+1][j+1][k+1];
                        if (k>0) Znorm+=w[i+1][j+1][k+1];

                    }
                }
            }
        }
        Xnorm*=dx;
        Ynorm*=dy;
        Znorm*=dz;
    }


    if (x>0 || x<X-1  || y>0 || y<Y-1 || z>0 || z<Z-1)
    {
    if (x==0 || x==X-1 || y==0 || y==Y-1 || z==0 || z==Z-1) return V;
    }



    for (k=-1; k<=1; k++)
    {
        for (j=-1; j<=1; j++)
        {
            for (i=-1; i<=1; i++)
            {
                if (InImageRange(x+i, y+j, z+k, X, Y, Z))
                {

                    voxeln=voxel + i + j*X + k*XY;
                    weight=w[i+1][j+1][k+1];

                    if (i<0)
                    {
                        V.x -= weight*image[voxeln];
                    }
                    else if (i>0)
                    {
                        V.x += weight*image[voxeln];
                    }

                    if (j<0)
                    {
                        V.y -= weight*image[voxeln];
                    }
                    else if (j>0)
                    {
                        V.y += weight*image[voxeln];
                    }


                    if (k<0)
                    {
                        V.z -= weight*image[voxeln];
                    }
                    else if (k>0)
                    {
                        V.z += weight*image[voxeln];
                    }

                }

            }
        }
    }

    V.x /= Xnorm;
    V.y /= Ynorm;
    V.z /= Znorm;
    V.f = sqrt(V.x*V.x + V.y*V.y + V.z*V.z);

    return V;
}
//==============================================================================
//TEST SobelVector3D
//==============================================================================
int TestSobelVector3D(struct Image *image)
{
    int X,Y,Z;
    int x,y,z;
    struct FourFloatVector V;
    float *grad=NULL;
    float max=0.0;


    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;

    if (!(grad=(float *)calloc(X*Y*Z, sizeof(float)))) return 0;

    V = SobelVector3D((*image).img,  X, Y, Z, (*image).dx, (*image).dy, (*image).dz, 0, 0, 0,1);//initialise the weights

    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                V = SobelVector3D((*image).img,  X, Y, Z, (*image).dx, (*image).dy, (*image).dz, x, y, z,0);
                grad[x + y*X + z*X*Y]=sqrt(V.x*V.x + V.y*V.y + V.z*V.z);
                if (grad[x + y*X + z*X*Y]>max) max=grad[x + y*X + z*X*Y];
            }
        }
    }

    memcpy((*image).img, grad, X*Y*Z*sizeof(float));
    (*image).MaxIntensity=max;

    if (grad) free(grad);
    return 1;
}




//==============================================================================
//                     Get the GRAD image using Sobel
//==============================================================================
int CreateGradImage(struct Image *image, struct Image *grad)
{

    int x,y,z;
    int voxel, voxels;
    struct ThreeVector V;

    voxels=(*image).X*(*image).Y*(*image).Z;
    for (z=0; z<(*image).Z; z++)
    {
        for (y=0; y<(*image).Y; y++)
        {
            for (x=0; x<(*image).X; x++)
            {
                voxel=Voxel(x, y, z, (*image).X, (*image).Y, (*image).Z);
                V=SobelVector((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, x, y, z);
                (*grad).img[voxel]=V.x;
                (*grad).img[voxel+voxels]=V.y;
                (*grad).img[voxel+2*voxels]=V.z;
            }
        }
    }
    return 1;
}




//==============================================================================
//                         Sobel Filter
//DOESNT COMPUTE THE GRADIENT
//==============================================================================
int SobelImageFilter(float *image, int X, int Y, int Z, float dx, float dy, float dz, int Dimensions)
{

    int x,y,z;
    int voxels=X*Y*Z,voxel;
    int Zstart, Zend;
    float *image2=NULL;
    struct ThreeVector V;
    struct FourFloatVector V4;

    if (!(image2=(float *)calloc(voxels,sizeof(float)))) return 0;

    Zstart=0;
    Zend=Z;

    ///IF ITS 3D IT NEEDS TO BE INITIALISED
    if (Dimensions==SOBEL3D)
    {
        SobelVector3D(image, X, Y, Z, dx, dy, dz, 0, 0, 0, 1);
        Zstart=1;//cant do the first and last slice in 3D
        Zend=Z-1;
    }

    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if (x>0 && x<X-1 && y>0 && y<Y-1 && z>=Zstart && z<=Zend)
                {
                if (Dimensions==SOBEL2D)
                {
                    V=SobelVector(image, X, Y, Z, dx, dy, dz, x, y, z);
                    image2[voxel]=V.z;
                }
                else
                {
                    V4=SobelVector3D(image, X, Y, Z, dx, dy, dz, x, y, z, 0);
                    image2[voxel]=V4.f;
                }
                }
                voxel++;
            }
        }
    }
    memcpy(image,image2,sizeof(float)*voxels);


    if (image2) free(image2);
    return 1;
}



//==============================================================================
//on exit image is replaced by edge intensities
//intensities are computed in 3D
//==============================================================================
int Edges(struct Image *image)
{
    int result=0;
    int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int voxel;
    struct FourFloatVector *f=NULL;
    float max=0.0;

    if(!(f=(struct FourFloatVector *)malloc(voxels*sizeof(struct FourFloatVector)))) goto END;

    result=EdgesEx(image,f);

    for (voxel=0;voxel<voxels;voxel++)
    {
        (*image).img[voxel]=f[voxel].f;
        if ((*image).img[voxel]>max) max=(*image).img[voxel];
    }
    (*image).MaxIntensity=max;

END:
    if (f) free(f);
    return result;
}

//==============================================================================
//USE MAXIMAL GRADIENT TO IDENTIFY THE EDGES IN 3D
//ON EXIT f HAS THE FOURVECTOR GRADIENT
//==============================================================================
int EdgesEx(struct Image *image, struct FourFloatVector *f)
{
    int result=0;
    struct FourFloatVector g,gf,gb,zero;
    int voxel;
    int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int x,y,z;
    int X,Y,Z,XY;
    int i,j,k;
    float norm;
    char *edge=NULL;

    if (!(edge=(char *)calloc(voxels,sizeof(char)))) goto END;

    memset(&zero,0,sizeof(struct FourFloatVector));

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;
    XY=X*Y;

    SobelVector3D((*image).img, X, Y, Z, 1.0, 1.0, 1.0, 0, 0, 0, 1);


    //Get the gradients and magnitude
    voxel=0;
    for (z=0;z<Z;z++)
    {
        for (y=0;y<Y;y++)
        {
            for (x=0;x<X;x++)
            {
                //interested in image edges. Dont care if the voxels are anisotropic
                f[voxel]=SobelVector3D((*image).img, X, Y, Z, 1.0, 1.0, 1.0, x, y, z, 0);
                voxel++;
            }
        }
    }
    for (z=1;z<Z-1;z++)
    {
        for (y=1;y<Y-1;y++)
        {
            for (x=1;x<X-1;x++)
            {
                voxel=x+ y*X + z*XY;
                g=f[voxel];
                norm=g.f;

                if (g.x>0.0) i=(int)(g.x/norm+0.5);
                else i=(int)(g.x/norm-0.5);

                if (g.y>0.0) j=(int)(g.y/norm+0.5);
                else j=(int)(g.y/norm-0.5);

                if (g.z>0.0) k=(int)(g.z/norm+0.5);
                else k=(int)(g.z/norm-0.5);

                gf=f[voxel+i+j*X+k*XY];
                gb=f[voxel-i-j*X-k*XY];

                if ((g.f>gf.f) && (g.f>gb.f)) edge[voxel]=1;
            }
        }
    }
    for (voxel=0;voxel<voxels;voxel++)
    {
        if (!edge[voxel]) f[voxel]=zero;
    }

    result=1;
END:
    if (edge) free(edge);
    return result;
}
//=====================================
//what are the vectors to the nearest neighbours?
int TestNeighbourVoxelDirections(void)
{
    int i,j,k;
    double v;
    FILE *fp=NULL;

    fp=fopen("c:\\temp\\directions.txt","w");
    for (k=-1;k<=1;k++)
    {
        for (j=-1;j<=1;j++)
        {
            for (i=-1;i<=1;i++)
            {
                v=sqrt(1.0*i*i + 1.0*j*j + 1.0*k*k);
                if (fp) fprintf(fp,"%d %d %d %f %f %f\n",i,j,k,1.0*i/v,1.0*j/v,1.0*k/v);
            }
        }
    }
    if (fp) fclose(fp);
    return 0;
}
//==============================================================================
//                   Maximal Gradient Supression
//                   remove the strong edges
//==============================================================================
int MaximalGradientSupression(struct Image *image)
{

    struct Image grad;
    char *descrip="Gradient Image";
    int x,y,z;
    int flag;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    int i, j, ibest, jbest;
    int voxel;
    struct ThreeVector V;
    double dp,maxdp;


    memset(&grad,0,sizeof(struct Image));

    //-------------create the image where the gradient will go--------------
    flag=MakeImage(&grad, (*image).X, (*image).Y, (*image).Z/(*image).volumes, (*image).volumes*3,
                   (*image).dx, (*image).dy, (*image).dz,
                   (*image).x0, (*image).y0, (*image).z0,
                   1.0, 0.0, DT_FLOAT, HDR, descrip);



    if (!flag) return 0;

    CreateGradImage(image, &grad);                                               //create the gradient

    for (z=0; z<(*image).Z; z++)
    {
        for (y=1; y<(*image).Y-1; y++)
        {
            for (x=1; x<(*image).X-1; x++)
            {
                voxel=Voxel(x,y,z,(*image).X, (*image).Y, (*image).Z);
                V.x=grad.img[voxel];
                V.y=grad.img[voxel+voxels];
                V.z=grad.img[voxel+2*voxels];

                maxdp=0.0;
                ibest=jbest=0;
                for (j=-1; j<=1; j++)
                {
                    for (i=-1; i<=1; i++)
                    {
                        dp=(*image).dx*V.x*i + (*image).dy*V.y*j;
                        if (dp>maxdp)                                                   //get the vector to the neighbour that gives
                        {
                            maxdp=dp;                                                    //the highest dot product with the
                            ibest=i;                                                     //gradient vector
                            jbest=j;
                        }
                    }
                }

                if (ibest || jbest)                                                 //check if this voxel is maximal
                {
                    if (grad.img[voxel+ibest+jbest*(*image).X+2*voxels]<V.z &&       //along the gradient direction
                            grad.img[voxel-ibest-jbest*(*image).X+2*voxels]<V.z)
                    {
                        (*image).img[voxel]=0;                                       //NULL the voxel if it is
                    }
                }

            }
        }
    }

    if (grad.img) free( grad.img );

    return 1;
}







//==============================================================================
//                      Intensity filter
//                      Intensity limits the first volume
//                      Then applies the first volume as binary to the others
//==============================================================================
int IntensityFilter(struct Image *image, float min, float max)
{

    int voxel;
    int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int volume;

    if (!IsImageScalar((*image).DataType)) return 0;

    //threshold the first volume by intensity
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((*image).img[voxel]<min) || ((*image).img[voxel]>max) ) (*image).img[voxel]=0.0;
    }

    //use first volume to zero voxels in the other volumes
    for (volume=1; volume<(*image).volumes; volume++)
    {
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (!((*image).img[voxel])) (*image).img[voxel+volume*voxels]=0.0;
        }
    }

    ImageMinMax((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).DataType, &min, &(*image).MaxIntensity);

    return 1;
}





//==============================================================================
//                         FILTERS
//                         types are
//                         GAUSSIAN, MEDIAN, SOBEL, MAXIMALSUPRESSION
//==============================================================================
int FilterImage(struct Image *image, int FilterType, double SD)
{

    int volume;
    int voxels;
    float min,max;
    HCURSOR hourglass, PrevCursor;



    if (!((*image).volumes)) return 0;

    if (!IsImageScalar((*image).DataType))
    {
        MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
    }

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;

    (*image).changed=1;                                                         //the image has been changed
    if (FilterType==GAUSSIAN && voxels && IsImageScalar((*image).DataType))
    {
        for (volume=0; volume<(*image).volumes; volume++)
            GaussFilterFastEx(&(*image).img[volume*voxels], (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                              (*image).dx, (*image).dy, (*image).dz, SD, 1);
        ImageMinMax((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).DataType, &min, &max);
        (*image).MaxIntensity=max;                                         //get the new image maximum
        (*image).changed=1;
        SetCursor(PrevCursor);
        return 1;
    }
    if (FilterType==MEDIAN && voxels && IsImageScalar((*image).DataType))
    {
        for (volume=0; volume<(*image).volumes; volume++)
            MedianImageFilter(&(*image).img[volume*voxels], (*image).X, (*image).Y, (*image).Z/(*image).volumes, 0);
        ImageMinMax((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).DataType, &min, &max);
        (*image).MaxIntensity=max;                                                //get the new image maximum
        (*image).changed=1;
        SetCursor(PrevCursor);
        return 1;
    }
    if ((FilterType==SOBEL2D || FilterType==SOBEL3D) && voxels && IsImageScalar((*image).DataType))
    {
        for (volume=0; volume<(*image).volumes; volume++)
            SobelImageFilter(&(*image).img[volume*voxels], (*image).X, (*image).Y, (*image).Z/(*image).volumes, (*image).dx, (*image).dy, (*image).dz, FilterType);
        (*image).changed=1;
        SetCursor(PrevCursor);
        return 1;
    }
    if (FilterType==MAXIMALSUPRESSION && voxels && IsImageScalar((*image).DataType))
    {
        //MessageBox(NULL,"test","",MB_OK);
        MaximalGradientSupression(image);
        (*image).changed=1;
        SetCursor(PrevCursor);
        return 1;
    }
    return 0;
}
















//==============================================================================
//              Similarity based filter for multi volume images
//Can be used with just a couple of volumes, unlike the linear model based
//SoomthMultiVolume......
//==============================================================================
#define H_LENGTH 2001
int MultiVolumeSimilarityFilter(float *image, int X, int Y, int Zpv, int volumes, float dx, float dy, float dz, int iterations)
{

    float *tmp=NULL;
    float weights[3][3], weight, norm;
    float width2;
    float difference;
    float H[H_LENGTH];
    float mean;
    int voxels=X*Y*Zpv*volumes;
    int voxelspv=X*Y*Zpv;
    int XY=X*Y;
    int voxel, voxeln;
    int volume;
    int iteration;
    int x,y,z;
    int i,j;
    int h,n;
    HCURSOR hourglass, PrevCursor;


    if (volumes<=1) return 0;


    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    //FILE *fp;

    if ( (tmp=(float *)malloc(voxels*sizeof(float))) )
    {

        //compute spatial weights
        width2=(dx*dx < dy*dy) ? dx*dx:dy*dy;
        if (width2<=0.0) goto END;

        for (j=-1; j<=1; j++)
        {
            for (i=-1; i<=1; i++)
            {
                weights[i+1][j+1]=exp(-((i*dx)*(i*dx) + (j*dy)*(j*dy))/width2);
            }
        }



        //compute similarity distribution
        memset(H,0,sizeof(float)*H_LENGTH);
        mean=0.0;
        n=0;
        for (z=0; z<Zpv; z++)
        {
            for (y=0; y<Y; y++)
            {
                for (x=0; x<X; x++)
                {
                    voxel=x+y*X+z*XY;

                    for (j=-1; j<=1; j++)
                    {
                        for (i=-1; i<=1; i++)
                        {
                            if (InImageRange((x+i), (y+j), z, X, Y, Zpv))
                            {
                                voxeln=voxel+i+j*X;
                                if (image[voxel] && image[voxeln])
                                {
                                    difference=(image[voxel]-image[voxeln]);
                                    mean+=difference*difference;
                                    n++;
                                }
                            }
                        }
                    }

                }
            }
        }
        if ((n>0) && (mean>=0.0))
        {
            mean=sqrt(mean/n);
            mean*=3;
        }
        else goto END;

        for (iteration=0; iteration<iterations; iteration++)
        {
            norm=0.0;
            for (z=0; z<Zpv; z+=2)
            {
                for (y=0; y<Y; y+=4)
                {
                    for (x=0; x<X; x+=4)
                    {
                        voxel=x+y*X+z*XY;

                        for (j=-1; j<=1; j++)
                        {
                            for (i=-1; i<=1; i++)
                            {
                                if ((i||j) && InImageRange((x+i), (y+j), z, X, Y, Zpv))
                                {
                                    voxeln=voxel+i+j*X;
                                    if (image[voxel] && image[voxeln])
                                    {
                                        difference=GetDifference(image, voxel, voxeln, voxelspv, volumes);
                                        h=(H_LENGTH-1)*difference/mean;
                                        if (h>H_LENGTH-1) h=H_LENGTH-1;
                                        H[h]+=1.0;
                                        norm+=1.0;
                                    }
                                }
                            }
                        }

                    }
                }
            }

            if (norm==0.0) goto END;
            for (i=1; i<H_LENGTH; i++)    H[i]+=H[i-1];     //get cummulative df
            for (i=0; i<H_LENGTH; i++)    H[i]/=(norm*1.001); //normalise H[1000]=1.0/1.001

            /*if (fp=fopen("c:/temp/H.txt","w")){
              for (i=0;i<H_LENGTH;i++) fprintf(fp,"%d %f\n",i,H[i]);
              fclose(fp);
            }*/






            //-----------Now Smooth the Volumes----------------------------
            memset(tmp,0,voxels*sizeof(float));
            for (z=0; z<Zpv; z++)
            {
                for (y=0; y<Y; y++)
                {
                    for (x=0; x<X; x++)
                    {
                        voxel=x+y*X+z*XY;
                        norm=0.0;

                        for (j=-1; j<=1; j++)
                        {
                            for (i=-1; i<=1; i++)
                            {
                                if (InImageRange((x+i), (y+j), z, X, Y, Zpv))
                                {
                                    voxeln=voxel+i+j*X;
                                    if (i || j)
                                    {
                                        difference=GetDifference(image, voxel, voxeln, voxelspv, volumes);
                                        h=(H_LENGTH-1)*difference/mean;
                                        if (h>H_LENGTH-1) h=H_LENGTH-1;
                                        weight=weights[i+1][j+1]*(1.0-H[h])*(1.0-H[h]);
                                        if ( (1.0-H[h])<0.0 ) weight=0.0;
                                    }
                                    else weight=1.0;

                                    if (weight)
                                    {
                                        norm+=weight;
                                        for (volume=0; volume<volumes; volume++)
                                        {
                                            tmp[voxel+volume*voxelspv] += weight*image[voxeln+volume*voxelspv];
                                        }
                                    }

                                }
                            }
                        }

                        if (norm)
                        {
                            for (volume=0; volume<volumes; volume++)
                            {
                                tmp[voxel+volume*voxelspv]/=norm;
                            }
                        }
                    }
                }
            }
            memcpy(image, tmp, sizeof(float)*voxels);


        }//iteration

        SetCursor(PrevCursor);
    }
    else return 0;


END:
    if (tmp) free(tmp);


    return 1;
}








//==============================================================================
//                  -Get the similarity between neighbours
//==============================================================================
float GetDifference(float *image, int voxel, int voxeln, int voxels, int volumes)
{

    int volume;
    float sum=0.0;
    float diff;

    if (!volumes) return 0.0;

    for (volume=0; volume<volumes; volume++)
    {
        diff = (image[voxel+voxels*volume]-image[voxeln+voxels*volume]);
        sum += diff*diff;
    }

    return sqrt(sum/volumes);
}
















//==============================================================================
//                      Filter Multi Volume images
//                      Neighbourhood data should explain the variance
//                      within voxel. The R^2 value tells us how much.
//                      Weight the filter using R^2.
//                      Add the estimates from the polynomial fit of the
//                      neighbour data to the within voxel data.
//==============================================================================
double SmoothMultiVolumeResidualWeighted(struct Image *image)
{

    int i,j,k; //neighbours
    int x,y,z;
    int X, Y, Zpv;
    int count,countvolumes;
    int volume,voxelvolumes;
    int voxel, voxeln, voxelspv=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    int volumes=(*image).volumes;
    int kXY;
    int nonzero;
    double *M=NULL;
    double R2;
    double *fy=NULL, *fyn=NULL;
    double *knowns=NULL;
    double change=0.0;
    float mean;
    float *tmp=NULL;
    HCURSOR hourglass, PrevCursor;

    if (volumes<7)
    {
        MessageBox(NULL,"Must be at least 7 volumes to use filter.","",MB_OK|MB_ICONWARNING);
        return 0;
    }


    M  =    (double *)malloc(volumes*6*sizeof(double));//the model has 6 parameters
    fy =    (double *)malloc(volumes*sizeof(double));
    fyn=    (double *)malloc(volumes*6*sizeof(double));//6 neighbours considered, hence the *6
    knowns= (double *)malloc(volumes*sizeof(double));
    tmp=    (float *)malloc(sizeof(float)*(*image).X*(*image).Y*(*image).Z);

    if ((!tmp) || (!M) || (!fy) || (!fyn) || (!knowns)) goto END;


    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/volumes;


    //get the mean intensity value
    //T2mean used to normalise the data to make the linear model numerically more stable
    count=0;
    mean=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*image).img[voxel])>0.0 )
        {
            count++;
            mean += (*image).img[voxel];
        }
    }
    if (count) mean/=count;

    if (mean<=0.0) goto END;

    memcpy(tmp, (*image).img, sizeof(float)*voxels);


    for (z=0; z<Zpv; z++)
    {
        for (y=1; y<Y-1; y++)
        {
            for (x=1; x<X-1; x++)
            {
                voxel=x+y*X+z*X*Y;

                nonzero=0;
                voxelvolumes=0;
                for (volume=0; volume<volumes; volume++)
                {
                    fy[volume]=(double)((*image).img[voxel+voxelvolumes])/mean;
                    if (fabs(fy[volume])>0.0) nonzero++;
                    voxelvolumes+=voxelspv;
                }
                if ( nonzero==volumes )
                {
                    count=0;
                    countvolumes=0;
                    for (k=-1; k<=1; k++)
                    {
                        if (((z+k)<Zpv) && ((z+k)>=0))
                        {
                            kXY=k*X*Y;
                            for (j=-1; j<=1; j++)
                            {
                                for (i=-1; i<=1; i++)
                                {
                                    if ((count<6) && (fabs(i) + fabs(j) + fabs(k))==1)
                                    {
                                        voxeln=voxel + i + j*X + kXY;

                                        nonzero=0;
                                        voxelvolumes=0;
                                        for (volume=0; volume<volumes; volume++)
                                        {
                                            fyn[volume+countvolumes]=(double)((*image).img[voxeln + voxelvolumes])/mean;
                                            if (fyn[volume+countvolumes]) nonzero++;
                                            voxelvolumes+=voxelspv;
                                        }
                                        count++;
                                        countvolumes+=volumes;

                                    }
                                }
                            }
                        }
                    }
                    //sprintf(txt,"%f %d",R2,count);
                    //MessageBox(NULL,txt,"",MB_OK);
                    //fit model
                    if ((R2=SmoothMultiVolumeDataBayes(fy, fyn, knowns, volumes, M, count))>0.0)
                    {
                        for (volume=0; volume<volumes; volume++) tmp[voxel+volume*voxelspv]=fy[volume]*mean;
                    }

                }
            }
        }
    }


    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]>0.0) change+=fabs( (*image).img[voxel]-tmp[voxel] );
    }

    memcpy((*image).img, tmp, sizeof(float)*voxels);

    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]<0.0) (*image).img[voxel]=0.0;
    }

    SetCursor(PrevCursor);


END:
    if (M) free(M);
    if (fy) free(fy);
    if (fyn) free(fyn);
    if (tmp) free(tmp);
    if (knowns) free(knowns);
    return change;
}

//==============================================================================
//					Smooth the multi volume data using a Bayesian linear model
//					The dependent variable is from the voxel to be smoothed
//					Independents are from the 6 nearest neighbours
//fy is the unsmoothed data; smoothed using R^2 on exit
//knowns are model estimate of the data on exit
//rows is the number of data points
//M is pre reserved memory; only used for storing the design matrix
//neighbours is the number of neighbours to average over; max 6
//==============================================================================
double SmoothMultiVolumeDataBayes(double fy[], double fyn[], double *knowns, int rows, double *M,  int neighbours)
{

    double params[6];
    double SS, SSr;
    double tmp;
    double R2=0.0;
    double priorInvV[6*6];
    double priorM[6];
    int row,col;

    if (rows<=neighbours) return 0.0;//need at least as many rows as neighbours
    if (neighbours<=2) return 0.0;//dont smooth without at least 2 neighbours

    memset(M,0,sizeof(double)*rows*neighbours);
    for (row=0; row<rows; row++)
    {
        for (col=0; col<neighbours; col++)
        {
            M[row*neighbours + col]=fyn[col*rows+row];
        }
    }

    memcpy(knowns, fy, sizeof(double)*rows);



    //prepare the priors
    memset(priorInvV,0,sizeof(double)*neighbours*neighbours);
    memset(priorM,0,sizeof(double)*neighbours);

//priors
    for (col=0; col<neighbours; col++)
    {
        priorInvV[col*neighbours+col]=0.1;
        priorM[col]=1.0/neighbours;
    }

    if (BayesLinearRegression(knowns, M, params, rows, neighbours, priorInvV, priorM))
    {


        for (row=0; row<rows; row++)
        {
            knowns[row]=0.0;
            for (col=0; col<neighbours; col++)
            {
                knowns[row]+=M[row*neighbours + col]*params[col];
            }
        }

        SS=SSr=0.0;
        for (row=0; row<rows; row++)
        {
            tmp=fy[row]-knowns[row];
            SSr+=tmp*tmp;
            SS+=fy[row];
        }
        //variance=Var(fy, rows);

        if ((SS>0.0) && (SSr<SS))
        {
            //Compare the linear model to a constant; weight by how much more variance the linear model explains
            //Could use the sum of squares instead, but that would smooth more.
            //R2=1.0-SSr/variance;//*******TOO CONSERVATIVE***********

            //Compare sum of squared residuals to sum of squares
            R2=1.0-SSr/SS;
            if (R2>0.0)
            {
                for (row=0; row<rows; row++)
                {
                    fy[row]+=R2*knowns[row];
                    fy[row]/=(1.0+R2);
                }
            }
        }
    }

    return R2;
}








//==============================================================================
//==============================================================================
float MaxProjectionAlongX(float *image, int X, int Y, int Z, int xa, int xb, int y, int z)
{
    int x;
    float max=0.0;
    float i=0.0;
    int index=y*X + z*X*Y;

    for (x=xa;x<=xb;x++)
    {
        i=image[x + index];
        if (i>max) max=i;
    }
    return max;
}

//==============================================================================
//==============================================================================
float MaxProjectionAlongY(float *image, int X, int Y, int Z, int x, int ya, int yb, int z)
{
    int y;
    float max=0.0;
    float i=0.0;
    int index=x + z*X*Y;

    for (y=ya;y<=yb;y++)
    {
        i=image[y*X + index];
        if (i>max) max=i;
    }
    return max;
}

//==============================================================================
//==============================================================================
float MaxProjectionAlongZ(float *image, int X, int Y, int Z, int x, int y, int za, int zb)
{
    int z;
    float max=0.0;
    float i=0.0;
    int index=x + y*X;

    for (z=za;z<=zb;z++)
    {
        i=image[z*X*Y + index];
        if (i>max) max=i;
    }
    return max;
}
int TestMaxProjections(float *image, int X, int Y, int Z)
{
    int voxel;
    float max;
    double xf,yf,zf;
    char txt[256];

    max=0.0;
    for (voxel=0;voxel<X*Y*Z;voxel++)
    {
        if (image[voxel]>max) max=image[voxel];
    }
    xf=MaxProjectionAlongX(image, X, Y, Z, 0,X-1,Y/2,Z/2);
    yf=MaxProjectionAlongY(image, X, Y, Z, X/2,0,Y-1,Z/2);
    zf=MaxProjectionAlongZ(image, X, Y, Z, X/2,Y/2,0,Z-1);
    sprintf(txt,"%f %f %f %f",xf,yf,zf,max);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}

//==============================================================================
//              -Get a max intensity projection onto 3 planes
//              -output is in plane1[X*Y], plane2[X*Z], and plane3[Y*Z]
//==============================================================================
int MaxIntensityProjection(float *image, int X, int Y, int Z, struct ImagePlanes *planes)
{

    int x,y,z;
    int voxel;
    int zoffset, yoffset;
    int yX,zX,zY;
    float I;

    if ((*planes).plane1) free((*planes).plane1);
    if ((*planes).plane2) free((*planes).plane2);
    if ((*planes).plane3) free((*planes).plane3);

    (*planes).plane1=(float *)malloc(X*Y*sizeof(float));//axial
    (*planes).plane2=(float *)malloc(X*Z*sizeof(float));//coronal
    (*planes).plane3=(float *)malloc(Y*Z*sizeof(float));//sagittal

    if ((*planes).plane1 && (*planes).plane2 && (*planes).plane3)
    {
        memset((*planes).plane1,0,sizeof(float)*X*Y);
        memset((*planes).plane2,0,sizeof(float)*X*Z);
        memset((*planes).plane3,0,sizeof(float)*Y*Z);
        (*planes).X=X;
        (*planes).Y=Y;
        (*planes).Z=Z;
        (*planes).max=0.0;
        for (z=0; z<Z; z++)
        {
            zoffset = z*X*Y;
            zX = z*X;
            zY = z*Y;
            for (y=0; y<Y; y++)
            {
                yoffset = y*X;
                yX = y*X;
                for (x=0; x<X; x++)
                {
                    voxel=x + yoffset + zoffset;
                    I=image[voxel];
                    if (I>(*planes).plane1[x+yX]) (*planes).plane1[x+yX]=I;
                    if (I>(*planes).plane2[x+zX]) (*planes).plane2[x+zX]=I;
                    if (I>(*planes).plane3[y+zY]) (*planes).plane3[y+zY]=I;
                    if (I>(*planes).max) (*planes).max=I;
                }
            }
        }
    }
    else
    {
        if ((*planes).plane1) free((*planes).plane1);
        if ((*planes).plane2) free((*planes).plane2);
        if ((*planes).plane3) free((*planes).plane3);
        return 0;
    }

    return 1;
}


//==============================================================================
//              Convert image to max intensity projection image
//==============================================================================
int ConvertToMaxIntensityProjection(struct Image *image)
{

    struct ImagePlanes planes;
    struct Image conv;
    int X,Y,Zpv,volumes;
    int Xp,Yp;
    int y;
    int voxelspv;
    int volume;
    int result=0;
    float dx,dy,dz;
    float max=0.0;

    memset(&conv,0,sizeof(struct Image));
    memset(&planes,0,sizeof(struct ImagePlanes));

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    volumes=(*image).volumes;
    voxelspv=X*Y*Zpv;

//the dimensions of the planes the max intensity will be projected onto
    Xp=(X>Y) ? X:Y;
    Yp=(Y>Zpv) ? Y:Zpv;

    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;

    if (!MakeImage(&conv, Xp, Yp, 3, volumes, dx, dy, dz, X/2.0, Y/2.0, 0.0, 1.0, 0.0,
                   DT_FLOAT, HDR, "Max Intensity Projections")) goto END;

    for (volume=0; volume<volumes; volume++)
    {
        if (MaxIntensityProjection(&(*image).img[volume*voxelspv], X, Y, Zpv, &planes))
        {
            for (y=0; y<Yp; y++)
            {
                //plane1 is XY
                memcpy(&conv.img[volume*Xp*Yp*3 + y*Xp], &planes.plane1[y*X], sizeof(float)*X);

                //plane2 is XZpv
                if (y<Zpv) memcpy(&conv.img[volume*Xp*Yp*3+Xp*Yp + y*Xp], &planes.plane2[y*X], sizeof(float)*X);

                //plane3 is YZpv
                if (y<Zpv) memcpy(&conv.img[volume*Xp*Yp*3+2*Xp*Yp + y*Xp], &planes.plane3[y*Y], sizeof(float)*Y);
            }
            if (planes.max>max) max=planes.max;
        }
        else goto END;
    }

    conv.MaxIntensity=max;
    ReleaseImage(image);
    MakeCopyOfImage(&conv, image);
    result = 1;

END:
    if (planes.plane1) free(planes.plane1);
    if (planes.plane2) free(planes.plane2);
    if (planes.plane3) free(planes.plane3);
    ReleaseImage(&conv);

    return result;
}














//==============================================================================
//                            Perform 90 degree rotations about
//                            X, Y, or Z axis
//==============================================================================
int Rotate90(struct Image *image, int axis)
{

    float *img;
    float dx, dy, dz;
    float x0, y0, z0;
    double rot[16];
    int mat[4][4];
    int i,j,k,i1,j1,k1;
    int X, Y, Z, X1, Y1, Z1;
    int voxel;


    memset(mat,0,sizeof(int)*4*4);

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;


    img=(float *)malloc(X*Y*Z*sizeof(float));
    if (!img) return 0;


    mat[3][3]=1;

    if (axis==X_AXIS) //X->X, Y->(-Z), Z->Y
    {
        mat[0][0]=1;//X
        mat[1][2]=-1;//Y
        mat[2][1]=1;//Z
        mat[1][3]=(Z-1);
    }
    if (axis==Y_AXIS) //X->(-Z), Y->Y, Z->X
    {
        mat[0][2]=-1;//X
        mat[1][1]=1;//Y
        mat[2][0]=1;//Z
        mat[0][3]=(Z-1);
    }
    if (axis==Z_AXIS) //X->Y, Y->(-X), Z->Z
    {
        mat[0][1]=1;//X
        mat[1][0]=-1;//Y
        mat[2][2]=1;//Z
        mat[1][3]=(X-1);
    }


    X1=abs(mat[0][0]*X + mat[0][1]*Y + mat[0][2]*Z);
    Y1=abs(mat[1][0]*X + mat[1][1]*Y + mat[1][2]*Z);
    Z1=abs(mat[2][0]*X + mat[2][1]*Y + mat[2][2]*Z);

    dx=fabs(mat[0][0]*(*image).dx + mat[0][1]*(*image).dy + mat[0][2]*(*image).dz);
    dy=fabs(mat[1][0]*(*image).dx + mat[1][1]*(*image).dy + mat[1][2]*(*image).dz);
    dz=fabs(mat[2][0]*(*image).dx + mat[2][1]*(*image).dy + mat[2][2]*(*image).dz);
    (*image).dx=dx;
    (*image).dy=dy;
    (*image).dz=dz;

    x0=fabs(mat[0][0]*(*image).x0 + mat[0][1]*(*image).y0 + mat[0][2]*(*image).z0);
    y0=fabs(mat[1][0]*(*image).x0 + mat[1][1]*(*image).y0 + mat[1][2]*(*image).z0);
    z0=fabs(mat[2][0]*(*image).x0 + mat[2][1]*(*image).y0 + mat[2][2]*(*image).z0);
    (*image).x0=x0;
    (*image).y0=y0;
    (*image).z0=z0;

    for (k=0; k<Z; k++)
    {
        for (j=0; j<Y; j++)
        {
            for (i=0; i<X; i++)
            {
                i1=mat[0][0]*i + mat[0][1]*j + mat[0][2]*k + mat[0][3];
                j1=mat[1][0]*i + mat[1][1]*j + mat[1][2]*k + mat[1][3];
                k1=mat[2][0]*i + mat[2][1]*j + mat[2][2]*k + mat[2][3];
                voxel=i1+j1*X1+k1*X1*Y1;
                img[voxel]=(*image).img[i+j*X+k*X*Y];
            }
        }
    }
    memcpy((*image).img, img, X*Y*Z*sizeof(float));
    (*image).X=X1;
    (*image).Y=Y1;
    (*image).Z=Z1;

    (*image).changed=1;


    //save the rotation to the total image rotations
    memset(rot,0,sizeof(double)*16);
    for (k=0; k<4; k++)
    {
        for (j=0; j<4; j++)
        {
            for (i=0; i<4; i++)
            {
                rot[j+k*4]+=(*image).rotation[i + k*4]*mat[i][j];
            }
        }
    }
    memcpy((*image).rotation, rot, sizeof(double)*16);

    if (img) free(img);

    return 1;
}












//==============================================================================
//                            -Make Copy Of Image
//                            -Only copies .img
//==============================================================================
int MakeCopyOfImage(struct Image *original, struct Image *copy)
{

    int voxels;

    ReleaseImage(copy);                                                         //have to free memory already allocated

    memcpy(copy, original, sizeof(struct Image));                               //copy the whole structure

    (*copy).floatimg=NULL;//not copying these
    (*copy).charimg=NULL;


    voxels=(*original).X*(*original).Y*(*original).Z;
    (*copy).img=(float *)malloc(voxels*sizeof(float));                          //replace the pointer to the original

    if ( (*copy).img )
    {
        memcpy((*copy).img, (*original).img, voxels*sizeof(float));              //now copy the image
        return 1;
    }
    else (*copy).img=NULL;//make sure its NULL

    return 0;
}











//==============================================================================
//                            free memory in an Image
//==============================================================================
int ReleaseImage(struct Image *image)
{

    if ((*image).img)
    {
        free((*image).img);
        (*image).img=NULL;
    }
    if ((*image).floatimg)
    {
        free((*image).floatimg);
        (*image).floatimg=NULL;
    }
    if ((*image).charimg)
    {
        free((*image).charimg);
        (*image).charimg=NULL;
    }

    memset(image,0,sizeof(struct Image));
    return 1;
}









//==============================================================================
//                     Flip image
//==============================================================================
int MirrorImage(struct Image *image)
{

    float *slice=NULL;
    double rot[16];
    int i,j,k;
    int x,y,z;
    int pixels=(*image).X*(*image).Y;
    int mat[4][4];

    memset(mat,0,sizeof(int)*4*4);

    slice=(float *)malloc(pixels*sizeof(float));
    if (!slice) return 0;


    //mirror the image
    for (z=0; z<(*image).Z; z++)
    {
        memcpy(slice, &(*image).img[z*pixels], pixels*sizeof(float));
        for (y=0; y<(*image).Y; y++)
        {
            for (x=0; x<(*image).X; x++)
            {
                (*image).img[(*image).X-x-1+y*(*image).X+z*pixels]=slice[x+y*(*image).X];
            }
        }
    }

    //adjust the total transformation matrix for this image
    mat[0][0]=-1;
    mat[1][1]=mat[2][2]=mat[3][3]=1;
    mat[0][3]=(*image).X-1;
    memset(rot,0,sizeof(double)*16);
    for (k=0; k<4; k++)
    {
        for (j=0; j<4; j++)
        {
            for (i=0; i<4; i++)
            {
                rot[j+k*4]+=(*image).rotation[i + k*4]*mat[i][j];
            }
        }
    }
    memcpy((*image).rotation, rot, sizeof(double)*16);




    (*image).changed=1;

    if (slice) free(slice);

    return 1;
}












//==============================================================================
//              Image will be resampled with voxel dimensions dx, dy, dz
//              Uses nearest neighbour interpolation
//==============================================================================
int ReSampleImage(struct Image *image, float dx, float dy, float dz)
{

    int Xi, Yi, Zi;//initial dimensions
    int Xf, Yf, Zf;//final dimensions
    int voxels;
    int result=0;
    int x,y,z;
    int xt, yt, zt;
    float dxi,dyi,dzi;
    float *resized=NULL;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;

    hourglass=LoadCursor(NULL,IDC_WAIT);
    PrevCursor=SetCursor(hourglass);

    if (dx<=0.0 || dy<=0.0 || dz<=0.0) goto END;

    //initial image dimensions
    dxi=(*image).dx;
    dyi=(*image).dy;
    dzi=(*image).dz;

    Xi=(*image).X;
    Yi=(*image).Y;
    Zi=(*image).Z;

    //WORK OUT THE NEW IMAGE DIMENSIONS
    if (dx==dxi) Xf=Xi;
    else Xf=Xi*dxi/dx;
    if (dy==dyi) Yf=Yi;
    else Yf=Yi*dyi/dy;
    if (dz==dzi) Zf=Zi;
    else Zf=Zi*dzi/dz;

    voxels=Xf*Yf*Zf;
    if (!(resized=(float *)malloc(voxels*sizeof(float)))) goto END;




//SAMPLE image TO THE RESIZED IMAGE
    for (z=0; z<Zf; z++)
    {
        zt=(int)((float)z/Zf*Zi + 0.5);
        for (y=0; y<Yf; y++)
        {
            yt=(int)((float)y/Yf*Yi + 0.5);
            for (x=0; x<Xf; x++)
            {
                xt=(int)((float)x/Xf*Xi + 0.5);
                if (InImageRange( xt, yt, zt, Xi, Yi, Zi ))
                {
                    resized[x + y*Xf + z*Xf*Yf]=(*image).img[xt + yt*Xi + zt*Xi*Yi];
                }
                else resized[x + y*Xf + z*Xf*Yf]=0.0;
            }
        }
    }



    free((*image).img);
    if ( ((*image).img=(float *)malloc(voxels*sizeof(float))) )
    {
        memcpy((*image).img, resized, voxels*sizeof(float));
        (*image).X=Xf;
        (*image).Y=Yf;
        (*image).Z=Zf;
        (*image).dx=dx;
        (*image).dy=dy;
        (*image).dz=dz;

        (*image).changed=1;
    }
    else
    {
        (*image).X=0;
        (*image).Y=0;
        (*image).Z=0;
        goto END;
    }



    result=1;
END:
    SetCursor(PrevCursor);
    if (resized) free(resized);

    return result;
}



//==============================================================================
//              Image will be resized with voxel dimensions dx, dy, dz
//              for multi volume images does one volume at a time
//              assumes image is arranged by volume, rather than by slice
//==============================================================================
int ReSizeImage(struct Image *image, float dx, float dy, float dz)
{

    struct Volume *vol=NULL;
    int voxels;
    int volume;
    int resized=1;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;

    hourglass=LoadCursor(NULL,IDC_WAIT);
    PrevCursor=SetCursor(hourglass);

    if (!(vol=(struct Volume *)malloc(sizeof(struct Volume)*(*image).volumes))) return 0;

    for (volume=0; (volume<(*image).volumes) && (resized); volume++)            //resize each volume
    {
        vol[volume].X=(*image).X;
        vol[volume].Y=(*image).Y;
        vol[volume].Z=(*image).Z/(*image).volumes;
        voxels=vol[volume].X*vol[volume].Y*vol[volume].Z;

        vol[volume].dx=(*image).dx;
        vol[volume].dy=(*image).dy;
        vol[volume].dz=(*image).dz;

        vol[volume].img=(float *)malloc(sizeof(float)*voxels);

        if ((vol[volume].img))
        {
            memcpy(vol[volume].img, &(*image).img[voxels*volume], voxels*sizeof(float));
            if (!ReSizeVolume(&vol[volume], dx, dy, dz)) resized=0;
        }
    }

    if (resized)                                                                //put resized volumes back into image
    {
        voxels=vol[0].X*vol[0].Y*vol[0].Z;
        free((*image).img);
        (*image).img=(float *)malloc(voxels*(*image).volumes*sizeof(float));
        if ((*image).img)
        {
            (*image).X=vol[0].X;
            (*image).Y=vol[0].Y;
            (*image).Z=vol[0].Z*(*image).volumes;
            (*image).dx=dx;
            (*image).dy=dy;
            (*image).dz=dz;
            for (volume=0; volume<(*image).volumes; volume++) memcpy(&(*image).img[volume*voxels], vol[volume].img, voxels*sizeof(float));
            (*image).changed=1;
        }
        else
        {
            (*image).X=0;
            (*image).Y=0;
            (*image).Z=0;
            resized=0;
        }
    }
    else resized=0;

    for (volume=0; volume<(*image).volumes; volume++)
    {
        if (vol[volume].img)
            free(vol[volume].img); //free the malloced volume memory
    }

    SetCursor(PrevCursor);

    return resized;
}

//==============================================================================
//      volume will be resized with voxel dimensions dx, dy, dz
//==============================================================================
int ReSizeVolume(struct Volume *vol, float dx, float dy, float dz)
{

    int xi,yi,zi,voxel;
    int Xf, Yf, Zf;
    int Xi, Yi, Zi;
    double x,y,z;
    float *TmpImage=NULL;
    float dxi,dyi,dzi;
//	char txt[256];


    if (dx<=0.0 || dy<=0.0 || dz<=0.0) return 0;


    //initial image dimensions
    dxi=(*vol).dx;
    dyi=(*vol).dy;
    dzi=(*vol).dz;

    Xi=(*vol).X;
    Yi=(*vol).Y;
    Zi=(*vol).Z;


    //WORK OUT THE NEW IMAGE DIMENSIONS
    if (dx==dxi) Xf=Xi;
    else Xf=Xi*dxi/dx;
    if (dy==dyi) Yf=Yi;
    else Yf=Yi*dyi/dy;
    if (dz==dzi) Zf=Zi;
    else Zf=Zi*dzi/dz;


    //X DIRECTION FIRST
    if (Xi!=Xf)
    {
        TmpImage=(float *)malloc(sizeof(float)*Xf*Yi*Zi);
        if (TmpImage)
        {
            for (zi=0; zi<Zi; zi++)
            {
                for (yi=0; yi<Yi; yi++)
                {
                    for (xi=0; xi<Xf; xi++)
                    {
                        x=((double)xi)*dx/dxi;
                        voxel=xi + yi*Xf + zi*Xf*Yi;
                        if (dx/dxi>1.0) TmpImage[voxel]=Xintegral((*vol).img, Xi, Yi, Zi, x, yi, zi, dx/dxi);
                        else TmpImage[voxel]=InterpolateX((*vol).img, Xi, Yi, Zi, x,yi,zi);
                    }
                }
            }
            if ( ((*vol).img=(float *)realloc((*vol).img,sizeof(float)*Xf*Yi*Zi)) )
            {
                memcpy((*vol).img,TmpImage,sizeof(float)*Xf*Yi*Zi);
                Xi=Xf;
                (*vol).X=Xf;
                free(TmpImage);
                TmpImage=NULL;
            }
            else
            {
                free(TmpImage);
                return 0;
            }

        }
        else return 0;
    }



    //Y DIRECTION
    if (Yi!=Yf)
    {
        TmpImage=(float *)malloc(sizeof(float)*Xf*Yf*Zi);
        if (TmpImage)
        {
            for (zi=0; zi<Zi; zi++)
            {
                for (yi=0; yi<Yf; yi++)
                {
                    y=((double)yi)*dy/dyi;
                    for (xi=0; xi<Xf; xi++)
                    {
                        voxel=xi + yi*Xf + zi*Xf*Yf;
                        if (dy/dyi>1.0) TmpImage[voxel]=Yintegral((*vol).img, Xf, Yi, Zi, xi, y, zi, dy/dyi);
                        else TmpImage[voxel]=InterpolateY((*vol).img, Xi, Yi, Zi, xi,y,zi);
                    }
                }
            }

            if ( ((*vol).img=(float *)realloc((*vol).img,sizeof(float)*Xf*Yf*Zi)) )
            {
                memcpy((*vol).img,TmpImage,sizeof(float)*Xf*Yf*Zi);
                Yi=Yf;
                (*vol).Y=Yf;
                free(TmpImage);
                TmpImage=NULL;
            }
            else
            {
                free(TmpImage);
                return 0;
            }
        }
        else return 0;
    }


    //Z DIRECTION
    if (Zi!=Zf)
    {
        TmpImage=(float *)malloc(sizeof(float)*Xf*Yf*Zf);
        if (TmpImage)
        {
            for (zi=0; zi<Zf; zi++)
            {
                z=((double)zi)*dz/dzi;
                for (yi=0; yi<Yf; yi++)
                {
                    for (xi=0; xi<Xf; xi++)
                    {
                        voxel=xi + yi*Xf + zi*Xf*Yf;
                        if (dz/dzi>1.0) TmpImage[voxel]=Zintegral((*vol).img, Xf, Yf, Zi, xi, yi, z, dz/dzi);
                        else TmpImage[voxel]=InterpolateZ((*vol).img, Xi, Yi, Zi, xi,yi,z);
                    }
                }
            }
            if ( ((*vol).img=(float *)realloc((*vol).img,sizeof(float)*Xf*Yf*Zf)) )
            {
                memcpy((*vol).img,TmpImage,sizeof(float)*Xf*Yf*Zf);
                Zi=Zf;
                (*vol).Z=Zf;
                free(TmpImage);
                TmpImage=NULL;
            }
            else
            {
                free(TmpImage);
                return 0;
            }
        }
        else return 0;
    }

    return 1;
}






//==============================================================================
//                           Integrate intensity along x
//                           X, Y, Z are image matrix size
//                           centre of point to be integrated over is
//                                  x, yi, zi
//                           range to integrate over is dx
//==============================================================================
#define MAX_INTEGRAL_POINTS 256
float Xintegral(float image[], int X, int Y, int Z, double x, int yi, int zi, double dx)
{

    float a,b;
    float Xp[MAX_INTEGRAL_POINTS],Yp[MAX_INTEGRAL_POINTS];
    float I;
    int count,xi,i;

    if (dx<=0.0) return 0.0;

    memset(Xp,0,MAX_INTEGRAL_POINTS*sizeof(float));
    memset(Yp,0,MAX_INTEGRAL_POINTS*sizeof(float));

    //integration limits
    a=x-dx/2.0;
    b=x+dx/2.0;


    //get the data at the start of the integration range
    count=0;
    Xp[count]=a;
    Yp[count]=InterpolateX(image, X, Y, Z, b, yi, zi);
    count++;

    //get the data at points in between the integration limits
    //only use the integer points
    xi=(int)(a+1.0);
    while(xi<=(int)b)
    {
        Xp[count]=(float)xi;
        Yp[count]=InterpolateX(image, X, Y, Z, (float)xi, yi, zi);
        xi++;
        count++;
    }

    //if not already at the integration limit, get data point at limit
    if (Xp[count-1]<b)
    {
        Xp[count]=b;
        Yp[count]=InterpolateX(image, X, Y, Z, b, yi, zi);
    }
    else count--;

    //use trapezoid integration
    I=0.0;
    for (i=0; i<count; i++) I+=(Xp[i+1]-Xp[i])*(Yp[i]+Yp[i+1])/2.0;

    return I/dx;

}
//==============================================================================
//                           Integrate intensity along y
//                           X, Y, Z are image matrix size
//                           centre of point to be integrated over is
//                                  xi, y, zi
//                           range to integrate over is dy
//==============================================================================
float Yintegral(float image[], int X, int Y, int Z, int xi, double y, int zi, double dy)
{

    float a,b;
    float Xp[MAX_INTEGRAL_POINTS],Yp[MAX_INTEGRAL_POINTS];
    float I;
    int count,yi,i;

    if (dy<=0.0) return 0.0;

    memset(Xp,0,MAX_INTEGRAL_POINTS*sizeof(float));
    memset(Yp,0,MAX_INTEGRAL_POINTS*sizeof(float));

    a=y-dy/2.0;
    b=y+dy/2.0;


    count=0;
    Xp[count]=a;
    Yp[count]=InterpolateY(image, X, Y, Z, xi, a, zi);
    count++;

    yi=(int)(a+1.0);
    while(yi<=(int)b)
    {
        Xp[count]=(float)yi;
        Yp[count]=InterpolateY(image, X, Y, Z, xi, (float)yi, zi);
        yi++;
        count++;
    }

    if (Xp[count-1]<b)
    {
        Xp[count]=b;
        Yp[count]=InterpolateY(image, X, Y, Z, xi, b, zi);
    }
    else count--;

    I=0.0;
    for (i=0; i<count; i++) I+=(Xp[i+1]-Xp[i])*(Yp[i]+Yp[i+1])/2.0;

    return I/dy;
}
//==============================================================================
//                           Integrate intensity along z
//                           X, Y, Z are image matrix size
//                           centre of point to be integrated over is
//                                  xi, yi, z
//                           range to integrate over is dz
//==============================================================================
float Zintegral(float image[], int X, int Y, int Z, int xi, int yi, double z, double dz)
{

    float a,b;
    float Xp[MAX_INTEGRAL_POINTS],Yp[MAX_INTEGRAL_POINTS];
    float I;
    int count,zi,i;

    if (dz<=0.0) return 0.0;

    memset(Xp,0,MAX_INTEGRAL_POINTS*sizeof(float));
    memset(Yp,0,MAX_INTEGRAL_POINTS*sizeof(float));

    a=z-dz/2.0;
    b=z+dz/2.0;


    count=0;
    Xp[count]=a;
    Yp[count]=InterpolateZ(image, X, Y, Z, xi, yi, a);
    count++;

    //add the next bits that are the voxel centres
    zi=(int)(a+1.0);
    while(zi<=(int)b)
    {
        Xp[count]=(float)zi;
        Yp[count]=InterpolateZ(image, X, Y, Z, xi, yi, (float)zi);
        zi++;
        count++;
    }

    //if the last voxel centre doesnt coincide with x1, add the last point
    if (Xp[count-1]<b)
    {
        Xp[count]=b;
        Yp[count]=InterpolateZ(image, X, Y, Z, xi, yi, b);
    }
    else count--;

    I=0.0;
    for (i=0; i<count; i++) I+=(Xp[i+1]-Xp[i])*(Yp[i]+Yp[i+1])/2.0;

    return I/dz;
}


//==============================================================================
//                           Interpolate intensity along x
//                           X, Y, Z are image matrix size
//==============================================================================
float InterpolateX(float image[], int X, int Y, int Z, float x,int yi,int zi)
{

    int xi;
    float dx;
    float I=0.0;
    int voxel;
    int XY=X*Y;

    xi=(int)x;

    if (xi>=0 && xi<X)
    {
        dx=x-xi;

        voxel=xi+yi*X+zi*XY;

        if (xi<(X-1))
        {
            I=dx*image[voxel+1]+(1.0-dx)*image[voxel];
        }
        else
        {
            I=(1.0-dx)*image[voxel];
        }
    }

    return I;
}
//==============================================================================
//                           Interpoltate y
//==============================================================================
float InterpolateY(float image[], int X, int Y, int Z, int xi, float y,int zi)
{

    int yi,voxel;
    float dy;
    float I=0.0;
    int XY=X*Y;

    yi=(int)y;

    if (yi>=0 && yi<Y)
    {
        dy=y-yi;

        voxel=xi+yi*X+zi*XY;

        if (yi<(Y-1))
        {
            I=dy*image[voxel+X]+(1.0-dy)*image[voxel];
        }
        else
        {
            I=(1.0-dy)*image[voxel];
        }
    }

    return I;
}
//==============================================================================
//                           Interpoltate z
//==============================================================================
float InterpolateZ(float image[], int X, int Y, int Z, int xi, int yi, float z)
{

    int zi,voxel;
    float dz;
    float I=0.0;
    int XY=X*Y;

    zi=(int)z;

    if (zi>=0 && zi<Z)
    {

        dz=z-zi;

        voxel=xi+yi*X+zi*XY;

        if (zi<(Z-1))
        {
            I=dz*image[voxel+X*Y]+(1.0-dz)*image[voxel];
        }
        else
        {
            I=(1.0-dz)*image[voxel];
        }
    }

    return I;
}




//==============================================================================
//          Interpolate an image at point {xf,yf,zf}
//          Use methods ID_NEAREST_NEIGHBOUR, ID_TRILINEAR
//==============================================================================
float InterpolateImage(struct Image *image, int volume, double xf, double yf, double zf, int method)
{

    int xi,yi,zi;
    int voxelspv=(*image).X*(*image).Y*(*image).Z/(*image).volumes;

    if (method==ID_NEAREST_NEIGHBOUR)
    {
        xi=(int)(xf+0.5);
        yi=(int)(yf+0.5);
        zi=(int)(zf+0.5);
        if (InImageRange(xi, yi, zi, (*image).X, (*image).Y, (*image).Z/(*image).volumes))
        {
            return (*image).img[xi + yi*(*image).X + zi*(*image).X*(*image).Y + volume*voxelspv];
        }
        else return 0.0;
    }
    else if (method==ID_TRILINEAR)
    {
        return Lagrange3D(&(*image).img[volume*voxelspv], (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                          xf, yf, zf);
    }
    else if (method==ID_CUBIC)
    {
        return CubicInterpolation3D(&(*image).img[volume*voxelspv], (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                                    xf, yf, zf);
    }

    return 0.0;
}


//==============================================================================
//                           Lagrange Interpoltate in 2D
//==============================================================================
float Lagrange2D(float image[], int X, int Y, int Z, double x,double y, int zi)
{

    float f00,f01,f10,f11;
    float f;
    int xi,yi, voxel;
    double dx,dy;


    xi=(int)x;
    yi=(int)y;
    if (!InImageRange(xi,yi,zi,X,Y,Z)) return 0.0;

    dx=x-(double)xi;
    dy=y-(double)yi;

    voxel=Voxel(xi, yi, zi, X, Y, Z);

    f00=										  image[voxel];
    f10=( (xi+1)<X ) 							? image[voxel+1]:0.0;
    f01=( (yi+1)<Y ) 							? image[voxel+X]:0.0;
    f11=( (xi+1)<X && (yi+1)<Y ) 				? image[voxel+1+X]:0.0;

    f=(dx-1.0)*(dy-1.0)*f00;
    f+=-(dx-1.0)*dy*f01;
    f+=-dx*(dy-1.0)*f10;
    f+=dx*dy*f11;

    if (f<0.0) f=0.0;

    return f;
}




//==============================================================================
//                           Lagrange Interpolate in 3D
//==============================================================================
float Lagrange3D(float image[], int X, int Y, int Z, double x,double y,double z)
{

    float f000,f001,f010,f011,f100,f101,f110,f111;
    float f;
    int xi,yi,zi, voxel, voxelsperslice=X*Y;
    double dx,dy,dz;


    xi=(int)x;
    yi=(int)y;
    zi=(int)z;
    if (!InImageRange(xi,yi,zi,X,Y,Z)) return 0.0;

    dx=x-xi;
    dy=y-yi;
    dz=z-zi;

    voxel=Voxel(xi, yi, zi, X, Y, Z);

    xi++;
    yi++;
    zi++;

    f000=										  image[voxel];
    f001=( (zi)<Z ) 							? image[voxel+voxelsperslice]:0.0;
    f010=( (yi)<Y ) 							? image[voxel+X]:0.0;
    f011=( (zi)<Z && (yi)<Y ) 				? image[voxel+voxelsperslice+X]:0.0;
    f100=( (xi)<X ) 							? image[voxel+1]:0.0;
    f101=( (xi)<X && (zi)<Z ) 				? image[voxel+1+voxelsperslice]:0.0;
    f110=( (xi)<X && (yi)<Y ) 				? image[voxel+1+X]:0.0;
    f111=( (xi)<X && (yi)<Y && (zi)<Z ) 	? image[voxel+1+X+voxelsperslice]:0.0;

    f=-(dx-1.0)*(dy-1.0)*(dz-1.0)*f000;
    f+=(dx-1.0)*(dy-1.0)*dz*f001;
    f+=(dx-1.0)*dy*(dz-1.0)*f010;
    f+=-(dx-1.0)*dy*dz*f011;
    f+=dx*(dy-1.0)*(dz-1.0)*f100;
    f+=-dx*(dy-1.0)*dz*f101;
    f+=-dx*dy*(dz-1.0)*f110;
    f+=dx*dy*dz*f111;

    if (f<0.0) f=0.0;

    return f;
}



//==============================================================================
//                    -Lagrange Interpoltate in 3D
//                       given the Lagrange coefficients
//                    -can be used to interpolate many times quickly
//                       where the coefficients dont change
//==============================================================================
float Lagrange3DA(float image[], int X, int Y, int Z, double x,double y,double z, float c[])
{

    float f000,f001,f010,f011,f100,f101,f110,f111;
    float f;
    int xi,yi,zi, voxel, voxelsperslice=X*Y;
    int xiplus1,yiplus1,ziplus1;
    int voxelnextslice;

    xi=(int)x;
    xiplus1=xi+1;
    yi=(int)y;
    yiplus1=yi+1;
    zi=(int)z;
    ziplus1=zi+1;
    if (!InImageRange(xi,yi,zi,X,Y,Z)) return 0.0;



    voxel = xi + yi*X + zi*voxelsperslice;

    voxelnextslice = voxel + voxelsperslice;

    f000=										                                image[voxel];
    f001=( ziplus1<Z ) 							                     ? image[voxelnextslice]:0.0;
    f010=( yiplus1<Y ) 							                 ? image[voxel+X]:0.0;
    f011=( (ziplus1<Z) && (yiplus1<Y) )		         ? image[voxelnextslice+X]:0.0;
    f100=( xiplus1<X ) 							                 ? image[voxel+1]:0.0;
    f101=( (xiplus1<X) && (ziplus1<Z) )		         ? image[voxelnextslice+1]:0.0;
    f110=( (xiplus1<X) && (yiplus1<Y) )			     ? image[voxel+1+X]:0.0;
    f111=( (xiplus1<X) && (yiplus1<Y) && (ziplus1<Z) ) 	? image[voxelnextslice+1+X]:0.0;

    f=c[0]*f000;
    f+=c[1]*f001;
    f+=c[2]*f010;
    f+=c[3]*f011;
    f+=c[4]*f100;
    f+=c[5]*f101;
    f+=c[6]*f110;
    f+=c[7]*f111;

    return f;

}

//==============================================================================
//                    -Lagrange Interpoltate in 3D
//                       given the Lagrange coefficients
//                    -can be used to interpolate many times quickly
//                       where the coefficients dont change
//SAME AS Lagrange3DA BUT USES UNSIGNED CHAR IMAGES
//==============================================================================
float Lagrange3DB(unsigned char image[], int X, int Y, int Z, double x,double y,double z, float c[])
{

    float f000,f001,f010,f011,f100,f101,f110,f111;
    float f;
    int xi,yi,zi, voxel, voxelsperslice=X*Y;

    xi=(int)x;
    yi=(int)y;
    zi=(int)z;
    if (!InImageRange(xi,yi,zi,X,Y,Z)) return 0.0;


    voxel=Voxel(xi, yi, zi, X, Y, Z);

    f000=										  (float)image[voxel];
    f001=( (zi+1)<Z ) 							? (float)image[voxel+voxelsperslice]:0.0;
    f010=( (yi+1)<Y ) 							? (float)image[voxel+X]:0.0;
    f011=( (zi+1)<Z && (yi+1)<Y ) 				? (float)image[voxel+voxelsperslice+X]:0.0;
    f100=( (xi+1)<X ) 							? (float)image[voxel+1]:0.0;
    f101=( (xi+1)<X && (zi+1)<Z ) 				? (float)image[voxel+1+voxelsperslice]:0.0;
    f110=( (xi+1)<X && (yi+1)<Y ) 				? (float)image[voxel+1+X]:0.0;
    f111=( (xi+1)<X && (yi+1)<Y && (zi+1)<Z ) 	? (float)image[voxel+1+X+voxelsperslice]:0.0;

    f=c[0]*f000;
    f+=c[1]*f001;
    f+=c[2]*f010;
    f+=c[3]*f011;
    f+=c[4]*f100;
    f+=c[5]*f101;
    f+=c[6]*f110;
    f+=c[7]*f111;

    return f;

}

//==============================================================================
//                  Lagrange Interpoltate coefficients in 3D
//==============================================================================
int Lagrange3DCoefficients(float dx, float dy, float dz, float c[])
{

    if (dx<0.0) dx=0.0;
    if (dy<0.0) dy=0.0;
    if (dz<0.0) dz=0.0;
    if (dx>1.0) dx=1.0;
    if (dy>1.0) dy=1.0;
    if (dz>1.0) dz=1.0;

    c[0]=-(dx-1.0)*(dy-1.0)*(dz-1.0);
    c[1]=(dx-1.0)*(dy-1.0)*dz;
    c[2]=(dx-1.0)*dy*(dz-1.0);
    c[3]=-(dx-1.0)*dy*dz;
    c[4]=dx*(dy-1.0)*(dz-1.0);
    c[5]=-dx*(dy-1.0)*dz;
    c[6]=-dx*dy*(dz-1.0);
    c[7]=dx*dy*dz;
    return 1;
}



//==============================================================================
//      Interpolate Image by fitting cubics to the 4 nearest neighbours
//      in each dimension
//==============================================================================
float CubicInterpolation3D(float image[], int X, int Y, int Z, double x,double y,double z)
{

    int xi, yi, zi;
    int i,j, k;
    int voxel;
    int o,oz;
    double Ix[4], Iy[4], Ixyz=0.0;
    double V[4];

    if ((x<0.0) || (x>(double)(X-1)) || (y<0.0) || (y>(double)(Y-1)) || (z<0.0) || (z>(double)(Z-1))) return 0.0;

    xi=(int)x;
    yi=(int)y;
    zi=(int)z;
    o=xi+yi*X+zi*X*Y;
    for (k=-1; k<=2; k++)
    {
        if (((zi+k)>=0) && ((zi+k)<Z))
        {
            oz=k*X*Y;
            for (j=-1; j<=2; j++)
            {
                if (((yi+j)>=0) && ((yi+j)<Y))
                {
                    voxel=o+j*X+oz;
                    for (i=-1; i<=2; i++)
                    {
                        if (((xi+i)>=0) && ((xi+i)<X)) V[i+1]=image[voxel+i];
                        else V[i+1]=0.0;
                    }
                    Ix[j+1]=CubicPolynomialInterpolation(V, (1.0+(x-xi)));
                    //Ix[j+1]=SmoothCurveFit(V, 4, (1.0+(x-xi))/3.0);
                }
                else Ix[j+1]=0.0;
            }
            Iy[k+1]=CubicPolynomialInterpolation(Ix, (1.0+(y-yi)));
            //Iy[k+1]=SmoothCurveFit(Ix, 4, (1.0+(y-yi))/3.0);
        }
        else Iy[k+1]=0.0;
    }
    Ixyz=CubicPolynomialInterpolation(Iy, (1.0+(z-zi)));
    //Ixyz=SmoothCurveFit(Iy, 4, (1.0+(z-zi))/3.0);


    return (float)Ixyz;
}




//==============================================================================
//                         is voxel in image matrix?
//==============================================================================
int InImageRange(int x,int y,int z, int X, int Y, int Z)
{
    if ((x>=0) && (x<X) && (y>=0) && (y<Y) && (z>=0) && (z<Z)) return 1;
    return 0;
}




//==============================================================================
//					Index to 6 nearest neighbours
//					So neighbour {x,y,z} must have |x| + |y| + |z| = 1 to be valid
//                  returns 1-6 if valid
//                  returns 0 if not valid
//==============================================================================
int IndexToNearestNeighbour(int i, int j, int k)
{

    static int lu[3][3][3];
    static int first=1;
    int x,y,z,count;

    if ((abs(i) + abs(j) + abs(k))!=1) return 0;

    if (first)
    {
        count=0;//start at volume 0
        for (z=-1; z<=1; z++)
        {
            for (y=-1; y<=1; y++)
            {
                for (x=-1; x<=1; x++)
                {
                    if ((abs(x) + abs(y) +	abs(z))==1)
                    {
                        count++;
                        lu[x+1][y+1][z+1]=count;
                    }
                    else lu[x+1][y+1][z+1]=0;
                }
            }
        }
        first=0;
    }

    return lu[i+1][j+1][k+1];
}
//==============================================================================
//					Vector to neighbours in 6 nearest neighbourhood
//                  index must be between 1 and 6
//==============================================================================
int DirectionFromIndexToNearestNeighbour(int index, int *x, int *y, int *z)
{

    static int xn[6], yn[6], zn[6];
    static int first=1;
    int i,j,k,l;


    //get the lookup only on first entry to the function
    if (first)
    {

        for (k=-1; k<=1; k++)
        {
            for (j=-1; j<=1; j++)
            {
                for (i=-1; i<=1; i++)
                {
                    if ((abs(i) + abs(j) + abs(k))==1)
                    {
                        if ((l=IndexToNearestNeighbour(i, j, k)))
                        {
                            xn[l-1]=i;
                            yn[l-1]=j;
                            zn[l-1]=k;
                        }
                    }
                }
            }
        }
        first=0;
    }

    if ((index<=0) || (index>6))
    {
        (*x)=0;
        (*y)=0;
        (*z)=0;
        return 0;
    }

    (*x)=xn[index-1];
    (*y)=yn[index-1];
    (*z)=zn[index-1];

    return 1;
}







//==============================================================================
//					Index to neighbours in 5x5x5 neighbourhood
//					Cant use degenerate neighbours
//					So neighbour {x,y,z} must have |x| OR |y| OR |z| = 1
//                  returns -1 if neighbour voxel<voxel; only works for forward voxels
//==============================================================================
int IndexToNeighbour555(int i, int j, int k)
{

    static int lu[5][5][5];
    static int first=1;
    int x,y,z,l,count;

    if (first)
    {
        count=0;//start at volume 0
        for (z=-2; z<=2; z++)
        {
            for (y=-2; y<=2; y++)
            {
                for (x=-2; x<=2; x++)
                {
                    l=x+y*5+z*25;//neighbours with greater voxel numbers only needed; l>0
                    lu[x+2][y+2][z+2]=-1;
                    if ((l>0) && (abs(x)==1 || abs(y)==1 || abs(z)==1))
                    {
                        lu[x+2][y+2][z+2]=count;
                        count++;
                    }
                }
            }
        }

        first=0;
    }

    if ((abs(i)>2) || (abs(j)>2) || (abs(k)>2)) return -1;
    return lu[i+2][j+2][k+2];
}




//==============================================================================
//					Vector to neighbours in 5x5x5 neighbourhood
//					Cant use degenerate neighbours
//					So neighbour {x,y,z} must have |x| OR |y| OR |z| = 1
//==============================================================================
int DirectionFromIndex555(int index, int *x, int *y, int *z)
{

    static int xn[125], yn[125], zn[125];
    static int first=1;
    static int neighbours;
    int i,j,k;


    //get the lookup only on first entry to the function
    if (first)
    {
        neighbours=0;
        for (k=-2; k<=2; k++)
        {
            for (j=-2; j<=2; j++)
            {
                for (i=-2; i<=2; i++)
                {
                    if (((abs(i)==1) || (abs(j)==1) || (abs(k)==1)) && (neighbours<125))
                    {
                        xn[neighbours]=i;
                        yn[neighbours]=j;
                        zn[neighbours]=k;
                        neighbours++;
                    }
                }
            }
        }
        first=0;
    }

    if ((index<0) || (index>=neighbours))
    {
        (*x)=0;
        (*y)=0;
        (*z)=0;
        return 0;
    }

    (*x)=xn[index];
    (*y)=yn[index];
    (*z)=zn[index];

    return 1;
}






//==============================================================================
//                  Histogram Equalisation
//                  Processes *image by equalising the histogram of intensities
//                  Best if the noisy background is removed first
//18/07/2010
//==============================================================================
int HistogramEqualiseImage(struct Image *image)
{

    int result=0;
    int X, Y, Z, voxels, voxel;
    int i;
    struct Hist hist;
    unsigned char *mask=NULL;

    if (!IsImageScalar((*image).DataType)) return 0;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;


    //compute the mask
    if (!(mask=(unsigned char *)malloc(voxels))) goto END;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]) mask[voxel]=1;
        else mask[voxel]=0;
    }


    //the standardised histogram
    memset(&hist,0,sizeof(struct Hist));
    if (!GetStandardizedHistogram((*image).img, mask, X, Y, Z, (*image).scale, (*image).offset,
                                  (*image).DataType, &hist, 0.00001)) goto END;

    //compute cdf
    for (i=1; i<hist.N; i++)
    {
        hist.H[i]+=hist.H[i-1];
    }



    //convert intensities
    if (!hist.binwidth) goto END;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]>0.0)
        {
            i=(int)(( (*image).img[voxel]-hist.min )/hist.binwidth + 0.5);
            if ((i>0) && (i<hist.N))(*image).img[voxel]=hist.max*hist.H[i]/hist.count;
        }
    }



END:
    if (mask) free(mask);
    if (hist.H) free(hist.H);

    return result;
}






//==============================================================================
//                         computes a standardized histogram
//                         widthfraction (0<=widthfraction<=1) controls how many bins to use
//                         mask limits the voxels included in the histogram
//                         returns the number of voxels included
//                         on output (*hist).min + i*(*hist).binwidth + (*hist).binwidth/2
//                              maps the intensities back to the image intensities
//==============================================================================
int GetStandardizedHistogram(float *image, unsigned char mask[], int X, int Y, int Z, float scale, float offset,
                             int DataType, struct Hist *hist, float widthfraction)
{

    int voxels;
    int voxel;
    int i;
    float FullWidth;
    float I;
    //char txt[256];

    (*hist).count=0;
    (*hist).N=0;

    if (!IsImageScalar(DataType)) return 0;

    if (widthfraction<=0.0) return 0;


    //the highest bin number, as a function of binwidth
    (*hist).N=(int)(1.0/widthfraction+0.5);
    if (((*hist).N)<=1)  return 0;

    voxels=X*Y*Z;

    //get the min non-zero intensity
    (*hist).min=FLT_MAX;
    (*hist).max=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        I=image[voxel];
        if (mask[voxel] && (I>0.0))
        {
            if (I<(*hist).min)   (*hist).min=I;
            if (I>(*hist).max)   (*hist).max=I;
        }
    }
    if ((*hist).min==(*hist).max) (*hist).min-=1.0;

    FullWidth=(*hist).max-(*hist).min;//defined by max and min in masked region


    (*hist).binwidth=FullWidth/((*hist).N-1);


    (*hist).H=(int *)malloc(sizeof(int)*((*hist).N));
    if (!((*hist).H)) return 0;

    memset((*hist).H,0,sizeof(int)*((*hist).N));


    for (voxel=0; voxel<voxels; voxel++)
    {
        if (mask[voxel] && image[voxel])
        {
            i=(int)((image[voxel]-(*hist).min)/(*hist).binwidth + 0.5);//i is the bin
            if ((i>=0) && (i<(*hist).N))
            {
                (*hist).count++;
                (*hist).H[i]++;
            }
        }
    }


    (*hist).scale=scale;
    (*hist).offset=offset;

    return (*hist).count;
}





//==============================================================================
//Finds the object connected to {x0,y0,z0} in bin
//can be fairly fast, but use lots of memory
//bin is zero outside the object after finishing
//return value is the number of voxels in the found object
//==============================================================================
#define CONNECTED 6
int ConnectedObject(unsigned char bin[], int X, int Y, int Z, int x0, int y0, int z0)
{

    struct KeepTrack *track=NULL;
    int voxel, voxel_n, total_voxels=X*Y*Z, XY=X*Y;
    int x[6]= {-1,1,0,0,0,0};
    int y[6]= {0,0,-1,1,0,0};
    int z[6]= {0,0,0,0,-1,1};
    int found;
    int size=0;


    if (!InImageRange(x0,y0,z0,X,Y,Z)) return 0;

    if ( !(track=(struct KeepTrack *)malloc(X*Y*Z*sizeof(struct KeepTrack))) ) return 0;
    memset(track,0,X*Y*Z*sizeof(struct KeepTrack));

    voxel=x0+y0*X+z0*XY;
    track[voxel].PrevVoxel=voxel;
    do
    {
        found=0;
        do
        {
            voxel_n=voxel + x[track[voxel].index] + y[track[voxel].index]*X + z[track[voxel].index]*XY;
            XYZfromVoxelNumber(voxel_n, &x0, &y0, &z0, X, Y, Z);
            if (InImageRange(x0,y0,z0,X,Y,Z))
            {
                if (bin[voxel_n] && (!track[voxel_n].index)) found=1;
            }
            track[voxel].index++;
        }
        while(track[voxel].index<CONNECTED && (!found));

        if (found)
        {
            track[voxel_n].PrevVoxel=voxel;
            voxel=voxel_n;
        }
        else voxel=track[voxel].PrevVoxel;
    }
    while(!((track[voxel].PrevVoxel==voxel) && (track[voxel].index>=CONNECTED)));

    size=0;
    for (voxel=0; voxel<total_voxels; voxel++)
    {
        if (!track[voxel].index) bin[voxel]=0;
        else if (bin[voxel]) size++;
    }

    if (track) free(track);

    return size;

}








//======================================================================================================
//                         Compute the x,y,z coordinates from voxel index
//======================================================================================================
int ComputeXYZfromVoxel(struct Image *image, int voxel, int *x, int *y, int *z)
{

    if ( !((*image).X) || !((*image).Y) ) return 0;

    (*z)=voxel/( (*image).X*(*image).Y );
    (*y)=(voxel-(*z)*(*image).X*(*image).Y)/(*image).X;
    (*x)=voxel - (*y)*(*image).X - (*z)*(*image).X*(*image).Y;

    return 1;
}


//==============================================================================
//                  voxel is the target
//                  x, y, z contain the target voxel coordinates on exit
//==============================================================================
int XYZfromVoxelNumber(int voxel, int *x, int *y, int *z, int X, int Y, int Z)
{

    int XY;
    int zXY;
    int tmp;

    if ( (!X) || (!Y) ) return 0;

    XY=X*Y;

    (*z)=voxel/(XY);
    zXY=(*z)*XY;
    (*y)=(tmp=voxel - zXY)/X;
    // (*x)=voxel - (*y)*X - zXY;
    (*x)=tmp - (*y)*X;

    //if (((*x)+(*y)*X+(*z)*X*Y)!=voxel) MessageBox(NULL,"Error","",MB_OK);

    return 1;
}





int OffEdge2DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z);
int OnEdge2DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z);
//==============================================================================
//                  Dilate the binary image
//==============================================================================
int DilateImage2D(unsigned char bin[], int X, int Y, int Z)
{

    int x, y, z;
    int voxel;
    unsigned char *tmp;

    tmp=(unsigned char *)malloc(X*Y*Z);

    if (!tmp) return 0;

    memcpy(tmp,bin,X*Y*Z);
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ((!bin[voxel]) && OffEdge2DEx(bin, x,y,z, X, Y, Z)) tmp[voxel]=1;
                voxel++;
            }
        }
    }
    memcpy(bin,tmp,X*Y*Z);

    free(tmp);

    return 1;
}
//==============================================================================
//                  Erode the binary image
//==============================================================================
int ErodeImage2D(unsigned char bin[], int X, int Y, int Z)
{

    int x, y, z;
    int voxel;
    unsigned char *tmp;

    tmp=(unsigned char *)malloc(X*Y*Z);

    if (!tmp) return 0;

    memcpy(tmp,bin,X*Y*Z);
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ((bin[voxel]) && OnEdge2DEx(bin, x,y,z, X, Y, Z)) tmp[voxel]=0;
                voxel++;
            }
        }
    }
    memcpy(bin,tmp,X*Y*Z);

    free(tmp);

    return 1;
}
//==============================================================================
//                  check if a voxel if off an edge; assuming it is a NULL voxel
//                  i.e. a neighbour is not NULL
//==============================================================================
int OffEdge2DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z)
{

    int i,j;
    int voxel, voxeln;

    voxel=x0 + y0*X + z0*X*Y;
    for (j=-1; j<=1; j++)
    {
        for (i=-1; i<=1; i++)
        {
            if ((i||j) && InImageRange(x0+i, y0+j, z0, X, Y, Z))
            {
                voxeln=voxel+i+j*X;
                if (binimg[voxeln]) return 1;
            }
        }
    }
    return 0;
}
//==============================================================================
//                  check if a voxel if an an edge; assuming it is a NULL voxel
//                  i.e. a neighbour is not NULL
//==============================================================================
int OnEdge2DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z)
{

    int i,j;
    int voxel, voxeln;

    voxel=x0 + y0*X + z0*X*Y;
    for (j=-1; j<=1; j++)
    {
        for (i=-1; i<=1; i++)
        {
            if ((i||j) && InImageRange(x0+i, y0+j, z0, X, Y, Z))
            {
                voxeln=voxel+i+j*X;
                if (!binimg[voxeln]) return 1;
            }
        }
    }
    return 0;
}
//==============================================================================
//                  Dilate the binary image
//==============================================================================
int DilateImage3D(unsigned char bin[], int X, int Y, int Z)
{

    int x, y, z;
    int voxel;
    unsigned char *tmp=NULL;

    tmp=(unsigned char *)malloc(X*Y*Z);

    if (!tmp) return 0;

    memcpy(tmp,bin,X*Y*Z);
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ((!bin[voxel]) && OffEdge3DEx(bin, x,y,z, X, Y, Z)) tmp[voxel]=1;
                voxel++;
            }
        }
    }
    memcpy(bin,tmp,X*Y*Z);

    free(tmp);

    return 1;
}

//==============================================================================
//                  Erode the binary image
//==============================================================================
int ErodeImage3D(unsigned char bin[], int X, int Y, int Z)
{

    int x, y, z;
    int voxel;
    unsigned char *tmp=NULL;

    tmp=(unsigned char *)malloc(X*Y*Z);

    if (!tmp) return 0;

    memcpy(tmp,bin,X*Y*Z);
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if (bin[voxel] && OnEdge3DEx(bin, x,y,z, X, Y, Z)) tmp[voxel]=0;
                voxel++;
            }
        }
    }
    memcpy(bin,tmp,X*Y*Z);


    free(tmp);

    return 1;
}

//==============================================================================
//                  check if a voxel if on an edge
//                  i.e. at least one neighbour is NULL
//==============================================================================
int OnEdge3D(int voxel, unsigned char binimg[], int X, int Y, int Z)
{

    int x[6]= {-1,1,0,0,0,0};
    int y[6]= {0,0,1,-1,0,0};
    int z[6]= {0,0,0,0,1,-1};
    int x0,y0,z0;
    int i,voxeln;
    int XY=X*Y;

    XYZfromVoxelNumber(voxel, &x0, &y0, &z0, X, Y, Z);

    for (i=0; i<6; i++)
    {
        if (InImageRange(x0+x[i], y0+y[i], z0+z[i], X, Y, Z))
        {
            voxeln=voxel+x[i]+y[i]*X+z[i]*XY;
            if (!binimg[voxeln]) return 1;
        }
    }
    return 0;
}
//==============================================================================
//                  check if a voxel if off an edge; assuming it is a NULL voxel
//                  i.e. a neighbour is not NULL
//==============================================================================
int OffEdge3D(int voxel, unsigned char binimg[], int X, int Y, int Z)
{

    int x[6]= {-1,1,0,0,0,0};
    int y[6]= {0,0,1,-1,0,0};
    int z[6]= {0,0,0,0,1,-1};
    int x0,y0,z0;
    int i,voxeln;
    int XY=X*Y;

    XYZfromVoxelNumber(voxel, &x0, &y0, &z0, X, Y, Z);

    for (i=0; i<6; i++)
    {
        if (InImageRange(x0+x[i], y0+y[i], z0+z[i], X, Y, Z))
        {
            voxeln=voxel+x[i]+y[i]*X+z[i]*XY;
            if (binimg[voxeln]) return 1;
        }
    }
    return 0;
}



//==============================================================================
//                  check if a voxel if on an edge
//                  i.e. at least one neighbour is NULL
//==============================================================================
int OnEdge3DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z)
{

    int x[6]= {-1,1,0,0,0,0};
    int y[6]= {0,0,1,-1,0,0};
    int z[6]= {0,0,0,0,1,-1};
    int i,voxel, voxeln;
    int XY=X*Y;

    voxel=x0 + y0*X + z0*XY;
    for (i=0; i<6; i++)
    {
        if (InImageRange(x0+x[i], y0+y[i], z0+z[i], X, Y, Z))
        {
            voxeln=voxel+x[i]+y[i]*X+z[i]*XY;
            if (!binimg[voxeln]) return 1;
        }
    }
    return 0;
}
//==============================================================================
//                  check if a voxel if off an edge; assuming it is a NULL voxel
//                  i.e. a neighbour is not NULL
//==============================================================================
int OffEdge3DEx(unsigned char binimg[], int x0, int y0, int z0, int X, int Y, int Z)
{

    int x[6]= {-1,1,0,0,0,0};
    int y[6]= {0,0,1,-1,0,0};
    int z[6]= {0,0,0,0,1,-1};
    int i,voxel, voxeln;
    int XY=X*Y;

    voxel=x0 + y0*X + z0*XY;

    for (i=0; i<6; i++)
    {
        if (InImageRange(x0+x[i], y0+y[i], z0+z[i], X, Y, Z))
        {
            voxeln=voxel+x[i]+y[i]*X+z[i]*XY;
            if (binimg[voxeln]) return 1;
        }
    }
    return 0;
}






//==============================================================================
//                  Remove background
//                  bin can be anything on entry
//                  bin is freed on exit
//==============================================================================
int RemoveNoisyBackground(float *image, int X, int Y, int Zpv, int volumes, float min)
{
    int result=0;
    int voxel, voxels;
    HCURSOR hourglass, PrevCursor;
    unsigned char *bin=NULL;

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    if (!volumes) return 0;


    if (!(bin=(unsigned char *)malloc(X*Y*Zpv))) goto END;


    voxels=X*Y*Zpv;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (image[voxel]>min) bin[voxel]=1;
        else bin[voxel]=0;
    }
    DilateImage3D(bin, X, Y, Zpv);                                         //fill the holes
    DilateImage3D(bin, X, Y, Zpv);
    DilateImage3D(bin, X, Y, Zpv);
    DilateImage3D(bin, X, Y, Zpv);

    ErodeImage3D(bin, X, Y, Zpv);
    ErodeImage3D(bin, X, Y, Zpv);
    ErodeImage3D(bin, X, Y, Zpv);
    ErodeImage3D(bin, X, Y, Zpv);

    for (voxel=0; voxel<voxels; voxel++)                                    //save result
    {
        if (!bin[voxel]) image[voxel]=0;
    }

    SetCursor(PrevCursor);
    result=1;
END:
    if (bin) free(bin);
    return result;
}


//==============================================================================
//                  Automatically remove background
//                  May not work, in which case use the
//                  manual method
//==============================================================================
#define THRESHOLD_CLASSES 4
int AutoRemoveNoisyBackground(HWND hwnd, struct Image *image, int brain)
{

    double means[THRESHOLD_CLASSES];
    int voxel,volume;
    int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int Zpv=(*image).Z/(*image).volumes;
    HCURSOR hourglass, PrevCursor;
    unsigned char *cl=NULL;
    float *tmp=NULL;
    int result=0;

    if (!IsImageScalar((*image).DataType)) return 0;

    hourglass=LoadCursor(NULL,IDC_WAIT);

    PrevCursor=SetCursor(hourglass);


    tmp=(float *)malloc(sizeof(float)*voxels);
    cl=(unsigned char *)malloc(voxels);


    if (cl && tmp)
    {

        memset(cl,1,voxels);
        memcpy(tmp,(*image).img,sizeof(float)*voxels);

        //GaussFilterFastEx(float image[], int X, int Y, int Z, float dx, float dy, float dz, double SD, int ThreeD)
        GaussFilterFastEx(tmp, (*image).X, (*image).Y, Zpv, (*image).dx, (*image).dy, (*image).dz, 4.0, 1);

        if (Fuzzy_cMeansClustering(tmp, cl, (*image).X, (*image).Y, Zpv, THRESHOLD_CLASSES, means, 100))
        {

            for (voxel=0; voxel<voxels; voxel++)
            {
                if (cl[voxel]==1) cl[voxel]=0;
            }

            if (brain) FindBrain(hwnd, cl, (*image).X, (*image).Y, Zpv);

            for (volume=0; volume<(*image).volumes; volume++)
            {
                for (voxel=0; voxel<voxels; voxel++)
                {
                    if (!(cl[voxel])) (*image).img[voxel+volume*voxels]=0.0;
                }
            }
        }
        result=1;

        free(tmp);
        free(cl);
    }

    SetCursor(PrevCursor);

    return result;
}



//==============================================================================
//                  Find the matrix limits based on intensity
//==============================================================================
struct MatrixLimits FindImageMatrixLimits(struct Image *image)
{

    struct MatrixLimits ml;
    int x,y,z, zv;
    int voxel;

    ml.x0=(*image).X;
    ml.x1=0;
    ml.y0=(*image).Y;
    ml.y1=0;


    //this may be faster
    for (x=0; x<(*image).X && ml.x0==(*image).X; x++)
    {
        for (z=0; z<(*image).Z && ml.x0==(*image).X; z++)
        {
            zv=z*(*image).X*(*image).Y;
            for (y=0; y<(*image).Y && ml.x0==(*image).X; y++)
            {
                voxel=x+y*(*image).X+zv;
                if ( (*image).img[voxel] ) ml.x0=x;
            }
        }
    }

    for (x=(*image).X-1; x>=0 && !ml.x1; x--)
    {
        for (z=0; z<(*image).Z && !ml.x1; z++)
        {
            zv=z*(*image).X*(*image).Y;
            for (y=0; y<(*image).Y && !ml.x1; y++)
            {
                voxel=x+y*(*image).X+zv;
                if ( (*image).img[voxel] ) ml.x1=x;
            }
        }
    }

    for (y=0; y<(*image).Y && ml.y0==(*image).Y; y++)
    {
        for (z=0; z<(*image).Z && ml.y0==(*image).Y; z++)
        {
            zv=z*(*image).X*(*image).Y;
            for (x=0; x<(*image).X && ml.y0==(*image).Y; x++)
            {
                voxel=x+y*(*image).X+zv;
                if ( (*image).img[voxel] ) ml.y0=y;
            }
        }
    }

    for (y=(*image).Y-1; y>=0 && !ml.y1; y--)
    {
        for (z=0; z<(*image).Z && !ml.y1; z++)
        {
            for (x=0; x<(*image).X && !ml.y1; x++)
            {
                voxel=x+y*(*image).X+z*(*image).X*(*image).Y;
                if ( (*image).img[voxel] ) ml.y1=y;
            }
        }
    }

    if (ml.x0>0) ml.x0--;
    if (ml.x1<(*image).X-1) ml.x1++;
    if (ml.y0>0) ml.y0--;
    if (ml.y1<(*image).Y-1) ml.y1++;

    ml.valid=1;

    return ml;
}















//==============================================================================
//                Centre of intensity and deviation
//==============================================================================
int GetCentreOfImageIntensityUS(unsigned char image[], int X, int Y, int Z, double *x0, double *xSD, double *y0, double *ySD, double *z0, double *zSD)
{

    int result=0;
    int voxel, x,y,z;
    double s,g;

    (*x0)=(*y0)=(*z0)=0.0;
    (*xSD)=(*ySD)=(*zSD)=0.0;

    //find the centre of intensity
    voxel=0;
    s=0.0;
    (*x0)=(*y0)=(*z0)=0.0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {

                if ( (g=(double)image[voxel]) )
                {
                    s+=g;
                    (*x0)+=g*x;
                    (*y0)+=g*y;
                    (*z0)+=g*z;
                }

                voxel++;
            }
        }
    }
    if (s)
    {
        (*x0)/=s;
        (*y0)/=s;
        (*z0)/=s;
    }
    else goto END;

    //find the standard deviations
    voxel=0;
    (*xSD)=(*ySD)=(*zSD)=0.0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {

                if ( (g=(double)image[voxel]) )
                {
                    (*xSD)+=g*(x-(*x0))*(x-(*x0));
                    (*ySD)+=g*(y-(*y0))*(y-(*y0));
                    (*zSD)+=g*(z-(*z0))*(z-(*z0));
                }

                voxel++;
            }
        }
    }


    if ((*xSD)/s>=0.0) (*xSD)=sqrt( (*xSD)/s );
    if ((*ySD)/s>=0.0) (*ySD)=sqrt( (*ySD)/s );
    if ((*zSD)/s>=0.0) (*zSD)=sqrt( (*zSD)/s );

    result=1;
END:
    return result;
}



//==============================================================================
//                Centre of intensity and deviation
//==============================================================================
int GetCentreOfImageIntensityF(float image[], int X, int Y, int Z, double *x0, double *xSD, double *y0, double *ySD, double *z0, double *zSD)
{

    int result=0;
    int voxel, x,y,z;
    double s,g;

    (*x0)=(*y0)=(*z0)=0.0;
    (*xSD)=(*ySD)=(*zSD)=0.0;

    //find the centre of intensity
    s=0.0;
    (*x0)=(*y0)=(*z0)=0.0;
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ( (g=(double)image[voxel]) )
                {
                    s+=g;
                    (*x0)+=g*x;
                    (*y0)+=g*y;
                    (*z0)+=g*z;
                }
                voxel++;
            }
        }
    }
    if (s)
    {
        (*x0)/=s;
        (*y0)/=s;
        (*z0)/=s;
    }
    else goto END;

    //find the standard deviations
    (*xSD)=(*ySD)=(*zSD)=0.0;
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ( (g=(double)image[voxel]) )
                {
                    (*xSD)+=g*pow((x-(*x0)),2);
                    (*ySD)+=g*pow((y-(*y0)),2);
                    (*zSD)+=g*pow((z-(*z0)),2);
                }
                voxel++;
            }
        }
    }


    if ((*xSD)/s>=0.0) (*xSD)=sqrt( (*xSD)/s );
    if ((*ySD)/s>=0.0) (*ySD)=sqrt( (*ySD)/s );
    if ((*zSD)/s>=0.0) (*zSD)=sqrt( (*zSD)/s );

    result=1;
END:

    return result;
}









//==============================================================================
//  CONVERT MNI TO TAL SPACE
//http://www.brainmap.org/icbm2tal/icbm_spm2tal.m
//from paper Bias Between MNI and Talairach Coordinates Analyzed Using the ICBM-152 Brain Template
//Human Brain Mapping 28:1194�1205 (2007)
///CHANGED 16/05/2017 TO USE AVERAGE TRANSFORM SUITABLE FOR BOTH SPM AND FSL
///PERVIOUSLY USED SPM TRANSFORM FROM PAPER
//==============================================================================
int MNI2TAL(float *x, float *y, float *z)
{
    /*double M[16]= {0.9254,     0.0024,   -0.0118,    -1.0207,
                   -0.0048,   0.9316,   -0.0871,    -1.7667,
                   0.0152,    0.0883,    0.8924,     4.0926,
                   0.0000,    0.0000,    0.0000,     1.0000
                  };*/

    double M[16]= {0.9357,     0.0029,   -0.0072,    -1.0423,
                   -0.0065,    0.9396,   -0.0726,    -1.394,
                   0.0103,    0.0752,    0.8967,     3.6475,
                   0.0000,    0.0000,    0.0000,     1.0000
                  };

    double V[3];
    int i;

    for (i=0; i<3; i++)
    {
        V[i]=M[4*i]*(*x) + M[4*i+1]*(*y) + M[4*i+2]*(*z) + M[4*i+3];
    }
    (*x)=V[0];
    (*y)=V[1];
    (*z)=V[2];
    return 1;
}



//================================================================================
//NORMALISE IMAGE B SO ITS INTENSITIES ARE MOST LIKE THOSE OF IMAGE A
//THE IMAGES NEED TO BE IN THE SAME SPACE
//THEY SHOULD BE THE SAME TYPE (T2, T1...)
//do this by approximating a gain (G(x,y,z)) using a smoothed ratio of A & B
//SO WE SOLVE Ia=G(x,y,z)Ib
//================================================================================

double NormalizeIntensity(struct Image *A, struct Image *B)
{
    double sd=0.0;
    double m,c;
    double *y=NULL;
    double *x=NULL;
    double pa,pb;
    double sum,sum2;
    double dif;
    int i,N;
    int X,Y,Z;
    int voxel, voxels;


    X=(*A).X;
    Y=(*A).Y;
    Z=(*A).Z;
    voxels=X*Y*Z;

    if ((X!=(*B).X) || (Y!=(*B).Y) || (Z!=(*B).Z)) goto END;

    //-------Simple Linear Regression Normalisation----------
    //Ia = m*Ib + c
    N=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*A).img[voxel]>0.0) && ((*B).img[voxel]>0.0) ) N++;

    }

    if (!(x=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(y=(double *)malloc(N*sizeof(double)))) goto END;

    i=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((i<N) && ((*A).img[voxel]>0.0) && ((*B).img[voxel]>0.0) )
        {
            y[i] = (*A).img[voxel];
            x[i] = (*B).img[voxel];
            i++;
        }
    }
    SimpleLinearRegression(y, x, N, &c, &m, &pa, &pb);


    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((*A).img[voxel]>0.0) && ((*B).img[voxel]>0.0)) (*B).img[voxel] = (*B).img[voxel]*m + c;
    }

    sum=sum2=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*A).img[voxel]>0.0) && ((*B).img[voxel]>0.0) )
        {
            dif = (*A).img[voxel] - (*B).img[voxel];
            sum += dif;
            sum2 += dif*dif;
        }
    }
    if ( (sum2/N - sum*sum/N/N)>0.0 ) sd=sqrt(sum2/N - sum*sum/N/N);
    else sd=0.0;


END:
    if (x) free(x);
    if (y) free(y);

    return sd;
}




//======================================================================================================
//                         Save a bitmap to filename
///WIDTH MUST BE A MULTIPLE OF 4
//======================================================================================================
int SaveGreybitmap(char fname[], int width, int height, HWND hwndMain, unsigned char *pix){

    int pixels=width*height;
    int x,y;
    int I;
	HDC hDC=GetDC(hwndMain);
	HDC chDC=CreateCompatibleDC(hDC);
	HBITMAP hBitmap,hOldbmp;
	BITMAPFILEHEADER BmFileHdr;
	BITMAPCOREHEADER BmCoreHdr;
	BITMAPINFOHEADER BmInfoHdr;
	unsigned char  *pBits ;
	FILE *fp;


	//File header structure
	memset(&BmFileHdr,0,sizeof(BITMAPFILEHEADER));
	BmFileHdr.bfType=0x4D42;//=BM
	BmFileHdr.bfSize=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + 3*pixels;
	BmFileHdr.bfOffBits=sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

	//Core header structure
	memset(&BmCoreHdr,0,sizeof(BITMAPCOREHEADER));
	BmCoreHdr.bcSize=sizeof(BITMAPCOREHEADER);
	BmCoreHdr.bcWidth=width;
	BmCoreHdr.bcHeight=height;
	BmCoreHdr.bcPlanes=1;
	BmCoreHdr.bcBitCount=24;

	//Bitmap info header
	memset(&BmInfoHdr,0,sizeof(BITMAPINFOHEADER));
	BmInfoHdr.biWidth=width;
	BmInfoHdr.biHeight=height;
	BmInfoHdr.biSize=sizeof(BITMAPINFOHEADER);
	BmInfoHdr.biPlanes=1;
	BmInfoHdr.biBitCount=24;
	BmInfoHdr.biCompression=BI_RGB;

	//Create the DIB bitmap section
	hBitmap = CreateDIBSection (NULL, (BITMAPINFO *)  &BmInfoHdr, 0, (void *)&pBits, NULL, 0) ;
	hOldbmp = SelectObject(chDC, hBitmap);


    //draw the bitmap
    for (y=0;y<height;y++)
    {
        for (x=0;x<width;x++)
        {
            I=pix[x+y*width];
            SetPixel(chDC, x, y,RGB(I, I, I));
        }
    }


    BitBlt(hDC, 0, 0, width, height, chDC, 0, 0, SRCCOPY);
	SelectObject(chDC, hOldbmp);

	//Now save the bitmap file
	if ( (fp=fopen(fname,"wb")) ) {
		fwrite(&BmFileHdr,1,sizeof(BITMAPFILEHEADER),fp);
		fwrite(&BmInfoHdr,1,sizeof(BITMAPINFOHEADER),fp);
		fwrite(pBits,1,3*pixels,fp);
		fclose(fp);
		}



	SendMessage(hwndMain, WM_COMMAND, ID_REDRAW,1);

	DeleteObject(hBitmap);
	ReleaseDC(hwndMain, hDC);
	DeleteDC(chDC);

	return 1;
}
int TestSaveGreybitmap(HWND hwnd)
{
    unsigned char pix[400];
    int i,j;
    char fname[MAX_PATH];

    memset(pix,0,400);
    for (i=0;i<20;i+=2)
    {
        for (j=0;j<20;j+=2)
        {
            pix[i+j*20]=255;
        }
    }

    sprintf(fname,"%s/testbitmap.bmp",REPORT_FOLDER);
    SaveGreybitmap(fname, 20,20, hwnd, pix);

    return 0;
}



