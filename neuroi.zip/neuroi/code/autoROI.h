/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(AutoROI_H)
//Do Nothing
#else

#define AutoROI_H
//--------------------------------------------------------------------------------------------
//                              routines for Auto ROIs
//                              12th Mar 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>

#include "display.h"



HWND hAutoROI;
INT_PTR CALLBACK AutoROIsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int DrawCurrentAutoROI(struct Picture *picture, HDC hDC, float dx, float dy);






#endif
