/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "templatefunctions.h"
#include "display.h"
#include "coregister.h"
#include "imageprocess.h"
#include "numerical.h"
#include "menuresources.h"
#include "polynomial.h"
#include "ROIs.h"
#include "global.h"


//there are 84 terms in the ^6 3D polynomial, including the constant term
//there are 56 terms in the ^5 3D polynomial, including the constant term
//there are 35 terms in the ^4 3D polynomial, including the constant term
//there are 20 terms in the ^3 3D polynomial, including the constant term
//there are 10 terms in the ^2 3D polynomial, including the constant term
#define P_ORDER 4   //polynomial order
#define P_TERMS 35  //number of polynomial terms
#define TERMS (P_TERMS+1) //need extra constant for GM


#define MAX_PRIORS 10
#define GAIN_ITERATIONS 5


double CorrectGainUsingClasses(HWND hwnd, struct Image *image, unsigned char *Probs, double param[]);
int IssolateBrainTissue(HWND hwnd, struct Image *image, unsigned char *Probs, int nPriors);
double GetGainFieldParametersNonParametric(HWND hwnd, struct Image *image, unsigned char *Probs,
        unsigned char *priors, int nPriors, double GainParameters[]);
double NormalisePriors(struct Image *priors, int N);
int Load_Template_WM_GM_CSF_priors(HWND hwnd, struct Image *Template, struct Image *priors);
int Load_Template_Brain(HWND hwnd, struct Image *brainstem);
int Load_Template_Brainstem(HWND hwnd, struct Image *brainstem);
unsigned char *RegisterPriors(struct Image *image, struct Image *priors, int Npriors, unsigned char *USpriors, double p[], int Nregparams);
//=============================================================================================
//               Register the image to the template brainstem
//              Needs the template directory to be set
//              New on 05/11/2019
//=============================================================================================
int TemplateBrainstemRegistration(HWND hwnd, struct Image *image)
{
    int result=0;
    struct Image Template;
    double parameters[MAX_REGISTRATION_PARAMETERS];
    //struct Image BrainStem;
    //unsigned char *mask=NULL;
    unsigned char dummy;
    //int voxel,voxels;



//NULL THE IMAGE STRUCTURES
    memset(&Template,0,sizeof(struct Image));
    //memset(&BrainStem,0,sizeof(struct Image));



//LOAD THE PRIORS
    if ( !(result=Load_Template_Brain(hwnd, &Template)) ) goto END;
    //voxels=Template.X*Template.Y*Template.Z/Template.volumes;

    /*if ( !(result=Load_Template_Brainstem(hwnd, &BrainStem)) ) goto END;

    //make the brainstem unsigned char mask
    if (!(mask=(unsigned char *)malloc(voxels))) goto END;
    for (voxel=0;voxel<voxels;voxel++)
    {
        if (BrainStem.img[voxel]) mask[voxel]=1;
        else mask[voxel]=0;
    }*/
    //FindBrain(hwnd,mask,Template.X,Template.Y,Template.Z/Template.volumes);

    InitialiseRegistrationParameters(parameters, MAX_REGISTRATION_PARAMETERS);
    RegisterTwoImagesP(hwnd,&Template, image, 	parameters, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);
    RegisterTwoImagesP(hwnd,&Template, image, 	parameters, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);
    RegisterTwoImagesP(hwnd,&Template, image, 	parameters, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);


    //RegisterTwoImagesP(hwnd,&Template, image, 	parameters, AFFINE12, 0.5, mask,1);

    ReformatMatchImage(Template.X, Template.Y, Template.Z/Template.volumes, Template.dx, Template.dy, Template.dz,
                       Template.x0, Template.y0, Template.z0, image, parameters, AFFINE12, ID_CUBIC);


    //Save the parameters for future use
    SaveParameters((*image).filename, parameters, AFFINE12, &Template);

    result=1;

END:
    //in case these images were not released
    ReleaseImage(&Template);
    //ReleaseImage(&BrainStem);
    //if (mask) free(mask);

    return result;
}
//=============================================================================================
//               Register the image to the template
//              Needs the template directory to be set
//              New on 31st July 2011
//=============================================================================================
int TemplateRegistration(HWND hwnd, struct Image *image)
{

    int result=0;
    struct Image Template;
    double parameters[AFFINE12];
    unsigned char dummy;



//NULL THE IMAGE STRUCTURES
    memset(&Template,0,sizeof(struct Image));




//LOAD THE TEMPLATE
    if ( !(result=Load_Template_Brain(hwnd, &Template)) ) goto END;

    InitialiseRegistrationParameters(parameters, AFFINE12);
    RegisterTwoImagesP(hwnd,&Template, image, 	parameters, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);


    ReformatMatchImage(Template.X, Template.Y, Template.Z/Template.volumes, Template.dx, Template.dy, Template.dz,
                       Template.x0, Template.y0, Template.z0, image, parameters, AFFINE12, ID_CUBIC);


    //Save the parameters for future use
    SaveParameters((*image).filename, parameters, AFFINE12, &Template);

    result=0;

END:
    //in case these images were not released
    ReleaseImage(&Template);


    return result;
}





//=========================================================================================
//				Given the probabilities, with the last being the prob of non brain tissue,
//				segment the brain tissue
//				It then classifies image into the different tissue classes
//CSF must be the second to last prior, and background must be the last prior
//=========================================================================================
int IssolateBrainTissue(HWND hwnd, struct Image *image, unsigned char *Probs, int nPriors)
{


    int voxel, voxels;
    int X, Y, Zpv;
    int prior;
    int max;
    int result=0;
    int size;
    float maxd;
    int Ndilations,i;
    unsigned char *mask=NULL;
//    FILE *fp=NULL;

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;

    ///need to know how many dilations to do, which depends on the largest voxel dimension
    maxd=(*image).dx;
    if ((*image).dy>maxd) maxd=(*image).dy;
    if ((*image).dz>maxd) maxd=(*image).dz;
    Ndilations=3.0/maxd;
    if (!Ndilations) Ndilations=1;

    if (!(mask=(unsigned char *)calloc(1,voxels))) goto END;

//ISSOLATE THE BRAIN
    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Getting tissue mask in function IssolateBrainTissue\n");fclose(fp);}
    for (voxel=0; voxel<voxels; voxel++)
    {
        max = 0;
        for (prior=1; prior<nPriors; prior++)
        {
            if (Probs[voxel+prior*voxels]>Probs[voxel+max*voxels]) max=prior;
        }

        if ((max<nPriors-2) && (Probs[voxel+max*voxels]>0.0) && ((*image).img[voxel]) ) mask[voxel]=1;//not including CSF or background
    }

    //smooth the mask a little
    for (i=1;i<=Ndilations;i++) DilateImage3D(mask, X, Y, Zpv);
    for (i=1;i<=Ndilations;i++) ErodeImage3D(mask, X, Y, Zpv);



    size=FindBrain(hwnd, mask, X, Y, Zpv);
    if (!size) goto END;

//CREATE THE CLASS IMAGE
    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Making class image in function IssolateBrainTissue\n");fclose(fp);}
    memset((*image).img, 0, sizeof(float)*voxels);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( mask[voxel] )
        {
            //fIND THE HIGHEST PROBABILITY, EXCLUDING NON BRAIN TISSUE
            max=0;
            for (prior=1; prior<nPriors-1; prior++)
            {
                if (Probs[voxel+prior*voxels]>Probs[voxel+max*voxels]) max=prior;
            }
            if (Probs[voxel+max*voxels]) (*image).img[voxel]=max+1;
        }
    }

    (*image).MaxIntensity=(float)nPriors;

    result=1;

END:
    if (mask) free(mask);

    return result;

}






#define HIST_MAX 1024
int BayesianClassifierNonParametric(struct Image *image, unsigned char *Priors, unsigned char *probs, int nPriors, int initialise);
int ComputeNonParametricDistributions(double Hist[], double min, double max, unsigned char probs[],
                                      struct Image *image, int nPriors);
double UpdateClassificationProbabilitiesNonParametric(double Hist[], double min, double max, struct Image *image,
        unsigned char *probs,  unsigned char *Priors, int nPriors);
int SmoothAndNormaliseHistogram(double H[], int nPriors);

//=============================================================================================
//                  Classify WM, CSF, GM using priors
//				Change compared to Ashburner: volume not used to update probabilities
//=============================================================================================
int CorrectInhomogeneityUsingTemplateNonParametric(HWND hwnd, struct Image *image, int classify)
{

    int result=0;
    int X, Y, Zpv,  voxels;
    int nPriors=4;
    int iter;
    float dx,dy,dz,x0,y0,z0,fovx,fovy,fovz;
    struct Image priors[4];
    struct Image brain;
    struct Image little;
    double change;
    double RegParams[MAX_REGISTRATION_PARAMETERS];
    double GainParameters[TERMS];
    unsigned char *Probs=NULL;
    unsigned char *USpriors=NULL;
    unsigned char dummy;
    HCURSOR hourglass, PrevCursor;
    //FILE *fp;



    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;



//NULL THE IMAGE STRUCTURES
    memset(&priors,0,sizeof(struct Image)*4);
    memset(&brain,0,sizeof(struct Image));
    memset(&little,0,sizeof(struct Image));


//GET A SMALL IMAGE TO DO PROCESSING ON
    if (!MakeCopyOfImage(image, &little)) goto END;
    ReSizeImage(&little, ((*image).dx<2.0) ? 2.0:(*image).dx, ((*image).dy<2.0) ? 2.0:(*image).dy, ((*image).dz<2.0) ? 2.0:(*image).dz);



//LOAD THE PRIORS
    if (!Load_Template_WM_GM_CSF_priors(hwnd, &brain, priors)) goto END;



//MAKE THE Probs IMAGE
    if (!(Probs=(unsigned char *)malloc(little.X*little.Y*little.Z/little.volumes*4))) goto END;


    InitialiseRegistrationParameters(RegParams, MAX_REGISTRATION_PARAMETERS);


    memset(GainParameters, 0, sizeof(double)*TERMS);
    iter=0;
    do
    {
        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Registering images in function CorrectInhomogeneityUsingTemplateNonParametric\n");fclose(fp);}
        RegisterTwoImagesP(hwnd, &little, &brain, RegParams, AFFINE12, PRE_PROCESS_SMOOTH, &dummy,0);
        if (!(USpriors=RegisterPriors(&little, priors, 4, USpriors, RegParams,AFFINE12))) goto END;

        //GET THE GAIN FIELD OF image
        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Computing gain field in function CorrectInhomogeneityUsingTemplateNonParametric\n");fclose(fp);}
        hourglass=LoadCursor(NULL,IDC_WAIT);
        PrevCursor=SetCursor(hourglass);
        change = GetGainFieldParametersNonParametric(hwnd, &little, Probs, USpriors, nPriors, GainParameters);
        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Change due to gain field=%f\n",change);fclose(fp);}
        //*********************************************
        iter++;
    }
    while(change && (iter<3));

    FreeROIMemory();


    fovx=little.dx*little.X;
    fovy=little.dy*little.Y;
    fovz=little.dz*little.Z/little.volumes;
    x0=fovx/2.0;
    y0=fovy/2.0;
    z0=fovz/2.0;

    CorrectPolynomialGain((*image).img, X, Y, Zpv,
                          dx, dy, dz, x0, y0, z0,
                          fovx, fovy, fovz, GainParameters, P_ORDER, P_TERMS);



//CLASSIFY THE IMAGE IF REQUIRED
    if (classify)
    {
        if (!(Probs=(unsigned char *)realloc(Probs,voxels*4))) goto END;
        memset(Probs, 0, voxels*4);
        RegisterTwoImagesP(hwnd, image, &brain, RegParams, MAX_REGISTRATION_PARAMETERS, PRE_PROCESS_SMOOTH, &dummy,0);
        if (!(USpriors=RegisterPriors(image, priors, 4, USpriors, RegParams,MAX_REGISTRATION_PARAMETERS))) goto END;
        BayesianClassifierNonParametric(image, USpriors, Probs, nPriors, 1);
        IssolateBrainTissue(hwnd, image, Probs, nPriors);
    }

    (*image).MaxIntensity=MaximumIntensity(image);

    SetCursor(PrevCursor);

    result=1;
END:
    ReleaseImage(&priors[0]);
    ReleaseImage(&priors[1]);
    ReleaseImage(&priors[2]);
    ReleaseImage(&priors[3]);
    ReleaseImage(&brain);
    ReleaseImage(&little);

    if (Probs) free(Probs);
    if (USpriors) free(USpriors);

    return result;
}

//==============================================================================
//     Compute the gain field parameters for an image using a low res copy
//     The gain field parameters are in p[] at the end
//==============================================================================
double GetGainFieldParametersNonParametric(HWND hwnd, struct Image *image, unsigned char *Probs,
        unsigned char *priors, int nPriors, double GainParameters[])
{

    int iter, i;
    int X, Y, Zpv;
    float dx, dy, dz;
    float x0,y0,z0,fovx,fovy,fovz;
    double p[TERMS];
    double change=0.0;
//    FILE *fp;

    memset(p,0,sizeof(double)*TERMS);
    p[0]=1.0;

    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    fovx=(*image).dx*(*image).X;
    fovy=(*image).dy*(*image).Y;
    fovz=(*image).dz*(*image).Z/(*image).volumes;
    x0=fovx/2.0;
    y0=fovy/2.0;
    z0=fovz/2.0;
    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;



    iter=0;
    do
    {

        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Classification in function GetGainFieldParametersNonParametric\n");fclose(fp);}
        BayesianClassifierNonParametric(image, priors, Probs, nPriors, 1);



        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Fitting polynomial in function GetGainFieldParametersNonParametric");fclose(fp);}
        FitClassPolynomialFlatConstrainedBayes((*image).img, Probs, dx, dy, dz, X, Y, Zpv,
                                               x0, y0, z0, fovx, fovy, fovz,
                                               p, P_ORDER, P_TERMS, 2);
        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"***DONE***\n");fclose(fp);}



        //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Correcting homogeneity in function GetGainFieldParametersNonParametric\n");fclose(fp);}
        change=CorrectPolynomialGain((*image).img, X, Y, Zpv,
                                     dx, dy, dz, x0, y0, z0,
                                     fovx, fovy, fovz, p, P_ORDER, P_TERMS);

        for (i=1; i<P_TERMS; i++) GainParameters[i] += p[i];

        iter++;
    }
    while ((iter<GAIN_ITERATIONS));



    /*    if ((fp=fopen("c:\\temp\\parameters.txt","w")))
        {
            for (i=0;i<TERMS;i++)
            {
                fprintf(fp,"%f\n",p[i]);
            }
            fclose(fp);
        }*/
    return change;

}

/*
//==============================================================================
//     Compute the gain field parameters for an image using a low res copy
//     The gain field parameters are in p[] at the end
//==============================================================================
double GetGainFieldParametersNonParametric(HWND hwnd, struct Image *image, unsigned char *Probs,
                                        struct Image *priors, int nPriors, double RegParam[], int Nparam)
{

    struct Image SmallImage, SmallCopy;
    int Svoxels;
    int iter;
    float targ_dx, targ_dy, targ_dz;
    float dx, dy, dz;
    float x0,y0,z0,fovx,fovy,fovz;
    double change=0.0;
    double p[TERMS];

    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;

    memset(&SmallImage, 0, sizeof(struct Image));
    if (!MakeCopyOfImage(image, &SmallImage)) goto END;
    targ_dx=(dx>3.0) ? dx:3.0;
    targ_dy=(dy>3.0) ? dy:3.0;
    targ_dz=(dz>3.0) ? dz:3.0;
    if ((targ_dx!=dx) || (targ_dy!=dy) || (targ_dz!=dz))
    {
        ReSizeImage(&SmallImage, targ_dx, targ_dy, targ_dz);
    }
    Svoxels=SmallImage.X*SmallImage.Y*SmallImage.Z/SmallImage.volumes;
    fovx=SmallImage.dx*SmallImage.X;
    x0=fovx/2.0;
    fovy=SmallImage.dy*SmallImage.Y;
    y0=fovy/2.0;
    fovz=SmallImage.dz*SmallImage.Z/SmallImage.volumes;
    z0=fovz/2.0;

    //try to smooth away the noise so that there will be less bias in the linear model
    //due to log transforming the data
    //FilterImage(&SmallImage, GAUSSIAN, 3.0);
    //AutoRemoveNoisyBackground(&SmallImage);

    memset(&SmallCopy, 0, sizeof(struct Image));
    if (!MakeCopyOfImage(&SmallImage, &SmallCopy)) goto END;

    BayesianClassifierNonParametric(&SmallImage, priors, Probs, nPriors, RegParam, Nparam, 1);


    iter=0;
    do
    {

        BayesianClassifierNonParametric(&SmallImage, priors, Probs, nPriors, RegParam, Nparam, 0);

        memcpy(SmallImage.img, SmallCopy.img, sizeof(float)*Svoxels);

        //FitClassPolynomialFlatConstrained(SmallImage.img, Probs, SmallImage.dx, SmallImage.dy, SmallImage.dz, SmallImage.X, SmallImage.Y, SmallImage.Z/SmallImage.volumes,
        //                             x0, y0, z0, fovx, fovy, fovz,
        //                             p, P_ORDER, P_TERMS, 3);

        //FitClassPolynomialBayes(SmallImage.img, Probs, SmallImage.dx, SmallImage.dy, SmallImage.dz, SmallImage.X, SmallImage.Y, SmallImage.Z/SmallImage.volumes,
        //                             x0, y0, z0, fovx, fovy, fovz,
        //                             p, P_ORDER, P_TERMS, 3)
        if (FitClassPolynomialFlatConstrainedBayes(SmallImage.img, Probs, SmallImage.dx, SmallImage.dy, SmallImage.dz, SmallImage.X, SmallImage.Y, SmallImage.Z/SmallImage.volumes,
                x0, y0, z0, fovx, fovy, fovz,
                p, P_ORDER, P_TERMS, 3))
        {
            change=CorrectPolynomialGain(SmallImage.img, SmallImage.X, SmallImage.Y, SmallImage.Z/SmallImage.volumes,
                                         SmallImage.dx, SmallImage.dy, SmallImage.dz, x0, y0, z0,
                                         fovx, fovy, fovz, p, P_ORDER, P_TERMS);
        }
        else change=0.0;

        iter++;
    }
    while ((iter<GAIN_ITERATIONS) && (change>0.0));

    CorrectPolynomialGain((*image).img, (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                          (*image).dx, (*image).dy, (*image).dz, x0, y0, z0,
                          fovx, fovy, fovz, p, P_ORDER, P_TERMS);


END:

    ReleaseImage(&SmallImage);
    ReleaseImage(&SmallCopy);

    return change;

}
*/

//=====================================================================================
//              Register the image to the template
//              to identify the brain tissue
//              Needs the template directory to be set
//              Needs a BrainMask.img to identify the brain
//=====================================================================================
int ExtractBrainByTemplateRegistrationNonParametric(HWND hwnd, struct Image *image, int RegParameters)
{

    struct Image original;
    int voxel,voxels;
    int volume;
    int X, Y, Zpv;
    int result=0;

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;

    memset(&original,0,sizeof(struct Image));

    if (!MakeCopyOfImage(image, &original)) goto END;


    //the original image may be multi volume. Reduce to just one volume
    if (original.volumes>1)
    {
        original.Z/=original.volumes;
        original.volumes=1;
    }

    //smoothing the image makes the brain ROI smooth
    //FilterImage(&original, GAUSSIAN, 1.0);

    if (Classify_WM_GM_CSF_NonParametric(hwnd, &original, 0, RegParameters))
    {

        for (volume=0; volume<(*image).volumes; volume++)
        {
            for (voxel=0; voxel<voxels; voxel++)
            {
                if (!original.img[voxel]) (*image).img[voxel+volume*voxels]=0.0;
            }
        }
    }

    result=1;
END:
    ReleaseImage(&original);

    return result;
}


//=============================================================================================
//                  Classify WM, CSF, GM using priors
//				Change compared to Ashburner: volume not used to update probabilities
//=============================================================================================
int Classify_WM_GM_CSF_NonParametric(HWND hwnd, struct Image *image, int ReturnProbs, int RegParameters)
{

    int result=0;
    int X, Y, Zpv, voxel, voxels;
    int nPriors=4;
    struct Image priors[4];//WM, GM, CSF, NonBrain
    struct Image Template;
    double RegParams[MAX_REGISTRATION_PARAMETERS];
    unsigned char *Probs=NULL;
    unsigned char *USpriors=NULL;
    unsigned char dummy;
    HCURSOR hourglass, PrevCursor;
//    FILE *fp;

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;




//NULL THE IMAGE STRUCTURES
    memset(&priors,0,sizeof(struct Image)*nPriors);
    memset(&Template,0,sizeof(struct Image));



//LOAD THE PRIORS
    if ( (!Load_Template_WM_GM_CSF_priors(hwnd, &Template, priors)) ) goto END;



//GET THE TRANSFORMATION MATRIX
    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Registering images in function Classify_WM_GM_CSF_NonParametric\n");fclose(fp);}
    InitialiseRegistrationParameters(RegParams, MAX_REGISTRATION_PARAMETERS);
    RegisterTwoImagesP(hwnd, image, &Template, RegParams, RegParameters, PRE_PROCESS_SMOOTH, &dummy,0);


//ALLOCATE MEMORY FOR THE PRIORS AS UNSIGNED CHARS
    if (!(USpriors=RegisterPriors(image, priors, nPriors, USpriors, RegParams,RegParameters))) goto END;


//MAKE THE Probs IMAGE
    if (!(Probs=(unsigned char *)malloc(voxels*nPriors))) goto END;

    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Classification in function Classify_WM_GM_CSF_NonParametric\n");fclose(fp);}
    hourglass=LoadCursor(NULL,IDC_WAIT);
    PrevCursor=SetCursor(hourglass);
    BayesianClassifierNonParametric(image, USpriors, Probs, nPriors, 1);
    SetCursor(PrevCursor);


//ISSOLATE THE BRAIN
    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Issolating brain tissue in function Classify_WM_GM_CSF_NonParametric\n");fclose(fp);}
    IssolateBrainTissue(hwnd, image, Probs, nPriors);//dont include background prior


    if (ReturnProbs)
    {
        (*image).DataType=DT_FLOAT;
        if ( ((*image).img=(float *)realloc((*image).img, sizeof(float)*5*voxels)) )
        {
            for (voxel=0; voxel<voxels*nPriors; voxel++)
            {
                (*image).img[voxels + voxel]=(float)Probs[voxel]/255;
            }
            (*image).Z=5*Zpv;
            (*image).volumes=5;
            (*image).MaxIntensity=MaximumIntensity(image);
        }
        else
        {
            memset(image,0,sizeof(struct Image));
            goto END;
        }
    }


    result=1;
END:
    //in case these images were not released
    ReleaseImage(&Template);
    ReleaseImage(&priors[0]);
    ReleaseImage(&priors[1]);
    ReleaseImage(&priors[2]);
    ReleaseImage(&priors[3]);

    if (Probs) free(Probs);
    if (USpriors) free(USpriors);

    return result;
}

//=============================================================================================
//              Bayesian classifier as proposed by Ashburner & Friston
//              NEUROIMAGE 6, 209�217 (1997)
//				Uses multiple priors, not just WM, GM, CSF
//				Change compared to Ashburner: volume not used to update probabilities
//              Non parametric version uses histograms to represent the class intensity distributions
//=============================================================================================
int BayesianClassifierNonParametric(struct Image *image, unsigned char *Priors, unsigned char *probs, int nPriors, int initialise)
{

    int X, Y, Zpv;
    int voxel;
    int voxels;
    int prior;
    int iterations;
    int result=0;
    double initial;
    double *Hist=NULL;
    double min,max;

    if (nPriors>MAX_PRIORS) goto END;


    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;

    if(!(Hist=(double *)calloc(HIST_MAX*nPriors,sizeof(double)))) goto END;

    min=max=(*image).img[0];
    for (voxel=1; voxel<voxels; voxel++)
    {
        if (min>(*image).img[voxel]) min=(*image).img[voxel];
        if (max<(*image).img[voxel]) max=(*image).img[voxel];
    }


    //INITIALISE THE PROBABILITIES AS THE PRIORS
    if (initialise)
    {
        memset(probs,0,nPriors*voxels);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if ((*image).img[voxel])
            {
                for (prior=0; prior<nPriors; prior++)
                {
                    //AT FIRST THE PROBABILITIES COULD BE THE PRIORS
                    probs[voxel+prior*voxels]=Priors[voxel+prior*voxels];
                }
            }
        }
    }


    //UPDATE THE PROBABILITIES
    ComputeNonParametricDistributions(Hist, min, max, probs, image, nPriors);
    initial=UpdateClassificationProbabilitiesNonParametric(Hist, min, max, image, probs, Priors, nPriors);
    iterations=0;
    do
    {
        ComputeNonParametricDistributions(Hist, min, max, probs, image, nPriors);
        iterations++;
    }
    while ((iterations<5) && UpdateClassificationProbabilitiesNonParametric(Hist, min, max, image, probs, Priors, nPriors)>(initial/20.0));

    /*if ((fp=fopen("c:/temp/hist.txt","w")))
    {
        for (xi=0; xi<HIST_MAX; xi++)
        {
            fprintf(fp,"%d ",xi);
            for (prior=0; prior<nPriors; prior++)
            {
                fprintf(fp,"%f ",Hist[prior*HIST_MAX+xi]);
            }
            fprintf(fp,"\n");
        }
        fclose(fp);
    }*/


    result=1;
END:
    if (Hist) free(Hist);

    return result;
}

//=============================================================================================
//                         Compute the parameters
//Uses histograms to detail the intensity distributions for each class
//Probs has nPriors volumes
//=============================================================================================
int ComputeNonParametricDistributions(double Hist[], double min, double max, unsigned char probs[],
                                      struct Image *image, int nPriors)
{

    int X, Y, Zpv;
    int voxel, voxels;
    int prior;
    int priorXvoxels;
    int priorXHIST_MAX;
    int i;
    double prob;
    double g;
    float I;

    if (max<=min) return 0;
    g=(double)(HIST_MAX-1)/(max-min);

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;

    //HIST_MAX ENTRIES PER PRIOR
    memset(Hist,0,sizeof(double)*nPriors*HIST_MAX);

    //COMPUTE THE HISTOGRAMS
    priorXHIST_MAX=priorXvoxels=0;
    for (prior=0; prior<nPriors; prior++)
    {
        for (voxel=0; voxel<voxels; voxel++)
        {
            if ((I=(*image).img[voxel]))
            {
                i=(int)(0.5 + g*(I-min));

                if ((prob=(double)probs[voxel+priorXvoxels])>0.0)
                {
                    Hist[priorXHIST_MAX+i]+=prob/255.0;
                }

            }
        }
        priorXHIST_MAX+=HIST_MAX;
        priorXvoxels+=voxels;
    }

    SmoothAndNormaliseHistogram(Hist, nPriors);

    return 1;
}

//=============================================================================================
//             Update the probabilities
//There are nPriors means, followed by nPriors volumes, followed by nPriors variances
//=============================================================================================
double UpdateClassificationProbabilitiesNonParametric(double Hist[], double min, double max, struct Image *image,
        unsigned char *probs, unsigned char *Priors, int nPriors)
{

    int X, Y, Zpv, voxels;
    int voxel;
    int prior;
    int i;
    int priorindex,priorindex2;
    double Updates[MAX_PRIORS];
    double Ptotal;
    double change=0.0;
    float I;
    float p;


    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;


    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((I=(*image).img[voxel]))
        {
            i=(int)((double)(HIST_MAX-1)*(I-min)/(max-min) + 0.5);

            //FOR THIS VOXEL COMPUTE THE UN-NORMALISED UPDATES
            Ptotal=0.0;
            priorindex=priorindex2=0;
            for (prior=0; prior<nPriors; prior++)
            {
                p=Priors[priorindex +voxel];
                Updates[prior]=Hist[priorindex2+i]*p;
                Ptotal+=Updates[prior];
                priorindex+=voxels;
                priorindex2+=HIST_MAX;
            }

            //NOW NORMALISE THE PROBABILITY ESTIMATES
            if (Ptotal)
            {
                priorindex=0;
                for (prior=0; prior<nPriors; prior++)
                {
                    Updates[prior]/=Ptotal;
                    change+=fabs(Updates[prior]-(float)probs[voxel+priorindex]/255.0);
                    probs[voxel+priorindex]=255*Updates[prior];
                    priorindex+=voxels;
                }
            }
            else for (prior=0; prior<nPriors; prior++) probs[voxel+prior*voxels]=0;

        }
    }


    return change;
}
//===============================================================================
int SmoothAndNormaliseHistogram(double H[], int nPriors)
{

    //double mult;
    double norm[MAX_PRIORS];
    double Hsmooth[HIST_MAX];
    //double Hbak[3*HIST_MAX];
    int max[MAX_PRIORS];
    int iter, i, prior, o;
    //FILE *fp;
    //memcpy(Hbak,H,sizeof(double)*HIST_MAX*3);




    //first smooth the histograms
    for (iter=0; iter<2; iter++)
    {
        o=0;
        for (prior=0; prior<nPriors; prior++)
        {

            Hsmooth[0] = (H[0+o]+H[1+o])/2.0;

            norm[prior] = Hsmooth[0];

            max[prior] = 0;
            for (i=1; i<HIST_MAX-1; i++)
            {
                Hsmooth[i] = (H[i-1+o]+H[i+o]+H[i+1+o])/3.0;
                norm[prior] += Hsmooth[i];
                if (Hsmooth[i] > Hsmooth[max[prior]]) max[prior]=i;
            }

            Hsmooth[HIST_MAX-1] = (H[HIST_MAX-2+o]+H[HIST_MAX-1+o])/2.0;
            norm[prior] += Hsmooth[HIST_MAX-1];

            memcpy(&H[o],Hsmooth,HIST_MAX*sizeof(double));

            o+=HIST_MAX;
        }
    }

    o=0;
    for (prior=0; prior<nPriors; prior++)
    {
        norm[prior]=0.0;
        //mult=1.0;
        for (i=max[prior]; i<HIST_MAX; i++)
        {
            //H[i+o] *= mult;
            //if (H[i+o] <= 0.0) mult = 0.0;
            norm[prior] += H[i+o];
        }
        //mult=1.0;
        for (i=max[prior]-1; i>=0; i--)
        {
            //H[i+o] *= mult;
            //if (H[i+o] <= 0.0) mult=0.0;
            norm[prior] += H[i+o];
        }

        o+=HIST_MAX;
    }




    o=0;
    for (prior=0; prior<nPriors; prior++)
    {
        if (norm[prior])
        {
            for (i=0; i<HIST_MAX; i++)
            {
                H[o + i] /= norm[prior];
            }
        }
        o+=HIST_MAX;
    }

    /*
    fp=fopen("c:\\temp\\hist.csv","w");
    if (fp)
    {
    for (i=0; i<HIST_MAX; i++)
    {
        fprintf(fp,"%d,%f,%f,%f,%f,%f,%f\n",i,H[i],Hbak[i],H[i+HIST_MAX],Hbak[i+HIST_MAX],H[i+2*HIST_MAX],Hbak[i+2*HIST_MAX]);
    }
    fclose(fp);
    }
    */


    return 1;
}








//===============================================================================
//NORMALISE N PRIORS BY THE MAXIMUM SUM OVER THE N PRIORS
//THEN THE MAXIMUM SUM WILL BE 1
//===============================================================================
double NormalisePriors(struct Image *priors, int N)
{
    int prior;
    int voxel,voxels=priors[0].X*priors[0].Y*priors[0].Z;
    double max;
    double sum;

    max=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        sum=0.0;
        for (prior=0; prior<N; prior++) sum+=priors[prior].img[voxel];
        if (sum>max) max=sum;
    }
    if (max)
    {
        for (voxel=0; voxel<voxels; voxel++)
        {
            for (prior=0; prior<N; prior++)
            {
                priors[prior].img[voxel]/=max;
            }
        }
    }
    return max;
}


//===============================================================================
//LOAD THE TEMPLATE BRAINSTEM
//===============================================================================
int Load_Template_Brainstem(HWND hwnd, struct Image *brainstem)
{
    int result=0;
    char fname[MAX_PATH];
    int ImageFormat=0;


    sprintf(fname,"%s\\brainstem.img",gOptions.TemplateDir);
    if (LoadFromFileName(hwnd, fname, brainstem, 0))
    {
        ImageFormat=HDR;
    }
    else
    {
        sprintf(fname,"%s\\brainstem.nii",gOptions.TemplateDir);
        if (LoadFromFileName(hwnd, fname, brainstem, 0))
        {
            ImageFormat=NIFTI;
        }
    }

    if (!ImageFormat) goto END;



    result=1;
END:
    return result;
}


//===============================================================================
//LOAD THE TEMPLATE BRAIN ONLY
//===============================================================================
int Load_Template_Brain(HWND hwnd, struct Image *brainstem)
{
    int result=0;
    char fname[MAX_PATH];
    int ImageFormat=0;


    sprintf(fname,"%s\\brain.img",gOptions.TemplateDir);
    if (LoadFromFileName(hwnd, fname, brainstem, 0))
    {
        ImageFormat=HDR;
    }
    else
    {
        sprintf(fname,"%s\\brain.nii",gOptions.TemplateDir);
        if (LoadFromFileName(hwnd, fname, brainstem, 0))
        {
            ImageFormat=NIFTI;
        }
    }

    if (!ImageFormat) goto END;



    result=1;
END:
    return result;
}

//===============================================================================
//LOAD THE TEMPLATE, WM, GM, AND CSF PRIORS
//===============================================================================
int Load_Template_WM_GM_CSF_priors(HWND hwnd, struct Image *Template, struct Image *priors)
{
    int result=0;
    char fname[MAX_PATH];
    int ImageFormat=0;
    int voxel,voxels;
    int X,Y,Z;
    unsigned char *mask=NULL;





    sprintf(fname,"%s\\brain.img",gOptions.TemplateDir);
    if (LoadFromFileName(hwnd, fname, Template, 0))
    {
        ImageFormat=HDR;
    }
    else
    {
        sprintf(fname,"%s\\brain.nii",gOptions.TemplateDir);
        if (LoadFromFileName(hwnd, fname, Template, 0))
        {
            ImageFormat=NIFTI;
        }
    }

    if (!ImageFormat) goto END;


    if (ImageFormat==HDR) sprintf(fname,"%s\\white.img",gOptions.TemplateDir);
    else sprintf(fname,"%s\\white.nii",gOptions.TemplateDir);
    if (!LoadFromFileName(hwnd, fname, &priors[0], 0)) goto END;


    if (ImageFormat==HDR) sprintf(fname,"%s\\grey.img",gOptions.TemplateDir);
    else sprintf(fname,"%s\\grey.nii",gOptions.TemplateDir);
    if (!LoadFromFileName(hwnd, fname, &priors[1], 0)) goto END;



    if (ImageFormat==HDR) sprintf(fname,"%s\\csf.img",gOptions.TemplateDir);
    else sprintf(fname,"%s\\csf.nii",gOptions.TemplateDir);
    if (!LoadFromFileName(hwnd, fname, &priors[2], 0)) goto END;


    X=priors[0].X;
    Y=priors[0].Y;
    Z=priors[0].Z;
    voxels=X*Y*Z;

//NORMALISE THE PRIORS
//PRIORS NOW SUM TO A MAXIMUM OF 1.0
    NormalisePriors(priors, 3);

//COMPUTE THE SUM OF THE PROBABILITIES
    if (MakeCopyOfImage(&priors[0], &priors[3]))
    {
        for (voxel=0; voxel<voxels; voxel++)
        {
            priors[3].img[voxel] += priors[1].img[voxel];
            priors[3].img[voxel] += priors[2].img[voxel];
            if (priors[3].img[voxel]>1.0) priors[3].img[voxel]=1.0;
        }
    }
    else goto END;


//Get a mask of the definite brain tissue, then convert to background
    if ((mask=(unsigned char *)calloc(1,voxels)))
    {
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (priors[3].img[voxel]>=0.8) mask[voxel]=1;
        }
        FindBrain(hwnd, mask, X, Y, Z);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (mask[voxel]) priors[3].img[voxel]=0.0;
            else priors[3].img[voxel]=1.0-priors[3].img[voxel];
        }
        free(mask);
    }

    result=1;
END:
    return result;
}


//===============================================================================
//register the priors to image
//the result will be unsigned char priors in the image space
//the p[] provide the coordinate transform
//the unsigned priors (USprior) are malloced here when this function is called
//===============================================================================
unsigned char *RegisterPriors(struct Image *image, struct Image *priors, int Npriors, unsigned char *USpriors, double p[], int Nregparams)
{
    struct AffineMatrix M;
    int xi,yi,zi;
    int X,Y,Zpv;
    int voxel, voxels;
    int prior;
    float I,sum;
    float x0,y0,z0;
    float dx,dy,dz;
    float yf,zf;
    float x,y,z;
    float c[8];
    double *poly=NULL;
    int *polyorder=NULL;




    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels=X*Y*Zpv;

    dx=priors[0].dx;
    dy=priors[0].dy;
    dz=priors[0].dz;
    x0=dx*priors[0].X/2;
    y0=dy*priors[0].Y/2;
    z0=dz*priors[0].Z/priors[0].volumes/2;




    if (!(poly=(double *)malloc(sizeof(double)*MAX_REGISTRATION_PARAMETERS/3))) goto END;
    if (!(polyorder=(int *)malloc(MAX_REGISTRATION_PARAMETERS/3*sizeof(int)))) goto END;



    if (USpriors)
    {
        free(USpriors);
        USpriors=NULL;
    }
    if (!(USpriors=(unsigned char *)calloc(1,voxels*Npriors))) goto END;



    memset(&M,0,sizeof(struct AffineMatrix));
    if (Nregparams>RIGID6) M=AffineTransformationMatrix12param(p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11]);
    else if (Nregparams==RIGID6) M=AffineTransformationMatrix(p[0], p[1], p[2], p[3], p[4], p[5]);



    voxel=0;
    for (zi=0; zi<Zpv; zi++)
    {
        zf=(*image).dz*zi - (*image).dz*(*image).Z/(*image).volumes/2;
        for (yi=0; yi<Y; yi++)
        {
            yf=(*image).dy*yi - (*image).dy*(*image).Y/2;
            for (xi=0; xi<X; xi++)
            {
                x=(*image).dx*xi - (*image).dx*(*image).X/2;
                y=yf;
                z=zf;

                PolynomialRegressors3DTermOrderSorted(x,y,z,poly,polyorder,MAX_REGISTRATION_POLY_ORDER);
                GetTransformedVoxelCoordinates(&x, &y, &z, x0, y0, z0, dx, dy, dz, &M, p, poly, Nregparams);
                Lagrange3DCoefficients(x-(int)x, y-(int)y, z-(int)z, c);

                sum=0.0;
                for (prior=0; prior<Npriors; prior++)
                {
                    I = Lagrange3DA(priors[prior].img, priors[prior].X, priors[prior].Y, priors[prior].Z, (double)x, (double)y, (double)z, c);
                    USpriors[prior*voxels + voxel] = 255*I;
                    if (prior<Npriors-1) sum+=I;
                }
                if (sum==0.0) USpriors[(Npriors-1)*voxels + voxel] = 255;//if the priors are all zero, then the background is 255

                voxel++;
            }
        }
    }


END:
    if (poly) free(poly);
    if (polyorder) free(polyorder);

    return USpriors;
}


