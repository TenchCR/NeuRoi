/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(CBMAN_H)
//Do Nothing
#else

#define CBMAN_H

#include <windows.h>
#include <windowsx.h>
#include "loader.h"
#include "CBMAfiles.h"
#include "localALE.h"


struct BivariateSample
{
	short int Samples;
	double *d1;//effect sizes of sample 1
	double *d2;//effect sizes of sample 2
	double *V;//The within study variance 1/N.
	double *CensorLevel;//This is normalised absolute value and could be the minimum magnitude Z from a study, or a reported threshold, or other...
	short int *censor1;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
	short int *censor2;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
	double *LogLike;
	double p;//the p value
	double mean1;//bivariate parameters:
	double mean2;
	double var1;
	double var2;
	double rho;
	double rho2;
	float *covariate;
};


INT_PTR CALLBACK CBMAN_Dlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


double CBMAN(HWND hwnd,
             struct Image *image,
             double critical,
             struct Coordinates *Co,
             int CompareGroups,
             int MarkerSize,
             char directory[]) ;

int FillBivariateSampleStructure(struct BivariateSample *BV,
                                 struct Coordinates *Co,
                                 int cl1, int cl2,
                                 char directory[], int save);
double SaveNetworkResults(struct Image *image, HWND hwnd, struct Coordinates *Co, double Aij[], double Pmat[], int valid[], int Nclusters,
                          float xc[], float yc[], float zc[], double critical, char directoryCBMAN[], int MarkerSize);
int ConvertTalairachToProjection(double size, float xtal, float ytal, float ztal, int *x, int *y);
int IsBVvalid(struct BivariateSample *BV, int CompareGroups) ;
int MakeStructBivariateSample(struct BivariateSample *BV, int samples);
int FreeStructBivariateSample(struct BivariateSample *BV);
double NegativeBVNloglikelihood(double P[], int Nparameters, void *BVN);
double MaximumLogLikelihoodGivenStartingPoint(double P[], int parameters, struct BivariateSample *BV);
int GetInitialEstimates(double P[], struct BivariateSample *BV);
int FillEdgeMatrix(HWND hwnd, struct Coordinates *Co,
                   int Nclusters,
                   double Edges[],
                   int valid[],
                   double pvalue[],
                   int CompareGroups,
                   char directory[],
                   int save) ;

int TestFittingBivariateNorm(int Nstudies);
int TestBivariateNormalIntegration(void);
double PvalueOfConnectionUsingPermutation(double P[], struct BivariateSample *BV, int MaxPermutations, int MinSamplesToPermute);
///NEW CBclustering---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
int GetClusterCentres(struct Image *image, struct Coordinates *Co, float xc[], float yc[], float zc[],
                                                int MinimumExperiments, char directory[]);

int SaveSignificantClusterDensity(struct Image *image, struct Coordinates *Co, double pvalue, int MinStudies, char directory[]);
int SaveSignificantClusterMeanConnectivity(struct Image *image, struct Coordinates *Co, double pvalue, int Nstudies, double Aij[], int valid[], float xc[], float yc[], float zc[], int Nclusters, char directory[]);
int ReportClustersCBMAN(HWND hwnd, struct Coordinates *CoordinateStruct,
                   char directory[], char file[],
                   int X, int Y, int Z, float z0,
                   float dx, float dy, float dz,
                   double critical,
                   float xc[], float yc[], float zc[], int Nclusters);
///-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

int TestExperimentDensity2(struct Image *image, struct Coordinates *Co);
int TestWeightedExperimentDensity(struct Image *image, struct Coordinates *Co);
#endif
