/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(GraphTheory_H)
//Do Nothing
#else


#define GraphTheory_H



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "tensor.h"




struct AffinityMatrix{
    unsigned char A[2][2];//2x2 to consider up to 2 tensors; could be expanded
};




int RemoveRootElement(float weights[], int heap[], int entered, int node[]);
int UpdateHeap(float weights[], int heap[], int entered, int voxel, float NewWeight, int node[]);
int NewHeapElement(float weights[], int heap[], int entered, int voxel, int node[], float NewWeight);
int HeapBackShift(float weights[], int heap[], int current, int node[]);
int HeapForwardShift(float weights[], int heap[], int i, int node[]);
int Parent(int i);
int LeftChild(int i);
int RightChild(int i);
int FuzzyConnectedness(float (*GetAffinity)(void *image, int, int, int, int, int, int, int, float, void *), void *P,
												 void *image, int Seed, float Connectedness[],
                                                 int X, int Y, int Z, HWND hwnd, float thresh, int iterations);


int FuzzyConnectednessWithMemory5x5x5(float (*GetAffinity)(void *image, int, int, int, int, int, int, int, float, float *), void *P,
												 void *image, int Seed, float Connectedness[], char prev[],
                                                 int X, int Y, int Z, float dx, float dy, float dz, float CosAngle,
                                                 HWND hwnd, float thresh, int iterations);


int GetNeighourDirections(struct ThreeVector Vneighbour[], float dx, float dy, float dz);
int GetNNeighourDirections(struct ThreeVector Vneighbour[], float dx, float dy, float dz, int N);
int PathsLengthAndCurvature(char *prev, int X, int Y, int Z, int start, int *steps, double *curvature);

int TestGetNeighourDirections(HWND hwnd, char execdir[]);

#endif
