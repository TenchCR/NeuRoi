/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "global.h"


int GetMedianCordAndCSF(float *image, unsigned char *slice, int X, int Y, float *medCSF, float *medCord);
double GetROImaskPV(float *image, unsigned char *slice, int X, int Y, struct ROIedge *roi, int length);
int CentreOfCord(unsigned char *slice, int X, int Y, float *x0, float *y0);
double CorrectForAngle(unsigned char *img, int X, int Y, int Z, float dx, float dy, float dz);
double AreaOfSlice(unsigned char *slice, int X, int Y, float dx, float dy);
//============================================================================================
//                      gets the fractional contributions
//                      to the cord area
//                      return the number of non-zero voxels; include half ROIedge voxels
//                          this is to say that the area contribution for the edge voxels is
//                          half that of the ROI internal voxels
//============================================================================================
double GetROImaskPV(float *image, unsigned char *slice, int X, int Y, struct ROIedge *roi, int length)
{

    float medCSF, medCord;
    float I;
    int pixel, pixels=X*Y, N=0;

    memset(slice, 0, pixels);                                                   //slice is zero

    if (!length) return 0;

    N=FloodFillROI(slice, X, Y, roi, length);                                   //slice is FILL or EDGE or zero

    DilateImage3D(slice, X, Y, 1);                                              //slice is FILL or EDGE or ONE
    //Now the cord is FILL (=3), the ROI is EDGE (=2) and the dilated voxels are 1

    if (N && GetMedianCordAndCSF(image, slice, X, Y, &medCSF, &medCord))
    {

        for (pixel=0; pixel<pixels; pixel++)
        {
            if (slice[pixel]==1) slice[pixel]=0;                                //CSF contributes zero
            if (slice[pixel]==FILL) slice[pixel]=100;                           //cord contributes 100%
            if (slice[pixel]==EDGE)
            {
                //this works whether the cord is brighter or darker than CSF
                I=100.0*(image[pixel]-medCSF)/(medCord-medCSF);                 //contribution of partial volume voxels depends on intensity
                if (I>100.0) I=100.0;
                if (I<0.0) I=0.0;
                slice[pixel]=(unsigned char)I;
            }
        }
    }
    return (double)N + (double)(length-1)/2.0;
}









//============================================================================================
//                      get median CSF and cord intensities
//                      In slice[], the CSF is indicated by 1
//                          the cord is indicated by FILL
//============================================================================================
int GetMedianCordAndCSF(float *image, unsigned char *slice, int X, int Y, float *medCSF, float *medCord)
{

    int pixel, pixels=X*Y;
    int Ncord, Ncsf;
    int icord,icsf;
    int result=0;
    double *dcord=NULL, *dcsf=NULL;

    (*medCord)=1.0;
    (*medCSF)=0.0;

    //count the number of cord and CSF voxels
    Ncord=Ncsf=0;
    for (pixel=0; pixel<pixels; pixel++)
    {
        if (slice[pixel]==1) Ncsf++;//the 0ne indicates csf; the ones are the voxels outside the ROI EDGE found by dilation
        if (slice[pixel]==FILL) Ncord++;
    }

    if (!Ncord || !Ncsf) return 0;


    dcord=(double *)malloc(Ncord*sizeof(double));
    dcsf=(double *)malloc(Ncsf*sizeof(double));

    if (dcord && dcsf)
    {
        //get the cord and CSF intensities
        icord=icsf=0;
        for (pixel=0; pixel<pixels; pixel++)
        {
            if (slice[pixel]==1 && icsf<Ncsf)
            {
                dcsf[icsf]=image[pixel];
                icsf++;
            }
            if (slice[pixel]==FILL && icord<Ncord)
            {
                dcord[icord]=image[pixel];
                icord++;
            }
        }

        //get the cord and CSF medians
        (*medCord)=(float)MedianValueDouble(Ncord, dcord);
        (*medCSF)=(float)MedianValueDouble(Ncsf, dcsf);
        if ( (*medCord)!=(*medCSF) ) result=1;
    }

    if (dcord) free(dcord);
    if (dcsf) free(dcsf);

    return result;
}




//============================================================================================
//                      Get centre of cord
//============================================================================================
int CentreOfCord(unsigned char *slice, int X, int Y, float *x0, float *y0)
{

    int x, y, pixel;
    float xsum,ysum;
    float weight;

    (*x0)=(*y0)=0.0;

    xsum=ysum=weight=0.0;
    for (y=0; y<Y; y++)
    {
        for (x=0; x<X; x++)
        {
            pixel=x+y*X;
            xsum+=(float)x*slice[pixel]/100.0;
            ysum+=(float)y*slice[pixel]/100.0;
            weight+=(float)slice[pixel]/100.0;
        }
    }

    if (fabs(weight)>0.0)
    {
        (*x0)=xsum/weight;
        (*y0)=ysum/weight;
    }
    else return 0;

    return 1;
}






//============================================================================================
//                      Get Angle correction
//============================================================================================
double CorrectForAngle(unsigned char *img, int X, int Y, int Z, float dx, float dy, float dz)
{

    double *M,*bx, *by;
    double correction=1.0;//default correction
    double coefx[2], coefy[2];
    double dxdz, dydz;
    double length;
    float x0,y0;
    int slice,count;

    M=(double *)malloc(sizeof(double)*Z*2);
    bx=(double *)malloc(sizeof(double)*Z);
    by=(double *)malloc(sizeof(double)*Z);

    if (M && bx && by)
    {
        count=0;
        for (slice=0; slice<Z; slice++)
        {
            if (CentreOfCord(&img[X*Y*slice], X, Y, &x0, &y0))
            {
                M[count*2]=1.0;
                M[count*2+1]=dz*slice;
                bx[count]=dx*(x0-X/2);
                by[count]=dy*(y0-Y/2);
                count++;
            }
        }
        if (count>1) //there must be more than one slice to fit a straight line to
        {
            if (LeastSquaresFitting(M, bx, coefx, 2, count) && LeastSquaresFitting(M, by, coefy, 2, count))
            {
                dxdz=coefx[1];
                dydz=coefy[1];
                length=sqrt(dxdz*dxdz + dydz*dydz);
                if (length>0.0)
                {
                    correction=cos(atan(length));
                }
            }
        }
    }

    if (M) free(M);
    if (bx) free(bx);
    if (by) free(by);

    return correction;
}






//============================================================================================
//                      Compute cord area for slice
//                      correct for PV
//                      slice contains percentage of tissue content (0..100)
//============================================================================================
double AreaOfSlice(unsigned char *slice, int X, int Y, float dx, float dy)
{

    int x, y;
    int pixel;
    double area;

    area=0.0;
    for (y=0; y<Y; y++)
    {
        for (x=0; x<X; x++)
        {
            pixel=x+y*X;
            area+=(float)slice[pixel]*dx*dy/100.0;
        }
    }
    return area;
}





//============================================================================================
//                      Compute cord area using ROIs
//                      correct for PV and angle
//============================================================================================
double ComputeMeanCordArea(struct Image *image)
{

    int X=(*image).X;
    int Y=(*image).Y;
    int Z=(*image).Z;
    int voxels=X*Y*Z;
    int roi;
    int slices;
    double correction;
    double area,areasum;
    double uarea, uareasum; //uncorrected areas
    char txt[256];
    FILE *fp=NULL;
    char fname[MAX_PATH];

    sprintf(fname,"./areas.csv");
    fp=fopen(fname,"w");
    if (fp)
           {
                  fprintf(fp,"slice,area\n");
            }


    if (gNumberOfROIs<=0)
    {
        MessageBox(NULL,"Please define some cord ROIs","",MB_OK);
        return 0;
    }

    if ((*image).charimg) free((*image).charimg);
    (*image).charimg=(unsigned char *)malloc(voxels);

    area=uarea=0.0;
    if ((*image).charimg)
    {

        memset((*image).charimg,0,voxels);

        slices=0;
        areasum=uareasum=0.0;
        for (roi=1; roi<=gNumberOfROIs; roi++)
        {
            if ( (ROIs[roi].type!=LIMIT) && (!ROIs[roi].removed))
            {
                uarea=GetROImaskPV(&(*image).img[ROIs[roi].slice*X*Y], &(*image).charimg[ROIs[roi].slice*X*Y],
                                   (*image).X, (*image).Y, ROIs[roi].roi, ROIs[roi].length)
                      *(*image).dx*(*image).dy;


                area=AreaOfSlice(&(*image).charimg[ROIs[roi].slice*X*Y], X, Y, (*image).dx, (*image).dy);
                if (area>0.0)
                {
                    uareasum+=uarea;
                    areasum+=area;
                    slices++;
                }

                if (fp)
                {
                    fprintf(fp,"%d,%f\n",ROIs[roi].slice,area);
                }
            }
        }
        correction=0.0;
        if (slices)
        {
            if (slices>1) correction=CorrectForAngle((*image).charimg, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz);
            else correction=1.0;
            area=areasum*correction/slices;
            uarea=uareasum/slices;
        }

        sprintf(txt,"UnCorrected Area=%f  \nCorrected Area=%f  \nInclination correction applied=%f   \nSlices=%d",uarea,area,correction,slices);
        MessageBox(NULL,txt,"",MB_OK);
    }

    if (fp) fclose(fp);

    if ((*image).charimg)
    {
        free((*image).charimg);
        (*image).charimg=NULL;
    }

    return area;
}






//============================================================================================
//                  TEST CORD MEASUREMENT ROUTINES
//============================================================================================
#define CORD_DIAM 10.0
#define X_VOXELS 256
#define Y_VOXELS 256
#define Z_SLICES 10
#define VOXEL_DX 0.1
#define VOXEL_DY 0.1
#define VOXEL_DZ 1.0
int InCord(int x, int y, int z);
//============================================================================================
//                  GET THE CORD IMAGE
//============================================================================================
int SaveCordPhantomImage(void)
{

    struct Image image;
    float x0,y0,z0;
    int x, y, z;
    int voxel;

    x0=VOXEL_DX*X_VOXELS/2.0;
    y0=VOXEL_DY*Y_VOXELS/2.0;
    z0=VOXEL_DZ*Z_SLICES/2.0;

    memset(&image,0,sizeof(struct Image));
    MakeImage(&image, X_VOXELS, Y_VOXELS, Z_SLICES, 1, VOXEL_DX, VOXEL_DY, VOXEL_DZ,
              x0, y0, z0, 1.0, 0.0, DT_FLOAT,
              HDR, "Cord Phantom");

    for (z=0; z<Z_SLICES; z++)
    {
        for (y=0; y<Y_VOXELS; y++)
        {
            for (x=0; x<X_VOXELS; x++)
            {
                voxel=x+y*X_VOXELS+z*X_VOXELS*Y_VOXELS;
                if (InCord(x,y,z)) image.img[voxel]=100.0;
            }
        }
    }

    SaveAs(&image);
    ReleaseImage(&image);

    return 1;
}
//============================================================================================
//              CORD DEFINITION
//============================================================================================
int InCord(int x, int y, int z)
{

    double x0,y0;
    double xf,yf;
    double r;

    x0=VOXEL_DX*X_VOXELS/2.0+0.2*z;
    y0=VOXEL_DY*Y_VOXELS/2.0;

    xf=VOXEL_DX*x-x0;
    yf=VOXEL_DY*y-y0;

    r=sqrt( xf*xf + yf*yf );
    if (r<=CORD_DIAM/2.0) return 1;
    return 0;
}




