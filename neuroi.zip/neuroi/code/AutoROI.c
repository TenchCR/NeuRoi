/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "autoROI.h"
#include "menuresources.h"
#include "loader.h"
#include "ROIs.h"
#include "global.h"

#define SCROLL_MAX 1000
#define SCROLL_MIN 1

struct ROIedge gEdit[MAX_ROI_LENGTH];
int gEditLength;
struct ROIedge ROI[MAX_ROI_LENGTH];
int gLength;                           //length of the currently defined ROI
int gSlice;                            //slice for currently define ROI


int GrowROI(float *image, unsigned char *result, unsigned char *limit, int X, int Y, int slice,
            int xseed, int yseed, float min, float max, struct ROIedge ROI[], int length);
int HandleMouseInputAutoROI(HWND hwndAuto, UINT msg, WPARAM wParam, LPARAM lParam, int slice, int mode, struct ROIedge ROI[], int *length,
                            int X, int Y, int x0, int y0, float zoom);
int StoreLimitsToLimitMask(unsigned char *limit, int X, int Y, struct ROI rois[], int NumberOfRois);
int AutoIntensityRange(float *image, int X, int Y, int xs, int ys, int slice, float max, HWND hwnd);
int EditCurrentROI(struct ROIedge *Current, int CurrentL, struct ROIedge *Edit, int EditL);
//=============================================================================================
//                           Auto ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK AutoROIsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static unsigned char *region=NULL, *limit=NULL;                                       //limit mask and region grown
    static char current_selection[256]="new";
    static int  hi, lo;
    static int Mode;                                                            //mode selected ID_ROI_SEED, ID_ROI_LIMIT
    static int xseed, yseed;
    static int HoldObjectNumber;
    int pos;
    int i, object;
    int roitype;
    struct ROIedge limroi[MAX_ROI_LENGTH];
    float I;
    char txt[256];


    switch (msg)
    {


    case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hAutoROI=(HWND)NULL;
        if (region) free(region);
        region=(unsigned char *)NULL;
        if (limit)  free(limit);
        limit=(unsigned char *)NULL;
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:
        //SET UP THE ROI OBJECT NUMBER SELECTION BOX
        if ( SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_FINDSTRING,-1,(LPARAM)current_selection)==CB_ERR)
        {
            sprintf(current_selection,"new");
        }
        SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_RESETCONTENT,0,0);
        SendDlgItemMessage(hwnd,ID_SELECT_OBJECT,CB_ADDSTRING,(WPARAM)0,(LPARAM)"new");
        for (i=1;i<=gNumberOfObjects;i++)
        {
            sprintf(txt,"%d",i);
            SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)txt);
        }
        SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_SELECTSTRING ,-1,(LPARAM)current_selection);
        SendMessage(GetDlgItem(hwnd,Mode),BM_SETCHECK,BST_CHECKED,0);
        if (HoldObjectNumber) SendMessage(GetDlgItem(hwnd,ID_HOLD_OBJECT),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_HOLD_OBJECT),BM_SETCHECK,BST_UNCHECKED,0);
        break;





    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        region=(unsigned char *)malloc((int)(gImage.X*gImage.Y));
        limit =(unsigned char *)malloc((int)(gImage.X*gImage.Y));
        if ((!region) || (!limit)) SendMessage(hwnd, WM_CLOSE,0,0);
        memset(limit,1,(int)(gImage.X*gImage.Y));
        memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
        SendMessage(GetDlgItem(hwnd,ID_ROI_HI),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
        SendMessage(GetDlgItem(hwnd,ID_ROI_HI),SBM_SETPOS,SCROLL_MAX,TRUE);
        SendMessage(GetDlgItem(hwnd,ID_ROI_LO),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX-1);
        SendMessage(GetDlgItem(hwnd,ID_ROI_LO),SBM_SETPOS,SCROLL_MAX-1,TRUE);
        Mode=ID_ROI_SEED;
        break;





    case WM_HSCROLL:
        if (Mode!=ID_ROI_SEED)
        {
            SendMessage(GetDlgItem(hwnd,Mode),BM_SETCHECK,BST_UNCHECKED,0);
            SendMessage(hwnd, WM_COMMAND, ID_ROI_SEED,0);
            SendMessage(GetDlgItem(hwnd,ID_ROI_SEED),BM_SETCHECK,BST_CHECKED,0);
            break;
        }
        pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
        switch (LOWORD(wParam))
        {
        case SB_LINELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-1) , TRUE);
            break;
        case SB_LINERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+1) , TRUE);
            break;
        case SB_PAGELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-SCROLL_MAX/10) , TRUE);
            break;
        case SB_PAGERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+SCROLL_MAX/10) , TRUE);
            break;
        case SB_THUMBTRACK:
            SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam) , TRUE);
            break;
        }

        hi = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_HI), SBM_GETPOS, 0, 0);
        lo = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_LO), SBM_GETPOS, 0, 0);

        if (hi<=lo)                                                             //hi shouldnt be <= lo
        {
            hi=lo+1;
            SendMessage(GetDlgItem(hwnd,ID_ROI_HI),SBM_SETPOS,hi,TRUE);
        }
        sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*hi/SCROLL_MAX)));
        SendMessage(GetDlgItem(hwnd,ID_ROI_HI_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*lo/SCROLL_MAX)));
        SendMessage(GetDlgItem(hwnd,ID_ROI_LO_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH, 0);
        gLength=GrowROI(gImage.img, region, limit, gMainPict.X, gMainPict.Y, gMainPict.slice,
                        xseed, yseed, gImage.MaxIntensity*lo/SCROLL_MAX, gImage.MaxIntensity*hi/SCROLL_MAX,
                        ROI, MAX_ROI_LENGTH);

        SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
        SetFocus(GetParent(hwnd));
        break;




    case WM_MOUSEMOVE:                                                          //mouse input
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONDOWN:
    case WM_MBUTTONDOWN:
        if (Mode==ID_ROI_LIMIT) gSlice=gMainPict.slice;//makes sure the limit is shown on screen as it is drawn
        HandleMouseInputAutoROI(hwnd, msg, wParam, lParam, gMainPict.slice, Mode, ROI, &gLength, gMainPict.X, gMainPict.Y,
                                gMainPict.xpos, gMainPict.ypos, gMainPict.zoom);
        break;




    case WM_COMMAND:
        switch (LOWORD(wParam))
        {

        case ID_HOLD_OBJECT:
            if (HoldObjectNumber)
            {
                HoldObjectNumber=0;
                SendMessage(GetDlgItem(hwnd,ID_HOLD_OBJECT),BM_SETCHECK,BST_UNCHECKED,0);
            }
            else
            {
                HoldObjectNumber=1;
                SendMessage(GetDlgItem(hwnd,ID_HOLD_OBJECT),BM_SETCHECK,BST_CHECKED,0);
            }
        break;


        case ID_ACCEPT_ROI:
            //if (Mode==ID_ROI_EDIT) break;
            roitype=NOROI;
            if ((Mode==ID_ROI_SEED) || (Mode==ID_ROI_EDIT))
            {
                roitype=AUTO;
                i=SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_GETCURSEL,0,0);
                SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_GETLBTEXT,i,(LPARAM)current_selection);
                if (strstr("new",current_selection))
                {
                    gNumberOfObjects++;
                    object=gNumberOfObjects;
                    sprintf(current_selection,"%d",object);
                    i=SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)current_selection);
                    if (HoldObjectNumber) SendMessage(GetDlgItem(hwnd,ID_SELECT_OBJECT),CB_SETCURSEL,i,0);
                }
                else object=atoi(current_selection);
            }
            else if (Mode==ID_ROI_LIMIT)
            {
                roitype=LIMIT;
                memcpy(limroi, ROI, gLength*sizeof(struct ROIedge));
                gLength=ConvertToROI(limroi, gLength, ROI);                      //convert limit to roi line
                object=0;
            }
            if (gLength && (roitype!=NOROI))
            {
                gNumberOfROIs=AcceptROI(gImage.X, gImage.Y, ROI, gLength, gMainPict.x, gMainPict.y, gMainPict.slice,
                                        gNumberOfROIs, object, roitype);
                StoreLimitsToLimitMask(limit, gImage.X, gImage.Y, ROIs, gNumberOfROIs); //store limit to limit mask

                gLength=0;
                memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);

                SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
                SaveROIs(1, gMainPict.X, gMainPict.Y, gMainPict.Z);
            }
            break;



        case VK_ESCAPE:
            gLength=0;
            memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;

        case VK_DELETE:
            if (Mode!=ID_ROI_LIMIT) break;
            gLength--;
            if (gLength<0) gLength=0;
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;



        case ID_ROI_SEED:
        case ID_ROI_LIMIT:
        case ID_ROI_DELETE:
        case ID_ROI_RENUMBER:
            gLength=0;
            memset(ROI,0,sizeof(struct ROIedge)*MAX_ROI_LENGTH);
            Mode=(int)LOWORD(wParam);
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;
        case ID_ROI_EDIT:
            Mode=(int)LOWORD(wParam);
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;




        case ID_AUTOROI_SEED:
            if (Mode!=ID_ROI_SEED) break;
            xseed=gMainPict.x;
            yseed=gMainPict.y;
            AutoIntensityRange(gImage.img, gMainPict.X, gMainPict.Y, xseed, yseed, gMainPict.slice, gImage.MaxIntensity, hwnd);
            hi = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_HI), SBM_GETPOS, 0, 0);
            lo = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_LO), SBM_GETPOS, 0, 0);
            if (hi<=lo)                                                             //hi shouldnt be <= lo
            {
                hi=lo+1;
                SendMessage(GetDlgItem(hwnd,ID_ROI_HI),SBM_SETPOS,hi,TRUE);
            }
            sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*hi/SCROLL_MAX)));
            SendMessage(GetDlgItem(hwnd,ID_ROI_HI_TEXT),WM_SETTEXT,0,(LPARAM)txt);
            sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*lo/SCROLL_MAX)));
            SendMessage(GetDlgItem(hwnd,ID_ROI_LO_TEXT),WM_SETTEXT,0,(LPARAM)txt);

            gLength=GrowROI(gImage.img, region, limit, gMainPict.X, gMainPict.Y, gMainPict.slice,
                            xseed, yseed, gImage.MaxIntensity*lo/SCROLL_MAX,
                            gImage.MaxIntensity*hi/SCROLL_MAX,
                            ROI, MAX_ROI_LENGTH);
            gSlice=gMainPict.slice;
            UpdateWindow(GetParent(hwnd));
            I=gImage.img[xseed+yseed*gMainPict.X+gSlice*gMainPict.X*gMainPict.Y];
            sprintf(txt,"%f",I);
            SendMessage(GetDlgItem(hwnd,ID_INTENSITY),WM_SETTEXT,0,(LPARAM)txt);
            break;




        case ID_CLEAR_LIMITS:
            for (i=1;i<=gNumberOfROIs;i++) if (ROIs[i].type==LIMIT) ROIs[i].removed=1;
            StoreLimitsToLimitMask(limit, gImage.X, gImage.Y, ROIs, gNumberOfROIs); //store limit to limit mask
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REFRESH,0);
            break;

        case ID_GOTO_MANUAL:
            SendMessage(hwnd, WM_CLOSE,0,0);
            SendMessage(GetParent(hwnd),WM_COMMAND, IDM_MANUAL_ROIS, 0);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;


    }
    return 0;
}









//=============================================================================================
//                           Grow the ROI
//=============================================================================================
int GrowROI(float *image, unsigned char *result, unsigned char *limit, int X, int Y, int slice,
            int xseed, int yseed, float min, float max, struct ROIedge ROI[], int length)
{
    int area;
    //char txt[256];

    memset(result,0,X*Y);
    area = FloodFillLimited(&image[slice*X*Y], result, limit, X, Y, xseed, yseed, min, max);

   /* sprintf(txt,"%d, %f, %f",area,min,max);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;*/

    if (area) {}//Grow2Dregion(result, X, Y);
    else return 0;


    return RegionEdgeDetect(result, X, Y, ROI, length);
}







//=============================================================================================
//                           Auto Range
//=============================================================================================
int AutoIntensityRange(float *image, int X, int Y, int xs, int ys, int slice, float max, HWND hwnd)
{

    float sum, sum2, sd;
    float I;
    int i,j,XY=X*Y;
    int hi,lo;

    if (max<=0.0) return 0;

    hi = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_HI), SBM_GETPOS, 0, 0);
    lo = (int)SendMessage( GetDlgItem(hwnd,ID_ROI_LO), SBM_GETPOS, 0, 0);

    I=image[xs + ys*X + slice*XY]*SCROLL_MAX/max;

    if ((I<hi) && (I>lo)) return 0;//if the range is already suitable, dont adjust it and return

    sum=sum2=0.0;
    for (j=-2;j<=2;j++)
    {
        for (i=-2;i<=2;i++)
        {
            I=image[(xs+i) + (ys+j)*X + slice*XY];
            sum+=I;
            sum2+=I*I;
        }
    }
    sd=sum2/25.0 -sum*sum/25.0/25.0;
    if (sd>0.0) sd=sqrt(sd);
    else sd=0.0;

    I=image[xs + ys*X + slice*XY];
    hi=SCROLL_MAX*(I+2*sd)/max;
    lo=SCROLL_MAX*(I-2*sd)/max;

    if (hi>SCROLL_MAX) hi=SCROLL_MAX;
    if (lo<SCROLL_MIN) lo=SCROLL_MIN;

    SendMessage(GetDlgItem(hwnd,ID_ROI_HI),SBM_SETPOS,hi,TRUE);
    SendMessage(GetDlgItem(hwnd,ID_ROI_LO),SBM_SETPOS,lo,TRUE);

    return 1;
}










//=============================================================================================
//                           Show the current ROI
//                           Use the global variables ROI & gLength
//=============================================================================================
int DrawCurrentAutoROI(struct Picture *picture, HDC hDC, float dx, float dy)
{

    short int x1,y1;
    float LimitLength;//the length of the limit line
    int l;
    char txt[256];


//set up the font for displaying the length of an edit line
    SetBkMode(hDC, TRANSPARENT);
    SetTextColor(hDC, RGB(0,0,255));


    LimitLength=0.0;
    for (l=1;l<gLength;l++)
    {
        LimitLength +=  sqrt(pow((ROI[l-1].x-ROI[l].x)*dx,2) + pow((ROI[l-1].y-ROI[l].y)*dy,2));
    }
    sprintf(txt,"%d",(int)LimitLength);
    ImageToPicture(picture, &x1, &y1, ROI[0].x, ROI[0].y, (*picture).slice);
    if (SendMessage(GetDlgItem(hAutoROI, ID_ROI_LIMIT),BM_GETCHECK,0,0)==BST_CHECKED)
    {
        TextOut(hDC,x1, y1,txt,strlen(txt));
    }



    if (gEditLength) DrawROI(picture, hDC, gEdit, gEditLength, Colour(1), 1);

    if ((!gLength) || ((*picture).slice!=gSlice)) return 0;
    DrawROI(picture, hDC, ROI, gLength, RGB(255,0,0), 1);



    return 1;
}














//=============================================================================================
//                        Handle all the mouse inputs for AutoROI
//mode is one of the Auto ROI modes (seed, delete, renumber, limit)
//x0 and y0 are the scroll offsets; the user scroll the image around
//=============================================================================================
int HandleMouseInputAutoROI(HWND hwndAuto, UINT msg, WPARAM wParam, LPARAM lParam, int slice, int mode, struct ROIedge ROI[], int *length,
                            int X, int Y, int x0, int y0, float zoom)
{

    static int PenDown;
    int i;
    short int xim, yim, zim;
    int sellected=0;
    static int current;
    char txt[256];

    if (!zoom) return 0;

    PictureToImage(&gMainPict, (int)LOWORD(lParam)-x0, (int)HIWORD(lParam)-y0, &xim, &yim, &zim,
                   IsMenuItemChecked(GetParent(hwndAuto), IDM_VIEW_PLANES));
    if (xim<0) xim=0;
    if (yim<0) yim=0;
    if (xim>=X) xim=X-1;
    if (yim>=Y) yim=Y-1;

    switch (msg)
    {


    case WM_LBUTTONDOWN:
        if (mode==ID_ROI_SEED) SendMessage(hwndAuto, WM_COMMAND, ID_AUTOROI_SEED, 0);
        if ((mode==ID_ROI_LIMIT) && (xim>=0) && (yim>=0) && (xim<X) && (yim<Y))
        {
            if (!(*length))
            {
                ROI[0].x=ROI[1].x=xim;
                ROI[0].y=ROI[1].y=yim;
                (*length)=2;
            }
            else
            {
                (*length)++;
                if ( (*length)>=2 )
                {
                    ROI[(*length)-2].x=ROI[(*length)-1].x=xim;
                    ROI[(*length)-2].y=ROI[(*length)-1].y=yim;
                }
            }
        }
        if (mode==ID_ROI_DELETE && current && slice==gSlice)
        {
            ROIs[current].removed=1;
            current=0;
            (*length)=0;
        }
        if (mode==ID_ROI_RENUMBER && current && slice==gSlice)
        {
            i=SendMessage(GetDlgItem(hwndAuto,ID_SELECT_OBJECT),CB_GETCURSEL,0,0);
            SendMessage(GetDlgItem(hwndAuto,ID_SELECT_OBJECT),CB_GETLBTEXT,i,(LPARAM)txt);
            if (strstr("new",txt))
            {
                gNumberOfObjects++;
                ROIs[current].object=gNumberOfObjects;
                sprintf(txt,"%d",gNumberOfObjects);
                SendMessage(GetDlgItem(hwndAuto,ID_SELECT_OBJECT),CB_ADDSTRING,0,(LPARAM)txt);
            }
            else ROIs[current].object=atoi(txt);
        }
        if (mode==ID_ROI_EDIT)
        {
            PenDown=1;
            gEditLength=0;
            gEdit[0].x=xim;
            gEdit[0].y=yim;
        }
        break;




    case WM_LBUTTONUP:
        if (mode==ID_ROI_EDIT && PenDown)
        {
            PenDown=0;
            (*length)=EditCurrentROI(ROI, (*length), gEdit, gEditLength);
            gEditLength=0;
            SendMessage(GetParent(hwndAuto), WM_COMMAND, ID_REFRESH,0);
        }
        break;




    case WM_MOUSEMOVE:
        if (mode==ID_ROI_LIMIT && xim>=0 && yim>=0 && xim<X && yim<Y)
        {
            ROI[(*length)-1].x=xim;
            ROI[(*length)-1].y=yim;
            SendMessage(GetParent(hwndAuto), WM_COMMAND, ID_REFRESH,0);
        }
        sellected=GetNearestROI(xim, yim, slice);
        if ((sellected>0) && (sellected!=current) && (mode==ID_ROI_DELETE || mode==ID_ROI_RENUMBER))
        {
            (*length)=ROIs[sellected].length;
            gSlice=slice;
            memcpy(ROI, ROIs[sellected].roi, (*length)*sizeof(struct ROIedge));
            SendMessage(GetParent(hwndAuto), WM_COMMAND, ID_REFRESH,0);
            current=sellected;
        }
        if (mode==ID_ROI_EDIT && PenDown && (gEditLength<MAX_ROI_LENGTH) && (gEditLength>=0))
        {
            gEditLength++;
            gEdit[gEditLength].x=xim;
            gEdit[gEditLength].y=yim;
            SendMessage(GetParent(hwndAuto), WM_COMMAND, ID_REFRESH,0);
        }
        break;

    }


    return 1;
}



//=============================================================================================
//                          Edit the current ROI
//							Selects the longest ROI from the two possible after edit
//=============================================================================================
int EditCurrentROI(struct ROIedge *Current, int CurrentL, struct ROIedge *Edit, int EditL)
{

    int intercept,i;
    int ei;
    int C1, C2, E1, E2;//Ci records the intercept with the original ROI. Ei the intercept with the Edit line
    int x,y;
    int NewLength;
    int EditRoiLength;
    int length1,length2;
    double dist;
    float xf,yf;
    struct ROIedge ROI[MAX_ROI_LENGTH];
    struct ROIedge EditRoi[MAX_ROI_LENGTH];

    if (EditL<=0) return CurrentL;

    //change the edit line into a region of interest line; single pixel steps from start to finish
    EditRoiLength=0;
    for (ei=0;ei<EditL-1;ei++)
    {
        dist=(double)abs(Edit[ei+1].x-Edit[ei].x);
        if (abs(Edit[ei+1].y-Edit[ei].y)>dist) dist=(double)abs(Edit[ei+1].y-Edit[ei].y);
        if (dist<=0.0) dist=1.0;

        EditRoi[EditRoiLength].x=Edit[ei].x;
        EditRoi[EditRoiLength].y=Edit[ei].y;
        xf=(float)EditRoi[EditRoiLength].x;
        yf=(float)EditRoi[EditRoiLength].y;
        EditRoiLength++;



        //while not at next step of the Edit line
        while (!(Edit[ei+1].x==(int)xf && Edit[ei+1].y==(int)yf))
        {
            //Edit[i+1] must not equal Edit[i] for this to work
            //the mouse handling routine used to draw the edit must handle this
            if ((int)xf!=Edit[ei+1].x) xf+=0.1*(Edit[ei+1].x-Edit[ei].x)/dist;
            if ((int)yf!=Edit[ei+1].y) yf+=0.1*(Edit[ei+1].y-Edit[ei].y)/dist;


            x=(int)xf;
            y=(int)yf;
            if (((x!=EditRoi[EditRoiLength-1].x) || (y!=EditRoi[EditRoiLength-1].y)) && (!(Edit[ei+1].x==x && Edit[ei+1].y==y)))
            {

                EditRoi[EditRoiLength].x=x;
                EditRoi[EditRoiLength].y=y;
                EditRoiLength++;
            }
        }//while

    }//for (ei)
    EditRoi[EditRoiLength].x=Edit[EditL-1].x;// this is the last point on the Edit line
    EditRoi[EditRoiLength].y=Edit[EditL-1].y;
    EditRoiLength++;





    //get the intercepts between the original and the Edit ROIs
    C1=C2=E1=E2=-1;
    for (ei=0;ei<EditRoiLength;ei++)
    {

        intercept=-1;
        for (i=0;(i<CurrentL) && (intercept==-1);i++)
        {
            if ((Current[i].x==EditRoi[ei].x) && (Current[i].y==EditRoi[ei].y))
            {
                intercept=i;
            }
        }
        if (intercept>=0)
        {
            if (C1<0)
            {
                C1=intercept;
                E1=ei;
            }
            else
            {
                C2=intercept;
                E2=ei;
            }
        }

    }//for (ei)
    //E1 and E2 are now the start and end points of the new ROI segment formed by the Edit ROI
    //E2>E1


    if ((C2<0) || (E2<0) || ((E2-E1)<2)) return CurrentL;//return if didnt cross the line twice (at least)


    //correct the order of the points
    if (C1>C2)
    {
        i=C2;
        C2=C1;
        C1=i;
        i=E2;
        E2=E1;
        E1=i;
    }


    //compute the length of the two possible ROIs after the edit
    length1=length2=0;

    length1=C1;
    if (E2>E1) length1+=(E2-E1);
    else length1+=(E1-E2);
    length1+=CurrentL-C2;

    length2=C2-C1;
    if (E2>E1) length2+=(E2-E1);
    else length2+=(E1-E2);


    if (length1>=length2)
    {
        NewLength=0;
        //first segment from orriginal
        for (i=0;i<C1;i++)
        {
            ROI[NewLength]=Current[i];
            NewLength++;
        }
        //new segment
        if (E2>E1)
        {
            for (i=E1;i<E2;i++)
            {
                ROI[NewLength]=EditRoi[i];
                NewLength++;
            }
        }
        else if (E1>E2)
        {
            for (i=E1;i>E2;i--)
            {
                ROI[NewLength]=EditRoi[i];
                NewLength++;
            }
        }
        for (i=C2;i<CurrentL;i++)
        {
            ROI[NewLength]=Current[i];
            NewLength++;
        }
    }
    else
    {
        NewLength=0;
        //first segment from orriginal
        for (i=C1;i<C2;i++)
        {
            ROI[NewLength]=Current[i];
            NewLength++;
        }
        if (E2>E1)
        {
            for (i=E2;i>=E1;i--)
            {
                ROI[NewLength]=EditRoi[i];
                NewLength++;
            }
        }
        else
        {
            for (i=E2;i<=E1;i++)
            {
                ROI[NewLength]=EditRoi[i];
                NewLength++;
            }
        }
    }

    memcpy(Current, ROI, sizeof(struct ROIedge)*NewLength);

    return NewLength;
}










//=============================================================================================
//                      Store limits to limitmask
//=============================================================================================
int StoreLimitsToLimitMask(unsigned char *limit, int X, int Y, struct ROI rois[], int NumberOfRois)
{

    int i,l;

    memset(limit,1,(X*Y));

    for (i=1;i<=NumberOfRois;i++)
    {
        if ((rois[i].type==LIMIT) && (!rois[i].removed))
        {
            for (l=0;l<rois[i].length;l++)
            {
                if (rois[i].roi[l].x>=0 && rois[i].roi[l].y>=0 && rois[i].roi[l].x<X && rois[i].roi[l].y<Y)
                {
                    limit[rois[i].roi[l].x + rois[i].roi[l].y*X]=0;
                }
            }
        }
    }
    return 1;
}
