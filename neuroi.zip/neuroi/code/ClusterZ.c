/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

///MODELS

///---------------MEAN-------------------
/*
The mean effect size within cluster is normally distributed
Null hypothesis to estimate p-value using likelihood ratio test: the mean is zero
Type 1 error control: replace coordinates with random coordinates and compute p-values in resulting clusters. Insist that observed clusters
for a given p-value outnumber the expected number of null clusters

*******Note******
Cant just use FDR on the, usually highly significant, p-values because they are derived from the highly significant effect sizes, and not from
spatial concordance of the studies; if FDR is used, the FWE is not controlled.
*/


///----------------REGRESSION------------------
/*
The effect sizes are linearly related to a covariate
Null Hypothesis to estimate p-value using likelihood ratio test: the regression coefficient is zero
Type 1 error control: replace coordinates with random coordinates and compute p-values in resulting clusters. Insist that observed clusters
for a given p-value outnumber the expected number of null clusters

******Note******
Cant just use FDR because it has no spatial concordance aspect, and the effect sizes tend to be correlated across the image. Therefore,
any coincidentally formed clusters are just as likely to have similar correlation to true clusters
*/


///--------------PostHocRegression------------------
/*
Regression analysis is not going to be very powerful. So this performs post hoc regression analysis only on significant clusters from the mean analysis.
Null hypothesis for computing cluster-wise p-values using likelihood ratio test: no significant regression in those clusters.
Type 1 error control: FDR*

An omnibus test is also performed. To get the p-values when they are likely correlated across the clusters a permutation test is performed.
The covariate is randomised across experiments, then the p-value for the covariate in each cluster computed many times. Then the omnibus test
works on the sum of log p-value statistic. The result is a single p-value that indicates if there is any global covariance, even if not
significant in any single cluster after type 1 error control.

*******Note****** that FDR would be reasonable if significance in each cluster is independent, which it might not be! There is no spatial aspect because that was removed in the meta-
analysis preceding the post hoc regression analysis; so no need to randomise coordinates.
*/


///Clustering

///-----------------Clustering Distance-----------------
/*
The clustering algorithm is based on DBSCAN, which requires that the coordinates that can form clusters
overlap with at least three others from different studies; this is a DBSCAN requirement for clustering in 3D.

The clustering distance is determined under the null hypothesis (random coordinates). The distribution of
the proportion of coordinates that overlap with at least three others is estimated. Then the proportion that
overlap at least three others computed. The clustering distance is modified iteratively so that this proportion
is small: 5%. This way, on average, few coordinates can form clusters under the null.
*/
///-------------------Signed Clustering------------------
/*
The standard clustering mode clusters coordinates independently of effect size sign.
The alternative is to form clusters from coordinates with effect sizes of the same sign.
This improves estimates when there is mixing of effect signs. But, it might hide heterogeneity.
*/

//for subanalysis
#define SUBANALYSIS 1
#define NO_SUBANALYSIS 0

//number of permutations to do. Can be increased as computers get better!
#define FCDR_PERMUTATIONS 4000
#define POST_HOC_PERMUTATIONS 1000

//parameters
#define SD_PARAMETER 0
#define MEAN_PARAMETER 1
#define COVARIATE 2


#include "display.h"
#include "imageprocess.h"
#include "numerical.h"
#include "graphtheoryalgorithms.h"
#include "CoordinateProcess.h"
#include "talairachfunctions.h"
#include "ClusterZ.h"








double EffectiveSubjectNumbers(int n1, int n2);


int GetPvaluesForEachCluster(struct Coordinates *CoordinateStruct,
                             int Nclusters,  double *p, int contrast, int model,
                             int save, char directory[], int Use_t, int subanalysis);


double LogLikelihoodOfCluster(struct EffectSample *Zs, double mean, double RandomSD, double cov);



double MLE_SD(struct EffectSample *Es, double *MLEsd);
double MLE_mean_sd(struct EffectSample *Es, double *mean, double *MLEsd);
double MLE_mean_sd_cov(struct EffectSample *Es, double *MLEmean, double *MLEsd, double *MLEcov);
double ProportionClusteringUnderNull(float mask[], int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                                     struct Coordinates *Co, double ClusteringDistance, int MinOverlapping, double error, int MergeGroups);
double NegativeLogLikelihoodOfCluster(double p[], int parameters, void *EffectSize);
double LogLikelihoodOfEffect(double Effect, double mean, double SD, double CensorThreshold, short int censor);

double pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz,
                 float x0, float y0, float z0, double ClusteringDistance, float critical, int model, char directory[],
                 int MergeStudies, int *SigClusters, int *TotalNullClusters, int save, int Use_t, int ErrorControl, int ClusteringMode, int MarkerSize);
double PostHocRegression(HWND hwnd, struct Coordinates *c, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, double pmeanz, double critical, char diretory[], int SigClusters, int save, int Use_t, int MergeStudies);


int SaveEffectSizeToCheckForOutliers(struct Coordinates *Co, char directory[]);




int SubAnalysisPostHoc(struct Coordinates *Co, int Nclusters, int model, int contrast, char directory[], int Use_t);

int TestLogLikelihoodOfCluster(int Studies, int subjects, double Zthreshold, int Niterations, int model);

int TestClusteringDistanceSensitivity(HWND hwnd, struct Coordinates *coord, struct Image *mask);
int TestClusterz_Mean_Regression(HWND hwnd, struct Image *image,double critical, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, int iterations, double Zthreshold, double mean, double beta,double BetweenStudySD, int model);

int TestAdaptiveClusteringDistance(struct Image *mask, struct Coordinates *coord);

int Test_Group_Simulation_Coordinates(struct Image *image,int Studies1, int Studies2, int MaxCoordinates,
                                      double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor, int experiments);
int Paper_Simulation_Coordinates(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, double Zcensor, int SystematicCoordinates, double SDcoord, struct ThreeVector V[]);
int Test_Paper_Effect_Size_Experiment(struct Image *image,int Studies, int MaxCoordinates,
                                      double CoordinateProportion, int Subjects, double Zcensor);
int Paper_Effect_Size_Experiment(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, double Zcensor, double SDcoord, struct ThreeVector V[], int Nclusters);
int Test_Paper_Simulation_Coordinates(struct Image *image,int Studies, int MaxCoordinates, double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor);

//=======================================================================================
//THE REGRESSION MODEL IS SUCH THAT THE EFFECT E+alpha*COVARIATE IS NORMALLY DISTRIBUTED.
//THEREFORE THE MODEL IS E~N(mu-alphaCOVARIATE, VAR)
//=======================================================================================


//=============================================================================================
//                           ClusterZ callback function
//=============================================================================================
INT_PTR CALLBACK ClusterZDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static struct Coordinates CoordinateStruct;
    static char directory[MAX_PATH];
    static double pvalue, ClusterDistance;
    static int MarkerSize;
    static int MergeStudies;
    static int model, control;
    static int Use_t;
    static int ClusteringMode;
    char txt[256], fname[MAX_PATH];
    int tmp;
    int SigClusters,TotalNullClusters;
    int save;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;
#if defined(DEVELOP)
    HDC hDC;
#endif

    switch (msg)
    {


    case WM_CLOSE:
        if (CoordinateStruct.Nexperiments) FreeCoordinates(&CoordinateStruct);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hClusterZ=(HWND)NULL;
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:

#if defined(DEVELOP)
        hDC=GetDC(GetParent(hwnd));
        sprintf(txt,"MIN_OVERLAP=%d",MIN_OVERLAP);
        TextOut(hDC, 100,160,txt,strlen(txt));
        sprintf(txt,"Pseudo experiments=%d",FCDR_PERMUTATIONS);
        TextOut(hDC, 100,190,txt,strlen(txt));
        sprintf(txt,"Post Hoc Pseudo experiments=%d",POST_HOC_PERMUTATIONS);
        TextOut(hDC, 100,220,txt,strlen(txt));
        sprintf(txt,"Min Coordinate overlap in cluster=%d",MIN_OVERLAP);
        TextOut(hDC, 100,250,txt,strlen(txt));
        ReleaseDC(GetParent(hwnd),hDC);
#endif

        sprintf(txt,"%f",pvalue);
        SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
        sprintf(txt,"%d",MarkerSize);
        SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_SETTEXT, 0, (LPARAM)txt);
        if (MergeStudies) SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_UNCHECKED,0);
        SendMessage(GetDlgItem(hwnd,model),BM_SETCHECK,BST_CHECKED,0);
        SendMessage(GetDlgItem(hwnd,control),BM_SETCHECK,BST_CHECKED,0);
        SendMessage(GetDlgItem(hwnd,ClusteringMode),BM_SETCHECK,BST_CHECKED,0);
        break;





    case WM_INITDIALOG:
        memset(&CoordinateStruct, 0, sizeof(struct Coordinates));
        srand ( time(NULL) );
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        pvalue=0.05;
        ClusterDistance=0.0;
        MergeStudies=1;
        model=ID_MEANZ;
        control=ID_DO_FCDR;
        Use_t=0;
        ClusteringMode=ID_CBMAN_CLUSTERING;
        MarkerSize=DEFAULT_MARKER_SIZE;
        break;





    case WM_COMMAND:
        switch (LOWORD(wParam))
        {


        case ID_MERGE_GROUPS:
            if (MergeStudies)
            {
                SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_UNCHECKED,0);
                MergeStudies=0;
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_CHECKED,0);
                MergeStudies=1;
            }
            if (CoordinateStruct.TotalFoci)
            {
                sprintf(txt,"%f",EstimateClusteringDistanceUsingNull(hwnd, &CoordinateStruct,gImage.img,gImage.X,gImage.Y,gImage.Z,gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0,0.05, MergeStudies));
                SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
            }
            break;

        case ID_USE_T:
            if (Use_t)
            {
                SendMessage(GetDlgItem(hwnd,ID_USE_T),BM_SETCHECK,BST_UNCHECKED,0);
                Use_t=0;
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_USE_T),BM_SETCHECK,BST_CHECKED,0);
                Use_t=1;
            }
            break;


        case ID_MEANZ:
        case ID_CORRECTED_MEANZ:
        case ID_REGRESSIONZ:
        case ID_POSTHOC_REGRESSIONZ:
            model = LOWORD(wParam);
            break;

        case ID_DO_FCDR:
        case ID_DO_FWE:
            control = LOWORD(wParam);
            break;

        case ID_CLUSTER_ALL:
        case ID_CLUSTER_BY_EFFECT_SIGN:
        case ID_CBMAN_CLUSTERING:
            ClusteringMode = LOWORD(wParam);
            break;


        case ID_LOAD_ACTIVATIONS:
            EnableWindow(GetDlgItem(hwnd,ID_LOAD_ACTIVATIONS),FALSE);
            if (CoordinateStruct.Nexperiments) FreeCoordinates(&CoordinateStruct);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd),&CoordinateStruct, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
            {
                ///Check this is whole brain only; no VOI
                if (!IsWBStudy(&CoordinateStruct))
                {
                    MessageBox(NULL,"ClusterZ only works with whole brain studies.\nPlease remove volume of interest studies and try again.","IMPORTANT!",MB_OK|MB_ICONWARNING);
                    SendMessage(hwnd, WM_CLOSE,0,0);
                    break;
                }

                if (MessageBox(NULL,"Are you sure studies using the same subjects have the same studyID?","IMPORTANT!",MB_YESNO|MB_ICONWARNING)==IDNO)
                {
                    MessageBox(NULL,"Please edit the coordinate file to correct this.\nStudies using the same subjects must have the same studyID or the results will not be valid.\nMinimizing within-experiment and within-group effects in Activation Likelihood Estimation meta-analyses\nTurkeltaub PE","INVALID META-ANALYSIS",MB_OK|MB_ICONWARNING);
                    SendMessage(hwnd, WM_CLOSE,0,0);
                    break;
                }

                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT), WM_SETTEXT, 0, (LPARAM)"Please wait while clustering distance is computed...");
                UpdateWindow(hwnd);

                hourglass=LoadCursor(NULL,IDC_WAIT);
                PrevCursor=SetCursor(hourglass);

                tmp=DirectoryFileDivide(CoordinateStruct.coordinate_file_name);
                sprintf(directory,"%s",CoordinateStruct.coordinate_file_name);
                directory[tmp]='\0';

                sprintf(fname,"%s\\CBRES",directory);
                CreateDirectory(fname,NULL);

                CheckForCoordinateDuplication(&CoordinateStruct, "_Z", directory);

                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT), WM_SETTEXT, 0, (LPARAM)CoordinateStruct.coordinate_file_name);


                sprintf(txt,"%.2f",EstimateClusteringDistanceUsingNull(hwnd, &CoordinateStruct,gImage.img,
                        gImage.X,gImage.Y,gImage.Z,gImage.dx,gImage.dy,gImage.dz,
                        gImage.x0,gImage.y0,gImage.z0,CD_PROPORTION,
                        MergeStudies));
                SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);


                SetCursor(PrevCursor);
                EnableWindow(GetDlgItem(hwnd,ID_LOAD_ACTIVATIONS),TRUE);
            }
            break;



        case ID_TEST_CLUSTERZ:
            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);

            SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            ClusterDistance=atof(txt);

            //TestCoreFocusClusteringDistance(&CoordinateStruct,0.0, ClusterDistance);



            //TestClusterMembers(&CoordinateStruct);

            //SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            //ClusterDistance=atof(txt);
            //TestCoordinateOverlaps(&gImage, &CoordinateStruct, ClusterDistance);
            //TestCountClusters(&CoordinateStruct, ClusterDistance);

            ///Figure 2/3 in paper
            //int Paper_Effect_Size_v_ClusterDistance_Experiment(struct Image *mask,int Studies, int MaxCoordinates, double CoordinateProportion, int Subjects, double Zcensor)
            //Paper_Effect_Size_v_ClusterDistance_Experiment(&gImage, 20, 20, 0.5, 20, 3.79);
            //Paper_Effect_Size_v_ClusterDistance_Experiment(&gImage, 50, 20, 0.5, 20, 3.79);
            //Paper_Effect_Size_v_ClusterDistance_Experiment(&gImage, 100, 20, 0.5, 20, 3.79);
            //Test_Paper_Effect_Size_Experiment(&gImage,20, 20, 0.5, 20, 3.79);
            //Test_Paper_Effect_Size_Experiment(&gImage,50, 20, 0.5, 20, 3.79);
            //Test_Paper_Effect_Size_Experiment(&gImage,100, 20, 0.5, 20, 3.79);





            ///figures 4/5 in paper
            //this takes a loooong time because it runs ClusterZ many times
            //It runs simulated experiments with a specified number of clusters
            //counts how many clusters are detected so error rates can be computed
            //(HWND hwnd, struct Image *image,double critical, int Studies, int MaxCoordinates, double CoordinateProportion,
            //int Subjects, int iterations, double Zthreshold, int Use_t, int SystematicClusters, double NotClustered)
            //TestNullRejectionOfClusterz(GetParent(hwnd), &gImage, 0.1, 30, 20, 0.5, 20, 180, 3.79, 0,3, 0.5);




            ///Figure 6 in paper
            //(struct Image *image,int Studies, int MaxCoordinates,
            // double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor)
            //Test_Paper_Simulation_Coordinates(&gImage, 40, 20, 0.5, 20, 1, 3.79);
            //Test_Paper_Simulation_Coordinates(&gImage, 40, 20, 0.5, 20, 3, 3.79);
            //Test_Paper_Simulation_Coordinates(&gImage, 40, 20, 0.5, 20, 5, 3.79);



            ///Figure 1 in paper
            //saves a set of model parameters and estimates using MLE
            //(int Studies, int subjects, double Zthreshold, int Niterations, int model);
            //TestLogLikelihoodOfCluster(30, 20, 3.72, 100, ID_REGRESSIONZ);
            //TestLogLikelihoodOfCluster(100, 100, 3.72, 100, ID_MEANZ);


            //testing an adaptive method of getting the clustering distance
            //if (CoordinateStruct.TotalFoci) TestAdaptiveClusteringDistance(&gImage, &CoordinateStruct);

            //(struct Image *image,int Studies1, int Studies2, int MaxCoordinates,
            //double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor, int experiments);
            //Test_Group_Simulation_Coordinates(&gImage, 20, 20, 20, 0.5, 20, 5, 3.79, 1);
            //Test_Group_Simulation_Coordinates(&gImage, 15, 15, 20, 0.5, 20, 5, 3.79, 1);

            SetCursor(PrevCursor);
            break;

        case ID_SAVE_CHECKS:
            if (CoordinateStruct.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }
            SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            ClusterDistance=atof(txt);
             if (ClusterDistance<=0.0)
             {
                sprintf(txt,"%.2f",EstimateClusteringDistanceUsingNull(hwnd, &CoordinateStruct,gImage.img,
                        gImage.X,gImage.Y,gImage.Z,gImage.dx,gImage.dy,gImage.dz,
                        gImage.x0,gImage.y0,gImage.z0,CD_PROPORTION,
                        MergeStudies));
                SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
                ClusterDistance=atof(txt);
             }

            ComputeCBRESdiagnosticBySpatialRandomisation(GetParent(hwnd), &CoordinateStruct, gImage.img, gImage.X, gImage.Y, gImage.Z,
                    gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0,ClusterDistance, directory);

            SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            ClusterDistance=atof(txt);
            if (ClusterDistance<=0.0)
            {
                MessageBox(NULL,"Please specify Clustering Distance (>0.0)",txt,MB_OK|MB_ICONWARNING);
                break;
            }
            SaveALE_MIP(GetParent(hwnd), &CoordinateStruct, &gImage, directory, SDfromClusteringDistance(ClusterDistance));
            break;


        case ID_CLUSTERZ:
            if (CoordinateStruct.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }
            EnableWindow(GetDlgItem(hwnd,ID_CLUSTERZ),FALSE);

            SendMessage(GetDlgItem(hwnd,ID_MARKER_SIZE), WM_GETTEXT, 256, (LPARAM)txt);
            MarkerSize=atoi(txt);
            if (MarkerSize<=0) MarkerSize=DEFAULT_MARKER_SIZE;

            SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            ClusterDistance=atof(txt);
            if (ClusteringMode!=ID_CBMAN_CLUSTERING && ClusterDistance<=0.0)
            {
                MessageBox(NULL,"Please specify Clustering Distance (>0.0)",txt,MB_OK|MB_ICONWARNING);
                break;
            }

            SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            pvalue=atof(txt);
            if (pvalue<=0.0)
            {
                MessageBox(NULL,"Please specify pvalue (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }


            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);

            save=SAVE;
            if (model==ID_POSTHOC_REGRESSIONZ) save=DONT_SAVE;

            pvalue = pClusterZ(GetParent(hwnd),&CoordinateStruct,gImage.img,gImage.X,gImage.Y,gImage.Z/gImage.volumes,
                               gImage.dx,gImage.dy,gImage.dz,gImage.x0,gImage.y0,gImage.z0,
                               ClusterDistance, pvalue, model, directory, MergeStudies, &SigClusters,&TotalNullClusters,
                               save, Use_t, control, ClusteringMode, MarkerSize);


            SetCursor(PrevCursor);
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;


        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;


    }
    return 0;
}

//======================================================================================================
//GET THE CLUSTERS AND P VALUES AND THRESHOLD
//======================================================================================================
double pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                 double ClusteringDistance, float critical, int model, char directory[], int MergeStudies, int *SigClusters, int *TotalNullClusters,
                 int save, int Use_t, int ErrorControl, int ClusteringMode, int MarkerSize)
{
    struct Coordinates AleCpy;
    struct Coordinates RandALE;
    double pvalue=-1.0;
    double pvalue2=1.0;
    double fdr,fdr2=1.0;
    double Pmin[FCDR_PERMUTATIONS];
    int sortmin[FCDR_PERMUTATIONS];
    double *Pnull=NULL;//the p values per cluster per null sample
    double *P=NULL;//the p-values per observed cluster
    double fwhm=FWHMfromClusteringDistance(ClusteringDistance);//this is because some of the routines used are from LocalALE
    double minCD;
    float *xc=NULL;
	float *yc=NULL;
	float *zc=NULL;
    int *sort=NULL;
    int i;
    int PositiveNullExperiments;
    int cluster;
    int contrast=IsContrastStudy(CoordinateStruct);
    float MeanNullClusters;
    int Nclusters, NullClusters, n;
    int permutation;
    struct Clusters cl;
    HDC hDC=GetDC(hwnd);
    int ReportCounter, MinOverlapping;
    char fname[MAX_PATH],fname2[MAX_PATH],fname3[MAX_PATH];
    char txt[256];
    FILE *fp=NULL;



    memset(&AleCpy,0,sizeof(struct Coordinates));
    memset(&RandALE,0,sizeof(struct Coordinates));
    memset(&cl,0,sizeof(struct Clusters));

    if (!(xc=(float *)malloc(sizeof(float)*(*CoordinateStruct).TotalFoci)))
		goto END;
	if (!(yc=(float *)malloc(sizeof(float)*(*CoordinateStruct).TotalFoci)))
		goto END;
	if (!(zc=(float *)malloc(sizeof(float)*(*CoordinateStruct).TotalFoci)))
		goto END;

    sprintf(directory,"%s\\CBRES",directory);

    MinOverlapping=MIN_OVERLAP;

    (*SigClusters)=0;
    (*TotalNullClusters)=0;

///pre-process
    CopyCoordinates(CoordinateStruct, &AleCpy);
    if (MergeStudies) MergeCoordinatesbyStudy(&AleCpy);
    CensorLevels(&AleCpy);
    GetTalairachLabels(&AleCpy);

    if (!(Pnull = (double *)calloc(AleCpy.TotalFoci*FCDR_PERMUTATIONS,sizeof(double)))) goto END;


///FIND THE CLUSTERS GIVEN THE ClusteringDistance
    minCD=EstimateMinClusteringDistance(AleCpy.Nexperiments, ClusteringDistance);
    ///RandomiseCoordinatesForTesting(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &AleCpy, ClusteringDistance);
    if (ClusteringMode==ID_CBMAN_CLUSTERING) Nclusters = GetClusters(&gImage, &AleCpy, xc, yc, zc, 5, 1, SAVE, directory);
    else Nclusters = GetAllClusters(&AleCpy, minCD, ClusteringDistance, MinOverlapping, ClusteringMode);


    //IF THERE ARE NO CLUSTERS THERE IS NO POINT IN CONTINUING
    if (!Nclusters)
    {
        sprintf(txt,"There are no clusters");
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }


    if (!(P = (double *)calloc(Nclusters,sizeof(double)))) goto END;
    if (!(sort = (int *)calloc(Nclusters,sizeof(int)))) goto END;


///GET THE OBSERVED CLUSTER P VALUES AND SORT THEM INTO ORDER OF MAGNITUDE
    GetPvaluesForEachCluster(&AleCpy, Nclusters, P, contrast, model, save, directory, Use_t, NO_SUBANALYSIS);
    QuickSort(P,sort,Nclusters);

    //IF THERE ARE NO P VALUES<critical THERE IS NO POINT IN CONTINUING
    if (P[sort[0]]>critical)
    {
        sprintf(txt,"There are no clusters with p-values<%f",critical);
        MessageBox(NULL,txt,"",MB_OK);
        goto END;
    }



    if (save)
    {
        if ( (model==ID_MEANZ) || (model==ID_POSTHOC_REGRESSIONZ) )sprintf(fname,"%s\\ClusterZ_FCDR_meanz.csv",directory);
        else sprintf(fname,"%s\\ClusterZ_FCDR_regression.csv",directory);
        fp=fopen(fname,"w");
        if (fp) fprintf(fp,"Cluster Number, p-value, FCDR, FWER\n");
    }



///GET P VALUES FOR THE NULL EXPERIMENTS
    CopyCoordinates(&AleCpy, &RandALE);
    ReportCounter=0;
    NullClusters=0;
    if (FillClusterStructure(&AleCpy, &cl, SD_ALE(fwhm)))
    {
        for (permutation=1; permutation<=FCDR_PERMUTATIONS; permutation++)
        {

            if (ReportCounter==10)
            {
                if (EscapePressed(hwnd)) goto END;
                RemoveInput(hwnd);
                sprintf(txt,"permutation %d of %d     ",permutation,FCDR_PERMUTATIONS);
                TextOut(hDC,100,100,txt,strlen(txt));
                UpdateWindow(hwnd);
                ReportCounter=0;
            }
            RandomiseFociRandomEffects(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &RandALE, &cl, SD_ALE(fwhm));

            if (ClusteringMode==ID_CBMAN_CLUSTERING) n = GetClusters(&gImage, &RandALE, xc, yc, zc,5, 0, DONT_SAVE, directory);
            else n = GetAllClusters(&RandALE, minCD, ClusteringDistance, MinOverlapping, ClusteringMode);

            if (n) GetPvaluesForEachCluster(&RandALE, n, &Pnull[NullClusters], contrast, model, DONT_SAVE, directory, Use_t, NO_SUBANALYSIS);

            //get the smallest p-value for this permutation for FWE control
            Pmin[permutation-1]=1.0;
            for (i=0; i<n; i++)
            {
                if (Pnull[NullClusters+i]<Pmin[permutation-1]) Pmin[permutation-1]=Pnull[NullClusters+i];
            }

            NullClusters += n;
            ReportCounter++;
        }

        RemoveInput(hwnd);
        sprintf(txt,"Finished....................................");
        TextOut(hDC,100,100,txt,strlen(txt));
        UpdateWindow(hwnd);
    }


///compute the FCDR
    for (i=0; (i<Nclusters) && (P[sort[i]]<=critical); i++)
    {
        //compute the average of number of null clusters
        n=0;
        for (cluster=0; cluster<NullClusters; cluster++)
        {
            if (Pnull[cluster]<=P[sort[i]]) n++;
        }
        MeanNullClusters = (float)n/FCDR_PERMUTATIONS;

        if ((critical*(i+1))>=MeanNullClusters)
        {
            pvalue=P[sort[i]];
            //fcdr=(double)MeanNullClusters/(i+1);
            (*SigClusters) = i+1;
            (*TotalNullClusters)=n;
        }
        fdr=MeanNullClusters/(i+1);
        if (fdr>critical && fdr<fdr2)
        {
            pvalue2=P[sort[i]];//next most significant p value (>critical)
            fdr2=fdr;
        }
        if ((save==SAVE) && fp)
        {
            PositiveNullExperiments=0;
            for (permutation=0; permutation<FCDR_PERMUTATIONS; permutation++)
            {
                if (Pmin[permutation]<=P[sort[i]]) PositiveNullExperiments++;
            }
            if (fp) fprintf(fp,"%d,%e,%f,%f\n",sort[i]+1,P[sort[i]], MeanNullClusters/(i+1), (double)PositiveNullExperiments/FCDR_PERMUTATIONS);
        }
    }

    if ( (save==SAVE) && fp) fclose(fp);

///FWE
    if (ErrorControl==ID_DO_FWE)
    {
        //compute p-value threshold for FWE
        QuickSort(Pmin,sortmin,FCDR_PERMUTATIONS);
        i=(int)(critical*FCDR_PERMUTATIONS+0.5);//the pvalue at Pmin[sortmin[i-1]] will control the FWE at critical
        if (i<=0) i=0;
        pvalue=Pmin[sortmin[i-1]];
    }


    if (model==ID_POSTHOC_REGRESSIONZ)
    {
        //now do post hoc regression analysis on the significant clusters
        pvalue = PostHocRegression(hwnd, &AleCpy, X,Y,Z,dx,dy,dz,x0,y0,z0,
                                   pvalue, critical, directory, (*SigClusters),
                                   SAVE, Use_t, MergeStudies);
    }


    if ( (save==SAVE) || (model==ID_POSTHOC_REGRESSIONZ) )
    {
        sprintf(fname,"%s\\AllCoordinatesZ.txt",directory);
        SaveExperimentsALE(&AleCpy, fname, "", pvalue,1);

        //Filenames for saved image results
        sprintf(fname,"%s\\clusterz.nii",directory);
        sprintf(fname2,"%s\\clusterzRGB.nii",directory);
        sprintf(fname3,"%s\\signRGB.nii",directory);

        //SaveSignificantEffectClusters(double critical, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, struct Coordinates *CoordinateStruct, char fname[]);
        SaveSignificantEffectClusters(pvalue, X, Y, Z, dx, dy, dz, x0, y0, z0, &AleCpy,
                                      fname, fname2, fname3, MarkerSize);

        if (model==ID_POSTHOC_REGRESSIONZ) ReportClusterZ(hwnd, &AleCpy, directory, "ClusterZreport_postHoc.csv", X, Y, Z, z0, dx, dy, dz, pvalue, MergeStudies, ErrorControl, Use_t, ClusteringDistance);
        else ReportClusterZ(hwnd, &AleCpy, directory, "ClusterZreport.csv", X, Y, Z, z0, dx, dy, dz, pvalue, MergeStudies, ErrorControl, Use_t, ClusteringDistance);

        SaveEffectSizeToCheckForOutliers(&AleCpy, directory);

        sprintf(fname,"%s\\clusterz fdr=%f.nii",directory,fdr2);
        sprintf(fname2,"%s\\clusterzRGB fdr=%f.nii",directory,fdr2);
        sprintf(fname3,"%s\\signRGB fdr=%f.nii",directory,fdr2);
        SaveSignificantEffectClusters(pvalue2, X, Y, Z, dx, dy, dz, x0, y0, z0, &AleCpy,
                                      fname, fname2, fname3, MarkerSize);
        if (model==ID_POSTHOC_REGRESSIONZ) ReportClusterZ(hwnd, &AleCpy, directory, "ClusterZreport_postHoc fdr2.csv", X, Y, Z, z0, dx, dy, dz, pvalue2, MergeStudies, ErrorControl, Use_t, ClusteringDistance);
        else ReportClusterZ(hwnd, &AleCpy, directory, "ClusterZreport fdr2.csv", X, Y, Z, z0, dx, dy, dz, pvalue2, MergeStudies, ErrorControl, Use_t, ClusteringDistance);
    }

    if (save==SAVE) SubAnalysisPostHoc(&AleCpy, Nclusters, model, contrast, directory, Use_t);

END:
    if (P) free(P);
    if (Pnull) free(Pnull);
    if (sort) free(sort);
    if (xc)
		free(xc);
	if (yc)
		free(yc);
	if (zc)
		free(zc);
    FreeCluster(&cl);
    FreeCoordinates(&AleCpy);
    FreeCoordinates(&RandALE);
    ReleaseDC(hwnd, hDC);

    return pvalue;
}

//======================================================================================================

//======================================================================================================
double PostHocRegression(HWND hwnd, struct Coordinates *c,
                         int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                         double pmeanz, double critical, char directory[],
                         int SigClusters, int save, int Use_t, int MergeStudies)
{
    double pvalue=-1.0;
    double *p=NULL;
    double *covpermutation=NULL;//a permutation of the covariate
    double *r=NULL;//a random number
    double *pAllPermutations=NULL;
    double pomnibus;
    double lpcombined,ltestcombined;
    int sig;
    int *sort=NULL;
    struct EffectSample Es;
    int TotalClusters;
    int coordinate, cluster;
    int cl, NnullClusters;
    int i;
    int study;
    int permutation;
    int contrast=IsContrastStudy(c);
    int *ClusterUsed=NULL;
    HDC hDC=GetDC(hwnd);
    char txt[256];
    FILE *fp=NULL;
    char fname[MAX_PATH];


    memset(&Es,0,sizeof(struct EffectSample));
    if (!MakeEffectSampleStructure(&Es, (*c).Nexperiments,ID_REGRESSIONZ)) goto END;


    if (!(pAllPermutations=(double *)malloc(sizeof(double)*POST_HOC_PERMUTATIONS*SigClusters))) goto END;//-----the p-values from the permuted clusters-------
    if (!(p=(double *)malloc(SigClusters*sizeof(double)))) goto END;//-------observed p-values----------
    if (!(covpermutation=(double *)malloc((*c).Nexperiments*sizeof(double)))) goto END;//------the permuted covariate----------
    if (!(r=(double *)malloc((*c).Nexperiments*sizeof(double)))) goto END;//---------random numbers for the permutation-----------
    if (!(sort=(int *)malloc((*c).Nexperiments*sizeof(int)))) goto END;



    //---------how many clusters are there?----------------
    TotalClusters=0;
    for (coordinate=0; coordinate<(*c).TotalFoci; coordinate++)
    {
        if ((*c).cluster[coordinate]>TotalClusters) TotalClusters=(*c).cluster[coordinate];
    }
    if (!(ClusterUsed=(int *)malloc(TotalClusters*sizeof(int)))) goto END;



    //---------get a vector of clusters that are significant and used-----------
    for (cluster=1; cluster<=TotalClusters; cluster++)
    {
        ClusterUsed[cluster-1]=0;
        coordinate=0;
        while( (coordinate<(*c).TotalFoci) && ((*c).cluster[coordinate]!=cluster) )
        {
            coordinate++;
        }
        if ((coordinate<(*c).TotalFoci) && ((*c).p[coordinate]<=pmeanz)) ClusterUsed[cluster-1]=1;
    }


    //-------get the p-values for each cluster that is significant (p<=pmeanz)-------------
    cl=0;
    for (cluster=1; cluster<=TotalClusters; cluster++)
    {
        if ((cl<SigClusters) && ClusterUsed[cluster-1])
        {
            FillEffectStructureWithCluster(&Es, cluster, c, contrast, ID_REGRESSIONZ, save, directory, Use_t, 0);
            p[cl] = PvalueOfClusterRandomEffect(&Es, cluster, ID_REGRESSIONZ, save, directory, NO_SUBANALYSIS);
            cl++;
        }
    }




    //------------Do permutations for omnibus test-----------------
    NnullClusters=0;
    for (permutation=0; permutation<POST_HOC_PERMUTATIONS; permutation++)
    {
        RemoveInput(hwnd);
        sprintf(txt,"Post hoc permutation %d of %d        ",permutation,POST_HOC_PERMUTATIONS);
        TextOut(hDC, 100,100,txt,strlen(txt));
        UpdateWindow(hwnd);

        for (study=0; study<(*c).Nexperiments; study++) r[study] = (double)rand()/RAND_MAX;
        QuickSort(r,sort,(*c).Nexperiments);
        for (cluster=1; cluster<=TotalClusters; cluster++)
        {
            if (ClusterUsed[cluster-1])
            {
                FillEffectStructureWithCluster(&Es, cluster, c, contrast, ID_REGRESSIONZ, DONT_SAVE, directory, Use_t, 0);

                //-----replace the covariate with a random permutation----------
                for (study=0; study<(*c).Nexperiments; study++) Es.cov[sort[study]] = (*c).covariate[study];


                //----------add to all p-values-------------
                pAllPermutations[NnullClusters] = PvalueOfClusterRandomEffect(&Es, cluster, ID_REGRESSIONZ, DONT_SAVE, directory, NO_SUBANALYSIS);
                NnullClusters++;
            }
        }
    }



    //get threshold p-value from permutations
    sprintf(fname,"%s//PostHocFCDR.txt",directory);
    fp=fopen(fname,"w");
    if (fp) fprintf(fp,"Pvalue FCDR\n");
    QuickSort(p,sort,SigClusters);
    for (cl=0; cl<SigClusters; cl++)
    {


        sig=0;
        for (i=0; i<NnullClusters; i++)
        {
            if (pAllPermutations[i]<=p[sort[cl]]) sig++;
        }
        if ((p[sort[cl]]<=critical) && ((double)sig/POST_HOC_PERMUTATIONS/(cl+1)<=critical)) pvalue=p[sort[cl]];
        if (fp)
        {
            fprintf(fp,"%f %f\n",p[sort[cl]], (double)sig/POST_HOC_PERMUTATIONS/(cl+1));
        }


    }
    if (fp) fclose(fp);



    //OMNIBUS
    lpcombined=0.0;
    for (cl=0; cl<SigClusters; cl++)
    {
        if (p[cl]>DBL_MIN) lpcombined += log(p[cl]);
        else lpcombined += log(DBL_MIN);
    }
    pomnibus=0.0;
    for (permutation=0; permutation<POST_HOC_PERMUTATIONS; permutation++)
    {
        ltestcombined=0.0;
        for (cl=0; cl<SigClusters; cl++)
        {
            if (pAllPermutations[permutation*SigClusters + cl]>DBL_MIN) ltestcombined += log(pAllPermutations[permutation*SigClusters + cl]);
            else ltestcombined += log(DBL_MIN);
        }
        if (ltestcombined<=lpcombined) pomnibus += 1.0;
    }
    pomnibus /= POST_HOC_PERMUTATIONS;



    //sprintf(txt,"threshold pvalue=%f omnibus p-value=%f",pvalue,pomnibus);
    //MessageBox(NULL,txt,"",MB_OK);




    //now pvalue is a threshold for regression in clusters that are significant by the ID_MEANZ model
    //make the non significant cluster p-value=1
    cl=0;
    for (cluster=1; cluster<=TotalClusters; cluster++)
    {
        if (ClusterUsed[cluster-1])
        {
            for (coordinate=0; coordinate<(*c).TotalFoci; coordinate++)
            {
                if ((*c).cluster[coordinate]==cluster)
                {
                    (*c).p[coordinate]=p[cl];
                }
            }
            cl++;
        }
        else
        {
            for (coordinate=0; coordinate<(*c).TotalFoci; coordinate++)
            {
                if ((*c).cluster[coordinate]==cluster)
                {
                    (*c).p[coordinate]=1.0;
                }
            }
        }

    }


END:
    FreeEffectSampleStructure(&Es);
    if (ClusterUsed) free(ClusterUsed);
    if (p) free(p);
    if (covpermutation) free(covpermutation);
    if (pAllPermutations) free(pAllPermutations);
    if (r) free(r);
    if (sort) free(sort);

    return pvalue;
}


//======================================================================================================
//DO POST HOC SUBANALYSIS
//TAKE ONLY THOSE EXPERIMENTS THAT ARE LABELED FOR SUBANALYSIS
//GET THE P-VALUES AND EFFECT ESTIMATES IN THE ALREADY DEFINED CLUSTERS
//======================================================================================================
int SubAnalysisPostHoc(struct Coordinates *Co, int Nclusters, int model, int contrast, char directory[], int Use_t)
{
    struct Coordinates cpy;
    double *p=NULL;
    int result=0;
    int sub=0;
    int study;

    memset(&cpy,0,sizeof(struct Coordinates));

    for (study=0; study<(*Co).Nexperiments; study++)
    {
        if ((*Co).subanalysis[study]) sub=1;
    }

    if (!sub) goto END;///there are no studies for subanalysis

    if (!CopyCoordinates(Co, &cpy)) goto END;

    if (!GetSubAnlysesCoordinates(&cpy)) goto END;
    if (cpy.Nexperiments<=0) goto END;

//char txt[256];
//sprintf(txt,"%d %d",(*Co).TotalFoci,(*Co).Nexperiments);
//MessageBox(NULL,txt,"",MB_OK);

    if (!(p=(double *)malloc(Nclusters*sizeof(double)))) goto END;
    GetPvaluesForEachCluster(&cpy, Nclusters,  p, contrast, model, SAVE, directory, Use_t, SUBANALYSIS);

    result=1;
END:
    FreeCoordinates(&cpy);
    if (p) free(p);
    return result;
}


//======================================================================================================
//test if the experiments are a contrast of two populations
//both the subjects and controls entry in the coordinates file should be>0
//subjects MUST be > 0, so no need to test
//======================================================================================================
int IsContrastStudy(struct Coordinates *c)
{
    int study;

    for (study=0; study<(*c).Nexperiments; study++)
    {
        if ((*c).ControlsInExp[study]<=0) return 0;
    }
    return 1;
}



//======================================================================================================
//SAVE DATA FOR A FOREST PLOT
//modified for subanalysis 12/04/2017
//======================================================================================================
int ForestPlotR(struct Coordinates *c, struct EffectSample *Es, double pvalue, int cluster, char directory[],
                int subanalysis)
{
    char fname[MAX_PATH];
    int result=0;
    int study;
    float Min,Max;
    float MaxLength;
    FILE *fp;

    if (!subanalysis) sprintf(fname,"%s\\Forest%d.R",directory,cluster);
    else sprintf(fname,"%s\\Forest_subanalysis%d.R",directory,cluster);
    if (!(fp=fopen(fname,"w"))) goto END;

    //margins
    MaxLength=0.0;
    for (study=0; study<(*c).Nexperiments; study++) if (strlen((*c).ID[study].txt)>(int)MaxLength)
        {
            MaxLength=(float)strlen((*c).ID[study].txt);
        }
    if (fp) fprintf(fp,"#Forest plot produced by %s\n",(*c).coordinate_file_name);
    if (fp) fprintf(fp,"#Alter font size and main title scale here\n");
    if (fp) fprintf(fp,"ForestFontsize = 10\n");
    if (fp) fprintf(fp,"ForestMainScale = 1.3\n");
    if (fp) fprintf(fp,"par(ps=ForestFontsize, cex.main=ForestMainScale, mar=c(4.5, %f, 2, 1))\n",MaxLength/1.5);

    //x axis
    Min=1000.0;
    Max=-1000.0;
    if (fp) fprintf(fp,"x=c(");
    for (study=0; study<(*c).Nexperiments; study++)
    {
        switch((*Es).censor[study])
        {
        case NOT_CENSORED:
        case INTERVAL_CENSORED:
            if ((!study) && (fp)) fprintf(fp,"%f",(*Es).d[study]);
            else if (fp) fprintf(fp,",%f",(*Es).d[study]);
            break;
        case LEFT_CENSORED:
            if (!study) fprintf(fp,"%f",-(*Es).CensorLevel[study]);
            else if (fp) fprintf(fp,",%f",-(*Es).CensorLevel[study]);
            break;
        case RIGHT_CENSORED:
            if (!study) fprintf(fp,"%f",(*Es).CensorLevel[study]);
            else if (fp) fprintf(fp,",%f",(*Es).CensorLevel[study]);
            break;
        }

        if ((*Es).d[study]+1.96*(*Es).SampleSD[study]>Max) Max=(*Es).d[study]+1.96*(*Es).SampleSD[study];
        if ((*Es).d[study]-1.96*(*Es).SampleSD[study]<Min) Min=(*Es).d[study]-1.96*(*Es).SampleSD[study];

    }
    if (fp) fprintf(fp,")\n");


    //y axis
    if (fp) fprintf(fp,"y=c(%d",1);
    for (study=2; study<=(*c).Nexperiments; study++) if (fp) fprintf(fp,",%d",study);
    if (fp) fprintf(fp,")\n");

    //plot
    if (fp) fprintf(fp,"plot(x,y,xlab=\"Effect Size\",ylab=\"\",axes=FALSE,xlim=c(%f,%f),pch=c(%d",Min,Max,fabs((*Es).d[0])>0.0 ? 20:1);
    for (study=1; study<(*c).Nexperiments; study++)
    {
        if (fp) fprintf(fp,",%d",fabs((*Es).d[study])>0.0 ? 20:1);
    }
    if (fp) fprintf(fp,"))\n");



    //y axis labels
    if (fp) fprintf(fp,"axis(2,1:%d,c(\"%s\"",(*Es).Samples,(*c).ID[0].txt);///print the start from the first valid study
    for (study=1; study<(*c).Nexperiments; study++) if (fp) fprintf(fp,",\"%s\"",(*c).ID[study].txt);
    if (fp) fprintf(fp,"),las=1)\n");


    //x axis labels
    if (fp) fprintf(fp,"axis(1, seq(%d,%f,0.1))\n",(int)(Min-0.5),Max);

    //main title
    if (fp) fprintf(fp,"title(main=\"mean=%1.2f sd=%1.2f p=%1.2e\")\n",(*Es).mean, (*Es).sigma, pvalue);

    //error bars
    for (study=0; study<(*c).Nexperiments; study++)
    {
        switch((*Es).censor[study])
        {
        case NOT_CENSORED:
            if ((*Es).censor[study]==NOT_CENSORED)
                if (fp) fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=1, lwd=2)\n",(*Es).d[study]-1.96*(*Es).SampleSD[study],
                                    (*Es).d[study]+1.96*(*Es).SampleSD[study], study+1,study+1);
            break;
        case INTERVAL_CENSORED:
            if (fp) fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2)\n",-(*Es).CensorLevel[study],
                                (*Es).CensorLevel[study], study+1,study+1);
            break;
        case LEFT_CENSORED:
            if (fp) fprintf(fp,"lines(c(%d,%f),c(%d,%d),lty=3, lwd=2)\n",(int)(Min-0.5),-(*Es).CensorLevel[study], study+1,study+1);
            break;
        case RIGHT_CENSORED:
            if (fp) fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=3, lwd=2)\n",(*Es).CensorLevel[study],Max, study+1,study+1);
            break;
        }

    }

    //the mean effect line
    if ((*Es).Model==ID_MEANZ && (fp)) fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=2, lwd=2)\n",(*Es).mean,(*Es).mean,1,(*Es).Samples);
    else if (fp) fprintf(fp,"lines(c(%f,%f),c(%d,%d),lty=2, lwd=2)\n",(*Es).covariate,(*Es).covariate,1,(*Es).Samples);

    if (fp) fclose(fp);

    result=1;
END:

    return result;
}






//======================================================================================================
//======================================================================================================
//COUNT THE NUMBER OF COINCIDENT EXPERIMENTS AT EACH FOCI WITHIN CLUSTER
//THIS SHOULD BE HIGHEST WHERE THERE ARE PEAK DENSITIES
//overlap[0..TotalFoci-1] is a normalised measure of study overlap (within ClusteringDistance) at the end
//======================================================================================================
int WithinClusterCoordinateOverlaps(struct Coordinates *CoordinateStruct, float *overlap, float ClusteringDistance)
{

    int coordinate,coordinate2;
    int study;
    int Ncoordinates=(*CoordinateStruct).TotalFoci;
    int Nexperiments=(*CoordinateStruct).Nexperiments;
    int coordinateNcoordinates;
    char *StudyOverlap=NULL;
    double *DM=NULL;
    float min2dist=ClusteringDistance*ClusteringDistance;

    if (!(DM=(double *)malloc(Ncoordinates*Ncoordinates*sizeof(double)))) goto END;
    if (!(StudyOverlap=(char *)malloc(Nexperiments))) goto END;

    Distance2Matrix((*CoordinateStruct).x, (*CoordinateStruct).y, (*CoordinateStruct).z,
                    (*CoordinateStruct).experiment, (*CoordinateStruct).TotalFoci, DM);

    coordinateNcoordinates=0;
    for (coordinate=0; coordinate<Ncoordinates; coordinate++)
    {
        overlap[coordinate]=0.0;//A COORDINATE ON ITS OWN HAS ZERO OVERLAP
        if ((*CoordinateStruct).cluster[coordinate])
        {
            memset(StudyOverlap,0,Nexperiments);
            for (coordinate2=0; coordinate2<Ncoordinates; coordinate2++)
            {
                if ( ((*CoordinateStruct).cluster[coordinate]==(*CoordinateStruct).cluster[coordinate2]) && ((*CoordinateStruct).experiment[coordinate] != (*CoordinateStruct).experiment[coordinate2]) && (!StudyOverlap[(*CoordinateStruct).experiment[coordinate2]]) )
                {
                    if (DM[coordinate2 + coordinateNcoordinates]<=min2dist) StudyOverlap[(*CoordinateStruct).experiment[coordinate2]]=1;
                }
            }
            for (study=0; study<Nexperiments; study++)
            {
                overlap[coordinate] += (float)StudyOverlap[study];//this gives peaks where there is a lot of overlap between coordinates. This helps separate clusters from each other
            }
        }
        coordinateNcoordinates += Ncoordinates;
    }

END:
    if (DM) free(DM);
    if (StudyOverlap) free(StudyOverlap);
    return 1;
}

//======================================================================================================
//COMPUTE THE P VALUE FOR EACH CLUSTER
//======================================================================================================
int GetPvaluesForEachCluster(struct Coordinates *CoordinateStruct, int Nclusters,
                             double *p, int contrast, int model, int save,
                             char directory[], int Use_t, int subanalysis)
{
    int result=0;
    int cluster;
    int coordinate;
    int Nsize;
    struct EffectSample Es;
    char fname[MAX_PATH];
    FILE *fp=NULL;

    memset(&Es,0,sizeof(struct EffectSample));

    if (!subanalysis) sprintf(fname,"%s\\ClusterZp.csv",directory);
    else sprintf(fname,"%s\\ClusterZp_subanalysis.csv",directory);
    if (save) fp=fopen(fname,"w");

    if (fp && Use_t) fprintf(fp,"Use_t\n");

    if (!MakeEffectSampleStructure(&Es, (*CoordinateStruct).Nexperiments,model)) goto END;
    for (cluster=1; cluster<=Nclusters; cluster++)
    {

        if (FillEffectStructureWithCluster(&Es, cluster, CoordinateStruct, contrast, model, save, directory, Use_t, subanalysis))
        {
            p[cluster-1] = PvalueOfClusterRandomEffect(&Es, cluster, model, save, directory, subanalysis);
        }
        else
        {
            p[cluster-1] = 1.0;
            Es.mean=0.0;
            Es.sigma=1.0;
            Es.Ll0=Es.Lla=0.0;
        }


        if ((save==SAVE))
        {
            if (model==ID_MEANZ) ForestPlotR(CoordinateStruct, &Es, p[cluster-1], cluster, directory, subanalysis);
        }


        Nsize=0;
        for (coordinate=0; coordinate<(*CoordinateStruct).TotalFoci; coordinate++)
        {
            if ((*CoordinateStruct).cluster[coordinate]==cluster)
            {
                (*CoordinateStruct).p[coordinate] = p[cluster-1];
                Nsize++;
            }
        }

        if (fp && (save==SAVE))
        {
            if (model==ID_MEANZ) fprintf(fp,"cluster=%d,  p=%g,  mean=%f, sd=%f,  NullLl=%f,  HaLl=%f,ContributingFoci=%d\n", cluster, p[cluster-1], Es.mean, Es.sigma, Es.Ll0, Es.Lla, Nsize);
            else if (fp) fprintf(fp,"cluster=%d,  p=%g,  mean=%f, sd=%f, covariate=%f, NullLl=%f,  HaLl=%f,ContributingFoci=%d  \n", cluster, p[cluster-1], Es.mean, Es.sigma, Es.covariate, Es.Ll0, Es.Lla, Nsize);
        }
    }

    if (fp && save) fclose(fp);

    result=1;
END:
    FreeEffectSampleStructure(&Es);

    return result;
}

//======================================================================================================
//modified 22/10/2016 to save an RGB image as well
//modified 22/01/2017 to save an RGB image of the sign of the reported effect
//======================================================================================================
int SaveSignificantEffectClusters(double critical, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                                  struct Coordinates *CoordinateStruct, char fname[], char fnameRGB[], char fnameSignRGB[],
                                  int Marker)
{
    struct Image clusterimg, clusterimgRGB, signRGB;
    int result=0;
    int coordinate;
    int cl;
    int x,y,z, voxel, voxels=X*Y*Z;
    int XY=X*Y;
    int ColourLevels;//there are 6 colours before they repeat
    int MaxClusters;
    RGBQUAD rgb;

    memset(&clusterimg,0,sizeof(struct Image));
    memset(&clusterimgRGB,0,sizeof(struct Image));
    memset(&signRGB,0,sizeof(struct Image));

    //get the biggest cluster number
    MaxClusters=0;
    for (coordinate=0; coordinate<(*CoordinateStruct).TotalFoci; coordinate++)
    {
        if ((*CoordinateStruct).cluster[coordinate]>MaxClusters) MaxClusters=(*CoordinateStruct).cluster[coordinate];
    }

    ColourLevels = MaxClusters/6+1;

    if (!MakeImage(&clusterimg, X, Y, Z, 1, dx, dy, dz, x0, y0, z0, 1.0, 0.0, DT_FLOAT, NIFTI, "Significant clusterZ")) goto END;
    if (!MakeImage(&clusterimgRGB, X, Y, Z, 1, dx, dy, dz, x0, y0, z0, 1.0, 0.0, DT_RGB, NIFTI, "Significant clusterZ RGB")) goto END;
    if (!MakeImage(&signRGB, X, Y, Z, 1, dx, dy, dz, x0, y0, z0, 1.0, 0.0, DT_RGB, NIFTI, "Effect Sign RGB")) goto END;

    for (coordinate=0; coordinate<(*CoordinateStruct).TotalFoci; coordinate++)
    {
        for (z=-Marker; z<=Marker; z++)
        {
            for (y=-Marker; y<=Marker; y++)
            {
                for (x=-Marker; x<=Marker; x++)
                {

                    voxel = (*CoordinateStruct).voxel[coordinate] + x + X*y + XY*z;
                    if ((voxel>=0) && (voxel<voxels))
                    {

                        if (((*CoordinateStruct).cluster[coordinate]>0))
                        {
                            /*(x && !(y || z)) || (y && !(x || z)) || (z && !(x || y)) || (abs(x)<2 && abs(y)<2 && abs(z)<2)*/
                            if ( (x*x + y*y + z*z)<=Marker*Marker )
                            {
                                cl=(*CoordinateStruct).cluster[coordinate];
                                clusterimg.img[voxel] = (float)cl;

                                if ((*CoordinateStruct).p[coordinate]<=critical)
                                {
                                        rgb=Colours(cl-1,ColourLevels);
                                        memcpy(&clusterimgRGB.img[voxel], &rgb, sizeof(float));
                                }

                            }
                        }
                        if (( (x*x + y*y + z*z)<=3) )
                        {
                            memset(&rgb,128,sizeof(RGBQUAD));
                            if ((*CoordinateStruct).Zsc[coordinate]>0.0) rgb.rgbRed=255;
                            else rgb.rgbBlue=255;
                            memcpy(&signRGB.img[voxel], &rgb, sizeof(float));
                        }
                    }
                }
            }
        }
    }

    if (strlen(fname))
    {
        sprintf(clusterimg.filename, "%s", fname);
        //Save(&clusterimg);
        SaveAsCharImage(&clusterimg,0);
    }
    if (strlen(fnameRGB))
    {
        sprintf(clusterimgRGB.filename, "%s", fnameRGB);
        Save(&clusterimgRGB);
    }
    if (strlen(fnameSignRGB))
    {
        sprintf(signRGB.filename, "%s", fnameSignRGB);
        Save(&signRGB);
    }


    result=1;
END:
    ReleaseImage(&clusterimg);
    ReleaseImage(&clusterimgRGB);
    ReleaseImage(&signRGB);

    return result;
}


//======================================================================================================
//======================================================================================================
int TestClusterZ(HWND hwnd, struct Image *mask, int model, int Use_t)
{

    int X,Y,Z;
    int i;
    int SigClusters,TotalNullClusters;
    float ClusteringDistance;
    float x0,y0,z0;
    float dx, dy, dz;
    struct Coordinates CoordinateStruct;
    char fname[MAX_PATH];

    x0 = (*mask).x0;
    y0 = (*mask).y0;
    z0 = (*mask).z0;
    dx = (*mask).dx;
    dy = (*mask).dy;
    dz = (*mask).dz;
    X = (*mask).X;
    Y = (*mask).Y;
    Z = (*mask).Z;

    memset(&CoordinateStruct,0,sizeof(struct Coordinates));
    LoadExperimentsCOORDINATES(hwnd, &CoordinateStruct, X, Y, Z, dx, dy, dz, x0, y0, z0);
    sprintf(fname,"%s",CoordinateStruct.coordinate_file_name);
    i = DirectoryFileDivide(fname);
    fname[i] = '\0';

    MergeCoordinatesbyStudy(&CoordinateStruct);

    //double EstimateClusteringDistanceUsingNull(struct Coordinates *CoordinateStruct, float mask[], int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, float fwhmSD, float proportion)
    ClusteringDistance = EstimateClusteringDistanceUsingNull(hwnd, &CoordinateStruct, (*mask).img,  X,  Y,  Z,  dx,  dy,  dz,  x0,  y0,  z0,  0.05, 0);

    //double pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, double ClusteringDistance, float critical, int model, char directory[])
    pClusterZ(hwnd, &CoordinateStruct, (*mask).img,  X, Y, Z, dx, dy, dz, x0, y0, z0, ClusteringDistance, 0.05, model, fname, 0,
              &SigClusters, &TotalNullClusters, 1,Use_t, ID_DO_FCDR, ID_CLUSTER_ALL, DEFAULT_MARKER_SIZE);

    FreeCoordinates(&CoordinateStruct);

    return 1;
}
//======================================================================================================
//GET P VALUE FOR A CLUSTER USING
//LIKELIHOOD RATIO TEST
//H0: mean=0.0
//Ha: mean!=0.0
//returns the p value for the cluster and sets the mean value in the EffectSample structure to the MLE
//======================================================================================================
double PvalueOfClusterRandomEffect(struct EffectSample *Es, int cluster, int model, int save, char directory[], int subanalysis)
{
    double P=1.0;//the default value is 1.0
    double mean,sd, cov;
    double HaLl;//log likelihood for Ha
    double H0Ll;//log likelihood for H0
    double D;
    char txt[256];

    mean=sd=cov=0.0;

    switch (model)
    {

    case ID_MEANZ:
    case ID_POSTHOC_REGRESSIONZ:
        //log likelihood UNDER THE NULL HYPOTHESIS
        H0Ll = MLE_SD(Es, &sd);
        //log likelihood UNDER THE ALTERNATIVE HYPOTHESIS
        HaLl = MLE_mean_sd(Es, &mean, &sd);
        sprintf(txt,"Mean Z");
        break;

    case ID_REGRESSIONZ:
        H0Ll = MLE_mean_sd(Es, &mean, &sd);
        HaLl = MLE_mean_sd_cov(Es, &mean, &sd, &cov);
        sprintf(txt,"Regression Z");
        break;

    default:
        MessageBox(NULL,"No Such Model Type","",MB_OK|MB_ICONWARNING);
        H0Ll=HaLl=0.0;
        sprintf(txt,"null");
        break;

    }


    (*Es).mean=mean;
    (*Es).sigma=sd;
    (*Es).covariate=cov;
    (*Es).Ll0 = H0Ll;
    (*Es).Lla = HaLl;


    //COMPUTE THE P VALUE BY LIKELIHOOD RATIO TEST
    D = 2.0*(HaLl - H0Ll);

    if ( (!isinf(H0Ll)) && (!isinf(HaLl))  )
    {
        P = ChiSquaredPvalue(1.0, D);
    }
    else
    {
        if (isinf(H0Ll)) P = 0.0;
    }


    if ((save==SAVE))
    {
        FILE *fp=NULL;
        char fname[MAX_PATH];
        if (subanalysis==NO_SUBANALYSIS) sprintf(fname,"%s\\cluster%d.txt",directory, cluster);
        else sprintf(fname,"%s\\cluster%d_subanalysis.txt",directory, cluster);
        if ((fp=fopen(fname,"a")))
        {
            fprintf(fp,"H0=%f\n Ha=%f\n model=%s\n pvalue=%f\n mean=%f\n sd=%f\n cov=%f\n statistic=%f", H0Ll, HaLl, txt, P, mean, sd, cov,D);
            fclose(fp);
        }
    }

    return P;
}


//======================================================================================================
//report the significant clusters
//the format is:
//x y z Nexperiments Minimum_p_value; where {x,y,z} is the peak focus in the cluster
///changed 22/05/2018 to use the focus at the peak overlap rather than the mean focus in the cluster
/// PeakFocus to do this
//======================================================================================================
int ClusterVolumeEstimate(struct Coordinates *Co, int cluster, int X, int Y, int Z);
int ReportClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct,
                   char directory[], char file[],
                   int X, int Y, int Z, float z0,
                   float dx, float dy, float dz,
                   double critical,
                   int MergeGroups, int control, int Use_t, double ClusteringDistance)
{
    char fname[MAX_PATH];
    FILE *fp;
    int cluster;
    int Nclusters;              //how many clusters are there to report
    int *experiments=NULL;      //how many experiments contribute to the clusters
    int Nfoci=(*CoordinateStruct).TotalFoci;
    int NsignificantFoci;
    int foci, iexp, FoundContributor;
    int xi,yi,zi;
    int peakfocus;
    float x,y,z;
    float *overlap=NULL;
    double minp;
    int ClusterVoxels;
    char *labels=NULL;
    char *b=NULL;
    int Nentries,Nl;
    struct Image Tal;



//LOAD THE TALAIRACH DATA
    memset(&Tal,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    LoadFromFileName(hwnd, fname, &Tal, 0);
    labels=LoadTalairachLabels(&Nl);
    Nentries=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,Nentries);

//count the number of significant foci
    NsignificantFoci=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        if ((*CoordinateStruct).p[foci]<=critical) NsignificantFoci++;
    }

//find the number of clusters
    Nclusters=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        if ((*CoordinateStruct).cluster[foci]>Nclusters) Nclusters=(*CoordinateStruct).cluster[foci];
    }

    if (!(overlap=(float *)malloc((*CoordinateStruct).TotalFoci*sizeof(float)))) goto END;
    WithinClusterCoordinateOverlaps(CoordinateStruct, overlap, ClusteringDistance);

//count the number of significant studies contributing to each cluster
    if (!(experiments=(int *)malloc((Nclusters+1)*sizeof(int)))) goto END;
    memset(experiments,0,(Nclusters+1)*sizeof(int));
    for (cluster=1; cluster<=Nclusters; cluster++)
    {
        for (iexp=0; iexp<(*CoordinateStruct).Nexperiments; iexp++)
        {
            FoundContributor=0;
            for (foci=0; foci<Nfoci; foci++)
            {
                if (((*CoordinateStruct).experiment[foci] == iexp) &&
                        ((*CoordinateStruct).cluster[foci] == cluster) &&
                        ((*CoordinateStruct).p[foci] <= critical)) FoundContributor=1;
            }
            if (FoundContributor) experiments[cluster]++;
        }
    }



    sprintf(fname,"%s\\%s",directory,file);
    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"%s\n",(*CoordinateStruct).coordinate_file_name);
        if (MergeGroups) fprintf(fp,"Studies Merged\n");

        if (Use_t) fprintf(fp,"t statistic used\n");
        else fprintf(fp,"Z score used\n");

        if (critical>0.0) fprintf(fp,"p-value for significance <=, %f\n", critical);
        else  fprintf(fp,"p-value for significance =, 0.0\n");

        if (control==ID_DO_FCDR) fprintf(fp,"FCDR used\n");
        else fprintf(fp,"FWE used\n");

        fprintf(fp,"Proportion of foci that are significant,%f\n",(float)NsignificantFoci/Nfoci);
        fprintf(fp,"Clustering Distance,%f\n",ClusteringDistance);
        fprintf(fp,"Number of foci, %d\n", (*CoordinateStruct).TotalFoci);
        fprintf(fp,"Number of studies, %d\n", (*CoordinateStruct).Nexperiments);
        fprintf(fp,"Talairach report, , , , , Cluster{x y z},p_value,Volume (mm^3),Number Of significant Studies,Slice,Within Cluster Overlap,Studies,,,,,Nearest GM\n\n");
        for (cluster=1; cluster<=Nclusters; cluster++)
        {

            peakfocus = PeakFocus(CoordinateStruct, overlap, cluster);
            minp = (*CoordinateStruct).p[peakfocus];

            if ( peakfocus>=0 && (minp<=critical) )
            {

                if (fp) fprintf(fp,"cluster %d\n",cluster);

                ClusterVoxels = ClusterVolumeEstimate(CoordinateStruct, cluster, X, Y, Z);

                x=(*CoordinateStruct).x[peakfocus];
                y=(*CoordinateStruct).y[peakfocus];
                z=(*CoordinateStruct).z[peakfocus];

                xi=(int)((x+Tal.x0)/Tal.dx+0.5);
                yi=(int)((y+Tal.y0)/Tal.dy+0.5);
                zi=(int)((z+Tal.z0)/Tal.dz+0.5);

                if (labels && Tal.img)
                {
                    b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                    if (fp) fprintf(fp,"%s,",&b[1]);
                }



                zi=(int)((z+z0)/dz+0.5);
                if (fp) fprintf(fp," (%5.1f  %5.1f  %5.1f),%f,%f,%d,%d,", x, y, z,minp, ClusterVoxels*dx*dy*dz,experiments[cluster], zi);

                //list each experiment that contributes to this cluster
                //report the lowest p value for the experiment, and indicate if it is significant
                for (iexp=0; iexp<(*CoordinateStruct).Nexperiments; iexp++)
                {
                    for (foci=0; foci<Nfoci; foci++)
                    {
                        if (((*CoordinateStruct).cluster[foci]==cluster) && ((*CoordinateStruct).experiment[foci] == iexp))
                        {

                            if (fp) fprintf(fp,"%d, %s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
                                                (int)overlap[foci],
                                                (*CoordinateStruct).ID[(*CoordinateStruct).experiment[foci]].txt,
                                                (*CoordinateStruct).CTRST[(*CoordinateStruct).experiment[foci]].txt,
                                                (*CoordinateStruct).CND[(*CoordinateStruct).experiment[foci]].txt,
                                                (*CoordinateStruct).x[foci],(*CoordinateStruct).y[foci],(*CoordinateStruct).z[foci],(*CoordinateStruct).Zsc[foci]);

                            if (labels && Tal.img)
                            {
                                xi=(int)(((*CoordinateStruct).x[foci]+Tal.x0)/Tal.dx+0.5);
                                yi=(int)(((*CoordinateStruct).y[foci]+Tal.y0)/Tal.dy+0.5);
                                zi=(int)(((*CoordinateStruct).z[foci]+Tal.z0)/Tal.dz+0.5);
                                b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                                if (fp) fprintf(fp,"%s\n , , , , , , , , , ,",&b[1]);
                            }
                        }
                    }

                }
            }
            if (fp) fprintf(fp,"\n");
        }
        fclose(fp);
    }


END:
    if (labels) free(labels);
    if (experiments) free(experiments);
    if (overlap) free(overlap);
    ReleaseImage(&Tal);

    return Nclusters;
}

//======================================================================================================
//Find the focus that is nearest to the peak overlap in Cluster
//======================================================================================================
int PeakFocus(struct Coordinates *Co, float overlap[], int Cluster)
{
    int focus;
    int PeakFocus=-1;
    float MaxOverlap=0.0;
    float x,y,z;
    float norm;
    double dist2,mindist2;

    //find the maximum overlap
    for (focus=0; focus<(*Co).TotalFoci; focus++)
    {
        if ((*Co).cluster[focus]==Cluster && overlap[focus]>MaxOverlap)
        {
            PeakFocus = focus;
            MaxOverlap = overlap[focus];
        }
    }


    if (PeakFocus>=0)
    {
        //find the mean focus at this max overlap
        norm=0.0;
        x=y=z=0.0;
        for (focus=0; focus<(*Co).TotalFoci; focus++)
        {
            if ((*Co).cluster[focus]==Cluster && overlap[focus]==MaxOverlap)
            {
                x += (*Co).x[focus];
                y += (*Co).y[focus];
                z += (*Co).z[focus];
                norm += 1.0;
            }
        }

        //now find the focus closest to this mean
        if (norm>0.0)
        {
            x /= norm;
            y /= norm;
            z /= norm;
            mindist2=DBL_MAX;
            for (focus=0; focus<(*Co).TotalFoci; focus++)
            {
                if ((*Co).cluster[focus]==Cluster && overlap[focus]==MaxOverlap)
                {
                    dist2 = (x-(*Co).x[focus])*(x-(*Co).x[focus]) +
                            (y-(*Co).y[focus])*(y-(*Co).y[focus]) +
                            (z-(*Co).z[focus])*(z-(*Co).z[focus]);
                    if (dist2<mindist2)
                    {
                        PeakFocus = focus;
                        mindist2 = dist2;
                    }
                }
            }
        }
    }

    return PeakFocus;
}

//======================================================================================================
//======================================================================================================
int ClusterVolumeEstimate(struct Coordinates *Co, int cluster, int X, int Y, int Z)
{
    int voxelcount=0;
    int voxel,i,j,k;
    int voxels=X*Y*Z;
    int XY=X*Y;
    int focus;
    int MarkerSize=3;
    char *mask=NULL;

    if (!(mask=(char *)calloc(voxels, sizeof(char)))) goto END;

    for (focus=0; focus<(*Co).TotalFoci; focus++)
    {
        if ((*Co).cluster[focus]==cluster)
        {

            for (k=-MarkerSize; k<=MarkerSize; k++)
            {
                for (j=-MarkerSize; j<=MarkerSize; j++)
                {
                    for (i=-MarkerSize; i<=MarkerSize; i++)
                    {
                        if (i*i + j*j + k*k<=MarkerSize*MarkerSize)
                            voxel=(*Co).voxel[focus] + i + j*X + k*XY;
                        if (voxel>=0 && voxel<voxels)
                        {
                            mask[voxel]=1;
                        }
                    }
                }
            }
        }
    }
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (mask[voxel]) voxelcount++;
    }

END:
    if (mask) free(mask);
    return voxelcount;
}




//======================================================================================================
//MLE OF MODEL WITH ZERO MEAN, AND NO COVARIATE
//ONLY PARAMETER IS THE STANDARD DEVIATION
//======================================================================================================
double MLE_SD(struct EffectSample *Es, double *MLEsd)
{
    double Ll, Llmax;
    double sd,del;
    double bestsd;
    double scale[1];
    double p[1];

    *MLEsd = bestsd = 0.0;
    del=0.1;


    Llmax = -DBL_MAX;
    for (sd=0.01; sd<=1.0; sd+=del)
    {
        Ll = LogLikelihoodOfCluster(Es, 0.0, sd, 0.0);
        if ((!isinf(Ll)) && (Ll>Llmax))
        {
            Llmax = Ll;
            bestsd = sd;
        }
    }

    scale[SD_PARAMETER] = 0.1;
    p[SD_PARAMETER] = bestsd;

    Llmax = -GoldenSearch(p, scale, 1, NegativeLogLikelihoodOfCluster(p, 1, Es), NegativeLogLikelihoodOfCluster, Es, 30);

    *MLEsd = p[SD_PARAMETER];

    return Llmax;
}



//======================================================================================================
//MLE OF MODEL NO COVARIATE
//ONLY PARAMETERS ARE THE MEAN AND STANDARD DEVIATION
//======================================================================================================
double MLE_mean_sd(struct EffectSample *Es, double *MLEmean, double *MLEsd)
{
    double Ll,Llmax;
    double mean,sd;
    double bestmean,bestsd;
    double scale[2];
    double p[2];

    (*MLEmean) = (*MLEsd) = bestmean = bestsd = 0.0;

    Llmax = -DBL_MAX;
    for (sd=0.01; sd<=1.01; sd+=0.2)
    {
        for (mean=-1.5; mean<=1.5; mean+=0.2)
        {
            Ll = LogLikelihoodOfCluster(Es, mean, sd, 0.0);
            if ((!isinf(Ll)) && (Ll>Llmax))
            {
                Llmax = Ll;
                bestmean = mean;
                bestsd = sd;
            }
        }
    }

    p[MEAN_PARAMETER] = bestmean;
    p[SD_PARAMETER] = bestsd;

    scale[0]=scale[1]=0.2;
    Llmax = -DownHillSimplex(p, 2, scale, 1, NegativeLogLikelihoodOfCluster, Es, 20);

    *MLEmean = p[MEAN_PARAMETER];
    *MLEsd = p[SD_PARAMETER];

    return Llmax;
}
//======================================================================================================
//MLE OF MODEL NO COVARIATE
//PARAMETERS ARE THE MEAN, STANDARD DEVIATION AND COVARIATE COEFFICIENT
//======================================================================================================
double MLE_mean_sd_cov(struct EffectSample *Es, double *MLEmean, double *MLEsd, double *MLEcov)
{
    double Ll,Llmax;
    double cov;
    double bestmean,bestsd,bestcov;
    double CovMax=sqrt(Var((*Es).cov, (*Es).Samples));
    double scale[3];
    double p[3];


    (*MLEmean) = (*MLEsd) = (*MLEcov) = bestmean = bestsd = bestcov = 0.0;


    if (CovMax<=0.0) return MLE_mean_sd(Es, MLEmean, MLEsd);

    MLE_mean_sd(Es, &bestmean, &bestsd);

    Llmax = -DBL_MAX;
    for (cov=-1.0/CovMax; cov<=1.0/CovMax; cov+=0.1/CovMax)
    {
        Ll = LogLikelihoodOfCluster(Es, bestmean, bestsd, cov);
        if ((!isinf(Ll)) && (Ll>Llmax))
        {
            Llmax = Ll;
            bestcov=cov;
        }
    }



    p[MEAN_PARAMETER] = bestmean;
    p[SD_PARAMETER] = bestsd;
    p[COVARIATE] = bestcov;
    scale[MEAN_PARAMETER]=scale[SD_PARAMETER]=0.2;
    scale[COVARIATE]=1.0/CovMax/3;
    Llmax = -DownHillSimplex(p, 3, scale, 1, NegativeLogLikelihoodOfCluster, Es, 20);

    /*
        FILE *fp;
        char fname[256];

        sprintf(fname,"%s\\MLEcov.csv",REPORT_FOLDER);
        if (fp=fopen(fname,"a"))
        {
            fprintf(fp,"%f,%f,%f,%f,%f,%f\n",bestmean,p[0],bestsd,p[1],bestcov,p[2]);
            if (fp) fclose(fp);
        }
    */

    *MLEmean = p[MEAN_PARAMETER];
    *MLEsd = p[SD_PARAMETER];
    *MLEcov = p[COVARIATE];

    return Llmax;
}


//======================================================================================================
//COMPUTE THE CENSOR LEVEL FOR STUDIES THAT HAVE NONE DECLAIRED
//this is either the minimum Z in the study, a global min Z, or if no Z is declared
//it is set to something sensible
//======================================================================================================
int CensorLevels(struct Coordinates *CoordinateStruct)
{
    int study;
    int coordinate;
    int n;
    double BIG_Z=DBL_MAX;
    double StudyMinZ;
    double DefaultMinZ=3.09;


    for (study=0; study<(*CoordinateStruct).Nexperiments; study++)
    {
        if ((*CoordinateStruct).Zcensor[study]<=0.0)//no censor level given so estimate it
        {
            n=0;
            StudyMinZ=BIG_Z;
            for (coordinate=0; coordinate<(*CoordinateStruct).TotalFoci; coordinate++)
            {
                if ( ((*CoordinateStruct).experiment[coordinate]==study) && (fabs((*CoordinateStruct).Zsc[coordinate])<StudyMinZ) && (fabs((*CoordinateStruct).Zsc[coordinate])>1.0) )
                {
                    StudyMinZ = fabs((*CoordinateStruct).Zsc[coordinate]);
                    n++;
                }
            }
            if (n>0)
            {
                (*CoordinateStruct).Zcensor[study] = StudyMinZ;//minimum reported
            }
            else (*CoordinateStruct).Zcensor[study] = DefaultMinZ;//default value
        }
    }

    return 1;
}


//======================================================================================================
//Compute the mean covariate
//======================================================================================================
double ComputeMeanCovariate(struct Coordinates *Co)
{
    int study;
    double MeanCovariate=0.0;

    if ((*Co).Nexperiments<=0) return 0.0;

    for (study=0; study<(*Co).Nexperiments; study++)
    {
        MeanCovariate += (*Co).covariate[study];
    }
    return MeanCovariate / (*Co).Nexperiments;
}

//======================================================================================================
//FILL THE EffectSample FOR A GIVEN CLUSTER
/*
struct EffectSample
{
    short int Studies;//the number of studies
    double mean;//the estimate of the mean
    double sigma;//the estimate of the  standard deviation
    double covariate;//the estimate of the covariate parameter for REGRESSION model
    double Ll0;//the log likelihood of the null
    double Lla;//the log likelihood of the alternative
    double *d;//The effect size, which is Z/sqrt(Number of subjects)
    double *cov;//the covariate. Could be the group indicator
    double *CensorLevel;//This is normalised absolute value and could be the minimum magnitude Z from a study, or a reported threshold, or other...
    double *StudySD;//The within study standard deviation sqrt(1/N)
    short int *censor;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, or 0 if not censored
    int Model;
};
*/
//for contrast studies that use a comparison group set contrast to 1. This will then set the variance appropriately
//this sets the correct variance for the likelihood
//For meta-regression the cov array in the coordinate file contains the regressor
//changed 21/12/2017 to modify the estimated effect size variance when a study reports more than one coordinate within a cluster
//======================================================================================================
int FillEffectStructureWithCluster(struct EffectSample *Es, int cluster, struct Coordinates *Co,
                                   int contrast, int model, int save, char directory[],
                                   int Use_t, int subanalysis)
{

    int study;
    int uncensored=0;
    int coordinate;
    int n1,n2;
    double MeanCovariate = ComputeMeanCovariate(Co);
    char Warn[1024];
    int n;

    Warn[0]='\0';
    uncensored=0;
    for (study=0; study<(*Co).Nexperiments; study++)
    {
        if (!(*Co).SubjectsInExp[study])
        {
            (*Es).Samples=0;
            return 0;//should never happen!
        }

        n1=(*Co).SubjectsInExp[study];///subject numbers determine variance
        n2=(*Co).ControlsInExp[study];

        ///default effect size 0 and NOT_CENSORED
        (*Es).d[study] = 0.0;
        (*Es).censor[study]=NOT_CENSORED;

        (*Es).cov[study] = (*Co).covariate[study]-MeanCovariate;//mean shifted covariate

        ///check the number of controls is appropriate for contrast studies
        if (!contrast) n2=0;//there is no second study group
        else if (!(*Co).ControlsInExp[study]) return 0;


        (*Es).CensorLevel[study] = EffectSize((*Co).Zcensor[study], n1, n2, Use_t);

        n=0;
        for (coordinate=0; coordinate<(*Co).TotalFoci; coordinate++)
        {
            if ( ((*Co).experiment[coordinate] == study) && ((*Co).cluster[coordinate] == cluster) )
            {
                if ((*Co).Zsc[coordinate]==1.0) (*Es).censor[study]=RIGHT_CENSORED;
                else if ((*Co).Zsc[coordinate]==-1.0) (*Es).censor[study]=LEFT_CENSORED;
                else
                {
                    (*Es).d[study]+=EffectSize((*Co).Zsc[coordinate], n1, n2, Use_t);
                    n++;
                }
            }
        }

        if (n) (*Es).d[study]/=n;

        if ((*Es).d[study]==0.0 && !(*Es).censor[study])
        {
            (*Es).censor[study] = INTERVAL_CENSORED;
            if ((*Co).VOI[study])  (*Es).censor[study] = VOI_CENSORED;
        }

        (*Es).SampleSD[study] = WithinStudyStandardDeviation(n1, n2, Use_t);

        if ((*Es).censor[study]==NOT_CENSORED) uncensored++;
    }


    ///LETS CHECK WHAT THE STRUCTURE LOOKS LIKE
    if (save)
    {

        FILE *fp;
        char fname[MAX_PATH];
        int Nl;
        char *labels;
        char *b;

        labels=LoadTalairachLabels(&Nl);

        if (!subanalysis) sprintf(fname,"%s\\cluster%d.txt",directory,cluster);
        else sprintf(fname,"%s\\cluster%d_subanalysis.txt",directory,cluster);
        if ((fp=fopen(fname,"w")))
        {
            for (study=0; study<(*Co).Nexperiments; study++)
            {
                if (fp) fprintf(fp,"study=%s\n",(*Co).ID[study].txt);
                if (fp) fprintf(fp,"d=%f  MinEffect=%g ",(*Es).d[study],(*Es).CensorLevel[study]);
                if (fp) fprintf(fp,"Covariate=%f  SD=%f\n",(*Es).cov[study]+MeanCovariate, (*Es).SampleSD[study]);
                for (coordinate=0; coordinate<(*Co).TotalFoci; coordinate++)
                {
                    if ((*Co).experiment[coordinate]==study)
                    {
                        if ((*Co).cluster[coordinate] == cluster)
                        {
                            if (fp) fprintf(fp,"x=%f,y=%f,z=%f,Zeffect=%f",(*Co).x[coordinate],(*Co).y[coordinate],(*Co).z[coordinate],(*Co).Zsc[coordinate]);
                            if (labels)
                            {

                                //b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                                b=FindEntryInTalairachLabels(labels, Nl, (*Co).TalLabel[coordinate]);
                                if (fp) fprintf(fp," %s\n",&b[1]);
                            }
                            else if (fp) fprintf(fp,"\n");
                        }
                    }
                }
                switch ((*Es).censor[study])
                {
                case NOT_CENSORED:
                    if (fp) fprintf(fp,"NOT_CENSORED\n");
                    break;
                case RIGHT_CENSORED:
                    if (fp) fprintf(fp,"RIGHT_CENSORED\n");
                    break;
                case LEFT_CENSORED:
                    if (fp) fprintf(fp,"LEFT_CENSORED\n");
                    break;
                case INTERVAL_CENSORED:
                    if (fp) fprintf(fp,"INTERVAL_CENSORED\n");
                    break;
                case VOI_CENSORED:
                    if (fp) fprintf(fp,"VOI_CENSORED\n");
                    break;
                };

                if (fp) fprintf(fp,"\n");

            }
            if (strlen(Warn) && (fp)) fprintf(fp,"WARNING! These studies report both left censored and right censored effects within this cluster: %s\n\n\n",Warn);
            if (fp) fclose(fp);
            if (labels) free(labels);
        }
        if (model==ID_REGRESSIONZ)
        {
            if (!subanalysis) sprintf(fname,"%s\\Regression%d.csv",directory,cluster);
            else sprintf(fname,"%s\\Regression_subanalysis%d.csv",directory,cluster);
            if ((fp=fopen(fname,"w")))
            {
                fprintf(fp,"Study,effect,regressor\n");
                for (study=0; study<(*Co).Nexperiments; study++)
                {
                    if ((*Es).censor[study]==NOT_CENSORED)
                    {
                        fprintf(fp,"%s,%f,%f\n",(*Co).ID[study].txt,(*Es).d[study], (*Es).cov[study]+MeanCovariate);
                    }
                }
                fclose(fp);
            }
        }



        if (!subanalysis) sprintf(fname,"%s\\Contributors to Cluster %d.csv",directory,cluster);
        else sprintf(fname,"%s\\Contributors to Cluster subanalysis %d.csv",directory,cluster);
        if ((fp=fopen(fname,"w")))
        {
            fprintf(fp,"Study,Contributor,Subjects,Controls,n*\n");
            for (study=0; study<(*Co).Nexperiments; study++)
            {
                n1=(*Co).SubjectsInExp[study];
                n2=(*Co).ControlsInExp[study];
                fprintf(fp,"%s,",(*Co).ID[study].txt);
                switch ((*Es).censor[study])
                {
                case RIGHT_CENSORED:
                case LEFT_CENSORED:
                case NOT_CENSORED:
                    fprintf(fp,"1,");
                    break;
                case INTERVAL_CENSORED:
                    fprintf(fp,"0,");
                    break;
                };
                fprintf(fp,"%d,%d,%f\n",n1,n2,EffectiveSubjectNumbers(n1,n2));
            }
            fclose(fp);
        }
    }

    return uncensored;
}
//======================================================================================================
//Compute the effect size given the Z score, and subject numbers
//The within study sd depends on whether its a single subject study
//or a comparison between two groups
//======================================================================================================
double EffectSize(double Z, int n1, int n2, int Use_t)
{

    double es;
    double t;
    int df;

    if (n1<=1) return 0.0;

    if (Use_t)
    {
        if ((n1>1) && (n2>1) )
        {
            df=n1+n2-2;
        }
        else
        {
            df=n1-1;
        }
        t=TstatisticFromZscore(Z, df);
        es=t/sqrt(EffectiveSubjectNumbers(n1,n2));
    }
    else es=Z/sqrt(EffectiveSubjectNumbers(n1,n2));

    return es;
}

//======================================================================================================
//compute the within study sd
//this is a combination of the variance of the Student's t distribution
//and the division of the Z score by sqrt(n*)
//n*=n1 for single subject studies; then n2=0
//n*=n1n2/(n1+n2) for comparison of two group studies
//======================================================================================================
double WithinStudyStandardDeviation(int n1, int n2, int Use_t)
{
    double sd;
    int df;

    if (n1<=1) return DBL_MAX;//infinite standard deviation if no subjects!

    if ((n1>1) && (n2>1) )
    {
        sd=sqrt(1.0/(n1*n2/(n1+n2)));
        df=n1+n2-2;
    }
    else
    {
        sd=sqrt(1.0/n1);
        df=n1-1;
    }

    if (Use_t) sd*=sqrt(df/(df-2));

    return sd;
}
//======================================================================================================
//EFFECTIVE SUBJECT NUMBERS
//IF THERE IS ONLY 1 GROUP (n2=0) then the subject numbers are n1
//IF n1>0 AND n2>0 THEN THE SUBJECT NUMBERS ARE n1*n2/(n1+n2)
//======================================================================================================
double EffectiveSubjectNumbers(int n1, int n2)
{
    if (n2>0) return (double)n1*n2/(n1+n2);
    else return (double)n1;
}
//======================================================================================================
//NEGATIVE LOG LIKELIHOOD SUITABLE FOR SIMPLEX OPTIMISATION
//double DownHillSimplex(double P[], int N, double scale[], int Scale,
//                       double (*GetError)(double *, int, void *), void *H, double tol)
//======================================================================================================
double NegativeLogLikelihoodOfCluster(double p[], int parameters, void *EffectSize)
{
    struct EffectSample *Es = (struct EffectSample *)EffectSize;
    double Ll;


    switch (parameters)
    {
    case 1:
        Ll = LogLikelihoodOfCluster(Es, 0.0, p[SD_PARAMETER], 0.0);//the mean is defaulted to zero
        break;
    case 2:
        Ll = LogLikelihoodOfCluster(Es, p[MEAN_PARAMETER], p[SD_PARAMETER], 0.0);
        break;
    case 3:
        Ll = LogLikelihoodOfCluster(Es, p[MEAN_PARAMETER], p[SD_PARAMETER], p[COVARIATE]);
        break;
    }

    /*FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s\\Ll.csv",REPORT_FOLDER);
    if ((fp=fopen(fname,"a")))
    {
        fprintf(fp,"%g\n",Ll);
        fclose(fp);
    }*/

    return -Ll;
}
//======================================================================================================
//LOG LIKELIHOOD OF EFFECT
//======================================================================================================
double LogLikelihoodOfEffect(double Effect, double mean, double SD, double CensorThreshold, short int censor)
{
    double sqrt2=1.41421356237;
    double sqrt2pi=2.506628275;
    double Ll;
    double SDsqrt2;
    double tmp;


    switch(censor)
    {
    case LEFT_CENSORED://these are deactivations or GM reductions, but no Z is given
        Ll = log(0.5 + 0.5*ErrorFunction((CensorThreshold - mean) / SD / sqrt2));
        break;

    case RIGHT_CENSORED://these are activations or GM increases, but no Z is given
        tmp = 1.0-(0.5 + 0.5*ErrorFunction((CensorThreshold - mean) / SD / sqrt2));
        if (tmp>=DBL_MIN) Ll = log(tmp);
        else Ll = log(DBL_MIN);
        break;

    case INTERVAL_CENSORED://no significant result is reported by this study, so the Z value is somewhere between the censor thresholds
        SDsqrt2=SD*sqrt2;
        tmp = 0.5*(ErrorFunction( (CensorThreshold - mean)/SDsqrt2) - ErrorFunction( (-CensorThreshold - mean) / SDsqrt2));
        if (tmp>=DBL_MIN) Ll=log(tmp);
        else Ll = log(DBL_MIN);
        break;

    case NOT_CENSORED:
        Ll =  -(log( sqrt2pi * SD ) + (Effect - mean)*(Effect - mean) / (SD*SD) /2);
        break;

    default:
        MessageBox(NULL,"There is a mistake here somewhere","LogLikelihoodOfCluster",MB_OK);
        return 0.0;
        break;
    }
    return Ll;
}
//======================================================================================================
//LOG LIKELIHOOD
//INCLUDES CENSORING
//THIS FUNCTION GOES TO -INF WHEN THE TERMS ON THE LOG GO TO ZERO. THIS NEEDS TO BE TRAPPED IN THE CALLING
//FUNCTION

//=======================================================================================
//THE REGRESSION MODEL IS SUCH THAT THE EFFECT E+alpha*COVARIATE IS NORMALLY DISTRIBUTED.
//THEREFORE THE MODEL IS E~N(mu-alphaCOVARIATE, VAR)
//=======================================================================================

//======================================================================================================
double LogLikelihoodOfCluster(struct EffectSample *Es, double mean, double RandomSD, double cov)
{
    double Ll=0.0;
    int sample;
    double sd;
    double R2;

    if (RandomSD<=DBL_MIN) return log(DBL_MIN);

    //if (RandomSD<=0.001) RandomSD=0.001;
    R2=RandomSD*RandomSD;


    for (sample=0; sample<(*Es).Samples; sample++)
    {
        sd=sqrt( (*Es).SampleSD[sample]*(*Es).SampleSD[sample] + R2 );

        //LogLikelihoodOfEffect(double Effect, double mean, double SD, double CensorThreshold, int censor);
        Ll += LogLikelihoodOfEffect((*Es).d[sample],  mean+cov*(*Es).cov[sample], sd, (*Es).CensorLevel[sample], (*Es).censor[sample]);
    }
    return Ll;
}
//======================================================================================================
//TEST LIKELIHOOD
//======================================================================================================
int TestLogLikelihoodOfCluster(int Studies, int subjects, double Zthreshold, int Niterations, int model)
{
    struct EffectSample Es;
    int iteration;
    int study;
    int CensoredCount=0;
    double a;
    double m, mean, sigma, coeficient;
    char fname[MAX_PATH];
    FILE *fp;


    memset(&Es,0,sizeof(struct EffectSample));

    //to equalise the variance for the mean and regression estimates, need to make the covariate equally spread, at Studies points, between -a and a
    //for example, for 20 Studies, a=1.64 will equalise the variance of the mean and regression parameter estimates

    if (model==ID_REGRESSIONZ) a=sqrt(1.0/(1.0/3.0 + 2.0/3.0/(Studies-1)));
    else a=0.0;

    sprintf(fname,"%s\\Ll_%d_%d_%f.csv",REPORT_FOLDER, Studies,subjects,Zthreshold);
    fp=fopen(fname,"w");


    MakeEffectSampleStructure(&Es, Studies, ID_MEANZ);



    for (iteration=0; iteration<Niterations; iteration++)
    {

        //the random effects parameters
        mean=2.0*rand()/RAND_MAX-1.0;

        do
        {
            sigma = (double)rand()/RAND_MAX;
        }
        while ( (sigma<0.1) );

        coeficient=2.0*rand()/RAND_MAX-1.0;

        CensoredCount=0;
        for (study=0; study<Studies; study++)
        {
            Es.SampleSD[study] = sqrt(1.0/subjects);
            Es.CensorLevel[study] = fabs(Zthreshold)/sqrt((double)subjects);
            Es.censor[study] = NOT_CENSORED;
            Es.cov[study]=-a + 2.0*a*(study)/(Studies-1);


            m = GaussRandomNumber_BoxMuller(mean, sigma);
            Es.d[study] = GaussRandomNumber_BoxMuller(m + coeficient*Es.cov[study], Es.SampleSD[study]);
            if (fabs(Es.d[study])<(Zthreshold)/sqrt((double)subjects))
            {
                Es.d[study] = 0.0;
                Es.censor[study] = INTERVAL_CENSORED;
                CensoredCount++;
            }
        }

        if (model==ID_MEANZ) MLE_mean_sd(&Es, &Es.mean, &Es.sigma);
        else MLE_mean_sd_cov(&Es, &Es.mean, &Es.sigma, &Es.covariate);

        if (fp) fprintf(fp,"%d,%f,%f,%f,%f,%g,%f\n",CensoredCount,Es.mean, mean,
                            Es.sigma, sigma,
                            Es.covariate, coeficient);

    }

    if (fp) fclose(fp);
    FreeEffectSampleStructure(&Es);

    return 1;
}

//======================================================================================================
//CREATE AN EMPTY EffectSample STRUCTURE GIVEN THE NUMBER OF STUDIES
//======================================================================================================
int MakeEffectSampleStructure(struct EffectSample *Es, int Studies, int model)
{
    int result=0;

    (*Es).Samples = Studies;
    if ( !( (*Es).d = (double *)calloc(Studies,sizeof(double))) ) goto END;
    if ( !( (*Es).cov = (double *)calloc(Studies,sizeof(double))) ) goto END;
    if ( !( (*Es).CensorLevel = (double *)calloc(Studies,sizeof(double))) ) goto END;
    if ( !( (*Es).SampleSD = (double *)calloc(Studies,sizeof(double))) ) goto END;
    if ( !( (*Es).censor = (short int *)calloc(Studies,sizeof(short int))) ) goto END;
    (*Es).Model = model;

    result=1;
END:
    if (!result) FreeEffectSampleStructure(Es);
    return result;
}

//======================================================================================================
int FreeEffectSampleStructure(struct EffectSample *Es)
{

        if ((*Es).cov) free((*Es).cov);
        if ((*Es).d) free((*Es).d);
        if ((*Es).CensorLevel) free((*Es).CensorLevel);
        if ((*Es).SampleSD) free((*Es).SampleSD);
        if ((*Es).censor) free((*Es).censor);

        memset(Es,0,sizeof(struct EffectSample));//NULL the structure
    return 1;
}




//======================================================================================================
//Estimate the minimum overlap under the null
//It turns out that requiring a clustering distance where under the null the coordinates just
//begin to cluster is similar to requiring few (~5%) coordinates overlap with at least MIN_OVERLAP
//MIN_OVERLAP is three according to DBSCAN (for 3D clustering)
//======================================================================================================
double ProportionClusteringUnderNull(float mask[],
                                     int X, int Y, int Z,
                                     float dx, float dy, float dz,
                                     float x0, float y0, float z0,
                                     struct Coordinates *Co,
                                     double ClusteringDistance,
                                     int MinOverlapping,
                                     double error,
                                     int MergeGroups)
{

    double proportion=0.0;
    double sd;
    int sum;
    int norm=0;
    int coordinate1,coordinate2;
    int iteration;
    int Ncoordinates=(*Co).TotalFoci;
    int NcoordinatesCoordinate1;
    int overlaps;
    struct Coordinates rCo;
    struct Clusters cl;
    float min2dist=ClusteringDistance*ClusteringDistance;
    double *D2M=NULL;
    char *StudyOverlap=NULL;
    int *Hoverlap=NULL;//a histogram of the frequency of overlap

    memset(&cl,0,sizeof(struct Clusters));
    memset(&rCo,0,sizeof(struct Coordinates));

    CopyCoordinates(Co,&rCo);

    if (MergeGroups) MergeCoordinatesbyStudy(&rCo);

    if (!(StudyOverlap=(char *)malloc(rCo.Nexperiments))) goto END;
    if (!(D2M=(double *)malloc(Ncoordinates*Ncoordinates*sizeof(double)))) goto END;
    if (!(Hoverlap=(int *)calloc(rCo.Nexperiments,sizeof(int)))) goto END;

    FillClusterStructure(&rCo, &cl,  SDfromClusteringDistance(ClusteringDistance));


    iteration=0;
    do
    {
        RandomiseFociRandomEffects(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &rCo, &cl, SDfromClusteringDistance(ClusteringDistance));
        Distance2Matrix(rCo.x, rCo.y, rCo.z, rCo.experiment, rCo.TotalFoci, D2M);

        NcoordinatesCoordinate1=0;
        for (coordinate1=0; coordinate1<Ncoordinates; coordinate1++)
        {
            memset(StudyOverlap,0,rCo.Nexperiments);
            sum=0;
            for (coordinate2=0; coordinate2<Ncoordinates; coordinate2++)
            {
                if ( (rCo.experiment[coordinate1] != rCo.experiment[coordinate2]) && (!StudyOverlap[rCo.experiment[coordinate2]]) )
                {
                    if (D2M[coordinate2 + NcoordinatesCoordinate1]<=min2dist)
                    {
                        StudyOverlap[rCo.experiment[coordinate2]]=1;
                        sum++;
                    }
                }
            }
            Hoverlap[sum]++;
            norm++;
            NcoordinatesCoordinate1+=Ncoordinates;
        }

        sum=0;
        for (overlaps=MIN_OVERLAP; overlaps<rCo.Nexperiments; overlaps++) sum += Hoverlap[overlaps];
        if (norm)
        {
            proportion=(double)sum/norm;
            sd=sqrt(proportion*(1.0-proportion)/norm);
        }

        iteration++;
    }
    while ( iteration<500 || norm<1000 ||  sd>error );

END:
    if (StudyOverlap) free(StudyOverlap);
    if (D2M) free(D2M);
    if (Hoverlap) free(Hoverlap);
    FreeCluster(&cl);
    FreeCoordinates(&rCo);

    return proportion;
}

//======================================================================================================
//COMPUTE THE ClusteringDistance THAT, UNDER THE NULL HYPOTHESIS, WOULD JUST START CLUSTERS FORMING
//changed on 6/6/2018 to increase accuracy
//====================================a==================================================================
#define REGRESSION_POINTS_FOR_ESTIMATE 20
#define REGRESSION_RANGE 0.5
double EstimateClusteringDistanceUsingNull(HWND hwnd, struct Coordinates *Co, float mask[], int X, int Y, int Z, float dx, float dy,
        float dz, float x0, float y0, float z0, float proportion, int MergeStudies)
{

    double error=0.001;
    double a,b,c;
    float MinVol, MaxVol, CD,f;
    struct Coordinates Cocpy;
    double result=0.0;
    double x[REGRESSION_POINTS_FOR_ESTIMATE+1];
    double y[REGRESSION_POINTS_FOR_ESTIMATE+1];
    double pa,pb;
    int i;
    char txt[256];

    memset(&Cocpy,0,sizeof(struct Coordinates));
    if (!(CopyCoordinates(Co,&Cocpy))) return 0.0;

    if (MergeStudies)
    {
        MergeCoordinatesbyStudy(&Cocpy);
    }


    MinVol=1.0;
    MaxVol=40.0*40.0*40.0;

    a=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, pow(MinVol,1.0/3), MIN_OVERLAP,error,0);
    b=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, pow(MaxVol,1.0/3), MIN_OVERLAP,error,0);


    while((a<proportion) && (b>proportion) && ((MaxVol-MinVol)>0.05))
    {

        if (b>a) f=(proportion-a)/(b-a);
        else f=0.5;

        CD=pow(MinVol + f*(MaxVol - MinVol),1.0/3);

        c=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, CD, MIN_OVERLAP,error,0);
        sprintf(txt,"%.2f",CD);
        SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
        UpdateWindow(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT));

        if (c>proportion)
        {
            MaxVol=CD*CD*CD;
            b=c;
        }
        else
        {
            MinVol=CD*CD*CD;
            a=c;
        }
    }

    ///use simple linear regression around this solution to find CD at proportion

    error/=2;//make the error smaller

    x[0]=CD;
    y[0]=c;

    a=CD-REGRESSION_RANGE;
    for (i=1; i<=REGRESSION_POINTS_FOR_ESTIMATE; i++)
    {
        c=a+2.0*REGRESSION_RANGE*(i-1)/(REGRESSION_POINTS_FOR_ESTIMATE-1);
        x[i]=c;
        y[i]=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, c, MIN_OVERLAP,error,0);
        sprintf(txt,"%.2f",c);
        SendMessage(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
        UpdateWindow(GetDlgItem(hwnd,ID_CLUSTER_DISTANCE_TXT));
    }

    SimpleLinearRegression(y, x, REGRESSION_POINTS_FOR_ESTIMATE+1, &a, &b, &pa, &pb);

    if (b)
    {
        CD=(proportion-a)/b;//solve proportion=a + b*CD
    }
    else///if simple linear regression didnt work, try this
    {
        //use the gradient of the proportion around CD to estimate where CD should be to give required proportion
        a=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, CD, MIN_OVERLAP,error/5,0);
        b=ProportionClusteringUnderNull(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &Cocpy, CD+0.1, MIN_OVERLAP,error/5,0);//increase CD by 0.1
        if (a>b)
        {
            c=a;
            a=b;
            b=c;
        }
        if (b>a) f=(proportion-a)/(b-a);
        else f=0.0;
        CD=CD + f*0.1;//0.1 is the difference in CD between a & b
    }

    result=CD;

    FreeCoordinates(&Cocpy);

    return result;
}


//======================================================================================================
//Compute the FWHM from the clustering distance
//======================================================================================================
double FWHMfromClusteringDistance(double CD)
{
    return CD*sqrt(8.0*log(2.0))/NSIGMA95;
}

//======================================================================================================
//Compute the SD from the ClusteringDistance
//======================================================================================================
double SDfromClusteringDistance(double CD)
{
    return CD/NSIGMA95;
}







//======================================================================================================
//TEST FUNCTIONS FOR PAPER
//CREATE A COORDINATE FILE WITH Z SCORES
//The Z scores should be Normally distributed with N(mean,sd*sd)
//The Coordinate structure will have Nexperiments=studies and Subjects=subjects
//The censoring is at value censor
//======================================================================================================
int PaperALE_CBRES(struct Image *mask, struct Coordinates *CoordinateStruct, double mean, double sigma, int Studies, int Subjects, int Coordinates, double censor)
{
    int result=0;
    float x[2]= {-11.0, 11.0};
    float y[2]= {-20.0, -20.0};
    float z[2]= {4.0, 4.0};
    double dx, dy, dz;
    int RandomVoxel;
    int study;
    int i;
    int xi,yi,zi;
    int Ncoordinates, coordinate;
    double *Z=NULL;
    double r;


//first compute the Z scores
    if (!(Z=(double *)calloc(Coordinates*Studies, sizeof(double)))) goto END;


    Ncoordinates=0;
    for (coordinate=0; coordinate<Coordinates*Studies; coordinate++)
    {
        r = GaussRandomNumber_BoxMuller(mean, sigma);
        Z[coordinate] = sqrt((double)Subjects)*GaussRandomNumber_BoxMuller(r, 1.0/sqrt((double)Subjects));
        if (fabs(Z[coordinate])>censor) Ncoordinates++;//COUNT THE NUMBER OF Z SCORES ABOVE THE CENSORING THRESHOLD
    }
    if (!Ncoordinates) goto END;



//create the coordinate structure
    if (!MakeStructCoordinates(CoordinateStruct, Ncoordinates, Studies)) goto END;
    (*CoordinateStruct).ZscoreUsed=1;


    i=0;
    for (study=0; study<Studies; study++)
    {
        (*CoordinateStruct).Zcensor[study] = censor;
        (*CoordinateStruct).SubjectsInExp[study]=Subjects;
        sprintf((*CoordinateStruct).ID[study].txt,"Study%d",study);
        for (coordinate=0; coordinate<Coordinates; coordinate++)
        {
            if (fabs(Z[study*Coordinates + coordinate])>censor)
            {
                if (coordinate<2)
                {
                    dx = GaussRandomNumber_BoxMuller(0.0,3.0);
                    dy = GaussRandomNumber_BoxMuller(0.0,3.0);
                    dz = GaussRandomNumber_BoxMuller(0.0,3.0);
                    (*CoordinateStruct).x[i]=x[coordinate] + dx;
                    (*CoordinateStruct).y[i]=y[coordinate] + dy;
                    (*CoordinateStruct).z[i]=z[coordinate] + dz;
                }
                else
                {
                    RandomVoxel = RandomVoxelALE((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
                    XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
                    (*CoordinateStruct).x[i] = (*mask).dx*xi - (*mask).x0;
                    (*CoordinateStruct).y[i] = (*mask).dy*yi - (*mask).y0;
                    (*CoordinateStruct).z[i] = (*mask).dz*zi - (*mask).z0;
                }
                (*CoordinateStruct).experiment[i]=study;
                (*CoordinateStruct).Zsc[i] = Z[study*Coordinates + coordinate];
                (*CoordinateStruct).subjects[i] = Subjects;

                i++;
            }
        }
    }


    result=1;
END:

    if (Z) free(Z);
    return result;
}
//======================================================================================================
int TestPaperALE_CBRES(struct Image *mask, double mean, double sigma, int Studies, int Subjects, int Coordinates, double censor)
{
    struct Coordinates CoordinateStruct;
    int i;
    char fname[MAX_PATH];

    memset(&CoordinateStruct,0,sizeof(struct Coordinates));

    sprintf(fname,"%s/CBRES",REPORT_FOLDER);
    CreateDirectory(fname,NULL);

    for (i=0; i<10; i++)
    {

        if (PaperALE_CBRES(mask, &CoordinateStruct, mean, sigma, Studies, Subjects, Coordinates, censor))
        {
            sprintf(fname,"%s/coordinates%d.txt",REPORT_FOLDER,i);
            SaveExperimentsALE(&CoordinateStruct, fname, "GM", 0.0, 0);
            FreeCoordinates(&CoordinateStruct);
        }
        else return 0;
    }

    return 1;
}

//======================================================================================================
//NULL coordinates and effect generator
//effects are between MinZ<=|Z|<=MaxZ
//SDcoord is the standard of the coordinates from the cluster peak
//======================================================================================================
int Paper_Simulation_Coordinates(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, double Zcensor, int SystematicCoordinates, double SDcoord, struct ThreeVector V[])
{
    double MaxZ=6.0;
    double MinZ=Zcensor;
    double sd=SDcoord/pow(3.0,1.0/3);//the standard deviation of the cluster size
    int study, coordinate;
    int TotalCoordinates;
    int RandomVoxel;
    int xi,yi,zi;
    int i;
    double dist, MinDist;
    double Z, effect;
    double dx,dy,dz;


    //find the effect size. This is the mean of a normal with sd=1, such that CoordinateProportion of the distribution is > Zcensor
    effect=Zcensor - Zvalue(1.0-CoordinateProportion);

    if ((effect>7.0) || (effect<-7.0))
    {
        MessageBox(NULL,"Error in effect size; Paper_Simulation_Coordinates","",MB_OK);
    }

    memset(Co,0,sizeof(struct Coordinates));
    if (!MakeStructCoordinates(Co, (MaxCoordinates+SystematicCoordinates)*Studies, Studies)) return 0;
    (*Co).ZscoreUsed=1;
    TotalCoordinates=0;
    for (study=0; study<Studies; study++)
    {
        sprintf((*Co).ID[study].txt,"Study%d",study);
        (*Co).SubjectsInExp[study] = Subjects;
        (*Co).Zcensor[study] = MinZ;
        //insert the random coordinates
        for (coordinate=0; coordinate<MaxCoordinates; coordinate++)
        {

            do
            {
                Z=GaussRandomNumber_BoxMuller(effect, 1.0);//|Z| will be >MinZ and <=MaxZ
            }
            while ((fabs(Z)>MaxZ));

            if (fabs(Z)>MinZ)
            {

                do
                {
                    RandomVoxel = RandomVoxelALE((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
                    XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
                    MinDist=10000000.0;
                    for (i=0; i<SystematicCoordinates; i++)
                    {
                        dist= ((*mask).dx*xi - (*mask).x0 - V[i].x)*((*mask).dx*xi - (*mask).x0 - V[i].x)+
                              ((*mask).dy*yi - (*mask).y0 - V[i].y)*((*mask).dy*yi - (*mask).y0 - V[i].y)+
                              ((*mask).dz*zi - (*mask).z0 - V[i].z)*((*mask).dz*zi - (*mask).z0 - V[i].z);
                        if (dist<MinDist) MinDist=dist;
                    }
                }
                while (MinDist<NSIGMA95*NSIGMA95*sd*sd);

                (*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
                (*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
                (*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
                (*Co).subjects[TotalCoordinates] = Subjects;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
        //insert the systematic coordinates
        for (coordinate=0; coordinate<SystematicCoordinates; coordinate++)
        {
            Z=GaussRandomNumber_BoxMuller(effect, 1.0);
            if (Z>MinZ)//not censored
            {
                do
                {
                    dx=GaussRandomNumber_BoxMuller(0.0,sd);
                    dy=GaussRandomNumber_BoxMuller(0.0,sd);
                    dz=GaussRandomNumber_BoxMuller(0.0,sd);
                }
                while (sqrt(dx*dx + dy*dy + dz*dz)>NSIGMA95*sd);

                (*Co).x[TotalCoordinates] = V[coordinate].x + dx;
                (*Co).y[TotalCoordinates] = V[coordinate].y + dy;
                (*Co).z[TotalCoordinates] = V[coordinate].z + dz;
                (*Co).subjects[TotalCoordinates] = Subjects;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
    }
    if (TotalCoordinates>0) (*Co).TotalFoci=TotalCoordinates;


    return TotalCoordinates;

}
//======================================================================================================
//NULL coordinates and effect generator FOR TWO GROUPS
//effects are between MinZ<=|Z|<=MaxZ
//SDcoord is the standard of the coordinates from the cluster peak
//two groups with covariate = 1 for group 1 and 0 for group 2
//======================================================================================================
int Paper_Group_Effect_Size_Experiment(struct Coordinates *Co, struct Image *mask, int Group1, int Group2, int MaxCoordinates, double CoordinateProportion,
                                       double effect_difference, int Subjects, double Zcensor, double SDcoord, struct ThreeVector V[], int Nclusters)
{
    double MaxZ=6.0;
    double MinZ=Zcensor;
    double sd=SDcoord/pow(3.0,1.0/3);//the standard deviation of the cluster size
    int study, coordinate;
    int TotalCoordinates;
    int RandomVoxel;
    int xi,yi,zi;
    int Studies=Group1+Group2;
    int i;
    double dist, MinDist;
    double Z, effect1, effect2;
    double dx,dy,dz;


    //find the effect size. This is the mean of a normal with sd=1, such that CoordinateProportion of the distribution is > Zcensor
    effect1=Zcensor - Zvalue(1.0-CoordinateProportion);
    effect2=effect1 + effect_difference;

    if ((effect1>7.0) || (effect1<-7.0))
    {
        MessageBox(NULL,"Error in effect size; Paper_Simulation_Coordinates","",MB_OK);
    }

    memset(Co,0,sizeof(struct Coordinates));
    if (!MakeStructCoordinates(Co, (MaxCoordinates+2)*Studies, Studies)) return 0;
    (*Co).ZscoreUsed=1;
    TotalCoordinates=0;
    for (study=0; study<Studies; study++)
    {
        sprintf((*Co).ID[study].txt,"Study%d",study);
        (*Co).SubjectsInExp[study] = Subjects;
        (*Co).Zcensor[study] = MinZ;
        (*Co).covariate[study]=(study<Group1) ? 1.0:0.0;
        (*Co).subanalysis[study]=(study<Group1) ? 1:0;

        //insert the random coordinates
        for (coordinate=0; coordinate<MaxCoordinates; coordinate++)
        {
            do
            {
                Z=GaussRandomNumber_BoxMuller(effect1, 1.0);//|Z| will be >MinZ and <=MaxZ
            }
            while ((fabs(Z)>MaxZ));

            if (fabs(Z)>MinZ)
            {

                do
                {
                    RandomVoxel = RandomVoxelALE((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
                    XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
                    MinDist=10000000.0;
                    for (i=0; i<2; i++)
                    {
                        dist= ((*mask).dx*xi - (*mask).x0 - V[i].x)*((*mask).dx*xi - (*mask).x0 - V[i].x)+
                              ((*mask).dy*yi - (*mask).y0 - V[i].y)*((*mask).dy*yi - (*mask).y0 - V[i].y)+
                              ((*mask).dz*zi - (*mask).z0 - V[i].z)*((*mask).dz*zi - (*mask).z0 - V[i].z);
                        if (dist<MinDist) MinDist=dist;
                    }
                }
                while (sqrt(MinDist)<NSIGMA95*sd);

                (*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
                (*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
                (*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
                (*Co).subjects[TotalCoordinates] = Subjects;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
        //insert the systematic coordinates
        for (coordinate=0; coordinate<Nclusters; coordinate++)
        {
            if (study<Group1) Z=GaussRandomNumber_BoxMuller(effect1, 1.0);
            else Z=GaussRandomNumber_BoxMuller(effect2, 1.0);
            if (Z>MinZ)//not censored
            {
                do
                {
                    dx=GaussRandomNumber_BoxMuller(0.0,sd);
                    dy=GaussRandomNumber_BoxMuller(0.0,sd);
                    dz=GaussRandomNumber_BoxMuller(0.0,sd);
                }
                while (sqrt(dx*dx + dy*dy + dz*dz)>NSIGMA95*sd);

                (*Co).x[TotalCoordinates] = V[coordinate].x + dx;
                (*Co).y[TotalCoordinates] = V[coordinate].y + dy;
                (*Co).z[TotalCoordinates] = V[coordinate].z + dz;
                (*Co).subjects[TotalCoordinates] = Subjects;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
    }
    if (TotalCoordinates>0) (*Co).TotalFoci=TotalCoordinates;



    return TotalCoordinates;
}
//======================================================================================================
//Test the Paper_Simulation_Coordinates function
//Save the results, including the SDM files to disk
//======================================================================================================
int Test_Group_Simulation_Coordinates(struct Image *image,int Studies1, int Studies2,
                                      int MaxCoordinates, double CoordinateProportion,
                                      int Subjects, int SystematicClusters, double Zcensor, int experiments)
{
    struct Coordinates Co;
    char fname[MAX_PATH];
    //char directory[MAX_PATH];
    double del=4.5;//according to the ALE paper they are spread with sd~4 or 5mm
    int i;
    struct ThreeVector V[5];

    //systematic coordinates all on the same slice
    V[0].x=-12.0;
    V[0].y=-22.0;
    V[0].z=10.0;//left thalamus
    V[1].x=12.0;
    V[1].y=-22.0;
    V[1].z=10.0;//right thalamus
    V[2].x=-40.0;
    V[2].y=-6.0;
    V[2].z=10.0;
    V[3].x=40.0;
    V[3].y=-6.0;
    V[3].z=10.0;
    V[4].x=0.0;
    V[4].y=48.0;
    V[4].z=10.0;


    memset(&Co,0,sizeof(struct Coordinates));

    for (i=0; i<1; i++)
    {

        //(struct Coordinates *Co, struct Image *mask, int Group1, int Group2, int MaxCoordinates, double CoordinateProportion,
        //double effect_difference, int Subjects, double Zcensor, double SDcoord, struct ThreeVector V[], int Nclusters)
        Paper_Group_Effect_Size_Experiment(&Co, image, Studies1, Studies2, MaxCoordinates, CoordinateProportion, 1.0, Subjects, Zcensor, del, V, 5);

        sprintf(fname,"%s\\GroupMA studies1_%d studies2_%d SystematicClusters_%d realisation_%d.txt",REPORT_FOLDER,Studies1,Studies2,SystematicClusters,i);
        SaveExperimentsALE(&Co, fname, (*image).filename, 1.0, 0);



        //sprintf(fname,"%s/NullCBRES",REPORT_FOLDER);
        //sprintf(directory,"SDM%d",i);
        //SaveSDMfiles(&Co, (*image).x0, (*image).y0, (*image).z0, fname, directory);

        //sprintf(fname,"%s/NullCBRES/GAcoordinates%d.txt",REPORT_FOLDER,i);
        //Co.ZscoreUsed=0;
        //SaveExperimentsALE(&Co, fname, (*image).filename, 1.0, 0);

        FreeCoordinates(&Co);
    }


    return 1;
}
//======================================================================================================
//NULL coordinates and effect generator
//effects are between MinZ<=|Z|<=MaxZ
//SDcoord is the standard of the coordinates from the cluster peak
//USED IN PAPER figure 3
//======================================================================================================
int Paper_Effect_Size_Experiment(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, double Zcensor, double SDcoord, struct ThreeVector V[], int Nclusters)
{
    double MaxZ=6.0;
    double MinZ=Zcensor;
    double sd=SDcoord/pow(3.0,1.0/3);//the standard deviation of the cluster size
    int study, coordinate;
    int TotalCoordinates;
    int RandomVoxel;
    int xi,yi,zi;
    int i;
    double sign;
    double dist, MinDist;
    double Z, effect;
    double dx,dy,dz;


    //find the effect size. This is the mean of a normal with sd=1, such that CoordinateProportion of the distribution is > Zcensor
    effect=Zcensor - Zvalue(1.0-CoordinateProportion);

    if ((effect>7.0) || (effect<-7.0))
    {
        MessageBox(NULL,"Error in effect size; Paper_Simulation_Coordinates","",MB_OK);
    }

    memset(Co,0,sizeof(struct Coordinates));
    if (!MakeStructCoordinates(Co, (MaxCoordinates+2)*Studies, Studies)) return 0;
    (*Co).ZscoreUsed=1;
    TotalCoordinates=0;
    for (study=0; study<Studies; study++)
    {
        sprintf((*Co).ID[study].txt,"Study%d",study);
        (*Co).SubjectsInExp[study] = Subjects;
        (*Co).Zcensor[study] = MinZ;
        //insert the random coordinates
        for (coordinate=0; coordinate<MaxCoordinates; coordinate++)
        {

            do
            {
                Z=GaussRandomNumber_BoxMuller(effect, 1.0);//|Z| will be >MinZ and <=MaxZ
            }
            while ((fabs(Z)>MaxZ));

            if (fabs(Z)>MinZ)
            {

                do
                {
                    RandomVoxel = RandomVoxelALE((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
                    XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
                    MinDist=10000000.0;
                    for (i=0; i<2; i++)
                    {
                        dist= ((*mask).dx*xi - (*mask).x0 - V[i].x)*((*mask).dx*xi - (*mask).x0 - V[i].x)+
                              ((*mask).dy*yi - (*mask).y0 - V[i].y)*((*mask).dy*yi - (*mask).y0 - V[i].y)+
                              ((*mask).dz*zi - (*mask).z0 - V[i].z)*((*mask).dz*zi - (*mask).z0 - V[i].z);
                        if (dist<MinDist) MinDist=dist;
                    }
                }
                while (sqrt(MinDist)<NSIGMA95*sd);

                (*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
                (*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
                (*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
                (*Co).subjects[TotalCoordinates] = Subjects;
                sign=1.0;
                if ((double)rand()/RAND_MAX>0.5) sign=-1.0;
                (*Co).Zsc[TotalCoordinates] = sign*Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
        //insert the systematic coordinates
        for (coordinate=0; coordinate<Nclusters; coordinate++)
        {
            Z=GaussRandomNumber_BoxMuller(effect, 1.0);
            if (Z>MinZ)//not censored
            {
                do
                {
                    dx=GaussRandomNumber_BoxMuller(0.0,sd);
                    dy=GaussRandomNumber_BoxMuller(0.0,sd);
                    dz=GaussRandomNumber_BoxMuller(0.0,sd);
                }
                while (sqrt(dx*dx + dy*dy + dz*dz)>NSIGMA95*sd);

                (*Co).x[TotalCoordinates] = V[coordinate].x + dx;
                (*Co).y[TotalCoordinates] = V[coordinate].y + dy;
                (*Co).z[TotalCoordinates] = V[coordinate].z + dz;
                (*Co).subjects[TotalCoordinates] = Subjects;
                if (coordinate==1) Z*=-1.0;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
    }
    if (TotalCoordinates>0) (*Co).TotalFoci=TotalCoordinates;



    return TotalCoordinates;
}
//======================================================================================================
//Test the Paper_Simulation_Coordinates function
//Save the results, including the SDM files to disk
//======================================================================================================
int Test_Paper_Effect_Size_Experiment(struct Image *image,int Studies, int MaxCoordinates, double CoordinateProportion, int Subjects, double Zcensor)
{
    struct Coordinates Co;
    char fname[MAX_PATH];
    double del=4.5;//according to the ALE paper they are spread with sd~4 or 5mm. This means the cluster has a radius of NSIGMA*4.5/(3^{1/3})=8.75mm
    int i;
    struct ThreeVector V[2];

    //opposite sides of brain case
    //V[0].x = -42.0;
    //V[1].x = 42.0;
    //V[0].y = V[1].y = -14.0;
    //V[0].z = V[1].z = 10.0;

    //same side of brain, not too close
    //V[0].x = 42.0;
    //V[1].x = 42.0;
    //V[0].y = -14.0;
    //V[1].y = 10.0;
    //V[0].z = V[1].z = 10.0;

    //same side of brain, very close
    V[0].x = 42.0;
    V[1].x = 42.0;
    V[0].y = -14.0;
    V[1].y = 5.0;
    V[0].z = V[1].z = 10.0;


    //char txt[256];
    //sprintf(txt,"%f",ClusteringDisntance);
    //MessageBox(NULL,txt,"",MB_OK);

    memset(&Co,0,sizeof(struct Coordinates));

    for (i=0; i<10; i++)
    {

        Paper_Effect_Size_Experiment(&Co, image, Studies, MaxCoordinates, CoordinateProportion, Subjects, Zcensor, del, V, 2);

        sprintf(fname,"%s/NullCBRES\\CBRES_ES_studies_%d realisation_%d.txt",REPORT_FOLDER,Studies,i);
        SaveExperimentsALE(&Co, fname, (*image).filename, 1.0, 0);

        FreeCoordinates(&Co);
    }

    return 1;
}




//======================================================================================================
//Test the Paper_Simulation_Coordinates function
//Save the results, including the SDM files to disk
//======================================================================================================
int Test_Paper_Simulation_Coordinates(struct Image *image,int Studies, int MaxCoordinates, double CoordinateProportion, int Subjects, int SystematicClusters, double Zcensor)
{
    struct Coordinates Co;
    char fname[MAX_PATH];
    char directory[MAX_PATH];
    double del=4.5;//according to the ALE paper they are spread with sd~4 or 5mm
    int i;
    struct ThreeVector V[5];

    //systematic coordinates all on the same slice
    V[0].x=-12.0;
    V[0].y=-22.0;
    V[0].z=10.0;//left thalamus
    V[1].x=12.0;
    V[1].y=-22.0;
    V[1].z=10.0;//right thalamus
    V[2].x=-40.0;
    V[2].y=-6.0;
    V[2].z=10.0;
    V[3].x=40.0;
    V[3].y=-6.0;
    V[3].z=10.0;
    V[4].x=0.0;
    V[4].y=48.0;
    V[4].z=10.0;


    memset(&Co,0,sizeof(struct Coordinates));

    for (i=0; i<1; i++)
    {
        //int Paper_Simulation_Coordinates(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
        //                       int Subjects, double Zcensor, int SystematicCoordinates, double SDcoord)
        Paper_Simulation_Coordinates(&Co, image, Studies, MaxCoordinates, CoordinateProportion, Subjects, Zcensor, SystematicClusters, del, V);


        sprintf(fname,"%s/NullCBRES\\NullCBRES studies_%d SystematicClusters_%d realisation_%d.txt",REPORT_FOLDER,Studies,SystematicClusters,i);
        SaveExperimentsALE(&Co, fname, (*image).filename, 1.0, 0);



        sprintf(fname,"%s/NullCBRES",REPORT_FOLDER);
        sprintf(directory,"SDM%d",i);
        SaveSDMfiles(&Co, (*image).x0, (*image).y0, (*image).z0, fname, directory);

        sprintf(fname,"%s/NullCBRES/GAcoordinates%d.txt",REPORT_FOLDER,i);
        Co.ZscoreUsed=0;
        SaveExperimentsALE(&Co, fname, (*image).filename, 1.0, 0);
        Co.ZscoreUsed=1;

        FreeCoordinates(&Co);
    }

    return 1;
}
//======================================================================================================
//TEST NULL REJECTION
//======================================================================================================
int TestNullRejectionOfClusterz(HWND hwnd, struct Image *image,double critical, int Studies, int MaxCoordinates, double CoordinateProportion,
                                int Subjects, int iterations, double Zthreshold, int Use_t, int SystematicClusters, double NotClustered)
{
    struct Coordinates Co;
    double ClusteringDistance;
    char fname[MAX_PATH];
    int iter;
    int SigClusters,TotalNullClusters;
    double pvalue;
    double error,sum,sum2,variance;
    FILE *fp=NULL;
    double del=4.5;//according to the ALE paper they are spread with sd~4 or 5mm
    struct ThreeVector V[5];

    //systematic coordinates all on the same slice
    V[0].x=-12.0;
    V[0].y=-22.0;
    V[0].z=10.0;//left thalamus
    V[1].x=12.0;
    V[1].y=-22.0;
    V[1].z=10.0;//right thalamus
    V[2].x=-40.0;
    V[2].y=-6.0;
    V[2].z=10.0;
    V[3].x=40.0;
    V[3].y=-6.0;
    V[3].z=10.0;
    V[4].x=0.0;
    V[4].y=48.0;
    V[4].z=10.0;


    memset(&Co,0,sizeof(struct Coordinates));


    sprintf(fname,"%s/CBRES/NullRejection MaxCoord=%d SystematicClusters=%d critical=%f stud=%d sub=%d prop=%f Zcen=%f CDprop=%f.csv",
            REPORT_FOLDER,MaxCoordinates,SystematicClusters,critical, Studies, Subjects, CoordinateProportion, Zthreshold, NotClustered);
    //if ((fp=fopen(fname,"w"))) fclose(fp);



    iter=1;
    sum=sum2=0.0;
    do
    {


        Paper_Simulation_Coordinates(&Co, image, Studies, MaxCoordinates, CoordinateProportion, Subjects, Zthreshold, SystematicClusters, del, V);




        ClusteringDistance = EstimateClusteringDistanceUsingNull(hwnd, &Co,(*image).img,
                             (*image).X, (*image).Y, (*image).Z,
                             (*image).dx, (*image).dy, (*image).dz,
                             (*image).x0, (*image).y0, (*image).z0,NotClustered, 0);



        if (ClusteringDistance>0.0)
        {


            //pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
            //double ClusteringDistance, float critical, int model, char directory[], int MergeStudies, int *SigClusters, int *TotalNullClusters, int save, int Use_t)
            pvalue=pClusterZ(hwnd, &Co, (*image).img,  (*image).X, (*image).Y, (*image).Z,
                             (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,
                             ClusteringDistance, critical, ID_MEANZ, "", 0, &SigClusters,&TotalNullClusters,
                             0, Use_t, ID_DO_FCDR, ID_CLUSTER_ALL, DEFAULT_MARKER_SIZE);


            error=0.0;
            if (SystematicClusters>0)
            {
                if (SigClusters) error = (double)TotalNullClusters/SigClusters/FCDR_PERMUTATIONS;
                else error = 0.0;
            }
            else
            {
                if (SigClusters>0) error=1.0;
            }
            sum+=error;
            sum2+=error*error;
            variance=sum2/iter-sum*sum/iter/iter;
            if (variance<0.0) variance=0.0;


            if ((fp=fopen(fname,"a")))
            {
                fprintf(fp,"%d,%f,%d,%f,%f,%f\n",iter,pvalue,SigClusters,(float)TotalNullClusters/FCDR_PERMUTATIONS,sum/iter,sqrt(variance));
                fclose(fp);
            }



        }
        FreeCoordinates(&Co);

        iter++;
    }
    while((iter<100) || ( (iter<=iterations) && (sqrt(variance)>(critical/10) ) ));

    FreeCoordinates(&Co);


    return 1;
}

//======================================================================================================
//NULL coordinates and effect generator
//effects are between MinZ<=|Z|<=MaxZ
//======================================================================================================
int Paper_MEAN_COEFFICIENT_Coordinates(struct Coordinates *Co, struct Image *mask, int Studies, int MaxCoordinates, double CoordinateProportion,
                                       int Subjects, double Zcensor, double mean, double beta,double BetweenStudySD)
{
    double MaxZ=6.0;
    double MinZ=Zcensor;
    int study, coordinate;
    int TotalCoordinates;
    int RandomVoxel;
    int xi,yi,zi;
    double U, Z;
    double dx,dy,dz;
    struct ThreeVector V;
    double a=sqrt(1.0/(1.0/3 + 2.0/3/(Studies-1)));
    double theta;

    V.x=-38.0;
    V.y=0.0;
    V.z=13.0;


    memset(Co,0,sizeof(struct Coordinates));
    MakeStructCoordinates(Co, (MaxCoordinates+2)*Studies, Studies);
    (*Co).ZscoreUsed=1;
    TotalCoordinates=0;
    for (study=0; study<Studies; study++)
    {
        sprintf((*Co).ID[study].txt,"Study%d",study);
        (*Co).SubjectsInExp[study] = Subjects;
        (*Co).Zcensor[study] = MinZ;
        //insert the random coordinates
        for (coordinate=0; coordinate<MaxCoordinates; coordinate++)
        {
            U=(double)rand()/RAND_MAX;
            if (U<=CoordinateProportion)
            {

                do
                {
                    Z=GaussRandomNumber_BoxMuller(mean, 3.0);//|Z| will be >MinZ and <=MaxZ
                }
                while ((fabs(Z)>MaxZ) || (fabs(Z)<MinZ));


                RandomVoxel = RandomVoxelALE((*mask).img,(*mask).X*(*mask).Y*(*mask).Z);
                XYZfromVoxelNumber(RandomVoxel, &xi, &yi, &zi, (*mask).X, (*mask).Y, (*mask).Z);
                (*Co).x[TotalCoordinates] = (*mask).dx*xi - (*mask).x0;
                (*Co).y[TotalCoordinates] = (*mask).dy*yi - (*mask).y0;
                (*Co).z[TotalCoordinates] = (*mask).dz*zi - (*mask).z0;
                (*Co).subjects[TotalCoordinates] = Subjects;
                (*Co).Zsc[TotalCoordinates] = Z;
                (*Co).experiment[TotalCoordinates] = study;
                TotalCoordinates++;
            }
        }
        //insert the systematic coordinates

        theta=mean + beta*(-a + 2*a*(study)/(Studies-1));

        Z=GaussRandomNumber_BoxMuller(theta, BetweenStudySD);
        if (Z>MinZ)//not censored
        {
            dx=GaussRandomNumber_BoxMuller(0.0,5.0);
            dy=GaussRandomNumber_BoxMuller(0.0,5.0);
            dz=GaussRandomNumber_BoxMuller(0.0,5.0);
            (*Co).x[TotalCoordinates] = V.x+dx;
            (*Co).y[TotalCoordinates] = V.y+dy;
            (*Co).z[TotalCoordinates] = V.z+dz;
            (*Co).subjects[TotalCoordinates] = Subjects;
            (*Co).Zsc[TotalCoordinates] = Z;
            (*Co).experiment[TotalCoordinates] = study;
            TotalCoordinates++;
        }

    }
    (*Co).TotalFoci=TotalCoordinates;


    return 1;
}
//======================================================================================================
//TEST NULL REJECTION
//======================================================================================================
int TestClusterz_Mean_Regression(HWND hwnd, struct Image *image,double critical, int Studies, int MaxCoordinates, double CoordinateProportion,
                                 int Subjects, int iterations, double Zthreshold, double mean, double beta,double BetweenStudySD, int model)
{
    struct Coordinates Co;
    double ClusteringDistance;
    char fname[MAX_PATH];
    int iter;
    int SigClusters,TotalNullClusters;
    double pvalue;
    FILE *fp=NULL;

    memset(&Co,0,sizeof(struct Coordinates));

    sprintf(fname,"%s/CBRES/MEAN REGRESSION critical=%f studies=%d subjects=%d censor=%f, mean=%f beta=%f BSsd=%f.csv",
            REPORT_FOLDER,critical, Studies, Subjects, Zthreshold,mean, beta, BetweenStudySD);
    //if ((fp=fopen(fname,"w"))) fclose(fp);

    for (iter=0; iter<iterations; iter++)
    {

        Paper_MEAN_COEFFICIENT_Coordinates(&Co, image, Studies, MaxCoordinates, CoordinateProportion,
                                           Subjects, Zthreshold, mean, beta, BetweenStudySD);


        ClusteringDistance = EstimateClusteringDistanceUsingNull(hwnd, &Co,(*image).img,  (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,0.05, 0);


        //pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
        //     double ClusteringDistance, float critical, int model, char directory[], int MergeStudies, int *SigClusters, int save)
        pvalue=pClusterZ(hwnd, &Co, (*image).img,  (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,
                         ClusteringDistance, critical, model, "", 0, &SigClusters,&TotalNullClusters, 0, 0, ID_DO_FCDR, ID_CLUSTER_ALL, DEFAULT_MARKER_SIZE);

        FreeCoordinates(&Co);

        if ((fp=fopen(fname,"a")))
        {
            fprintf(fp,"%d,%f,%d,%f\n",iter,pvalue,SigClusters,(float)TotalNullClusters/FCDR_PERMUTATIONS);
            fclose(fp);
        }

    }





    return 1;
}

//======================================================================================================
//TEST THE CLUSTERING DISTANCE ON LOADED DATA
//THIS WILL REDUCE THE CLUSTERING DISTANCE AND SAVE THE NUMBER OF SIGNIFICANT CLUSTERS
//======================================================================================================
int TestClusteringDistanceSensitivity(HWND hwnd, struct Coordinates *coord, struct Image *image)
{
    int result=0;
    int SigClusters, TotalNullClusters;
    double ClusteringDistance;
    double fraction;
    FILE *fp;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\ClusteringSensitivity.csv",REPORT_FOLDER);
    if (!(fp=fopen(fname,"w"))) goto END;
    fclose(fp);

    if (!(fp=fopen(fname,"a"))) goto END;
    fprintf(fp,"fraction, distance, clusters\n");
    fclose(fp);

    for (fraction=0.2; fraction>=0.01; fraction-=0.01)
    {
        //double EstimateClusteringDistanceUsingNull(struct Coordinates *CoordinateStruct, float mask[], int X, int Y, int Z, float dx, float dy,
        //float dz, float x0, float y0, float z0, float CD_SD, float proportion, int MergeStudies)
        ClusteringDistance = EstimateClusteringDistanceUsingNull(hwnd, coord,(*image).img,
                             (*image).X, (*image).Y, (*image).Z,
                             (*image).dx, (*image).dy, (*image).dz,
                             (*image).x0, (*image).y0, (*image).z0,fraction, 1);

//        pClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[],  int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
//                 double ClusteringDistance, float critical, int model, char directory[], int MergeStudies, int *SigClusters, int *TotalNullClusters, int save, int Use_t, int control)

        pClusterZ(hwnd, coord, (*image).img,  (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,
                  ClusteringDistance, 0.05, ID_MEANZ, "", 1, &SigClusters,&TotalNullClusters, 0, 0, ID_DO_FCDR, ID_CLUSTER_ALL, DEFAULT_MARKER_SIZE);

        if (!(fp=fopen(fname,"a"))) goto END;
        fprintf(fp,"%f,%f,%d\n",1.0-fraction, ClusteringDistance, SigClusters);
        fclose(fp);

    }

END:
    return result;
}

//======================================================================================================
//explore an adaptive method of selecting the clustering distance
//look at the proportion of coordinates forming clusters in the real data as a function of the clustering distance
//also look at the same thing under the null hypothesis (random coordinates)
//======================================================================================================
int GetDistanceToNearestNeighbour(struct Coordinates *coord,double shortest[]);
int TestAdaptiveClusteringDistance(struct Image *mask, struct Coordinates *coord)
{
    int result=0;
    int Ncoordinates=(*coord).TotalFoci;
    double *shortestReal=NULL;
    double *shortestNull=NULL;
    double *sum=NULL;
    double sum2;
    double change;
    double sd;
    double error;
    int *sort=NULL;
    int d;
    int iteration, i;
    int Iterations=500;
    struct Coordinates cpy;
    struct Clusters cl;
    FILE *fp=NULL;
    char fname[MAX_PATH];

    MergeCoordinatesbyStudy(coord);

    memset(&cl,0,sizeof (struct Clusters));
    memset(&cpy,0,sizeof (struct Coordinates));

    //get a copy of the coordinates
    if (!memset(&cpy,0,sizeof(struct Coordinates))) goto END;
    CopyCoordinates(coord, &cpy);

    //allocate the memory
    if (!(shortestReal=(double *)malloc(Ncoordinates*sizeof(double)))) goto END;
    if (!(shortestNull=(double *)malloc(Ncoordinates*sizeof(double)))) goto END;
    if (!(sum=(double *)calloc(Ncoordinates,sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(Ncoordinates*sizeof(int)))) goto END;

    GetDistanceToNearestNeighbour(coord,shortestReal);
    QuickSort(shortestReal,sort,Ncoordinates);

    for (d=0; d<Ncoordinates; d++)
    {
        sd=shortestReal[sort[d]]/NSIGMA95;
        FillClusterStructure(coord, &cl, sd);
        sum2=0.0;
        iteration=0;
        do
        {
            //randomise the coordinates
            RandomiseFociRandomEffects((*mask).img, (*mask).X, (*mask).Y, (*mask).Z, (*mask).dx, (*mask).dy, (*mask).dz, (*mask).x0, (*mask).y0, (*mask).z0, &cpy, &cl, sd);

            //compute the distances to nearest neighbours
            GetDistanceToNearestNeighbour(&cpy,shortestNull);

            change=0.0;
            for (i=0; i<Ncoordinates; i++)
            {
                if (shortestNull[i]<shortestReal[sort[d]]) change+=1.0;
            }
            sum[sort[d]]+=change;
            sum2+=change*change;
            iteration++;

            error=sqrt(sum2/iteration - sum[sort[d]]*sum[sort[d]]/iteration/iteration);

        }
        while ( (iteration<Iterations) && ((iteration<10) || (error>0.1)) );
        sum[sort[d]]/=iteration;
    }


    sprintf(fname,"%s/clusterdist.csv",REPORT_FOLDER);
    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"dist,Real,Null,diff\n");
        for (i=0; i<Ncoordinates; i++)
        {
            fprintf(fp,"%f,%f,%f,%f\n",NSIGMA95*shortestReal[sort[i]],(float)(i), sum[sort[i]],(float)(i)-sum[sort[i]]);
        }
        fclose(fp);
    }

    result=1;
END:
    if (shortestReal) free(shortestReal);
    if (shortestNull) free(shortestNull);
    if (sum) free(sum);
    if (sort) free(sort);
    FreeCoordinates(&cpy);

    return result;
}
int GetDistanceToNearestNeighbour(struct Coordinates *coord,double shortest[])
{
    int Ncoordinates=(*coord).TotalFoci;
    int i,j;
    double dist;

    for (i=0; i<Ncoordinates; i++)
    {
        shortest[i]=1000.0;//something big
        for (j=0; j<Ncoordinates; j++)
        {
            if ((*coord).experiment[i]!=(*coord).experiment[j])
            {
                dist=ActivationSeparation(coord, i, j);
                if (dist<shortest[i]) shortest[i]=dist;
            }
        }
    }

    return 1;
}







//======================================================================================================
//SAVE THE EFFECT SIZES IN A CSV FILE FOR SCATTER PLOTTING
//THIS IS TO CHECK FOR OUTLIERS
//======================================================================================================
int SaveEffectSizeToCheckForOutliers(struct Coordinates *Co, char directory[])
{
    FILE *fp;
    int focus;
    int result=0;
    int n1,n2,experiment;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\EffectSizeScatter.csv",directory);
    if (!(fp=fopen(fname,"w"))) goto END;

    for (focus=0; focus<(*Co).TotalFoci; focus++)
    {
        experiment=(*Co).experiment[focus];
        n1=(*Co).SubjectsInExp[experiment];
        n2=(*Co).ControlsInExp[experiment];
        if (fabs((*Co).Zsc[focus])!=1.0) fprintf(fp,"%s,%d,%f\n",(*Co).ID[experiment].txt, experiment, EffectSize((*Co).Zsc[focus], n1, n2, 0));
        else fprintf(fp,"%s,%d,%f\n",(*Co).ID[experiment].txt, experiment, 0.0);
    }

    result=1;
END:
    if (fp) fclose(fp);
    return result;
}



