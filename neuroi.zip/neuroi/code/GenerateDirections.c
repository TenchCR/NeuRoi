/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "generatedirections.h"
#include "tensor.h"
#include "SHdecomposition.h"
#include "display.h"
#include "global.h"
#include "SHdecomposition.h"
#include "sphericalharmonicfunctions.h"


int MaximiseMinimumDistance(struct Spherical sph[], int N, double del);
int MaximiseSHorthogonality(struct Spherical sph[], int N, double del, int order);
double Orthogonality(double X[], int columns, int rows);
int PlotDirections(HWND hwnd, struct Spherical V[], int N);
int GenerateDirections(HWND hwnd, struct ThreeVector V[], int N);
int GenerateOrthogonormalDirections(HWND hwnd, struct ThreeVector V[], int N, int order);
int SaveGeneratedDirections(struct ThreeVector V[], int N);
int PlotAnalysisOfDistances(HWND hwnd, struct ThreeVector V[], int N);
int PlotTriangles3D(HWND hwnd, struct ThreeVector V[], int N, struct Triangle T[], int triangles);
double MaxDotProduct(double x, double y, double z, int v, struct Spherical sph[], int N);
int PlotTriangles(HWND hwnd, struct ThreeVector V[], int N, struct Triangle T[], int triangles);
//=============================================================================================
//                           Generate Directions dialog callback function
//=============================================================================================
INT_PTR CALLBACK GenerateDirectionsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    int N;
    char txt[256];
    struct ThreeVector *V=NULL;

    switch(msg) {


	case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hGenerateDirections=(HWND)NULL;
		EndDialog(hwnd,0);
	break;


    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
    break;



    case WM_COMMAND:
	  switch (LOWORD(wParam)) {

		case IDOK:
            SendMessage(GetDlgItem(hwnd,ID_N_DIRECTIONS),WM_GETTEXT,256,(LPARAM)txt);
            N=abs(atoi(txt));
            if (!N){
                MessageBox(NULL,"Please enter a number","",MB_OK);
                break;
            }
            if (N>=MAX_DIFFUSION_DIRECTIONS){
               sprintf(txt,"Please make the number of directions<%d",MAX_DIFFUSION_DIRECTIONS);
               MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
               break;
            }
            if (!(V=(struct ThreeVector *)malloc(N*sizeof(struct ThreeVector)))){
                MessageBox(NULL,"Unable to allocate memory","",MB_OK);
                break;
            }

            GenerateDirections(GetParent(hwnd), V, N);
            SaveGeneratedDirections(V, N);
	        if (V) free(V);
    		SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}






//==============================================================================
//                        Generate a set of N evenly spaced directions
//==============================================================================
int GenerateDirections(HWND hwnd, struct ThreeVector V[], int N){

    struct Spherical *sph=NULL;
    int i, count;
    int change;
    int iter;
    double x,y,z;
    double R,theta,phi;
    double del=0.1;

    if (!(sph=(struct Spherical *)malloc(N*sizeof(struct Spherical)))) goto END;
    memset(sph,0,N*sizeof(struct Spherical));

    count=GoldenRatioVectors(V, N);


    for (i=0;i<N;i++){
        Cartesian2Spherical(V[i].x, V[i].y, V[i].z, &R, &theta, &phi);
        sph[i].theta=theta;
        sph[i].phi=phi;
    }



//Now maximise the minimum distance between closest vectors
    for (iter=0;iter<8;iter++){
    count=0;
    do{

        change=MaximiseMinimumDistance(sph, N, del);


        count++;

        PlotDirections(hwnd, sph, N);

    }
    while (change && count<1000);
    del/=2;
    }

//convert to cartesian
    for (i=0;i<N;i++){
        Spherical2Cartesian(&x, &y, &z, 1.0, (double)sph[i].theta, (double)sph[i].phi);
        V[i].x=(float)x;
        V[i].y=(float)y;
        V[i].z=(float)z;
    }
    PlotAnalysisOfDistances(hwnd, V, N);


END:
    if (sph) free(sph);

    return 1;
}



//==============================================================================
//                 Maximise the minimum distance between vectors
//==============================================================================
int MaximiseMinimumDistance(struct Spherical sph[], int N, double del){

    int change=0;
    int i;
    double x1,y1,z1;
    double R,thetabest,phibest;
    double dpmax, dpmaxmin, Initdp;
    double d1,d2;
    double V[9];
    double length;

//One iteration of the optimisation algorithm

    for (i=0;i<N;i++){

        Spherical2Cartesian(&x1, &y1, &z1, 1.0, (double)sph[i].theta, (double)sph[i].phi);

        Initdp=dpmaxmin=MaxDotProduct(x1, y1, z1, i, sph, N);
        thetabest=sph[i].theta;
        phibest=sph[i].phi;

        V[0]=x1;
        V[1]=y1;
        V[2]=z1;
        if (OrthogonalVectors(V)){

        x1=V[0]+del*V[3]/3.0;
        y1=V[1]+del*V[4]/3.0;
        z1=V[2]+del*V[5]/3.0;
        length=sqrt(x1*x1+y1*y1+z1*z1);
        if (length>0.0){
            x1/=length;
            y1/=length;
            z1/=length;
        }
        dpmax=MaxDotProduct(x1, y1, z1, i, sph, N);
        d1=Initdp-dpmax;
        if (dpmax<dpmaxmin){
            dpmaxmin=dpmax;
            Cartesian2Spherical(x1, y1, z1, &R, &thetabest, &phibest);
        }

        x1=V[0]+del*V[6]/3.0;
        y1=V[1]+del*V[7]/3.0;
        z1=V[2]+del*V[8]/3.0;
        length=sqrt(x1*x1+y1*y1+z1*z1);
        if (length>0.0){
            x1/=length;
            y1/=length;
            z1/=length;
        }
        dpmax=MaxDotProduct(x1, y1, z1, i, sph, N);
        d2=Initdp-dpmax;
        if (dpmax<dpmaxmin){
            dpmaxmin=dpmax;
            Cartesian2Spherical(x1, y1, z1, &R, &thetabest, &phibest);
        }

        length=sqrt(d1*d1 + d2*d2);

        if (length>0.0){
           x1=V[0] + del*V[3]*d1/length + del*V[6]*d2/length;
           y1=V[1] + del*V[4]*d1/length + del*V[7]*d2/length;
           z1=V[2] + del*V[5]*d1/length + del*V[8]*d2/length;
           length=sqrt(x1*x1+y1*y1+z1*z1);
           if (length>0.0){
               x1/=length;
               y1/=length;
               z1/=length;
           }
           dpmax=MaxDotProduct(x1, y1, z1, i, sph, N);
           if (dpmax<dpmaxmin){
              dpmaxmin=dpmax;
              Cartesian2Spherical(x1, y1, z1, &R, &thetabest, &phibest);
           }
        }

        if (dpmaxmin<Initdp){
            sph[i].theta=thetabest;
            sph[i].phi=phibest;
            change++;
        }

        }
    }



    return change;

}



//==============================================================================
//          Compute the max dot product between vectors
//==============================================================================
double MaxDotProduct(double x, double y, double z, int v, struct Spherical sph[], int N){

    double x1,y1,z1;
    double dp,dpmax;
    int i;

    dpmax=0.0;
    for (i=0;i<N;i++){
        if (i!=v){
            Spherical2Cartesian(&x1, &y1, &z1, 1.0, (double)sph[i].theta, (double)sph[i].phi);
            dp=fabs(x*x1+y*y1+z*z1);
            if (dp>dpmax){
                dpmax=dp;
            }
        }
    }

    return dpmax;

}









//=============================================================================================
//                           Generate Directions dialog callback function
//=============================================================================================
INT_PTR CALLBACK GenerateOrthogonalDirectionsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    int N, order;
    char txt[256];
    struct ThreeVector *V=NULL;

    switch(msg) {


	case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hGenerateDirections=(HWND)NULL;
		EndDialog(hwnd,0);
	break;


    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
    break;



    case WM_COMMAND:
	  switch (LOWORD(wParam)) {

		case IDOK:
            SendMessage(GetDlgItem(hwnd,ID_N_DIRECTIONS),WM_GETTEXT,256,(LPARAM)txt);
            N=atoi(txt);
            if (!N){
                MessageBox(NULL,"Please enter a number","",MB_OK);
                break;
            }
            if (N>=MAX_DIFFUSION_DIRECTIONS){
               sprintf(txt,"Please make the number of directions<%d",MAX_DIFFUSION_DIRECTIONS);
               MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
               break;
            }

            SendMessage(GetDlgItem(hwnd,ID_SH_ORDER),WM_GETTEXT,256,(LPARAM)txt);
            order=atoi(txt);
            if ((order%2) || (order<=0)){
                MessageBox(NULL,"Please enter a positive even number","",MB_OK);
                break;
            }


            if (!(V=(struct ThreeVector *)malloc(N*sizeof(struct ThreeVector)))){
                MessageBox(NULL,"Unable to allocate memory","",MB_OK);
                break;
            }

            GenerateOrthogonormalDirections(GetParent(hwnd), V, N, order);
            SaveGeneratedDirections(V, N);
	        if (V) free(V);
    		SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}


//==============================================================================
//                        Generate a set of N evenly spaced directions
//==============================================================================
int GenerateOrthogonormalDirections(HWND hwnd, struct ThreeVector V[], int N, int order){

    struct Spherical *sph=NULL;
    double *weights=NULL;
    int i, count;
    int change;
    int iter;
    double x,y,z;
    double R,theta,phi;
    double del=0.1;

    if (N>MAX_DIFFUSION_DIRECTIONS) N=MAX_DIFFUSION_DIRECTIONS-1;

    if (!(sph=(struct Spherical *)malloc(N*sizeof(struct Spherical)))) goto END;
    memset(sph,0,N*sizeof(struct Spherical));
    if (!(weights=(double *)malloc(N*sizeof(double)))) goto END;
    for (i=0;i<N;i++) weights[i]=1.0;

    count=GoldenRatioVectors(V, N);


    for (i=0;i<N;i++){
        Cartesian2Spherical(V[i].x, V[i].y, V[i].z, &R, &theta, &phi);
        sph[i].theta=theta;
        sph[i].phi=phi;
    }



//Now maximise the minimum distance between closest vectors
    for (iter=0;iter<6;iter++){
        //sprintf(txt,"%d",iter);
        //MessageBox(NULL,txt,"",MB_OK);
        count=0;
        do{

            change=MaximiseSHorthogonality(sph, N, del, order);

            PlotDirections(hwnd, sph, N);

            count++;
        }
        while (change && count<1000);
        del/=2;
    }

//convert to cartesian
    for (i=0;i<N;i++){
        Spherical2Cartesian(&x, &y, &z, 1.0, (double)sph[i].theta, (double)sph[i].phi);
        V[i].x=(float)x;
        V[i].y=(float)y;
        V[i].z=(float)z;
    }

    PlotMatrix(hwnd, V, N, order);


END:
    if (sph) free(sph);
    if (weights) free(weights);

    return 1;
}




//==============================================================================
//                 Maximise the orthogonaliy of the spherical harmonics
//==============================================================================
int MaximiseSHorthogonality(struct Spherical sph[], int N, double del, int order){

    int change=0;
    int i;
    int Nharmonics=(order+2)*(order+1)/2;
    double x1,y1,z1;
    double R,theta,phi,thetabest,phibest;
    double V[9];
    double d1,d2, length;
    double *X=NULL;
    double *best=NULL;
    double orthogonality, minorthogonality, InitOrthogonality;

//COMPUTE ALL OF THE SPHERICAL HARMONICS FOR ALL N OF THE DIRECTIONS
    X=(double *)malloc(Nharmonics*N*sizeof(double));
    best=(double *)malloc(Nharmonics*sizeof(double));
    if (!best || !X) goto END;

    for (i=0;i<N;i++){
        //COMPUTE THE SPHERICAL HARMONICS FOR THIS sph[i]
        ComputeSHgivenDirection(&X[i*Nharmonics], order, (double)sph[i].theta, (double)sph[i].phi);
    }

//One iteration of the optimisation algorithm

    minorthogonality=Orthogonality(X, Nharmonics, N);
    for (i=0;i<N;i++){

        InitOrthogonality=minorthogonality;
        memcpy(best,&X[i*Nharmonics], sizeof(double)*Nharmonics);
        thetabest=sph[i].theta;
        phibest=sph[i].phi;


        Spherical2Cartesian(&x1, &y1, &z1, 1.0, (double)sph[i].theta, (double)sph[i].phi);
        V[0]=x1;
        V[1]=y1;
        V[2]=z1;

        if (OrthogonalVectors(V)){


           //displace each vector
           x1=V[0]+del*V[3];
           y1=V[1]+del*V[4];
           z1=V[2]+del*V[5];
           Cartesian2Spherical(x1, y1, z1, &R, &theta, &phi);
           ComputeSHgivenDirection(&X[i*Nharmonics], order, theta, phi);
           orthogonality=Orthogonality(X, Nharmonics, N);
           d1=InitOrthogonality-orthogonality;
           if (orthogonality<minorthogonality){
                memcpy(best,&X[i*Nharmonics], sizeof(double)*Nharmonics);
                minorthogonality=orthogonality;
                thetabest=theta;
                phibest=phi;
           }


           x1=V[0]+del*V[6];
           y1=V[1]+del*V[7];
           z1=V[2]+del*V[8];
           Cartesian2Spherical(x1, y1, z1, &R, &theta, &phi);
           ComputeSHgivenDirection(&X[i*Nharmonics], order, theta, phi);
           orthogonality=Orthogonality(X, Nharmonics, N);
           d2=InitOrthogonality-orthogonality;
           if (orthogonality<minorthogonality){
                memcpy(best,&X[i*Nharmonics], sizeof(double)*Nharmonics);
                minorthogonality=orthogonality;
                thetabest=theta;
                phibest=phi;
           }

           length=sqrt(d1*d1 + d2*d2);

           if (length>0.0){
               x1=V[0]+del*V[3]*d1/length+del*V[6]*d2/length;
               y1=V[1]+del*V[4]*d1/length+del*V[7]*d2/length;
               z1=V[2]+del*V[5]*d1/length+del*V[8]*d2/length;
               Cartesian2Spherical(x1, y1, z1, &R, &theta, &phi);
               ComputeSHgivenDirection(&X[i*Nharmonics], order, theta, phi);
               orthogonality=Orthogonality(X, Nharmonics, N);
               if (orthogonality<minorthogonality){
                    memcpy(best,&X[i*Nharmonics], sizeof(double)*Nharmonics);
                    minorthogonality=orthogonality;
                    thetabest=theta;
                    phibest=phi;
               }

           }

           memcpy(&X[i*Nharmonics], best, sizeof(double)*Nharmonics);
           sph[i].theta=thetabest;
           sph[i].phi=phibest;

           if (minorthogonality<InitOrthogonality) change++;
        }
    }

END:
    if (X) free(X);
    if (best) free(best);

    return change;
}

//==============================================================================
//              Measure the orthogonality
//==============================================================================
double Orthogonality(double X[], int columns, int rows){

    double result;
    double *M=NULL;
    int i,j,k;

    M=(double *)malloc(columns*columns*sizeof(double));
    if (!M) return 0.0;

    for (i=0;i<columns;i++){
        for (j=i;j<columns;j++){
            M[i*columns+j]=0.0;
            for (k=0;k<rows;k++){
                M[i*columns+j]+=X[k*columns+i]*X[k*columns+j];
            }
            M[i*columns+j]*=4.0*PI/rows;
            M[j*columns+i]=M[i*columns+j];
            if (i==j) M[i*columns+j]-=1.0;
        }
    }

    result=0.0;
    for (i=0;i<columns;i++){
        for (j=0;j<columns;j++){
            result+=M[j*columns+i]*M[i*columns+j];
        }
    }

    if (M) free(M);

    return result;
}
















//==============================================================================
//                 Plot the directions
//                 Plots the vectors on the screen
//                  with x<-phi and y<-theta
//==============================================================================
int PlotDirections(HWND hwnd, struct Spherical V[], int N){

    int i;
    int x,y;
    HDC hDC;
    HBRUSH hBrush;
    HPEN hPen;

    hDC=GetDC(hwnd);

    hBrush=SelectObject(hDC,GetStockObject(WHITE_BRUSH));
    hPen=SelectObject(hDC,GetStockObject(BLACK_PEN));


    Rectangle(hDC,50,100,250,200);

    for (i=0;i<N;i++){
        x=50+200.0*V[i].phi/2.0/PI;
        y=100+100.0*V[i].theta/PI;
        Ellipse(hDC,x-1,y-1,x+1,y+1);
    }

    SelectObject(hDC,hBrush);
    SelectObject(hDC,hPen);

    ReleaseDC(hwnd,hDC);

    return 1;
}






//==============================================================================
//          Save the matrix X^TX to see if it is diagonal
//==============================================================================
int PlotMatrix(HWND hwnd, struct ThreeVector V[], int N, int order){

    COLORREF C;
    int row,col;
    int i;
    int Nharmonics=NumberSHs(order);
    double M, max;
    double *X=NULL;
    double R, theta, phi;
    double frac;
    HDC hDC=GetDC(hwnd);

    C=RGB(0,0,255);
    DrawRectangle(hDC, 95, 195, 105+5*Nharmonics, 205+5*Nharmonics, C);

    X=(double *)malloc(N*Nharmonics*sizeof(double));

    if (X){

        for (i=0;i<N;i++){
            Cartesian2Spherical(V[i].x, V[i].y, V[i].z, &R, &theta, &phi);
            ComputeSHgivenDirection(&X[i*Nharmonics], order, theta, phi);
        }

        max=0.0;
        for (row=0;row<Nharmonics;row++){
            for (col=0;col<Nharmonics;col++){
                M=0.0;
                for (i=0;i<N;i++){
                    M+=X[i*Nharmonics+row]*X[i*Nharmonics+col];
                }
                if (M>max) max=M;
            }
        }

        if (max>0.0){
            for (row=0;row<Nharmonics;row++){
                for (col=0;col<Nharmonics;col++){
                    M=0.0;
                    for (i=0;i<N;i++){
                        M+=X[i*Nharmonics+row]*X[i*Nharmonics+col];
                    }
                    frac=(fabs(M/max))*255;
                    C=RGB((char)frac,(char)frac,(char)frac);
                    DrawRectangle(hDC, 100+5*col, 200+5*row, 105+5*col, 205+5*row, C);
                }
            }
        }

    }

    ReleaseDC(hwnd, hDC);
    if (X) free(X);

    return 1;
}













//==============================================================================
//                 Analyse Directions
//==============================================================================
int AnalyseDirectionVectors(HWND hwnd){

    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];
    int N;

    N=LoadAcquisitionDirections(V);
    if (!N) return 0;

    return PlotAnalysisOfDistances(hwnd, V, N);
}


//==============================================================================
//                  Save Directions as text file
//                  Directions are saved in format:
//                  N
//                  x1 y1 z1
//                  x2 y2 z2
//                  .
//                  .
//                  xN yN zN
//                  Also saves in bvecs format as specified by FSL
//==============================================================================
int SaveGeneratedDirections(struct ThreeVector V[], int N){

    OPENFILENAME fnamedlg;
	char filename[MAX_PATH];        //the filename including path
    char bvecsfile[MAX_PATH];
    int dir;
    FILE *fp;

    filename[0]='\0';

	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=NULL;
	fnamedlg.lpstrFilter="Direction Vectors\0*.txt\0\0";
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=filename;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrInitialDir="./";
	fnamedlg.lpstrDefExt="txt";
	fnamedlg.lpstrTitle="Select directions file";

    if (GetSaveFileName(&fnamedlg)){
       //first save the vectors in x y z by row
       if ( (fp=fopen(filename,"w")) ){
          fprintf(fp,"%d\n",N);
          for (dir=0;dir<N;dir++){
              fprintf(fp,"%f %f %f\n",V[dir].x, V[dir].y, V[dir].z);
          }
          fclose(fp);
       }

       //now save a bvecs file; format specified in FSL
       //filename is as above, but with _bvecs and no extension
       memcpy(bvecsfile,filename,strlen(filename));
       bvecsfile[strlen(filename)-4]='\0';
       sprintf(bvecsfile,"%s_bvecs",bvecsfile);
       if ( (fp=fopen(bvecsfile,"w")) ){
          fprintf(fp,"0.0 ");
          for (dir=0;dir<N;dir++) fprintf(fp,"%f ",V[dir].x);
          fprintf(fp,"0.0 ");
          for (dir=0;dir<N;dir++) fprintf(fp,"%f ",V[dir].y);
          fprintf(fp,"0.0 ");
          for (dir=0;dir<N;dir++) fprintf(fp,"%f ",V[dir].z);
          fclose(fp);
       }

    }

    return 0;
}





//==============================================================================
//                  Plot analysis of distances
//                  That is, the sorted dot products between vectors i,j
//                  If the vecotrs are evenly spaced on the sphere, this should
//                     be a straight line
//==============================================================================
int PlotAnalysisOfDistances(HWND hwnd, struct ThreeVector V[], int N){

    int result=0;
    int i,j;
    int x,y;
    int *sort=NULL;
    //int H[101];
    //int Hmax=0;
    double *dp=NULL;
    HDC hDC;
    HBRUSH hBrush;
    HPEN hPen;

    hDC=GetDC(hwnd);


    hBrush=SelectObject(hDC,GetStockObject(WHITE_BRUSH));
    hPen=SelectObject(hDC,GetStockObject(BLACK_PEN));

    Rectangle(hDC,45,245,255,455);


	if (!(dp=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(N*sizeof(int)))) goto END;

    //memset(H,0,sizeof(int)*101);

    memset(sort,0,N*sizeof(int));
    for (i=0;i<N;i++){
        memset(dp,0,sizeof(double)*N);
        for (j=0;j<N;j++){
            //if (i!=j){
                dp[j]=fabs(V[i].x*V[j].x + V[i].y*V[j].y + V[i].z*V[j].z);
                //k=100*dp[j];
                //if (k>100) k=100;
                //H[k]++;
                //if (H[k]>Hmax) Hmax=H[k];
            //}
        }
        QuickSort(dp, sort, N);
        for (j=0;j<N;j++){
            x=50+j*200/N;
            y=250+dp[sort[j]]*200;
            Ellipse(hDC,x-1,y-1,x+1,y+1);
        }
    }

    /*if (Hmax){
       Rectangle(hDC,45,495,255,605);
       MoveToEx(hDC,50,600-100*H[0]/Hmax,NULL);

       for (k=0;k<=100;k++){
    	LineTo(hDC,50+2*k,600-100*H[k]/Hmax);
       }
    }*/

    result=1;

END:
    SelectObject(hDC,hBrush);
    SelectObject(hDC,hPen);

    ReleaseDC(hwnd,hDC);
    if (dp) free(dp);
    if (sort) free(sort);

    return result;
}
















//=============================================================================================
//          Generate set of direction vectors, similar to the Fibonacci set, but not so restricted
//          In the Fibonacci set, use F1 and F2 as sequential Fibonacci numbers
//          Then, z=-1+2/F2*i, phi=2*PI*i*F1/F2
//          The ratio of F1 to F2 is F2/F1=1.618..., the golden ratio
//          So in this routine, chose F2 to be an integer, and F1=(int)(F2/1.618...)
//=============================================================================================
int GoldenRatioVectors(struct ThreeVector V[], int N){

    int F1, F2;
    int j,n=0;
    double del;
    double x,y,z,phi;
    double length;
    //char txt[256];


    F2=N-1;
    F1=(int)(F2/1.6180339887 + 0.5);
    if (F1<=0) return 0;




    del=2.0/F2;
    n=0;
    for (j=0;j<=F2;j++){
        z=-1.0+j*del;
        if (z>1.0) z=1.0;//can overflow due to machine precision, making length sqrt(-ve)
        if (z<-1.0) z=-1.0;
        length=sqrt((1.0-z*z));
        phi=2.0*PI*((double)F1/F2)*j;
        x=length*cos(phi);
        y=length*sin(phi);


        V[j].x=x; V[j].y=y; V[j].z=z;
        n++;
    }

    //sprintf(txt,"%d %d %d %f",F1,F2,n,(float)F2/F1);
    //MessageBox(NULL,txt,"",MB_OK);


    return n;

}

//=============================================================================================
//          Generate Fibonacci set of direction vectors
//          Two Fibonacci numbers, F1 & F2, are generated, with F1 being the Fibonacci
//              number just before F2
//          The total number of points is F2+1
//          The vectors are created such that z=-1+2/F2*i, phi=2*PI*i*F1/F2
//Fibonacci numerical integration on a sphere
//J H Hannay and J F Nye
//J. Phys. A: Math. Gen. 37 (2004) 11591�11601
//Fibonacci numbers  are: 1,1,2,3,5,8,13,21,34,55,89,144,233,377...
//=============================================================================================
int FibonacciVectors(struct ThreeVector V[], int N){

    int F1, F2;
    int tmp;
    int j;
    double del;
    double x,y,z,phi;
    double length;
    //char txt[256];

    //COMPUTE THE FIBONACCI NUMBERS THAT DEFINE THE SET
    F1=F2=1;
    while( (F1+F2+1)<=N ){
        tmp=F2;
        F2=F1+F2;
        F1=tmp;
    }

    //sprintf(txt,"%d %d",F1,F2);
    //MessageBox(NULL,txt,"",MB_OK);

    del=2.0/F2;

    for (j=0;j<=F2;j++){
        z=-1.0+j*del;
        length=sqrt((1.0-z*z));
        phi=2.0*PI*((double)F1/F2)*j;
        x=length*cos(phi);
        y=length*sin(phi);

        V[j].x=x; V[j].y=y; V[j].z=z;
    }


    return F2+1;
}

int TestFibonacci(HWND hwnd){

    struct ThreeVector V[5000];
    struct Spherical S[5000];
    int n;
    int i;
    double R,theta,phi;

//    n=TriangulateSphere(V, 500);
    n=GoldenRatioVectors(V, 1024);
    //n=FibonacciVectors(V, 100);

    for (i=0;i<n;i++){
        Cartesian2Spherical(V[i].x, V[i].y, V[i].z, &R, &theta, &phi);
        S[i].theta=theta;
        S[i].phi=phi;
    }

    PlotDirections(hwnd, S, n);
    PlotAnalysisOfDistances(hwnd, V, n);

    return 1;
}

//=============================================================================================
//          Generate Fibonacci set of INTEGRATION vectors
//          Two Fibonacci numbers, F1 & F2, are generated, with F1 being the Fibonacci
//              number just before F2
//          The total number of points is F2+1
//          The vectors are created such that z1=-1+2/F2*i, z=z+sin(PIz)/PI, phi=PI*i*F1/F2
//Fibonacci numerical integration on a sphere
//J H Hannay and J F Nye
//J. Phys. A: Math. Gen. 37 (2004) 11591�11601
//Fibonacci numbers  are: 1,1,2,3,5,8,13,21,34,55,89,144,233,377...
//See explicit integration equation for modifications to FibonacciVectors routine
//=============================================================================================
int FibonacciIntegrationVectors(struct ThreeVector V[], int N){

    int F1, F2;
    int tmp;
    int j;
    double del;
    double x,y,z,z1,phi;
    double length;
    //char txt[256];

    //COMPUTE THE FIBONACCI NUMBERS THAT DEFINE THE SET
    F1=F2=1;
    while( (F1+F2+1)<=N ){
        tmp=F2;
        F2=F1+F2;
        F1=tmp;
    }

    //sprintf(txt,"%d %d",F1,F2);
    //MessageBox(NULL,txt,"",MB_OK);

    del=2.0/F2;

    for (j=0;j<=F2;j++){
        z1=-1.0+j*del;
        z=z1+sin(PI*z1)/PI;
        if (z<0.0) z=0.0;
        if (z>1.0) z=1.0;
        length=sqrt((1.0-z*z));
        phi=PI*((double)F1/F2)*j;
        x=length*cos(phi);
        y=length*sin(phi);

        V[j].x=x; V[j].y=y; V[j].z=z;
    }


    return F2+1;
}



//=============================================================================================
//               Triangulate a sphere to find even distribution of vertices
//               Start with 6 points and 8 triangles
//               Subdivide each line at the midpoint to generate 1 new point
//               Each triangle is subdivided into 4
//               MAX number of triangle is 9000
//               The number of points is a power of 4
//=============================================================================================
struct TriangleElement{
       struct ThreeVector A;
       struct ThreeVector B;
       struct ThreeVector C;
};
int TriangulateSphere(struct ThreeVector V[], int MAX){

    int Ntri;
    int N;
    int tri;
    struct TriangleElement TE[9000], tmp;
    struct ThreeVector Vi[6];

    memset(TE,0,sizeof(struct TriangleElement)*9000);
    if (MAX>9000) MAX=9000;

//  to start there are 6 points
    Vi[0].x=0.0; Vi[0].y=0.0; Vi[0].z=1.0; //NORTH
    Vi[1].x=0.0; Vi[1].y=0.0; Vi[1].z=-1.0;//SOUTH
    Vi[2].x=1.0; Vi[2].y=0.0; Vi[2].z=0.0; //EAST
    Vi[3].x=-1.0; Vi[3].y=0.0; Vi[3].z=0.0;//WEST
    Vi[4].x=0.0; Vi[4].y=1.0; Vi[4].z=0.0; //FRONT
    Vi[5].x=0.0; Vi[5].y=-1.0; Vi[5].z=0.0;//BACK

//INITIALISE THE 8 TRIANGLES TO START WITH
    TE[0].A=Vi[0]; TE[0].B=Vi[2]; TE[0].C=Vi[4]; //N, E, F
    TE[1].A=Vi[0]; TE[1].B=Vi[2]; TE[1].C=Vi[5]; //N, E, B
    TE[2].A=Vi[0]; TE[2].B=Vi[3]; TE[2].C=Vi[4]; //N, W, F
    TE[3].A=Vi[0]; TE[3].B=Vi[3]; TE[3].C=Vi[5]; //N, W, B

    TE[4].A=Vi[1]; TE[4].B=Vi[2]; TE[4].C=Vi[4]; //S, E, F
    TE[5].A=Vi[1]; TE[5].B=Vi[2]; TE[5].C=Vi[5]; //S, E, B
    TE[6].A=Vi[1]; TE[6].B=Vi[3]; TE[6].C=Vi[4]; //S, W, F
    TE[7].A=Vi[1]; TE[7].B=Vi[3]; TE[7].C=Vi[5]; //S, W, B

    Ntri=8;

//SUBDIVIDE TRIANGLES
    while((Ntri*4)<MAX){
        N=Ntri;
        for (tri=0;tri<N;tri++){
            //CREATE THREE NEW POINTS
            Vi[0].x=TE[tri].A.x+TE[tri].B.x;
            Vi[0].y=TE[tri].A.y+TE[tri].B.y;
            Vi[0].z=TE[tri].A.z+TE[tri].B.z;
            NormaliseThreeVector(&Vi[0]);

            Vi[1].x=TE[tri].A.x+TE[tri].C.x;
            Vi[1].y=TE[tri].A.y+TE[tri].C.y;
            Vi[1].z=TE[tri].A.z+TE[tri].C.z;
            NormaliseThreeVector(&Vi[1]);

            Vi[2].x=TE[tri].C.x+TE[tri].B.x;
            Vi[2].y=TE[tri].C.y+TE[tri].B.y;
            Vi[2].z=TE[tri].C.z+TE[tri].B.z;
            NormaliseThreeVector(&Vi[2]);

            //NOW MODIFY THE CURRENT TRIANGLE
            tmp=TE[tri];
            TE[tri].B=Vi[0];
            TE[tri].C=Vi[1];

            //NOW ADD THREE NEW TRIANGLES
            TE[Ntri].A=tmp.B;
            TE[Ntri].B=Vi[0];
            TE[Ntri].C=Vi[2];
            Ntri++;

            TE[Ntri].A=tmp.C;
            TE[Ntri].B=Vi[1];
            TE[Ntri].C=Vi[2];
            Ntri++;

            TE[Ntri].A=Vi[0];
            TE[Ntri].B=Vi[1];
            TE[Ntri].C=Vi[2];
            Ntri++;

        }
    }

//COMPUTE THE VERTICES AS UNIT VECTORS AT THE CENTRE OF EACH TRIANGLE
    for (tri=0;tri<Ntri;tri++){
        V[tri].x=TE[tri].A.x + TE[tri].B.x + TE[tri].C.x;
        V[tri].y=TE[tri].A.y + TE[tri].B.y + TE[tri].C.y;
        V[tri].z=TE[tri].A.z + TE[tri].B.z + TE[tri].C.z;

        NormaliseThreeVector(&V[tri]);
    }

    return Ntri;
}









//==============================================================================
//          Load a directions file, triangulate, and display
//==============================================================================
int CheckDirections(HWND hwnd){

    struct ThreeVector V[2*MAX_DIFFUSION_DIRECTIONS];
    struct ThreeVector Norm[2*MAX_DIFFUSION_DIRECTIONS];
    struct Triangle *T=NULL;
    int Tmax, triangles;
    int vector,vectors;
    OPENFILENAME fnamedlg;
	char filename[MAX_PATH];        //the filename including path
    static HCURSOR hourglass;
    HCURSOR	PrevCursor;


    filename[0]='\0';

	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=NULL;
	fnamedlg.lpstrFilter="Directions\0*.txt;\0\0";
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=filename;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrInitialDir=NULL;
	fnamedlg.lpstrTitle="Load directions";
	fnamedlg.lpstrDefExt="txt";


	if(GetOpenFileName(&fnamedlg)){
        vectors=LoadDirections(V, filename);

        Tmax=10*vectors;
        if (!(T=(struct Triangle *)malloc(Tmax*sizeof(struct Triangle)))) goto END;
        memset(T,0,Tmax*sizeof(struct Triangle));

        for (vector=0;vector<vectors;vector++){
            V[vector+vectors].x=-V[vector].x;
            V[vector+vectors].y=-V[vector].y;
            V[vector+vectors].z=-V[vector].z;
            Norm[vector]=V[vector];
            Norm[vector+vectors]=V[vector+vectors];
            NormaliseThreeVector(&Norm[vector]);
            NormaliseThreeVector(&Norm[vector+vectors]);
        }


        hourglass=LoadCursor(NULL,IDC_WAIT);
        PrevCursor=SetCursor(hourglass);

        triangles=GetTrianglesFromVectors(hwnd, Norm, 2*vectors, T, Tmax);

        SetCursor(PrevCursor);
        SetFocus(GetParent(hwnd));
    }
    else goto END;

    if (!triangles){
       MessageBox(NULL,"No triangles defined","",MB_OK|MB_ICONWARNING);
       goto END;
    }

END:
    if (T) free(T);

    return 1;
}
//==============================================================================





//==============================================================================
//          Save the matrix X^TX to see if it is diagonal
//          Uses order 8 harmonics
//          Saves the matrix to the same directory as the bvecs file
//==============================================================================
int CheckOrthonormalisationOfVectors(HWND hwnd){

    int directions;
    int d;
    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];
    double weights[MAX_DIFFUSION_DIRECTIONS];
    char name[MAX_PATH];

    //LOAD THE DIRECTIONS (bvecs)
    directions=LoadAcquisitionDirections(V);
    if (!directions) return 0;
    directions--;

    for (d=0;d<directions;d++) weights[d]=1.0;

    sprintf(name,"./matrix_%d_8.txt",directions);
    CheckMatrixIsDiagonal(&V[1], weights, directions, 8, name);

    PlotMatrix(hwnd, &V[1], directions, 8);

    return directions;
}






int Intersect(struct ThreeVector V[], int iV11, int iV12, int iV21, int iV22);
int CountCommonPoints(int a, int b, int c, int a1, int b1, int c1);
double SphericalTriangleArea(struct ThreeVector V1, struct ThreeVector V2, struct ThreeVector V3);
double TriangleArea(struct ThreeVector V1, struct ThreeVector V2, struct ThreeVector V3);
float ValidTriangleArea(struct ThreeVector V[], int directions, struct Triangle T[],
                        int triangles, struct Triangle t, int acute);
int IsTriangleAcute(struct ThreeVector V[], int a, int b, int c);
//==============================================================================
//  Get the integration weights for each direction
//  Triangulate given directions
//  The directions to use are in V[]
//  The results are stored in struct Triangle; of which there should be < max
//==============================================================================
int GetTrianglesFromVectors(HWND hwnd, struct ThreeVector V[], int directions, struct Triangle T[], int Tmax){

    struct Triangle t;
    int Triangles=0;
    int i,j,k;
    int count=0;
    float area, total;
    float A1,A2,A3, maxmin;
    float *angles=NULL;
    double norm[2*MAX_DIFFUSION_DIRECTIONS];
//    char txt[256];

    if (!(angles=(float *)malloc(directions*directions*sizeof(float)))) goto END;

    for (i=0;i<directions;i++){
        norm[i]=LengthThreeVector(&V[i]);
    }

//COMPUTE THE ANGLES SUBTENDED BETWEEN VECTORS V
A3=0.0;
    for (i=0;i<directions;i++){
        for (j=i+1;j<directions;j++){
            angles[j+i*directions]=angles[i+j*directions]=180.0*AngleBetweenThreeVectors(V[i],V[j])/PI;
            if (angles[j+i*directions]>A3) A3=angles[j+i*directions];
        }
    }


//COMPUTE THE MAXIMUM ANGLE BETWEEN VECTORS THAT WE SHOULD TRY DURING TRIANGULATION
    maxmin=0.0;
    for (i=0;i<directions;i++){
        A1=A2=A3=180.0;
        for (j=0;j<directions;j++){
            if (i!=j){
               if (angles[j+i*directions]<A1) A1=angles[j+i*directions];
               if ((angles[j+i*directions]<A2) && (angles[j+i*directions]>A1)) A2=angles[j+i*directions];
               if ((angles[j+i*directions]<A3) && (angles[j+i*directions]>A2) && (angles[j+i*directions]>A1)) A3=angles[j+i*directions];
            }
        }
        if (A3>maxmin) maxmin=A3;
    }




//START BY LOOKING FOR ACUTE VALID TRIANGLES ONLY
    Triangles=0;
    total=0.0;
    for (i=0;i<directions;i++){
        for (j=i+1;j<directions;j++){
            if (angles[j+i*directions]<=maxmin){
                for (k=j+1;k<directions;k++){
                    if ((angles[k+i*directions]<=maxmin) && (angles[k+j*directions]<=maxmin)){
                        t.a=i; t.b=j; t.c=k;
                        if ((norm[i]>0.0) && (norm[j]>0.0) && (norm[k]>0.0)){
                            if ((Triangles<Tmax) && ((area=ValidTriangleArea(V, directions, T, Triangles, t, 1))>0.0)){
                                T[Triangles]=t;
                                T[Triangles].area=area;
                                Triangles++;
                                total+=area;
                                count++;
                                if (count>10){ PlotTriangles(hwnd, V, directions, T, Triangles); count=0;}
                            }
                            else if (Triangles>=Tmax){Triangles=Tmax-1; goto END;}
                        }
                    }
                }
            }
        }
    }

//sprintf(txt,"area=%f",total/4.0/PI);
//MessageBox(NULL,txt,"",MB_OK);

//THE ABOVE IS NOT GUARANTEED TO BE COMPLETE, SO LOOK FOR OTHER TRIANGLES TO COMPLETE THE TRIANGULATION
    /*for (i=0;i<directions;i++){
        for (j=i+1;j<directions;j++){
            for (k=j+1;k<directions;k++){
                t.a=i; t.b=j; t.c=k;
                if ((Triangles<Tmax) && ((area=ValidTriangleArea(V, directions, T, Triangles, t, 0))>0.0)){
                    T[Triangles]=t;
                    T[Triangles].area=area;
                    Triangles++;
                    total+=area;
                }
                else if (Triangles>=Tmax) {Triangles=Tmax-1; goto END;}
            }
        }
    }*/

    PlotTriangles3D(hwnd, V, directions, T, Triangles);

END:
    if (angles) free(angles);

    return Triangles;
}
//==============================================================================
//      Compute the area of a triangle if it is valid
//      A valid triangle contains no other direction vectors within its borders
//==============================================================================
float ValidTriangleArea(struct ThreeVector V[], int directions, struct Triangle T[],
                        int triangles, struct Triangle t, int acute){

    struct ThreeVector Vcentre;
    float area=0.0;
    double *dp=NULL;
    double M[9];
    int *sort=NULL;
    int dir, tri;
    int common;

    if (!(dp=(double *)malloc(directions*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(directions*sizeof(int)))) goto END;


    M[0]=V[t.a].x; M[1]=V[t.a].y; M[2]=V[t.a].z;
    M[3]=V[t.b].x; M[4]=V[t.b].y; M[5]=V[t.b].z;
    M[6]=V[t.c].x; M[7]=V[t.c].y; M[8]=V[t.c].z;

    if (!InvertMatrixA(M,3)) goto END;

    Vcentre.x=M[0]+M[1]+M[2];
    Vcentre.y=M[3]+M[4]+M[5];
    Vcentre.z=M[6]+M[7]+M[8];


    for (dir=0;dir<directions;dir++) dp[dir]=DPThreeVector(&Vcentre, &V[dir]);
    QuickSort(dp, sort, directions);


    //if the three nearest vectors are not t.a, t.b, t.c then the triangle is not valid
    if (CountCommonPoints(t.a, t.b, t.c, sort[directions-1], sort[directions-2], sort[directions-3])!=3) goto END;
    //it may be a valid triangle otherwise

    //triangle should be acute; if acute=TRUE
    if (acute){
        if (!IsTriangleAcute(V, t.a, t.b, t.c)) goto END;
    }

    //check if this triangle is already defined
    for (tri=0;tri<triangles;tri++){
        if ((common=CountCommonPoints(t.a,t.b,t.c,T[tri].a,T[tri].b,T[tri].c))){//may overlap
            //does triangle already exist
            if (common==3) goto END;
        }
    }


    //check if the edges intercept other triangle edges
    /*for (tri=0;tri<triangles;tri++){
        //check t.a-t.b
        if (Intersect(V, t.a, t.b, T[tri].a, T[tri].b)) return 0.0;
        if (Intersect(V, t.a, t.b, T[tri].a, T[tri].c)) return 0.0;
        if (Intersect(V, t.a, t.b, T[tri].b, T[tri].c)) return 0.0;

        //check t.a-t.c
        if (Intersect(V, t.a, t.c, T[tri].a, T[tri].b)) return 0.0;
        if (Intersect(V, t.a, t.c, T[tri].a, T[tri].c)) return 0.0;
        if (Intersect(V, t.a, t.c, T[tri].b, T[tri].c)) return 0.0;


        //check t.b-t.c
        if (Intersect(V, t.b, t.c, T[tri].a, T[tri].b)) return 0.0;
        if (Intersect(V, t.b, t.c, T[tri].a, T[tri].c)) return 0.0;
        if (Intersect(V, t.b, t.c, T[tri].b, T[tri].c)) return 0.0;
    }*/



    //compute area
    area=SphericalTriangleArea(V[t.a], V[t.b], V[t.c]);
    //area=TriangleArea(V[t.a], V[t.b], V[t.c]);

END:
    if (dp) free(dp);
    if (sort) free(sort);

    return area;
}



//==============================================================================
//==============================================================================
int IsTriangleAcute(struct ThreeVector V[], int a, int b, int c){

    if (AngleBetweenThreeVectors(V[a], V[b])>=PI/2.0) return 0;
    if (AngleBetweenThreeVectors(V[a], V[c])>=PI/2.0) return 0;
    if (AngleBetweenThreeVectors(V[b], V[c])>=PI/2.0) return 0;
    return 1;
}


//==============================================================================
//                 Plot the directions
//                 Plots the vectors on the screen
//                  with x<-phi and y<-theta
//==============================================================================
int PlotTriangles(HWND hwnd, struct ThreeVector V[], int N, struct Triangle T[], int triangles){

    int i;
    int x, y;
    double R, theta, phi, theta1, phi1, theta2, phi2;
    HDC hDC;
    HBRUSH hBrush;
    HPEN hPen;

    hDC=GetDC(hwnd);

    hBrush=SelectObject(hDC,GetStockObject(WHITE_BRUSH));
    hPen=SelectObject(hDC,GetStockObject(BLACK_PEN));


    Rectangle(hDC,50,100,250,200);

    for (i=0;i<triangles;i++){
        Cartesian2Spherical(V[T[i].a].x,V[T[i].a].y,V[T[i].a].z, &R, &theta, &phi);

        Cartesian2Spherical(V[T[i].b].x,V[T[i].b].y,V[T[i].b].z, &R, &theta1, &phi1);

        Cartesian2Spherical(V[T[i].c].x,V[T[i].c].y,V[T[i].c].z, &R, &theta2, &phi2);

        if (fabs(phi-phi1)<PI/2.0 && fabs(phi-phi2)<PI/2.0 && fabs(phi1-phi2)<PI/2.0){
        x=50+200.0*phi/2.0/PI;
        y=100+100.0*theta/PI;
        MoveToEx(hDC,x,y,NULL);

        x=50+200.0*phi1/2.0/PI;
        y=100+100.0*theta1/PI;
        LineTo(hDC,x,y);

        x=50+200.0*phi2/2.0/PI;
        y=100+100.0*theta2/PI;
        LineTo(hDC,x,y);

        x=50+200.0*phi/2.0/PI;
        y=100+100.0*theta/PI;
        LineTo(hDC,x,y);
        }
    }

    SelectObject(hDC,hBrush);
    SelectObject(hDC,hPen);

    ReleaseDC(hwnd,hDC);

    return 1;
}


//==============================================================================
//                 Plot the directions
//                 Plots the vectors on the screen
//                  with x<-phi and y<-theta
//==============================================================================
int PlotTriangles3D(HWND hwnd, struct ThreeVector V[], int N, struct Triangle T[], int triangles){

    int i;
	double z;
	POINT P[3];
    HDC hDC;
    HBRUSH hOldBrush, hBrush;
    HPEN hOldPen;

    hDC=GetDC(hwnd);


    hOldPen=SelectObject(hDC,GetStockObject(BLACK_PEN));

    hBrush=CreateSolidBrush(RGB(100,100,100));
	hOldBrush=SelectObject(hDC,hBrush);
    Rectangle(hDC,100,100,500,500);
    SelectObject(hDC,hOldBrush);
	DeleteObject(hBrush);

    for (i=0;i<triangles;i++){
		z=(V[T[i].a].z+V[T[i].b].z+V[T[i].c].z)/3;
		if (z>0.0){
        	if (z>1.0) z=1.0;
        	if (z<0.0) z=0.0;
        	hBrush=CreateSolidBrush(RGB(255*z,255*z,255*z));
    		hOldBrush=SelectObject(hDC,hBrush);

	        P[0].x=300+200*V[T[i].a].x;
	        P[0].y=300+200*V[T[i].a].y;
	        P[1].x=300+200*V[T[i].b].x;
	        P[1].y=300+200*V[T[i].b].y;
	        P[2].x=300+200*V[T[i].c].x;
	        P[2].y=300+200*V[T[i].c].y;

	        Polygon(hDC, P, 3);

			SelectObject(hDC,hOldBrush);
			DeleteObject(hBrush);
		}
    }


    SelectObject(hDC,hOldPen);

    ReleaseDC(hwnd,hDC);

    return 1;
}




//==============================================================================
int CountCommonPoints(int a, int b, int c, int a1, int b1, int c1){

    int count=0;

    if ((a==a1) || (a==b1) || (a==c1)) count++;
    if ((b==a1) || (b==b1) || (b==c1)) count++;
    if ((c==a1) || (c==b1) || (c==c1)) count++;

    return count;
}

//==============================================================================
//      Do the great arcs between vectors intersect?
//      aV11 + (1-a)V12 = b[cV21 + (1-c)V22]
//      V12 = a(V12-V11) + bc(V21-V22) + bV22
//      a interpolates between V11 and V12 and will be 0<a<1 if there is an intercept
//      c interpolates between V11 and V12 and will be 0<c<1 if there is an intercept
//      The scale b should be >0.0
//==============================================================================
int Intersect(struct ThreeVector V[], int iV11, int iV12, int iV21, int iV22){

    struct ThreeVector V11=V[iV11], V12=V[iV12], V21=V[iV21], V22=V[iV22];
    double a,bc,b,c;
    double M[9];

    //if there are common points, then they cant intercect
    if ((iV11==iV21) || (iV11==iV22)) return 0;
    if ((iV12==iV21) || (iV12==iV22)) return 0;


    M[0]=V12.x-V11.x; M[1]=V21.x-V22.x; M[2]=V22.x;
    M[3]=V12.y-V11.y; M[4]=V21.y-V22.y; M[5]=V22.y;
    M[6]=V12.z-V11.z; M[7]=V21.z-V22.z; M[8]=V22.z;

    if (!InvertMatrixA(M, 3)){
        //MessageBox(NULL,"Failed to invert","",MB_OK);
        return 0;
    }

    a =M[0]*V12.x + M[1]*V12.y + M[2]*V12.z;
    bc=M[3]*V12.x + M[4]*V12.y + M[5]*V12.z;
    b =M[6]*V12.x + M[7]*V12.y + M[8]*V12.z;

    if (b<=0.0) return 0;

    c=bc/b;

    if ((a>0) && (a<1.0) && (c>0.0) && (c<1.0)) return 1;

    return 0;
}

//==============================================================================
//      Compute the spherical triangle area
//==============================================================================
//see http://mathforum.org/library/drmath/view/65316.html
double SphericalTriangleArea(struct ThreeVector V1, struct ThreeVector V2, struct ThreeVector V3){

    double A;
    double a,b,c,s;


    a=acos(DPThreeVector(&V1, &V2));
    b=acos(DPThreeVector(&V1, &V3));//angles between points
    c=acos(DPThreeVector(&V2, &V3));

    s=(a+b+c)/2.0;

    A=sqrt(tan(s/2.0)*tan((s-a)/2.0)*tan((s-b)/2.0)*tan((s-c)/2.0));


    return 4.0*atan(A);

}
//==============================================================================
//      Compute triangle ares; NOT SPHERICAL TRIANGLE
//==============================================================================
double TriangleArea(struct ThreeVector V1, struct ThreeVector V2, struct ThreeVector V3){

    struct ThreeVector V12, V13;
    double theta;
    double length;
    double height;

    V12=SubtractThreeVector(V1,V2);
    V13=SubtractThreeVector(V1,V3);

    length=LengthThreeVector(&V12);

    theta=AngleBetweenThreeVectors(V12,V13);

    height=length*sin(theta);

    return LengthThreeVector(&V13)*height/2.0;

}

