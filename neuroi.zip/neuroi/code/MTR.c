/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

//==============================================================================
//              Compute the MT ratio using two images (ON/OFF)
//==============================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "loader.h"
#include "imageprocess.h"



//==============================================================================
//              Load two MRI images (ON and OFF from MTR imaging)
//==============================================================================
int ComputeMTR(HWND hwnd, struct Image *image, int StandardiseScale){

    struct Image On, Off;
    int result=0;
    int X, Y, Zpv;
    int voxel, voxels;

    memset(&On,0,sizeof(struct Image));
    memset(&Off,0,sizeof(struct Image));

    if (LoadAnalyzeOrNiftiEx(hwnd, &On, "Select ON image", StandardiseScale) && LoadAnalyzeOrNiftiEx(hwnd, &Off, "Select OFF image", StandardiseScale)){

        X=On.X; Y=On.Y; Zpv=On.Z/On.volumes;
        if (Off.X!=X || Off.Y!=Y || Off.Z!=On.Z){
            MessageBox(NULL,"The image dimensions are not equal.","",MB_OK|MB_ICONWARNING);
            goto END;
        }
        voxels=X*Y*Zpv;

        ReleaseImage(image);
        MakeImage(image, X, Y, Zpv, 1, On.dx, On.dy, On.dz, On.x0, On.y0, On.z0, 1.0,0.0, DT_FLOAT, HDR, "MTR image MTR=1-ON/OFF");

        for (voxel=0;voxel<voxels;voxel++){
            if ((Off.img[voxel]>0.0) && (On.img[voxel]>0.0)) (*image).img[voxel]=1.0-On.img[voxel]/Off.img[voxel];
            if ((*image).img[voxel]<0.0) (*image).img[voxel]=0.0;
        }
        (*image).changed=1;


        result=1;
    }

    (*image).MaxIntensity=MaximumIntensity(image);

END:
    ReleaseImage(&On);
    ReleaseImage(&Off);

    return result;
}


//==============================================================================
//              Load one MRI image with two volumes (ON and OFF from MTR imaging)
//==============================================================================
int ComputeMTRfromTwoVolume(HWND hwnd, struct Image *image, int StandardiseScale){

    struct Image OnOff;
    int result=0;
    int X, Y, Zpv;
    int voxel, voxels;
    int count;
    int nonnull;

    memset(&OnOff,0,sizeof(struct Image));


    if (LoadAnalyzeOrNiftiEx(hwnd, &OnOff, "Select image", StandardiseScale)){

        if (OnOff.volumes!=2){
            MessageBox(NULL,"Image must have 2 volumes.","",MB_OK|MB_ICONWARNING);
            goto END;
        }

        X=OnOff.X; Y=OnOff.Y; Zpv=OnOff.Z/OnOff.volumes;

        voxels=X*Y*Zpv;

        ReleaseImage(image);
        MakeImage(image, X, Y, Zpv, 1, OnOff.dx, OnOff.dy, OnOff.dz, OnOff.x0, OnOff.y0, OnOff.z0, 1.0,0.0, DT_FLOAT, HDR, "MTR image MTR=1-ON/OFF");

        nonnull=count=0;
        for (voxel=0;voxel<voxels;voxel++){
            if ((OnOff.img[voxel]>0.0) && (OnOff.img[voxel+voxels]>0.0)){
                if ((OnOff.img[voxel]>OnOff.img[voxel+voxels])) count++;
                nonnull++;
            }
        }


        for (voxel=0;voxel<voxels;voxel++){
            if ((OnOff.img[voxel]>0.0) && (OnOff.img[voxel+voxels]>0.0)){
                if ((count<nonnull/2)){
                    (*image).img[voxel]=1.0-OnOff.img[voxel]/OnOff.img[voxel+voxels];
                }
                else{
                    (*image).img[voxel]=1.0-OnOff.img[voxel+voxels]/OnOff.img[voxel];
                }
            }
            if ((*image).img[voxel]<0.0) (*image).img[voxel]=0.0;
        }
        (*image).changed=1;

        result=1;
    }
    (*image).MaxIntensity=MaximumIntensity(image);

END:
    ReleaseImage(&OnOff);

    return result;
}
