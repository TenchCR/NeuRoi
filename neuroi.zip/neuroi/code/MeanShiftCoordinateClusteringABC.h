/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#if defined(MeanShiftClusteringABC_H)
//Do Nothing
#else

#define MeanShiftClusteringABC_H


#include "CoordinateProcess.h"
#include "CBMAfiles.h"
#include "CBclustering2.h"
#include "talairachfunctions.h"
#include "CBMAN.h"
#include "numerical.h"


double OptimiseMeanShiftClusteringKernelABC(HWND hwnd, struct Image *img, struct Coordinates *C, double critical, short int ToCluster[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, double MaxWidth, double *shape, char directory[]);
int GetValidMeanShiftClustersABC(struct Image *image, struct Coordinates *C, short int ToCluster[], char excluded[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width, double shape);



int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int ToCluster[], int MinStudies, double sd);


#endif
