/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "interleave.h"
#include "imageprocess.h"


//==============================================================================
//                  Get a filename
//                  filename must have length MAX_PATH
//==============================================================================
int GetAnImageFileName(char filename[]){

    OPENFILENAME fnamedlg;

    filename[0]='\0';

	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=NULL;
	fnamedlg.lpstrFilter="Image Files\0*.img;*.nii\0\0";
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=filename;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrInitialDir=NULL;
	fnamedlg.lpstrTitle="Select image file to interleave";
	fnamedlg.lpstrDefExt="img";

    return GetOpenFileName(&fnamedlg);
}





//==============================================================================
//                 Rearrange image by volume instead of slice
//==============================================================================
int ArrangeByVolume(struct Image *image){

    int X=(*image).X, Y=(*image).Y, Z=(*image).Z;
    int XYZ=X*Y*Z;
    int XY=X*Y;
    int volume, slice;
    int slices=Z/(*image).volumes;
    int Vol=(*image).volumes;
    float *img;

    if ( (img=(float *)malloc(XYZ*sizeof(float))) ){
        for (volume=0;volume<Vol;volume++){
			for (slice=0;slice<slices;slice++){
                memcpy(&img[volume*XY*slices + slice*XY], &(*image).img[volume*XY + slice*XY*Vol], XY*sizeof(float));
			}
		}
        memcpy((*image).img, img, sizeof(float)*XYZ);
        free(img);
    }
    else return 0;


    return 1;
}




//==============================================================================
//                 Rearrange image by slice instead of volume
//==============================================================================
int ArrangeBySlice(struct Image *image){

    int X=(*image).X, Y=(*image).Y, Z=(*image).Z;
    int XYZ=X*Y*Z;
    int XY=X*Y;
    int volume, slice;
    int slices=Z/(*image).volumes;
    int Vol=(*image).volumes;
    float *img;

    if ( (img=(float *)malloc(XYZ*sizeof(float))) ){
        for (volume=0;volume<Vol;volume++){
			for (slice=0;slice<slices;slice++){
                memcpy(&img[volume*XY + slice*XY*Vol], &(*image).img[slice*XY + volume*XY*slices], XY*sizeof(float));
			}
		}
        memcpy((*image).img, img, sizeof(float)*XYZ);
        free(img);
    }
    else return 0;


    return 1;
}









//==============================================================================
//                 Interleave images
//                 put the result in *image
//==============================================================================
int InterleaveImages(HWND hwnd, struct Image *image){

    int N;

    N=AppendImages(hwnd, image);
    if (!N) return 0;

    if (ArrangeBySlice(image)){
        (*image).volumes=1;//now there is only one volume
        (*image).changed=1;
        return N;
    }

    return 0;
}




//==============================================================================
//                 Append volumes
//                 put the result in *image
//				   Appended volumes must be of the same dimensions as *image
//				   Return number of appended volumes
//==============================================================================
int AppendImages(HWND hwnd, struct Image *image){

	int new_volumes=0;
    int voxels_pv;
    int X, Y, Zpv;
    char fname[MAX_PATH];
    struct Image loaded;

    memset(&loaded,0,sizeof(struct Image));

    X=(*image).X;
    Y=(*image).Y;
    Zpv=(*image).Z/(*image).volumes;
    voxels_pv=X*Y*Zpv;


    while(GetAnImageFileName(fname)){
        if (LoadFromFileName(hwnd, fname, &loaded, 0)){
            if ((X==loaded.X) && (Y==loaded.Y) && (Zpv==loaded.Z/loaded.volumes)){

                if ( ((*image).img=(float *)realloc((*image).img,
					((*image).volumes+loaded.volumes)*voxels_pv*sizeof(float))) ){

                    //append loaded volumes
					memcpy(&(*image).img[(*image).volumes*voxels_pv], loaded.img,
							sizeof(float)*X*Y*loaded.Z);

					(*image).Z+=loaded.Z;
                    (*image).volumes+=loaded.volumes;

                    new_volumes+=loaded.volumes;
                }

                free(loaded.img);
                memset(&loaded,0,sizeof(struct Image));
            }
            else MessageBox(NULL,"Dimensions of each image should be the same.","",MB_OK);

        }
        else MessageBox(NULL,"Load failed, Please try again","",MB_OK);
    }


    (*image).changed=1;

    return new_volumes;
}




