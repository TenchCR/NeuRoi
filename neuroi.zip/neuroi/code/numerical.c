/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "numerical.h"
#include "imageprocess.h"


double TestErrorFunctionForminimisation(double *x, int N, void *na);




//==============================================================================
//EM algorithm for Gaussian mixture models
//==============================================================================
int EMalgorithmNormal(double member[], double mean[], double SD[], double mix[], int N, double x[], int Nx)
{
    double *bak=NULL;
    double change;
    double average,sd;
    int ix, ic;
    double norm;
    //char txt[1000];

    if (N<=1 || Nx<N)
        return 0;

    if (!(bak=(double *)calloc(N*Nx,sizeof(double))))
        goto END;

    memset(member,0,N*Nx*sizeof(double));

    //the initial sd parameter
    sd=sqrt(Var(x,Nx));
    for (ic=0; ic<N; ic++)
        SD[ic] = sd/sqrt((double)N);

    //pick random starting mean parameters
    average=MeanValueDouble(Nx,x);
    for (ic=0; ic<N; ic++)
        {
            //mean[ic] = GaussRandomNumber_BoxMuller(average, sd);
            mean[ic] = average-1.5*sd + 3.0*sd/(N-1)*ic;
        }

    for (ic=0; ic<N; ic++)
        mix[ic] = 1.0/N;

    do
        {
            //sprintf(txt,"%f %f %f\n%f %f %f\n%f %f %f",mean[0], mean[1], mean[2], SD[0], SD[1], SD[2], mix[0], mix[1], mix[2]);
            //MessageBox(NULL,txt,"",MB_OK);

            //E step: compute membership probabilities
            change=0.0;
            memcpy(bak,member,N*Nx*sizeof(double));
            for (ix=0; ix<Nx; ix++)
                {
                    norm=0.0;
                    for (ic=0; ic<N; ic++)
                        {
                            member[ic + ix*N] = mix[ic]*NormalDistribution(mean[ic], SD[ic]*SD[ic], x[ix]);
                            norm += member[ic + ix*N];
                        }
                    if (norm)
                    {
                    for (ic=0; ic<N; ic++)
                        {
                            member[ic + ix*N] /= norm;
                            change+=pow(member[ic + ix*N] - bak[ic + ix*N],2);
                        }
                    }
                }

            //compute new mixture probabilities
            for (ic=0; ic<N; ic++)
                {
                    mix[ic]=0.0;
                    for (ix=0; ix<Nx; ix++)
                        {
                            mix[ic] += member[ic + ix*N];
                        }
                    mix[ic] /= Nx;
                }

            //compute updated means and SDs
            for (ic=0; ic<N; ic++)
                {
                    norm=0.0;
                    mean[ic]=0.0;
                    for (ix=0; ix<Nx; ix++)
                        {
                            mean[ic]+=x[ix]*member[ic + ix*N];
                            norm+=member[ic + ix*N];
                        }
                    if (norm)
                        {
                            mean[ic]/=norm;

                            SD[ic]=0.0;
                            for (ix=0; ix<Nx; ix++)
                                {
                                    SD[ic] += member[ic + ix*N]*(mean[ic]-x[ix])*(mean[ic]-x[ix]);
                                }
                            SD[ic]=sqrt(SD[ic]/norm);
                        }
                }
        }
    while (change>1.0e-6);

END:
    if (bak)
        free(bak);

    return 0;
}
int TestEMalgorithm(void)
{
    double x[1000];
    int n1,n2,n3;
    int i;
    double m1,m2,m3,sd1,sd2,sd3;
    double mean[3];
    double SD[3];
    double mix[3];
    double member[3000];
    char txt[1000];

    n1=500;
    n2=300;
    n3=200;

    m1=1.0;
    m2=3.0;
    m3=5.0;

    sd1=0.05;
    sd2=0.05;
    sd3=0.05;

    for (i=0; i<n1; i++)
        x[i] = GaussRandomNumber_BoxMuller(m1,sd1);
    for (i=0; i<n2; i++)
        x[i+n1] = GaussRandomNumber_BoxMuller(m2,sd2);
    for (i=0; i<n3; i++)
        x[i+n1+n2] = GaussRandomNumber_BoxMuller(m3,sd3);

    EMalgorithmNormal(member, mean, SD, mix, 3, x, 1000);

    sprintf(txt,"%f %f %f\n%f %f %f\n%f %f %f",mean[0], mean[1], mean[2], SD[0], SD[1], SD[2], mix[0], mix[1], mix[2]);
    MessageBox(NULL,txt,"",MB_OK);

    return 0;
}



//==============================================================================
//==============================================================================
//==============================================================================
//Redix sort algorithm
//==============================================================================
//==============================================================================
int RadixSort(double data[], int sort[], int N, int dp)
{
    int result=0;
    int *s=NULL;
    int Counter[10];
    int CDF[10];
    int i,j,k,mp;
    double f;
    unsigned char *m=NULL;

    if (!(m=(unsigned char *)malloc(N)))
        goto END;

    if (!(s=(int *)malloc(N*sizeof(int))))
        goto END;


    for (j=0; j<N; j++)
        sort[j]=j;

    for (i=dp; i>=0; i--)
        {
            memset(Counter,0,10*sizeof(int));
            f=pow(10,i);
            for (j=0; j<N; j++)
                {
                    k=(int)(data[sort[j]] * f);
                    mp=k%10;
                    m[j]=mp;
                    Counter[mp]++;
                }
            CDF[0]=0;
            for (k=1; k<10; k++)
                CDF[k]=CDF[k-1]+Counter[k-1];

            for (j=0; j<N; j++)
                {
                    mp=m[j];
                    s[CDF[mp]]=sort[j];
                    CDF[mp]++;
                }
            memcpy(sort, s, sizeof(int)*N);

        }

    result=1;
END:
    if (m)
        free(m);

    if (s)
        free(s);

    return result;
}

int TestRadixSort(int N, int dp)
{

    double *da=NULL;
    int *sort=NULL;
    int i,save;
    FILE *fp=NULL;

    save=N;
    if (N>1000)
        save=1000;

    da=(double *)malloc(N*sizeof(double));
    sort=(int *)malloc(N*sizeof(int));

    if (da && sort)
        {
            for (i=0; i<N; i++)
                da[i]=(double)rand()/RAND_MAX;
            RadixSort(da, sort, N, dp);
            if ((fp=fopen("c:/temp/Redixsort.txt","w")))
                {
                    for (i=0; i<save; i++)
                        fprintf(fp,"%d %g %g\n",i,da[i],da[sort[i]]);
                    fclose(fp);
                }
        }

    if (da)
        free(da);
    if (sort)
        free(sort);

    return 1;

}





//==============================================================================
//                            QUICK SORT ALGORITHM
//sorts data of type double
//could be re-written to use a different partition algorithm to sort different types such as int or structures
//the data to be sorted are in array data
//on exit sort contains index to the data such that sort[0] points to the lowest and sort[N-1] points to the highest
//Modified Jan 2009. Hi and Lo are not defined arrays anymore, they are malloced. Stops errors when N is large
//==============================================================================
int partition( double *data, int sort[], int sort2[], int Lo, int Hi);
int QuickSort(double *data, int sort[], int N)
{
    /** \brief  sort double data[N]
     *
     * \return 0 if failed, otherwise 1
     *
     */


    int *Hi=NULL,*Lo=NULL;
    int current, UpTo;
    int i;
    int Pivot=N-1;
    int *sort2=NULL;
    int result=0;


    if (N<=0)
        return 0;

    sort2=(int *)malloc(N*sizeof(int));
    Hi=(int *)malloc(N*sizeof(int));
    Lo=(int *)malloc(N*sizeof(int));

    if (sort2 && Hi && Lo)
        {

            //Initially the sort order is unknown
            for (i=0; i<N; i++)
                sort[i]=i;


            current=0;
            Hi[current]=N-1;
            Lo[current]=0;

            UpTo=0;
            do
                {
                    if (Hi[current]>Lo[current])
                        {
                            Pivot=partition(data, sort, sort2, Lo[current], Hi[current]);
                            if ( (Pivot-1)>Lo[current] )
                                {
                                    UpTo++;
                                    Hi[UpTo]=Pivot-1;
                                    Lo[UpTo]=Lo[current];
                                }
                            if ( (Pivot+1)<Hi[current] )
                                {
                                    UpTo++;
                                    Hi[UpTo]=Hi[current];
                                    Lo[UpTo]=Pivot+1;
                                }

                        }
                    current++;
                }
            while((UpTo>=0) && (UpTo<N) && (current>=0) && (current<=UpTo));
            result=1;
        }


    if (sort2)
        free(sort2);

    if (Hi)
        free(Hi);

    if (Lo)
        free(Lo);

    return result;

}
//==============================================================================
//goes with QuickSort routine
//modified 11 May 2015. Use random pivot
//==============================================================================
int partition( double *data, int sort[], int sort2[], int Lo, int Hi)
{

    int i, index, Pivot;
    //int PivotIndex=Lo + rand()%(Hi-Lo+1);//apparently using a random pivot is efficient. See Numerical Recipes page 333
    int PivotIndex=Lo + (Hi-Lo)/2;
    double pivot=data[sort[PivotIndex]];


    //put those between Lo and Hi (inclusive) into an ordered list where those below the pivot are first, then the pivot, then those >= than the pivot

    //below the pivot first
    index=0;
    for (i=Lo; i<=Hi; i++)
        {
            if ((i!=PivotIndex) && (data[sort[i]]<pivot))
                {
                    sort2[index]=sort[i];
                    index++;
                }
        }


    //Not the pivot
    Pivot=index;
    sort2[Pivot]=sort[PivotIndex];
    index++;

    //now those >= pivot
    for (i=Lo; i<=Hi; i++)
        {
            if ((i!=PivotIndex) && (data[sort[i]]>=pivot))
                {
                    sort2[index]=sort[i];
                    index++;
                }
        }

    for (i=Lo; i<=Hi; i++)
        sort[i]=sort2[i-Lo];


    return (Lo+Pivot);
}

int TestQuickSort(int N)
{

    double *da=NULL;
    int *sort=NULL;
    int i,save,result=1;
    FILE *fp=NULL;

    save=N;
    if (N>1000)
        save=1000;

    da=(double *)malloc(N*sizeof(double));
    sort=(int *)malloc(N*sizeof(int));

    if (da && sort)
        {
            for (i=0; i<N; i++)
                da[i]=(double)rand()/RAND_MAX;
            QuickSort(da, sort, N);
            if ((fp=fopen("c:/temp/quicksort.txt","w")))
                {
                    for (i=0; i<save; i++)
                        fprintf(fp,"%d %f %f\n",i,da[i],da[sort[i]]);
                    fclose(fp);
                }
        }

    for (i=1; i<N && result; i++)
        if (da[sort[i]]<da[sort[i-1]])
            result=0;

    if (!result)
        MessageBox(NULL,"failed","",MB_OK);

    if (da)
        free(da);
    if (sort)
        free(sort);

    return result;

}

//==============================================================================
//              Integer sort routines
//==============================================================================
int SortIntegers(int values[], int sort[], int N)
{
    /** Sorts integer data values[N], which should be faster than QuickSort
     *
     *  returns 0 if it fails, 1 otherwise
     */

    int i,d,index,max=0,min,MaxBin;
    long int *H, n0=0;

    memset(sort,0,sizeof(int)*N);

    for (i=0; i<N; i++)
        if (values[i]>values[max])
            max=i;
    min=max;
    max=values[max]+1;


    for (i=0; i<N; i++)
        if (values[i]<values[min])
            min=i;
    min=values[min];

    if (min>=0)
        {
            MaxBin=max;
            min=0;
        }
    else
        MaxBin=max-min;


    if ( (H=(long int *)malloc(sizeof(long int)*MaxBin)) )
        {
            memset(H,0,sizeof(long int)*MaxBin);


            for (i=0; i<N; i++)
                H[values[i]-min]++;
            for (i=1; i<MaxBin; i++)
                H[i]+=H[i-1];



            for (i=0; i<N; i++)
                {
                    d=values[i]-min;
                    if (d==0)
                        {
                            index=n0;
                            n0++;
                        }
                    else
                        {
                            index=H[d-1];
                            H[d-1]++;
                        }
                    if (index<N)
                        sort[index]=i;
                }

            free(H);
            return 1;
        }
    else
        return 0;

}





//==============================================================================
//compute the mean value of a set of N float numbers s
//==============================================================================
double MeanValueFloat(int N, float s[])
{
    int i;
    double sum=0.0;

    if (N<=0)
        return 0.0;

    for (i=0; i<N; i++)
        sum+=s[i];

    return sum/N;
}
//==============================================================================
//compute the mean value of a set of N double numbers s
//==============================================================================
double MeanValueDouble(int N, double s[])
{
    int i;
    double sum=0.0;

    if (N<=0)
        return 0.0;

    for (i=0; i<N; i++)
        sum+=s[i];

    return sum/N;
}
//==============================================================================
//compute the median value of a set of N double numbers s
//==============================================================================
double MedianValueDouble(int N, double s[])
{

    double median;
    int *sort=NULL;

    if ( (sort=(int *)malloc(N*sizeof(int))) )
        {

            median=MedianValueDoubleEx(N, s, sort);

        }
    else
        median=0.0;

    if (sort)
        free(sort);

    return median;
}




//==============================================================================
//compute the median value of a set of N double numbers s
//Pass the array sort so it doesnt have to be malloced each time
//  -speeds things up if called many times
//==============================================================================
double MedianValueDoubleEx(int N, double s[], int sort[])
{

    QuickSort(s, sort, N);

    return s[sort[N/2]];
}




//==============================================================================
//compute the approximate median quickly
//==============================================================================
double MedianValueDoubleFastApprox(int N, double s[])
{

    int approx;
    int H[101];
    int i,sum;
    double min, max;
    double tmp;


    min=max=s[0];
    for (i=1; i<N; i++)
        {
            if (min>s[i])
                min=s[i];
            if (max<s[i])
                max=s[i];
        }
    if (max>min)
        {
            memset(H,0,101*sizeof(int));
            sum=0;
            tmp=100.0/(max-min);
            for (i=0; i<N; i++)
                {
                    approx=(int)((s[i]-min)*tmp);
                    H[approx]++;
                    sum++;
                }
            sum/=2;
            for (i=1; i<101; i++)
                {
                    H[i]+=H[i-1];
                    if (H[i]>=sum)
                        return (max-min)*i/100.0+min;
                }
        }

    return 0.0;
}




//==============================================================================
//compute the variance of a vector of doubles
//==============================================================================
double Var(double d[], int N)
{
    /**
     * \return variance of a double vector d[N]
     *
     */

    double s,s2,v;
    int i;

    if (N<=0)
        return 0.0;

    s=s2=0.0;
    for (i=0; i<N; i++)
        {
            s+=d[i];
            s2+=d[i]*d[i];
        }

    v=s2/N-s*s/N/N;
    if (s2>0.0)
        return v;

    return 0.0;
}

//==============================================================================
//compute the variance of a vector of floats
//==============================================================================
double VarFloat(float d[], int N)
{
    /**
     * \return variance of a double vector d[N]
     *
     */

    double s,s2,v;
    int i;

    if (N<=0)
        return 0.0;

    s=s2=0.0;
    for (i=0; i<N; i++)
        {
            s+=d[i];
            s2+=d[i]*d[i];
        }

    v=s2/N-s*s/N/N;
    if (s2>0.0)
        return v;

    return 0.0;
}




//==============================================================================
//                      Golden search method of MINIMISATION
//                      V[] is the parameter set at the current minimum
//                      n is the number of parameters
//                      dir[] is the direction we are currently minimizing in
//TERMINTATION IS 1/shrinks OF THE MAGNITUDE OF DIR[]
///can search in one dimension only unlike DownHillSimplex
//==============================================================================
double GoldenSearch(double V[], double dir[], int n, double Ecurrent,
                    double (*Get_Error)(double *, int, void *), void *H, int shrinks)
{

    double a,b,c,x;
    double Ea, Eb, Ec;
    double *Vtry=NULL;
    double GS=0.38197;
    double L=1.0/GS;
    int i;




    if (!(Vtry=(double *)malloc(n*sizeof(double))))
        return 0.0;

    //starting points
    a=-1.0;
    b=0.0;
    c=L-1.0;

    Eb=Ecurrent;

    //evaluate at a
    for (i=0; i<n; i++)
        Vtry[i]=V[i]+a*dir[i];

    Ea=Get_Error(Vtry, n, H);

    //evaluate at c
    for (i=0; i<n; i++)
        Vtry[i]=V[i]+c*dir[i];

    Ec=Get_Error(Vtry, n, H);



    do
        {
            //solution=0;
            if ((Ea<Eb) && (Ea<Ec))//Ea<Eb<Ec moving downhill from the a end
                {
                    x=1.618*(a-b)+a;
                    Ec=Eb;
                    c=b;
                    Eb=Ea;
                    b=a;
                    a=x;
                    for (i=0; i<n; i++)
                        Vtry[i]=V[i]+a*dir[i];
                    Ea=Get_Error(Vtry, n, H);

                    //solution=1;
                }
            else if ((Ec<Ea) && (Ec<Eb))//Ec<Eb<Ea moving downhill from the c end
                {
                    x=1.618*(c-b)+c;
                    Ea=Eb;
                    a=b;
                    Eb=Ec;
                    b=c;
                    c=x;
                    for (i=0; i<n; i++)
                        Vtry[i]=V[i]+c*dir[i];
                    Ec=Get_Error(Vtry, n, H);

                    //solution=2;
                }
            else
                {
                    if ((b-a)>(c-b))
                        {
                            L=(b-a);
                            Ec=Eb;
                            c=b;
                            b=a+L*GS;
                            for (i=0; i<n; i++)
                                Vtry[i]=V[i]+b*dir[i];
                            Eb=Get_Error(Vtry, n, H);

                            //solution=3;
                        }
                    else
                        {
                            L=(c-b);
                            Ea=Eb;
                            a=b;
                            b+=L*GS;
                            for (i=0; i<n; i++)
                                Vtry[i]=V[i]+b*dir[i];
                            Eb=Get_Error(Vtry, n, H);

                            //solution=4;
                        }
                }
            //if (fp && count<10) fprintf(fp,"a=%f Ea=%f \t b=%f Eb=%f \t c=%f Ec=%f \t a-c=%f %d\n",a,Ea,b,Eb,c,Ec,a-c,solution);
        }
    while((Ea<Eb) || (Ec<Eb) || (fabs(c-a)>1.0/shrinks));

    x=b;
    for (i=0; i<n; i++)
        V[i]+=x*dir[i];

    //if (fp) fclose(fp);

    if (Vtry)
        free(Vtry);

    return Ecurrent;
}

//==============================================================================
//              Minimize a function using Powells method; Golden Search method used for line search
//              See Numerical recipes, or http://www.ecs.fullerton.edu/~mathews/n2003/PowellMethodMod.html
//==============================================================================
double PowellMinimisation(double Vbest[], int N, double scale[], int Scale,
                          double (*Get_Error)(double *, int, void *), void *H, double tol)
{

    double *directions=NULL;
    double *Vtry=NULL, *Vinitial=NULL;
    double E, Einit, Ebest=0.0;
    double del;
    double normalise;
    int i;
    int direction;
    int bestdir;
    int count;


    //FILE *fp;
    //fp=fopen("c:\\temp\\Powell.txt","a");
    //if (fp) fclose(fp);


    Vtry=(double *)malloc(N*sizeof(double));
    Vinitial=(double *)malloc(N*sizeof(double));
    directions=(double *)malloc(N*N*sizeof(double));


    if ( (!Vtry) || (!Vinitial) || (!directions) )
        goto END;

    //set scales to 1 if not set
    if (!Scale)
        for (direction=0; direction<N; direction++)
            scale[direction]=1.0;

    //------------Set the inital directions to be each dimension---------
    memset(directions,0,sizeof(double)*N*N);
    for (i=0; i<N; i++)
        {
            directions[i+i*N]=scale[i];
        }


    count=0;
    Ebest=Get_Error(Vbest, N, H);
    do
        {

            del=0.0;
            Einit=Ebest;
            memcpy(Vinitial,Vbest,sizeof(double)*N);
            bestdir=-1;
            for (direction=0; direction<N; direction++)
                {
                    //optimise along this direction
                    E=Ebest;

                    Ebest=GoldenSearch(Vbest, &directions[direction*N], N, E, Get_Error, H, 30);

                    if ((E-Ebest) > del)
                        {
                            del=E-Ebest;
                            bestdir=direction;
                        }

                    /*fp=fopen("c:\\temp\\Powell.txt","a");
                      if (fp)
                      {
                          fprintf(fp,"\n%d %d %f %f\n",direction,bestdir,E,Ebest);
                          fclose(fp);
                      }*/


                }//for(direction...



            //now remove the direction that was best in the previous optimisation
            //and put the average direction moved in the previous iteration in last place in the direction set
            if ((bestdir>=0) )
                {
                    if (bestdir<N-1)
                        memcpy(&directions[bestdir*N],&directions[(bestdir+1)*N],sizeof(double)*N*(N-bestdir-1));

                    normalise=1.0;
                    for (i=0; i<N; i++)
                        {
                            if (fabs(scale[i])>0.0)
                                {
                                    if (fabs((Vbest[i]-Vinitial[i])/scale[i])>normalise)
                                        normalise = fabs((Vbest[i]-Vinitial[i])/scale[i]);
                                }
                        }
                    for (i=0; i<N; i++)
                        {
                            directions[i+(N-1)*N]=(Vbest[i]-Vinitial[i])/normalise;//difference between initial and current
                        }
                    //optimise in this best direction
                    Ebest=GoldenSearch(Vbest, &directions[direction*N], N, Ebest, Get_Error, H, 30);

                }


            if (count>N)
                {
                    memset(directions,0,sizeof(double)*N*N);
                    for (i=0; i<N; i++)
                        {
                            directions[i+i*N]=scale[i];
                        }
                    count=0;
                }

            count++;
        }
    while((bestdir>=0) && ((Einit-Ebest)/fabs(Ebest)>tol));



END:
    if (Vtry)
        free(Vtry);

    if (Vinitial)
        free(Vinitial);

    if (directions)
        free(directions);

    return Ebest;

}

//======================================================================================
//nonlinear function with minima at 1,2,3
//======================================================================================
double TestErrorFunctionForminimisation(double *x, int N, void *na)
{
    return (x[0]-1.0)*(x[0]-1.0) + (x[1]-2.0)*(x[1]-2.0) + (x[2]-3.0)*(x[2]-3.0);// + 0.1*(x[0]-3.0)*(x[1]-3.0);
}
//==============================================================================
int TestPowell(void)
{
    double x[3]= {10.0, 35.0, -7.0};
    double scale[3]= {1.0, 1.0, 1.0};
    double a;
    char txt[256];


    x[0]=(double)50.0*rand()/RAND_MAX;
    x[1]=(double)50.0*rand()/RAND_MAX;
    x[2]=(double)50.0*rand()/RAND_MAX;

    PowellMinimisation(x, 3, scale, 1, TestErrorFunctionForminimisation, &a, 1.0e-4);

    sprintf(txt,"%f %f %f",x[0],x[1],x[2]);
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}








//==============================================================================
//if fa, fb, and fc are the values at points a, b, and c respectively
//fit a quadratic through the points and return the minimum/maximum point
//from Numerical recipes, page 402 (parabolic interpolation and Brents method)
//==============================================================================
double QuadraticExtrema(double a, double b, double c, double fa, double fb, double fc)
{
    /**
     * if fa, fb, and fc are the values at points a, b, and c respectively
     * fit a quadratic through the points and return the minimum/maximum point
     * from Numerical recipes, page 402 (parabolic interpolation and Brents method)
     *
     *
     */

    double n,d;

    n=(b-a)*(b-a)*(fb-fc) - (b-c)*(b-c)*(fb-fa);
    d=(b-a)*(fb-fc) - (b-c)*(fb-fa);

    //if (!d) return 0.0;
    //else return b-0.5*n/d;

    if (fabs(d)>0.0)
        return b-0.5*n/d;

    else
        return 0.0;
}





//==============================================================================
//Numerical integration using Simpson's rule
//I~h*(f(a) + 4f( (a+b)/2 ) + f(b))/3 where h=(b-a)/2 the midpoint
//*H contains data to inform the function evaluations
//Use Simpsons rule with interval h and 2h and make sure they converge
//==============================================================================
double Integrate(double A, double B, int maxevaluations, double err, double (*f)(double, void *), void *H)
{
    double I=0.0;
    double S1,S2;
    double *a=NULL;
    double *b=NULL;
    double *m=NULL;
    double *fa=NULL;
    double *fb=NULL;
    double *fm=NULL;
    double h,lm,rm,flm,frm,e;
    double smallh;
    double bigh=(B-A)/10;//dont want to stop while h is too big
    int current=0;
    int upto=0;
    //FILE *fp=NULL;

    //fp=fopen("c:\\temp\\integrate.csv","w");


    if (maxevaluations<=0)
        goto END;
    smallh=(B-A)/(maxevaluations-1);//dont want to go too small in h.

    if (!(a=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;
    if (!(b=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;
    if (!(m=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;
    if (!(fa=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;
    if (!(fb=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;
    if (!(fm=(double *)malloc(maxevaluations*sizeof(double))))
        goto END;

    a[0]=A;
    b[0]=B;
    m[0]=(A+B)/2;
    fa[0]=f(A,H);
    fb[0]=f(B,H);
    fm[0]=f(m[0],H);

    //if (fp) fprintf(fp,"%f,%f\n",A,fa[0]);
    //if (fp) fprintf(fp,"%f,%f\n",B,fb[0]);
    //if (fp) fprintf(fp,"%f,%f\n",m[0],fm[0]);
    do
        {
            lm=(a[current]+m[current])/2.0;///left midpoint
            rm=(m[current]+b[current])/2.0;///right midpoint
            h=(m[current]-a[current])/2.0;///the step size
            flm=f(lm,H);
            frm=f(rm,H);

            S2=h*(fa[current] + 4.0*flm + fm[current] + fm[current] + 4.0*frm + fb[current])/3;//Simpson's x2
            S1=2.0*h*(fa[current] + 4.0*fm[current] + fb[current])/3;//Simpsons x1

            e=fabs(S2-S1);

            //if (fp) fprintf(fp,"%d,%d,%f,%f,%f,%f,%f\n",current,upto,a[current],b[current],m[current],fm[current],e);

            if (h<=smallh)//h has got too small so add to the integral
                {
                    I+=S2 + (S2-S1)/15;
                }
            else if ( (upto<maxevaluations-2) && ((h>bigh) || (e>err && h<bigh)) )//h is too big to risk
                {
                    upto++;
                    a[upto]=a[current];
                    b[upto]=m[current];
                    m[upto]=lm;
                    fa[upto]=fa[current];
                    fb[upto]=fm[current];
                    fm[upto]=flm;

                    upto++;
                    a[upto]=m[current];
                    b[upto]=b[current];
                    m[upto]=rm;
                    fa[upto]=fm[current];
                    fb[upto]=fb[current];
                    fm[upto]=frm;
                }
            else
                I+=S2 + (S2-S1)/15;

            current++;

        }
    while ((current<=upto) && (upto<maxevaluations));

    //if (fp) fprintf(fp,"%d,%d,%d\n",current,upto,maxevaluations);

END:
    if (a)
        free(a);

    if (b)
        free(b);

    if (m)
        free(m);

    if (fa)
        free(fa);

    if (fb)
        free(fb);

    if (fm)
        free(fm);
    //if (fp) fclose(fp);

    return I;
}
double TestIntegral(double x, void *H)
{
    return dNorm(x, 2.0, 0.1);
}
int TestIntegrate(void)
{
    int H;
    double I=Integrate(-5.0,7.0,500,1.0e-4,TestIntegral,&H);
    char txt[256];
    sprintf(txt,"%f",I);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}


//==============================================================================
//initialise the scale for nonlinear optimisation
//target is the error difference in each direction if moved by scale
//==============================================================================
int ScaleInitialisation(double P0[], int N, double target, double scale[], double (*GetError)(double *, int, void *), void *H)
{

    int result=0;
    int n,i;
    double Err0;
    double *P=NULL;
    double d;
    double MaxScale;
    double ratio;

    if (!(P=(double *)malloc(N*sizeof(double))))
        goto END;

    MaxScale=0.0;
    for (n=0; n<N; n++)
        {
            if (fabs(scale[n])>MaxScale)
                MaxScale=fabs(scale[n]);
        }
    if (MaxScale<=0.0)
        MaxScale=1.0;

    Err0 = GetError(P0, N, H);



    memcpy(P,P0,sizeof(double)*N);
    for (n=0; n<N; n++)
        {
            if (fabs(scale[n])<=0.0)
                scale[n]=MaxScale;

            i=1;
            do
                {
                    P[n] += scale[n];
                    d = GetError(P,N,H)-Err0;
                    P[n] -= scale[n];

                    if (fabs(d)>0.0)
                        ratio = fabs(target/d);
                    else
                        ratio=1.0;
                    scale[n] *= ratio;
                    i++;
                }
            while(fabs(ratio-1)<0.1 && (i<5));
        }


    result=1;
END:
    if (P)
        free(P);

    return result;
}

//==============================================================================
//              Downhill Simplex
//works by finding the worst error in a set that forms the simplex
//then trying to get rid of it
//if no scale provided, set all scales equal
//fabs(Err[ibest]-Err[iworst])/(fabs(Err[ibest])+fabs(Err[iworst])+DBL_MIN)>tol
//==============================================================================
double DownHillSimplex(double P[], int N, double scale[], int Scale,
                       double (*GetError)(double *, int, void *), void *H, int Nshrinks)
{

    double error=0.0;
    double *V=NULL;                      //store the N+1 vectors in rows
    double *change=NULL;                 //this is the direction to try changing the worst vector by
    double *Vav=NULL;                    //average vector, except for the worst point
    double *Vref=NULL;                   //this is the reflection vector
    double *Vexp=NULL;                   //this is the expansion vector
    double *Vcon=NULL;                   //this is the contraction vector
    double *Err;                    //the error for each vector
    double Eref,Eexp,Econ;
    int i;
    int vectN,iworstN,ibestN;
    int Fev=0;                      //count the function evaluations
    int vect;
    int ibest, iworst, i2ndworst;
    int shrinkage=0;                      //how many times the simplex has been shrunk
    int count=0;
    //char fname[MAX_PATH];
    //FILE *fp=NULL;

    //sprintf(fname,"%s/DHsimplex.csv",REPORT_FOLDER);
    //fp=fopen(fname,"a");


    if (N<=0)
        return 0.0;

    V=(double *)malloc((N+1)*N*sizeof(double));
    change=(double *)malloc(N*sizeof(double));
    Vav=(double *)malloc(N*sizeof(double));
    Vref=(double *)malloc(N*sizeof(double));
    Vexp=(double *)malloc(N*sizeof(double));
    Vcon=(double *)malloc(N*sizeof(double));
    Err=(double *)malloc((N+1)*sizeof(double));

    if ((!V) || (!change) || (!Vav) || (!Err) || (!Vref) || (!Vexp) || (!Vcon))
        goto END;



//if no scale provided, set all scales equal
    if (!Scale)
        for (vect=0; vect<N; vect++)
            scale[vect]=1.0;


//define the simplex
    for (vect=0; vect<N; vect++)
        {
            memcpy(&V[vect*N], P, N*sizeof(double));
            V[vect + vect*N]+=scale[vect];
        }
    memcpy(&V[N*N], P, N*sizeof(double));//the initialisation point given to the function


//get all the errors
    Err[N]=GetError(&V[N*N], N, H);
    ibest=iworst=N;
    for (vect=0; vect<N; vect++)
        {
            Err[vect]=GetError(&V[vect*N], N, H);
            if (Err[vect]<Err[ibest])
                ibest=vect;
            if (Err[vect]>Err[iworst])
                iworst=vect;

        }
    i2ndworst=ibest;
    for (vect=0; vect<=N; vect++)
        {
            if ((vect!=iworst) && (Err[vect]>Err[i2ndworst]) && (Err[vect]<=Err[iworst]))
                i2ndworst=vect;
        }


//NOW OPTIMISE
    do
        {

            ///compute the average vector not including the worst
            memset(Vav, 0, sizeof(double)*N);
            for (vect=0; vect<=N; vect++)
                {
                    if (vect!=iworst)
                        {
                            vectN=vect*N;
                            for (i=0; i<N; i++)
                                {
                                    Vav[i]+=V[i+vectN];
                                }
                        }
                }
            for (i=0; i<N; i++)
                Vav[i]/=N;


            //compute change direction
            iworstN=iworst*N;
            for (i=0; i<N; i++)
                change[i]=Vav[i]-V[i+iworstN]; //adding change to Vav would reflect the worst point through Vav


            //reflect the worst point through Vav
            for (i=0; i<N; i++)
                Vref[i]=Vav[i]+change[i]; //adding change reflects the highest point about the average
            Eref=GetError(Vref, N, H);
            Fev++;

            //if that is better than the best point, try an expansion
            if (Eref<Err[ibest])
                {
                    //try an expansion of that reflection
                    for (i=0; i<N; i++)
                        Vexp[i]=Vav[i]+2.0*change[i]; //adding 2.0*change expands the reflection
                    Eexp=GetError(Vexp, N, H);
                    Fev++;

                    //if this is better than Eref (the reflected error) then this is the solution for this iteration
                    if (Eexp<Eref)
                        {
                            memcpy(&V[iworst*N], Vexp, sizeof(double)*N);
                            Err[iworst]=Eexp;
                        }
                    else
                        {
                            memcpy(&V[iworst*N], Vref, sizeof(double)*N);
                            Err[iworst]=Eref;
                        }
                }
            else if (Eref<Err[i2ndworst])
                {
                    memcpy(&V[iworst*N], Vref, sizeof(double)*N);
                    Err[iworst]=Eref;
                }
            else
                {
                    for (i=0; i<N; i++)
                        Vcon[i]=Vav[i]+change[i]/2; //adding change/2 contracts the highest point toward the average
                    Econ=GetError(Vcon, N, H);
                    Fev++;
                    if (Econ<Err[iworst])
                        {
                            memcpy(&V[iworst*N], Vcon, sizeof(double)*N);
                            Err[iworst]=Econ;
                        }
                    else
                        {
                            //do compression
                            ibestN=ibest*N;
                            for (vect=0; vect<=N; vect++)
                                {
                                    if (vect!=ibest)
                                        {
                                            vectN=vect*N;
                                            for (i=0; i<N; i++)
                                                {
                                                    V[i+vectN]=V[i+vectN]+(V[i+ibestN]-V[i+vectN])/2.0;
                                                }
                                            Err[vect]=GetError(&V[vectN], N, H);
                                            Fev++;
                                        }
                                }
                            shrinkage++;
                        }
                }



//sort the best, 2nd worst, and worst errors
            iworst=ibest=0;
            for (vect=1; vect<=N; vect++)
                {
                    if (Err[vect]<Err[ibest])
                        ibest=vect;
                    if (Err[vect]>Err[iworst])
                        iworst=vect;

                }
            i2ndworst=ibest;
            for (vect=0; vect<=N; vect++)
                {
                    if ((vect!=iworst) && (Err[vect]>Err[i2ndworst]) && (Err[vect]<=Err[iworst]))
                        i2ndworst=vect;
                }

            /*if (fp)
            {
                fprintf(fp,"%d,%f,%f",count,Err[ibest],Err[iworst]);
                for (i=0;i<N;i++)
                {
                    fprintf(fp,",%f,%f",V[i+ibest*N],V[i+iworst*N]);
                }
                fprintf(fp,"\n");
            }*/

            count++;
        }
    while ((double)(shrinkage)<Nshrinks && fabs(Err[ibest]-Err[iworst])/(fabs(Err[ibest])+fabs(Err[iworst])+DBL_MIN)>2*DBL_MIN && (count<1000));

    memcpy(P, &V[ibest*N], sizeof(double)*N);

//char txt[256];
//sprintf(txt,"Error function evaluations=%d",Fev);
//MessageBox(NULL,txt,"",MB_OK);

    error=Err[ibest];
END:
//    if (fp) fclose(fp);
    if (V)
        free(V);

    if (change)
        free(change);

    if (Vav)
        free(Vav);

    if (Vref)
        free(Vref);

    if (Vexp)
        free(Vexp);

    if (Vcon)
        free(Vcon);

    if (Err)
        free(Err);
    return error;
}

























//==============================================================================
//  Fit a straight line to data
//  return the R^2 value for the fit
//==============================================================================
double StraightLineFit(double x[], double y[], int N, double *mu, double *beta)
{

    double sumx, sumy, sumx2, sumy2, sumxy;
    double Sxx, Syy, Sxy;
    double xmean, ymean;
    int n;

    sumx=sumy=0.0;
    sumx2=sumy2=0.0;
    sumxy=0.0;
    for (n=0; n<N; n++)
        {
            sumx+=x[n];
            sumy+=y[n];

            sumx2+=x[n]*x[n];
            sumy2+=y[n]*y[n];

            sumxy+=x[n]*y[n];
        }

    xmean=sumx/N;
    ymean=sumy/N;

    Sxx=sumx2-N*xmean*xmean;
    Syy=sumy2-N*ymean*ymean;
    Sxy=sumxy-N*xmean*ymean;

    if ((Sxx>0.0) && (Syy>0.0))
        {
            (*beta)=Sxy/Sxx;
            (*mu)=ymean-(*beta)*xmean;

            return Sxy*Sxy/Sxx/Syy;
        }
    else
        {
            (*mu)=(*beta)=0.0;
            return 0.0;
        }

}





//==============================================================================
//Given a matrix M, of c columns and r rows (c<=r), and the r knowns, find the c<=r unknowns
//b contains the knowns on input (not on exit)
//x are the r unknowns on exit. They can be anything on entry
//M is unchanged on exit
//==============================================================================
int LeastSquaresFitting(double M[], double b[], double x[], int c, int r)
{

    double *SM=NULL;
    int row,col,j;
    double Xn,Yn,XYn,X2n,Y2n;
    double a;
    int result=0;

    if (c==1)
        {
            Xn=Yn=XYn=X2n=Y2n=0.0;
            for (row=0; row<r; row++)
                {
                    Xn+=M[row]/r;
                    Yn+=b[row]/r;
                    XYn+=M[row]*b[row]/r;
                    X2n+=M[row]*M[row]/r;
                    Y2n+=b[row]*b[row]/r;
                }
            a=X2n-Xn*Xn;
            if ( fabs(a)>0.0 )
                {
                    x[0]=(XYn-Xn*Yn)/a;
                    return 1;
                }
            else
                {
                    x[0]=0.0;
                    return 0;
                }
        }


    SM=(double *)malloc(c*c*sizeof(double));


    if (SM)
        {
            //multiply the knowns and the matrix M by the transpose of the matrix M
            memset(SM,0,c*c*sizeof(double));
            memset(x,0,sizeof(double)*c);
            for (col=0; col<c; col++)
                {
                    for (j=0; j<r; j++)
                        x[col]+=M[col+j*c]*b[j];
                    for (row=0; row<c; row++)
                        {
                            for (j=0; j<r; j++)
                                SM[col+row*c]+=M[row+j*c]*M[col+j*c];
                        }
                }

            result=SimultaneousEquationSolverPivoting(SM, x, c);

            free(SM);
        }
    else
        return 0;

    return result;
}





//==============================================================================
//V contains matrix elements in COLUMN order. V is nxn square
//b is initially from Vx=b. After it b=x, the solution.
//n is the length of vector b and rows of matrix V
//Uses row exchange to help stability
//==============================================================================
int SimultaneousEquationSolverPivoting(double V[], double b[], int n)
{

    /**
     * V contains matrix elements in COLUMN order. V is nxn square
     *  b is initially from Vx=b. After it b=x, the solution.
     *  n is the length of vector b and rows of matrix V
     *  Uses row exchange to help stability
     *
     */

    int row, col, currentrow;
    int i,j,ibiggest;
    int result=0;
    double *scales=NULL,tmp;
    double pivot, biggest, alpha, sum;

    if (!(scales=(double *)malloc(n*sizeof(double))))
        goto END;


    for (i=0; i<n; i++)
        {
            scales[i]=0.0;
            for (j=0; j<n; j++)
                {
                    if ((tmp=fabs(V[j+i*n]))>scales[i])
                        scales[i]=tmp;
                }
            if (scales[i]<=0.0)
                {
                    free(scales);
                    goto END;
                }
        }

    //---------------Gaussian elimination----------------
    for (currentrow=0; currentrow<n-1; currentrow++)
        {


            //locate the best (biggest) pivot
            biggest=V[currentrow+n*currentrow]/scales[currentrow];
            ibiggest=currentrow;
            for (i=currentrow+1; i<n; i++)
                {
                    if ((tmp=fabs(V[i+n*i]/scales[i]))>biggest)
                        {
                            ibiggest=i;
                            biggest=tmp;
                        }
                }


            //row exchange if there is a better pivot
            //row exchanges dont change the ordering of the unknowns
            if (ibiggest!=currentrow)
                {
                    for (i=currentrow; i<n; i++)
                        {
                            tmp=V[i+ibiggest*n];
                            V[i+ibiggest*n]=V[i+currentrow*n];
                            V[i+currentrow*n]=tmp;
                        }
                    tmp=b[ibiggest];
                    b[ibiggest]=b[currentrow];
                    b[currentrow]=tmp;

                    tmp=scales[ibiggest];
                    scales[ibiggest]=scales[currentrow];
                    scales[currentrow]=tmp;
                }

            pivot=V[currentrow+n*currentrow];
            if (fabs(pivot)>0.0)
                {
                    for (row=currentrow+1; row<n; row++)
                        {
                            alpha=V[n*row+currentrow]/pivot;
                            for (col=currentrow; col<n; col++)
                                {
                                    V[n*row+col]-=alpha*V[n*currentrow+col];
                                }
                            b[row]-=alpha*b[currentrow];
                        }
                }
            else
                goto END;

        }



    //----------------Back substitution----------------
    for (row=n-1; row>=0; row--)
        {
            sum=0.0;
            for (col=row+1; col<n; col++)
                sum+=V[n*row+col]*b[col];
            if (fabs(V[n*row+row])>0.0)
                b[row]=(b[row]-sum)/V[n*row+row];
            else
                goto END;
            if (isnan(b[row]))
                goto END;
        }

    result=1;
END:

    if (scales)
        free(scales);

    return result;
}



//==============================================================================
//LU is NxN matrix to be factorised
//Uses Crout's procedure
//The diagonals of L are not stored but are equal to 1
// (*d) is either 1 or -1 on exit, depending if there are an even or odd number
//  of row permutations
//index[] is an indicator of the row permutations on exit
int CheckLUfactorisation(double *Original, double *LU, int N, int index[]);
//==============================================================================
int LUfactorisationWithPivoting(double LU[], int N, int index[], double *d)
{

    int row,col,k,kN;
    double dum;
    double *scale=NULL,biggest;
    //double *Original=NULL;
    double sum;
    int bigrow,bigrowN;
    int result=0;
    int rowN, colN;

    //Original=(double *)malloc(sizeof(double)*N*N);
    //if (Original) memcpy(Original, LU, sizeof(double)*N*N);


    if (!(scale=(double *)malloc(N*sizeof(double))))
        return 0;

    //no row permutations initially
    *d=1.0;

    //find the scale for each row. The scale is the largest entry in the row.
    rowN=0;
    for (row=0; row<N; row++)
        {
            index[row]=row;
            scale[row]=0.0;
            for (col=0; col<N; col++)
                if ((dum=fabs(LU[col+rowN]))>scale[row])
                    scale[row]=dum;
            if (scale[row]<=0.0)
                goto END;

            rowN+=N;
        }

    colN=0;
    for (col=0; col<N; col++)
        {

            //LU FACTORISATION WORKS DOWN EACH COLUMN IN TURN
            //REPLACING THE ORIGINAL MATRIX ELEMENTS WITH THE LU ELEMENTS

            //row<=col equations (find U[row,col])
            rowN=0;
            for (row=0; row<=col; row++)
                {
                    sum=LU[col+rowN];
                    kN=0;
                    for (k=0; k<row; k++)
                        {
                            sum-=(LU[k+rowN])*(LU[col+kN]);
                            kN += N;
                        }
                    LU[col+rowN]=sum;
                    //for (k=0;k<row;k++)	LU[col+row*N]-=LU[k+row*N]*LU[col+k*N];
                    rowN += N;
                }



            //row>col equations (find L[row,col])
            biggest=fabs(LU[col+colN])/scale[col];
            bigrow=col;
            rowN=N*(col+1);
            for (row=col+1; row<N; row++)
                {
                    sum=LU[col+rowN];
                    kN=0;
                    for (k=0; k<col; k++)
                        {
                            sum-=(LU[k+rowN])*(LU[col+kN]);
                            kN += N;
                        }
                    LU[col+rowN]=sum;
                    //for (k=0;k<col;k++)	LU[col+row*N]-=LU[k+row*N]*LU[col+k*N];
                    if ( (dum=fabs(LU[col+rowN])/scale[row])>biggest )
                        {
                            biggest=dum;
                            bigrow=row;
                        }
                    rowN += N;
                }

            //Now do row permutations
            if (bigrow>col)
                {
                    //permute the row
                    bigrowN=bigrow*N;
                    for (k=0; k<N; k++)
                        {
                            dum=LU[k+colN];
                            LU[k+colN]=LU[k+bigrowN];
                            LU[k+bigrowN]=dum;
                        }
                    //permute the scale
                    dum=scale[col];
                    scale[col]=scale[bigrow];
                    scale[bigrow]=dum;
                    //permute the index
                    k=index[col];
                    index[col]=index[bigrow];
                    index[bigrow]=k;
                    //change sign of (*d)
                    (*d)=-(*d);
                }

            //now complete the equations for col>row by division by pivot
            dum=LU[col+colN];
            if (fabs(dum)>0.0)
                {
                    if (col<(N-1))
                        {
                            rowN = N*(col+1);
                            for (row=col+1; row<N; row++)
                                {
                                    LU[col+rowN]/=dum;
                                    rowN += N;
                                }
                        }
                }
            else
                goto END;//matrix singular

            colN += N;
        }
    result=1;


    //if (Original){
    //    CheckLUfactorisation(Original, LU, N, index);
    //    free(Original);
    //}

END:

    if (scale)
        free(scale);

    return result;

}
//==============================================================================
int CheckLUfactorisation(double *Original, double *LU, int N, int index[])
{

    FILE *fp;
    int row,col,k;
    double L,U;
    double *P=NULL;
    double det=1.0;
    char txt[256];

    for (k=0; k<N; k++)
        det*=LU[k+k*N];
    sprintf(txt,"%g",det);
    MessageBox(NULL,txt,"",MB_OK);

    if (!(P=(double *)malloc(N*N*sizeof(double))))
        return 0;
    for (row=0; row<N; row++)
        {
            for (col=0; col<N; col++)
                {
                    P[col+row*N]=Original[col+index[row]*N];
                }
        }
    memcpy(Original, P, sizeof(double)*N*N);
    free(P);


    if (!(fp=fopen("c:/temp/LUtest.txt","w")))
        return 0;

    for (row=0; row<N; row++)
        {
            for (col=0; col<N; col++)
                {
                    for (k=0; k<N; k++)
                        {
                            L=0.0;
                            if (k<row)
                                {
                                    L=LU[k+row*N];
                                }
                            else if (k==row)
                                {
                                    L=1.0;
                                }

                            U=0.0;
                            if (k<=col)
                                U=LU[col+k*N];

                            Original[col+row*N]-=L*U;
                        }
                    fprintf(fp,"%f ",Original[col+row*N]);
                }
            fprintf(fp,"\n");
        }



    fclose (fp);


    return 1;
}




//==============================================================================
//Cholesky
//https://en.wikipedia.org/wiki/Cholesky_decomposition
//Given square, positive definite, real, matrix A
//compute L such that L^t*L=A and L is a lower triangle matrix
//==============================================================================
int Cholesky(double A[], int N, double L[])
{
    int row,col;
    int k;
    int diagonal;
    int colN,rowN;
    double sum;

    memset(L,0,sizeof(double)*N*N);

    for (col=0; col<N; col++)
        {
            colN=col*N;
            diagonal=colN + col;
            sum=0.0;
            for (k=0; k<col; k++)
                sum += L[colN + k]*L[colN + k];
            if (A[diagonal]>sum)
                L[diagonal] = sqrt(A[diagonal]-sum);
            else
                return 0;//the diagonal of L must be > 0.0 because the off diagonal elements are scaled by it
            for (row=col+1; row<N; row++)
                {
                    rowN=row*N;
                    sum=0.0;
                    for (k=0; k<row; k++)
                        sum += L[colN + k]*L[k + rowN];
                    L[col+rowN] = (A[col+rowN] - sum)/L[diagonal];
                }
        }

    return 1;
}
int TestCholesky(void)
{
    double A[9]= {4.0,12.0,-16.0,12.0,37.0,-43.0,-16.0,-43.0,98.0}; //example from wikipedia
    double L[9];
    char txt[256];
    int i,j;

    Cholesky(A,3,L);

    txt[0]='\0';

    for (i=0; i<3; i++)
        {
            for (j=0; j<3; j++)
                {
                    sprintf(txt,"%s\t%f",txt,L[i*3+j]);
                }
            sprintf(txt,"%s\n",txt);
        }
    MessageBox(NULL,txt,"",MB_OK);

    return 0;
}







//==============================================================================
//                  Compute the determinant of a matrix A
//                  Determinant given by product of diagonals of LU factorised matrix
//                  from its LU decomposition
//                  n is the size of the matrix (number of columns/rows)
//                  returns the LU decomposition of A in A
//                  returns the determinant of A
//==============================================================================
double Determinant(double A[], int n)
{

    int *index;
    double d, det;

    if (!(index=(int *)malloc(n*sizeof(int))))
        return 0;

    det=DeterminantEx(A, n, index, &d);

    if (index)
        free(index);

    return det;
}


//==============================================================================
//                  Compute the determinant of a matrix A
//                  Determinant given by product of diagonals of LU factorised matrix
//                  from its LU decomposition
//                  n is the size of the matrix (number of columns/rows)
//                  returns the LU decomposition of A in A
//                  returns the determinant of A
//==============================================================================
double DeterminantEx(double A[], int n, int index[], double *d)
{

    int i;
    long double det;

    if (!LUfactorisationWithPivoting(A, n, index, d))
        {
            return 0.0;
        }

    det=(long double)(*d);
    for (i=0; i<n; i++)
        det*=(long double)A[i+i*n];

    return (double)det;
}



//==============================================================================
//Test the Determinant and LU algorithms
//==============================================================================
int TestLU(void)
{

    int N=8;
    double A[100],B[100], C[100];
    double L,U;
    double d;
    int row,col,k, iter;
    int index[5];
    char txt[1024];

    for (iter=0; iter<10; iter++)
        {
            //assign values randomly to the elements of A[]
            txt[0]='\0';
            for (row=0; row<N; row++)
                {
                    for (col=0; col<N; col++)
                        {
                            A[col+row*N]=(double)rand()/RAND_MAX;
                            //if (col==row) A[col+col*N]+=10.0;
                            B[col+row*N]=A[col+row*N];
                            sprintf(txt,"%s %f",txt,A[col+row*N]);
                        }
                    sprintf(txt,"%s\n",txt);
                }
            //MessageBox(NULL,txt,"before",MB_OK);

            LUfactorisationWithPivoting(A, N, index, &d);

            //show the LU decomposition
            txt[0]='\0';
            for (row=0; row<N; row++)
                {
                    for (col=0; col<N; col++)
                        {
                            sprintf(txt,"%s %f",txt,A[col+row*N]);
                        }
                    sprintf(txt,"%s\n",txt);
                }
            //MessageBox(NULL,txt,"before",MB_OK);

            //reconstruct the original matrix from the LU decomposition
            txt[0]='\0';
            for (row=0; row<N; row++)
                {
                    for (col=0; col<N; col++)
                        {
                            C[col+row*N]=-B[col+index[row]*N];//negative of the original matrix
                            for (k=0; k<N; k++)
                                {
                                    L=0.0;
                                    if (k<row)
                                        {
                                            L=A[k+row*N];
                                        }
                                    else if (k==row)
                                        {
                                            L=1.0;
                                        }

                                    U=0.0;
                                    if (k<=col)
                                        U=A[col+k*N];

                                    C[col+row*N]+=L*U;
                                }
                            sprintf(txt,"%s %f",txt,C[col+row*N]);
                        }
                    sprintf(txt,"%s\n",txt);
                }
            MessageBox(NULL,txt,"difference",MB_OK);

        }//iter

    return 1;
}




//==============================================================================
//do simple linear regression
//fit y=a + bx
//return R^2
//return the parameters, and p values
//https://en.wikipedia.org/wiki/Simple_linear_regression
//==============================================================================
double SimpleLinearRegression(double y[], double x[], int N, double *a, double *b, double *pa, double *pb)
{
    int i;
    double meanx, meany, meanx2, meany2, meanxy;
    double R2=0.0;
    double SSR,varx,vary;
    double residual;
    double ta,tb;
    if (N<=2)
        return 0.0;

    meanx=meany=meanx2=meany2=meanxy=0.0;
    for (i=0; i<N; i++)
        {
            meanx+=x[i];
            meany+=y[i];
            meanx2+=x[i]*x[i];
            meany2+=y[i]*y[i];
            meanxy+=x[i]*y[i];
        }
    meanx/=N;
    meany/=N;
    meanx2/=N;
    meany2/=N;
    meanxy/=N;

    varx=meanx2-meanx*meanx;
    vary=meany2-meany*meany;
    if ((varx>0.0) && (vary>0.0))
        {
            (*b)=(meanxy-meanx*meany)/varx;
            (*a)=meany - (*b)*meanx;


            R2=0.0;
            SSR=0.0;
            for (i=0; i<N; i++)
                {
                    residual=(y[i]-((*a)+(*b)*x[i]));
                    SSR+=residual*residual;
                }
            R2=1.0-SSR/N/vary;

            tb=(*b)/sqrt(SSR/(N-2)/(varx*N));
            (*pb)=TwoSidedTtest(tb, N-2);
            ta=(*a)/sqrt(SSR/N/(N-2)*meanx2/varx);
            (*pa)=TwoSidedTtest(ta, N-2);

        }
    else
        return 0.0;

    return R2;
}
//==============================================================================
int TestSimpleLinearRegression(void)
{
    int i;
    double x[10];
    double y[10];
    double a,b,pa,pb;
    char txt[256];
    for (i=0; i<10; i++)
        {
            x[i]=(double)i;
            y[i]=10.0+(double)i + GaussRandomNumber_BoxMuller(0.0,2.5);
        }
    SimpleLinearRegression(y, x, 10, &a, &b, &pa, &pb);


    FILE *fp=NULL;
    if ((fp=fopen("c:\\temp\\LMtest.txt","w")))
        {
            fprintf(fp,"x y\n");
            for (i=0; i<10; i++)
                {
                    fprintf(fp,"%f %f\n",x[i],y[i]);
                }
            fclose(fp);
        }

    sprintf(txt,"%f %f %f %f",a,b,pa,pb);
    MessageBox(NULL,txt,"",MB_OK);

    return 0;
}


//==============================================================================
//given the LU matrix, solve for unknowns x with knowns b
//there is row permutation (stored in index) from the LU routine with pivoting
//==============================================================================
int SolveLUsystem(double LU[], int N, double x[], double b[], int index[])
{

    int row,col,istart=-1;
    int rowN;
    double *y, tmp;

    if (!(y=(double *)malloc(N*sizeof(double))))
        return 0;

    //undo the row permutations
    //index indicates exactly how the equations have been rearranged, and therefore how the knowns (b) should be rearranged
    //the unknowns, of course, are still in the correct order since they cant be rearranged (no column exchanges)
    for (row=0; row<N; row++)
        x[row]=b[index[row]];
    memcpy(b,x,sizeof(double)*N);


    rowN=0;
    for (row=0; row<N; row++)
        {
            y[row]=b[row];
            if (istart>-1)
                {
                    for (col=istart; col<row; col++)
                        y[row]-=LU[col+rowN]*y[col];
                }
            else if (istart==-1 && (fabs(y[row])>0.0))
                istart=row;
            rowN += N;
        }


    for (row=N-1; row>=0; row--)
        {
            rowN=row*N;
            x[row]=y[row];
            tmp=0.0;
            for (col=N-1; col>row; col--)
                {
                    tmp+=(LU[col+rowN])*(x[col]);
                    //x[row]-=LU[col+row*N]*x[col];
                }
            x[row]-=tmp;
            if (fabs(LU[row+rowN])>0.0)
                x[row]/=LU[row+rowN];
            else
                return 0;
        }

    free(y);
    return 1;
}







//==============================================================================
//inverts the matrix M
//uses LUfactorisation with pivoting to reduce rounding error and make more stable
//M and LU are NxN matrices
//V is a vector of length N
//x is a vector length N
//index has length N
//All vectors are supplied so that if this routine is called a lot, dont need
//to keep malloc-ing
//If not calling repeatedly use InvertMatrixA
//==============================================================================
int InvertMatrix(double M[], double LU[], double V[], double x[], int index[], int N)
{

    int coloumn,i;
    double d;

    if (N==2 || N==3)
        {
            //if the matrix is 2x2 or 3x3, do the inverse analytically
            return Inverse2x2OR3x3Matrix(M,N);
        }


    memcpy(LU,M,sizeof(double)*N*N);

    if (!LUfactorisationWithPivoting(LU, N, index, &d))
        return 0;

    for (coloumn=0; coloumn<N; coloumn++)
        {
            memset(V,0,sizeof(double)*N);
            V[coloumn]=1.0;
            if (!SolveLUsystem(LU, N, x, V, index))
                return 0;
            for (i=0; i<N; i++)
                M[i+coloumn*N]=x[i];
        }

    return 1;
}



//==============================================================================
//invert matrix M (NxN)
//==============================================================================
int InvertMatrixA(double M[], int N)
{

    double *LU, *V, *x;
    int *index;
    int result=0;


    if (N==2 || N==3)
        {
            //if the matrix is 2x2 or 3x3, do the inverse analytically
            return Inverse2x2OR3x3Matrix(M,N);
        }


    LU=(double *)malloc(N*N*sizeof(double));
    V=(double *)malloc(N*sizeof(double));
    x=(double *)malloc(N*sizeof(double));
    index=(int *)malloc(N*sizeof(int));

    if (LU && V && x && index)
        result=InvertMatrix(M, LU, V, x, index, N);

    if (LU)
        free(LU);

    if (V)
        free(V);

    if (x)
        free(x);

    if (index)
        free(index);

    return result;
}





//==============================================================================
//          compute the psuedo inverse (M^tM)^(-1)M^t of matrix M
//          M is replaced by its TRANSPOSED psuedo inverse on return
//==============================================================================
int PsuedoInverse(double M[], int rows, int cols)
{

    double *I=NULL, *tmp=NULL;
    int r,c,i;
    int result=0;
    int rcols,icols;


    if (rows<cols)
        return 0;

    I=(double *)malloc(cols*cols*sizeof(double));
    tmp=(double *)malloc(cols*sizeof(double));

    if (I && tmp)
        {

            for (r=0; r<cols; r++)
                {
                    rcols=r*cols;
                    for (c=0; c<cols; c++)
                        {
                            I[c+rcols]=0.0;
                            for (i=0; i<rows; i++)
                                {
                                    icols=i*cols;
                                    I[c+rcols] += M[r + icols]*M[c + icols];
                                }
                        }
                }


//-------------------------------------------------------
            //test=(double *)malloc(cols*cols*sizeof(double));
            //Ident=(double *)malloc(cols*cols*sizeof(double));
            //memcpy(test, I, cols*cols*sizeof(double));
//-------------------------------------------------------


            if (!InvertMatrixA(I, cols))
                goto END;

//----------------------------------------
            /*for (r=0;r<cols;r++){
                for (c=0;c<cols;c++){
                    Ident[c+r*cols]=0.0;
                    for (i=0;i<cols;i++){
                        Ident[c+r*cols]+=test[r*cols + i]*I[i*cols + c];
                    }
                }
            }

            sprintf(txt,"");
            for (r=0;r<cols;r++){
                for (c=0;c<cols;c++){
                    sprintf(txt,"%s%f ",txt,Ident[r*cols+c]);
                }
                sprintf(txt,"%s\n",txt);
            }
            MessageBox(NULL,txt,"",MB_OK);

            if (test) free(test);
            if (Ident) free(Ident);*/
//------------------------------------------



            for (r=0; r<rows; r++)
                {
                    rcols=r*cols;
                    for (c=0; c<cols; c++)
                        {
                            tmp[c]=0.0;
                            for (i=0; i<cols; i++)
                                {
                                    tmp[c] += I[i+c*cols]*M[i+rcols];
                                }
                        }
                    memcpy(&M[rcols], tmp, sizeof(double)*cols);
                }
            result=1;
        }

END:
    if (I)
        free(I);

    if (tmp)
        free(tmp);

    return result;
}


//==============================================================================
//          compute the psuedo inverse (M^tM)^(-1)M^t of matrix M
//          M is replaced by its TRANSPOSED psuedo inverse on return
//          Var contains the diagonals of the (M^TM)^-1 matrix on exit
//==============================================================================
int PsuedoInverseEx(double M[], double Var[], int rows, int cols)
{

    double *I, *tmp;
    int r,c,i;
    int result=0;
    int rcols,icols;
    //double *test=NULL, *Ident=NULL;
    //char txt[1024];

    if (rows<cols)
        return 0;

    I=(double *)malloc(cols*cols*sizeof(double));
    tmp=(double *)malloc(cols*sizeof(double));



    if (I && tmp)
        {

            for (r=0; r<cols; r++)
                {
                    rcols=r*cols;
                    for (c=0; c<cols; c++)
                        {
                            I[c+rcols]=0.0;
                            for (i=0; i<rows; i++)
                                {
                                    icols=i*cols;
                                    I[c+rcols] += M[r + icols]*M[c + icols];
                                }
                        }
                }

//-------------------------------------------------------
            /*        test=(double *)malloc(cols*cols*sizeof(double));
                    Ident=(double *)malloc(cols*cols*sizeof(double));
                    memcpy(test, I, cols*cols*sizeof(double));*/
//-------------------------------------------------------


            if (!InvertMatrixA(I, cols))
                goto END;
            for (c=0; c<cols; c++)
                Var[c]=I[c+c*cols];

//----------------------------------------
            /*		for (r=0;r<cols;r++){
                        for (c=0;c<cols;c++){
                            Ident[c+r*cols]=0.0;
                            for (i=0;i<cols;i++){
                                Ident[c+r*cols]+=test[r*cols + i]*I[i*cols + c];
                            }
                        }
                    }

            		sprintf(txt,"");
            		for (r=0;r<cols;r++){
                        for (c=0;c<cols;c++){
                            sprintf(txt,"%s%f ",txt,Ident[r*cols+c]);
                        }
                        sprintf(txt,"%s\n",txt);
                    }
            		MessageBox(NULL,txt,"",MB_OK);

            		if (test) free(test);
            		if (Ident) free(Ident);*/
//------------------------------------------



            for (r=0; r<rows; r++)
                {
                    rcols=r*cols;
                    for (c=0; c<cols; c++)
                        {
                            tmp[c]=0.0;
                            for (i=0; i<cols; i++)
                                {
                                    tmp[c] += I[i+c*cols]*M[i+rcols];
                                }
                        }
                    memcpy(&M[rcols], tmp, sizeof(double)*cols);
                }
            result=1;
        }

END:
    if (I)
        free(I);

    if (tmp)
        free(tmp);

    return result;
}
//==============================================================================
//            Compute the parameters (Params[Nparams]) of a linear model
//            Pinv[Nknowns*Nparams]: the transpose of the psuedo inverse of the design matrix
//            Knowns[]: the known values
//            return the estimate of variance
//==============================================================================
int LinearModelParameters(double Pinv[], double Knowns[], double Params[], int Nknowns, int Nparams)
{

    int i,j;

    memset(Params,0,sizeof(double)*Nparams);

    for (j=0; j<Nparams; j++)
        {
            for (i=0; i<Nknowns; i++)
                {
                    Params[j]+=Pinv[i*Nparams+j]*Knowns[i];
                }
        }

    return 1;
}

//==============================================================================
//               Linear model
//               X: design matrix
//               params[Nparams]: parameters
//               knowns[Nknowns]: knowns
//               V[Nparams]: the diagonals of the covarience matrix ON EXIT
//               return the estimate of sigma
//==============================================================================
double LinearModel(double X[], double knowns[], double params[], double V[], int Nknowns, int Nparams)
{

    double *Pseudo=NULL;
    double sigma=0.0;
    double sum;
    int df=Nknowns-Nparams;
    int i,j;

    if (df<=0)
        goto END;

    if (!(Pseudo=(double *)malloc(Nknowns*Nparams*sizeof(double))))
        goto END;

    memcpy(Pseudo,X,Nknowns*Nparams*sizeof(double));

    if (!PsuedoInverseEx(Pseudo, V, Nknowns, Nparams))
        goto END;

    LinearModelParameters(Pseudo, knowns, params, Nknowns, Nparams);

    for (j=0; j<Nknowns; j++)
        {
            sum=0.0;
            for (i=0; i<Nparams; i++)
                {
                    sum+=X[j*Nparams+i]*params[i];
                }
            sigma+=pow(knowns[j]-sum,2);
        }

    sigma=sqrt(sigma/df);

END:
    if (Pseudo)
        free(Pseudo);

    return sigma;
}




//==============================================================================
//              Invert 3x3 or 2x2 matrix M
//http://www.dr-lex.be/random/matrix_inv.html
//22/08/2009
//==============================================================================
int Inverse2x2OR3x3Matrix(double M[], int N)
{

    long double det;
    long double a11, a12, a13, a21, a22, a23, a31, a32, a33;

    if (N==2 || N==3)
        {
            if (N==2)
                {
                    a11=M[0];
                    a12=M[1];
                    a21=M[2];
                    a22=M[3];
                    det=a11*a22-a12*a21;
                    if (fabs(det)>0.0)
                        {
                            M[0]=a22/det;
                            M[1]=-a12/det;
                            M[2]=-a21/det;
                            M[3]=a11/det;
                        }
                    else
                        return 0;
                }
            else
                {
                    a11=M[0];
                    a12=M[1];
                    a13=M[2];
                    a21=M[3];
                    a22=M[4];
                    a23=M[5];
                    a31=M[6];
                    a32=M[7];
                    a33=M[8];
                    det=a11*(a33*a22-a32*a23)-a21*(a33*a12-a32*a13)+a31*(a23*a12-a22*a13);
                    if (fabs(det)>0.0)
                        {
                            M[0]=(a33*a22-a32*a23)/det;
                            M[1]=-(a33*a12-a32*a13)/det;
                            M[2]=(a23*a12-a22*a13)/det;
                            M[3]=-(a33*a21-a31*a23)/det;
                            M[4]=(a33*a11-a31*a13)/det;
                            M[5]=-(a23*a11-a21*a13)/det;
                            M[6]=(a32*a21-a31*a22)/det;
                            M[7]=-(a32*a11-a31*a12)/det;
                            M[8]=(a22*a11-a21*a12)/det;
                        }
                    else
                        return 0;
                }

        }
    else
        return 0;

    return 1;
}


//==============================================================================
//              Invert 3x3 or 2x2 symmetric matrix M
//http://www.dr-lex.be/random/matrix_inv.html
//22/08/2009
//==============================================================================
int Inverse2x2OR3x3SymmetricMatrix(double M[], int N)
{

    double det;
    double a11, a12, a13, a22, a23, a33;

    if (N==2 || N==3)
        {
            if (N==2)
                {
                    a11=M[0];
                    a12=M[1];
                    a22=M[3];
                    det=a11*a22-a12*a12;
                    if (fabs(det)>0.0)
                        {
                            M[0]=a22/det;
                            M[1]=-a12/det;
                            M[2]=M[1];
                            M[3]=a11/det;
                        }
                    else
                        return 0;
                }
            else
                {
                    a11=M[0];
                    a12=M[1];
                    a13=M[2];
                    a22=M[4];
                    a23=M[5];
                    a33=M[8];
                    det=a11*(a33*a22-a23*a23)-a12*(a33*a12-a23*a13)+a13*(a23*a12-a22*a13);
                    if (fabs(det)>0.0)
                        {
                            M[0]=(a33*a22-a23*a23)/det;
                            M[1]=-(a33*a12-a23*a13)/det;
                            M[2]=(a23*a12-a22*a13)/det;
                            M[3]=M[1];
                            M[4]=(a33*a11-a13*a13)/det;
                            M[5]=-(a23*a11-a12*a13)/det;
                            M[6]=M[2];
                            M[7]=M[5];
                            M[8]=(a22*a11-a12*a12)/det;
                        }
                    return 0;
                }

        }
    else
        return 0;

    return 1;
}






//==============================================================================
//computes the eigen values of a symmetric matrix
//A is the N*N symmetric matrix on entry. The diagonals and sub diagonals are unchanged on exit
//e are the N sorted eigenvalues (in ascending order) on exit
//V contains the eigenvectors on exit in columns if evects is true
//see numerical methods section 11.1 page 463
//==============================================================================
#define FRACTION 0.3
int JacobiEigenSystemSolver(double A[], double V[], double e[], int N, int evects)
{

    int iter=0;
    double s, c, theta, t,tor, thetamax=10e10, *d=NULL;
    int r,p,q;
    double Sum, thresh, Apq, Arp, Arq, Vrp, Vrq, abstrace;
    int *sort=NULL;


    if (N<=1)
        return 0;

    if (!(sort=(int *)malloc(N*sizeof(int))))
        goto END;

    if (!(d=(double *)malloc(N*sizeof(double))))
        goto END;


    //initialize vectors
    if (evects)
        {
            memset(V,0,sizeof(double)*N*N);
            for (r=0; r<N; r++)
                V[r+r*N]=1.0;
        }

    //initialize d to the diagonals
    for (r=0; r<N; r++)
        d[r]=A[r+r*N];


    do
        {

            //get the size of the off diagonal elements and the diagonal elements
            Sum=abstrace=0.0;
            for (p=0; p<N; p++)
                {
                    abstrace+=fabs(A[p+p*N]);
                    for (q=p+1; q<N; q++)
                        {
                            Sum+=fabs(A[q+p*N]);
                        }
                }
            thresh=FRACTION*Sum/(N-1)/(N-1);		                                //dont process elements with mag < thresh

            for (p=0; p<N; p++)
                {
                    for (q=p+1; q<N; q++)
                        {

                            Apq=A[q+p*N];
                            if (fabs(Apq)>thresh) 		                                    //adjust elements that are above the threshold
                                {
                                    theta=(d[q]-d[p])/2.0/Apq;


                                    if (fabs(theta)<thetamax)                                   //compute the values of t, c, s, and tor
                                        {
                                            if (theta<0.0)
                                                t=-1.0/(fabs(theta)+sqrt(theta*theta+1.0));
                                            else
                                                t=1.0/(fabs(theta)+sqrt(theta*theta+1.0));
                                        }
                                    else
                                        t=1.0/2.0/theta;

                                    c=1.0/sqrt(t*t+1.0);
                                    s=t*c;

                                    tor=s/(1.0+c);


                                    for (r=0; r<N; r++)
                                        {

                                            if (r!=q && r!=p)
                                                {
                                                    if (q>=r)
                                                        Arq=A[q+r*N];
                                                    else
                                                        Arq=A[r+q*N];
                                                    if (p>=r)
                                                        Arp=A[p+r*N];
                                                    else
                                                        Arp=A[r+p*N];

                                                    if (r<=p)
                                                        A[p+r*N]-=s*(Arq+tor*Arp);
                                                    else
                                                        A[r+p*N]-=s*(Arq+tor*Arp);

                                                    if (r<=q)
                                                        A[q+r*N]+=s*(Arp-tor*Arq);
                                                    else
                                                        A[r+q*N]+=s*(Arp-tor*Arq);

                                                }

                                            if (evects)
                                                {
                                                    Vrp=V[p+r*N];
                                                    Vrq=V[q+r*N];
                                                    V[p+r*N]-=s*(Vrq+tor*Vrp);
                                                    V[q+r*N]+=s*(Vrp-tor*Vrq);
                                                }

                                        }



                                    d[p]-=t*Apq;                                                //Now change the values of the matrix elements
                                    d[q]+=t*Apq;

                                    A[q+p*N]=0.0;

                                }
                        }
                }

            iter++;
        }
    while((abstrace>0.0) && Sum/abstrace>1.0e-6/N && iter<50);





    QuickSort(d, sort, N);                                                      //order the eigenvalues
    for (r=0; r<N; r++)
        e[r]=d[sort[r]];

    if (evects)                                                                 //now order the vectors
        {
            for (p=0; p<N; p++)
                {
                    memcpy(d,&V[p*N],sizeof(double)*N);
                    for (r=0; r<N; r++)
                        {
                            V[r+p*N]=d[sort[r]];
                        }
                }
        }

END:
    if (sort)
        free(sort);

    if (d)
        free(d);

    return iter;
}





//==============================================================================
//       -Runga-Kutta 2
//       -n is dimensions
//       -h is step size
//       -V[] is a vector of positions along the solution step h apart
//          this is the solution
//       -V[0] is the initial position at the begining
//          V[] has length MAX (V[0]..V[MAX-1])
//       -func(void *data, float V[], int n, float K[]) puts the step vector
//          at position V[n] into K (normalized to unity). Initially K is
//          the K from the previous step. func returns 0 if it fails.
//       -The algotithm will terminate if func gives k of length 0,
//          or if the number of steps exceeds MAX-1
//       -returns the number of steps 0..(MAX-1)
//==============================================================================
int RK2(void *dat, float h, float V[], int n, int MAX, double (*func)(void *dat, float *P, int n, float *K))
{

    float *K=NULL;
    double length;
    int step=0;
    int i;
//    char txt[256];

    K=(float *)malloc(sizeof(float)*n);

    if (!K)
        return 0;

    do
        {
            //K=f(step, V)
            length=func(dat, V, step, K);

            if ( length>0.0 )//K is normalised
                {

                    //midpoint evaluation->V[step]+h*K/2
                    for (i=0; i<n; i++)
                        V[(step+1)*n+i] = V[step*n+i] + h*K[i]/2.0;

                    //K=f(step+h/2, h*K/2)
                    length=func(dat, V, step+1, K);

                    //V[step+1]=V[step]+h*K
                    if (length>0.0)
                        {
                            for (i=0; i<n; i++)
                                V[(step+1)*n+i]=V[step*n+i] + h*K[i];
                        }

                    step++;
                }
        }
    while(step<(MAX-1) && length>0.0);
//sprintf(txt,"%d",step);
//MessageBox(NULL,txt,"",MB_OK);

    if (K)
        free(K);

    return step;
}






//==============================================================================
//              compute the length of the vector v
//              with n dimensions
//==============================================================================
float VectorLength(float v[], int n)
{

    float length=0.0;
    int i;

    for (i=0; i<n; i++)
        length+=v[i]*v[i];

    return sqrt(length);
}



//==============================================================================
//              Add vector V2 to V1
//              with n dimensions
//==============================================================================
int AddVectors(float V1[], float V2[], int n)
{

    int i;
    for (i=0; i<n; i++)
        V1[i]+=V2[i];

    return 1;
}





//==============================================================================
//              Dot product between 2 ThreeVectors
//==============================================================================
float DPThreeVector(struct ThreeVector *V1, struct ThreeVector *V2)
{
    return (*V1).x*(*V2).x + (*V1).y*(*V2).y + (*V1).z*(*V2).z;
}

//==============================================================================
//          Cross product between two ThreeVectors
//==============================================================================
struct ThreeVector CrossProduct(struct ThreeVector V1, struct ThreeVector V2)
{

    struct ThreeVector V;

    V.x=(V1.y*V2.z - V2.y*V1.z);
    V.y=-(V1.x*V2.z - V2.x*V1.z);
    V.z=(V1.x*V2.y - V2.x*V1.y);

    return V;
}

//==============================================================================
//      Normalise ThreeVector
//==============================================================================
int NormaliseThreeVector(struct ThreeVector *V)
{
    double length=LengthThreeVector(V);
    if (length>0.0)
        {
            (*V).x/=length;
            (*V).y/=length;
            (*V).z/=length;
        }
    else
        return 0;
    return 1;
}
//==============================================================================
//			Return length of a ThreeVector
//==============================================================================
double LengthThreeVector(struct ThreeVector *V)
{
    return sqrt((*V).x*(*V).x + (*V).y*(*V).y + (*V).z*(*V).z);
}

//==============================================================================
//      return the angle between two ThreeVectors
//==============================================================================
double AngleBetweenThreeVectors(struct ThreeVector V,struct ThreeVector V1)
{

    double dp;

    NormaliseThreeVector(&V);
    NormaliseThreeVector(&V1);
    dp=DPThreeVector(&V, &V1);
    if (dp<-1.0)
        dp=-1.0;

    if (dp>1.0)
        dp=1.0;

    return acos(dp);
}

//==============================================================================
//          return V-V1
//==============================================================================
struct ThreeVector SubtractThreeVector(struct ThreeVector V,struct ThreeVector V1)
{

    V.x-=V1.x;
    V.y-=V1.y;
    V.z-=V1.z;
    return V;
}

//==============================================================================
//                  Rigid transform only returned
//==============================================================================
struct AffineMatrix AffineTransformationMatrix(double ThetaX, double ThetaY, double ThetaZ, double x, double y, double z)
{

    struct AffineMatrix M,M2;
    double trans[4][4][3];
    int i,j,k,l;

    memset(&M,0,sizeof(struct AffineMatrix));
    memset(&M2,0,sizeof(struct AffineMatrix));
    memset(trans,0,sizeof(double)*4*4*3);


    //x axis rotation
    trans[0][0][0]=1.0;
    trans[1][1][0]=cos(ThetaX);
    trans[2][1][0]=sin(ThetaX);
    trans[1][2][0]=-trans[2][1][0];
    trans[2][2][0]=trans[1][1][0];
    trans[3][3][0]=1.0;

    //z axis rotation
    trans[0][0][1]=cos(ThetaY);
    trans[0][2][1]=sin(ThetaY);
    trans[1][1][1]=1.0;
    trans[2][0][1]=-trans[0][2][1];
    trans[2][2][1]=trans[0][0][1];
    trans[3][3][1]=1.0;

    //z axis rotation
    trans[0][0][2]=cos(ThetaZ);
    trans[0][1][2]=-sin(ThetaZ);
    trans[1][0][2]=-trans[0][1][2];
    trans[1][1][2]=trans[0][0][2];
    trans[2][2][2]=1.0;
    trans[3][3][2]=1.0;


    //diagonal
    for (i=0; i<4; i++)
        M.M[i][i]=1.0;
    for (i=0; i<3; i++)
        {
            //multiply matrix i-1 by i. Result stored in matrix
            for (j=0; j<4; j++)
                {
                    for (k=0; k<4; k++)
                        {
                            M2.M[j][k]=0.0;
                            for (l=0; l<4; l++)
                                {
                                    M2.M[j][k]+=trans[j][l][i]*M.M[l][k];
                                }
                        }
                }
            M=M2;
        }


    //translation
    M.M[0][3]=-x;
    M.M[1][3]=-y;
    M.M[2][3]=-z;
    M.M[3][3]=1.0;
    return M;
}









//==============================================================================
//                  return full affine transform matrix
//                  Changed 23/09/2010 so that there are only 3 shear parameters
//                  instead of the original 6
//==============================================================================
struct AffineMatrix AffineTransformationMatrix12param(double ThetaX, double ThetaY, double ThetaZ, double x, double y, double z,
        double scalex, double scaley, double scalez,
        double shearxy, double shearxz, double shearyz)
{



    struct AffineMatrix M,M2;
    double trans[4][4][5];
    int i,j,k,l;

    memset(&M,0,sizeof(struct AffineMatrix));
    memset(&M2,0,sizeof(struct AffineMatrix));
    memset(trans,0,sizeof(double)*4*4*5);


    //x axis rotation
    trans[0][0][0]=1.0;
    trans[1][1][0]=cos(ThetaX);
    trans[2][1][0]=sin(ThetaX);
    trans[1][2][0]=-trans[2][1][0];
    trans[2][2][0]=trans[1][1][0];
    trans[3][3][0]=1.0;

    //y axis rotation
    trans[0][0][1]=cos(ThetaY);
    trans[0][2][1]=sin(ThetaY);
    trans[1][1][1]=1.0;
    trans[2][0][1]=-trans[0][2][1];
    trans[2][2][1]=trans[0][0][1];
    trans[3][3][1]=1.0;

    //z axis rotation
    trans[0][0][2]=cos(ThetaZ);
    trans[0][1][2]=-sin(ThetaZ);
    trans[1][0][2]=-trans[0][1][2];
    trans[1][1][2]=trans[0][0][2];
    trans[2][2][2]=1.0;
    trans[3][3][2]=1.0;

    //shear
    trans[0][0][3]=1.0;
    trans[1][1][3]=1.0;
    trans[2][2][3]=1.0;
    trans[0][1][3]=shearxy;
    trans[0][2][3]=shearxz;
    trans[1][2][3]=shearyz;
    trans[3][3][3]=1.0;

    //scale
    trans[0][0][4]=scalex;
    trans[1][1][4]=scaley;
    trans[2][2][4]=scalez;
    trans[3][3][4]=1.0;


    //diagonal
    for (i=0; i<4; i++)
        M.M[i][i]=1.0;

    for (i=0; i<5; i++)
        {
            //multiply matrix i-1 by i. Result stored in matrix
            for (j=0; j<4; j++)
                {
                    for (k=0; k<4; k++)
                        {
                            M2.M[j][k]=0.0;
                            for (l=0; l<4; l++)
                                {
                                    M2.M[j][k] += trans[j][l][i]*M.M[l][k];
                                }
                        }
                }
            M = M2;
        }

    //translation
    M.M[0][3]=-x;
    M.M[1][3]=-y;
    M.M[2][3]=-z;
    M.M[3][3]=1.0;




    return M;
}





//==============================================================================
//                  transform *x, *y, *z by *matrix
//                  Modified 23/09/2010
//==============================================================================
int AffineTransformCoordinates(float *x, float *y, float *z, struct AffineMatrix *matrix)
{

    float f[4]= {(*x),(*y),(*z),1.0};
    //int j;

    (*x)=(*y)=(*z)=0.0;
    /*for (j=0; j<4; j++)
    {
        (*x)+=f[j]*(*matrix).M[0][j];
        (*y)+=f[j]*(*matrix).M[1][j];
        (*z)+=f[j]*(*matrix).M[2][j];
    }*/

    (*x) = (*matrix).M[0][0]*f[0] + (*matrix).M[0][1]*f[1] + (*matrix).M[0][2]*f[2] + (*matrix).M[0][3];
    (*y) = (*matrix).M[1][0]*f[0] + (*matrix).M[1][1]*f[1] + (*matrix).M[1][2]*f[2] + (*matrix).M[1][3];
    (*z) = (*matrix).M[2][0]*f[0] + (*matrix).M[2][1]*f[1] + (*matrix).M[2][2]*f[2] + (*matrix).M[2][3];

    return 1;
}

//==============================================================================
//                  transform *x, *y, *z by affine *matrix
//                  Also by the polynomial terms P[], which do quadratic
//                  There are 12 parameters in *matrix, plus 18 for the quadratic
//                  terms not included in the affine matrix.
//                  Therefore a total of 30 parameters
//==============================================================================
int PolynomialCoordinateTransformQuadratic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[])
{

    float x1,y1,z1,z2;

    AffineTransformCoordinates(x, y, z, matrix);

    x1=(*x), y1=(*y), z1=(*z);
    z2=(*z)*(*z);


    (*x)+=(P[0]*x1 + P[1]*y1 + P[2]*z1)*x1  +  (P[3]*y1 + P[4]*z1)*y1   +  P[5]*z2;
    (*y)+=(P[6]*x1 + P[7]*y1 + P[8]*z1)*x1  +  (P[9]*y1 + P[10]*z1)*y1   +  P[11]*z2;
    (*z)+=(P[12]*x1 + P[13]*y1 + P[14]*z1)*x1  +  (P[15]*y1 + P[16]*z1)*y1   +  P[17]*z2;

    return 1;
}

//==============================================================================
//                  transform *x, *y, *z by affine *matrix
//                  Also by the polynomial terms P[], which do cubic
//                  There are 12 parameters in *matrix, plus 18 for the quadratic + 30 for cubic
//                  terms not included in the affine matrix.
//                  Therefore a total of 60 parameters
//==============================================================================
int PolynomialCoordinateTransformCubic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[])
{

    double *p;
    float x1,y1,y2,z1,z2;


    p=&P[18];//the cubic terms start here
    PolynomialCoordinateTransformQuadratic(x, y, z, matrix, P);

    x1=(*x), y1=(*y), z1=(*z);
    y2=(*y)*(*y), z2=(*z)*(*z);


    (*x)+=((p[0]*x1 + p[3] *y1  +  p[4]*z1 )*x1 +  (p[5]*y1 +  p[9]*z1)*y1)*x1  +  (p[1]*y1 + p[6]*z1)*y2  +  (p[2]*z1 + p[7]*x1 + p[8]*y1)*z2;
    (*y)+=((p[10]*x1 + p[13] *y1  +  p[14]*z1 )*x1 +  (p[15]*y1 +  p[19]*z1)*y1)*x1  +  (p[11]*y1 + p[16]*z1)*y2  +  (p[12]*z1 + p[17]*x1 + p[18]*y1)*z2;
    (*z)+=((p[20]*x1 + p[23] *y1  +  p[24]*z1 )*x1 +  (p[25]*y1 +  p[29]*z1)*y1)*x1  +  (p[21]*y1 + p[26]*z1)*y2  +  (p[22]*z1 + p[27]*x1 + p[28]*y1)*z2;

    return 1;
}



//==============================================================================
//                  transform *x, *y, *z by affine *matrix
//                  Also by the polynomial terms P[], which do quartic
//                  There are 12 parameters in *matrix, plus 18 for the quadratic + 30 for cubic + 45 for quartic
//                  terms not included in the affine matrix.
//                  Therefore a total of 105 parameters
//==============================================================================
int PolynomialCoordinateTransformQuartic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[])
{

    double *p;
    double  x1,y1,y2,y3,y4,z1,z2,z3,z4;

    p=&P[48];//the quartic terms start here
    PolynomialCoordinateTransformCubic(x, y, z, matrix, P);
    x1=(*x), y1=(*y), z1=(*z);

    y2=y1*y1;
    y3=y2*y1;
    y4=y3*y1;
    z2=z1*z1;
    z3=z2*z1;
    z4=z3*z1;




    /*(*x) += p[0]*x4 + p[1]*x3*y1 + p[2]*x3*z1 + p[3]*x2*y2 + p[4]*x2*y1*z1 + p[5]*x2*z2 + p[6]*x1*y3 + p[7]*x1*y2*z1 + p[8]*x1*y1*z2 +  p[9]*x1*z3 +
               p[10]*y4 + p[11]*y3*z1 + p[12]*y2*z2 + p[13]*y1*z3 + p[14]*z4;

    (*y) += p[15]*x4 + p[16]*x3*y1 + p[17]*x3*z1 + p[18]*x2*y2 + p[19]*x2*y1*z1 + p[20]*x2*z2 + p[21]*x1*y3 + p[22]*x1*y2*z1 + p[23]*x1*y1*z2 +
               p[24]*x1*z3 + p[25]*y4 + p[26]*y3*z1 + p[27]*y2*z2 + p[28]*y1*z3 + p[29]*z4;

    (*z) += p[30]*x4 + p[31]*x3*y1 + p[32]*x3*z1 + p[33]*x2*y2 + p[34]*x2*y1*z1 + p[35]*x2*z2 + p[36]*x1*y3 + p[37]*x1*y2*z1 + p[38]*x1*y1*z2 +
               p[39]*x1*z3 + p[40]*y4 + p[41]*y3*z1 + p[42]*y2*z2 + p[43]*y1*z3 + p[44]*z4;*/

//factorise to save some multiplications
    (*x) += x1*(p[6]*y3 + p[7]*y2*z1 + p[8]*y1*z2 + p[9]*z3 + x1*(p[3]*y2 + p[4]*y1*z1 + p[5]*z2 + x1*(p[2]*z1 + p[1]*y1 + p[0]*x1)) ) +
            p[10]*y4 + p[11]*y3*z1 + p[12]*y2*z2 + p[13]*y1*z3 + p[14]*z4;

    (*y) += x1*(p[21]*y3 + p[22]*y2*z1 + p[23]*y1*z2 + p[24]*z3 + x1*(p[18]*y2 + p[19]*y1*z1 + p[20]*z2 + x1*(p[17]*z1 + p[16]*y1 + p[15]*x1)) ) +
            p[24]*x1*z3 + p[25]*y4 + p[26]*y3*z1 + p[27]*y2*z2 + p[28]*y1*z3 + p[29]*z4;

    (*z) += x1*(p[36]*y3 + p[37]*y2*z1 + p[38]*y1*z2 + p[39]*z3 + x1*(p[33]*y2 + p[34]*y1*z1 + p[35]*z2 + x1*(p[32]*z1 + p[31]*y1 + p[30]*x1)) ) +
            p[39]*x1*z3 + p[40]*y4 + p[41]*y3*z1 + p[42]*y2*z2 + p[43]*y1*z3 + p[44]*z4;

    return 1;
}


//==============================================================================
//                  transform *x, *y, *z by affine *matrix
//                  Also by the polynomial terms P[], which do quartic
//                  There are 12 parameters in *matrix, plus 18 for the quadratic + 30 for cubic + 45 for quartic
//                  + 63 for Quintic
//                  terms not included in the affine matrix.
//                  Therefore a total of 105 parameters
//==============================================================================
int PolynomialCoordinateTransformQuintic(float *x, float *y, float *z, struct AffineMatrix *matrix, double P[])
{

    double *p;
    double  x1,x2,x3,x4,x5,y1,y2,y3,y4,y5,z1,z2,z3,z4,z5;

    p=&P[93];//the quintic terms start here
    PolynomialCoordinateTransformQuartic(x, y, z, matrix, P);

    x1=(*x), y1=(*y), z1=(*z);
    x2=x1*x1;
    x3=x2*x1;
    x4=x3*x1;
    x5=x4*x1;
    y2=y1*y1;
    y3=y2*y1;
    y4=y3*y1;
    y5=y4*y1;
    z2=z1*z1;
    z3=z2*z1;
    z4=z3*z1;
    z5=z4*z1;



    (*x) += p[0]*x5 + x4*(p[1]*y1 + p[2]*z1) + x3*(p[3]*y2 + p[4]*y1*z1 + p[5]*z2) + x2*(p[6]*y3 + p[7]*y2*z1 + p[8]*y1*z2 + p[9]*z3) +
            x1*(p[10]*y4 + p[11]*y3*z1 + p[12]*y2*z2 + p[13]*y1*z3 + p[14]*z4) + p[15]*y5 + p[16]*y4*z1 + p[17]*y3*z2 + p[18]*y2*z3 +
            p[19]*y1*z4 + p[20]*z5;


    (*y) += p[21]*x5 + x4*(p[22]*y1 + p[23]*z1) + x3*(p[24]*y2 + p[25]*y1*z1 + p[26]*z2) + x2*(p[27]*y3 + p[28]*y2*z1 + p[29]*y1*z2 + p[30]*z3) +
            x1*(p[31]*y4 + p[32]*y3*z1 + p[33]*y2*z2 + p[34]*y1*z3 + p[35]*z4) + p[36]*y5 + p[37]*y4*z1 + p[38]*y3*z2 + p[39]*y2*z3 +
            p[40]*y1*z4 + p[41]*z5;

    (*z) += p[42]*x5 + x4*(p[43]*y1 + p[44]*z1) + x3*(p[45]*y2 + p[46]*y1*z1 + p[47]*z2) + x2*(p[48]*y3 + p[49]*y2*z1 + p[50]*y1*z2 + p[51]*z3) +
            x1*(p[52]*y4 + p[53]*y3*z1 + p[54]*y2*z2 + p[55]*y1*z3 + p[56]*z4) + p[57]*y5 + p[58]*y4*z1 + p[59]*y3*z2 + p[60]*y2*z3 +
            p[61]*y1*z4 + p[62]*z5;

    return 1;
}




//==============================================================================
//          Generate a random number from a Gaussian distribution
//          Use a Box-Muller method
//          Could generate 2 random numbers, but not here
//          If sd<=0.0, returns 0.0
//          If sd<=0.0, returns mean//changed 28/10/2016
//slightly more efficient than Gauss2RandomNumbers_BoxMuller because of fewer calculations
//==============================================================================
double GaussRandomNumber_BoxMuller(double mean, double sd)
{
    double u1, u2;//uniform random number [0..1]

    if (sd<=0.0)
        return mean;

    do
        {
            u1=(double)rand()/RAND_MAX;
            u2=(double)rand()/RAND_MAX;
        }
    while ( (u1<=0.0) || (u2<=0.0) );

    if (u1>=1.0)
        return mean;
    else
        return sd*sqrt(-2.0*log(u1))*cos(2.0*PI*u2) + mean;//standard normal * sd + mean
}
int TestBoxMuller(void)
{

    double H[101];
    double r;
    double sum,sum2;
    int i,k,n;
    FILE *fp;
    char txt[256];

    memset(H,0,sizeof(double)*101);

    sum=sum2=0.0;
    n=0;
    for (i=0; i<1000000; i++)
        {
            r=GaussRandomNumber_BoxMuller(10.0, 3.14);
            sum+=r;
            sum2+=r*r;
            n++;

            r+=50.0;

            k=(int)r;
            if (k>=0 && k<101)
                H[k]+=1.0;
        }

    sprintf(txt,"mean=%f sd=%f",sum/n, sqrt(sum2/n-sum*sum/n/n));
    MessageBox(NULL,txt,"",MB_OK);

    if ( (fp=fopen("c:/temp/guass.txt","w") ) )
        {
            for (k=0; k<101; k++)
                {
                    fprintf(fp,"%f %f\n",((float)k-50.0), H[k]);
                }
            fclose(fp);
        }

    return 1;
}

//==============================================================================
//generates 2 uncorrelated normally distributed variables with the same mean and sd
//==============================================================================
struct TwoNorm Gauss2RandomNumbers_BoxMuller(double mean, double sd)
{
    double u1, u2;//uniform random number [0..1]
    struct TwoNorm TN;

    if (sd<=0.0)
        {
            TN.x=TN.y=mean;
            return TN;
        }

    do
        {
            u1=(double)rand()/RAND_MAX;
            u2=(double)rand()/RAND_MAX;
        }
    while ( (u1<=0.0) || (u2<=0.0) );

    if (u1>=1.0)
        {
            TN.x=mean;
            TN.y=mean;
        }
    else
        {
            TN.x=sd*sqrt(-2.0*log(u1))*cos(2.0*PI*u2) + mean;//standard normal * sd + mean
            TN.y=sd*sqrt(-2.0*log(u1))*sin(2.0*PI*u2) + mean;//standard normal * sd + mean
        }

    return TN;
};
int TestGauss2RandomNumbers_BoxMuller(void)
{
    int N=1000;
    double x[1000];
    double y[1000];
    struct TwoNorm tn;
    int i;
    char txt[256];

    for (i=0; i<N; i++)
        {
            tn = Gauss2RandomNumbers_BoxMuller(1.0,1.5);
            x[i] = tn.x;
            y[i] = tn.y;
        }
    sprintf(txt,"%f %f %f %f %f",MeanValueDouble(N,x), MeanValueDouble(N,y), sqrt(Var(x,N)), sqrt(Var(y,N)), Pearsons(x,y,N));
    MessageBox(NULL,txt,"",MB_OK);


    return 1;

}












//==============================================================================
//a mixture of 2 Gaussians f=alpha*f1 + (1-alpha)*f2
//mean of f1 is mean1
//mean of f2 is mean2
//==============================================================================
double TwoNormalMixtureMean(double alpha, double mean1, double mean2)
{
    return alpha*mean1 + (1.0-alpha)*mean2;
}
//==============================================================================
//a mixture of 2 Gaussians f=alpha*f1 + (1-alpha)*f2
//mean (sd) of f1 is mean1 (sigma1)
//mean (sd) of f2 is mean2 (sigma2)
//used var = mean(x^2) - mean(x)^2
//and used standard integral int_{+-inf}  x^2.e(-ax^2 + bx).dx=sqrt(PI)*(2a+b^2).e^(b^2/4a)/4/a^{5/2}
//see https://en.wikipedia.org/wiki/List_of_integrals_of_exponential_functions
//==============================================================================
double TwoNormalMixtureVar(double alpha, double mean1, double mean2, double sigma1, double sigma2)
{
    double mean=TwoNormalMixtureMean(alpha, mean1, mean2);
    return alpha*(sigma1*sigma1 + mean1*mean1) + (1.0-alpha)*(sigma2*sigma2 + mean2*mean2) - mean*mean;
}















//==============================================================================
//                  SMOOTH CURVE FITTING
//==============================================================================
//==============================================================================
//              Interpolation using Cubic fitting
//              V[] is 4 points, equally spaced
//              V[0] is at x=0, V[1] is at x=1.....
//              0<=x<=3
//==============================================================================
double CubicPolynomialInterpolation(double V[], double x)
{
    double x1,x2,x3,xx1,x2x3;
    x1=x-1.0;
    x2=x-2.0;
    x3=x-3.0;
    xx1=x*x1;
    x2x3=x2*x3;
    return ((xx1*x2*V[3]-x1*x2x3*V[0])/3.0 + x*x2x3*V[1] - xx1*x3*V[2])/2.0;
    //return -(x-1.0)*(x-2.0)*(x-3.0)*V[0]/6.0 + x*(x-2.0)*(x-3.0)*V[1]/2.0 -
    //         x*(x-1.0)*(x-3.0)*V[2]/2.0 + x*(x-1.0)*(x-2.0)*V[3]/6.0;
}
//==============================================================================
//                  Fit a smooth surface using SmoothCurveFit
//                  The surface has N control points along X, and M along Y
//                  V[  xi + yi*N  ] are the control points, of which there are N*M
//==============================================================================
double SmoothSurfaceFit(double V[], int N, int M, double x, double y)
{

    double *Vy;
    double f=0.0;
    int yi,yindex;

    if (!(Vy=(double *)malloc(M*sizeof(double))))
        goto END;

    yindex=0;
    for (yi=0; yi<M; yi++)
        {
            V[yi]=SmoothCurveFit(&V[yindex], N, x);
            yindex+=N;
        }

    f=SmoothCurveFit(Vy, M, y);

END:
    if (Vy)
        free(Vy);
    return f;
}

//==============================================================================
//                  Fit a smooth surface using SmoothCurveFit
//                  The surface is periodic in x
//                  The surface has N control points along X, and M along Y
//                  V[xi+yi*N] are the control points, of which there are N*M
//==============================================================================
double SmoothPeriodicSurfaceFit(double V[], int N, int M, double x, double y)
{

    double *Vy;
    double f;
    int yi, yindex;

    Vy=(double *)malloc(M*sizeof(double));

    if (!Vy)
        return 0.0;

    yindex=0;
    for (yi=0; yi<M; yi++)
        {
            V[yi]=SmoothCurveFitPeriodic(&V[yindex], N, x);
            yindex+=N;
        }

    f=SmoothCurveFit(Vy, M, y);

    free(Vy);
    return f;
}








//==============================================================================
//0<=x<=M-1
//0<=y<=N-1
//0<=z<=P-1
//coef[M*N*P];
int SmoothInterpolation3D(double coef[], int M, int N, int P, double x, double y, double z)
{
    double *X=NULL;
    double *Y=NULL;
    double *Z=NULL;
    int result=1;
    int m,n,p;

    if (!(X=malloc(M*sizeof(double))))
        goto END;

    if (!(Y=malloc(N*sizeof(double))))
        goto END;

    if (!(Z=malloc(P*sizeof(double))))
        goto END;

    result *= SmoothCurveCoefficients(X, M, x);
    result *= SmoothCurveCoefficients(Y, N, y);
    result *= SmoothCurveCoefficients(Z, P, z);

    if (result)
        {
            for (p=0; p<P; p++)
                {
                    for (n=0; n<N; n++)
                        {
                            for (m=0; m<M; m++)
                                {
                                    coef[m + n*M + p*M*N] = X[m]*Y[n]*Z[p];
                                }
                        }
                }
        }

END:
    if (X)
        free(X);

    if (Y)
        free(Y);

    if (Z)
        free(Z);

    return result;

}
//==============================================================================
//                  fit cubic y=a + b*x + c*x*x + d*x*x*x
//                  The number of known points V[i] is N.
//                  V[0<=i<N] are the known points
//==============================================================================
int SmoothCurveCoefficients(double coef[], int N, double x)
{
    int result=0;
    int i,n;
    double z;
    double *B=NULL;
    double *C=NULL;
    double *D=NULL;

    memset(coef,0,sizeof(double)*N);
    if (!(B=(double *)calloc(N,sizeof(double))))//coefficient b=B
        goto END;

    if (!(C=(double *)calloc(N,sizeof(double))))//coefficient c=3*C-B
        goto END;

    if (!(D=(double *)calloc(N,sizeof(double))))//coefficient d=D-2*C
        goto END;

    if (N<4)
        goto END;

    if (x>=(double)(N-1))
        {
            coef[N-1]=1.0;
            result=1;
            goto END;
        }

    if (x<=0.0)
        {
            coef[0]=1.0;
            result=1;
            goto END;
        }

    i=(int)x;


    if (x==i)
        {
            coef[i]=1.0;
            result=1;
            goto END;
        }

    if (i==0)//zero boundary
        {
            B[i+1]=0.5;

            C[i]=-1.0;
            C[i+1]=0.5;

            D[i]=-0.5;
            D[i+1]=-0.5;
            D[i+2]=0.5;
        }
    else if (i==N-2)//end boundary
        {
            B[i-1]=-0.5;

            C[i-1]=0.5;
            C[i]=-1.0;

            D[i-1]=0.5;
            D[i]=-0.5;
            D[i+1]=-0.5;
        }
    else// not at boundary
        {
            B[i+1]=0.5;
            B[i-1]=-0.5;

            C[i-1]=0.5;
            C[i]=-1.0;
            C[i+1]=0.5;

            D[i-1]=0.5;
            D[i]=-0.5;
            D[i+1]=-0.5;
            D[i+2]=0.5;
        }

    z=x-(int)x;
    coef[i]=1.0;
    for (n=0; n<N; n++)
        {
            //coef[n]+=B[n]*z + (3*C[n]-D[n]) *z*z + (D[n]-2*C[n])*z*z*z;
            coef[n]+= (B[n] + ((3.0*C[n]-D[n]) + (D[n]-2.0*C[n])*z)*z)*z;
        }

    result=1;
END:


    if (B)
        free(B);
    if (C)
        free(C);
    if (D)
        free(D);

    return result;

}
//==============================================================================
int TestSmoothInterpolation3D(struct Image *image)
{
    double Xfov=(*image).dx*((*image).X-1);
    double Yfov=(*image).dy*((*image).Y-1);
    double Zfov=(*image).dz*((*image).Z-1);
    int M,N,P;
    double C[4*4*4];
    double F[4*4*4];
    int i,j,k;
    int voxel;
    int m,n,p;
    double x,y,z;

    M=4;
    N=P=4;



    for (p=0; p<P; p++)
        {
            for (n=0; n<N; n++)
                {
                    for (m=0; m<M; m++)
                        {
                            F[m + n*M + p*M*N]=(double)(rand()%5);
                        }
                }
        }

    voxel=0;
    for (k=0; k<(*image).Z; k++)
        {
            z=(*image).dz*k/Zfov*(P-1);
            for (j=0; j<(*image).Y; j++)
                {
                    y=(*image).dy*j/Yfov*(N-1);
                    for (i=0; i<(*image).X; i++)
                        {
                            x=(*image).dx*i/Xfov*(M-1);

                            SmoothInterpolation3D(C, M, N, P,x, y, z);

                            (*image).img[voxel]=0.0;
                            for (p=0; p<P; p++)
                                {
                                    for (n=0; n<N; n++)
                                        {
                                            for (m=0; m<M; m++)
                                                {
                                                    (*image).img[voxel]+=C[m + n*M + p*M*N]*F[m + n*M + p*M*N];
                                                }
                                        }
                                }

                            voxel++;
                        }
                }
        }

    (*image).MaxIntensity=5.0;


    return 1;
}
//==============================================================================
//                  fit cubic y=A + B*x + C*x*x + D*x*x*x
//                  The number of known points V[i] is N.
//                  So there are N divides between x=0 and x=1
//                  V[0<=i<N] are the known points
//                  It is assumed that 0<=x<=1.
//                  If x<=0.0, returns V[0]
//                  If x>=1.0, returns V[N-1]
//==============================================================================
double SmoothCurveFit(double V[], int N, double x)
{

    int i;
    double d1,d2;
    double x1,del;
    double A,B,C,D;
    double t;


    if (N<=0)
        return 0.0;

    if (N==1)
        return V[0];

    if (x>=1.0)
        return V[N-1];

    if (x<=0.0)
        return V[0];


    //----spacing between points----
    del=1.0/(N-1);

    i=(int)(x*(N-1));

    //----FRACTION AFTER ith CONTROL POINT----
    x1=(x-i*del)/del;

    //----IF LANDED ON A CONTROL POINT, RETURN THE VALUE AT THAT POINT----
    if (fabs(x1)<del*1.0e-6)
        return V[i];

    //--------COMPUTE THE GRADIENTS----------
    d1=d2=0.0;
    t=1.0/2.0/del/(N-1);
    if (i>0 && i<(N-1))
        d1=(V[i+1]-V[i-1])*t;
    else if (i==0)
        d1=(V[1]-V[0])*t;

    if (i<(N-2))
        d2=(V[i+2]-V[i])*t;
    else if (i==(N-2))
        d2=(V[N-1]-V[i])*t;

    //THERE ARE 4 LINEAR EQUATIONS NOW
    //THE VALUES AT THE NEXT AND PREVIOUS CONTROL POINTS
    //AND THE GRADIENTS AT THE NEXT AND PREVIOUS CONTROL POINTS
    //A CUBIC POLYNOMIAL CAN THEREFORE BE FIT
    //THE POLYNOMIAL COEFFICIENTS ARE A, B, C, D
    //AFTER MATRIX INVERSION, THE COEFFICIENTS ARE GIVEN BY:
    A=V[i];
    B=d1;
    C=3.0*(V[i+1]-V[i]) - 2.0*d1 - d2;
    D=2.0*(V[i]-V[i+1]) + d1 + d2;


    return A + (B + (C + D*x1)*x1)*x1;

}


//==============================================================================
//                  fit cubic y=a + b*x + c*x*x + d*x*x*x
//                  It is assumed that 0<=x<=1.
//                  If x=a.b (eg 3.2) then it is adjusted to be 0.b (eg 0.2)
//                  The number of known points is N.
//                  So there are N divides between x=0 and x=1
//                  V[N] are the known points
//                  Periodic boundary conditions
//==============================================================================
double SmoothCurveFitPeriodic(double V[], int N, double x)
{

    int i,j;
    double d1=0.0,d2=0.0;          //GRADIENTS
    double x1,del;
    double A,B,C,D;        //CUBIC POLYNOMIAL COEFFICIENTS
    double Vcp=0.0, Vnextcp=0.0;

    if (N<2)
        return 0.0;//MINIMUM N=2


    //---ENFORCE PERIODIC BOUNDARY CONDITIONS----------
    if (x>1.0)
        do
            {
                x-=1.0;
            }
        while(x>1.0);
    if (x<0.0)
        do
            {
                x+=1.0;
            }
        while(x<0.0);

    if (fabs(x)<1.0e-6/N)
        return V[0];
    if (fabs(x-1.0)<1.0e-6/N)
        return V[0];


    del=1.0/N;

    i=(int)(x*N);

    //----------FRACTION AFTER ith CONTROL POINT----------
    x1=(x-i*del)/del;

    //---------IF LANDED ON A CONTROL POINT, RETURN THE VALUE AT THAT POINT---------
    if (fabs(x1)<1.0e-6)
        return V[i];


    //-----COMPUTE THE GRADIENTS, CONSIDERING THE PERIODIC BOUNDARY CONDITIONS----------
    if (i>0 && i<(N-1))
        d1=(V[i+1]-V[i-1])/2.0/del;
    else if (i==(N-1))
        d1=(V[0]-V[N-2])/2.0/del;
    else if (i==0 || i==N)
        d1=(V[1]-V[N-1])/2.0/del;


    j=i+1;//index to the next known point
    if (j>N)
        j-=N;//make the index periodic
    if (j>0 && j<(N-1))
        d2=(V[j+1]-V[j-1])/2.0/del;
    else if (j==(N-1))
        d2=(V[0]-V[N-2])/2.0/del;
    else if (j==0 || j==N)
        d2=(V[1]-V[N-1])/2.0/del;



    //-----RESCALE THE GRADIENTS------
    d1/=(N);
    d2/=(N);

    //-----FIND THE CURRENT AND NEXT CONTROL POINT VALUES--------
    Vcp=V[i];
    if (i>=0 && i<(N-1))
        Vnextcp=V[i+1];
    else if (i==(N-1))
        Vnextcp=V[0];

    //THERE ARE 4 LINEAR EQUATIONS NOW
    //THE VALUES AT THE NEXT AND PREVIOUS CONTROL POINTS
    //AND THE GRADIENTS AT THE NEXT AND PREVIOUS CONTROL POINTS
    //A CUBIC POLYNOMIAL CAN THEREFORE BE FIT
    //THE POLYNOMIAL COEFFICIENTS ARE A, B, C, D
    //AFTER MATRIX INVERSION, THE COEFFICIENTS ARE GIVEN BY:
    A=Vcp;
    B=d1;
    C=-3.0*Vcp + 3*Vnextcp - 2.0*d1-d2;
    D= 2.0*Vcp - 2.0*Vnextcp + d1 + d2;

    return A + (B + (C + D*x1)*x1)*x1;

}











//==============================================================================
//              compute the associated legendre polynomial Plm
//              0<=m<=l
//              -1<=x<=1
//              taken from numerical recipees in C
//==============================================================================
double AssociatedLegendrePolynomial(int l, int m, double x)
{

    double fact, pll=0.0, pmm, pmmp1, somx2;
    int i,ll;

    if ((m<0) || (m>l) || (fabs(x)>1.0))
        return 0.0;

    pmm=1.0;
    if (m>0)
        {
            somx2=sqrt( (1.0-x)*(1.0+x) );
            fact=1.0;
            for (i=1; i<=m; i++)
                {
                    pmm*=-fact*somx2;
                    fact+=2.0;
                }
        }
    if (l==m)
    {
        return pmm;
    }
    else
        {
            pmmp1=x*(2*m+1)*pmm;
            if (l==(m+1))
                return pmmp1;
            else
                {
                    for (ll=m+2; ll<=l; ll++)
                        {
                            pll=(x*(2*ll-1)*pmmp1 - (ll+m-1)*pmm)/(ll-m);
                            pmm=pmmp1;
                            pmmp1=pll;
                        }
                    return pll;
                }
        }
    return 0.0;
}



//==============================================================================
//returns the factorial of an integer
//i should be >=0
//==============================================================================
double Factorial(int i)
{

    double fact=1.0;
    int j;

    if (i<0)
        return 0;

    if (!i)
        return 1.0;

    for (j=0; j<i-1; j++)
        fact*=(i-j);

    return fact;
}
//==============================================================================
//return log of a factorial log(n!)
//==============================================================================
double LogFactorial(int n)
{
    double f=0.0;

    if (n==0)
        return 0.0;
    if (n>20)
        return 0.9189385332 + log((double)n)*((double)n+0.5) - (double)n;///Stirlings Approximation
    else
        {
            f = log( Factorial(n) );
            return f;
        }
    return 0.0;
}

//==============================================================================
struct Complex ComplexAdd(struct Complex c1, struct Complex c2)
{

    struct Complex C;

    C.r=c1.r + c2.r;
    C.i=c1.i + c2.i;

    return C;
}
//==============================================================================
struct Complex ComplexSub(struct Complex c1, struct Complex c2)
{

    struct Complex C;

    C.r=c1.r - c2.r;
    C.i=c1.i - c2.i;

    return C;
}
//==============================================================================
struct Complex ComplexMul(struct Complex c1, struct Complex c2)
{

    struct Complex C;

    C.r=c1.r * c2.r - c1.i*c2.i;
    C.i=c1.r * c2.i + c1.i*c2.r;

    return C;
}
//==============================================================================
struct Complex ComplexDiv(struct Complex c1, struct Complex c2)
{

    struct Complex C,D;

    C=ComplexMul(c1,Conjugate(c2));

    D=ComplexMul(c2,Conjugate(c2));

    if (fabs(D.r)>0.0)
        {
            C.r/=D.r;
            C.i/=D.r;
        }

    return C;
}
//==============================================================================
struct Complex Conjugate(struct Complex c)
{
    c.i*=-1.0;
    return c;
}
//==============================================================================
double ComplexMag(struct Complex c)
{
    return sqrt(c.r*c.r+c.i*c.i);
}
//==============================================================================
struct Complex ComplexExp(double x)
{
    struct Complex r;
    r.r=cos(x);
    r.i=sin(x);
    return r;
}


//==============================================================================
//0<=theta<=PI
//0<=phi<=2PI
int Cartesian2Spherical(double x, double y, double z, double *R, double *theta, double *phi)
{

    double stheta;

    (*R)=sqrt(x*x + y*y + z*z);

    if ((*R)<=0.0)
        return 0;

    (*theta)=acos(z/(*R));
    stheta=sin( (*theta) );
    if (fabs(stheta)<=0.0)
        (*phi)=0.0;
    else
        {
            (*phi)=atan2(y,x);
            if ((*phi)<0.0)
                (*phi)+=2.0*PI;
        }

    return 1;
}
//==============================================================================
int Spherical2Cartesian(double *x, double *y, double *z, double R, double theta, double phi)
{

    (*x)=R*cos(phi)*sin(theta);
    (*y)=R*sin(phi)*sin(theta);
    (*z)=R*cos(theta);

    return 1;
}






//==============================================================================
//			Return the modified bessel function I0(x)
//			From numerical recipes in C
//          For large x, the returned value will be inf because of the exp term
//==============================================================================
double BesselI0(double x)
{

    double ax, ans;
    double y;

    if ( (ax=fabs(x)) < 3.75)
        {
            y=x/3.75;
            y*=y;
            ans=1.0+y*(3.5156229 +
                       y*(3.0899424 +
                          y*(1.2067492 +
                             y*(0.2659732 +
                                y*(0.0360768 +
                                   y*0.0045813)))));
        }
    else
        {
            y=3.75/ax;

            ans=(exp(ax)/sqrt(ax))*(0.39894228 +
                                    y*(0.01328592 +
                                       y*(0.00225319 +
                                          y*(-0.00157565 +
                                             y*(0.00916281 +
                                                y*(-0.02057706 +
                                                   y*(0.02635537 +
                                                      y*(-0.01647633 +
                                                         y*0.00392377))))))));

        }

    return ans;
}


//==============================================================================
//				Rician distribution p(M|A)
//				A is the parameter, M the measurements
//					obtained when the noise is Rician distributed
//				sigma2 is the variance of the distribution
//				See: Maximum likelihood estimation of Rician Distribution
//					 Parameters. Jan Sijbers. 1998. IEEE trans Med Imag.
//													Vol 17, No 3
//              Rewritten 31/12/2010 to avoid call to BesselI0(double x),
//                  which returns inf for large x because of the exp term
//==============================================================================
double Rician(double A, double M, double sigma2)
{

    double R;
    double x,ax;
    double y;

    if (sigma2<=0.0)
        return 0.0;

    x=A*M/sigma2;

    if ( (ax=fabs(x)) < 3.75)
        {
            y=x/3.75;
            y*=y;
            R=1.0+y*(3.5156229 +
                     y*(3.0899424 +
                        y*(1.2067492 +
                           y*(0.2659732 +
                              y*(0.0360768 +
                                 y*0.0045813)))))*(M/sigma2)*exp(-(M*M+A*A)/2.0/sigma2);
        }
    else
        {
            y=3.75/ax;
            R=(exp(ax-(M*M+A*A)/2.0/sigma2)/sqrt(ax))*
              (0.39894228 +
               y*(0.01328592 +
                  y*(0.00225319 +
                     y*(-0.00157565 +
                        y*(0.00916281 +
                           y*(-0.02057706 +
                              y*(0.02635537 +
                                 y*(-0.01647633 +
                                    y*0.00392377))))))))*(M/sigma2);

        }

    return R;
}
//TestRician(100.0, 1.0);
int TestRician(double A, double sigma2)
{

    FILE *fp;
    double M;

    if ((fp=fopen("c:/temp/rician.txt","w")))
        {
            for (M=-1.0; M<20*A; M+=A/100.0)
                {
                    fprintf(fp,"%f %g\n",M,Rician(A, M, sigma2));
                }
            fclose(fp);
        }
    return 1;
}

















//==============================================================================
//          Get the quantiles of data; ignoring 0.0
//data>0
//==============================================================================
#define H_BINS 100001
int Quantiles(float *data, int N, float quantiles[], int Nquantiles)
{

    int *H=NULL;
    int i;
    int I;
    int q;
    int result=0;
    long int count;
    double max,min,range;
    float sum;

    if (!(H=(int *)malloc(H_BINS*sizeof(int))))
        {
            memset(quantiles,0,sizeof(float)*Nquantiles);
            goto END;
        }

//get the data range
    min=FLT_MAX;
    max=-FLT_MAX;
    for (i=0; i<N; i++)
        {
            if ((fabs(data[i])>0.0) && (data[i]<min))
                min=(double)data[i];

            if (data[i]>max)
                max=(double)data[i];
        }

    if ((range=max-min)<=0.0)
        {
            memset(quantiles,0,sizeof(float)*Nquantiles);
            goto END;
        }

//construct the histogram
    memset(H,0,H_BINS*sizeof(int));
    count=0;
    for (i=0; i<N; i++)
        {
            if (data[i]>=min)
                {
                    I=(data[i]-min)/range*(H_BINS-1);
                    if (I>=0 && I<H_BINS)
                        {
                            count++;
                            H[I]++;
                        }
                }
        }

//find the quantiles
    for (q=0; q<Nquantiles; q++)
        {
            if (quantiles[q]<=0.0)
                {
                    quantiles[q]=min;
                }
            else if (quantiles[q]>=1.0)
                {
                    quantiles[q]=max;
                }
            else
                {
                    sum=0.0;
                    i=0;
                    while((i<(H_BINS-1)) && ((sum/count)<quantiles[q]))
                        {
                            sum+=(float)H[i];
                            i++;
                        }
                    quantiles[q]=(float)(i-1)/(H_BINS-1)*range+min;
                }
        }

    result=1;
END:
    if (H)
        free(H);

    return result;
}










//=======================================================================================
//              The Beta probability distribution function
//=======================================================================================
double BetaDistribution(double x, double a, double b)
{

    double beta;

    if ((a<=0.0) || (b<=0.0) || (x<0.0) || (x>1.0))
        return 0.0;

    beta=exp(GammaFunctionLog(a) + GammaFunctionLog(b) - GammaFunctionLog(a+b));

    if (beta<=0.0)
        return 0.0;

    return pow(x, a-1.0)*pow(1.0-x, b-1.0)/beta;
}

//=======================================================================================
int BetaDistributionParameterEstimates(double x[], int N, double *a, double *b)
{

    double sum, sum2;
    double mean, var;
    int i;

    if (N<=0.0)
        return 0;

    sum=sum2=0.0;
    for (i=0; i<N; i++)
        {
            sum+=x[i];
            sum2+=x[i]*x[i];
        }
    mean=sum/N;
    var=sum2/N - mean*mean;
    if (var<=0.0)
        return 0;

    BetaDistributionParameterEstimatesEx(mean, var, a, b);

    return 1;
}

//=======================================================================================
int BetaDistributionParameterEstimatesEx(double mean, double var, double *a, double *b)
{

    double z;

    if ((mean<0.0) || (var<=0.0))
        return 0;

    z=mean*( (1.0-mean)/var -1.0);
    (*a)=mean*z;
    (*b)=(1.0-mean)*z;

    return 1;
}
//=======================================================================================
//=======================================================================================
double LogGammaDistributionAlphaBeta(double x, double alpha, double beta)
{
    double k;
    double theta;

    k=alpha;
    if (beta!=0.0)
        {
            theta=1.0/beta;
        }
    else
        return -DBL_MAX;

    return LogGammaDistribution(x, k, theta);
}
//=======================================================================================
//Gamma distribution function
//returns the log
//parameterised by k,theta; k is shape (k>0) and theta is scale (theta>0)
//TO USE alpha, beta PARAMETERS k=alpha AND theta=1/beta
//=======================================================================================
double LogGammaDistribution(double x, double k, double theta)
{

    if ((k<=0.0) || (x<=0.0) || (theta<=0.0))
        return -DBL_MAX;

    return -k*log(theta) -GammaFunctionLog(k) + (k-1.0)*log(x) -x/theta;
}
int TestGammaDistribution(void)
{
    double x;
    FILE *fp;

    fp=fopen("c://temp//gammadist.csv","w");
    for (x=0; x<10.0; x+=0.1)
        {
            fprintf(fp,"%f,%f\n",x,exp(LogGammaDistribution(x,2.0,1.5)));
        }
    fclose(fp);
    return 1;
}
//=======================================================================================
//the derivative of the log of the gamma function
//https://en.wikipedia.org/wiki/Digamma_function
//=======================================================================================
double DiGamma(double x)
{
    double x2,x4,x6,x8,x10,x12,x14;
    double sum;
    if (x<=0.0)
        return 0.0;

    x2=x*x;
    x4=x2*x2;
    x6=x4*x2;
    x8=x4*x4;
    x10=x8*x2;
    x12=x10*x2;
    x14=x12*x2;
    sum = log(x) - 0.5*x - 1.0/12/x2 + 1.0/120/x4 - 1.0/252/x6 + 1.0/240/x8 - 5.0/660/x10 + 691.0/32760/x12 -1.0/12/x14;

    return sum;
}
//=======================================================================================
//=======================================================================================
double GammaCDF(double x, double a, double b)
{
    double gamma_a_b_x;

    if (a<=0.0 || b<=0.0 || x<=0.0)
        return 0.0;
    gamma_a_b_x = IncompleteGammaLower(a, b*x);

    return gamma_a_b_x;
}
int testGammaCDF(void)
{
    double x;
    double alpha,beta;
    char fname[MAX_PATH];
    FILE *fp;

    alpha=8.0;
    beta=1.0;

    sprintf(fname,"%s\\gammaCDF.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");
    for (x=1.0; x<20.0; x+=0.1)
        {
            fprintf(fp,"%f,%f\n",x,GammaCDF(x,alpha,beta));
        }

    if (fp)
        fclose(fp);

    return 0;
}
//=======================================================================================
// Gamma function from Numerical recipes in c
// returns the ***********log of Gamma(xx)**********;
//=======================================================================================
double GammaFunctionLog(double xx)
{

    double x,y,tmp,ser;
    static double cof[6]= {76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155,
                           0.1208650973866179e-2, -0.5395239384953e-5
                          };
    int j;

    y=x=xx;
    tmp=x+5.5;
    tmp-=(x+0.5)*log(tmp);
    ser=1.000000000190015;
    for (j=0; j<=5; j++)
        ser+=cof[j]/++y;
    return -tmp+log(2.5066282746310005*ser/x);
}
//=======================================================================================
//P value from chisquared distribution
//=======================================================================================
double ChiSquaredPvalue(double dof, double z)
{
    double a=dof/2.0;
    double x=z/2.0;

    if (x<(a+1.0))
        return 1.0 - IncompleteGammaP(a, x);
    else
        return IncompleteGammaQ(a, x);
}
//=======================================================================================
//CDF of chisquared distribution
//this = IncompleteGammaP(dof/2, x/2)
//need  1 - IncompleteGammaQ when x>(a+1)
//if a p value is needed it = 1 - ChiSquaredCDF(double dof, double z)
//=======================================================================================
double ChiSquaredCDF(double dof, double z)
{
    double a=dof/2.0;
    double x=z/2.0;

    if (x<(a))
        return  IncompleteGammaP(a, x);
    else
        return 1.0 - IncompleteGammaQ(a, x);
}
int TestChiSquaredCDF(void)
{
//checked against R's qchisq(p,df) function
    double dof=1.0;
    double z;
    FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s//CDFchisqr.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");
    for (z=0.0; z<10.0; z+=0.1)
        {
            fprintf(fp,"%f,%f,%f\n",z,ChiSquaredCDF(dof, z),ChiSquaredPvalue(dof, z));
        }
    fclose(fp);
    return 1;
}
//=======================================================================================
//computes lower incomplete gamma function; gamma
//for upper incomplete gamma function (GAMMA) use 1.0-IncompleteGammaLower(double a, double x)
//=======================================================================================
double IncompleteGammaLower(double a, double x)
{
    if (x<=(a+5.0))
        return IncompleteGammaP(a, x);
    else
        return 1.0-IncompleteGammaQ(a, x);
}
int TestIncompleteGamma(void)
{
//checked against R's qchisq(p,df) function
    double a=10.0;
    double x;
    FILE *fp;
    char fname[MAX_PATH];
    char txt[256];

    sprintf(fname,"%s//IncompleteGamma.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");
    for (x=0.01; x<20.0; x+=0.01)
        {
            fprintf(fp,"%f,%f,%f,%f\n",x,IncompleteGammaP(a, x),1.0-IncompleteGammaQ(a, x),IncompleteGammaLower(a, x));
        }
    fclose(fp);

    sprintf(txt,"%f %f",IncompleteGammaP(a, a+5.0),1.0-IncompleteGammaQ(a, a+5.0));
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}
//=======================================================================================
//compute the incomplete gamma function P(a,x)
//this function works for x<(a+1)
//see numerical recipes in C page 219
//=======================================================================================
double IncompleteGammaP(double a, double x)
{
    double sum, del, ap;
    int iter;
    double gln;

    if (x<=0.0)
        return 0.0;
    if (a<=0.0)
        return 0.0;

    gln = GammaFunctionLog(a);
    ap=a;
    del=sum=1.0/a;

    iter=0;
    do
        {
            ap += 1.0;
            del *= x/ap;
            sum += del;
            iter++;
        }
    while ((fabs(del)>fabs(sum)*3.0e-9) && iter<200);

    return sum*exp(-x+a*log(x)-gln);
}
int TestIncompleteGammaP(void)
{
//checked against R's qchisq(p,df) function
    double a=0.5;
    double x;
    FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s//IncompleteGamma.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");
    for (x=0.1; x<5.0; x+=0.1)
        {
            fprintf(fp,"%f,%f,%f,%f\n",x,IncompleteGammaP(a, x),1.0-IncompleteGammaQ(a, x),GammaFunctionLog(x));
        }
    fclose(fp);
    return 1;
}
//=======================================================================================
//compute the incomplete gamma function Q(a,x)=1-P(a,x); see above function IncompleteGammaP
//this function works for x>(a+1)
//see numerical recipes in C page 219
//=======================================================================================
double IncompleteGammaQ(double a, double x)
{
    double iter;
    double gln;
    double an, b, c, d, del, h;

    if (x<=0.0)
        return 1.0;
    if (a<=0.0)
        return 1.0;

    gln = GammaFunctionLog(a);

    b = x + 1.0 - a;
    c = DBL_MAX;
    d = 1.0/b;
    h=d;

    iter=1.0;
    do
        {
            an = -iter*(iter-a);
            b += 2.0;
            d = an*d + b;
            if (fabs(d)<DBL_MIN)
                d = DBL_MIN;
            c = b + an/c;
            if (fabs(c)<DBL_MIN)
                c = DBL_MIN;
            d = 1.0/d;
            del = d*c;
            h *= del;

            iter += 1.0;
        }
    while ((fabs(del-1.0)<3.0e-9) && (iter<200.0));
    return exp(-x + a*log(x) - gln)*h;
}
//=======================================================================================
//               To compute the p value in a 2 sided t-test use:
//                  BetaI(0.5*df, 0.5, df/(df+t*t));//df=degrees of freedom, t is t value
//Inclomplete Beta function
//Numerical recipes in c
double BetaCF(double a, double b, double x);
//=======================================================================================
double BetaI(double a, double b, double x)
{

    double bt;

    if (x<0.0)
        x=0.0;
    if (x>1.0)
        x=1.0;

    if ((x<=0.0) || (x>=1.0))
        bt=0.0;
    else
        bt=exp(GammaFunctionLog(a+b) - GammaFunctionLog(a) - GammaFunctionLog(b) +
               a*log(x) + b*log(1.0-x));

    if (x < (a+1.0)/(a+b+2.0))
        return bt*BetaCF(a,b,x)/a;
    return 1.0-bt*BetaCF(b,a,1.0-x)/b;

}
//=======================================================================================
//compute the T value given: p, the degrees of freedom, and one or two sided
//=======================================================================================
double Tvalue(double p, double df, int OneSided)
{
    double DfDt;
    double delta;
    double a = (OneSided) ? 0.5:1.0;
    double T,T1;
    double pa,pb;
    int count=0;

    T=0.0;
    do
        {
            pa = BetaI(0.5*df, 0.5, df/(df + T*T))*a;

            T1 = T + 1.0e-3;
            pb = BetaI(0.5*df, 0.5, df/(df + T1*T1))*a;

            DfDt = (pb-pa)/1.0e-3;

            if (fabs(DfDt)>0.0)
                {
                    delta = (p-pa)/DfDt;
                    T += delta;
                }
            else
                delta=0.0;
            count++;
        }
    while ( (fabs(DfDt)>0.0) && (fabs(delta)>1.0e-6) && (count<100) );

    return T;

}
int TestTvalue(void)
{
    char txt[256];
    double T;

    T=Tvalue(0.01, 10, 1);
    sprintf(txt,"%f",T);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}

//=======================================================================================
//compute the Z value given p
//p is the percentile of the Normal distribution
//used in fMRI
//=======================================================================================
double Zvalue(double p)
{

    double sign;
    double Z;
    double ptry;
    double MaxZmagnitude=20;
    double Zlo,Zhi;
    double error=0.01;
    int count=0;

    if (p>=1.0)
        p=1.0;
    if (p<=0.0)
        p=0.0;

    sign=1.0;
    if (p>0.5)
        {
            sign=-1.0;
            p=1.0-p;
        }


    Zlo=-MaxZmagnitude;
    Zhi=0.0;
    do
        {
            Z=Zlo + (Zhi-Zlo)/2.0;
            ptry = StandardNormalTailArea(Z/M_SQRT2);

            if ((ptry>p) && (Z<Zhi))
                Zhi=Z;
            else if ((ptry<p) && (Z>Zlo))
                Zlo=Z;
            count++;
        }
    while ( ((Zhi-Zlo)>error) && (count<20) );
    return sign*Z;

}
int TestZvalue(void)
{
    char txt[256];
    double Z;
    double p=2.0e-28;

    Z=Zvalue(p);
    sprintf(txt,"%g %f",p,Z);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}

//=======================================================================================
//CONVERT A Z SCORE TO A t STATISTIC
//limit t to -limit<=t<=limit
//=======================================================================================
double TstatisticFromZscore(double Z, int df)
{
    double tlo,thi,t;
    double error=0.0001;
    double p;
    double ztry;
    double limit=100.0;
    int counter=0;



    if (df<1)
        return 0.0;

    //start with t=Z as the first approximation
    t=-fabs(Z);//make it negative because then the p-value will be accurate (dont have to subtract from 1, which causes rounding)
    do
        {
            t-=0.1;
            p=TwoSidedTtest(t, df)/2.0;
            ztry = Zvalue(p);
        }
    while ((ztry>=-fabs(Z)) && (t>-limit));
    tlo=t;
    if (t<-limit)
        return ztry;


    t=-fabs(Z);
    do
        {
            t+=0.1;
            p=TwoSidedTtest(t, df)/2.0;
            ztry = Zvalue(p);
        }
    while ((ztry<=-fabs(Z)) && (t<0.0));
    thi=t;
    if (t>limit)
        return ztry;

    do
        {
            t=tlo + (thi-tlo)/2.0;
            p=TwoSidedTtest(t, df)/2.0;
            ztry = Zvalue(p);

            if ( (ztry>=-fabs(Z)) )
                thi=t;
            else if ( (ztry<-fabs(Z)) )
                tlo=t;

            counter++;

        }
    while (counter<200 && fabs(-fabs(Z)-ztry)>error);

    //for extreme values the conversion wont work because there is insufficient numerical precision
    if (fabs(t)<fabs(Z))
        t=Z;

    if (Z>0.0)
        return -t;
    return t;
}
//=======================================================================================
int TestTstatisticFromZscore(void)
{
    double t1;
    int df;
    double Z;
    FILE *fp=NULL;

    if (!(fp=fopen("c:\\temp\\ZtoT.csv","w")));

    for (Z=-10.0; Z<=10.0; Z+=0.5)
        {
            fprintf(fp,"%f,",Z);
            for (df=5; df<=30; df++)
                {
                    t1=TstatisticFromZscore(Z, df);
                    //z1=ZscoreFromT(t1, df);
                    fprintf(fp,"%f,",t1);
                }
            fprintf(fp,"\n");
        }


    if (fp)
        fclose(fp);

    return 0;
}
//=======================================================================================
//CONVERT A t STATISTIC TO A Z SCORE
//USE THE NORMAL APPROXIMATION TO THE STUDENTS t DISTRIBUTION
//A corrected normal approximation for the Student’s t distribution
//Baibing Li, Bart De Moor 1998
//modified (3/11/2016) to use TwoSidedTtest of only -ve t values
//+ve t values are handled by multiplying the Zvalue by -1
//=======================================================================================
double ZscoreFromT(double t, int df)
{
    double p;

    if (df<1)
        return 0.0;

    if (t<0.0)
        p=TwoSidedTtest(t, df)/2.0;
    else
        p=TwoSidedTtest(-t, df)/2.0;

    if (t>0.0)
        return -Zvalue(p);
    return Zvalue(p);
}
int TestZscoreFromT(double t, int df)
{
    double Z=ZscoreFromT(t,df);
    char txt[256];
    sprintf(txt,"t=%f dof=%d Z=%f",t,df,Z);
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}


// Compute the complete Beta function beta(x,y)
//Numerical recipes in c
//=======================================================================================
double BetaComplete(double x, double y)
{
    if ((x<=0.0) || (y<=0.0))
        return 0.0;
    return exp(GammaFunctionLog(x) + GammaFunctionLog(y) - GammaFunctionLog(x + y));
}
//=======================================================================================
//t distribution
//=======================================================================================
double tdist(double t, double dof)
{
    double lg1=GammaFunctionLog( (dof + 1.0)/2.0 );
    double lg2=GammaFunctionLog( (dof)/2.0 );
    double a=-(dof+1.0)/2.0*log(1.0 + t*t/dof);

    return exp( -log(sqrt(dof*3.14159265359))  + lg1 - lg2  + a );
}
int Test_tdist(double t, int dof)
{
    char txt[256];
    sprintf(txt,"t=%f dof=%d p=%g",t,dof,tdist(t,dof));
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}



//=======================================================================================
//compare two models to see if there is evidence that the more complex model fits better
//RSSred is the residual sum of squares of the reduced model, with dfred
//RSSfull is the residual sum of squares of the complete model, with dffull
//compute F=((RSSred-RSSfull)/(dfred-dffull)) / (RSSfull/dffull)
//compare to a cumulative F distribution
//http://en.wikipedia.org/wiki/F-test
//=======================================================================================
double CompareModels(double RSSred, int dfred, double RSSfull, int dffull)
{
    double F, Fp;
    double x;

    if (dfred<=0 || dffull<=dfred)
        return 1.0;

    F = ((RSSred-RSSfull)/(dfred-dffull)) / (RSSfull/dffull);

    x = (dfred-dffull)*F/((dfred-dffull)*F+dffull);

    return Fp = 1.0 - Fcf((dfred-dffull), dffull, x);
}
//=======================================================================================
//F(alpha;d1,d2) distribution
//returns the cumulative f distribution {0,1}
//=======================================================================================
double Fcf(int df1, int df2, double alpha)
{
    double x;

    x = df1*alpha/(df1*alpha+df2);

    return BetaI((double)df1/2.0, (double)df2/2.0, x);
}
//=======================================================================================
//test Fcf
//=======================================================================================
int TestFcf(void)
{
    double x;
    FILE *fp;

    fp=fopen("c:\\temp\\fcf.csv","w");
    for (x=0.0; x<10.0; x+=0.1)
        {
            fprintf(fp,"%f, %f\n", x, Fcf(1, 20, x));
        }
    fclose(fp);
    return 1;
}


//=======================================================================================
//continued fraction evaluation from numerical recipesl used by BetaI
//=======================================================================================
double BetaCF(double a, double b, double x)
{

    int m,m2;
    float aa,c,d,del,h,qab,qam,qap;

    qab=a+b;
    qap=a+1.0;
    qam=a-1.0;
    c=1.0;
    d=1.0-qab*x/qap;
    if (fabs(d)<1.0e-30)
        d=1.0e-30;
    d=1.0/d;
    h=d;
    for (m=1; m<=100; m++)
        {
            m2=2*m;
            aa=m*(b-m)*x/((qam+m2)*(a+m2));
            d=1.0+aa*d;
            if (fabs(d)<1.0e-30)
                d=1.0e-30;
            c=1.0+aa/c;
            if (fabs(c)<1.0e-30)
                c=1.0e-30;
            d=1.0/d;
            h*=d*c;
            aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
            d=1.0+aa*d;
            if (fabs(d)<1.0e-30)
                d=1.0e-30;
            c=1.0+aa/c;
            if (fabs(c)<1.0e-30)
                c=1.0e-30;
            d=1.0/d;
            del=d*c;
            h*=del;
            if (fabs(del-1.0)<3.0e-7)
                break;

        }
    return h;
}
//=======================================================================================
//Test the incomplete Beta function (BetaI) to see if it gives the right p-values
//=======================================================================================
int TestBetaI(void)
{

    double p;
    double t;
    int df;
    char txt[256];

    df=10;
    t=1.0;
    p=BetaI(0.5*df, 0.5, df/(df+t*t));//should be 0.34089

    sprintf(txt,"df=%d  t=%f  p=%f",df,t,p);
    MessageBox(NULL,txt,"",MB_OK);


    df=10;
    t=2.0;
    p=BetaI(0.5*df, 0.5, df/(df+t*t));//should be 0.073388

    sprintf(txt,"df=%d  t=%f  p=%f",df,t,p);
    MessageBox(NULL,txt,"",MB_OK);

    df=20;
    t=2.0;
    p=BetaI(0.5*df, 0.5, df/(df+t*t));//should be 0.059266

    sprintf(txt,"df=%d  t=%f  p=%f",df,t,p);
    MessageBox(NULL,txt,"",MB_OK);

    df=100;
    t=2.0;
    p=BetaI(0.5*df, 0.5, df/(df+t*t));//should be 0.048212

    sprintf(txt,"df=%d  t=%f  p=%f",df,t,p);
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}
//=======================================================================================
//https://en.wikipedia.org/wiki/Owen%27s_T_function
/*
OwensT(2.5, 0.75)
# should give [1]  0.002986697
# value from Owen's tables is 0.002987
OwensT(2.5, -0.75)
# should give [1] -0.002986697*/
//=======================================================================================
double OwensT(double h, double a)
{
    return  Integrate(0.0, a, 1000, 1.0e-4, OwensTintegrand, &h);
}
double OwensTintegrand(double x, void*vh)
{
    double *h=(double *)vh;
    return exp(-(*h)*(*h)*(1.0+x*x)/2)/(1.0+x*x)/2.0/PI;
}
int TestOwensT(double h, double a)
{
    char txt[256];
    sprintf(txt,"%f",OwensT(h,a));
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}
//=======================================================================================
//         Two sided t-test
//=======================================================================================
double TwoSidedTtest(double t, int df)
{
    return BetaI(0.5*df, 0.5, df/(df+t*t));
}
int TestTwoSidedTtest(void)
{

    double p1,p2;
    double t;
    int df;
    FILE *fp;

    fp=fopen("c:/temp/ttest.txt","w");


    df=5;
    for (t=0.0; t<50.0; t+=0.2)
        {
            p1=BetaI(0.5*df, 0.5, df/(df+t*t));
            p2=TwoSidedTtest(t, df);
            fprintf(fp,"%f %f\n",p1,p2);
        }
    fclose(fp);

    return 1;
}
//=======================================================================================
//compute the area under the tails of a standard normal distribution
//this is a one tailed test p-value
//this is the integral{|x|}{inf}N(0,1)
//OR equally the integral{-inf}{-|x|}N(0,1)
//THE OUTPUT HAS A MAXIMUM OF 1
//NOTE THAT x=Z/SQRT(2). SO IF YOU WANTED THE P VALUE GIVEN Z YOU NEED TO DIVIDE Z BY SQRT(2)
//=======================================================================================
double StandardNormalTailArea(double x)
{
    double t,z;

    z=fabs(x);

    t=1.0/(1.0+0.5*z);
    return  0.5*t*exp(-z*z - 1.26551223 + t*(1.00002368 + t*(0.37409196 + t*(0.09678418 +
                      t*(-0.18628806 + t*(0.27886807 + t*(-1.13520398 + t*(1.48851587 +
                                          t*(-0.82215223 + t*0.17087277)))))))));

}

//=======================================================================================
int TestStandardNormalTailArea(void)
{
    double x;
    char fname[MAX_PATH];
    FILE *fp;

    sprintf(fname,"%s\\tail.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");

    for (x=0.0; x<=5.0; x+=0.1)
        {
            if (fp)
                fprintf(fp,"%f, %g\n",x,StandardNormalTailArea(x/M_SQRT2));
        }


    fclose(fp);
    return 0;
}

//=======================================================================================
//compute approximation to the error function erf()
//this has a fractional error<1.2e-7
//Numerical recipes p221
//this function produces finite values for -8.3<=x<=8.3
//=======================================================================================
double ErrorFunction(double x)
{

    double ans;

    ans=2.0*StandardNormalTailArea(x);

    return (x>=0.0) ? (1.0 - ans) : (ans - 1.0);
}

//=======================================================================================
int TestErrorFunction(void)
{
    double x;
    FILE *fp=NULL;

    if (!(fp=fopen("c:\\temp\\err.csv","w")))
        return 0;
    for (x=-10.0; x<10.0; x+=0.1)
        {
            fprintf(fp,"%f,%8.15e\n",x,ErrorFunction(x/M_SQRT2));//this is actually the NormalCDF
            //if (x<0.0) fprintf(fp,"%f,%8.15e\n",x,(double)(0.5 + 0.5*ErrorFunction(x/M_SQRT2)));//this is actually the NormalCDF
            //else fprintf(fp,"%f,%8.15e\n",x,(double)(1.0 - (0.5 + 0.5*ErrorFunction(x/M_SQRT2))));//this is actually the NormalCDF
        }
    fclose(fp);

    return 1;
}
//=======================================================================================
//COMPUTE THE ERROR FUNCTION FOR LARGE MAGNITUDE OF Z
//THIS IS FROM Algorithms with Guaranteed Error Bounds for the Error Function and the
//Complementary Error Function
//Large x is > 6
//=======================================================================================
double ErrorFunctionC_Large_x(double x)
{

    double p[5]= {5.64189583547756078e-1,
                  8.80253746105525775,
                  3.84683103716117320e1,
                  4.77209965874436377e1,
                  8.08040729052301677
                 };
    double q[5]= {1.0,
                  1.61020914205869003e1,
                  7.54843505665954743e1,
                  1.12123870801026015e2,
                  3.73997570145040850e1
                 };
    double p4,q4;
    int i;


    p4=p[0];
    q4=q[0];
    for (i=1; i<5; i++)
        {
            p4 += p[i]/pow(x,2*i);
            q4 += q[i]/pow(x,2*i);
        }

    return exp(-x*x)*p4/q4/x;
}
int TestErrorFunctionC_Large_x(void)
{
    double x;
    FILE *fp=NULL;

    if (!(fp=fopen("c:\\temp\\err.csv","w")))
        return 0;
    for (x=1.0; x<10.0; x+=0.1)
        {
            if (x<0.0)
                fprintf(fp,"%f,%8.15e\n",x,(double)(ErrorFunctionC_Large_x(x/M_SQRT2)));//this is actually the NormalCDF
            else
                fprintf(fp,"%f,%8.15e\n",x,(double)(ErrorFunctionC_Large_x(x/M_SQRT2)));//this is actually the NormalCDF
        }
    fclose(fp);

    return 1;
}


//=======================================================================================
//truncated normal distribution
//a & b are the lower and upper truncation points
//returns 0 if x outside range defined by a & b
//=======================================================================================
double TruncatedNormal(double mean, double v, double x, double a, double b)
{
    double lo,hi;
    double norm;

    if (a==b)
        return 0.0;

    lo=(a<b) ? a:b;
    hi=(lo==a) ? b:a;

    if (x<lo || x>hi)
        return 0.0;

    norm=NormalCDF(hi, mean, sqrt(v))-NormalCDF(lo, mean, sqrt(v));
    //if (norm<=0.0) MessageBox(NULL,"TruncatedNormal","",MB_OK);


    return NormalDistribution(mean,v,x)/norm;

}
//=======================================================================================
//truncated normal distribution
//a & b are the lower and upper truncation points
//returns 0 if x outside range defined by a & b
//=======================================================================================
double TruncatedNormalCDF(double mean, double v, double x, double a, double b)
{
    double lo,hi;
    double norm;
    double CDFlo;
    double sd;

    if (v<=0.0)
        return 0.0;
    sd=sqrt(v);

    if (a==b)
        return 0.0;

    lo=(a<b) ? a:b;
    hi=(lo==a) ? b:a;

    if (x<=lo)
        return 0.0;
    if (x>=hi)
        return 1.0;

    CDFlo=NormalCDF(lo, mean, sd);
    norm=NormalCDF(hi, mean, sd)-CDFlo;

    return (NormalCDF(x,mean,sd)-CDFlo)/norm;

}
//=======================================================================================
//=======================================================================================
double NormalDistribution(double mean, double v, double x)
{
    /*	if (v<=0.0)
    		return 0.0;

    	return exp(-(x-mean)*(x-mean)/2.0/v)/sqrt(2.0*PI*v);*/
    return dNorm(x, mean, v);
}
//=======================================================================================
//Gaussian Distribution CDF
//=======================================================================================
double NormalCDF(double x, double mean, double sd)
{
    double z;
    if (sd<=0.0)
        return 0.0;

    z=(x-mean)/sd/M_SQRT2;

    return 0.5*(1.0 + ErrorFunction(z));

}
int TestNormalCDF(double x, double mean, double sd)
{
    char txt[256];
    double q=NormalCDF(x,mean,sd);
    sprintf(txt,"%f",q);
    MessageBox(NULL,txt,"",MB_OK);
    return 1;
}
//=======================================================================================
//Normal distribution
//=======================================================================================
double dNorm(double x, double m, double v)
{

    if (v<=0.0)
        return 0.0;

    return exp(-(x-m)*(x-m)/2.0/v)/SQRT_2PI/sqrt(v);
}

//=======================================================================================
//bivariate normal distribution
//=======================================================================================
double BivariateNormal(double x, double y, double mx, double my, double vx, double vy, double rho)
{
    double vxvy=vx*vy;
    double rho2=rho*rho;

    if (rho2>=1.0 || vx<=0.0 || vy<=0.0)
        return 0.0;

    return exp(-( (x-mx)*(x-mx)/vx + (y-my)*(y-my)/vy - 2.0*rho*(x-mx)*(y-my)/sqrt(vxvy) )/2.0/(1.0-rho2)) /
           PIx2/sqrt(vxvy*(1.0-rho2));
}


/*
library(plotly)

BVN<-read.table("c:\\temp\\bivariatenorm.txt",header=T)

BVNdf<-as.data.frame(BVN)

plot_ly(x=BVNdf$x, y=BVNdf$y, z=BVNdf$z)
*/
int TestBivariateNormal(void)
{
    double mx=0.0;
    double my=0.0;
    double vx=1.0;
    double vy=1.0;
    double rho=0.5;
    double x,y;
    FILE *fp=NULL;

    if (!(fp=fopen("c:\\temp\\bivariatenorm.txt","w")))
        return 0;

    fprintf(fp,"x y z\n");
    for (x=-3.0; x<=3.0; x+=0.2)
        {
            for (y=-3.0; y<=3.0; y+=0.2)
                {
                    fprintf(fp,"%f %f %f\n",x,y,BivariateNormal(x,y,mx,my,vx,vy,rho));
                }
        }
    fclose(fp);
    return 1;
}

//=====================================================================================================
//Given the Bivariate Normal distribution parameters
//What are the conditional normal distributions?
//=====================================================================================================
int BivariateNormYgivenX(double x, double mx, double my, double vx, double vy, double rho,
                         double *myGivenX, double *vyGivneX, double *prefactor)
{
    return BivariateNormXgivenY(x, my, mx, vy, vx, rho, myGivenX, vyGivneX, prefactor);
}
int BivariateNormXgivenY(double y, double mx, double my, double vx, double vy, double rho,
                         double *mxGivenY, double *vxGivneY, double *prefactor)
{

    double rho2=rho*rho;
    if (rho2>=1.0 || vx<=0.0 || vy<=0.0)
        {
            *mxGivenY=0.0;
            *vxGivneY=0.0;
            *prefactor=0.0;
            return 0;
        }

    *vxGivneY = (1.0-rho2)*vx;
    *mxGivenY = mx + rho*(y-my)*sqrt(vx/vy);
    *prefactor = SQRT_2PI*sqrt(*vxGivneY)*BivariateNormal((*mxGivenY), y, mx, my, vx, vy, rho);

    return 1;
}
int TestBivariateNormXgivenY(void)
{

    double mx=0.0;
    double my=2.0;
    double vx=1.0;
    double vy=1.5;
    double vyg;
    double myg;
    double a;
    double z;
    double rho=-0.5;
    double x,y;
    FILE *fp=NULL;



    if (!(fp=fopen("c:\\temp\\bivariatenorm.csv","w")))
        return 0;
    fprintf(fp,"x,y,z,z1\n");
    for (y=-3.0; y<=3.0; y+=0.2)
        {
            BivariateNormXgivenY(y, mx, my, vx, vy, rho, &myg, &vyg, &a);
            for (x=-3.0; x<=3.0; x+=0.2)
                {
                    z=a*dNorm(x,myg, vyg);
                    fprintf(fp,"%f,%f,%f,%f\n",x-mx,y-my,BivariateNormal(x,y,mx,my,vx,vy,rho),z);
                }
        }
    fclose(fp);

    return 1;
}
//=======================================================================================
//generate sample from multivariate (N) normal distribution
//=======================================================================================
int rMVnorm(double s[], double mean[], double Sigma[], int N)
{
    int result=0;
    int i,r,c, rN;
    double *L=NULL;
    double *n=NULL;
    struct TwoNorm tn;

    if (!(L=(double *)malloc(N*N*sizeof(double))))
        goto END;

    if (!(n=(double *)malloc(N*sizeof(double))))
        goto END;

    if (!Cholesky(Sigma, N, L))
        goto END;

    //generate N standard, independent, normals
    for (i=0; i<N-N%2; i+=2)
        {
            tn=Gauss2RandomNumbers_BoxMuller(0.0, 1.0);
            n[i] = tn.x;
            n[i+1] = tn.y;
        }
    if (N%2)
        n[N-1] = GaussRandomNumber_BoxMuller(0.0, 1.0);

    //now generate the multivariate sample
    for (r=0; r<N; r++)
        {
            rN=r*N;
            s[r]=mean[r];
            for (c=0; c<=r; c++)
                {
                    s[r] += L[rN+c]*n[c];
                }
        }

    result=1;
END:
    if (L)
        free(L);

    if (n)
        free(n);

    return result;
}
int TestrMVnorm(void)
{
    int N=3;
    double sd1=0.5;
    double sd2=1.0;
    double sd3=1.5;
    double rho12=0.5;
    double rho13=-0.5;
    double sample[3];
    double mean[3]= {0.0,1.0,2.0};
    double S[9]= {sd1*sd1, sd1*sd2*rho12, sd1*sd3*rho13,        sd1*sd2*rho12, sd2*sd2, 0.0,      sd1*sd3*rho13, 0.0, sd3*sd3};
    double x[1000];
    double y[1000];
    double z[1000];
    int i;
    char txt[256];

    for (i=0; i<1000; i++)
        {
            rMVnorm(sample, mean, S, N);
            x[i]=sample[0];
            y[i]=sample[1];
            z[i]=sample[2];
        }

    sprintf(txt,"%f %f %f\n%f %f %f\n%f %f %f\n",MeanValueDouble(1000,x),MeanValueDouble(1000,y), MeanValueDouble(1000,z),
            Var(x,1000), Var(y, 1000), Var(z,1000),
            Pearsons(x,y,1000), Pearsons(x,z,1000), Pearsons(y,z,1000));
    MessageBox(NULL,txt,"",MB_OK);


    return 0;
}

//=======================================================================================
double MultiVariateNormalDensity(double s[], double mean[], double Sigma[], int N)
{
    double f=0.0;
    double *inv=NULL;
    double *d=NULL;
    double sum;
    double exponent;
    double det;
    int i,j,k;

    if (N<=0)
        return 0.0;

    if (!(inv=(double *)malloc(N*N*sizeof(double))))
        goto END;

    if (!(d=(double *)malloc(N*sizeof(double))))
        goto END;

    memcpy(inv,Sigma,N*N*sizeof(double));
    if ( (det=fabs(Determinant(inv, N)))<=0.0 )
        goto END;
    memcpy(inv,Sigma,N*N*sizeof(double));
    if (!InvertMatrixA(inv,N))
        goto END;

    for (i=0; i<N; i++)
        d[i] = s[i]-mean[i];

    exponent=0.0;
    k=0;
    for (i=0; i<N; i++)
        {
            sum=0.0;
            for (j=0; j<N; j++)
                {
                    sum += d[j]*inv[j + k];
                }
            k+=N;
            exponent += sum*d[i];
        }
    f=exp(-exponent/2.0)/sqrt(pow(2.0*PI,N)*det);

END:
    if (inv)
        free(inv);

    if (d)
        free(d);

    return f;
}
//=======================================================================================
//produce a random sample from the bivariate normal distribution
//=======================================================================================
int rBivariateNorm(struct Bivariate *rB, double mx, double my, double sx, double sy, double rho)
{
    struct TwoNorm tn;
    double rho2;

    if (sx<=0.0 || sy<=0.0 || (rho2=rho*rho)>1.0)
        return 0;

    tn=Gauss2RandomNumbers_BoxMuller(0.0, 1.0);

    (*rB).x = mx + sx*tn.x;
    (*rB).y = my + sy*(tn.x*rho + tn.y*sqrt(1.0-rho2));

    return 1;
}
int TestrBivariateNorm(void)
{
    double x[100];
    double y[100];
    int N=100;
    int i;
    struct Bivariate B;
    char txt[256];

    for (i=0; i<N; i++)
        {
            rBivariateNorm(&B, 1.0, 3.0, 1.0, 1.5, -0.7);
            x[i] = B.x;
            y[i] = B.y;
        }

    sprintf(txt,"%f %f %f %f %f",MeanValueDouble(N, x), MeanValueDouble(N,y), sqrt(Var(x,N)), sqrt(Var(y,N)), Pearsons(x,y,N));
    MessageBox(NULL,txt,"",MB_OK);

    return 0;

}




//=======================================================================================
//Do Man Whitney U test for H0 equal distributions
//https://en.wikipedia.org/wiki/Mann%E2%80%93Whitney_U_test
//=======================================================================================
double MannWhitney(double X[], int nX, double Y[], int nY, int Alternative)
{
    double *Z=NULL;
    double *rank=NULL;
    int *sort=NULL;
    int N=nX+nY;
    int i,j,k;
    double p=1.0;
    double sum;
    double TieCorrection=0.0;
    double R1,R2;
    double U1,U2,U;

    //this test is either 1 tailed or two tailed.
    if ((Alternative!=TWO_TAILED) && (Alternative!=X_GT_Y) && (Alternative!=Y_GT_X))
        {
            MessageBox(NULL,"Alternative unknown in MannWhitney","",MB_OK|MB_ICONWARNING);
            return 1.0;
        }



    if (!(Z=(double *)malloc(N*sizeof(double))))
        goto END;

    if (!(rank=(double *)malloc(N*sizeof(double))))
        goto END;

    if (!(sort=(int *)malloc(N*sizeof(int))))
        goto END;

    j=0;
    for (i=0; i<nX; i++)
        {
            Z[j] = X[i];
            j++;
        }
    for (i=0; i<nY; i++)
        {
            Z[j] = Y[i];
            j++;
        }

    //get the ranks
    QuickSort(Z,sort,N);
    for (i=0; i<N; i++)
        rank[sort[i]] = (double)(i+1); //the rank starts at 1

    //get the ties
    i=0;
    do
        {
            sum=rank[sort[i]];
            j=i+1;
            while ((j<N) && (Z[sort[j]]==Z[sort[i]]))
                {
                    sum+=rank[sort[j]];
                    j++;
                }

            if (j>(i+1))
                {
                    for (k=i; k<j; k++)
                        rank[sort[k]] = sum/(j-i);
                    TieCorrection += (double)((j-i)*(j-i)*(j-i) - (j-i));
                }
            i=j;
        }
    while(i<N-1);

    //sum of ranks in group 1;
    R1=0.0;
    for (i=0; i<nX; i++)
        R1 += rank[i];

    U1 = R1 - (double)nX*(nX+1)/2;


    //sum of ranks in group 2;
    R2=0.0;
    for (i=nX; i<N; i++)
        R2 += rank[i];

    U2 = R2 - (double)nY*(nY+1)/2;

    switch(Alternative)
        {
        case TWO_TAILED:
            U = (U1<U2) ? U1 : U2;
            break;


        case X_GT_Y:
            U=U1;
            break;

        case Y_GT_X:
            U=U2;
            break;

        default:
            p=1.0;
            goto END;
            break;
        }


    p =1.0 - NormalCDF(U, (double)nX*nY/2, sqrt(   (double)nX*nY*(   (double)(N+1) - TieCorrection/(N*(N-1))     )/12   ));


    if (Alternative==TWO_TAILED)
        {
            if (p>0.05)
                p=1.0-p;
            p*=2.0;
        }

END:
    if (Z)
        free(Z);

    if (sort)
        free(sort);

    if (rank)
        free(rank);

    return p;
}
//===========================================================================================================
int TestMannWhitney(void)
{
    double X[10]= {0.0, 0.0, 1.89, 1.04, 1.45,1.38, 1.91, 1.64, 0.73, 1.64};
    double Y[5]= {5.15, 2.88, 3.88, 0.74,2.21};
    double p=MannWhitney(X,10,Y,5,X_GT_Y);
    double p2=MannWhitney(X,10,Y,5,Y_GT_X);
    double p3=MannWhitney(X,10,Y,5,TWO_TAILED);
    char txt[256];

    sprintf(txt,"%f %f %f",p,p2,p3);
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}


//=======================================================================================
//Multivariate generalisation of t test
//=======================================================================================
double MultivariateTtest(double m1[], double m2[], int D, double V1[], int n1, double V2[], int n2)
{
    double *C=NULL;//covariance matrix estimate
    double *a=NULL;
    double p=-1.0;
    int i,j,k;

    if (n1<2 || n2<2)
        goto END;

    if (!(C=(double *)calloc(D*D,sizeof(double))))
        goto END;
    if (!(a=(double *)calloc(D,sizeof(double))))
        goto END;

    //get pooled covariance matrix
    for (k=0; k<n1; k++)
        {
            for (i=0; i<D; i++)
                {
                    for (j=0; j<D; j++)
                        {
                            C[i+j*D]+= V1[k+i*n1]*V1[k+j*n1];
                        }
                }
        }
    for (k=0; k<n2; k++)
        {
            for (i=0; i<D; i++)
                {
                    for (j=0; j<D; j++)
                        {
                            C[i+j*D]+= V2[k+i*n1]*V2[k+j*n1];
                        }
                }
        }
    for (i=0; i<D; i++)
        {
            for (j=0; j<D; j++)
                C[i+j*D]/=(n1+n2-2);
        }
    if (!InvertMatrixA(C,D))
        goto END;




END:
    if (C)
        free(C);
    if (a)
        free(a);
    return p;
}











//=======================================================================================
//compute the FDR based threshold and return it
//=======================================================================================
double FDR(double p[], int N, double critical)
{
    int i;
    int *sort=NULL;
    double q=0.0;
    //FILE *fp;

    //fp=fopen("c:\\temp\\fdr.txt","w");

    if (!(sort=(int *)malloc(sizeof(int)*N)))
        goto END;

    QuickSort(p, sort, N);

    for (i=0; i<N; i++)
        {
            //if (((critical*(i+1))/N)>=p[sort[i]]) q=critical*(i+1)/N;
            if (((critical*(i+1))/N)>=p[sort[i]])
                q=p[sort[i]];
            //if (fp) fprintf(fp,"%f %f\n",p[sort[i]], critical*(i+1)/N);
        }
    //if (fp) fclose(fp);
END:
    if (sort)
        free(sort);

    return q;
}
//=======================================================================================
//THIS IS AN EXTENTION OF FDR WHERE THE NUMBER OF TESTS IS BIGGER THAN THE NUMBER OF P VALUES
//THIS HAPPENS WHEN SOME TESTS ARE NOT DONE BECAUSE IT IS KNOWN THE P VALUE IS > FDR
//=======================================================================================
double FDRext(double fdr, double p[], int Np, int Nall)
{
    double q=0.0;
    double expected;
    int i;
    int *sort=NULL;

    if (!(sort=(int *)malloc(sizeof(int)*Np)))
        goto END;

    QuickSort(p, sort, Np);
    for (i=0; i<Np; i++)
        {
            expected=p[sort[i]]*Nall;
            if (expected/(i+1)<=fdr)
                q=p[sort[i]];
        }

END:
    if (sort)
        free(sort);
    return q;
}
//=======================================================================================
//COMPUTE FDR ESTIMATES
//=======================================================================================
int EstimateFalseDiscoveryRate(double p[], double fdr[], int N)
{
    int i;
    int *sort=NULL;
    int result=0;


    if (!(sort=(int *)malloc(sizeof(int)*N)))
        goto END;

    QuickSort(p, sort, N);

    for (i=0; i<N; i++)
        {
            fdr[sort[i]] = p[sort[i]]*N/(i+1);
        }



    result=1;
END:
    if (sort)
        free(sort);

    return result;
}


//=======================================================================================
//return the number of combinations of k from N
//order doesnt matter
//=======================================================================================
double Combinations(int N, int k)
{

    if ((k<0) || (N<=0) || (k>N))
        return 0.0;
    if (k==0)
        return 1.0;

    return exp(LogFactorial(N) - LogFactorial(k) - LogFactorial(N-k));

}
int TestCombinations(void)
{
    char txt[256];
    int N,n;

    N=500*((double)rand()/RAND_MAX);
    n=N*((double)rand()/RAND_MAX);

    sprintf(txt,"%d %d %e",N,n,Combinations(N,n));
    MessageBox(NULL,txt,"",MB_OK);
    return 1;
}
//=======================================================================================
//do Fisher's p value for a given table
//THIS IS NOT FISHERS TEST.
//Fishers exact test can be performed by adding the appropriate set of these p-values
//Table:
//a b
//c d
//returns the p-value
//http://en.wikipedia.org/wiki/Fisher's_exact_test
//=======================================================================================
double FishersP(int a, int b, int c, int d)
{

    double logp;

    logp=LogFactorial(a+b) + LogFactorial(c+d) + LogFactorial(a+c) + LogFactorial(b+d)
         - LogFactorial(a) - LogFactorial(b) - LogFactorial(c) - LogFactorial(d) - LogFactorial(a+b+c+d);

    return exp(logp);
}
//=======================================================================================
//Fishers exact Test
//Run through all the tables, and sum the p-values
//Table:
//a b
//c d
//this test counts the proportion of ways (b/(a+b)) / (d/(c+d)) could be equal or larger
//the p value is an indicator of association between 2 variables
//THIS CODE IS FOR A ONE SIDED TEST
//USUALLY IT WOULD BE TWO SIDED
//=======================================================================================
double FishersTestOneSided(int a, int b, int c, int d)
{
    double p=0.0;

    if ((double)c/(c+d)<(double)a/(a+b))//the p value should be the same regardless of which way the table is arranged
        {
            int tmp;
            tmp=a;
            a=c;
            c=tmp;

            tmp=b;
            b=d;
            d=tmp;
        }

    while((a>=0) && (b>=0) && (c>=0) && (d>=0))
        {
            p+=FishersP(a, b, c, d);
            b++;
            a--;
            d--;
            c++;
        }
    if (p>1.0)
        p=1.0;//there are approximations and numerical rounding at work

    return p;
}
int TestFisher(HWND hwnd)
{
    char txt[256];
    int a,b,c,d;

    a=10;
    b=10;
    c=10;
    d=1;
    sprintf(txt,"%d %d \n%d %d\n %f\n",a,b,c,d,FishersTestOneSided(a, b, c, d));

    MessageBox(hwnd,txt,"",MB_OK);
    return 0;

}
//compute the p value using p=FishersTestOneSided(n/2, n/2, 0, n)*tests
int TestFisherForPaper(HWND hwnd, int n,int tests)
{
    int a,b,c,d;
    FILE *fp;

    fp=fopen("c://temp//fisher.csv","a");

    a=n/2;
    b=n/2;
    c=0;
    d=n;
    fprintf(fp,"%d,%f,%d\n",n,FishersTestOneSided(c, d, a, b)*tests,tests);

    fclose(fp);

    return 0;

}

//=======================================================================================
//compute the CDF of the Binomial distribution function
//=======================================================================================
double BinomialCDF(double p, int N, int n)
{
    //int i;
    //double Nfact = Factorial(N);
    //double sum;

    if (n>N)
        return 1.0;

    return BetaI((double)(N-n), 1.0+(double)n, 1.0-p);
    /*sum=0.0;
    for (i=0; i<=n; i++)
    {
        //sum += Nfact/(Factorial(i)*Factorial(N-i))*pow(p,i) * pow(1.0-p, N-i);
        sum += BinomialP(p,N,n);
    }

    return sum;*/
}
int TestBinomialCDF(void)
{
    double p=0.01;
    int N=350;
    int n=7;
    char txt[256];

    sprintf(txt,"%f %d %d: %f", p, N, n, BinomialCDF(p, N, n));
    MessageBox(NULL,txt,"",MB_OK);
    return 0;
}
//=======================================================================================
//the phi coefficient is like Pearson's correlation for binary variables
//it works on the 2x2 contingency table like Fisher's exact test
//the table is
//a b
//c d
//The range is between -1 and 1
double PhiCoefficient(int a, int b, int c, int d)
{
    int N=a+b+c+d;
    double tmp;

    if (N<=0 || a<0 || b<0 ||c<0 ||d<0)
        return 0.0;

    tmp=(double)((a+b)*(c+d)*(a+c)*(b+d));
    if (tmp<=0.0)
        return 0.0;

    return (double)(a*d-b*c)/sqrt(tmp);
}
//=======================================================================================
double PhiCoefficientBootstrap(int a, int b, int c, int d, double *se)
{

    int N=a+b+c+d;
    int *LU=NULL;
    double phi=PhiCoefficient(a,b,c,d);
    double sum2;
    double PhiSample;
    int iter;
    int SampleABCD[4];
    int r;
    int n;

    if (N<=0 || a<0 || b<0 ||c<0 ||d<0)
        {
            (*se)=1.0;
            return 0.0;
        }

    if (!(LU=(int *)malloc(N*sizeof(int))))
        {
            (*se)=1.0;
            return 0.0;
        }

    n=0;
    do
        {
            LU[n]=0;
            n++;
        }
    while(n<a);

    do
        {
            LU[n]=1;
            n++;
        }
    while(n<a+b);

    do
        {
            LU[n]=2;
            n++;
        }
    while(n<a+b+c);

    do
        {
            LU[n]=3;
            n++;
        }
    while(n<a+b+c+d);


    sum2=0.0;
    for (iter=0; iter<1000; iter++)
        {
            memset(SampleABCD,0,sizeof(int)*4);
            for (n=0; n<N; n++)
                {

                    r=rand()%N;

                    SampleABCD[ LU[r] ]++;
                }
            PhiSample=PhiCoefficient(SampleABCD[0], SampleABCD[1], SampleABCD[2], SampleABCD[3]);

            sum2+=(phi-PhiSample)*(phi-PhiSample);
        }

    (*se)=sqrt(sum2/1000);


    if (LU)
        free(LU);

    return phi;
}
//=======================================================================================
//BINOMIAL PROBABILITY
//=======================================================================================
double BinomialP(double p, int N, int n)
{
    if ( (p<=0.0) )
        {
            if ( n==0 )
                return 1.0;
            else
                return 0.0;
        }
    if ( (p>=1.0) )
        {
            if ( n==N )
                return 1.0;
            else
                return 0.0;
        }
    return Combinations(N, n) * pow(p,n) * pow(1.0-p, N-n);

}

//=======================================================================================
//GENERATE A RANDOM SAMPLE THAT HAS A BINOMIAL DISTRIBUTION
//=======================================================================================
int BinomialRandomSample(double p, int N)
{
    int n=0;
    int i;
    double *plu=NULL;//lookup
    double maxp;
    double r;

    if (!(plu=(double *)malloc((N+1)*sizeof(double))))
        goto END;

    maxp=0.0;
    for (i=0; i<=N; i++)
        {
            if ((plu[i]=BinomialP(p, N, i))>maxp)
                maxp=plu[i];
        }
    maxp/=RAND_MAX;

    do
        {
            n=rand()%(N+1);
            r=maxp*rand();
        }
    while (plu[n]<r);

END:
    if (plu)
        free(plu);

    return n;
}
int TestBinomialRandomSample(void)
{
    FILE *fp;
    int i;
    int H[100];
    int n;

    fp=fopen("c://temp//bin.csv","w");

    memset(H,0,sizeof(int)*100);
    for (i=0; i<10000; i++)
        {
            n=BinomialRandomSample(0.8,99);
            H[n]++;
        }

    for (i=0; i<100; i++)
        {
            fprintf(fp,"%d,%d\n",i,H[i]);
        }
    fclose(fp);

    return 0;
}

//=======================================================================================
//=======================================================================================
//FIND ALL PERMUTATIONS, ONE AT A TIME, USING HEAP'S ALGORITHM
//https://en.wikipedia.org/wiki/Heap%27s_algorithm
//IN THE CALLING ALGORITHM:
//Initialise permutation as permutation[0]=0,,,,, permutation[N-1]=N-1
//Initialise an integer array ci[N] to zero
//Initialise integer i to zero
//EACH CALL TO THIS FUNCTION WILL RETURN A PERMUTATION
//IF -1 IS RETURNED ALL OF THE PERMUTATIONS HAVE BEEN DONE
//=======================================================================================
int PermutationList(int N, int permutation[], int *ci, int *i)
{
    int temp;

    if ((*i)<N)
        {
            if ((*ci)<(*i))
                {
                    if ((*i)%2==0)//if (*i) is even
                        {
                            temp=permutation[0];
                            permutation[0]=permutation[(*i)];
                            permutation[(*i)]=temp;
                        }
                    else
                        {
                            temp=permutation[(*ci)];
                            permutation[(*ci)]=permutation[(*i)];
                            permutation[(*i)]=temp;
                        }

                    (*ci)++;
                    (*i)=0;
                }
            else
                {
                    (*ci)=0;
                    (*i)++;
                    return 0;//no permutation has happened during this call
                }
        }
    else
        return -1;

    return 1;
}
int TestPermutationList(void)
{
    int C[4]= {0,0,0,0};
    int p[4]= {0,1,2,3};
    int i;
    int count=0;
    int result;
    FILE *fp;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\permutations.csv",REPORT_FOLDER);
    fp=fopen(fname,"w");

    i=0;
    count=0;
    fprintf(fp,"%d,%d,%d,%d,%d\n",count,p[0],p[1],p[2],p[3]);
    while(i<4 && (result=PermutationList(4,p,&C[i],&i))>=0)
        {
            if (result==1)
                {
                    count++;
                    fprintf(fp,"%d,%d,%d,%d,%d\n",count,p[0],p[1],p[2],p[3]);
                }
        }

    fclose(fp);
    return 0;
}
//=======================================================================================
//compute the next step in the complete set of permutations of n numbers from N
//each permutation is unique
//set[0]>set[1]>set[2]...>set[n-1]
//=======================================================================================
int NextPermutation(int set[], int n, int N)
{
    int i = 0;
    int success = 0;
    int threshold;

    if (!n)
        {
            set[0]++;
            if (set[0]>N)
                return 0;
            else
                return 1;
        }

    while ((!success) && (i<n))
        {
            threshold = (i==0) ? N:set[i-1]-1;

            if (set[i]<threshold)
                {
                    set[i]++;
                    success = 1;
                }
            else
                {
                    if ( set[i+1] < (set[i]-1))
                        {
                            set[i+1]++;
                            set[i] = set[i+1]+1;
                            success=1;
                        }
                }

            i++;
        }


    return success;
}
int TestNextPermutation(void)
{
    int set[5]= {0,0,0,0,0};
    int N=10;
    int i;
    int success;
    FILE *fp;

    fp=fopen("c:\\temp\\permute.csv","w");
    success=1;
    for (i=0; i<100 && success; i++)
        {
            fprintf(fp,"%d, %d, %d ,%d ,%d\n", set[0], set[1], set[2], set[3], set[4]);
            success=NextPermutation(set, 0, N);
        }

    fclose (fp);
    return 1;
}


//==============================================================================
double PearsonsBootstrap(double X[], double Y[], int N, double *lo, double *hi, double confidence, double *sd, int Samples)
{
    double *Xs=NULL;
    double *Ys=NULL;
    double Rho=Pearsons(X, Y, N);
    double *s=NULL;
    double sum,sum2;
    int sample;
    int *sort=NULL;
    int i,j;

    if (confidence>1.0)
        confidence=1.0;
    if (confidence<0.0)
        confidence=0.0;

    if (Samples<0)
        Samples=1;

    if (!(Xs=(double *)malloc(sizeof(double)*N)))
        goto END;

    if (!(Ys=(double *)malloc(sizeof(double)*N)))
        goto END;

    if (!(s=(double *)malloc(sizeof(double)*Samples)))
        goto END;

    if (!(sort=(int *)malloc(sizeof(int)*Samples)))
        goto END;

    sum=sum2=0.0;
    for (sample=0; sample<Samples; sample++)
        {
            for (i=0; i<N; i++)
                {
                    j=rand()%N;
                    Xs[i]=X[j];
                    Ys[i]=Y[j];
                }
            s[sample] = Pearsons(Xs, Ys, N);
            sum+=s[sample];
            sum2+=s[sample]*s[sample];
        }

    //confidence interval
    QuickSort(s, sort, Samples);
    if (confidence>0.0 && confidence<1.0)
        {
            (*lo)=s[sort[(int)(Samples*(1.0-confidence)/2)]];
            (*hi)=s[sort[(int)(Samples*(confidence + (1.0-confidence)/2))]];
        }

    //standard deviation of the bootstraps
    if (sum2/Samples>sum*sum/Samples/Samples)
        {
            (*sd)=sqrt(sum2/Samples - sum*sum/Samples/Samples);
        }
    else
        {
            (*sd)=0.0;
        }


END:
    if (Xs)
        {
            free(Xs);
        }
    if (Ys)
        {
            free(Ys);
        }
    if (s)
        {
            free(s);
        }
    if (sort)
        {
            free(sort);
        }
    return Rho;
}
//==============================================================================
//compute Pearsons correlation coefficient
//modified 15/2/2018 to make sure not taking sqrt() of -ve number
//==============================================================================
double Pearsons(double X[], double Y[], int N)
{

    double Xmean, Ymean;
    double X2mean, Y2mean;
    double sigmaX, sigmaY;
    double XY;
    double tmp;
    int n;

    if (N<=1)
        return 0.0;

    Xmean=Ymean=0.0;
    X2mean=Y2mean=0.0;
    for (n=0; n<N; n++)
        {
            Xmean += X[n];
            Ymean += Y[n];
            X2mean += X[n]*X[n];
            Y2mean += Y[n]*Y[n];
        }
    Xmean /= N;
    Ymean /= N;
    X2mean /= N;
    Y2mean /= N;

    tmp=X2mean - Xmean*Xmean;
    if (tmp>=DBL_MIN)
        sigmaX=sqrt(tmp);
    else
        sigmaX=0.0;

    tmp=Y2mean - Ymean*Ymean;
    if (tmp>=DBL_MIN)
        sigmaY=sqrt(tmp);
    else
        sigmaY=0.0;

    if ( (sigmaX<DBL_MIN) || (sigmaY<DBL_MIN))
        return 0.0;

    XY=0.0;
    for (n=0; n<N; n++)
        {
            XY += (X[n]-Xmean)*(Y[n]-Ymean);
        }
    XY /= N;

    return XY/sigmaX/sigmaY;
}
//https://en.wikipedia.org/wiki/Pearson_correlation_coefficient
double CorrelationPvalue(double r, int n)
{
    double t;
    double p;

    if (n<=2)
        return 1.0;
    if (fabs(r)==1.0)
        return 0.0;

    t=fabs(r)*sqrt( (double)(n-2)/(1-r*r) );

    p=TwoSidedTtest(t, n-2);

    return p;
}


//==============================================================================
//SIGMOID FUNCTION FOR FORCING VALUES TO BETWEEN 0 AND 1
//==============================================================================
double Sigmoid(double x)
{
    return 1.0/(1.0+exp(-x));
}
double InvSigmoid(double s)
{
    // s*(1+exp(-x)) = 1
    //s*exp(-x) = 1-s
    //exp(-x) = (1-s)/s
    // -x = log( (1-s)/s )
    if (s<0.0)
        return -DBL_MAX;
    if (s>1.0)
        return DBL_MAX;
    return log(s/(1.0-s));
}
//==============================================================================
//SIGMOID FUNCTION FOR FORCING VALUES TO BETWEEN -1 AND 1
//==============================================================================
double Sigmoidpm1(double x)
{
    return 2.0/(1.0+exp(-x))-1.0;
}
double InvSigmoidpm1(double s)
{
    // (s+1)*(1+exp(-x)) = 2
    // 1+exp(-x)=2/(s+1)
    // exp(-x)=2/(s+1)-1
    // -x = log( 2/(s+1) -1 )
    if (s<-1.0)
        return -DBL_MAX;
    if (s>1.0)
        return DBL_MAX;
    return -log( 2.0/(s+1.0) - 1.0 );
}
int TestSigmoidpm1(void)
{
    double x;
    FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s\\Sig.csv",REPORT_FOLDER);

    if ((fp=fopen(fname,"w")))
        {
            for (x=-10.0; x<=10.0; x+=0.1)
                {
                    fprintf(fp,"%f,%f,%f\n",x,Sigmoidpm1(x),InvSigmoidpm1(Sigmoidpm1(x)));
                }
            fclose(fp);
        }
    return 0;
}

//================================================================================
///Binary logistic regression log likelihood
//================================================================================
double BinaryLogisticRegressionLL(char *resp, double *Mat, double *param, int Nparam, int Nresp)
{
    double LL=0.0;
    double LogOdds;
    double p;
    int i,j;
    int index;

    index=0;
    for (i=0; i<Nresp; i++)
        {
            LogOdds=0.0;
            for (j=0; j<Nparam; j++)
                LogOdds+=Mat[index + j]*param[j];
            p=InvLogOdds(LogOdds);
            if (resp[i])
                {
                    LL+=log(p);
                }
            else
                {
                    LL+=log(1.0-p);
                }
            index+=Nparam;
        }

    return LL;
}

//================================================================================
///Assume parameters are of magnitude<~1
double RegularisedBinaryLogisticRegressionLL(char *resp, double *Mat, double *param, int Nparam, int Nresp)
{
    double LL=BinaryLogisticRegressionLL(resp, Mat, param, Nparam, Nresp);
    int i;
    double sigma=5.0;//five because the log odds tends to plateau around then
    double c=-1.09806;//=log(1/(sqrt(2PI)sigma))
    double tmp;

    LL-=c*Nparam;
    for (i=0; i<Nparam; i++)
        {
            tmp=param[i]/sigma;
            LL+=-tmp*tmp/2;
        }
    return LL;
}
//================================================================================
//Returns negative of log likelihood so it can be minimised instead of maximised
double BinLogRegLL(double param[], int Nparam, void *vBLR)
{
    struct BinLogistic *BLR=(struct BinLogistic *)vBLR;

    if ((*BLR).Regularise)
        return -RegularisedBinaryLogisticRegressionLL((*BLR).resp, (*BLR).Mat, param, Nparam, (*BLR).Nresp);
    else
        return -BinaryLogisticRegressionLL((*BLR).resp, (*BLR).Mat, param, Nparam, (*BLR).Nresp);
}
//================================================================================
double LogOdds(double p)
{
    if (p<=0)
        return log(DBL_MIN);
    if (p>=1.0)
        return log(DBL_MAX);

    return log(p/(1.0-p));
}
//================================================================================
double InvLogOdds(double LogOdds)
{
    return 1.0/(1.0 + exp(-LogOdds));
}
//================================================================================
double BinaryLogisticRegression(char *resp, double *Mat, double *param, int Nparam, int Nresp)
{
    struct BinLogistic BLR;
    int i,count;
    double p;
    double *scale=NULL;

    if (!(scale=malloc(Nparam*sizeof(double))))
        {
            memset(param,0,sizeof(double)*Nparam);
            return 0.0;
        }

    memset(&BLR,0,sizeof(struct BinLogistic));

    BLR.resp=resp;
    BLR.Mat=Mat;
    BLR.Nresp=Nresp;
    BLR.Regularise=1;

    if (Nparam==1)
        {
            count=0;
            for (i=0; i<Nresp; i++)
                if (resp[i])
                    count++;
            p=(double) count/Nresp;
            if (count<Nresp)
                param[0]=log(p/(1.0-p));
            else
                param[0]=log(DBL_MAX);
            return 1.0;//temp return of 1. Ideally return R^2
        }

    for (i=0; i<Nparam; i++)
        scale[i]=5.0;
    DownHillSimplex(param, Nparam, scale, 1, BinLogRegLL, &BLR, 50);

    if (scale)
        free(scale);
    return 1.0;//temporary. Need to return R^2 or similar
}
//====================================================================================
int TestBinaryLogisticRegression(void)
{

    char resp[10000];
    double mat[10000*3];
    double model[3]= {1.0, -1.0, 4.0};
    double se[3];
    double parameters[3]= {10.0,-10.0, 0.0};
    double LOR,p;
    double r;
    int i;
    char txt[256];

    for (i=0; i<10000; i++)
        {
            mat[i*3]=1.0;
            mat[i*3+1]=2.0*rand()/RAND_MAX-1.0;
            mat[i*3+2]=2.0*rand()/RAND_MAX-1.0;

            LOR=model[0] + mat[i*3+1]*model[1] + mat[i*3+2]*model[2];
            p=InvLogOdds(LOR);
            r=(double)rand()/RAND_MAX;
            if (r<p)
                resp[i]=1;
            else
                resp[i]=0;
        }

    BinaryLogisticRegression(resp, mat, parameters, 3, 1000);

    sprintf(txt,"%f,%f,%f",parameters[0],parameters[1],parameters[2]);
    MessageBox(NULL,txt,"",MB_OK);

    BinaryLogisticRegressionIRLS(resp, mat, parameters, se, 3,1000);
    sprintf(txt,"%f,%f,%f\n%f,%f,%f",parameters[0],parameters[1],parameters[2],se[0],se[1],se[2]);
    MessageBox(NULL,txt,"",MB_OK);


    return 1;
}
//===============================================================================================
double ExpectedBLRaccuracy(char *resp, int Nresp)
{
    int row;
    int pos=0;
    double ExpectedAccuracy=0.0;

    for (row=0; row<Nresp; row++)
        {
            if (resp[row])
                pos++;
        }
    if (pos>(0.5 + Nresp/2))
        {
            ExpectedAccuracy=(double)pos/Nresp;
        }
    else
        ExpectedAccuracy=(double)(Nresp-pos)/Nresp;

    return ExpectedAccuracy;
}
//===============================================================================================
double BLRaccuracy(char *resp, double *X, double *param, int Nparam, int Nresp, double *ExpectedAcc)
{
    int row,col;
    int correct=0;
    double lodds;
    double p;

    *ExpectedAcc=ExpectedBLRaccuracy(resp,Nresp);

    for (row=0; row<Nresp; row++)
        {
            ///compute the current log odds
            lodds=0.0;
            for (col=0; col<Nparam; col++)
                {
                    lodds+=X[row*Nparam + col]*param[col];
                }

            ///compute the estimate of p
            p=InvLogOdds(lodds);

            ///count the 'correct' predictions
            if (p>0.5 && resp[row])
                correct++;
            if (p<0.5 && !resp[row])
                correct++;

        }

    return (double)correct/Nresp;

}
//===============================================================================================
double BLRLeaveOneOutAccuracy(char *resp, double *X, int Nparam, int Nresp, double *ExpectedAcc)
{
    int row,col;
    int correct=0;
    double lodds;
    double p;
    double *LooX=NULL;
    char *Looresp=NULL;
    double *param=NULL;
    double *se;

    if (!(LooX=(double *)malloc(Nparam*Nresp*sizeof(double))))
        goto END;

    if (!(Looresp=(char *)malloc(Nresp*sizeof(char))))
        goto END;

    if (!(param=(double *)malloc(Nparam*sizeof(double))))
        goto END;

    if (!(se=(double *)malloc(Nparam*sizeof(double))))
        goto END;

    //the expected accuracy is just the largest response proportion
    *ExpectedAcc=ExpectedBLRaccuracy(resp,Nresp);

    for (row=0; row<Nresp; row++)
        {
            if (row>0)
                {
                    memcpy(Looresp, resp, row*sizeof(char));
                    memcpy(LooX, X, Nparam*(row)*sizeof(double));
                }
            if (row<Nresp-1)
                {
                    memcpy(&Looresp[row], &resp[(row+1)], (Nresp-row-1)*sizeof(char));
                    memcpy(&LooX[Nparam*row], &X[Nparam*(row+1)], Nparam*(Nresp-row-1)*sizeof(double));
                }

            BinaryLogisticRegressionIRLS(Looresp, LooX, param, se, Nparam, Nresp-1);

            ///compute the current log odds
            lodds=0.0;
            for (col=0; col<Nparam; col++)
                {
                    lodds+=X[row*Nparam + col]*param[col];
                }

            ///compute the estimate of p
            p=InvLogOdds(lodds);

            ///count the 'correct' predictions
            if (p>0.5 && resp[row])
                correct++;
            if (p<0.5 && !resp[row])
                correct++;

        }


END:
    if (LooX)
        free(LooX);

    if (Looresp)
        free(Looresp);

    if (param)
        free(param);

    if (se)
        free(se);

    return (double)correct/Nresp;

}
//===============================================================================================
//iterative re-weighted least squares solution of binary logistic regression
double BinaryLogisticRegressionIRLS(char *resp, double *X, double *param, double *se, int Nparam, int Nresp)
{
    double *current=NULL;
    double *weights=NULL;
    double *tmp=NULL;
    double *tmp2;
    double *lodds=NULL;
    double *p=NULL;
    double *invXWX=NULL;
    double d;
    double diff;
    int row,col,col2,i;
    int iter;
    int index;

    if (!(current=(double *)malloc(Nparam*sizeof(double))))
        goto END;//current parameter estimates

    if (!(weights=(double *)malloc(Nresp*sizeof(double))))
        goto END;//weights

    if (!(tmp=(double *)malloc(Nresp*sizeof(double))))
        goto END;//general use

    if (!(tmp2=(double *)malloc(Nparam*sizeof(double))))
        goto END;//general use

    if (!(lodds=(double *)malloc(Nresp*sizeof(double))))
        goto END;//log odds

    if (!(p=(double *)malloc(Nresp*sizeof(double))))
        goto END;//odds

    if (!(invXWX=(double *)malloc(Nparam*Nparam*sizeof(double)))) goto END;//pseudo inverse X*weights*X

    memset(param,0,sizeof(double)*Nparam);

    iter=0;
    do
        {
            memcpy(current,param,sizeof(double)*Nparam);

            index=0;
            for (row=0; row<Nresp; row++)
                {
                    ///compute the current log odds
                    lodds[row]=0.0;
                    for (col=0; col<Nparam; col++)
                        {
                            lodds[row]+=X[index + col]*param[col];
                        }
                    ///compute the estimate of p
                    p[row]=InvLogOdds(lodds[row]);
                    ///compute the weights
                    weights[row]=p[row]*(1.0-p[row]);
                    ///compute weights * lodds
                    tmp[row]=weights[row]*lodds[row]+(double)resp[row]-p[row];
                    index+=Nparam;
                }

            memset(invXWX,0,sizeof(double)*Nparam*Nparam);
            for (col=0; col<Nparam; col++)
                {
                    tmp2[col]=0.0;
                    for (row=0; row<Nresp; row++)
                        {
                            tmp2[col]+=X[col+row*Nparam]*tmp[row];
                        }

                    for (col2=0; col2<Nparam; col2++)
                        {
                            for (row=0; row<Nresp; row++)
                                {
                                    invXWX[col*Nparam+col2]+=X[row*Nparam+col]*weights[row]*X[row*Nparam+col2];
                                }
                        }
                }

            InvertMatrixA(invXWX,Nparam);

            ///estimate the updated parameters
            for (col=0; col<Nparam; col++)
                {
                    param[col]=0.0;
                    for (col2=0; col2<Nparam; col2++)
                        {
                            param[col]+=invXWX[col*Nparam+col2]*tmp2[col2];
                        }
                }

            diff=0.0;
            for (i=0; i<Nparam; i++)
                {
                    d=(param[i]-current[i]);
                    if (invXWX[i*Nparam+i]>0.0)
                        diff+=d*d/invXWX[i*Nparam+i];
                    else
                        diff+=d*d;
                }


            iter++;
        }
    while(diff>1.0e-4 && iter<100);


    for (i=0; i<Nparam; i++)
        se[i]=sqrt(invXWX[i*Nparam+i]);

END:
    if (current)
        free(current);

    if (weights)
        free(weights);

    if (tmp)
        free(tmp);

    if (tmp2)
        free(tmp2);

    if (lodds)
        free(lodds);

    if (p)
        free(p);

    if (invXWX)
        free(invXWX);

    return diff;
}




