/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(CBMAfiles_H)
//Do Nothing
#else


#define CBMAfiles_H

#include "localALE.h"
#include "CoordinateProcess.h"


//censor types
#define NOT_CENSORED 0
#define LEFT_CENSORED 1
#define RIGHT_CENSORED 2
#define INTERVAL_CENSORED 3
#define VOI_CENSORED 4

#define CBMA_TEXT_LENGTH 1024
struct TextLabel
{
    char txt[CBMA_TEXT_LENGTH];
};


struct Coordinates{
   char coordinate_file_name[MAX_PATH];
   char ZscoreUsed;//1 if Z scores are included, otherwise 0
   int Nexperiments;
   int TotalFoci;
   short int *experiment;///starts at 0 [0...TotalFoci]
   short int *subjects;///[0...TotalFoci]
   int *voxel;///
   short int *cluster;///which cluster does this foci contribute to
   short int *TalLabel;///where is it in the Talairach atlas (GM)
   struct TextLabel *ID;///this is a study identifier
   struct TextLabel *CTRST;///contrast identifier
   struct TextLabel *CND;///condition identifier
   struct TextLabel *DESC;///study description
   short int *SubjectsInExp;///there are Nexperiments elements in this array
   short int *ControlsInExp;///there are Nexperiments elements in this array
   char *corrected;///did the study use statistical correction for multiple comparisons (0=No, 1=Yes)
   char *modality;///was it fMRI, PET, or structural?
   char *subanalysis;///this indicates if this study is to take part in any sub analysis
   char *VOI;///is this a Region Of Interest study? (1=yes, 0=no)
   double *p;///
   float *x;///
   float *y;///Talairach coordinates; transformed on entry from MNI
   float *z;///
   float *Zsc;///The Z score at each focus
   float *Zcensor;///the ABSOLUTE Z value used for censoring
   float *covariate;///this is a covariate for use with meta-regression in ClusterZ
};












int LoadExperimentsCOORDINATES(HWND hwnd, struct Coordinates *Co, int X, int Y, int Z, float dx, float dy, float dz,
                               float x0, float y0, float z0);

int AppendCoordinates(struct Coordinates *ale1, struct Coordinates *ale2);

int CopyCoordinates(struct Coordinates *A, struct Coordinates *B);
int CopyCoordinatesentryExt(struct Coordinates *A, int FocusA, int StudyA, struct Coordinates *B, int FocusB, int StudyB);
int CopyCoordinatesentry(struct Coordinates *A, int i, struct Coordinates *B, int j);
int EqualStudyID(struct Coordinates *ale, int iexp1, int iexp2);

int fgetl(FILE *fp, char txt[], int L);

int FreeCoordinates(struct Coordinates *ale);

int GetSubAnlysesCoordinates(struct Coordinates *Co);

int GetTalairachLabelsEx(struct Coordinates *ale, struct Image *TalGM);

int GetTalairachLabels(struct Coordinates *Co);

int MakeStructCoordinates(struct Coordinates *ale, int TotalFoci, int Nexperiments);

int MergeCoordinatesbyStudy(struct Coordinates *ale);
int NumberOfIndependentStudies(struct Coordinates *C);
int NumberOfNonNullIndependentStudies(struct Coordinates *C);

int NoSpaces(char In[], char Out[]);

int OrderExperimentsBy(int label);

char *RemoveCommas(char text[]);

int SaveExperimentsALE(struct Coordinates *ale, char fname[], char TempImageName[], double critical, int FullReport);

int SaveMKDAfiles(struct Coordinates *ale, float x0, float y0, float z0, char directory[], char SaveDir[]);

int SaveSDMfiles(struct Coordinates *ale, float x0, float y0, float z0, char directory[], char SaveDir[]);

int SaveStudyTable(struct Coordinates *ale, char *fname);

int TestGetSubAnalyses(struct Image *image);

int ZfilterCoordinates(struct Coordinates *ale, int Zfilter);

int CheckForCoordinateDuplication(struct Coordinates *ale, char ext[], char directory[]);

int RemoveWithinStudyDuplicates(struct Coordinates *C);
int IdentifyWithinStudyDuplicates(struct Coordinates *C, char duplicates[]);
#endif
