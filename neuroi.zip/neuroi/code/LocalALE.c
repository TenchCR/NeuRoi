/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "global.h"
#include "localALE.h"
#include "talairachfunctions.h"
#include "display.h"
#include "ROIs.h"
#include "imageprocess.h"
#include "numerical.h"
#include "options.h"
#include "generatedirections.h"
#include "graphtheoryalgorithms.h"
#include "loader.h"
#include <ctype.h>

#define IMAGES 4
#define ALEIMG 0
#define CLUSTALE 1
#define CLUSTNUM 2
#define FOCIIMG 3

#define P_SAMPLES 4000                                     //SAMPLES FROM THE NULL HYPOTHESIS USED FOR FCDR IN CBMA
#define CONTRAST_PERMUTATIONS 2000          //SAMPLES FROM THE NULL HYPOTHESIS USED FOR FCDR IN CMA                               2000 in paper
#define CMA_PERMUTATIONS 20000                  //NUMBER OF PERMUTATIONS USED TO ESTIMATE P-VALUES IN CMA                           10000 in paper


#define BHFDR_METHOD 0
#define FDR_METHOD 1
#define FCDR_METHOD 2

#define RANDOM_EFFECTS

#define ALE_BINS 5000//default used 5000


//for the contrast analysis would like 2 p values
//one is the significant p value
//the other is for the most significant trend; smallest FCDR>critical
#define SIGNIFICANT_CONTRAST_P 0
#define TREND_CONTRAST_P 1
struct ContrastP
{
    double p[2];
    double fcdr[2];
};




struct ContrastP CompareALEs_Omnibus_Spatial(HWND hwnd, struct Coordinates *A, struct Coordinates *B, double pA, double pB,
        float dx, float dy, float dz, float sigma, double critical, char directory[], int fcdr, int GroupsMerged);


double ComputePvalueBySpatialRandomisation(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float sigma, double critical, char directory[], int FCDR,
        double pmethod[], int SaveOutput);
double ContrastMeta(HWND hwnd, struct Coordinates *OriginalALE1, struct Coordinates *OriginalALE2, struct Image *image, double sigma, int UseSuggestedFWHM,
                    int FCDR, double critical, double ContrastCritial, double pmethod[], char directory[],
                    int MergeGroups, int Zfilter, int UseZ, int SaveResults);

double ControlFDR(double p[], int Np, float samples[], int Nsamples, int Ntrials, double critical, char directory[]);
double ControlFCDR(HWND hwnd, double p[], int Np, double ptests[], float ALEs[], float x[], float y[], float z[], int Ntests,
                   float sigma, double critical, char directory[], int *Nclusters);

struct ContrastP ControlFCDRforComparingALEs(HWND hwnd, double p[], int nA, int nB, double ptests[], int Ntests, float xa[], float ya[], float za[],
        float xb[], float yb[], float zb[], char G[], short int experiments[], int Nexperiments, float sigma,
        double critical, char directory[], int *Nclusters);

int CountSignificantClustersFast(float x[], float y[], float z[], double p[], short int cluster[], int N, float sigma,
                                 double critical, int SigOnly);

int CountSignificantClustersAllSig(float x[], float y[], float z[], double p[], short int cluster[], int Nsig, float sigma,
                                   double critical);
int CombineExperimentsIntoALEimage(struct Coordinates *ale, float *aleimg, int X, int Y, int Z,
                                   float dx, float dy, float dz, float x0, float y0, float z0,
                                   float sigma, int UseClusters, double critical, double MinALE);
int ComputeALEatFociFast(struct Coordinates *ale, float dx, float dy, float dz, float ALEvalues[], float sigma);


double DifferenceBetweenALEs(HWND hwnd, struct Coordinates *A, struct Coordinates *B, double sigma,
                             float dx, float dy, float dz, char directory[], int MergeGroups, double critical1, double critical2, int SaveResults);




int FillFilterComboBox(HWND hwnd, int ID);
int FilterExperimentByKeyword(HWND hwnd, struct Coordinates *ale, struct KeyWord KW[], int KeyWords, int include);








struct ThreeVector GetRandomFociRandomEffects(float *mask, int X, int Y, int Z, float dx, float dy, float dz,
        float xc, float yc, float zc, float MeanDist, float sd, int *vox);
int GetClusterNumberImage(struct Coordinates *sig, int clusters, float ClustALE[], float ClustNum[],
                          float dx, float dy, float dz, float x0, float y0, float z0,
                          int X, int Y, int Z, float sigma, double critical);








double MaxPossibleALE(struct Coordinates *ale, float dx, float dy, float dz, float sigma);
double Meta(HWND hwnd, struct Coordinates *OriginalALE, struct Image *image, double sigma, int UseSuggestedFWHM,
            int FCDR, double pvalue, double pmethod[], char directory[], int MergeGroups, int Zfilter, int SaveResults);




double NormALE(double sigma, float dx, float dy, float dz);


int ProportionOfExperimentsPerStructure(HWND hwnd, struct Coordinates *ale1, struct Coordinates *ale2, char directory[]);



int RandomiseExperimentsIntoGroups(char G[], int N, int n);
int RLflip(float *image, int X, int Y, int Z);

int ReportTalairach(HWND hwnd, struct Coordinates *ale, char directory[], char file[], double critical);
int ReportStudySummary(HWND hwnd, struct Coordinates *ale, char directory[], char file[], float FWHM, double critical, int FCDR, int MergeGroups);



int SaveNearestCoordinates(struct Coordinates *ale, float x, float y, float z, char fname[]);
int SaveStudyIDs(struct Coordinates *ale, char *fname);

int SaveClusterDataForDendrogram(HWND hwnd, struct Coordinates *ale, char directory[], char file[]);
int SaveReportedStructures(HWND hwnd, struct Coordinates *ale, char directory[]);
int SaveCommonClustersByStudyPairs(HWND hwnd, struct Coordinates *ale, char directory[], char file[]);


//=============================================================================================
//                           LocalALE callback function
//=============================================================================================
INT_PTR CALLBACK LocalALEDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static struct Coordinates ale1, ale2;
    static char directory[MAX_PATH];
    char directory2[MAX_PATH];
    static double pvalue, pcontrast, FWHM;
    static int UseZ;
    static int FCDR;
    static int FilterMode;
    static int Zfilter;
    static int MergeGroups;
    static int UseSuggestedFWHM;
    double sigma;
    double pmethod[3];
    float *out=NULL;
    char txt[256], fname[MAX_PATH];
    char current_selection[256];
    struct KeyWord KW[5];
    int tmp, i;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;



    switch (msg)
    {


    case WM_CLOSE:
        if (ale1.Nexperiments) FreeCoordinates(&ale1);
        if (ale2.Nexperiments) FreeCoordinates(&ale2);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hLocalALE=(HWND)NULL;
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:
        sprintf(txt,"%f",pvalue);
        SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_SETTEXT, 0, (LPARAM)txt);
        sprintf(txt,"%f",pcontrast);
        SendMessage(GetDlgItem(hwnd,ID_P_CONTRAST), WM_SETTEXT, 0, (LPARAM)txt);
        if (UseZ) SendMessage(GetDlgItem(hwnd,ID_USE_Z_SCORE),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_USE_Z_SCORE),BM_SETCHECK,BST_UNCHECKED,0);
        if (UseSuggestedFWHM) SendMessage(GetDlgItem(hwnd,ID_USE_SUGGESTED_FWHM),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_USE_SUGGESTED_FWHM),BM_SETCHECK,BST_UNCHECKED,0);
        if (FCDR) SendMessage(GetDlgItem(hwnd,ID_DO_FCDR),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_DO_FCDR),BM_SETCHECK,BST_UNCHECKED,0);
        if (MergeGroups) SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_UNCHECKED,0);
        SendMessage(GetDlgItem(hwnd,FilterMode),BM_SETCHECK,BST_CHECKED,0);
        SendMessage(GetDlgItem(hwnd,Zfilter),BM_SETCHECK,BST_CHECKED,0);
        break;





    case WM_INITDIALOG:
        FillFilterComboBox(hwnd, ID_LABEL_FILTER);
        srand ( time(NULL) );
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        pvalue=0.05;
        pcontrast=0.1;
        FWHM=10.0;
        UseZ=0;
        UseSuggestedFWHM=1;
        FCDR=1;
        FilterMode=ID_PASS_FILTER;
        Zfilter=ID_USE_ALL_Z;
        MergeGroups=1;//default changed 16/feb/2015
        SendMessage(GetDlgItem(hwnd,ID_DO_FCDR),BM_SETCHECK,BST_UNCHECKED,0);
        break;





    case WM_COMMAND:
        switch (LOWORD(wParam))
        {


        case ID_PASS_FILTER:
        case ID_STOP_FILTER:
            FilterMode=(int)LOWORD(wParam);
            break;

        case ID_USE_ALL_Z:
        case ID_USE_POSITIVE_Z:
        case ID_USE_NEGATIVE_Z:
            Zfilter=(int)LOWORD(wParam);
            break;



        case ID_CLEAR_KEYWORDS:
            SendDlgItemMessage(hwnd,ID_FILTER_KEYWORDS,CB_RESETCONTENT,0,0);
            break;


        case ID_ADD_KEYWORD:
            if ( (tmp = SendMessage(GetDlgItem(hwnd,ID_LABEL_FILTER),CB_GETCURSEL,0,0)) != CB_ERR)
            {
                if (SendDlgItemMessage(hwnd,ID_FILTER_KEYWORDS,CB_GETCOUNT,0,0)<5)
                {
                    SendMessage(GetDlgItem(hwnd,ID_LABEL_FILTER),CB_GETLBTEXT, tmp,(LPARAM)current_selection);
                    SendDlgItemMessage(hwnd,ID_FILTER_KEYWORDS,CB_ADDSTRING,(WPARAM)0,(LPARAM)current_selection);
                }
                else MessageBox(NULL,"Maximum 5 keywords allowed","",MB_OK|MB_ICONWARNING);
            }
            break;


        case ID_FILTER_ALE:
            if (ale1.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }
            if ( (tmp = SendMessage(GetDlgItem(hwnd,ID_FILTER_KEYWORDS),CB_GETCOUNT,0,0)) != CB_ERR)
            {
                for (i=0; i<=tmp; i++)
                {
                    SendMessage(GetDlgItem(hwnd,ID_FILTER_KEYWORDS),CB_GETLBTEXT, i,(LPARAM)KW[i].txt);
                }
                FilterExperimentByKeyword(GetParent(hwnd), &ale1, KW, tmp, (FilterMode==ID_PASS_FILTER)?1:0);
                sprintf(txt,"%f",FWHM_ALE(ale1.Nexperiments));
                SendMessage(GetDlgItem(hwnd,ID_FWHM_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                sprintf(fname,"%s\\FilteredActivations.txt",directory);
                SaveExperimentsALE(&ale1, fname, "Filtered activations", 1.0,0);

                //ALSO FILTER THE SECOND ALE IF LOADED
                if (ale2.TotalFoci)
                {
                    FilterExperimentByKeyword(GetParent(hwnd), &ale2, KW, tmp,(FilterMode==ID_PASS_FILTER)?1:0);
                    tmp=(ale1.Nexperiments<ale2.Nexperiments) ? ale1.Nexperiments:ale2.Nexperiments;
                    sprintf(txt,"%f",FWHM_ALE(tmp));
                    SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                    sprintf(fname,"%s\\FilteredActivations2.txt",directory);
                    SaveExperimentsALE(&ale2, fname, "Filtered activations", 1.0,0);
                }


                //SendDlgItemMessage(hwnd,ID_FILTER_KEYWORDS,CB_RESETCONTENT,0,0);
            }
            else MessageBox(NULL,"Please Make Filter Selection","",MB_OK);
            break;


        case ID_DO_FCDR:
            if (FCDR)
            {
                SendMessage(GetDlgItem(hwnd,ID_DO_FCDR),BM_SETCHECK,BST_UNCHECKED,0);
                FCDR=0;
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_DO_FCDR),BM_SETCHECK,BST_CHECKED,0);
                FCDR=1;
            }
            break;


        case ID_MERGE_GROUPS:
            if (MergeGroups)
            {
                SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_UNCHECKED,0);
                MergeGroups=0;
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_MERGE_GROUPS),BM_SETCHECK,BST_CHECKED,0);
                MergeGroups=1;
            }
            break;

        /*
                case ID_USE_Z_SCORE:
                    if (UseZ)
                    {
                        SendMessage(GetDlgItem(hwnd,ID_USE_Z_SCORE),BM_SETCHECK,BST_UNCHECKED,0);
                        UseZ=0;
                    }
                    else
                    {
                        SendMessage(GetDlgItem(hwnd,ID_USE_Z_SCORE),BM_SETCHECK,BST_CHECKED,0);
                        UseZ=1;
                    }
                    break;
        */

        /*
                case ID_USE_MAP:
                    if (UseMAP)
                    {
                        SendMessage(GetDlgItem(hwnd,ID_USE_MAP),BM_SETCHECK,BST_UNCHECKED,0);
                        UseMAP=0;
                    }
                    else
                    {
                        SendMessage(GetDlgItem(hwnd,ID_USE_MAP),BM_SETCHECK,BST_CHECKED,0);
                        UseMAP=1;
                    }
                    break;
        */

        case ID_USE_SUGGESTED_FWHM:
            if (UseSuggestedFWHM)
            {
                SendMessage(GetDlgItem(hwnd,ID_USE_SUGGESTED_FWHM),BM_SETCHECK,BST_UNCHECKED,0);
                UseSuggestedFWHM=0;
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_USE_SUGGESTED_FWHM),BM_SETCHECK,BST_CHECKED,0);
                UseSuggestedFWHM=1;
            }
            break;


        case ID_LOAD_ACTIVATIONS:

            if (ale1.Nexperiments) FreeCoordinates(&ale1);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &ale1, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
            {
                tmp=DirectoryFileDivide(ale1.coordinate_file_name);
                sprintf(directory,"%s",ale1.coordinate_file_name);
                directory[tmp]='\0';

                CheckForCoordinateDuplication(&ale1, "_A", directory);

                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT), WM_SETTEXT, 0, (LPARAM)ale1.coordinate_file_name);

                sprintf(txt,"%f",FWHM_ALE(ale1.Nexperiments));
                SendMessage(GetDlgItem(hwnd,ID_FWHM_TXT), WM_SETTEXT, 0, (LPARAM)txt);

                if ( (ale1.Nexperiments>0) && (ale2.Nexperiments>0) )
                {
                    tmp=(ale1.Nexperiments<ale2.Nexperiments) ? ale1.Nexperiments:ale2.Nexperiments;
                    sprintf(txt,"%f",FWHM_ALE(tmp));
                    SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                }
            }

            break;


        case ID_LOAD_ACTIVATIONS2:

            if (ale2.Nexperiments) FreeCoordinates(&ale2);
            if (LoadExperimentsCOORDINATES(GetParent(hwnd), &ale2, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0))
            {
                tmp=DirectoryFileDivide(ale2.coordinate_file_name);
                sprintf(directory2,"%s",ale2.coordinate_file_name);
                directory2[tmp]='\0';

                CheckForCoordinateDuplication(&ale2, "_B", directory2);

                sprintf(txt,"%f",10.0);
                SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                SendMessage(GetDlgItem(hwnd,ID_ALE_FILE_TXT2), WM_SETTEXT, 0, (LPARAM)ale2.coordinate_file_name);

                if ( (ale1.Nexperiments>0) && (ale2.Nexperiments>0) )
                {
                    tmp=(ale1.Nexperiments<ale2.Nexperiments) ? ale1.Nexperiments:ale2.Nexperiments;
                    sprintf(txt,"%f",FWHM_ALE(tmp));
                    SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_SETTEXT, 0, (LPARAM)txt);
                }
            }
            break;


        case ID_SAVE_CHECKS:
            if (ale1.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }
            SendMessage(GetDlgItem(hwnd,ID_FWHM_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            FWHM=atof(txt);
            if (FWHM<=0.0)
            {
                MessageBox(NULL,"Please specify FWHM (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }
            sigma=SD_ALE(FWHM);

            EnableWindow(GetParent(hwnd),0);
            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);
            SaveALE_MIP(GetParent(hwnd), &ale1, &gImage, directory, sigma);

            ComputeDiagnosticBySpatialRandomisation(GetParent(hwnd), &ale1, gImage.img, out, gImage.X, gImage.Y, gImage.Z,
                                                    gImage.dx, gImage.dy, gImage.dz, gImage.x0, gImage.y0, gImage.z0,
                                                    sigma, pvalue, directory);
            SetCursor(PrevCursor);
            EnableWindow(GetParent(hwnd),1);
            break;



        case ID_SAVE_CLOSEST_COORDINATES:
            if (ale1.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }
            sprintf(fname,"%s//Nearest Coordinates To %f %f %f.csv",directory,gImage.dx*gMainPict.x-gImage.x0, gImage.dy*gMainPict.y-gImage.y0, gImage.dz*gMainPict.slice-gImage.z0);
            //MessageBox(NULL,fname,"",MB_OK);
            SaveNearestCoordinates(&ale1, gImage.dx*gMainPict.x-gImage.x0, gImage.dy*gMainPict.y-gImage.y0, gImage.dz*gMainPict.slice-gImage.z0, fname);
            break;


        case ID_RUN_ALE:
            if (ale1.TotalFoci<=0)
            {
                MessageBox(NULL,"No activations loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }

            SendMessage(GetDlgItem(hwnd,ID_FWHM_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            FWHM=atof(txt);
            if (FWHM<=0.0)
            {
                MessageBox(NULL,"Please specify FWHM (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }
            sigma=SD_ALE(FWHM);

            SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            pvalue=atof(txt);
            if (pvalue<=0.0)
            {
                MessageBox(NULL,"Please specify pvalue (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }

            //GetFWHMestimate(&ale1, directory, gImage.dx, gImage.dy, gImage.dz, 1, 0);

            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);

            pvalue = Meta(GetParent(hwnd), &ale1, &gImage, sigma, UseSuggestedFWHM, FCDR, pvalue, pmethod, directory, MergeGroups, Zfilter, 1);


            SetCursor(PrevCursor);
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;



        case ID_COMPARE_ALE:

            if ((ale1.TotalFoci<=0) || (ale2.TotalFoci<=0))
            {
                MessageBox(NULL,"Two activation files must be loaded.","",MB_OK|MB_ICONWARNING);
                break;
            }


            SendMessage(GetDlgItem(hwnd,ID_FWHM2_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            FWHM=atof(txt);
            if (FWHM<=0.0)
            {
                MessageBox(NULL,"Please specify FWHM (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }
            sigma=SD_ALE(FWHM);

            //CorrelateALEs(GetParent(hwnd), &ale1, &ale2, gImage.img, gImage.X, gImage.Y, gImage.Z, gImage.dx, gImage.dy, gImage.dz,sigma);

            SendMessage(GetDlgItem(hwnd,ID_P_VALUE_TXT), WM_GETTEXT, 256, (LPARAM)txt);
            pvalue=atof(txt);
            if (pvalue<=0.0)
            {
                MessageBox(NULL,"Please specify pvalue (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }

            SendMessage(GetDlgItem(hwnd,ID_P_CONTRAST), WM_GETTEXT, 256, (LPARAM)txt);
            pcontrast=atof(txt);
            if (pvalue<=0.0)
            {
                MessageBox(NULL,"Please specify contrast pvalue (>0.0)","",MB_OK|MB_ICONWARNING);
                break;
            }


            hourglass=LoadCursor(NULL,IDC_WAIT);
            PrevCursor=SetCursor(hourglass);

            ContrastMeta(GetParent(hwnd), &ale1, &ale2, &gImage, sigma, UseSuggestedFWHM,FCDR, pvalue, pcontrast, pmethod, directory,MergeGroups, Zfilter, UseZ, 1);
            SetCursor(PrevCursor);
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;


        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;


    }
    return 0;
}
//======================================================================================================
//======================================================================================================
int SaveNearestCoordinates(struct Coordinates *ale, float x, float y, float z, char fname[])
{

    FILE *fp=NULL;
    int study,foci;
    int TotalFoci=(*ale).TotalFoci;
    int Nstudies=(*ale).Nexperiments;
    int *ClosestFoci=NULL;
    int *sort=NULL;
    double *dist=NULL;
    double d;

    if (!(ClosestFoci=(int *)malloc(Nstudies*sizeof(int)))) goto END;
    if (!(sort=(int *)malloc(Nstudies*sizeof(int)))) goto END;
    if (!(dist=(double *)malloc(Nstudies*sizeof(double)))) goto END;


    //find the closest foci to {x,y,z} in each of the studies
    for (study=0; study<Nstudies; study++)
    {
        dist[study]=10000.0;//initialise to be very big
        ClosestFoci[study]=-1;
        for (foci=0; foci<TotalFoci; foci++)
        {
            if ((*ale).experiment[foci]==study)
            {
                d=sqrt( pow(x-(*ale).x[foci],2) + pow(y-(*ale).y[foci],2) + pow(z-(*ale).z[foci],2) );
                if (d<dist[study])
                {
                    dist[study]=d;
                    ClosestFoci[study]=foci;
                }
            }
        }
    }

    QuickSort(dist,sort,Nstudies);

    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"Coordinates:,%f,%f,%f\n",x,y,z);
        fprintf(fp,"%s\n",(*ale).coordinate_file_name);
        fprintf(fp,"Study,x,y,z,distance\n");
        for (study=0; study<Nstudies; study++)
        {
            if (ClosestFoci[sort[study]]>=0) fprintf(fp,"%s,%f,%f,%f,%f\n",(*ale).ID[sort[study]].txt, (*ale).x[ClosestFoci[sort[study]]],(*ale).y[ClosestFoci[sort[study]]],(*ale).z[ClosestFoci[sort[study]]],dist[sort[study]]);
        }
        fclose(fp);
    }

END:
    if (sort) free(sort);
    if (dist) free(dist);
    if (ClosestFoci) free(ClosestFoci);

    return 1;

}





//======================================================================================================
//ESTIMATE THE FWHM GIVEN THE NUMBER OF EXPERIMENTS
//THIS IS AN EMPIRICLE ESTIMATE
//======================================================================================================
double FWHM_ALE(int Nexperiments)
{
    if (Nexperiments<=1) return 1.0;
    else return 30.0/pow((double)Nexperiments,1.0/3);
}
//======================================================================================================
//COMPUTE THE STANDARD DEVIATION GIVEN THE FWHM
//======================================================================================================
double SD_ALE(double FWHM)
{
    if (FWHM<=0.0) return DBL_MIN;
    return FWHM/sqrt(8.0*log(2.0));
}


//======================================================================================================
//DO CONTRAST META ANALYSIS
//======================================================================================================
double ContrastMeta(HWND hwnd, struct Coordinates *OriginalALE1, struct Coordinates *OriginalALE2, struct Image *image, double sigma, int UseSuggestedFWHM,
                    int FCDR, double critical, double ContrastCritial, double pmethod[], char directory[],
                    int MergeGroups, int Zfilter, int UseZ, int SaveResults)
{

    struct Coordinates ale1,ale2,alecomb;
    struct Image I1;
    double p1,p2,pvalue;
    struct ContrastP CP;
    double FWHM1, FWHM2;
    float *out=NULL;
    int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    char fname[MAX_PATH];

    memset(&CP,0,sizeof(struct ContrastP));


    memset(&ale1,0,sizeof(struct Coordinates));
    memset(&ale2,0,sizeof(struct Coordinates));
    memset(&alecomb,0,sizeof(struct Coordinates));
    memset(&I1,0,sizeof(struct Image));

    CopyCoordinates(OriginalALE1, &ale1);
    CopyCoordinates(OriginalALE2, &ale2);

    if ((*OriginalALE1).ZscoreUsed && ((Zfilter==ID_USE_POSITIVE_Z) || (Zfilter==ID_USE_NEGATIVE_Z))) ZfilterCoordinates(&ale1, Zfilter);
    if ((*OriginalALE2).ZscoreUsed && ((Zfilter==ID_USE_POSITIVE_Z) || (Zfilter==ID_USE_NEGATIVE_Z))) ZfilterCoordinates(&ale2, Zfilter);


    if (MergeGroups)
    {
        MergeCoordinatesbyStudy(&ale1);
        MergeCoordinatesbyStudy(&ale2);
    }

    if (UseSuggestedFWHM)
    {
        FWHM1=FWHM_ALE(ale1.Nexperiments);
        FWHM2=FWHM_ALE(ale2.Nexperiments);

        if (FWHM1>FWHM2)  sigma=SD_ALE(FWHM1);
        else sigma=SD_ALE(FWHM2);
    }



    if (!MakeImage(&I1, (*image).X, (*image).Y, (*image).Z/(*image).volumes, 1, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,
                   1.0, 0.0, DT_FLOAT, NIFTI, "")) goto END;
    if (!(out=(float *)malloc(IMAGES * voxels * sizeof(float)))) goto END;


    //do the meta analysis to filter out foci that are not to be compared
    p2 = ComputePvalueBySpatialRandomisation(hwnd, &ale2, (*image).img, out,  (*image).X, (*image).Y, (*image).Z/(*image).volumes,
            (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0, sigma, critical, directory, FCDR, pmethod, 0);
    p1 = ComputePvalueBySpatialRandomisation(hwnd, &ale1, (*image).img, out,  (*image).X, (*image).Y, (*image).Z/(*image).volumes,
            (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0, sigma, critical, directory, FCDR, pmethod, 0);



//NEW COMBINED OMNIBUS TEST AND CONTRAST TEST MARCH 2015
    CP = CompareALEs_Omnibus_Spatial(hwnd, &ale1, &ale2, p1, p2, (*image).dx, (*image).dy, (*image).dz,
                                     sigma, ContrastCritial, directory, FCDR, MergeGroups);



    //REPORT THE PROPORTION OF STUDIES REPORTING IN THE TALAIRACH STRUCTURES
    ProportionOfExperimentsPerStructure(hwnd, &ale1, &ale2, directory);



    if (SaveResults)
    {
        //SAVE THE SIGNIFICANT RESULT
        pvalue = CP.p[SIGNIFICANT_CONTRAST_P];

        CountSignificantClustersFast(ale1.x, ale1.y, ale1.z, ale1.p, ale1.cluster, ale1.TotalFoci, sigma, pvalue, 0);
        CombineExperimentsIntoALEimage(&ale1, out, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                       (*image).x0, (*image).y0, (*image).z0, sigma, 0, pvalue, 0.0);

        CountSignificantClustersFast(ale2.x, ale2.y, ale2.z, ale2.p, ale2.cluster, ale2.TotalFoci, sigma, pvalue, 0);
        CombineExperimentsIntoALEimage(&ale2, &out[voxels], (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                       (*image).x0, (*image).y0, (*image).z0, sigma, 0, pvalue, 0.0);

        //save the AgtB
        memcpy(I1.img, out, voxels * sizeof(float));
        sprintf(I1.Descrip,"AgtB image");
        sprintf(I1.filename,"%s\\AgtB.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);

        ReportClusters(GetParent(hwnd), &ale1, directory, "cluster report AgtB.csv",
                       out, (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                       (*image).z0, (*image).dz, sigma*sqrt(8.0*log(2.0)), pvalue, FCDR, MergeGroups, Zfilter);
        ReportTalairach(GetParent(hwnd), &ale1, directory, "Talairach Report AgtB.csv", pvalue);

        //save the BgtA
        memcpy(I1.img, &out[voxels], voxels * sizeof(float));
        sprintf(I1.Descrip,"BgtA image");
        sprintf(I1.filename,"%s\\BgtA.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);
        ReportClusters(GetParent(hwnd), &ale2, directory, "cluster report BgtA.csv",
                       &out[voxels], (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                       (*image).z0, (*image).dz, sigma*sqrt(8.0*log(2.0)), pvalue, FCDR, MergeGroups, Zfilter);
        ReportTalairach(GetParent(hwnd), &ale2, directory, "Talairach Report BgtA.csv", pvalue);


        sprintf(fname,"%s\\AllFoci_A.txt",directory);
        SaveExperimentsALE(&ale1, fname, (*image).filename, pvalue,1);
        sprintf(fname,"%s\\AllFoci_B.txt",directory);
        SaveExperimentsALE(&ale2, fname, (*image).filename, pvalue,1);

        if (FCDR)
        {

            //SAVE THE TREND RESULT
            pvalue = CP.p[TREND_CONTRAST_P];

            CountSignificantClustersFast(ale1.x, ale1.y, ale1.z, ale1.p, ale1.cluster, ale1.TotalFoci, sigma, pvalue, 0);
            CombineExperimentsIntoALEimage(&ale1, out, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                           (*image).x0, (*image).y0, (*image).z0, sigma, 0, pvalue, 0.0);

            CountSignificantClustersFast(ale2.x, ale2.y, ale2.z, ale2.p, ale2.cluster, ale2.TotalFoci, sigma, pvalue, 0);
            CombineExperimentsIntoALEimage(&ale2, &out[voxels], (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                           (*image).x0, (*image).y0, (*image).z0, sigma, 0, pvalue, 0.0);

            //save the AgtB
            memcpy(I1.img, out, voxels * sizeof(float));
            sprintf(I1.Descrip,"AgtB trend image");
            sprintf(I1.filename,"%s\\AgtB trend_FCDR %f.nii",directory,CP.fcdr[TREND_CONTRAST_P]);
            RLflip(I1.img, I1.X, I1.Y, I1.Z);
            Save(&I1);

            ReportClusters(GetParent(hwnd), &ale1, directory, "cluster report AgtB trend.csv",
                           out, (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                           (*image).z0, (*image).dz, sigma*sqrt(8.0*log(2.0)), pvalue, FCDR, MergeGroups, Zfilter);

            //save the BgtA
            memcpy(I1.img, &out[voxels], voxels * sizeof(float));
            sprintf(I1.Descrip,"BgtA trend image");
            sprintf(I1.filename,"%s\\BgtA trend_FCDR %f.nii",directory,CP.fcdr[TREND_CONTRAST_P]);
            RLflip(I1.img, I1.X, I1.Y, I1.Z);
            Save(&I1);
            ReportClusters(GetParent(hwnd), &ale2, directory, "cluster report BgtA trend.csv",
                           &out[voxels], (*image).X, (*image).Y, (*image).Z/(*image).volumes,
                           (*image).z0, (*image).dz, sigma*sqrt(8.0*log(2.0)), pvalue, FCDR, MergeGroups, Zfilter);

        }

    }


END:
    FreeCoordinates(&ale1);
    FreeCoordinates(&ale2);
    FreeCoordinates(&alecomb);

    if (out) free(out);

    ReleaseImage(&I1);

    return CP.p[SIGNIFICANT_CONTRAST_P];
}
//======================================================================================================
//do meta analysis
//======================================================================================================
double Meta(HWND hwnd, struct Coordinates *OriginalALE, struct Image *image, double sigma, int UseSuggestedFWHM,
            int FCDR, double pvalue, double pmethod[], char directory[], int MergeGroups, int Zfilter, int SaveResults)
{

    struct Coordinates ale;
    struct Image I1;
    int X,Y,Z, voxels;
    float dx,dy,dz;
    float x0,y0,z0;
    float *out = NULL;
    float FWHM = sigma*sqrt(8.0*log(2.0));
    char fname[MAX_PATH];

    memset(&ale,0,sizeof(struct Coordinates));
    memset(&I1,0,sizeof(struct Image));



    //SaveStudyIDs(OriginalALE, fname);
    CopyCoordinates(OriginalALE, &ale);

    if ((*OriginalALE).ZscoreUsed && ((Zfilter==ID_USE_POSITIVE_Z) || (Zfilter==ID_USE_NEGATIVE_Z)))
    {
        ZfilterCoordinates(&ale, Zfilter);
        sprintf(fname,"%s\\Zfiltered.txt",directory);
        SaveExperimentsALE(&ale, fname, (*image).filename, 1.0,0);
    }

    if (MergeGroups)
    {
        MergeCoordinatesbyStudy(&ale);
        sprintf(fname,"%s\\StudyIDs_Merged.csv",directory);
        SaveStudyIDs(&ale, fname);
    }



    //NEED A FILE SUITABLE FOR GINGERALE. CANT STORE Z SCORE FOR GINGERALE
    sprintf(fname,"%s\\GAcoordinates.txt",directory);
    if (ale.ZscoreUsed)
    {
        ale.ZscoreUsed=0;
        SaveExperimentsALE(&ale, fname, "GA coordinates", 1.0, 0);
        ale.ZscoreUsed=1;
    }
    else SaveExperimentsALE(&ale, fname, "GA coordinates", 1.0, 0);




    if (UseSuggestedFWHM)
    {
        FWHM=FWHM_ALE(ale.Nexperiments);
        sigma=SD_ALE(FWHM);
    }


    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;
    voxels = X*Y*Z;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    x0=(*image).x0;
    y0=(*image).y0;
    z0=(*image).z0;

    if (!MakeImage(&I1, X, Y, Z, 1, dx, dy, dz, x0, y0, z0, 1.0, 0.0, DT_FLOAT, NIFTI, "")) goto END;
    if (!(out=(float *)malloc(IMAGES * X * Y * Z * sizeof(float)))) goto END;



    pvalue = ComputePvalueBySpatialRandomisation(hwnd, &ale, (*image).img, out, X, Y, Z,
             dx, dy, dz, x0, y0, z0, sigma, pvalue, directory, FCDR, pmethod, 1);

//sprintf(fname,"%f",pvalue);
//MessageBox(NULL,fname,"",MB_OK);


//Radus lateralisation hypothesis
    //pvalue = LateralizationTest(hwnd, &ale, (*image).img, out, X, Y, Z,
    //                            dx, dy, dz, x0, y0, z0, sigma, pvalue, directory, FCDR, FCDRmode, pmethod, 1);




    if (SaveResults)
    {

        SaveReportedStructures(hwnd, &ale, directory);

        SaveCommonClustersByStudyPairs(hwnd, &ale, directory, "Clusters In Common.csv");

        //save the ALE (all activations)
        memcpy(I1.img, out, voxels * sizeof(float));
        sprintf(I1.Descrip,"ALE image");
        sprintf(I1.filename,"%s\\ALE.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);
        //save the clusters after correcting for too few experiments
        memcpy(I1.img, &out[CLUSTALE * voxels], voxels * sizeof(float));
        sprintf(I1.Descrip,"Cluster ALE");
        sprintf(I1.filename,"%s\\SignificantClusters.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);
        //save the clusters after correcting for too few experiments
        memcpy(I1.img, &out[CLUSTNUM * voxels], voxels * sizeof(float));
        sprintf(I1.Descrip,"ClusterNumbers image");
        sprintf(I1.filename,"%s\\ClusterNumbers.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);
        //save all Coordinates
        memcpy(I1.img, &out[FOCIIMG * voxels], voxels * sizeof(float));
        sprintf(I1.Descrip,"Coordinates image");
        sprintf(I1.filename,"%s\\Coordinates.nii",directory);
        RLflip(I1.img, I1.X, I1.Y, I1.Z);
        Save(&I1);


        ReportClusters(hwnd, &ale, directory, "cluster report.csv",
                       out, X, Y, Z,
                       z0, dz, FWHM, pvalue, FCDR, MergeGroups, Zfilter);
        ReportTalairach(hwnd, &ale, directory, "Talairach Report.csv", pvalue);

        ReportStudySummary(hwnd, &ale, directory, "Study Summary.csv", FWHM, pvalue, FCDR, MergeGroups);

        SaveClusterDataForDendrogram(hwnd, &ale, directory, "Dendrogram.txt");

        sprintf(fname,"%s\\AllCoordinates.txt",directory);
        SaveExperimentsALE(&ale, fname, (*image).filename, pvalue,1);

        SaveSDMfiles(&ale, x0, y0, z0, directory,"SDM");
        //SaveMKDAfiles(&ale, x0, y0, z0, directory, "MKDA");

#ifdef DEVELOP
        struct Clusters cl;
        memset(&cl,0,sizeof(struct Clusters));
        FillClusterStructure(&ale, &cl, sigma);
        RandomiseFociRandomEffects((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, &cl, sigma);


        int iExp;
        for (iExp=0; iExp<ale.Nexperiments; iExp++)
        {
            RandomiseFociInexperiment((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, iExp);
        }


        if (ale.ZscoreUsed) SaveSDMfiles(&ale, x0, y0, z0, directory,"SDMrandom");

        sprintf(fname,"%s\\RandomisedGAcoordinates.txt",directory);
        if (ale.ZscoreUsed)
        {
            ale.ZscoreUsed=0;//make sure it doesnt save the zscores
            SaveExperimentsALE(&ale, fname, (*image).filename, pvalue,0);
            ale.ZscoreUsed=1;
        }
        else SaveExperimentsALE(&ale, fname, (*image).filename, pvalue,0);

#endif // DEVELOP


    }



END:
    if (out) free(out);
    ReleaseImage(&I1);
    FreeCoordinates(&ale);

    return pvalue;
}



//======================================================================================================
//SAVE THE STUDY IDs
//======================================================================================================
int SaveStudyIDs(struct Coordinates *ale, char *fname)
{
    FILE *fp=NULL;
    int result=0;
    int iexp;

    if ((fp=fopen(fname,"w")))
    {
        for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
        {
            fprintf(fp,"%s\n",(*ale).ID[iexp].txt);
        }
        fclose(fp);
        result=1;
    }

    return result;
}


//======================================================================================================
//SAVE A REPORTED STRUCTURE FREQUNCY FILE
//======================================================================================================
int SaveReportedStructures(HWND hwnd, struct Coordinates *ale, char directory[])
{
    struct Image TalImg;
    int result=0;
    char fname[MAX_PATH];
    char *labels=NULL;
    char *b;
    int LengthLabels;
    int Nlabels;
    int st;
    int foci;
    int lab;
    short int *reported=NULL;
    short int *studies=NULL;
    double *pvalue=NULL;
    FILE *fp;

    memset(&TalImg,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\talGMmerged.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &TalImg, 0))
    {
        MessageBox(NULL,"Filtering not availabale without downloading the Talairach image file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    labels=LoadTalairachLabels(&LengthLabels);
    if (LengthLabels<=0)
    {
        MessageBox(NULL,"Filtering not availabale without downloading the Talairach labels file. This file should come with NeuROI.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    Nlabels=BiggestTalairachLabel(labels, LengthLabels);

    GetTalairachLabelsEx(ale, &TalImg);

    if (!(reported=(short int *)malloc(sizeof(short int)*(Nlabels+1)))) goto END;
    if (!(studies=(short int *)malloc(sizeof(short int)*(Nlabels+1)))) goto END;
    if (!(pvalue=(double *)malloc(sizeof(double)*(Nlabels+1)))) goto END;

    memset(studies,0,sizeof(short int)*(Nlabels+1));
    for (lab=0; lab<=Nlabels; lab++) pvalue[lab]=1.0;
    for (st=0; st<(*ale).Nexperiments; st++)
    {
        memset(reported,0,sizeof(short int)*(Nlabels+1));
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ((*ale).experiment[foci]==st)
            {
                reported[(*ale).TalLabel[foci]]++;
                if ((*ale).p[foci]<pvalue[(*ale).TalLabel[foci]]) pvalue[(*ale).TalLabel[foci]]=(*ale).p[foci];
            }
        }
        for (lab=0; lab<=Nlabels; lab++)
        {
            if (reported[lab]) studies[lab]++;
        }
    }

    sprintf(fname,"%s//Reported Structures.csv", directory);
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"Talairach,,,,,Proportion reporting, pvalue\n");
        for (lab=0; lab<=Nlabels; lab++)
        {
            if (studies[lab])
            {
                b=FindEntryInTalairachLabels(labels, LengthLabels, lab);
                fprintf(fp,"%s,%f,%f\n",&b[1],(double)studies[lab]/(*ale).Nexperiments, pvalue[lab]);
            }
        }

        fclose (fp);
    }

    result=1;
END:
    ReleaseImage(&TalImg);
    if (reported) free(reported);
    if (studies) free(studies);
    if (pvalue) free(pvalue);

    return result;
}
//======================================================================================================
//WRITE A FILE OF FREQUENCIES OF REPORTED TALAIRACH STRUCTURES
//======================================================================================================
int ProportionOfExperimentsPerStructure(HWND hwnd, struct Coordinates *ale1, struct Coordinates *ale2, char directory[])
{
    char *labels=NULL;
    char *b=NULL;
    int Nl;
    int study;
    struct Image Tal;
    int result=0;
    int foci, lab;
    int Nlabels;
    short int *reported=NULL;
    short int *reported1=NULL;
    short int *reported2=NULL;
    double *p=NULL;
    char *group=NULL;
    char fname[MAX_PATH];
    FILE *fp;

    //LOAD THE TALAIRACH DATA
    memset(&Tal,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    LoadFromFileName(hwnd, fname, &Tal, 0);
    labels=LoadTalairachLabels(&Nl);
    Nlabels=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,Nlabels);

    GetTalairachLabelsEx(ale1, &Tal);
    GetTalairachLabelsEx(ale2, &Tal);

    if (!(reported=(short int *)malloc(sizeof(short int)*(Nlabels+1)))) goto END;
    if (!(reported1=(short int *)malloc(sizeof(short int)*(Nlabels+1)))) goto END;
    if (!(reported2=(short int *)malloc(sizeof(short int)*(Nlabels+1)))) goto END;
    if (!(p=(double *)malloc(sizeof(double)*(Nlabels+1)))) goto END;
    if (!(group=(char *)malloc(sizeof(char)*(Nlabels+1)))) goto END;

    memset(group,0,(Nlabels+1));
    memset(reported1,0,sizeof(short int)*(Nlabels+1));
    for (lab=0; lab<=Nlabels; lab++)
    {
        p[lab]=1.0;
        for (study=0; study<(*ale1).Nexperiments; study++)
        {
            memset(reported,0,sizeof(short int)*(Nlabels+1));
            for (foci=0; foci<(*ale1).TotalFoci; foci++)
            {
                if (((*ale1).experiment[foci]==study) && ((*ale1).TalLabel[foci]==lab))
                {
                    reported[lab]++;
                    if ((*ale1).p[foci]<p[lab])
                    {
                        p[lab]=(*ale1).p[foci];
                        group[lab]=1;
                    }
                }
            }
            if (reported[lab]) reported1[lab]++;
        }
    }


    memset(reported2,0,sizeof(short int)*(Nlabels+1));
    for (lab=0; lab<=Nlabels; lab++)
    {
        for (study=0; study<(*ale2).Nexperiments; study++)
        {
            memset(reported,0,sizeof(short int)*(Nlabels+1));
            for (foci=0; foci<(*ale2).TotalFoci; foci++)
            {
                if (((*ale2).experiment[foci]==study) && ((*ale2).TalLabel[foci]==lab))
                {
                    reported[lab]++;
                    if ((*ale2).p[foci]<p[lab])
                    {
                        p[lab]=(*ale2).p[foci];
                        group[lab]=2;
                    }
                }
            }
            if (reported[lab]) reported2[lab]++;
        }
    }


    sprintf(fname,"%s//Talairach structure frequencies.csv",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"Talairach structure,,,,,A frequency, B frequency, pvalue, direction\n");
        for (lab=0; lab<=Nlabels; lab++)
        {
            if (reported1[lab] || reported2[lab])
            {
                b=FindEntryInTalairachLabels(labels, Nl, lab);
                fprintf(fp,"%s,",&b[1]);
                if (group[lab]==1) fprintf(fp,"%f,%f,%f,%s\n",(double)reported1[lab]/(*ale1).Nexperiments,(double)reported2[lab]/(*ale2).Nexperiments,p[lab],"A>B");
                else fprintf(fp,"%f,%f,%f,%s\n",(double)reported1[lab]/(*ale1).Nexperiments,(double)reported2[lab]/(*ale2).Nexperiments,p[lab],"B>A");
            }
        }
        fclose(fp);
    }

    result=1;
END:

    if (reported) free(reported);
    if (reported1) free(reported1);
    if (reported2) free(reported2);
    if (p) free(p);
    if (group) free(group);
    if (labels) free(labels);
    ReleaseImage(&Tal);

    return result;
}

//======================================================================================================
//FILTER THE EXPERIMENT TO REMOVE STUDIES THAT DONT HAVE THE KEYWORD IN THE TALAIRACH LOCATION
//OF AT LEAST ONE OF THEIR FOCI
//======================================================================================================
int FilterExperimentByKeyword(HWND hwnd, struct Coordinates *ale, struct KeyWord KW[], int KeyWords, int include)
{
    struct Image TalImg;
    struct Coordinates Fale;
    char fname[MAX_PATH];
    char *labels = NULL;
    char *b;
    int removed=0;
    int LengthLabels;
    int Nentries;
    int iExp, foci;
    int found, test;
    int i;
    //int ExpFoci;
    char txt[256];
    //FILE *fp;

    //fp=fopen("c:/temp/quality.csv","w");

    memset(&Fale,0,sizeof(struct Coordinates));
    memset(&TalImg,0,sizeof(struct Image));

    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &TalImg, 0))
    {
        MessageBox(NULL,"Filtering not availabale without downloading the Talairach image file.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    labels=LoadTalairachLabels(&LengthLabels);
    if (LengthLabels<=0)
    {
        MessageBox(NULL,"Filtering not availabale without downloading the Talairach labels file.","",MB_OK|MB_ICONWARNING);
        goto END;
    }
    Nentries=BiggestTalairachLabel(labels, LengthLabels);
    RemoveNonGM(&TalImg, labels, LengthLabels, Nentries);

    GetTalairachLabelsEx(ale, &TalImg);

    CopyCoordinates(ale, &Fale);
    Fale.TotalFoci      = 0;
    Fale.Nexperiments   = 0;
    for (iExp=0; iExp<(*ale).Nexperiments; iExp++)
    {
        found = 0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ((*ale).experiment[foci] == iExp)
            {
                //ExpFoci=foci;
                b = FindEntryInTalairachLabels(labels, LengthLabels, (*ale).TalLabel[foci]);
                test = 1;
                for (i=0; (i<KeyWords) && test; i++)
                {
                    if (!strstr(b, KW[i].txt)) test *= 0;
                }
                if (test) found=1;
            }
        }

        //fprintf(fp,"%s,%d,%d\n",(*ale).ID[iExp].txt,(*ale).subjects[ExpFoci],found);


        if ((found && include) || (!found && !include))
        {
            for (foci=0; foci<(*ale).TotalFoci; foci++)
            {
                if ((*ale).experiment[foci] == iExp)
                {
                    CopyCoordinatesentry(ale, foci, &Fale, Fale.TotalFoci);
                    Fale.experiment[Fale.TotalFoci] = Fale.Nexperiments;
                    Fale.TotalFoci++;
                }
            }
            Fale.Nexperiments++;
        }
        else removed++;
    }

    //fclose(fp);

    sprintf(txt,"%d removed of %d",removed, (*ale).Nexperiments);
    MessageBox(NULL,txt,"",MB_OK);

    FreeCoordinates(ale);
    CopyCoordinates(&Fale, ale);//the filtered ALE structure

END:
    ReleaseImage(&TalImg);
    FreeCoordinates(&Fale);

    return removed;
}


//======================================================================================================
//FILL THE COMBO BOX FOR FILTERING THE EXPERIMENTS
//======================================================================================================
int FillFilterComboBox(HWND hwnd, int ID)
{
    int N=0;
    int Labelslength;
    int nTalEntries;
    int l;
    int L;
    char *b, *c;
    char *labels=NULL;
    char txt[1024];

    if (!(labels=LoadTalairachLabels(&Labelslength))) goto END;
    nTalEntries=BiggestTalairachLabel(labels, Labelslength);

    SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_RESETCONTENT,0,0);
    SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM)"Left");
    SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM)"Right");
    SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM)"Cerebellum");
    SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM)"Cerebrum");

    //INSERT LOBES
    for (l=0; l<nTalEntries; l++)
    {
        if ( (b = FindEntryInTalairachLabels(labels, Labelslength, l)) )
        {
            if ( (b = strstr(b, ",")) )
            {
                if ((c = &b[1]) && (b = strstr(c,",")))//b points to the comma after the lobe label
                {
                    if ( (L=b-c)<1024 )
                    {
                        memcpy(txt,c,L);
                        txt[L] = '\0';
                        if (SendDlgItemMessage(hwnd,ID_LABEL_FILTER, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM) txt) == CB_ERR)
                        {
                            SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM) txt);
                        }
                    }
                }
            }
        }
    }

    //INSERT GYRUS
    for (l=0; l<nTalEntries; l++)
    {
        if ( (b = FindEntryInTalairachLabels(labels, Labelslength, l)) )
        {
            if ( (b = strstr(b, ",")) && (b = strstr(&b[1], ",")) )
            {
                if ((c = &b[1]) && (b = strstr(c,",")))//b points to the comma after the lobe label
                {
                    if ( (L=b-c)<1024 )
                    {
                        memcpy(txt,c,L);
                        txt[L] = '\0';
                        if (SendDlgItemMessage(hwnd,ID_LABEL_FILTER, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM) txt) == CB_ERR)
                        {
                            SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM) txt);
                        }
                    }
                }
            }
        }
    }

    //INSERT BRODMAN AREAS
    for (l=0; l<nTalEntries; l++)
    {
        if ( (b = FindEntryInTalairachLabels(labels, Labelslength, l)) )
        {
            if ( (b = strstr(b, ",")) && (b = strstr(&b[1], ",")) && (b = strstr(&b[1], ",")) && (b = strstr(&b[1], ",")))
            {
                if ((c = &b[1]))//b points to the comma after the lobe label
                {
                    if ( (L=strlen(c))<1024 )
                    {
                        memcpy(txt,c,L);
                        txt[L] = '\0';
                        if (SendDlgItemMessage(hwnd,ID_LABEL_FILTER, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM) txt) == CB_ERR)
                        {
                            SendDlgItemMessage(hwnd,ID_LABEL_FILTER,CB_ADDSTRING,(WPARAM)0,(LPARAM) txt);
                        }
                    }
                }
            }
        }
    }

END:
    if (labels) free(labels);
    return N;
}

//======================================================================================================
//compute the voxel-wise ALE null distribution
//null is from randomisation of foci by random effect method
//======================================================================================================
int TestVoxelWiseNullALEdistribution(HWND hwnd, struct Image *mask)
{

    int X,Y,Z;
    int voxel,voxels;
    int iteration;
    int index;
    double H[10001];
    double norm;
    double MaxALE;
    double ALEvalue;
    float FWHM;
    float sigma;
    float x0,y0,z0;
    float dx, dy, dz;
    float *aleimg=NULL;
    float min;
    struct Coordinates ale;
    struct Coordinates alecpy;
    struct Clusters cl;
    char fname[MAX_PATH];
    FILE *fp;

    memset(H,0,sizeof(double)*10001);

    x0 = (*mask).x0;
    y0 = (*mask).y0;
    z0 = (*mask).z0;
    dx = (*mask).dx;
    dy = (*mask).dy;
    dz = (*mask).dz;
    X = (*mask).X;
    Y = (*mask).Y;
    Z = (*mask).Z;
    voxels=X*Y*Z;

    if (!(aleimg=malloc(voxels*sizeof(float)))) goto END;

    //load an experiment and then randomise it
    //this just gives the same number of studies and foci per study
    memset(&ale,0,sizeof(struct Coordinates));
    LoadExperimentsCOORDINATES(hwnd, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);
    memset(&alecpy,0,sizeof(struct Coordinates));
    CopyCoordinates(&ale,&alecpy);



    FWHM=FWHM_ALE(ale.Nexperiments);
    sigma=SD_ALE(FWHM);

    MaxALE = MaxPossibleALE(&ale, dx, dy, dz, sigma);

    memset(&cl,0,sizeof(struct Clusters));
    FillClusterStructure(&ale, &cl, sigma);


    norm=0.0;
    for (iteration=0; iteration<1000; iteration++)
    {
        RandomiseFociRandomEffects((*mask).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, &cl, sigma);
        CombineExperimentsIntoALEimage(&ale, aleimg,  X,Y, Z, dx, dy,  dz, x0,  y0, z0, sigma, 0, 1.0, 0.0);
        for(voxel=0; voxel<voxels; voxel++)
        {
            if ((*mask).img[voxel]>0.0)
            {
                ALEvalue=sqrt(aleimg[voxel]/MaxALE)*10000;
                H[(int)ALEvalue]+=1.0;
                norm+=1.0;
            }
        }
    }
    CombineExperimentsIntoALEimage(&alecpy, (*mask).img,  X,Y, Z, dx, dy,  dz, x0,  y0, z0, sigma, 0, 1.0, 0.0);

    for (index=0; index<10001; index++)
    {
        H[index]/=norm;
    }
    for (index=1; index<10001; index++)
    {
        H[index]+=H[index-1];
    }
    for (index=0; index<10001; index++)
    {
        H[index]/=H[10000];
    }


    for(voxel=0; voxel<voxels; voxel++)
    {
        ALEvalue=sqrt((*mask).img[voxel]/MaxALE)*10000;
        index=(int)ALEvalue;
        if (index) index--;
        (*mask).img[voxel]=1.0-H[index];
    }

    RLflip((*mask).img, X, Y, Z);
    ImageMinMax((*mask).img, X, Y,Z, (*mask).DataType, &min, &(*mask).MaxIntensity);
    SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
    (*mask).DataType=DT_FLOAT;

    // TestGingerAleFDR(mask);

    sprintf(fname,"c://temp//ALEcdf.csv");
    fp=fopen(fname,"w");
    for (index=0; index<10001; index++)
    {
        fprintf(fp,"%f,%f\n",sqrt(MaxALE)*index/10000,H[index]);
    }
    fclose(fp);


END:
    if (aleimg) free(aleimg);
    FreeCoordinates(&ale);

    return 1;
}

//======================================================================================================
//compute the voxel-wise ALE null distribution
//null is from randomisation of voxels like the latest ALE method
//======================================================================================================
int TestVoxelWiseNullALEdistribution2(HWND hwnd, struct Image *mask)
{

    int X,Y,Z;
    int voxel,voxels;
    int iteration;
    int index;
    int iExp;
    int Rvoxel;
    double H[10001];
    double norm;
    double MaxALE;
    double ALEvalue;
    float FWHM;
    float sigma;
    float x0,y0,z0;
    float dx, dy, dz;
    float *aleimg=NULL;
    float min;
    struct Coordinates ale;
    char fname[MAX_PATH];
    FILE *fp;

    memset(H,0,sizeof(double)*10001);

    x0 = (*mask).x0;
    y0 = (*mask).y0;
    z0 = (*mask).z0;
    dx = (*mask).dx;
    dy = (*mask).dy;
    dz = (*mask).dz;
    X = (*mask).X;
    Y = (*mask).Y;
    Z = (*mask).Z;
    voxels=X*Y*Z;


    //load an experiment and then randomise it
    //this just gives the same number of studies and foci per study
    memset(&ale,0,sizeof(struct Coordinates));
    LoadExperimentsCOORDINATES(hwnd, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);

    if (!(aleimg=malloc(ale.Nexperiments*voxels*sizeof(float)))) goto END;

    FWHM=FWHM_ALE(ale.Nexperiments);
    sigma=SD_ALE(FWHM);

    MaxALE = MaxPossibleALE(&ale, dx, dy, dz, sigma);

    for (iExp=0; iExp<ale.Nexperiments; iExp++)
    {
        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, iExp, &aleimg[iExp*voxels], sigma, 0, 1.0);
    }


    norm=0.0;
    for (iteration=0; iteration<10000000; iteration++)
    {
        ALEvalue=1.0;
        for (iExp=0; iExp<ale.Nexperiments; iExp++)
        {
            Rvoxel=RandomImageVoxel((*mask).img, voxels);
            ALEvalue *= (1.0-aleimg[iExp*voxels + Rvoxel]);
        }
        ALEvalue=1.0-ALEvalue;
        index=10000*sqrt(ALEvalue/MaxALE);
        H[index]+=1.0;
        norm+=1.0;
    }

    for (index=0; index<10001; index++)
    {
        H[index]/=norm;
    }
    for (index=1; index<10001; index++)
    {
        H[index]+=H[index-1];
    }
    for (index=0; index<10001; index++)
    {
        H[index]/=H[10000];
    }

    CombineExperimentsIntoALEimage(&ale, (*mask).img,  X,Y, Z, dx, dy,  dz, x0,  y0, z0, sigma, 0, 1.0, 0.0);
    for(voxel=0; voxel<voxels; voxel++)
    {
        ALEvalue=sqrt((*mask).img[voxel]/MaxALE)*10000;
        index=(int)ALEvalue;
        if (index) index--;
        (*mask).img[voxel]=1.0-H[index];
    }

    RLflip((*mask).img, X, Y, Z);
    ImageMinMax((*mask).img, X, Y,Z, (*mask).DataType, &min, &(*mask).MaxIntensity);
    SendMessage(hwnd, WM_COMMAND, ID_REDRAW,0);
    (*mask).DataType=DT_FLOAT;

    //TestGingerAleFDR(mask);

    sprintf(fname,"c://temp//ALEcdfA.csv");
    fp=fopen(fname,"w");
    for (index=0; index<10001; index++)
    {
        fprintf(fp,"%f,%f\n",sqrt(MaxALE)*index/10000,H[index]);
    }
    fclose(fp);


END:
    if (aleimg) free(aleimg);
    FreeCoordinates(&ale);

    return 1;
}



//======================================================================================================
//test FDR on p-value image from GingerALE
//======================================================================================================
int TestGingerAleFDR(struct Image *pimage, double q)
{
    int N;
    int i,n1,n2;
    int X,Y,Z;
    int voxel,voxels;
    int *sort=NULL;
    int Ntests;
    double x,y;
    double C;
    double *p=NULL;
    double pFDR,pFDRn;
    char txt[256];
    FILE *fp;

    X = (*pimage).X;
    Y = (*pimage).Y;
    Z = (*pimage).Z;
    voxels=X*Y*Z;


    N=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*pimage).img[voxel]<=q)) N++;
    }


    Ntests=226657;


    C=0.0;
    for (i=1; i<=Ntests; i++)
    {
        C+=1.0/i;
    }


    if (!(p=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(N*sizeof(int)))) goto END;


    i=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*pimage).img[voxel]<=q)  )
        {
            p[i]=(*pimage).img[voxel];
            i++;
        }
    }

    for (i=0; i<N; i++) sort[i]=i;
    QuickSort(p,sort,N);

    if ( (fp=fopen("c:\\temp\\p.txt","w")) )
    {
        for (i=0; i<N; i++) fprintf(fp,"%f\n",p[sort[i]]);
        fclose(fp);
    }


    pFDR=pFDRn=0.0;
    n1=n2=0;
    for (i=0; i<N; i++)
    {
        x=(double)(i+1)*q/Ntests;

        if (p[sort[i]]<=x)
        {
            pFDR=p[sort[i]];
            n1++;
        }

        y=(double)(i+1)*q/C/Ntests;
        if (p[sort[i]]<=y)
        {
            pFDRn=p[sort[i]];
            n2++;
        }

    }

    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*pimage).img[voxel]<=pFDRn)  ) (*pimage).img[voxel]=1.0;
        else (*pimage).img[voxel]=0.0;
    }


    sprintf(txt,"Total < 0.05 %d   Significant after FDR %d   pFDR *%f   \n Significant after FDR %d   pFDR *%f ",N,n1,pFDR,n2,pFDRn);
    MessageBox(NULL,txt,"",MB_OK);

END:
    if (p) free(p);
    if (sort) free(sort);
    return 1;
}

//======================================================================================================
//test FDR on p-value image from GingerALE
//RECREATE THE GINGERALE CODE THAT LOOKS THROUGH ALL P VALUES, EVEN THOSE>q
//======================================================================================================
int TestGingerAleFDR2(struct Image *mask, double q)
{

    int i,n1,n2;
    int X,Y,Z;
    int voxel,voxels;
    int *sort=NULL;
    int Ntests;
    struct Image pimage;
    double x,y;
    double C;
    double *p=NULL;
    double pFDR,pFDRn;
    char txt[256];
    FILE *fp;

    X = (*mask).X;
    Y = (*mask).Y;
    Z = (*mask).Z;
    voxels=X*Y*Z;


    memset(&pimage,0,sizeof(struct Image));
    if (!LoadAnalyzeOrNifti(NULL, &pimage, 0)) goto END;

    Ntests=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*mask).img[voxel]>0.0) Ntests++;
    }

//sprintf(txt,"%d",Ntests);MessageBox(NULL,txt,"",MB_OK);


    C=0.0;
    for (i=1; i<=Ntests; i++)
    {
        C+=1.0/i;
    }


    if (!(p=(double *)malloc(Ntests*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(Ntests*sizeof(int)))) goto END;


    i=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*mask).img[voxel]>0.0)  )
        {
            p[i]=pimage.img[voxel];
            i++;
        }
    }

    for (i=0; i<Ntests; i++) sort[i]=i;
    RadixSort(p,sort,Ntests,6);

    if ((fp=fopen("c://temp//pvals.txt","w")))
    {
        for (i=0; i<1000; i++) fprintf(fp,"%g\n",p[sort[i]]);
        fclose(fp);
    }


    pFDR=pFDRn=0.0;
    n1=n2=0;
    for (i=0; i<Ntests; i++)
    {
        x=(double)(i+1)*q/Ntests;

        if (p[sort[i]]<=x)
        {
            pFDR=p[sort[i]];
            n1++;
        }

        y=(double)(i+1)*q/C/Ntests;
        if (p[sort[i]]<=y)
        {
            pFDRn=p[sort[i]];
            n2++;
        }

    }

    sprintf(txt,"Tests %d  \n Significant after FDR %d  \n pFDR *%f   \n Significant after FDRn %d  \n  pFDRn *%f ",Ntests,n1,pFDR,n2,pFDRn);
    MessageBox(NULL,txt,"",MB_OK);

END:
    if (p) free(p);
    if (sort) free(sort);
    ReleaseImage(&pimage);

    return 1;
}


//======================================================================================================
//test FDR on p-value image from GingerALE
//USE THE FOLLOWING CODE IN R TO TEST THE FDR
/*
pval=read.table("c:\\temp\\p.txt",header=F)
pval.fdr=p.adjust(pval$V1,method ="BH", n = 226657)
pval.fdr
*/
//======================================================================================================
int TestSDM_FDR(HWND hwnd, struct Image *mask, double q)
{
    int N;
    int i,n1;
    int X,Y,Z;
    int voxel,voxels;
    int *sort=NULL;
    int Ntests;
    double x;
    double *p=NULL;
    double pFDR;
    char txt[256];
    struct Image pos,neg;
    FILE *fp;

    X = (*mask).X;
    Y = (*mask).Y;
    Z = (*mask).Z;
    voxels=X*Y*Z;

    //count the number of voxels in the mask image. This is the number of tests
    Ntests=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ( ((*mask).img[voxel]>0.0) ) Ntests++;
    }


    //load the positive and negative p-value images from SDM
    memset(&pos,0,sizeof(struct Image));
    memset(&neg,0,sizeof(struct Image));
    if (!LoadAnalyzeOrNifti(hwnd, &pos, 0)) goto END;
    if (!LoadAnalyzeOrNifti(hwnd, &neg, 0)) goto END;


    //compute the number of p-values <= q
    N=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((*mask).img[voxel]>0.0))
        {
            if ( ((1.0-pos.img[voxel])<=q)) N++;
            if ( ((1.0-neg.img[voxel])<=q)) N++;
        }
    }

    if (!(p=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(N*sizeof(int)))) goto END;


    //put the p-values <= q into array p[]
    i=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (((*mask).img[voxel]>0.0))
        {
            if ( ((1.0-pos.img[voxel])<=q)  )
            {
                p[i]=1.0-pos.img[voxel];
                i++;
            }
            if ( ((1.0-neg.img[voxel])<=q)  )
            {
                p[i]=1.0-neg.img[voxel];
                i++;
            }
        }
    }



    QuickSort(p,sort,N);

    if ( (fp=fopen("c:\\temp\\p.txt","w")) )
    {
        for (i=0; i<N; i++) fprintf(fp,"%f\n",p[sort[i]]);
        fclose(fp);
    }


    pFDR=0.0;
    n1=0;
    for (i=0; i<N; i++)
    {
        x=(double)(i+1)/Ntests*q;
        if (p[sort[i]]<=x)
        {
            pFDR=p[sort[i]];
            n1++;
        }
    }

    for (voxel=0; voxel<voxels; voxel++)
    {
        if  ( ((1.0-pos.img[voxel])<=pFDR) ) (*mask).img[voxel]=(pFDR - (1.0-pos.img[voxel]))/pFDR;
        else if  ( ((1.0-neg.img[voxel])<=pFDR) ) (*mask).img[voxel]=(pFDR-(1.0-neg.img[voxel]))/pFDR;
        else (*mask).img[voxel]=0.0;
    }


    sprintf(txt,"Number of Tests=%d,   Total < 0.05=%d   Significant after FDR=%d    pFDR=%f ",Ntests, N,n1,pFDR);
    MessageBox(NULL,txt,"",MB_OK);



END:
    if (p) free(p);
    if (sort) free(sort);
    ReleaseImage(&pos);
    ReleaseImage(&neg);
    return 1;
}


//======================================================================================================
//test of the scheme
//random experiments with random numbers of foci distributed randomly
//how many significant clusters do we get?
//random experiments with random numbers of foci + a consistent foci accross experiments
//how many clusters do we get?
//======================================================================================================
int TestLocalALErandomExperiments(HWND hwnd, struct Image *image)
{

    int iexp;
    int X,Y,Z;
    int voxels = (*image).X*(*image).Y*(*image).Z;
    int iteration;
    int clusters;
    int Hbh[1000], Hfdr[1000], Hfcdr[1000],i;
    float sigma=4.25;
    float x0,y0,z0;
    float dx, dy, dz;
    float *out = NULL;
    double pmethod[3];
    struct Coordinates ale;
    char fname[MAX_PATH];
    FILE *fp;


    x0 = (*image).x0;
    y0 = (*image).y0;
    z0 = (*image).z0;
    dx = (*image).dx;
    dy = (*image).dy;
    dz = (*image).dz;
    X = (*image).X;
    Y = (*image).Y;
    Z = (*image).Z;


    //load an experiment and then randomise it
    //this just gives the same number of studies and foci per study
    memset(&ale,0,sizeof(struct Coordinates));
    LoadExperimentsCOORDINATES(hwnd, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);


    if (!(out = (float *)malloc(voxels*sizeof(float)*5))) goto END;


    memset(Hbh,0,sizeof(int)*1000);
    memset(Hfdr,0,sizeof(int)*1000);
    memset(Hfcdr,0,sizeof(int)*1000);

    clusters=0;
    for (iteration=0; iteration<1000; iteration++)
    {

        for (iexp=0; iexp<ale.Nexperiments; iexp++)
        {
            RandomiseFociInexperiment((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, iexp);
        }

        ComputePvalueBySpatialRandomisation(hwnd, &ale, (*image).img, out, X, Y, Z,
                                            dx, dy, dz, x0, y0, z0,
                                            sigma, 0.05, "c:\\temp", 1, pmethod, 0);



        clusters = CountSignificantClustersFast(ale.x, ale.y, ale.z, ale.p, ale.cluster, ale.TotalFoci, sigma, pmethod[BHFDR_METHOD],0);
        if (clusters<1000) Hbh[clusters]++;

        clusters = CountSignificantClustersFast(ale.x, ale.y, ale.z, ale.p, ale.cluster, ale.TotalFoci, sigma, pmethod[FDR_METHOD],0);
        if (clusters<1000) Hfdr[clusters]++;

        clusters = CountSignificantClustersFast(ale.x, ale.y, ale.z, ale.p, ale.cluster, ale.TotalFoci, sigma, pmethod[FCDR_METHOD],0);
        if (clusters<1000) Hfcdr[clusters]++;


        sprintf(fname,"c:\\temp\\TestActivations%d.txt", iteration);
        if (iteration<100) SaveExperimentsALE(&ale, fname, "Test activations", 1.0,0);

    }//iteration

    if ( (fp=fopen("c:\\temp\\hist Random experiments.csv","w")) )
    {
        fprintf(fp,"number, BH, FDR, FCDR\n");
        for (i=0; i<1000; i++)
        {
            if (Hbh[i] || Hfdr[i] || Hfcdr[i]) fprintf(fp,"%d,%d, %d, %d\n",i,Hbh[i], Hfdr[i], Hfcdr[i]);
        }
        fclose(fp);
    }


END:
    if (out) free(out);
    FreeCoordinates(&ale);

    return 0;
}
//======================================================================================================
//test of the scheme
//random experiments with random numbers of foci distributed randomly
//how many significant clusters do we get?
//random experiments with random numbers of foci + a consistent foci accross experiments
//how many clusters do we get?
//======================================================================================================
int TestRandomExperiment(struct Image *image)
{

    int iexp, foci;
    int ix, iy, iz, Rvoxel;
    int X,Y,Z;
    int done;
    int voxels = (*image).X*(*image).Y*(*image).Z;
    float x0,y0,z0;
    float dx, dy, dz;
    struct Coordinates ale;
    char fname[MAX_PATH];


    x0 = (*image).x0;
    y0 = (*image).y0;
    z0 = (*image).z0;
    dx = (*image).dx;
    dy = (*image).dy;
    dz = (*image).dz;
    X = (*image).X;
    Y = (*image).Y;
    Z = (*image).Z;

    Rvoxel = RandomImageVoxel((*image).img, voxels);
    XYZfromVoxelNumber(Rvoxel, &ix, &iy, &iz, X, Y, Z );

    //load an experiment and then randomise it
    //this just gives the same number of studies and foci per study
    memset(&ale,0,sizeof(struct Coordinates));
    LoadExperimentsCOORDINATES(NULL, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);

    for (iexp=0; iexp<ale.Nexperiments; iexp++)
    {
        RandomiseFociInexperiment((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, iexp);
    }


    for (iexp=0; iexp<ale.Nexperiments; iexp++)
    {
        done=0;
        for (foci=0; foci<ale.TotalFoci; foci++)
        {
            if (ale.experiment[foci] == iexp && (!done))
            {
                done=1;
                ale.x[foci] = dx*ix - x0;
                ale.y[foci] = dy*iy - y0;
                ale.z[foci] = dz*iz - z0;
            }
        }
    }

    sprintf(fname,"c://temp//randALE.txt");
    SaveExperimentsALE(&ale, fname, "Random activations", 1.0,0);

    FreeCoordinates(&ale);

    return 0;
}
//======================================================================================================
//test of the scheme
//random experiments with random numbers of foci distributed randomly
//how many significant clusters do we get?
//random experiments with random numbers of foci + a consistent foci accross experiments
//how many clusters do we get?
//======================================================================================================
int TestLocalALEclosestFoci(HWND hwnd, struct Image *image)
{

    int study;
    int i, j;
    int X,Y,Z;
    int Hdist[256];
    float x0,y0,z0;
    float dx, dy, dz;
    double dist, mindist;
    struct Coordinates ale;
    FILE *fp;


    x0 = (*image).x0;
    y0 = (*image).y0;
    z0 = (*image).z0;
    dx = (*image).dx;
    dy = (*image).dy;
    dz = (*image).dz;
    X = (*image).X;
    Y = (*image).Y;
    Z = (*image).Z;


    memset(&ale,0,sizeof(struct Coordinates));
    memset(Hdist,0,sizeof(int)*256);
    LoadExperimentsCOORDINATES(hwnd, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);

    for (study=0; study<ale.Nexperiments; study++)
    {
        for (i=0; i<ale.TotalFoci; i++)
        {
            if (ale.experiment[i]==study)
            {
                mindist=10000.0;
                for (j=0; j<ale.TotalFoci; j++)
                {
                    if ((ale.experiment[j]==study) && (i!=j))
                    {
                        dist = sqrt(    pow(ale.x[i] - ale.x[j], 2) +
                                        pow(ale.y[i] - ale.y[j], 2) +
                                        pow(ale.z[i] - ale.z[j], 2)
                                   );
                        if (dist<mindist) mindist = dist;
                    }
                }//j
                j = mindist + 0.5;
                if (j < 254) Hdist[j]++;
                else Hdist[255]++;
            }
        }//i
    }

    if ( (fp=fopen("c:\\temp\\distance histogram.csv","w")) )
    {
        for (j=0; j<256; j++) fprintf(fp,"%d, %d\n",j,Hdist[j]);
        fclose(fp);
    }


    FreeCoordinates(&ale);

    return 0;
}
//======================================================================================================
//test the random effect randomisation of the experiment
/*
struct Clusters{
  int TotalClusters;
  int *Nclusters;//number of clusters in experiment j = Nclusters[j]
  int *experiment;//the experiment this cluster belongs to
  float *x;
  float *y;//coordintates of the cluster centres
  float *z;
  float *S;//spread of cluster j = S[j]
  float *MeanDist;//mean distance of foci from the centre
  int *Nfoci;//number of foci in cluster j = Nfoci[j]
};*/
//======================================================================================================
int TestLocalALErandomEffects(struct Image *image)
{
    int iexp,experiment=0;
    int X,Y,Z;
    int voxel, voxels = (*image).X*(*image).Y*(*image).Z;
    int bin;
    int Bins=10;
    double Count;
    int iter;
    float x0,y0,z0;
    float dx, dy, dz;
    double H[100];
    double tmp[100];
    double H1[100], H12[100];
    double H2[100], H22[100];
    float norm;
    float *MA = NULL;
    float sigma=6.5;
    struct Coordinates ale, CpyALE;
    struct Clusters cl;
    FILE *fp;

    x0 = (*image).x0;
    y0 = (*image).y0;
    z0 = (*image).z0;
    dx = (*image).dx;
    dy = (*image).dy;
    dz = (*image).dz;
    X = (*image).X;
    Y = (*image).Y;
    Z = (*image).Z;

    norm = NormALE(sigma, dx, dy, dz);
    memset(H,0,100*sizeof(double));
    memset(H1,0,100*sizeof(double));
    memset(H12,0,100*sizeof(double));
    memset(H2,0,100*sizeof(double));
    memset(H22,0,100*sizeof(double));

    memset(&ale,0,sizeof(struct Coordinates));
    memset(&CpyALE,0,sizeof(struct Coordinates));
    memset(&cl,0,sizeof(struct Clusters));

    if (!(MA = (float *)malloc(voxels*sizeof(float)))) goto END;

    LoadExperimentsCOORDINATES(NULL, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);

//RandomiseFociInexperiment((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, experiment);

    CopyCoordinates(&ale,&CpyALE);

    FillClusterStructure(&ale, &cl, sigma);

    fp=fopen("c://temp//clusters.csv","w");
    for (iexp=0; iexp<ale.Nexperiments; iexp++)
    {
        fprintf(fp,"%d,%d\n",iexp,cl.Nclusters[iexp]);
    }
    fclose(fp);

    CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, experiment, MA, sigma, 0, 1.0);
    Count=0.0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*image).img[voxel]>0.0)
        {
            bin = Bins*MA[voxel]/norm;
            if (bin<Bins)
            {
                H[bin] += 1.0;
                Count +=1.0;
            }
        }
    }
    if (Count>0.0)
    {
        for (bin=0; bin<Bins; bin++) H[bin]/=Count;
    }
    else goto END;

    for (iter=0; iter<1000; iter++)
    {
        RandomiseFociRandomEffects((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, &cl, sigma);
        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, experiment, MA, sigma,  0, 1.0);
        Count=0.0;
        memset(tmp,0,100*sizeof(double));
        for (voxel=0; voxel<voxels; voxel++)
        {
            if ((*image).img[voxel]>0.0)
            {
                bin = Bins*MA[voxel]/norm;
                if (bin<Bins)
                {
                    tmp[bin] += 1.0;
                    Count += 1.0;
                }
            }
        }
        if (Count>0.0)
        {
            for (bin=0; bin<Bins; bin++) H1[bin] += tmp[bin]/Count;
            for (bin=0; bin<Bins; bin++) H12[bin] += pow(tmp[bin]/Count,2);
        }
        else goto END;
    }
    for (bin=0; bin<Bins; bin++) H1[bin] /= 1000;
    for (bin=0; bin<Bins; bin++) tmp[bin] = H12[bin] / 1000;
    for (bin=0; bin<Bins; bin++) H12[bin] = sqrt(tmp[bin] - H1[bin]*H1[bin]);


    Count=0.0;
    for (iter=0; iter<Bins; iter++)
    {
        //RandomiseFociRandomEffects((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, &cl);
        RandomiseFociInexperiment((*image).img, X, Y, Z, dx, dy, dz, x0, y0, z0, &CpyALE, experiment);
        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, &CpyALE, experiment, MA, sigma, 0, 1.0);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if ((*image).img[voxel]>0.0)
            {
                bin = Bins*MA[voxel]/norm;
                if (bin<Bins)
                {
                    H2[bin] += 1.0;
                    Count += 1.0;
                }
            }
        }
    }
    if (Count>0.0)
    {
        for (bin=0; bin<Bins; bin++) H2[bin]/=Count;
    }
    else goto END;



    fp=fopen("c://temp//alehist.csv","w");
    for (bin=0; bin<Bins; bin++)
    {
        fprintf(fp,"%f,%f,%f,%f,%f\n",norm*bin/Bins, H[bin], H1[bin],H12[bin],H2[bin]);
    }
    fclose(fp);

END:

    FreeCoordinates(&ale);
    FreeCoordinates(&CpyALE);
    FreeCluster(&cl);
    if (MA) free(MA);

    return 0;
}

//======================================================================================================
//Find the significant foci, and randomise all others
/*
struct Clusters{
  int TotalClusters;
  int *Nclusters;//number of clusters in experiment j = Nclusters[j]
  int *experiment;//the experiment this cluster belongs to
  float *x;
  float *y;//coordintates of the cluster centres
  float *z;
  float *S;//spread of cluster j = S[j]
  float *MeanDist;//mean distance of foci from the centre
  int *Nfoci;//number of foci in cluster j = Nfoci[j]
};*/
//======================================================================================================
int TestLocalALErandomNonSignificantFoci(HWND hwnd, struct Image *image)
{
    int Ncl;
    float *out = NULL;
    float *ALEs = NULL;
    float sigma=4.25;
    float *NoClust = NULL;
    double pmethod[3];
    struct Coordinates ale, CpyALE;
    struct Clusters cl;
    int Hfcdr[10],Hfdr[10],Hbhfdr[10],bin;
    int Count;
    int foci;
    int X,Y,Z;
    int voxel,voxels;
    int iter;
    int iexp;
    float x0,y0,z0;
    float dx,dy,dz;
    char fname[MAX_PATH];
    FILE *fp;

    x0 = (*image).x0;
    y0 = (*image).y0;
    z0 = (*image).z0;
    dx = (*image).dx;
    dy = (*image).dy;
    dz = (*image).dz;
    X = (*image).X;
    Y = (*image).Y;
    Z = (*image).Z;
    voxels=X*Y*Z;

    memset(Hfcdr,0,sizeof(int)*10);
    memset(Hfdr,0,sizeof(int)*10);
    memset(Hbhfdr,0,sizeof(int)*10);


    memset(&ale,0,sizeof(struct Coordinates));
    memset(&CpyALE,0,sizeof(struct Coordinates));
    memset(&cl,0,sizeof(struct Clusters));

    if (!(out = (float *)malloc(IMAGES*X*Y*Z*sizeof(float)))) goto END;
    if (!(NoClust = (float *)malloc(X*Y*Z*sizeof(float)))) goto END;
    memcpy(NoClust, (*image).img, X*Y*Z*sizeof(float));

    LoadExperimentsCOORDINATES(hwnd, &ale, X, Y, Z, dx, dy, dz, x0, y0, z0);
    if (!(ALEs = (float *)malloc(ale.TotalFoci*sizeof(float)))) goto END;


    CopyCoordinates(&ale,&CpyALE);

    FillClusterStructure(&ale, &cl, sigma);



    ComputePvalueBySpatialRandomisation(hwnd, &ale, (*image).img, out, X, Y, Z, dx, dy, dz, x0, y0, z0,
                                        sigma, 0.05, "c://temp", 1, pmethod, 0);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (out[CLUSTNUM*voxels + voxel]>0.0) NoClust[voxel] = 0.0;
    }




    ComputeALEatFoci(&ale, dx, dy, dz, ALEs, sigma, 0, ale.TotalFoci-1);

    Ncl = CountSignificantMApeaks(ale.x, ale.y, ale.z, ale.p, ALEs, ale.cluster, ale.TotalFoci, sigma, pmethod[FCDR_METHOD], 0);


    fp=fopen("c:\\temp\\n.txt","w");
    for (iter=0; iter<100; iter++)
    {
        //RandomiseFociRandomEffects(NoClust, X, Y, Z, dx, dy, dz, x0, y0, z0, &CpyALE, &cl);
        for (iexp=0; iexp<ale.Nexperiments; iexp++)
        {
            RandomiseFociInexperiment(NoClust, X, Y, Z, dx, dy, dz, x0, y0, z0, &ale, iexp);
        }

        for (foci=0; foci<ale.TotalFoci; foci++)
        {
            if (ale.cluster[foci])
            {
                CopyCoordinatesentry(&ale, foci, &CpyALE, foci);
            }
        }
        sprintf(fname,"c://temp//NonSig_%d.txt",iter);
        SaveExperimentsALE(&CpyALE, fname, "Processed activations", 1.0,0);

        ComputePvalueBySpatialRandomisation(hwnd, &CpyALE, (*image).img, out, X, Y, Z, dx, dy, dz, x0, y0, z0,
                                            sigma, 0.05, "c://temp", 1, pmethod, 0);

        ComputeALEatFoci(&CpyALE, dx, dy, dz, ALEs, sigma, 0, CpyALE.TotalFoci-1);

        Count = CountSignificantMApeaks(CpyALE.x, CpyALE.y, CpyALE.z, CpyALE.p, ALEs, CpyALE.cluster, CpyALE.TotalFoci, sigma, pmethod[FCDR_METHOD], 0);
        if ((Count>=Ncl) && (Count<Ncl+10)) Hfcdr[Count-Ncl]++;
        fprintf(fp,"%d %d ",iter,Count);

        Count = CountSignificantMApeaks(CpyALE.x, CpyALE.y, CpyALE.z, CpyALE.p, ALEs, CpyALE.cluster, CpyALE.TotalFoci, sigma, pmethod[FDR_METHOD], 0);
        if ((Count>=Ncl) && (Count<Ncl+10)) Hfdr[Count-Ncl]++;
        fprintf(fp,"%d ",Count);

        Count = CountSignificantMApeaks(CpyALE.x, CpyALE.y, CpyALE.z, CpyALE.p, ALEs, CpyALE.cluster, CpyALE.TotalFoci, sigma, pmethod[BHFDR_METHOD], 0);
        if ((Count>=Ncl) && (Count<Ncl+10)) Hbhfdr[Count-Ncl]++;
        fprintf(fp,"%d\n",Count);



    }
    fclose(fp);

    fp=fopen("z://extra clusters hist.csv","w");
    for (bin=0; bin<10; bin++)
    {
        fprintf(fp,"%d,%d,%d,%d\n",bin,Hfdr[bin],Hfcdr[bin],Hbhfdr[bin]);
    }
    fclose(fp);




END:

    FreeCoordinates(&ale);
    FreeCoordinates(&CpyALE);
    FreeCluster(&cl);
    if (ALEs) free(ALEs);
    if (out) free(out);
    if (NoClust) free(NoClust);

    return 0;
}
//======================================================================================================
//USE SHORTEST PATH ALGORITHM TO FIND VALID FOCI CONNECTED TO A PEAK
//======================================================================================================
int ClusterMA(float *distance, float *ALE, int N, int peak, float Shortest[], float MinDistance)
{

    int i,j;
    int offset;
    int iter;
    int *inout;
    int *heap;
    int entered;
    float dist,newdist;
    int Count=0;


    for (i=0; i<N; i++) Shortest[i] = -100000.0; //vary large shortest distance to start with
    if (N<=1) return 0;///cant cluster without multiple peaks

    inout=(int *)calloc(N,sizeof(int));
    heap=(int *)calloc(N,sizeof(int));

    if (inout && heap)
    {


        //----------------------initially there are no connections----------------------------
        entered=1;
        Count++;
        heap[entered]=peak;
        Shortest[peak]=0.0;//peaks are connected and in the Q
        inout[peak]=entered;
        //------------------------------------------------------------------------------------------


        //--------------------------Fill the Q------------------------------------------------------
        iter=0;
        while( entered && (iter<100) )
        {

            i=heap[1];
            entered=RemoveRootElement(Shortest, heap, entered, inout);	//take out of the Q

            offset = i*N;
            for (j=0; j<N; j++)
            {

                if (((dist=distance[offset + j])<MinDistance) && (ALE[j]<=ALE[i]))
                {

//the peak is possibly spread over multiple voxels
//so need to make these equal so as no to bias the distance from the peak by the peak finding process,
//which identifies only one voxel at the peak
                    if (ALE[j]==ALE[peak]) dist=0.0;

                    //----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
                    if ((newdist=(-dist + Shortest[i]))>Shortest[j])
                    {

                        if (!inout[j])
                        {
                            Count++;
                            entered=NewHeapElement(Shortest, heap, entered, j, inout, newdist);		//put into the Q if not already there
                        }
                        else
                        {
                            UpdateHeap(Shortest, heap, entered, j, newdist, inout);					//if already in the Q, update connectedness
                        }
                    }
                    //-----------------------------------------------------------------------------------

                }
            }
            iter++;
        }
    }



    for (j=0; j<N; j++) Shortest[j] *= -1.0; //revert back to positive distance
    if (inout) free(inout);
    if (heap) free(heap);

    return Count;
}


//======================================================================================================
//Count the number of peaks
//a cluster foci that overlap others within the same cluster
//a foci is part of a cluster if it overlaps another foci within the cluster
//if SigOnly then only those with p<=critical are considered
//the cluster number (>=1) that a significant foci belongs to is recorded in cluster[]
//======================================================================================================
int CountSignificantMApeaks(float x[], float y[], float z[], double p[], float PeakHeight[],
                             short int cluster[], int N, float sigma,
                             double critical, int SigOnly)
{

    int Nsig;
    int foci, BiggestALE, i,j,k;
    int Clusters=0;
    int Count;
    int indexed;
    int *index = NULL;
    float *SigPeakHeight = NULL;
    float *distance = NULL;
    float *shortest = NULL;
    float *length = NULL;
    float x0,y0,z0;
    float a,b,c;
    double dist, mindist2 = pow(NSIGMA95*sigma,2);

    memset(cluster,0,sizeof(short int)*N);


    if (!(index = (int *)malloc(N*sizeof(int)))) goto END;

    //FIND ALL THE SIGNIFICANT COORDINATES
    //COMPUTE A LOOKUP TABLE FOR THEM; index[]
    Nsig=0;
    for (foci=0; foci<N; foci++)
    {
        if ((p[foci]<=critical) && (PeakHeight[foci]>0.0))//added (PeakHeight[index[foci]]>0.0) 9/2/2016 because of CBRES
        {
            index[Nsig] = foci;
            Nsig++;
        }
    }
/*
char txt[256];
if (Nsig<N)
{
sprintf(txt,"%d %d",N,Nsig);
MessageBox(NULL,txt,"",MB_OK);
}
*/
    //IF WE ARE INTERESTED IN COORDINAES THAT ARE NOT SIGNIFICANT, THEN THEY NEED TO BE PUT INTO INDEX TOO
    //THIS IS ONLY FOR NON-SIGNIFICANT COORDINATES THAT OVERLAP WITH A SIGNIFICANT ONE
    if (!SigOnly)
    {
        for (foci=0; foci<N; foci++)
        {
            if ( (p[foci]>critical) )
            {
                indexed=0;
                for (i=0; i<N; i++)
                {
                    if ( (!indexed) && (i!=foci) && (p[i]<=critical) && (PeakHeight[i]>0.0))//added (PeakHeight[index[foci]]>0.0) 9/2/2016 because of CBRES
                    {
                        a=x[i] - x[foci];
                        b=y[i] - y[foci];
                        c=z[i] - z[foci];

                        dist = a*a + b*b + c*c;

                        if (dist<mindist2)
                        {
                            index[Nsig] = foci;
                            Nsig++;
                            indexed=1;
                        }
                    }
                }
            }
        }
    }


    if (!(distance = (float *)malloc(Nsig*Nsig*sizeof(float)))) goto END;
    if (!(shortest = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(SigPeakHeight = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(length = (float *)malloc(Nsig*sizeof(float)))) goto END;


    //COMPUTE THE DISTANCE MATRIX distance[Nsig*Nsig]
    //THIS RECORDS THE DISTANCE SQUARED BETWEEN EAC OF THE INDEXED COORDINATES
    k=0;
    for (i=0; i<Nsig; i++)
    {
        shortest[i] = 100000.0;
        SigPeakHeight[i] = PeakHeight[index[i]];
        //offset = i*Nsig;
        x0=x[index[i]];
        y0=y[index[i]];
        z0=z[index[i]];
        for (j=0; j<Nsig; j++)
        {
            a = x0 - x[index[j]];
            b = y0 - y[index[j]];
            c = z0 - z[index[j]];
            //distance[offset + j] = a*a + b*b + c*c;
            distance[k] = a*a + b*b + c*c;
            k++;
        }
    }




    do
    {
        //choose a foci that is not already part of a cluster, and which is significant
        //choose the most significant
        BiggestALE=Nsig;
        for (foci=0; foci<Nsig; foci++)
        {
            if ((!cluster[index[foci]]) && (p[index[foci]] <= critical))//must be significant to form a cluster
            {
                if (BiggestALE == Nsig) BiggestALE = foci;
                else if ((SigPeakHeight[foci] > SigPeakHeight[BiggestALE])) BiggestALE = foci;
            }
        }


        if ((BiggestALE<Nsig))
        {
            //we have a starting foci from which we will grow a cluster
            //Include foci that are SIGNIFICANT, or that overlap with SIGNIFICANT foci in the cluster
            Clusters++;
            cluster[index[BiggestALE]] = Clusters;
            shortest[BiggestALE] = 0.0;

            Count = ClusterMA(distance, SigPeakHeight, Nsig, BiggestALE, length, mindist2);

            if (Count)
            {
                for (foci=0; foci<Nsig; foci++)
                {
                    if ((length[foci]>=0.0) && (length[foci]<shortest[foci]))
                    {
                        cluster[index[foci]] = Clusters;
                        shortest[foci] = length[foci];
                    }
                }
            }

        }
    }
    while ((BiggestALE<Nsig));

END:
    if (distance) free(distance);
    if (shortest) free(shortest);
    if (length) free(length);
    if (index) free(index);
    if (SigPeakHeight) free(SigPeakHeight);


    return Clusters;
}

//======================================================================================================
//Count the number of clusters; significant foci overlapping
//a cluster foci that overlap others within the same cluster
//a foci is part of a cluster if it overlaps another foci within the cluster
//if SigOnly then only those with p<=critical are considered
//the cluster number (>=1) that a significant foci belongs to is recorded in cluster[]
//======================================================================================================
int CountSignificantClustersFast(float x[], float y[], float z[], double p[], short int cluster[], int N, float sigma,
                                 double critical, int SigOnly)
{

    int Nsig;
    int foci, MostSig, i,j;
    int Clusters=0;
    int Count;
    int indexed;
    int offset;
    int *index = NULL;
    float *SigALEs = NULL;
    float *distance = NULL;
    float *shortest = NULL;
    float *length = NULL;
    float a,b,c;
    double dist, mindist2 = NSIGMA95*sigma*NSIGMA95*sigma;
    //FILE *fp;

    memset(cluster,0,sizeof(short int)*N);

    //index tells us which foci are included in the clustering
    if (!(index = (int *)malloc(N*sizeof(int)))) goto END;
    Nsig=0;
    for (foci=0; foci<N; foci++)
    {
        if (p[foci]<=critical)
        {
            index[Nsig] = foci;
            Nsig++;
        }
    }



    if (!SigOnly)
    {
        for (foci=0; foci<N; foci++)
        {
            if ( (p[foci]>critical) )
            {
                indexed=0;
                for (i=0; i<N; i++)
                {
                    if ( (!indexed) && (i!=foci) && p[i]<=critical)
                    {
                        a=x[i] - x[foci];
                        dist = a*a;
                        if (dist<mindist2)
                        {
                            b=y[i] - y[foci];
                            dist += b*b;
                            if (dist<mindist2)
                            {
                                c=z[i] - z[foci];
                                dist += c*c;

                                if (dist<mindist2)
                                {
                                    index[Nsig] = foci;
                                    Nsig++;
                                    indexed=1;
                                }
                            }

                        }

                    }
                }
            }
        }
    }


    if (!(distance = (float *)malloc(Nsig*Nsig*sizeof(float)))) goto END;
    if (!(shortest = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(SigALEs = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(length = (float *)malloc(Nsig*sizeof(float)))) goto END;

    offset=0;
    for (i=0; i<Nsig; i++)
    {
        shortest[i] = 100000.0;
        SigALEs[i] = 1.0;
        for (j=0; j<Nsig; j++)
        {
            a=x[index[i]] - x[index[j]];
            b=y[index[i]] - y[index[j]];
            c=z[index[i]] - z[index[j]];
            distance[offset + j] = a*a + b*b + c*c;
        }
        offset += Nsig;
    }

    do
    {
        //choose a foci that is not already part of a cluster, and which is significant
        //choose the most significant
        MostSig=Nsig;
        for (foci=0; foci<Nsig; foci++)
        {
            if ((cluster[index[foci]] == 0) && (p[index[foci]] <= critical))//must be significant to form a cluster
            {
                if (MostSig == Nsig) MostSig = foci;
                else if (p[index[foci]] < p[index[MostSig]]) MostSig = foci;
            }
        }


        if ((MostSig<Nsig))
        {
            //we have a starting foci from which we will grow a cluster
            //Include foci that are SIGNIFICANT, or that overlap with SIGNIFICANT foci in the cluster
            Clusters++;
            cluster[index[MostSig]] = Clusters;
            shortest[MostSig] = 0.0;

            Count = ClusterMA(distance, SigALEs, Nsig, MostSig, length, mindist2);

            if (Count)
            {
                for (foci=0; foci<Nsig; foci++)
                {
                    if ((length[foci]>=0.0) && (length[foci]<shortest[foci]))
                    {
                        cluster[index[foci]] = Clusters;
                        shortest[foci] = length[foci];
                    }
                }
            }

        }
    }
    while ((MostSig<Nsig));

END:
    if (distance) free(distance);
    if (shortest) free(shortest);
    if (length) free(length);
    if (index) free(index);
    if (SigALEs) free(SigALEs);

    return Clusters;
}

//======================================================================================================
//ALL FOCI MUST BE SIGNIFICANT
//Count the number of clusters; significant foci overlapping
//a cluster foci that overlap others within the same cluster
//a foci is part of a cluster if it overlaps another foci within the cluster
//if SigOnly then only those with p<=critical are considered
//the cluster number (>=1) that a significant foci belongs to is recorded in cluster[]
//======================================================================================================
int CountSignificantClustersAllSig(float x[], float y[], float z[], double p[], short int cluster[], int Nsig, float sigma,
                                   double critical)
{

    int foci, MostSig, i;
    int Clusters=0;
    int Count;
    int offset;
    float *SigALEs = NULL;
    float *distance = NULL;
    float *shortest = NULL;
    float *length = NULL;
    float d;
    double mindist2 = NSIGMA95*sigma*NSIGMA95*sigma;
    //FILE *fp;

    memset(cluster,0,sizeof(short int)*Nsig);

    if (!(distance = (float *)malloc(Nsig*Nsig*sizeof(float)))) goto END;
    if (!(shortest = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(SigALEs = (float *)malloc(Nsig*sizeof(float)))) goto END;
    if (!(length = (float *)malloc(Nsig*sizeof(float)))) goto END;



    offset=0;
    for (foci=0; foci<Nsig; foci++)
    {
        SigALEs[foci] = 1.0;
        shortest[foci] = 100000.0;
        for (i=0; i<Nsig; i++)
        {
            d=x[i] - x[foci];
            distance[i+offset] = d*d;
            if (distance[i+offset]<mindist2)
            {
                d=y[i] - y[foci];
                distance[i+offset]+=d*d;
                if (distance[i+offset]<mindist2)
                {
                    d=z[i] - z[foci];
                    distance[i+offset] += d*d;
                }
            }
        }
        offset += Nsig;
    }


    do
    {
        //choose a foci that is not already part of a cluster, and which is significant
        //choose the most significant
        MostSig=Nsig;
        for (foci=0; foci<Nsig; foci++)
        {
            if (!cluster[foci])
            {
                if (MostSig == Nsig) MostSig = foci;
                else if (p[foci] < p[MostSig]) MostSig = foci;
            }
        }


        if ((MostSig<Nsig))
        {
            //we have a starting foci from which we will grow a cluster
            Clusters++;
            cluster[MostSig] = Clusters;
            shortest[MostSig] = 0.0;

            Count = ClusterMA(distance, SigALEs, Nsig, MostSig, length, mindist2);

            if (Count)
            {
                for (foci=0; foci<Nsig; foci++)
                {
                    if ((length[foci]>=0.0) && (length[foci]<shortest[foci]))
                    {
                        cluster[foci] = Clusters;
                        shortest[foci] = length[foci];
                    }
                }
            }
        }
    }
    while ((MostSig<Nsig));

END:
    if (distance) free(distance);
    if (shortest) free(shortest);
    if (length) free(length);
    if (SigALEs) free(SigALEs);

    return Clusters;
}

//======================================================================================================
//COMPUTE THE ALE ONLY AT THE FOCI FAST
//RETURN IT IN ALEvalues[]
//======================================================================================================
int ComputeALEatFociFast(struct Coordinates *ale, float dx, float dy, float dz, float ALEvalues[], float sigma)
{
    double norm=NormALE(sigma, dx, dy, dz);
    double a=1.0/2.0/sigma/sigma;
    double squaredist, minimum=(sigma*sigma*NSIGMA95*NSIGMA95);
    double *minsquaredist=NULL;
    float y,z;
    float MA;
    int *sort=NULL;//
    double *x=NULL;//for sorting the x dimensions
    double x_SortFoci;
    int foci, TotalFoci=(*ale).TotalFoci;
    int iexp, Experiments=(*ale).Nexperiments;
    int i;
    int iSortFoci;
    int iSorti;
    int Exp_iSorti;
    int *closest=NULL;

    if (!(sort=(int *)malloc(sizeof(int)*TotalFoci))) goto END;
    if (!(x=(double *)malloc(sizeof(double)*TotalFoci))) goto END;
    if (!(closest=(int *)malloc(Experiments*sizeof(int)))) goto END;
    if (!(minsquaredist=(double *)malloc(Experiments*sizeof(double)))) goto END;


    //the x coordinate is sorted so that we only end up comparing with those nearby
    for (foci=0; foci<TotalFoci; foci++) x[foci] = (*ale).x[foci];
    QuickSort(x, sort, TotalFoci);


    for (foci=0; foci<TotalFoci; foci++)
    {
        ALEvalues[sort[foci]] = 1.0;//dont need to weight the first foci
        iSortFoci=sort[foci];
        x_SortFoci=x[iSortFoci];

        for (iexp=0; iexp<Experiments; iexp++)
        {
            closest[iexp] = -1;//initial value meaning no closest for this experiment
            minsquaredist[iexp] = minimum;
        }


        i=foci+1;//forwards
        iSorti = sort[i];
        while ( (i<TotalFoci) && ((squaredist=(x_SortFoci - x[iSorti])*(x_SortFoci - x[iSorti]))<minimum) )
        {

            Exp_iSorti = (*ale).experiment[iSorti];
            if ((*ale).experiment[iSortFoci] != Exp_iSorti)
            {

                y = ((*ale).y[iSortFoci] - (*ale).y[iSorti]);
                squaredist += y*y;
                if (squaredist <= minsquaredist[Exp_iSorti])
                {
                    z = ((*ale).z[iSortFoci] - (*ale).z[iSorti]);
                    squaredist += z*z;
                    if (squaredist <= minsquaredist[Exp_iSorti])
                    {
                        closest[Exp_iSorti] = iSorti;
                        minsquaredist[Exp_iSorti] = squaredist;
                    }
                }
            }
            i++;
            iSorti = sort[i];
        }

        i=foci-1;//backwards
        iSorti = sort[i];
        while ( (i>=0) && ((squaredist=(x_SortFoci - x[iSorti])*(x_SortFoci - x[iSorti]))<minimum) )
        {

            Exp_iSorti = (*ale).experiment[iSorti];
            if  ((*ale).experiment[iSortFoci] != Exp_iSorti)
            {
                y = ((*ale).y[iSortFoci] - (*ale).y[iSorti]);
                squaredist += y*y;
                if (squaredist <= minsquaredist[Exp_iSorti])
                {
                    z = ((*ale).z[iSortFoci] - (*ale).z[iSorti]);
                    squaredist += z*z;
                    if (squaredist <= minsquaredist[Exp_iSorti])
                    {
                        closest[Exp_iSorti] = iSorti;
                        minsquaredist[Exp_iSorti] = squaredist;
                    }
                }
            }
            i--;
            iSorti = sort[i];
        }

        for (iexp=0; iexp<Experiments; iexp++)
        {
            if (closest[iexp]>=0)
            {
                MA = norm*exp(-minsquaredist[iexp]*a);
                ALEvalues[iSortFoci] *= (1.0-MA);
            }
        }
    }


    //convert to ALE
    for (foci=0; foci<TotalFoci; foci++) ALEvalues[foci] = (1.0 - ALEvalues[foci]);

END:
    if (sort) free(sort);
    if (x) free(x);
    if (closest) free(closest);
    if (minsquaredist) free(minsquaredist);

    return 1;
}
//======================================================================================================
//COMPUTE THE ALE ONLY AT THE FOCI
//RETURN IT IN ALEvalues[]
//======================================================================================================
int ComputeALEatFoci(struct Coordinates *ale, float dx, float dy, float dz, float ALEvalues[], float sigma, int StartFoci, int StopFoci)
{
    double norm=NormALE(sigma, dx, dy, dz);
    double a=1.0/2.0/sigma/sigma;
    float x,y,z;
    double squaredist, minsquaredist, minimum=pow(sigma*NSIGMA95,2);
    float MA;
    int closest;
    int foci, foci2;
    int iexp;
    short int *start=NULL;
    short int *stop=NULL;
    //FILE *fp;

//fp=fopen("c:\\temp\\startstop.txt","w");
    //get the start and stop points for the experiments
    if (!(start = (short int *)malloc((*ale).Nexperiments*sizeof(short int)))) goto END;
    if (!(stop = (short int *)malloc((*ale).Nexperiments*sizeof(short int)))) goto END;

    for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
    {
        start[iexp] = -1;//default value

        for (foci=(*ale).TotalFoci-1; foci>=0; foci--)
        {
            if (iexp == (*ale).experiment[foci]) start[iexp] = foci;
        }

        for (foci=start[iexp]; foci<(*ale).TotalFoci; foci++)
        {
            if (iexp == (*ale).experiment[foci]) stop[iexp] = foci;
        }

        // if (fp) fprintf(fp,"%d %d %d\n",iexp, start[iexp],stop[iexp]);
    }
//if (fp) fclose(fp);


    for (foci=StartFoci; foci<=StopFoci; foci++)
    {
        //ALEvalues[foci] = (1.0 - weights[(*ale).experiment[foci]]);
        ALEvalues[foci] = 1.0;//dont need to weight the first foci

        for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
        {
            if ((iexp != (*ale).experiment[foci]) && (start[iexp]>=0))
            {
                minsquaredist = minimum;
                closest = -1;
                for (foci2=start[iexp]; foci2<=stop[iexp]; foci2++)
                {
                    x = (double)((*ale).x[foci] - (*ale).x[foci2]);
                    squaredist = x*x;
                    //squaredist = pow((double)(x - (*ale).x[foci2]),2.0);
                    if (squaredist <= minsquaredist)
                    {
                        y = (double)((*ale).y[foci] - (*ale).y[foci2]);
                        squaredist += y*y;
                        //squaredist += pow((double)(y - (*ale).y[foci2]),2.0);
                        if (squaredist <= minsquaredist)
                        {
                            z = (double)((*ale).z[foci] - (*ale).z[foci2]);
                            squaredist += z*z;
                            //squaredist += pow((double)(z - (*ale).z[foci2]),2.0);
                            if (squaredist <= minsquaredist)
                            {
                                closest = foci2;
                                minsquaredist = squaredist;
                            }
                        }
                    }
                }
                if ((closest >= 0))
                {
                    MA = norm*exp(-minsquaredist*a);
                    //MA = norm*Padexp4(-minsquaredist*a);
                    ALEvalues[foci] *= (1.0-MA);
                }
            }
        }//iexp
    }//foci

    //convert to ALE
    for (foci=StartFoci; foci<=StopFoci; foci++) ALEvalues[foci] = (1.0 - ALEvalues[foci]);


END:
    if (start) free(start);
    if (stop) free(stop);

    return 1;
}

//======================================================================================================
//this is the maximum possible ALE if all experiments alligned perfectly
//======================================================================================================
double MaxPossibleALE(struct Coordinates *ale, float dx, float dy, float dz, float sigma)
{
    double norm=NormALE(sigma, dx, dy, dz);
    double MaxALE;
    int iexp;

    MaxALE = 1.0;
    for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
    {
        MaxALE *= (1.0 - norm);
    }
    MaxALE = (1.0 - MaxALE);

    return MaxALE;
}


//======================================================================================================
//TEST FOR SIGNIFICANT ACTIVATIONS
//NULL HYPOTHESIS: THE REPORTED FOCI ARE RANDOMLY PLACED
//GENERATE THE NULL BY RANDOMISATION THROUGHOUT THE GM
//======================================================================================================
double ComputePvalueBySpatialRandomisation(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
        float dx, float dy, float dz, float x0, float y0, float z0,
        float sigma, double critical, char directory[], int FCDR, double pmethod[], int SaveOutput)
{
    struct Coordinates ALEcopy;
    struct Clusters cl;
    int foci, Count=0;
    int sample;
    int offset;
    int Nsig;
    int voxels = X*Y*Z;
    int clusters;
    int voxel;
    int bin;
    int notsig;
    float *xnull=NULL;
    float *ynull=NULL;
    float *znull=NULL;
    float *ALEvalues=NULL;
    float *SigResults=NULL;
    float MinALE, MaxALE;
    float Hale[ALE_BINS];
    double pfdr=0.0,pfcdr, poldfdr, presult=0.0;
    double *p=NULL;
    HDC hDC=GetDC(hwnd);
    char txt[256];

    memset(&ALEcopy,0,sizeof(struct Coordinates));
    memset(&cl,0,sizeof(struct Clusters));
    memset(Hale,0,ALE_BINS*sizeof(float));

    if (!(xnull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(ynull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(znull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(SigResults = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(ALEvalues = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(p = (double *)malloc(sizeof(double)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    memset(p,0,sizeof(double)*(*ale).TotalFoci*(P_SAMPLES+1));



    CopyCoordinates(ale, &ALEcopy);
    memcpy(xnull, (*ale).x, sizeof(float)*(*ale).TotalFoci);
    memcpy(ynull, (*ale).y, sizeof(float)*(*ale).TotalFoci);
    memcpy(znull, (*ale).z, sizeof(float)*(*ale).TotalFoci);


//MaxALE for normalising the ALE histogram
    MaxALE = MaxPossibleALE(ale, dx, dy, dz, sigma);


    FillClusterStructure(ale, &cl, sigma);


//the ALE values for the observed foci
    ComputeALEatFociFast(ale, dx, dy, dz, ALEvalues, sigma);




//ALE values for randomised experiments
    Count=0;
    for (sample=1; sample<=P_SAMPLES; sample++)
    {
        Count++;
        if (Count>=100)
        {
            RemoveInput(hwnd);
            sprintf(txt,"%d of %d samples     ",sample, P_SAMPLES);
            TextOut(hDC,100,100,txt,strlen(txt));
            UpdateWindow(hwnd);
            Count=0;
        }

        RandomiseFociRandomEffects(mask, X, Y, Z, dx, dy, dz, x0, y0, z0, &ALEcopy, &cl, sigma);
        //ComputeALEatFoci(&ALEcopy, dx, dy, dz, &ALEvalues[(*ale).TotalFoci*sample], sigma, 0, (*ale).TotalFoci-1);
        ComputeALEatFociFast(&ALEcopy, dx, dy, dz, &ALEvalues[(*ale).TotalFoci*sample], sigma);

        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            bin = ALE_BINS * sqrt(ALEvalues[(*ale).TotalFoci*sample + foci]/MaxALE);
            if (bin<ALE_BINS) Hale[bin] += 1.0;
        }

        memcpy(&xnull[sample*(*ale).TotalFoci], ALEcopy.x, sizeof(float)*(*ale).TotalFoci);
        memcpy(&ynull[sample*(*ale).TotalFoci], ALEcopy.y, sizeof(float)*(*ale).TotalFoci);
        memcpy(&znull[sample*(*ale).TotalFoci], ALEcopy.z, sizeof(float)*(*ale).TotalFoci);
    }



//convert ALE histogram into CDF
    for (bin=ALE_BINS-2; bin>=0; bin--) Hale[bin] += Hale[bin+1];
    for (bin=ALE_BINS-1; bin>=0; bin--) Hale[bin] /= Hale[0];


    /*
        FILE *fp=NULL;
         if (fp=fopen("c:\\temp\\CDF.csv","w"))
         {
             for (bin=0; bin<ALE_BINS; bin++)
             {
                 fprintf(fp,"%d,%f\n",bin,Hale[bin]);
             }
             fclose(fp);
         }
    */

//convert to fraction of iterations; p-value
    for (sample=0; sample<(P_SAMPLES+1)*(*ale).TotalFoci; sample++)
    {
        bin = ALE_BINS * sqrt(ALEvalues[sample]/MaxALE);
        p[sample] = Hale[bin];
    }




//collect the NULL significant results for FDR
    Nsig=0;
    for (sample=1; sample<=P_SAMPLES; sample++)
    {
        offset = (*ale).TotalFoci*sample;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if (p[offset + foci] <= critical)
            {
                SigResults[Nsig]=p[offset+foci];
                Nsig++;
            }
        }
    }


    for (foci=0; foci<(*ale).TotalFoci; foci++) (*ale).p[foci] = p[foci];



//CONTROL THE FALSE DISCOVERY RATE
    poldfdr = FDR((*ale).p, (*ale).TotalFoci, critical);//STANDARD METHOD
    pmethod[BHFDR_METHOD] = poldfdr;

    pfdr = ControlFDR((*ale).p, (*ale).TotalFoci, SigResults, Nsig, P_SAMPLES, critical, directory);//NEW METHOD FOR FDR CONTROL
    pmethod[FDR_METHOD] = pfdr;



    //do fast FCDR
    clusters=0;
    pfcdr = ControlFCDR(hwnd, (*ale).p, (*ale).TotalFoci, p, ALEvalues, xnull, ynull, znull, P_SAMPLES, sigma, critical, directory, &clusters); //NEW METHOD FOR CONTROLING
    //now do slow FCDR, but only for the number of clusters = clusters
    if (clusters) pfcdr = ControlFCDR(hwnd, (*ale).p, (*ale).TotalFoci, p, ALEvalues, xnull, ynull, znull, P_SAMPLES, sigma, critical, directory, &clusters); //NEW METHOD FOR CONTROLING

    pmethod[FCDR_METHOD] = pfcdr;                                                                                   //FALSE CLUSTER RATE
    sprintf(txt,"                                                      ");
    TextOut(hDC,100,150,txt,strlen(txt));

//sprintf(txt,"pfdr=%f pStandardFDR=%f pfcdr=%f",pfdr,poldfdr,pfcdr);
//MessageBox(NULL,txt,"",MB_OK);


    if (FCDR) presult=pfcdr;
    else presult=pfdr;

    if (SaveOutput)
    {

        sprintf(txt,"Computing Output images            ");
        TextOut(hDC,100,150,txt,strlen(txt));


        CombineExperimentsIntoALEimage(ale, out, X, Y, Z,dx, dy, dz, x0, y0, z0, sigma, 0, 1.0, 0.0);
        //&out[0] now contains the ALE

        //find the minimum ALE; the ALE corresponding to pnotsig (the most significant of the not significant foci)
        notsig=0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if (p[foci]>p[notsig]) notsig=foci;
        }
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ( (p[foci]>presult) && (p[foci]<p[notsig]) ) notsig = foci;
        }
        MinALE = 1.0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ( (p[foci]<=p[notsig]) && (out[(*ale).voxel[foci]]<MinALE) ) MinALE = out[(*ale).voxel[foci]];
        }



        if ( (clusters = CountSignificantMApeaks((*ale).x, (*ale).y, (*ale).z, (*ale).p, ALEvalues, (*ale).cluster, (*ale).TotalFoci, sigma, presult, 0)) )
        {
            CombineExperimentsIntoALEimage(ale, &out[CLUSTALE*voxels], X, Y, Z,dx, dy, dz, x0, y0, z0, sigma, 1, presult, 0.0);
            for (voxel=0; voxel<voxels; voxel++)
            {
                if (out[voxel]<MinALE) out[CLUSTALE*voxels+voxel]=0.0;
            }

            clusters=GetClusterNumberImage(ale, clusters, &out[CLUSTALE*voxels], &out[CLUSTNUM*voxels],
                                           dx, dy, dz, x0, y0, z0, X, Y, Z, sigma, presult);
        }



        //save ALL the foci in an image
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            voxel=(*ale).voxel[foci];
            out[FOCIIMG*voxels+voxel]=((float)((*ale).experiment[foci]+1))/(*ale).Nexperiments;
        }


        sprintf(txt,"Computing Output images DONE        ");
        TextOut(hDC,100,150,txt,strlen(txt));
    }

END:
    if (ALEvalues) free(ALEvalues);
    if (p) free(p);
    if (SigResults) free(SigResults);
    if (xnull) free(xnull);
    if (ynull) free(ynull);
    if (znull) free(znull);
    FreeCoordinates(&ALEcopy);
    FreeCluster(&cl);
    ReleaseDC(hwnd,hDC);

    return presult;
}


//======================================================================================================
//TEST TO SEE IF THERE IS A DIFFERENCE BETWEEN TWO ALEs
//THIS IS A SINGLE TEST FOR A DIFFERENCE, UNLIKE THE COMPARE ALE FUNCTION, WHICH TESTS FOR DIFFERENCES BY LOCATION
//THE NULL HYPOTHESIS IS THAT THERE IS NO DIFFERENCE BETWEEN THE GROUPS
//SO SHOULD NOT BE CRITICAL OF THE DISTRIBUTION OF PERMUTED STUDIES
//======================================================================================================
double MAvalue(float x, float y, float z, struct Coordinates *ale, int study, double sigma, double norm);
double DifferenceBetweenALEs(HWND hwnd, struct Coordinates *A, struct Coordinates *B, double sigma, float dx, float dy, float dz,
                             char directory[], int MergeGroups, double critical1, double critical2, int SaveResults)
{

    char *labels=NULL;
    int Nlabels,Nl;
    struct Image Tal;
    int NullPerm=1000;
    int iterations=20000;
    int Nfoci=(*A).TotalFoci + (*B).TotalFoci;
    int Nstudies=(*A).Nexperiments + (*B).Nexperiments;
    int *studies=NULL;//a lookup to the study number for each foci
    unsigned short int *p_foci_perm=NULL;//the p-values for each foci and each permutation
    int *sort=NULL;
    int foci,perm,study,iter;
    int FociStudies,PermStudies,FociPermutations;
    int offset,index,i;
    char *G_study_perm=NULL;//the grouping variable
    char *G=NULL;
    double norm=NormALE(sigma, dx, dy, dz);
    double ma;
    double *MA_foci_study=NULL;//lookup table of MS values to compute ALE
    double pvalue=1.0;//the overall pvalue
    double pvalueSig=1.0;//overall pvalue for the significant foci
    double p,d;
    double *DIFF_foci_perm=NULL;//the ALE values for each null (and original) permutation
    double *diff=NULL;
    double *r=NULL;
    double Llike, Llike0;
    double LlikeSig, LlikeSig0;
    double tmpA,tmpB;
    char txt[256];
    char fname[MAX_PATH];
    HDC hDC=GetDC(hwnd);
    char *b=NULL;
    FILE *fp;
    //int Hist[10],counter;
    //memset(Hist,0,sizeof(int)*10);

    i=(Nstudies>Nfoci) ? Nstudies:Nfoci;
    if (!(r=(double *)malloc(sizeof(double)*i))) goto END;
    if (!(sort=(int *)malloc(sizeof(int)*i))) goto END;
    if (!(MA_foci_study=(double *)malloc(Nstudies*Nfoci*sizeof(double)))) goto END;
    if (!(G=(char *)malloc(Nstudies))) goto END;
    if (!(G_study_perm=(char *)calloc(Nstudies*(NullPerm+1),1))) goto END;
    if (!(DIFF_foci_perm=(double *)malloc((NullPerm+1)*Nfoci*sizeof(double)))) goto END;
    if (!(p_foci_perm=(unsigned short int *)malloc((NullPerm+1)*Nfoci*sizeof(unsigned short int)))) goto END;
    if (!(studies=(int *)malloc(Nfoci*sizeof(int)))) goto END;
    if (!(diff=(double *)malloc(Nfoci*sizeof(double)))) goto END;


    //LOAD THE TALAIRACH DATA
    memset(&Tal,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    LoadFromFileName(hwnd, fname, &Tal, 0);
    labels=LoadTalairachLabels(&Nl);
    Nlabels=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,Nlabels);

    GetTalairachLabelsEx(A, &Tal);
    GetTalairachLabelsEx(B, &Tal);


    //the list of studies is required for the FCDR routine and arranging groups
    for (foci=0; foci<(*A).TotalFoci; foci++) studies[foci] = (*A).experiment[foci];
    for (foci=0; foci<(*B).TotalFoci; foci++) studies[foci + (*A).TotalFoci] = (*B).experiment[foci] + (*A).Nexperiments;


    //create the lookup table of MA values
    for (foci=0; foci<(*A).TotalFoci; foci++)
    {
        //counter=0;
        FociStudies=foci*Nstudies;
        for (study=0; study<(*A).Nexperiments; study++)
        {
            MA_foci_study[FociStudies + study] =MAvalue((*A).x[foci], (*A).y[foci], (*A).z[foci], A, study, sigma, norm);
            //if (MA_foci_study[FociStudies + study]>0.0) counter++;
        }
        for (study=0; study<(*B).Nexperiments; study++)
        {
            MA_foci_study[FociStudies + study + (*A).Nexperiments] =MAvalue((*A).x[foci], (*A).y[foci], (*A).z[foci], B, study, sigma, norm);
            //if (MA_foci_study[FociStudies + study + (*A).Nexperiments]>0.0) counter++;
        }
        //if (counter<10) Hist[counter]++;
    }
    for (foci=0; foci<(*B).TotalFoci; foci++)
    {
        //counter=0;
        FociStudies=(foci+(*A).TotalFoci)*Nstudies;
        for (study=0; study<(*A).Nexperiments; study++)
        {
            MA_foci_study[FociStudies + study] =MAvalue((*B).x[foci], (*B).y[foci], (*B).z[foci], A, study, sigma, norm);
            //if (MA_foci_study[FociStudies + study]>0.0) counter++;
        }
        for (study=0; study<(*B).Nexperiments; study++)
        {
            MA_foci_study[FociStudies + study + (*A).Nexperiments] =MAvalue((*B).x[foci], (*B).y[foci], (*B).z[foci], B, study, sigma, norm);
            // if (MA_foci_study[FociStudies + study + (*A).Nexperiments]>0.0) counter++;
        }
        //if (counter<10) Hist[counter]++;
    }
    /*if ((fp=fopen("c:\\temp\\counts.csv","w")))
    {
        for (i=0;i<10;i++) fprintf(fp,"%d,%f\n",i,(double)Hist[i]/Nfoci);
        fclose(fp);
    }*/


    //compute ALE difference values per foci for the original groups and for NullPerm random permutations
    PermStudies=0;
    memset(G_study_perm,0,Nstudies*(NullPerm+1));
    for (perm=0; perm<=NullPerm; perm++)
    {

        if (!perm)
        {
            for (study=0; study<(*A).Nexperiments; study++) G_study_perm[study*(NullPerm+1)]=1;
        }
        else
        {
            RandomiseExperimentsIntoGroups(G, Nstudies, (*A).Nexperiments);
            for (study=0; study<Nstudies; study++) G_study_perm[study*(NullPerm+1) + perm]=G[study];
        }

        FociStudies=0;
        FociPermutations=0;
        for (foci=0; foci<Nfoci; foci++)
        {
            tmpA=tmpB=1.0;
            for (study=0; study<Nstudies; study++)
            {
                if (G_study_perm[study*(NullPerm+1) + perm]) tmpA *= (1.0-MA_foci_study[FociStudies+study]);
                else tmpB *= (1.0-MA_foci_study[FociStudies+study]);
            }
            DIFF_foci_perm[FociPermutations + perm] = (1.0-tmpA) - (1.0-tmpB);//difference in ALE at this foci and this permutation
            FociStudies += Nstudies;
            FociPermutations +=  NullPerm+1;
        }
        PermStudies += Nstudies;
    }



    //compute p-values
    memset(p_foci_perm,0,(NullPerm+1)*Nfoci*sizeof(unsigned short int));
    for (iter=0; iter<iterations; iter++)
    {
        if (!(iter%1000))
        {
            RemoveInput(hwnd);
            sprintf(txt,"Omnibus difference test: %d of %d permutations                ",iter+1, iterations);
            TextOut(hDC,100,100,txt,strlen(txt));
            UpdateWindow(hwnd);
        }

        RandomiseExperimentsIntoGroups(G,Nstudies,(*A).Nexperiments);
        FociStudies=0;
        for (foci=0; foci<Nfoci; foci++)
        {
            tmpA=tmpB=1.0;
            for (study=0; study<Nstudies; study++)
            {
                ma=MA_foci_study[FociStudies+study];
                if (ma>0.0)
                {
                    if (G[study]) tmpA *= (1.0-ma);
                    else tmpB *= (1.0-ma);
                }

            }
            diff[foci] = (1.0-tmpA) - (1.0-tmpB);
            FociStudies += Nstudies;
        }



        FociPermutations=0;
        for (foci=0; foci<Nfoci; foci++)
        {
            study=studies[foci];
            offset=study*(NullPerm+1) ;
            d=diff[foci];
            for (perm=0; perm<=NullPerm; perm++)
            {
                index = FociPermutations + perm;
                if (G_study_perm[offset + perm])//is it a group A foci in this permutation?
                {
                    if (d>=DIFF_foci_perm[index]) p_foci_perm[index]++;
                }
                else//no its a group B
                {
                    if (d<=DIFF_foci_perm[index]) p_foci_perm[index]++;
                }
            }
            FociPermutations += (NullPerm+1);
        }
    }



    //compute the overall pvalue
    Llike0=LlikeSig0=0.0;
    pvalue=pvalueSig=0.0;
    for (perm=0; perm<=NullPerm; perm++)
    {
        Llike=LlikeSig=0.0;
        FociPermutations=0;
        for (foci=0; foci<Nfoci; foci++)
        {
            p = ((double)p_foci_perm[FociPermutations+perm]+1.0)/(iterations+1);
            if (!perm) r[foci]=p;//record the p-values for saving the differences, most significant first
            Llike += log(p);
            if ((foci<(*A).TotalFoci) && ((*A).p[foci]<=critical1)) LlikeSig +=  log(p);
            else if ((foci>=(*A).TotalFoci) && ((*B).p[foci-(*A).TotalFoci]<=critical2)) LlikeSig +=  log(p);
            FociPermutations += (NullPerm+1);
        }
        if (!perm)
        {
            Llike0=Llike;
            LlikeSig0=LlikeSig;
        }
        else
        {
            if (Llike0>=Llike) pvalue+=1.0;
            if (LlikeSig0>=LlikeSig) pvalueSig+=1.0;
        }
    }
    pvalue /= NullPerm;
    pvalueSig /= NullPerm;



    sprintf(fname,"%s//difference between groups.txt",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        if (MergeGroups) fprintf(fp,"Groups Merged\n");
        fprintf(fp,"Group A:\n");
        fprintf(fp,"%s\n",(*A).coordinate_file_name);
        fprintf(fp,"Number of studies=%d\n",(*A).Nexperiments);
        fprintf(fp,"Number of foci=%d\n",(*A).TotalFoci);
        fprintf(fp,"Group B:\n");
        fprintf(fp,"%s\n",(*B).coordinate_file_name);
        fprintf(fp,"Number of studies=%d\n",(*B).Nexperiments);
        fprintf(fp,"Number of foci=%d\n",(*B).TotalFoci);
        fprintf(fp,"Significance of difference between two groups by permutation test\n All foci %f\n",pvalue);
        fclose(fp);
    }

    //save the differences, with the most significant first
    sprintf(fname,"%s//difference between groups by focus.csv",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        QuickSort(r,sort,Nfoci);
        fprintf(fp,"Study,group,x,y,z,pvalue\n");
        for (foci=0; foci<Nfoci; foci++)
        {

            if (sort[foci]<(*A).TotalFoci)
            {
                study=(*A).experiment[sort[foci]];
                fprintf(fp,"%s,A,%f,%f,%f,%f,",(*A).ID[study].txt, (*A).x[sort[foci]], (*A).y[sort[foci]], (*A).z[sort[foci]], r[sort[foci]]);
                b=FindEntryInTalairachLabels(labels, Nl, (*A).TalLabel[sort[foci]]);
                fprintf(fp,"%s\n",&b[1]);
            }
            else
            {
                study=(*B).experiment[sort[foci] - (*A).TotalFoci];
                fprintf(fp,"%s,B,%f,%f,%f,%f,",(*B).ID[study].txt, (*B).
                        x[sort[foci] - (*A).TotalFoci], (*B).y[sort[foci] - (*A).TotalFoci], (*B).z[sort[foci] - (*A).TotalFoci], r[sort[foci]]);
                b=FindEntryInTalairachLabels(labels, Nl, (*B).TalLabel[sort[foci] - (*A).TotalFoci]);
                fprintf(fp,"%s\n",&b[1]);
            }
        }

        fclose(fp);
    }

END:
    if (labels) free(labels);
    ReleaseImage(&Tal);
    if (sort) free(sort);
    if (r) free(r);
    if (MA_foci_study) free(MA_foci_study);
    if (G) free(G);
    if (G_study_perm) free(G_study_perm);
    if (DIFF_foci_perm) free(DIFF_foci_perm);
    if (p_foci_perm) free(p_foci_perm);
    if (studies) free(studies);
    if (diff) free(diff);
    ReleaseDC(hwnd,hDC);

    return pvalue;
}

//======================================================================================================
double MAvalue(float x, float y, float z, struct Coordinates *ale, int study, double sigma, double norm)
{
    double sqrdist,minsqrdst;
    double sigma2=sigma*sigma;
    double MinSquareDist=NSIGMA95*NSIGMA95*sigma2;
    int foci;


    minsqrdst=2.0*MinSquareDist;
    for (foci=0; foci<(*ale).TotalFoci; foci++)
    {
        if ((*ale).experiment[foci]==study)
        {
            sqrdist = (x-(*ale).x[foci])*(x-(*ale).x[foci]);
            if (sqrdist<MinSquareDist) sqrdist += (y-(*ale).y[foci])*(y-(*ale).y[foci]);
            if (sqrdist<MinSquareDist) sqrdist += (z-(*ale).z[foci])*(z-(*ale).z[foci]);
            if (sqrdist<minsqrdst) minsqrdst=sqrdist;
        }
    }

    if (minsqrdst>=MinSquareDist) return 0.0;
    return exp(-minsqrdst/2.0/sigma2)*norm;
}



/*

//======================================================================================================
//save a bitmap of MIPs of ALE for each study
//======================================================================================================
int SaveALE_MIP(HWND hwnd, struct Coordinates *ale, struct Image *image, char directory[], float sigma, int WEIGHT)
{
    int pX,pY;
    int CX,CY;
    int TX,TY;
    int X, Y, Z;
    int x,y,voxels;
    int iexp;
    int wide=sqrt((*ale).Nexperiments), height;
    float *MA=NULL;
    float dx,dy,dz,x0,y0,z0;
    struct ImagePlanes planes, planes2;
    struct Image im;
    HDC hDC=GetDC(hwnd);
    char txt[256];


    sprintf(txt,"   Saving MIPS   ");
    TextOut(hDC,100,100,txt,strlen(txt));
    UpdateWindow(hwnd);


    memset(&planes,0,sizeof(struct ImagePlanes));
    memset(&planes2,0,sizeof(struct ImagePlanes));
    memset(&im,0,sizeof(struct Image));


    height=1;
    while(height*wide<(*ale).Nexperiments)
    {
        height++;
    }
    if (!wide) goto END;
    if (!height) goto END;



    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    x0=(*image).x0;
    y0=(*image).y0;
    z0=(*image).z0;
    voxels=X*Y*Z;


    if (!(MA = (float *)malloc(voxels*sizeof(float)))) goto END;
    memcpy(MA,(*image).img, voxels*sizeof(float));
    MaxIntensityProjection(MA, X, Y, Z, &planes2);



    CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, ale, 0, MA, sigma, WEIGHT, 0, 1.0);
    MaxIntensityProjection(MA, X, Y, Z, &planes);

    pX = (X>Y) ? X:Y;
    pY = (Y>Z) ? Y:Z;

    TX=pX*2*wide;
    TY=pY*2*height+100*height;
    if (!MakeImage(&im, TX, TY, 1, 1, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, DT_FLOAT, NIFTI, "bitmap of ALE")) goto END;


    for (x=0; x<pX; x++)
    {
        for (y=0; y<pY; y++)
        {
            if ((x<X) && (y<Y)) im.img[x + (TY-Y + y)*TX] = planes.plane1[x+y*X];
            if ((x<X) && (y<Y) && !planes2.plane1[x+y*X]) im.img[x + (TY-Y + y)*TX] = 0.001;
            if ((x<X) && (y<Z)) im.img[x + pX + (TY-Y + y)*TX] = planes.plane2[x+y*X];
            if ((x<X) && (y<Z) && !planes2.plane2[x+y*X]) im.img[x + pX + (TY-Y + y)*TX] = 0.001;
            if ((x<Y) && (y<Z)) im.img[x + (TY-Y + y - pY)*TX] = planes.plane3[x+y*Y];
            if ((x<Y) && (y<Z) && !planes2.plane3[x+y*Y]) im.img[x + (TY-Y + y - pY)*TX] = 0.001;
        }
    }


    CX=2*pX;
    CY=0;
    if (wide==1) CY += 2*pY + 100;
    for (iexp=1; iexp<(*ale).Nexperiments; iexp++)
    {

        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, ale, iexp, MA, sigma, WEIGHT, 0, 1.0);
        MaxIntensityProjection(MA, X, Y, Z, &planes);


        for (x=0; x<pX; x++)
        {
            for (y=0; y<pY; y++)
            {
                if ((x<X) && (y<Y)) im.img[CX + x + (TY-Y - CY + y)*TX] = planes.plane1[x+y*X];
                if ((x<X) && (y<Y) && !planes2.plane1[x+y*X]) im.img[CX + x + (TY-Y - CY + y)*TX] = 0.001;

                if ((x<X) && (y<Z)) im.img[CX + x + pX + (TY-Y - CY + y)*TX] = planes.plane2[x+y*X];
                if ((x<X) && (y<Z) && !planes2.plane2[x+y*X]) im.img[CX + x + pX + (TY-Y - CY + y)*TX] = 0.001;

                if ((x<Y) && (y<Z)) im.img[CX + x + (TY-Y - CY + y - Y)*TX] = planes.plane3[x+y*Y];
                if ((x<Y) && (y<Z) && !planes2.plane3[x+y*Y]) im.img[CX + x + (TY-Y - CY + y - Y)*TX] = 0.001;
            }
        }

        CX+=2*pX;
        if (CX>=wide*2*pX)
        {
            CX=0;
            CY+=2*pY + 100;
        }
    }


    im.MaxIntensity=1.0;

    sprintf(im.filename,"%s\\maMIPS.nii",directory);
    Save(&im);


    sprintf(txt,"        Finished Saving MIPS        ");
    TextOut(hDC,100,100,txt,strlen(txt));
    UpdateWindow(hwnd);


END:
    if (MA) free(MA);
    if (planes.plane1) free(planes.plane1);
    if (planes.plane2) free(planes.plane2);
    if (planes.plane3) free(planes.plane3);
    if (planes2.plane1) free(planes2.plane1);
    if (planes2.plane2) free(planes2.plane2);
    if (planes2.plane3) free(planes2.plane3);


    ReleaseImage(&im);
    ReleaseDC(hwnd,hDC);

    return 0;
}
*/
//======================================================================================================
//REPORT THE (NEAREST) TALAIRACH GRAY MATTER STRUCTURES
//======================================================================================================
int ReportTalairach(HWND hwnd, struct Coordinates *ale, char directory[], char file[],double critical)
{
    struct Image Tal;
    struct ThreeVector *V=NULL;
    char fname[MAX_PATH];
    char *labels=NULL;
    char *b=NULL;
    double *p=NULL;
    double minp;
    int *Nfoci=NULL;//number of foci contributing to a Talairach region
    int *Nexp=NULL;//number of experiments contributing to a Talairach region
    int *sort=NULL;
    int iexp, ExpContributed;
    int si;
    int Nl, nTalEntries;
    int entry;
    int result=0;
    int foci;
    int reported;
    FILE *fp;


    memset(&Tal,0,sizeof(struct Image));

//LOAD THE TALAIRACH DATA
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    if (!LoadFromFileName(hwnd, fname, &Tal, 0)) goto END;
    labels=LoadTalairachLabels(&Nl);
    if (Nl<=0) goto END;
    nTalEntries=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,nTalEntries);

    if (!(sort=(int *)malloc(sizeof(int)*nTalEntries))) goto END;
    if (!(p=(double *)malloc(sizeof(double)*nTalEntries))) goto END;
    if (!(Nfoci=(int *)malloc(sizeof(int)*nTalEntries))) goto END;
    if (!(Nexp=(int *)malloc(sizeof(int)*nTalEntries))) goto END;
    if (!(V=(struct ThreeVector *)malloc(sizeof(struct ThreeVector)*nTalEntries))) goto END;
    memset(V,0,sizeof(struct ThreeVector)*nTalEntries);

    for (entry=0; entry<nTalEntries; entry++)
    {
        Nfoci[entry]=0;//initialise GM, Exp, and p
        Nexp[entry]=0;
        p[entry]=1.0;
    }



    //get the Talairach labels
    GetTalairachLabelsEx(ale, &Tal);


    //count the number of experiments contributing to a Talairach region
    //record the p-value and coordinate of the most significant foci
    for (entry=1; entry<nTalEntries; entry++)
    {
        for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
        {
            ExpContributed=0;
            for (foci=0; foci<(*ale).TotalFoci; foci++)
            {
                if (((*ale).p[foci]<=critical) &&
                        ((entry==(*ale).TalLabel[foci])) &&
                        (iexp==(*ale).experiment[foci]))
                {
                    Nfoci[entry]++;
                    ExpContributed++;


                    //get the lowest p-value for this Talairach entry
                    //and the associated coordinate
                    if (p[entry]>(*ale).p[foci])
                    {
                        p[entry]=(*ale).p[foci];

                        V[entry].x=(*ale).x[foci];
                        V[entry].y=(*ale).y[foci];
                        V[entry].z=(*ale).z[foci];
                    }
                }
            }
            if (ExpContributed) Nexp[entry]++;
        }
    }




    SortIntegers(Nexp, sort, nTalEntries);
    sprintf(fname,"%s\\%s",directory,file);
    if ((fp=fopen(fname,"w")))
    {
        if (critical>0.0) fprintf(fp,"p-value for significance<=, %f\n", critical);
        else fprintf(fp,"p-value for significance<=, 0.0\n");

        fprintf(fp,"Talairach report,,,,, x y z,p value, studies\n");
        for (entry=0; entry<nTalEntries; entry++)
        {
            si=sort[nTalEntries-entry-1];
            if (Nexp[si])
            {
                if (labels && Tal.img)
                {
                    b=FindEntryInTalairachLabels(labels, Nl, si);
                    if (b) fprintf(fp,"%s, %5.1f %5.1f %5.1f, %f,", &b[1],V[si].x,V[si].y,V[si].z,p[si]);
                }


                for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
                {
                    reported = 0;
                    minp = 1.0;
                    for (foci=0; foci<(*ale).TotalFoci; foci++)
                    {
                        if (((*ale).experiment[foci] == iexp) && ((*ale).TalLabel[foci] == si))
                        {
                            reported = iexp + 1;
                            if ((*ale).p[foci] < minp) minp = (*ale).p[foci];
                        }
                    }
                    if (reported)
                    {
                        if (minp <= critical) fprintf(fp,"*");
                        fprintf(fp,"p=%f, %s\n,,,,,,,",minp, (*ale).ID[reported-1].txt);
                    }
                }
                fprintf(fp,"\n");
            }
        }
        fclose(fp);
    }



    result=1;
END:
    ReleaseImage(&Tal);
    if (labels) free(labels);
    if (p) free(p);
    if (Nfoci) free(Nfoci);
    if (Nexp) free(Nexp);
    if (V) free(V);
    if (sort) free(sort);

    return result;
}

//======================================================================================================
//SAVE THE CLUSTER INFORMATION SO THAT IT CAN BE USED TO DRAW A DENDROGRAM IN R
//======================================================================================================
int SaveClusterDataForDendrogram(HWND hwnd, struct Coordinates *ale, char directory[], char file[])
{
    int result=0;
    char fname[MAX_PATH];
    int LastCluster;
    int cluster;
    int foci;
    int study;
    int *clusters=NULL;
    int *sort=NULL;
    int Nclusters;
    int index;
    int i,j;
    char txt[256];
    char f[MAX_PATH];
    FILE *fp;

    LastCluster=0;
    for (foci=0; foci<(*ale).TotalFoci; foci++)
    {
        if ((*ale).cluster[foci]>LastCluster) LastCluster=(*ale).cluster[foci];
    }


    if ( !(clusters=(int *)malloc(sizeof(int)*(*ale).TotalFoci)) ) goto END;
    if ( !(sort=(int *)malloc(sizeof(int)*(*ale).TotalFoci)) ) goto END;

    sprintf(fname,"%s\\%s",directory,file);
    if ( (fp=fopen(fname,"w")) )
    {

        for (study=0; study<(*ale).Nexperiments; study++)
        {

            memset(clusters,0,sizeof(int)*(*ale).TotalFoci);
            Nclusters=0;
            for (foci=0; foci<(*ale).TotalFoci; foci++)
            {
                if ((*ale).experiment[foci]==study)
                {
                    if ((*ale).cluster[foci])
                    {
                        clusters[Nclusters]=(*ale).cluster[foci];
                        Nclusters++;
                    }
                }
            }//foci

            NoSpaces((*ale).ID[study].txt,txt);
            if (strlen(txt)) fprintf(fp,"%s ",txt);
            else fprintf(fp,"* ");
            NoSpaces((*ale).CTRST[study].txt,txt);
            if (strlen(txt)) fprintf(fp,"%s ",txt);
            else fprintf(fp,"* ");
            NoSpaces((*ale).CND[study].txt,txt);
            if (strlen(txt)) fprintf(fp,"%s ",txt);
            else fprintf(fp,"* ");

            SortIntegers(clusters, sort, Nclusters);
            index=0;
            for (cluster=1; cluster<=LastCluster; cluster++)
            {
                if ((index<Nclusters))
                {
                    if (clusters[sort[index]]!=cluster) fprintf(fp,"0 ");
                    else
                    {
                        fprintf(fp,"1 ");
                        do
                        {
                            index++;
                        }
                        while ((index<Nclusters) && (clusters[sort[index]]==clusters[sort[index-1]]));
                    }
                }
                else fprintf(fp,"0 ");
            }
            fprintf(fp,"\n");
        }

        fclose(fp);
    }

    sprintf(fname,"%s\\dendrogram.R",directory);
    if ( (fp=fopen(fname,"w")) )
    {

        sprintf(f,"%s//%s",directory,file);
        j=0;
        for (i=0; i<strlen(f); i++)
        {
            if (f[i]!='\\')
            {
                fname[j]=f[i];
                j++;
            }
            else
            {
                fname[j]='/';
                fname[j+1]='/';
                j+=2;
            }
        }
        fname[j]='\0';
        fprintf(fp,"A=read.table(\"%s\",header=FALSE)\n width=dim(A)[2]\n A.dist=dist(as.matrix(A[,4:width]))\n A.clust=hclust(A.dist)\n par(cex=0.5)\n plot(A.clust, labels=A[,1])\n",fname);
        fclose(fp);
    }


    result=1;
END:
    if (clusters) free(clusters);
    if (sort) free(sort);
    return result;
}






//======================================================================================================
//SAVE THE NUMBER OF CLUSTERS EACH PAIR OF STUDIES HAS IN COMMON
//======================================================================================================
int SaveCommonClustersByStudyPairs(HWND hwnd, struct Coordinates *ale, char directory[], char file[])
{
    int result=0;
    int InCommon;
    int *cluster=NULL;
    int Nclusters;
    int study1,study2;
    int i,j;
    FILE *fp=NULL;
    char fname[MAX_PATH];


    sprintf(fname,"%s\\%s",directory,file);
    if (!(fp=fopen(fname,"w"))) goto END;

    Nclusters=0;
    for (i=0; i<(*ale).TotalFoci; i++) if ((*ale).cluster[i]>Nclusters) Nclusters=(*ale).cluster[i];
    if (!(cluster=(int *)malloc((Nclusters+1)*sizeof(int)))) goto END;

    //SAVE THE HEADERS (STUDYIDs)
    for (study1=0; study1<(*ale).Nexperiments; study1++) fprintf(fp,",%s",(*ale).ID[study1].txt);
    fprintf(fp,"\n");

    for (study1=0; study1<(*ale).Nexperiments; study1++)
    {
        fprintf(fp,"%s,",(*ale).ID[study1].txt);
        for (study2=0; study2<(*ale).Nexperiments; study2++)
        {
            memset(cluster,0,sizeof(int)*(Nclusters+1));
            for (i=0; i<(*ale).TotalFoci; i++)
            {
                if ((*ale).experiment[i]==study1)
                {
                    for (j=0; j<(*ale).TotalFoci; j++)
                    {
                        if ((*ale).experiment[j]==study2)
                        {
                            if ((*ale).cluster[i] == (*ale).cluster[j])
                            {
                                cluster[(*ale).cluster[i]] = 1;
                            }
                        }
                    }
                }
            }
            InCommon=0;
            for (i=1; i<=Nclusters; i++)
            {
                if (cluster[i]) InCommon++;
            }
            fprintf(fp,"%d,",InCommon);
        }
        fprintf(fp,"\n");
    }




    result=1;
END:
    if (fp) fclose(fp);
    if (cluster) free(cluster);

    return result;

}



//======================================================================================================
//report the significant clusters
//the format is:
//x y z Nexperiments Minimum_p_value; where {x,y,z} is the cluster centroid; weighted by the ALE value
//======================================================================================================
int ReportClusters(HWND hwnd, struct Coordinates *ale,
                   char directory[], char file[],
                   float ALE[],
                   int X, int Y, int Z, float z0, float dz, float FWHM,
                   double critical, int FCDR, int MergeGroups, int Zfilter)
{
    char fname[MAX_PATH];
    FILE *fp;
    int cluster;
    int Nclusters;              //how many clusters are there to report
    int *experiments=NULL;      //how many experiments contribute to the clusters
    int Nfoci=(*ale).TotalFoci;
    int NsignificantFoci;
    int foci, iexp, FoundContributor;
    int xi,yi,zi;
    float x,y,z;
    float norm, weight;
    float minp;
    char *labels=NULL;
    char *b=NULL;
    int Nentries,Nl;
    struct Image Tal;



//LOAD THE TALAIRACH DATA
    memset(&Tal,0,sizeof(struct Image));
    sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
    LoadFromFileName(hwnd, fname, &Tal, 0);
    labels=LoadTalairachLabels(&Nl);
    Nentries=BiggestTalairachLabel(labels, Nl);
    RemoveNonGM(&Tal, labels, Nl,Nentries);

//count the number of significant foci
    NsignificantFoci=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        if ((*ale).p[foci]<=critical) NsignificantFoci++;
    }

//find the number of clusters
    Nclusters=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        if ((*ale).cluster[foci]>Nclusters) Nclusters=(*ale).cluster[foci];
    }


//count the number of significant studies contributing to each cluster
    if (!(experiments=(int *)malloc((Nclusters+1)*sizeof(int)))) goto END;
    memset(experiments,0,(Nclusters+1)*sizeof(int));
    for (cluster=1; cluster<=Nclusters; cluster++)
    {
        for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
        {
            FoundContributor=0;
            for (foci=0; foci<Nfoci; foci++)
            {
                if (((*ale).experiment[foci] == iexp) &&
                        ((*ale).cluster[foci] == cluster) &&
                        ((*ale).p[foci] <= critical)) FoundContributor=1;
            }
            if (FoundContributor) experiments[cluster]++;
        }
    }



    sprintf(fname,"%s\\%s",directory,file);
    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"%s\n",(*ale).coordinate_file_name);
        if (Zfilter==ID_USE_NEGATIVE_Z) fprintf(fp,"Negative Z only\n");
        if (Zfilter==ID_USE_POSITIVE_Z) fprintf(fp,"Positive Z only\n");
        if (MergeGroups) fprintf(fp,"Studies Merged\n");
        if (critical>0.0) fprintf(fp,"p-value for significance <=, %f\n", critical);
        else  fprintf(fp,"p-value for significance <=, 0.0\n");
        fprintf(fp,"Proportion of foci that are significant,%f\n",(float)NsignificantFoci/Nfoci);
        fprintf(fp,"FWHM =, %f\n", FWHM);
        fprintf(fp,"Number of foci, %d\n", (*ale).TotalFoci);
        fprintf(fp,"Number of studies, %d\n", (*ale).Nexperiments);
        if (FCDR) fprintf(fp,"Method used FCDR\n");
        else fprintf(fp,"Method used FDR\n");
        fprintf(fp,"Talairach report, , , , , Cluster{x y z},p_value,Number Of significant Studies,Slice,Studies\n\n");
        for (cluster=1; cluster<=Nclusters; cluster++)
        {

            x=y=z=0.0;
            norm=0.0;
            minp=1.0;
            for (foci=0; foci<Nfoci; foci++)
            {
                if ((*ale).cluster[foci]==cluster)
                {
                    weight=ALE[(*ale).voxel[foci]];
                    x+=weight*(*ale).x[foci];
                    y+=weight*(*ale).y[foci];
                    z+=weight*(*ale).z[foci];
                    norm+=weight;
                    if ((*ale).p[foci]<minp)
                    {
                        minp=(*ale).p[foci];
                    }
                }
            }

            if (norm>0.0)
            {

                fprintf(fp,"cluster %d\n",cluster);


                x/=norm;
                y/=norm;
                z/=norm;



                xi=(int)((x+Tal.x0)/Tal.dx+0.5);
                yi=(int)((y+Tal.y0)/Tal.dy+0.5);
                zi=(int)((z+Tal.z0)/Tal.dz+0.5);

                if (labels && Tal.img)
                {
                    b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                    fprintf(fp,"%s,",&b[1]);
                }



                zi=(int)((z+z0)/dz+0.5);
                fprintf(fp," (%5.1f  %5.1f  %5.1f),%f,%d,%d,",x, y, z,minp, experiments[cluster], zi);

                //list each experiment that contributes to this cluster
                //report the lowest p value for the experiment, and indicate if it is significant
                for (iexp=0; iexp<(*ale).Nexperiments; iexp++)
                {
                    FoundContributor=Nfoci;
                    for (foci=0; foci<Nfoci; foci++)
                    {
                        if (((*ale).cluster[foci]==cluster) && ((*ale).experiment[foci] == iexp))
                        {
                            if (FoundContributor == Nfoci) FoundContributor = foci;
                            else if ((*ale).p[foci] < (*ale).p[FoundContributor]) FoundContributor = foci;
                        }
                    }
                    if (FoundContributor < Nfoci)
                    {
                        if ((*ale).p[FoundContributor] <= critical) fprintf(fp,"*");

                        if ((*ale).ZscoreUsed) fprintf(fp,"p=%f, %s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
                                                           (*ale).p[FoundContributor],
                                                           (*ale).ID[(*ale).experiment[FoundContributor]].txt,
                                                           (*ale).CTRST[(*ale).experiment[FoundContributor]].txt,
                                                           (*ale).CND[(*ale).experiment[FoundContributor]].txt,
                                                           (*ale).x[FoundContributor],(*ale).y[FoundContributor],(*ale).z[FoundContributor],(*ale).Zsc[FoundContributor]);
                        else fprintf(fp,"p=%f, %s, %s, %s, %5.1f  %5.1f  %5.1f,",
                                         (*ale).p[FoundContributor],
                                         (*ale).ID[(*ale).experiment[FoundContributor]].txt,
                                         (*ale).CTRST[(*ale).experiment[FoundContributor]].txt,
                                         (*ale).CND[(*ale).experiment[FoundContributor]].txt,
                                         (*ale).x[FoundContributor],(*ale).y[FoundContributor],(*ale).z[FoundContributor]);


                        if (labels && Tal.img)
                        {
                            xi=(int)(((*ale).x[FoundContributor]+Tal.x0)/Tal.dx+0.5);
                            yi=(int)(((*ale).y[FoundContributor]+Tal.y0)/Tal.dy+0.5);
                            zi=(int)(((*ale).z[FoundContributor]+Tal.z0)/Tal.dz+0.5);
                            b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
                            fprintf(fp,"%s\n , , , , , , , , ,",&b[1]);
                        }
                    }

                }
                fprintf(fp,"\n");
            }
        }
        fclose(fp);
    }


END:
    if (labels) free(labels);
    if (experiments) free(experiments);
    ReleaseImage(&Tal);

    return Nclusters;
}

//======================================================================================================
//REPORT STUDY RESULTS
//======================================================================================================
int ReportStudySummary(HWND hwnd, struct Coordinates *ale, char directory[], char file[], float FWHM, double critical, int FCDR, int MergeGroups)
{
    int result=0;
    int foci,TotalFoci=(*ale).TotalFoci;
    int studies=(*ale).Nexperiments;
    int study;
    int *StudyFoci=NULL;
    int *SignificantStudyFoci=NULL;
    char fname[MAX_PATH];
    FILE *fp=NULL;


    if (!(StudyFoci=(int *)malloc(studies*sizeof(int)))) goto END;
    if (!(SignificantStudyFoci=(int *)malloc(studies*sizeof(int)))) goto END;
    memset(StudyFoci,0,studies*sizeof(int));
    memset(SignificantStudyFoci,0,studies*sizeof(int));

    sprintf(fname,"%s\\%s",directory,file);
    if ((fp=fopen(fname,"w")))
    {
        for (foci=0; foci<TotalFoci; foci++)
        {
            StudyFoci[(*ale).experiment[foci]]++;
            if ((*ale).p[foci]<=critical) SignificantStudyFoci[(*ale).experiment[foci]]++;
        }

        if (MergeGroups) fprintf(fp,"Groups Merged\n");
        if (FCDR) fprintf(fp,"Used FCDR\n");
        fprintf(fp,"critical value=%f\n",critical);
        fprintf(fp,"FWHM=%f\n",FWHM);
        fprintf(fp,"ID,Description,Subjects,Controls,Proportion of significant foci, foci\n");
        for (study=0; study<studies; study++)
        {
            if (StudyFoci[study]) fprintf(fp,"%s,%s,%d,%d,%f,%d\n",(*ale).ID[study].txt,(*ale).DESC[study].txt,(*ale).SubjectsInExp[study],(*ale).ControlsInExp[study], (double)SignificantStudyFoci[study]/StudyFoci[study],StudyFoci[study]);
            else fprintf(fp,"%s,%s,%d,%f,%d\n",(*ale).ID[study].txt,(*ale).DESC[study].txt,(*ale).SubjectsInExp[study], 0.0, 0);
        }
        fclose(fp);
    }
    else goto END;

    result=1;
END:
    if (StudyFoci) free(StudyFoci);
    if(SignificantStudyFoci) free(SignificantStudyFoci);

    return result;
}


//======================================================================================================
//GET THE P VALUE THROUGH FDR CONTROL
//======================================================================================================
double ControlFDR(double p[], int Np, float samples[], int Nsamples, int Ntrials, double critical, char directory[])
{
    int *sort = NULL;
    int i,j,n;
    double pvalue = -1.0;
    FILE *fp;
    char fname[MAX_PATH];

    if (!(sort = (int *)malloc(sizeof(int)*Np))) goto END;

    sprintf(fname,"%s\\pvalue_FDR.csv",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"pvalue, FDR estimate\n");

        QuickSort(p, sort, Np);
        for (i=0; i<Np; i++)
        {
            if (p[sort[i]]<=critical)
            {

                n=0;
                for (j=0; j<Nsamples; j++) if (samples[j]<=p[sort[i]])
                    {
                        n++;
                    }


                if ((critical*(i+1)) >= (double)(n)/Ntrials)
                {
                    pvalue = 1.001*p[ sort[i] ];//attempt to avoid rounding errors
                    j=i+1;
                    while((j<Np) && (p[ sort[i] ] == p[ sort[j] ])) j++;
                    if (j<Np)
                    {
                        if (pvalue > p[ sort[j] ]) pvalue = (p[ sort[i] ] + p[ sort[j] ])/2;
                    }

                }

                fprintf(fp,"%f,%f\n",p[sort[i]], (double)n/Ntrials/(i+1));
            }
        }
        fclose(fp);
    }

END:
    if (sort) free(sort);

    return pvalue;
}


//======================================================================================================
//GET THE P VALUE THROUGH FCDR CONTROL
//CALL THIS FUNCTION WITH *Nclusters==0 TO GO (QUICKLY) ALL THE WAY THROUGH ALL POSSIBLE CLUSTERS UP TO critical
//HOWEVER, IT IS POSSIBLE FOR THE FCDR TO REDUCE IF THERE IS MERGING OF CLUSTERS UNDER THE NULL
//THEREFORE, CAN CALL THE FUNCTION AGAIN TO RUN COMPLETELY WHEN THE NUMBER OF CLUSTERS = *Nclusters
//======================================================================================================
double ControlFCDR(HWND hwnd, double p[], int Np, double ptests[], float ALEs[], float x[], float y[], float z[], int Ntests,
                   float sigma, double critical, char directory[], int *Nclusters)
{
    int *sort = NULL;
    int i,j,test,N, Nbak, n, Nvalue;
    int SigOnly=1;
    short int *cluster = NULL;
    double pvalue = -1.0;
    float *Nfalse = NULL;
    float *NfalseSig = NULL;
    float expected;
    float FWE;
    FILE *fp;
    char txt[256];
    char fname[MAX_PATH];
    HDC hDC=GetDC(hwnd);

    Nvalue=0;

    if (!(sort = (int *)malloc(sizeof(int)*Np))) goto END;
    if (!(cluster = (short int *)malloc(sizeof(short int)*Np))) goto END;
    if (!(Nfalse = (float *)malloc(Np*sizeof(float)))) goto END;
    if (!(NfalseSig = (float *)malloc(Np*sizeof(float)))) goto END;
    if (!hDC) goto END;


    sprintf(fname,"%s\\pvalue_FCDR%d.csv",directory,(*Nclusters));
    if ( (fp=fopen(fname,"w")) )
    {

        fprintf(fp,"pvalue, FCDR estimate, FWE estimate, Number of significant clusters\n");
        QuickSort(p, sort, Np);
        expected=0.0;
        Nbak=0;
        for (i=0; i<Np; i++)
        {
            if ( (p[sort[i]]<=critical) && ((!i) || (p[sort[i]]>p[sort[i-1]])) )
            {

                RemoveInput(hwnd);
                sprintf(txt,"Computing FCDR at level %f      ",p[sort[i]]);
                TextOut(hDC, 100,100,txt,strlen(txt));

                //count the number of observed clusters to this p-value
                N = CountSignificantMApeaks(x, y, z, ptests, ALEs, cluster, Np, sigma, ptests[sort[i]],SigOnly);


                if (  ((N>Nbak) && (!(*Nclusters))) || (N==(*Nclusters)) )
                {
                    Nbak=N;


                    //count the number of NULL clusters to this p-value
                    n=0;
                    FWE=0.0;
                    memset(Nfalse,0,sizeof(float)*Np);
                    for (test=1; test<=Ntests; test++)
                    {

                        //n += CountSignificantMApeaks(&x[test*Np], &y[test*Np], &z[test*Np], &ptests[test*Np], &ALEs[test*Np], cluster, Np, sigma, ptests[sort[i]],SigOnly);
                        j = CountSignificantMApeaks(&x[test*Np], &y[test*Np], &z[test*Np], &ptests[test*Np], &ALEs[test*Np], cluster, Np, sigma, ptests[sort[i]],SigOnly);
                        n+=j;
                        if (j) FWE+=1.0;
                        if (j<Np) Nfalse[j]+=1.0;
                    }


                    expected = ((double)n)/Ntests;
                    //sprintf(txt,"mean=%f median=%f",((double)n)/Ntests, expected);
                    //MessageBox(NULL,txt,"",MB_OK);


                    if ((critical*N) >= expected)
                    {

                        pvalue = 1.0001*ptests[ sort[i] ];//make it slightly bigger to avoid problems with < comparisons

                        j=i+1;
                        while((j<Np) && (ptests[ sort[i] ] == ptests[ sort[j] ])) j++;
                        if (j<Np)
                        {
                            if (pvalue > ptests[ sort[j]]) pvalue = (ptests[ sort[i] ] + ptests[ sort[j] ])/2;
                        }
                        memcpy(NfalseSig,Nfalse,sizeof(float)*Np);

                        Nvalue=N;
                    }

                    fprintf(fp,"%f, %f, %f, %d\n",ptests[sort[i]], expected/N, FWE/Ntests,N);
                }
            }
        }
        fclose(fp);
    }


    if (!Nvalue) goto END;

    /*
        sprintf(fname,"%s\\FCDR_cdf.csv",directory);
        if ( (fp=fopen(fname,"w")) )
        {
            for (i=1; (i<Np); i++) NfalseSig[i] += NfalseSig[i-1];
            for (i=0; (i<Np); i++)  NfalseSig[i] /= NfalseSig[Np-1];
            for (i=0; (i<Np) && (NfalseSig[i]<1.0); i++)
            {
                fprintf(fp,"%d,%f\n",i,NfalseSig[i]);
            }
            fclose(fp);
        }
    */

    *Nclusters=Nvalue;

END:
    if (sort) free(sort);
    if (cluster) free(cluster);
    if (Nfalse) free(Nfalse);
    if (NfalseSig) free(NfalseSig);
    if (hDC) ReleaseDC(hwnd, hDC);

    return pvalue;
}





//======================================================================================================
//GET THE P VALUE THROUGH FCDR CONTROL
//if Nfixed is not zero, then only compute the FCDR if the number of clusters=(*Nclusters)
//this allows us to spead things up
//return the number of clusters in *Nclusters at the end
//8/april/2015
#define PSUEDO_GROUP                                                        \
                            for (j=0; j<nA; j++)                                            \
                            {                                                                       \
                                if ((experiments[j] == iexp) && ((ptemp=ptests[NpTest + j])<=ptests[ sort[i]]) && (L<Np))                          \
                                {                                                                 \
                                    x[L] = xa[j];                                             \
                                    y[L] = ya[j];                                             \
                                    z[L] = za[j];                                             \
                                    pnull[L] = ptemp;                                    \
                                    L++;                                                        \
                                }                                                                  \
                            }                                                                       \
                            for (j=0; j<nB; j++)                                            \
                            {                                                                       \
                                if ((experiments[nA + j] == iexp) && ((ptemp=ptests[NpTest + nA + j])<=ptests[ sort[i]]) && (L<Np))               \
                                {                                                           \
                                    x[L] = xb[j];                                       \
                                    y[L] = yb[j];                                       \
                                    z[L] = zb[j];                                       \
                                    pnull[L] = ptemp;                               \
                                    L++;                                                    \
                                }                                                               \
                            }                                                                   \
//======================================================================================================
struct ContrastP ControlFCDRforComparingALEs(HWND hwnd, double p[], int nA, int nB, double ptests[], int Ntests, float xa[], float ya[], float za[],
        float xb[], float yb[], float zb[], char G[], short int experiments[], int Nexperiments, float sigma,
        double critical, char directory[], int *Nclusters)
{
    int *sort = NULL;
    int i,j,iexp,test,N,Nbak,n;
    int L,NullCount;
    int NpTest;
    int ClusterCount=0;
    int offset;
    short int *cluster = NULL;
    int Np = nA + nB;
    float expected;
    float *x = NULL;
    float *y = NULL;
    float *z = NULL;
    double *pnull = NULL;
    double pvalue = -1.0;
    double ptrend = -1.0;
    double TrendFCDR = 1.0;
    struct ContrastP CP;
    double ptemp;
    FILE *fp;
    char fname[MAX_PATH];
    char txt[256];
    HDC hDC=GetDC(hwnd);

    CP.p[SIGNIFICANT_CONTRAST_P] = -1.0;
    CP.p[TREND_CONTRAST_P] = -1.0;


    if (!(x = (float *)malloc(sizeof(float)*(Np)))) goto END;
    if (!(y = (float *)malloc(sizeof(float)*(Np)))) goto END;
    if (!(z = (float *)malloc(sizeof(float)*(Np)))) goto END;
    if (!(pnull = (double *)malloc(sizeof(double)*(Np)))) goto END;
    if (!(sort = (int *)malloc(sizeof(int)*Np))) goto END;
    if (!(cluster = (short int *)malloc(sizeof(short int)*Np))) goto END;



    sprintf(fname,"%s\\pvalue_FCDR contrast%d.csv",directory,(*Nclusters));
    if ( (fp=fopen(fname,"w")) )
    {

        fprintf(fp,"pvalue, FCDR estimate, Number of significant clusters\n");
        QuickSort(p, sort, Np);
        Nbak=0;
        for (i=0; i<Np; i++)
        {
            if ( (p[sort[i]] <= critical) && ((!i) || (p[sort[i]]>p[sort[i-1]])) )
            {

                RemoveInput(hwnd);
                sprintf(txt,"Current p-value = %f      Max Pvalue = %f       ",p[sort[i]], critical);
                TextOut(hDC,50,50,txt,strlen(txt));
                UpdateWindow(hwnd);


                //count the number of observed clusters to this p-value
                N = CountSignificantClustersFast(xa, ya, za, ptests, cluster, nA, sigma, ptests[ sort[i] ], 1);
                N += CountSignificantClustersFast(xb, yb, zb, &ptests[nA], cluster, nB, sigma, ptests[ sort[i] ], 1);

                if (  ((N>Nbak) && (!(*Nclusters))) || (N==(*Nclusters)) )//no point in computing FCDR if N not increased; FCDR cant go down unless N goes up
                {
                    Nbak=N;

                    //count the number of NULL clusters to this p-value
                    n=0;
                    for (test=1; test<=Ntests; test++)
                    {
                        NpTest=test*Np;

                        //ADD CLUSTERS FROM PSUEDO GROUP A
                        L=0;
                        offset=0;
                        for (iexp=0; iexp<Nexperiments; iexp++)
                        {
                            if ( G[test + offset] )//this indicates that this is psuedo group A
                            {
                                PSUEDO_GROUP
                            }
                            offset+=Ntests+1;
                        }

                        NullCount = CountSignificantClustersAllSig(x, y, z, pnull, cluster, L, sigma, ptests[ sort[i] ]);
                        //NullCount = CountSignificantClustersFast(x, y, z, pnull, cluster, L, sigma, ptests[ sort[i] ],1);

                        //ADD CLUSTERS FROM PSUEDO GROUP B
                        L=0;
                        offset=0;
                        for (iexp=0; iexp<Nexperiments; iexp++)
                        {
                            if ( !G[test + offset] )//this indicates that this is psuedo group B
                            {
                                PSUEDO_GROUP
                            }
                            offset+=Ntests+1;
                        }
                        NullCount += CountSignificantClustersAllSig(x, y, z, pnull, cluster, L, sigma, ptests[ sort[i] ]);
                        //NullCount += CountSignificantClustersFast(x, y, z, pnull, cluster, L, sigma, ptests[ sort[i] ],1);

                        n += NullCount;
                    }//test



                    expected = ((double)n)/Ntests;


                    //get the pvalue for a significant FCDR
                    if ((critical*N) >= expected)
                    {
                        pvalue = 1.00001*ptests[ sort[i] ];
                        ClusterCount=N;//need to return the number of clusters in *Nclusters
                        j=i+1;
                        while((j<Np) && (ptests[ sort[i] ] == ptests[ sort[j] ])) j++;
                        if (j<Np)
                        {
                            if (pvalue >= ptests[ sort[j] ]) pvalue = (ptests[ sort[i] ] + ptests[ sort[j] ])/2;
                        }
                        CP.p[SIGNIFICANT_CONTRAST_P] = pvalue;
                        CP.fcdr[SIGNIFICANT_CONTRAST_P] = (expected/N);
                    }

                    //get the pvalue for a trend
                    //the trend is the smallest FCDR that is > critical
                    if ((critical*N) < expected)
                    {
                        if ((expected/N)<TrendFCDR)
                        {
                            TrendFCDR = expected/N;
                            ptrend = 1.00001*p[ sort[i] ];
                            j=i+1;
                            while((j<Np) && (ptests[ sort[i] ] == ptests[ sort[j] ])) j++;
                            if (j<Np)
                            {
                                if (ptrend >= ptests[ sort[j] ]) ptrend = (ptests[ sort[i] ] + ptests[ sort[j] ])/2;
                            }
                            CP.p[TREND_CONTRAST_P] = ptrend;
                            CP.fcdr[TREND_CONTRAST_P] = (expected/N);

                        }
                    }

                    fprintf(fp,"%g, %f, %d\n",ptests[ sort[i] ],expected/N, N);

                }
            }
        }

        fclose(fp);
    }


    *Nclusters=ClusterCount;
END:
    if (sort) free(sort);
    if (cluster) free(cluster);
    if (x) free(x);
    if (y) free(y);
    if (z) free(z);
    if (pnull) free(pnull);
    ReleaseDC(hwnd, hDC);



    return CP;
}



int GetAllPvaluesByPermutation(HWND hwnd, HDC hDC, float MA[], int nA, int nB, int study[], float T[], double p[],
                               int Ncoordinates, int Ntests, char G[], int Iterations);
int GetPvalueByPermutation(float MA[], int nA, int nB, float T[], double p[], int Ntests, char G[], int iterations);
int GetPvalueByCountingPermutations(float MA[], int nA, int nB, float T[], double p[], int Ntests, char G[], double combinations[]);
int TestNormalApproximationToALEdifference(char group[], float T[], double p[], int Ntests);
int FixDegeneratePvalues(float T[], double P[], char group[], int N);
//======================================================================================================
//17/03/2015
//COMBINED OMNIBUS AND SPATIAL COMPARISON OF ALEs
//======================================================================================================
struct ContrastP CompareALEs_Omnibus_Spatial(HWND hwnd, struct Coordinates *A, struct Coordinates *B, double pA, double pB,
        float dx, float dy, float dz, float sigma, double critical,
        char directory[], int fcdr, int GroupsMerged)
{

    struct ContrastP CP,CP1;
    int TotalSigFoci;
    int AsigFoci, BsigFoci;
    int Nstudies=(*A).Nexperiments+(*B).Nexperiments;
    int Nfoci=(*A).TotalFoci+(*B).TotalFoci;
    int *studies=NULL;
    int foci,study;
    int i,j,offset,SignificantFocus;
    int Nsig;
    int Nclusters;
    int perm;
    short int *experiments = NULL;
    int *IndexToFocus=NULL;
    int IsSignificant;
    int group;
    char *G_study_perm = NULL, *G=NULL;
    double *pObserved=NULL;
    double pfdr, pvalue;
    double *p=NULL;
    double *pAllSamples=NULL;
    double *comb=NULL, maxcomb;
    double norm=NormALE(sigma, dx, dy, dz);
    float tmpA,tmpB;
    double *SumLn=NULL;
    float *MA_foci_study=NULL;
    float *Stest=NULL;
    float *SigResults=NULL;
    float *x=NULL;
    float *y=NULL;
    float *z=NULL;
    char txt[256];
    char fname[MAX_PATH];
    HDC hDC=GetDC(hwnd);
    FILE *fp;



//COUNT THE NUMBER OF SIGNIFICANT FOCI IN GROUP A AND B
    TotalSigFoci=AsigFoci=BsigFoci=0;
    for (foci=0; foci<(*A).TotalFoci; foci++)
    {
        if ((*A).p[foci]<=pA)
            //if ((*A).cluster[foci])
        {
            TotalSigFoci++;
            AsigFoci++;
        }
    }
    for (foci=0; foci<(*B).TotalFoci; foci++)
    {
        if ((*B).p[foci]<=pB)
            //if ((*B).cluster[foci])
        {
            TotalSigFoci++;
            BsigFoci++;
        }
    }

    if (!(SumLn=(double *)calloc((CONTRAST_PERMUTATIONS+1),sizeof(double)))) goto END;
    if (!(IndexToFocus=(int *)malloc(sizeof(int)*TotalSigFoci))) goto END;
    if (!(x=(float *)malloc(sizeof(float)*TotalSigFoci))) goto END;
    if (!(y=(float *)malloc(sizeof(float)*TotalSigFoci))) goto END;
    if (!(z=(float *)malloc(sizeof(float)*TotalSigFoci))) goto END;
    if (!(experiments = (short int *)malloc(sizeof(short int)*TotalSigFoci))) goto END;
    if (!(SigResults=(float *)malloc(TotalSigFoci*sizeof(float)*(CONTRAST_PERMUTATIONS+1)))) goto END;//The Significant Results for FDR estimation
    if (!(p=(double *)malloc(TotalSigFoci*sizeof(double)*(CONTRAST_PERMUTATIONS+1)))) goto END;//the p-values for ALL of the experiments, including random
    if (!(pAllSamples=(double *)malloc(Nfoci*(CONTRAST_PERMUTATIONS+1)*sizeof(double)))) goto END;//the p-values for ALL of the permutation samples
    if (!(pObserved=(double *)malloc(TotalSigFoci*sizeof(double)))) goto END;//The p-values for the observed data
    if (!(G_study_perm=(char *)malloc(Nstudies*(CONTRAST_PERMUTATIONS+1)))) goto END;//randomised grouping. If(G==TRUE) then its group A
    if (!(G=(char *)malloc(Nstudies))) goto END;//randomised grouping. If(G==TRUE) then its group A; one column of G_study_perm[]
    if (!(MA_foci_study=(float *)malloc(sizeof(float)*Nstudies*Nfoci))) goto END;//the lookup table for the ALE by experiment
    if (!(Stest=(float *)malloc(sizeof(float)*Nfoci*(CONTRAST_PERMUTATIONS+1)))) goto END;//the difference of ALE test statistic
    if (!(comb=(double *)malloc(sizeof(double)*(Nstudies+1)*(Nstudies+1)))) goto END;
    if (!(studies=(int *)malloc(sizeof(int)*Nfoci))) goto END;

    //compute a lookup table for the combinations used in the permutation routines
    //this is to speed things up hopefully
    maxcomb=0.0;
    offset=0;
    for (i=0; i<=Nstudies; i++)
    {
        for (j=0; j<=Nstudies; j++)
        {
            comb[offset + j] = Combinations(i, j);
            if (comb[offset + j]>maxcomb) maxcomb = comb[offset + j];
        }
        offset+=Nstudies;
    }
    if (maxcomb<=0.0) goto END;
    for (i=0; i<Nstudies*Nstudies; i++) comb[i] /= maxcomb;




    //GET AN INDEX TO THE SIGNIFICANT FOCI
    i=0;
    for (foci=0; foci<(*A).TotalFoci; foci++)
    {
        if ((*A).p[foci]<=pA)
            //if ((*A).cluster[foci])
        {
            IndexToFocus[i]=foci;
            x[i] = (*A).x[foci];
            y[i] = (*A).y[foci];
            z[i] = (*A).z[foci];
            i++;
        }
    }
    for (foci=0; foci<(*B).TotalFoci; foci++)
    {
        if ((*B).p[foci]<=pB)
            //if ((*B).cluster[foci])
        {
            IndexToFocus[i]=foci;
            x[i] = (*B).x[foci];
            y[i] = (*B).y[foci];
            z[i] = (*B).z[foci];
            i++;
        }
    }


//the list of experiments is required for the FCDR routine and arranging groups
    for (foci=0; foci<AsigFoci; foci++) experiments[foci] = (*A).experiment[IndexToFocus[foci]];
    for (foci=0; foci<BsigFoci; foci++) experiments[foci + AsigFoci] = (*B).experiment[IndexToFocus[foci+AsigFoci]] + (*A).Nexperiments;




//COMPUTE A LOOKUP TABLE OF THE MA VALUES FOE EACH FOCUS
    for (foci=0; foci<(*A).TotalFoci; foci++)
    {
        for (study=0; study<(*A).Nexperiments; study++)
        {
            MA_foci_study[foci*Nstudies + study] =(float)MAvalue((*A).x[foci], (*A).y[foci], (*A).z[foci], A, study, sigma, norm);
        }
        for (study=0; study<(*B).Nexperiments; study++)
        {
            MA_foci_study[foci*Nstudies + study + (*A).Nexperiments] =(float)MAvalue((*A).x[foci], (*A).y[foci], (*A).z[foci], B, study, sigma, norm);
        }
    }
    for (foci=0; foci<(*B).TotalFoci; foci++)
    {
        for (study=0; study<(*A).Nexperiments; study++)
        {
            MA_foci_study[(foci+(*A).TotalFoci)*Nstudies + study] =(float)MAvalue((*B).x[foci], (*B).y[foci], (*B).z[foci], A, study, sigma, norm);
        }
        for (study=0; study<(*B).Nexperiments; study++)
        {
            MA_foci_study[(foci+(*A).TotalFoci)*Nstudies + study + (*A).Nexperiments] =(float)MAvalue((*B).x[foci], (*B).y[foci], (*B).z[foci], B, study, sigma, norm);
        }
    }






    //compute ALE difference values per foci for the original groups and for NullPerm random permutations
    for (perm=0; perm<=CONTRAST_PERMUTATIONS; perm++)
    {

        if (!perm)
        {
            memset(G,0,Nstudies);
            for (study=0; study<(*A).Nexperiments; study++) G[study]=1;
        }
        else RandomiseExperimentsIntoGroups(G, Nstudies, (*A).Nexperiments);

        for (study=0; study<Nstudies; study++) G_study_perm[study*(CONTRAST_PERMUTATIONS+1) + perm]=G[study];

        for (foci=0; foci<Nfoci; foci++)
        {
            if (foci<(*A).TotalFoci) study=(*A).experiment[foci];
            else study=(*A).Nexperiments + (*B).experiment[foci-(*A).TotalFoci];
            group=G[study];
            tmpA=tmpB=0.0;
            for (study=0; study<Nstudies; study++)
            {
                if (G[study]) tmpA += MA_foci_study[foci*Nstudies+study];
                else tmpB += MA_foci_study[foci*Nstudies+study];
            }
            if (group) Stest[foci*(CONTRAST_PERMUTATIONS+1) + perm] = tmpA - tmpB;
            else Stest[foci*(CONTRAST_PERMUTATIONS+1) + perm] =  tmpB - tmpA;
        }
    }



    //list of studies is needed for the p value calculation procedure
    for (foci=0; foci<Nfoci; foci++)
    {
        if (foci<(*A).TotalFoci) studies[foci] = (*A).experiment[foci];
        else studies[foci] = (*A).Nexperiments + (*B).experiment[foci-(*A).TotalFoci];
    }

//compute p-values for all foci by counting permutations
    GetAllPvaluesByPermutation(hwnd, hDC, MA_foci_study, (*A).Nexperiments, (*B).Nexperiments, studies,
                               Stest, pAllSamples, Nfoci, CONTRAST_PERMUTATIONS+1, G_study_perm, CMA_PERMUTATIONS);

    //copy only the significant p-values
    //and do omnibus test
    SignificantFocus=0;
    for (foci=0; foci<Nfoci; foci++)
    {
        IsSignificant=0;
        if (foci<(*A).TotalFoci)
        {
            if ((*A).p[foci]<=pA) IsSignificant=1;
            //if ((*A).cluster[foci]) IsSignificant=1;
        }
        else
        {
            if ((*B).p[foci-(*A).TotalFoci]<=pB) IsSignificant=1;
            //if ((*B).cluster[foci-(*A).TotalFoci]) IsSignificant=1;
        }

        //do the log sum of the p values for the omnibus test
        for (perm=0; perm<=CONTRAST_PERMUTATIONS; perm++)
        {
            SumLn[perm]+=log(pAllSamples[foci*(CONTRAST_PERMUTATIONS+1) + perm]+1.0e-12);
        }

        //if this foci is significant AFTER CBMA copy the resulting p values to p[]
        if (IsSignificant)
        {
            for (perm=0; perm<=CONTRAST_PERMUTATIONS; perm++)
            {
                p[SignificantFocus*(CONTRAST_PERMUTATIONS+1)+perm] = pAllSamples[foci*(CONTRAST_PERMUTATIONS+1) + perm];
            }
            SignificantFocus++;
        }
    }



//save the omnibus test p value
    pvalue=0.0;
    for (perm=1; perm<=CONTRAST_PERMUTATIONS; perm++) if (SumLn[0]>=SumLn[perm])
        {
            pvalue+=1.0;
        }

    sprintf(fname,"%s//difference between groups.txt",directory);
    if ( (fp=fopen(fname,"w")) )
    {
        if (GroupsMerged) fprintf(fp,"Groups Merged\n");
        fprintf(fp,"Group A:\n");
        fprintf(fp,"%s\n",(*A).coordinate_file_name);
        fprintf(fp,"Number of studies=%d\n",(*A).Nexperiments);
        fprintf(fp,"Number of foci=%d\n",(*A).TotalFoci);
        fprintf(fp,"Group B:\n");
        fprintf(fp,"%s\n",(*B).coordinate_file_name);
        fprintf(fp,"Number of studies=%d\n",(*B).Nexperiments);
        fprintf(fp,"Number of foci=%d\n",(*B).TotalFoci);
        fprintf(fp,"Significance of difference between two groups by permutation test\n All foci %f\n",pvalue/CONTRAST_PERMUTATIONS);
        fclose(fp);
    }
//================================================
//###########################################
    /*
        fp=fopen("c://temp//index_new.csv","w");
        for (foci=0; foci<TotalSigFoci; foci++)
        {
            fprintf(fp,"%d\n",IndexToFocus[foci]);
        }
        fclose(fp);
        fp=fopen("c://temp//table_new.csv","w");
        for (foci=0; foci<TotalSigFoci; foci++)
        {
            for (study=0; study<Nstudies; study++)
            {
                if (foci<AsigFoci) fprintf(fp,"%f,",MA_foci_study[study + IndexToFocus[foci]*Nstudies]);
                else fprintf(fp,"%f,",MA_foci_study[study + (IndexToFocus[foci]+(*A).TotalFoci)*Nstudies]);
            }
            fprintf(fp,"\n");
        }
        fclose(fp);
        fp=fopen("c://temp//Stest_new.csv","w");
        for (foci=0; foci<TotalSigFoci; foci++)
        {
            if (foci<AsigFoci) fprintf(fp,"%f\n",Stest[IndexToFocus[foci]*(CONTRAST_PERMUTATIONS+1)]);
            else fprintf(fp,"%f\n",Stest[(IndexToFocus[foci]+(*A).TotalFoci)*(CONTRAST_PERMUTATIONS+1)]);
        }
        fclose(fp);
        fp=fopen("c://temp//pfcdr_new.csv","w");
        for (foci=0; foci<TotalSigFoci; foci++)
        {
            fprintf(fp,"%f\n",p[foci*(CONTRAST_PERMUTATIONS+1)]);
        }
        fclose(fp);
    */
//###########################################




    RemoveInput(hwnd);
    sprintf(txt,"Controlling FDR                        ");
    TextOut(hDC,100,150,txt,strlen(txt));
    UpdateWindow(hwnd);



    //gather the significant results from the null experiments
    Nsig=0;
    for (foci=0; foci<TotalSigFoci; foci++)
    {
        for (perm=1; perm<=(CONTRAST_PERMUTATIONS); perm++)
        {
            if (p[foci*(CONTRAST_PERMUTATIONS+1) + perm]<=critical)
            {
                SigResults[Nsig] = p[foci*(CONTRAST_PERMUTATIONS+1) + perm];
                Nsig++;
            }
        }
        pObserved[foci] = p[foci*(CONTRAST_PERMUTATIONS+1)];
    }



//Get the pvalue for controlling the FDR
    pfdr = ControlFDR(pObserved, TotalSigFoci, SigResults, Nsig, CONTRAST_PERMUTATIONS, critical, directory);



//the pvalue table needs transposing for the FCDR control
    for (foci=0; foci<TotalSigFoci; foci++)
    {
        for (perm=0; perm<=(CONTRAST_PERMUTATIONS); perm++)
        {
            Stest[foci*(CONTRAST_PERMUTATIONS+1) + perm] = p[foci*(CONTRAST_PERMUTATIONS+1) + perm];
        }
    }
    for (foci=0; foci<TotalSigFoci; foci++)
    {
        for (perm=0; perm<=(CONTRAST_PERMUTATIONS); perm++)
        {
            p[foci + perm*TotalSigFoci] = Stest[foci*(CONTRAST_PERMUTATIONS+1) + perm];
        }
    }



    RemoveInput(hwnd);
    sprintf(txt,"Controlling FCDR                        ");
    TextOut(hDC,100,150,txt,strlen(txt));
    UpdateWindow(hwnd);

    //do fast FCDR control to work out the number of clusters
    Nclusters=0;
    CP = ControlFCDRforComparingALEs(hwnd, pObserved, AsigFoci, BsigFoci, p, CONTRAST_PERMUTATIONS,
                                     x, y, z, &x[AsigFoci], &y[AsigFoci], &z[AsigFoci],
                                     G_study_perm, experiments, Nstudies, sigma, critical, directory,&Nclusters);

    //do slow FCDR control, but only for this Nclusters
    if (Nclusters) CP1 = ControlFCDRforComparingALEs(hwnd, pObserved, AsigFoci, BsigFoci, p, CONTRAST_PERMUTATIONS,
                             x, y, z, &x[AsigFoci], &y[AsigFoci], &z[AsigFoci],
                             G_study_perm, experiments, Nstudies, sigma, critical, directory,&Nclusters);


    RemoveInput(hwnd);
    sprintf(txt,"Done!                        ");
    TextOut(hDC,100,150,txt,strlen(txt));
    UpdateWindow(hwnd);



    for (foci=0; foci<(*A).TotalFoci; foci++) (*A).p[foci] =1.0;
    for (foci=0; foci<AsigFoci; foci++)
    {
        (*A).p[IndexToFocus[foci]] = pObserved[foci];
    }
    for (foci=0; foci<(*B).TotalFoci; foci++)  (*B).p[foci] = 1.0;
    for (foci=0; foci<BsigFoci; foci++)
    {
        (*B).p[IndexToFocus[foci + AsigFoci]] = pObserved[AsigFoci + foci];
    }




//copy both the pvalue to control the FDR or FCDR into the p-value structure
//also nee the pvalue for the trend result so that can be checked to see nothing is being missed
    if (fcdr)
    {
        CP.p[SIGNIFICANT_CONTRAST_P] = CP1.p[SIGNIFICANT_CONTRAST_P];
        CP.fcdr[SIGNIFICANT_CONTRAST_P] = CP1.fcdr[SIGNIFICANT_CONTRAST_P];
    }
    else
    {
        CP.p[SIGNIFICANT_CONTRAST_P] = pfdr;
        CP.p[TREND_CONTRAST_P] = 1.0;
    }


END:
    if (IndexToFocus) free(IndexToFocus);
    if (x) free(x);
    if (y) free(y);
    if (z) free(z);
    if (G_study_perm) free(G_study_perm);
    if (G) free(G);
    if (studies) free(studies);
    if (MA_foci_study) free(MA_foci_study);
    if (Stest) free(Stest);
    if (p) free(p);
    if (pAllSamples) free(pAllSamples);
    if (pObserved) free(pObserved);
    if (SigResults) free(SigResults);
    if (experiments) free(experiments);
    if (comb) free(comb);
    if (SumLn) free(SumLn);
    ReleaseDC(hwnd,hDC);

    return CP;
}


//======================================================================================================
//compute the p values for ALE comparisons given test statistics and MA values
//counts how many permutations are greater than or the same as the test statistic
//======================================================================================================
int GetAllPvaluesByPermutation(HWND hwnd, HDC hDC, float MA[], int nA, int nB, int study[], float T[], double p[],
                               int Ncoordinates, int Ntests, char G[], int Iterations)
{
    int N = nA + nB;
    int i,coordinate;
    int CoordinateXNtests,StudyXNtests,CoordinateXN;
    char *randG=NULL;
    float S,delta,mdelta;
    float A,B;
    int iter;
    int OutputCounter;
    int result=0;
    char txt[256];

    if ( (Iterations<=0) || (nA<=0) || (nB<=0)|| (!(randG = (char *)malloc(N))))
    {
        for (i=0; i<Ntests*Ncoordinates; i++) p[i] = 1.0;//default
        goto END;
    }


    OutputCounter=0;
    memset(p,0,sizeof(double)*Ntests*Ncoordinates);
    iter=0;
    do
    {

        if (OutputCounter>=100)
        {
            sprintf(txt,"Iteration %d of %d       ",iter, Iterations);
            RemoveInput(hwnd);
            TextOut(hDC,100,100,txt,strlen(txt));
            UpdateWindow(hwnd);
            OutputCounter=0;
        }
        OutputCounter++;


        RandomiseExperimentsIntoGroups(randG, N, nA);

        CoordinateXNtests=0;
        CoordinateXN=0;
        for (coordinate=0; coordinate<Ncoordinates; coordinate++)
        {
            //compute the statistic
            A=B=0.0;
            for (i=0; i<N; i++)
            {
                if (randG[i]) A += MA[CoordinateXN + i];
                else B += MA[CoordinateXN + i];

            }

            delta=A - B;
            mdelta=-delta;
            StudyXNtests=study[coordinate]*Ntests;
            for (i=0; i<Ntests; i++)
            {
                if (G[StudyXNtests + i] == 1) S = delta;
                else S = mdelta;

                if ( (S >= T[CoordinateXNtests + i]) ) p[CoordinateXNtests + i] += 1.0;
            }
            CoordinateXNtests += Ntests;
            CoordinateXN+=N;
        }

        iter++;
    }
    while (iter<Iterations);

    for (i=0; i<Ntests*Ncoordinates; i++) p[i] = (p[i] + 1.0)/(Iterations+1);//p values should never be zero

    result=1;
END:

    if (randG) free(randG);

    return result;
}


//======================================================================================================
//compute the p values for ALE comparisons given test statistics and MA values
//Uses the fact that there are few combinations with unique values of the test statistic
//the number of each permutations for each unique value is analytic
//counts how many permutations are greater than or the same as the test statistic
//======================================================================================================
int GetPvalueByPermutation(float MA[], int nA, int nB, float T[], double p[], int Ntests, char G[], int Iterations)
{
    int N = nA + nB;
    int i;
    char *randG=NULL;
    float S,delta,mdelta;
    float A,B;
    int iter;
    int result=0;

    if ( (Iterations<=0) || (nA<=0) || (nB<=0)|| (!(randG = (char *)malloc(N))))
    {
        for (i=0; i<Ntests; i++) p[i] = 1.0;//default
        goto END;
    }

    memset(p,0,sizeof(double)*Ntests);
    iter=0;
    do
    {
        RandomiseExperimentsIntoGroups(randG, N, nA);

        //compute the statistic
        A=B=0.0;
        for (i=0; i<N; i++)
        {
            if (randG[i]) A += MA[i];
            else B += MA[i];
        }

        delta=A - B;
        mdelta=-delta;
        for (i=0; i<Ntests; i++)
        {
            if (G[i] == 1) S = delta;
            else S = mdelta;

            if ( (S >= T[i]) ) p[i] += 1.0;
        }


        iter++;
    }
    while (iter<Iterations);



    for (i=0; i<Ntests; i++) p[i] = (p[i] + 1.0)/(Iterations+1);//p values should never be zero


    result=1;
END:

    if (randG) free(randG);

    return result;
}


//======================================================================================================
//The p values produced by permutation test can be degenerate even if the test statistic is not.
//These can be modified by interpolation
//======================================================================================================
int FixDegeneratePvalues(float T[], double P[], char group[], int N)
{
    int Nfixed=0;
    int i,j,k,q;
    int Ngroup;
    double *pgroup=NULL;
    double *Tgroup=NULL;
    int *sort=NULL;
    int G;
    double dP,dT, dPdT;

    if (!(pgroup=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(Tgroup=(double *)malloc(N*sizeof(double)))) goto END;
    if (!(sort=(int *)malloc(N*sizeof(int)))) goto END;

    for (G=0; G<=1; G++)
    {
        //start with group[i]=G
        Ngroup=0;
        for (i=0; i<N; i++)
        {
            if (group[i]==G)
            {
                pgroup[Ngroup]=P[i];
                Tgroup[Ngroup]=T[i];
                Ngroup++;
            }
        }

        QuickSort(pgroup,sort,Ngroup);

        i=0;
        do
        {
            j=i+1;

            while ( (j<Ngroup) && (pgroup[sort[i]]==pgroup[sort[j]]) ) j++;//degenerate i but not degenerate T

            if (j>(i+1))//some degenerate p-values
            {

                dT = Tgroup[sort[j]] - Tgroup[sort[i]];
                dP = pgroup[sort[j]] - pgroup[sort[i]];

                //fix degeneracy
                if ( (fabs(dT)>0.0) && (fabs(dP)>0.0) )
                {
                    dPdT= dP/dT;
                    for (k=i; k<=j; k++)
                    {
                        pgroup[sort[k]] = pgroup[sort[i]] + dPdT*(Tgroup[sort[k]]-Tgroup[sort[i]]);
                    }
                }



            }

            i=j;
        }
        while (i<Ngroup);

        //put the p values back
        k=0;
        for (q=0; q<N; q++)
        {
            if (group[q]==G)
            {
                P[q] = pgroup[k];
                k++;
            }
        }
    }

END:
    if (pgroup) free(pgroup);
    if (Tgroup) free(Tgroup);
    if (sort) free(sort);

    return Nfixed;
}


//======================================================================================================
//compute the p values for ALE comparisons given test statistics and ALE values
//Uses the fact that there are few combinations with unique values of the test statistic
//the number of each permutations for each unique value is analytic
//counts how many permutations are greater than or the same as the test statistic
//Combinations(N - a - b, nA - ones)=combinations[N*(N - a - b) + nA - ones]
//Combinations(N-1,k)=combinations[N*(N-1) + k]. The combinations[] table is in rows, with the nth row gives combinations of k from n; combinations[N*(n) + k]
//======================================================================================================
#define PERMUTATION_BITS 16
int NumberOfOnes(int I, int bits);
int GetPvalueByCountingPermutations(float MA[], int nA, int nB, float T[], double p[], int Ntests, char G[], double combinations[])
{
    int N = nA + nB;
    int a, b;
    int i;
    int offset;
    int index[PERMUTATION_BITS];
    int ones;
    double ZeroCombinations;
    double sum;
    float A,B;
    float S,delta,mdelta;
    int I, max;




    if ( (nA<=0) || (nB<=0) )
    {
        //default the p-values to 1.0
        for (i=0; i<Ntests; i++) p[i] = 1.0;
        return 0;
    }


    //count the number of non-zero experiments in each group
    a=b=0;
    for (i=0; i<nA; i++)
    {
        if ( (MA[i]>0.0) )
        {
            if (a<PERMUTATION_BITS)
            {
                index[a] = i;
            }
            a++;
        }
    }
    for (i=nA; i<N; i++)
    {
        if ((MA[i]>0.0))
        {
            if (a+b<PERMUTATION_BITS)
            {
                index[a+b] = i;
            }
            b++;
        }
    }

    if ((a+b)>PERMUTATION_BITS) return 0;//can only do PERMUTATION_BITS positive experiments.




    //max = (int)pow(2, a+b);
    max = 2<<(a+b);//we wont try combinations of non-zero experiments beyond this



    sum = 0.0;
    memset(p,0,sizeof(double)*Ntests);
    offset = N*(N - a - b) + nA;
    for (I=0; I<max; I++)//if max is 256 (8 non zero experiments) then need to go to 255, which is 11111111 in binary
    {
        ones = NumberOfOnes(I, a+b);//this will be the number of non zero elements assigned to group A
        if ((ones <= nA) && (a+b-ones <= nB))//this is a valid permutation
        {

            //compute the statistic
            A=B=0.0;
            for (i=0; i<a+b; i++)
            {
                if ((I>>i) & 1) A +=  MA[index[i]];
                else B  += MA[index[i]];
            }

            //how many combinations of the zero experiments are there?
            //ZeroCombinations = Combinations(N - a - b, nA - ones)/MaxCombinations;
            ZeroCombinations = combinations[offset - ones];

            delta=A - B;
            mdelta=-delta;
            for (i=0; i<Ntests; i++)
            {
                if (G[i] == 1) S = delta;
                else S = mdelta;

                if ((S >= T[i])) p[i] += ZeroCombinations;
            }

            sum += ZeroCombinations;
        }
    }

    if (sum>0.0)
    {
        for (i=0; i<Ntests; i++) p[i] /= sum;
    }
    else
    {
        for (i=0; i<Ntests; i++) p[i] = 1.0;
    }


    return 1;
}

//======================================================================================================
int NumberOfOnes(int I, int bits)
{
    int i, Count=I & 1;


    for (i=1; i<bits; i++)
    {
        if ((I>>i)&1) Count++;
    }
    return Count;
}
int TestNumberOfOnes(int n)
{
    int ans=NumberOfOnes(n,16);
    char txt[256];
    sprintf(txt,"%d",ans);
    MessageBox(NULL,txt,"",MB_OK);
    return 1;
}
//====================================================================================================
//TEST THE GetPvalueByPermutation ALGORITHMS
//====================================================================================================
#define N_P_TESTS 10000
int TestGetPvalueByPermutation(int nA, int nB, int nPos)
{

    char group[N_P_TESTS];
    char *G=NULL;
    float *v=NULL;
    double r;
    double p[N_P_TESTS], panalytic[N_P_TESTS];
    float A,B;
    float test[N_P_TESTS];
    int i,j,iterations=10000;
    double maxcomb;
    int offset;
    int nApos,nBpos;
    double *comb=NULL;
    FILE *fp=NULL;


    if (!(comb=(double *)malloc(sizeof(double)*(nA+nB)*(nA+nB)))) goto END;

    maxcomb=0.0;
    offset=0;
    for (i=0; i<nA+nB; i++)
    {
        for (j=0; j<nA+nB; j++)
        {
            comb[offset + j] = Combinations(i, j);
            if (comb[offset + j]>maxcomb) maxcomb = comb[offset + j];
        }
        offset+=nA+nB;
    }
    if (maxcomb<=0.0) goto END;
    for (i=0; i<(nA+nB)*(nA+nB); i++) comb[i] /= maxcomb;


    if (!(G=(char *)malloc(nA+nB))) goto END;
    if (!(v=(float *)malloc(sizeof(float)*(nA+nB)))) goto END;

    memset(v,0,sizeof(float)*(nA+nB));
    for (i=0; i<nPos; i++)
    {
        r=GaussRandomNumber_BoxMuller(0.0, 1.0);
        v[i]=exp(-r*r/2.0/3.1415926)/sqrt(2.0*3.1415926);
        //v[i]=0.8;
    }


    memset(G,0,nA+nB);
    for (i=0; i<nA; i++) G[i]=1;



    for (j=0; j<N_P_TESTS; j++)
    {

        RandomiseExperimentsIntoGroups(G, nA + nB, nA);//this indicates which are to be in group A

        nApos=nBpos=0;
        for (i=0; i<(nA+nB); i++)
        {
            if (G[i] && (v[i]>0.0)) nApos++;
            else if ( (!G[i] ) && (v[i]>0.0)) nBpos++;
        }


        A=B=0.0;
        for (i=0; i<nA+nB; i++)
        {
            if (G[i]) A += v[i];
            else B += v[i];
        }
        test[j] = A - B;

        group[j]=1;

    }

    GetPvalueByCountingPermutations(v, nA, nB, test, panalytic, N_P_TESTS, group, comb);


    GetPvalueByPermutation(v,  nA, nB, test, p, N_P_TESTS,  group, iterations);
    //FixDegeneratePvalues(test, p, group, N_P_TESTS);


    if ((fp=fopen("c:\\temp\\permtest.txt","w")))
    {
        fprintf(fp,"test analytic permutation error\n");
        for (j=0; j<N_P_TESTS; j++)
        {
            fprintf(fp,"%f %f %f %f\n",test[j],panalytic[j], p[j], sqrt((panalytic[j]-p[j])*(panalytic[j]-p[j])));
        }

        fclose(fp);
    }





END:
    if (G) free(G);
    if (v) free(v);
    if (comb) free(comb);

    return 1;
}





//======================================================================================================
//GENERATE A RANDOMISATION OF N EXPERIMENTS INTO TWO GROUPS, WITH n IN THE FIRST GROUP
//ON EXIT, G[] WILL BE 1 TO INDICATE THE FIRST GROUP, AND 0 OTHERWISE
//THERE WILL BE n ELEMENTS OF G[] THAT ARE 1
//********CHANGED 27 MARCH 2015***********
//WILL MAKE G[] = 1 IN n SLOTS IF N<N/2
//WILL MAGE G[] = 0 IN (N-n) ELEMENTS OTHERWISE
//======================================================================================================
int RandomiseExperimentsIntoGroups(char G[], int N, int n)
{
    int r,k;

    if (n<=N/2)
    {
        memset(G,0,N);
        while(n)
        {
            r = rand()%N;
            if (!G[r])
            {
                G[r] = 1;
                n--;
            }
        }
    }
    else
    {
        memset(G,1,N);
        k=0;
        while(k<(N-n))
        {
            r = rand()%N;
            if (G[r])
            {
                G[r] = 0;
                k++;
            }
        }

    }




    return 1;
}
//======================================================================================================
//outputs a cdf of the number of positives drawn, given the number of positives, and number of samples per group
//should follow a hypergeometric distribution
int TestRandomiseExperimentsIntoGroups(int nA, int nB, int pos)
{
    int *vals=NULL;//the values, which will be either zero, or non-zero
    char *G=NULL;//the grouping vector; G[i]=1 for group A, and 0 for group B
    int Niterations=100000;
    int iter;
    int i;
    int positivecount;
    double *cdf=NULL;
    FILE *fp;

    if (!(vals=(int *)calloc(nA+nB, sizeof(int)))) goto END;
    if (!(G=(char *)malloc(nA+nB))) goto END;
    if (!(cdf=(double *)calloc(pos+1, sizeof(double)))) goto END;

    for (i=0; i<pos; i++) vals[i]=1;

    if ((fp=fopen("c:\\temp\\randomisation.csv","w")))
    {
        for (iter=0; iter<Niterations; iter++)
        {
            RandomiseExperimentsIntoGroups(G, nA+nB, nA);
            positivecount=0;
            for (i=0; i<(nA+nB); i++)
            {
                if (G[i] && vals[i]) positivecount++;
            }
            cdf[positivecount]++;
        }
        for (i=1; i<=pos; i++) cdf[i]+=cdf[i-1];
        if (cdf[pos]>0.0)
        {
            for (i=0; i<pos; i++) cdf[i]/=cdf[pos];
        }
        cdf[pos]=1.0;

        for (i=0; i<=pos; i++)  fprintf(fp,"%d,%f\n",i,cdf[i]);

        fclose(fp);
    }


END:
    if (G) free(G);
    if (cdf) free(cdf);
    if (vals) free(vals);

    return 1;
}



//======================================================================================================
//creates a union of all experiments in *ale
//======================================================================================================
int CombineExperimentsIntoALEimage(struct Coordinates *ale, float *aleimg, int X, int Y, int Z,
                                   float dx, float dy, float dz, float x0, float y0, float z0, float sigma,
                                   int UseClusters, double critical, double MinALE)
{

    float *tmp=NULL;
    int voxel,voxels=X*Y*Z;
    int experiment;
    int result=0;

    memset(aleimg,0,sizeof(float)*voxels);
    if (!(*ale).TotalFoci) goto END;

    if (!(tmp=(float *)malloc(voxels*sizeof(float)))) goto END;
    for (voxel=0; voxel<voxels; voxel++)
    {
        aleimg[voxel]=1.0;
    }
    for (experiment=0; experiment<(*ale).Nexperiments; experiment++)
    {
        CreateExperimentMAmapALE(X, Y, Z, dx, dy, dz, x0, y0, z0, ale, experiment, tmp, sigma, UseClusters, critical);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (tmp[voxel]>0.0) aleimg[voxel]*=(1.0-tmp[voxel]);
        }
    }
    for (voxel=0; voxel<voxels; voxel++) aleimg[voxel]=1.0-aleimg[voxel];
    for (voxel=0; voxel<voxels; voxel++)
    {
        if (aleimg[voxel]<MinALE) aleimg[voxel] = 0.0;
    }

    result=1;
END:
    if (tmp) free(tmp);
    return result;
}

//======================================================================================================
//Uses only foci with p <= critical
//create MA map for given experiment
//The MA is the maximum of ALE from all foci in the experiment
//======================================================================================================
int CreateExperimentMAmapALE(int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                             struct Coordinates *ale, int experiment, float MA[], float sigma, int UseClusters, double critical)
{

    int x, y, z;
    int xi,yi,zi;
    int delx, dely, delz;
    int voxel,voxels=X*Y*Z;
    int foci;
    int zXY, yX;
    float xf, yf, zf;
    double py,pz;
    double ma;
    double r2;
    double maxr2=NSIGMA95*NSIGMA95;
    double norm;
    double a;


    memset(MA,0,voxels*sizeof(float));

    if (sigma<=0.0) return 0;

//need to compute norm from sigma
    norm=NormALE(sigma, dx, dy, dz);

    a=1.0/2.0/sigma/sigma;//saves repeat computation

    delx=NSIGMA95*sqrt(2.0)*sigma/dx+1;
    dely=NSIGMA95*sqrt(2.0)*sigma/dy+1;
    delz=NSIGMA95*sqrt(2.0)*sigma/dz+1;

    for (foci=0; foci<(*ale).TotalFoci; foci++)
    {

        xi=((*ale).x[foci]+x0)/dx;
        yi=((*ale).y[foci]+y0)/dy;
        zi=((*ale).z[foci]+z0)/dz;
        if ((experiment==(*ale).experiment[foci]) && (((*ale).p[foci]<=critical) || (UseClusters && (*ale).cluster[foci])))
        {

            for (z=0; z<Z; z++)
            {
                if ((zi<z+delz) && (zi>z-delz))
                {
                    zXY = z*X*Y;
                    zf = (*ale).z[foci] - (dz*z-z0);
                    pz = zf*zf;

                    for (y=0; y<Y; y++)
                    {
                        if ((yi<y+dely) && (yi>y-dely))
                        {
                            yX = y*X;
                            yf = (*ale).y[foci] - (dy*y-y0);
                            py = yf*yf;

                            for (x=0; x<X; x++)
                            {
                                if ((xi<x+delx) && (xi>x-delx))
                                {
                                    voxel=x + yX + zXY;
                                    xf = (*ale).x[foci] - (dx*x-x0);
                                    r2 = (xf*xf + py + pz)*a;

                                    if (2*r2 <= maxr2) ma=exp(-r2)*norm;//include 95% of the mass of the foci model
                                    else ma=0.0;

                                    if (ma > MA[voxel]) MA[voxel] = ma;//the weighted MA
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return 1;
}





//======================================================================================================
//get a random part of a single voxel
//this is because finding random voxels using RandomImageVoxel
//gives an answer to the nearest voxel centre.
//That makes the results depend on the voxel dimensions
//This allows sub voxel resolution
//======================================================================================================
int RandomPointInVoxel(float *dx, float *dy, float *dz)
{
    (*dx)=(float)rand()/RAND_MAX-0.5;
    (*dy)=(float)rand()/RAND_MAX-0.5;
    (*dz)=(float)rand()/RAND_MAX-0.5;

    return 1;
}
int TestRandomPointInVoxel(void)
{
    int i;
    float x,y,z;
    FILE *fp;
    char fname[MAX_PATH];

    sprintf(fname,"%s\\randominvoxel.txt",REPORT_FOLDER);
    if ((fp=fopen(fname,"w")))
    {
      for(i=0;i<1000;i++)
      {
          RandomPointInVoxel(&x,&y,&z);
          fprintf(fp,"%f %f %f\n",x,y,z);
      }
      fclose(fp);
    }


    return 1;
}

//======================================================================================================
//compute the voxel from the foci
//======================================================================================================
int FociVoxelALE(float x, float y, float z, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0)
{

    int voxel;
    int xi,yi,zi;
    //char txt[256];

    xi=(x+x0)/dx+0.5;
    yi=(y+y0)/dy+0.5;//nearest integer
    zi=(z+z0)/dz+0.5;

    voxel=xi+yi*X+zi*X*Y;
    if ((voxel<X*Y*Z) && (voxel>=0)) return voxel;
    else return 0;
}

//======================================================================================================
//          flip to left handed coordinate
//======================================================================================================
int RLflip(float *image, int X, int Y, int Z)
{
    int x,y,z;
    float *tmp=NULL;

    if (!(tmp=(float *)malloc(X*sizeof(float)))) return 0;

    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            memcpy(tmp, &image[y*X+z*X*Y], X*sizeof(float));
            for (x=0; x<X; x++)
            {
                image[x+y*X+z*X*Y]=tmp[X-1-x];
            }
        }
    }
    if (tmp) free(tmp);
    return 1;
}

//======================================================================================================
//      Returns the number of sigma to get a percentile of the mass of the Gauss function
//Trivariate Gauss function=1/( pow(2PI,3/2)*pow(sigma,3) )*exp(-r^2/2/sigma^2)
//======================================================================================================
double Nsigma(double percentile, double sigma)
{
    double r,dr;
    double area;
    double target;
    double I1,I2;
    char txt[256];

    target=percentile*sqrt(2.0*PI)*sigma*sigma*sigma/2.0;//percentile of the mass of the Gaussian

    r=0.0;
    dr=0.0001;
    area=0.0;
    while ((area<target) && (r<100.0*sigma))//do the integration until we reach the target
    {
        I1=r*r*exp(-r*r/2.0/sigma/sigma);
        I2=(r+dr)*(r+dr)*exp(-(r+dr)*(r+dr)/2.0/sigma/sigma);
        area+=dr*(I1+I2)/2.0;
        r+=dr;
    }

    sprintf(txt,"%f",r/sigma);
    MessageBox(NULL,txt,"",MB_OK);

    return r/sigma;

}


//======================================================================================================
double NormALE(double sigma, float dx, float dy, float dz)
{
    return 1.0/pow(2.0*3.1415926*sigma*sigma, 3.0/2)*dx*dy*dz;
}







//======================================================================================================
/*
struct Clusters{
  int TotalClusters;
  int *Nclusters;//number of clusters in experiment j = Nclusters[j]
  short int *experiment;//the experiment this cluster belongs to
  float *x;
  float *y;//coordintates of the cluster centres
  float *z;
  float *S;//spread of cluster j = S[j]
  float *MeanDist;//mean distance of foci from the centre
  int *Nfoci;//number of foci in cluster j = Nfoci[j]
};
};*/
//======================================================================================================
int FreeCluster(struct Clusters *clust)
{
    if ((*clust).x) free((*clust).x);
    if ((*clust).y) free((*clust).y);
    if ((*clust).z) free((*clust).z);
    if ((*clust).S) free((*clust).S);
    if ((*clust).MeanDist) free((*clust).MeanDist);
    if ((*clust).Nclusters) free((*clust).Nclusters);
    if ((*clust).Nfoci) free((*clust).Nfoci);
    if ((*clust).experiment) free((*clust).experiment);
    memset(clust,0,sizeof(struct Clusters));
    return 0;
}




//================================================================================================
//================================================================================================
//================================================================================================
//Randomise the coordintates within the ALE structure
//Randomise only within a mask
//================================================================================================
//================================================================================================
//================================================================================================
int RandomiseFociInexperiment(float *mask, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, struct Coordinates *ale, int experiment)
{
    int i, voxel;
    int ix, iy, iz;
    int voxels=X*Y*Z;

    for (i=0; i<(*ale).TotalFoci; i++)
    {
        if ((*ale).experiment[i] == experiment)
        {
            voxel=RandomImageVoxel(mask, voxels);

            XYZfromVoxelNumber( voxel, &ix, &iy, &iz, X, Y, Z );

            (*ale).x[i]            =dx*ix-x0;
            (*ale).y[i]            =dy*iy-y0;
            (*ale).z[i]            =dz*iz-z0;
            (*ale).voxel[i]        =voxel;
        }
    }
    return 1;
}


//======================================================================================================
//======================================================================================================
//======================================================================================================
//randomise the ALE using random effects model
//clusters within experiments are stored in the Clusters structure
//======================================================================================================
//======================================================================================================
//======================================================================================================
int InvalidRandomisation(struct Clusters *cl, int experiment, float sigma, char Randomised[]);
int RandomiseFociRandomEffects(float *mask,
                               int X, int Y, int Z,
                               float dx, float dy, float dz,
                               float x0, float y0, float z0,
                               struct Coordinates *ale, struct Clusters *cl, float sigma)
{
    int cluster;
    int foci;
    int aleindex=0;
    int voxels = X*Y*Z;
    int voxel;
    int ix,iy,iz;
    int experiment, experiments;
    int result=0;
    int GetOut;
    int *VoxelList=NULL;
    float delx,dely,delz;
    struct ThreeVector V;
    char *Randomised=NULL;

    V.x=x0;
    V.y=y0;
    V.z=z0;


    if (!(Randomised = (char *)malloc((*cl).TotalClusters))) goto END;
    if (!(VoxelList = (int *)malloc((*cl).TotalClusters*sizeof(int)))) goto END;


    //how many experiments are there?
    experiments=(*ale).Nexperiments;


    for (experiment=0; experiment<experiments; experiment++)
    {
        memset(Randomised,0,(*cl).TotalClusters);
        GetOut=0;
        do
        {
            GetOut++;
            for (cluster=0; cluster<(*cl).TotalClusters; cluster++)
            {
                if (((*cl).experiment[cluster] == experiment) && (!Randomised[cluster]))
                {
                    voxel = RandomImageVoxel(mask, voxels);
                    XYZfromVoxelNumber( voxel, &ix, &iy, &iz, X, Y, Z );

                    ///ADDED 22/05/2018
                    ///Instead of having voxel resolution, the random coordinates
                    ///now have sub voxel resolution
                    RandomPointInVoxel(&delx, &dely, &delz);

                    (*cl).x[cluster]            = dx*(delx+ix);
                    (*cl).y[cluster]            = dy*(dely+iy);
                    (*cl).z[cluster]            = dz*(delz+iz);
                    VoxelList[cluster]=voxel;
                    Randomised[cluster]         = 1;
                }
            }
        }
        while(InvalidRandomisation(cl, experiment, sigma, Randomised) && (GetOut<100));


        if (GetOut>=100)
        {
            for (cluster=0; cluster<(*cl).TotalClusters; cluster++)
            {
                if (((*cl).experiment[cluster] == experiment) && (!Randomised[cluster]))
                {
                    voxel = RandomImageVoxel(mask, voxels);
                    XYZfromVoxelNumber( voxel, &ix, &iy, &iz, X, Y, Z );

                    (*cl).x[cluster]            = dx*ix;
                    (*cl).y[cluster]            = dy*iy;
                    (*cl).z[cluster]            = dz*iz;
                    VoxelList[cluster]=voxel;
                    Randomised[cluster]         = 1;
                }
            }
        }

    }




//randomise the within study clusters of foci
    for (cluster=0; cluster<(*cl).TotalClusters; cluster++)
    {

        //FOR A CLUSTER OF SIZE 1 ITS JUST A RANDOM VOXEL
        if ((*cl).Nfoci[cluster] == 1)
        {
            (*ale).x[aleindex] = (*cl).x[cluster]-x0;
            (*ale).y[aleindex] = (*cl).y[cluster]-y0;
            (*ale).z[aleindex] = (*cl).z[cluster]-z0;
            //(*ale).voxel[aleindex] = FociVoxelALE((*ale).x[aleindex], (*ale).y[aleindex], (*ale).z[aleindex] , X, Y, Z, dx, dy, dz, x0, y0, z0);
            (*ale).voxel[aleindex] = VoxelList[cluster];
            aleindex++;
        }
        else//FOR MULTIPLE FOCI PER CLUSTER
        {
            for (foci=0; foci<(*cl).Nfoci[cluster]; foci++)
            {
                V = GetRandomFociRandomEffects(mask, X, Y, Z, dx, dy, dz,
                                               (*cl).x[cluster], (*cl).y[cluster], (*cl).z[cluster],
                                               (*cl).MeanDist[cluster], (*cl).S[cluster], &voxel);

                (*ale).x[aleindex] = V.x - x0;
                (*ale).y[aleindex] = V.y - y0;
                (*ale).z[aleindex] = V.z - z0;
                (*ale).voxel[aleindex] = voxel;
                aleindex++;
            }
        }

    }

    result=1;
END:
    if (Randomised) free(Randomised);
    if (VoxelList) free(VoxelList);
    return result;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================
//Check is the randomisation is valid
//it is valid if the within-experiment clusters dont overlap
//======================================================================================================
//======================================================================================================
//======================================================================================================
int InvalidRandomisation(struct Clusters *cl, int experiment, float sigma, char Randomised[])
{
    int i,j;
    int Count=0;
    float MinDist,NSIGMAsigma=NSIGMA95*sigma;
    float dist, tmp;

    for (i=0; i<(*cl).TotalClusters; i++)//FOR ALL THE CLUSTERS
    {
        if ( ((*cl).experiment[i] == experiment) && (Randomised[i]) )//IN THIS EXPERIMENT AND THAT HAVE BEEN RANDOMISED
        {
            for (j=i+1; j<(*cl).TotalClusters; j++)
            {
                if ( ((*cl).experiment[j] == experiment) && (Randomised[j]) )//IS IT TOO CLOSE TO THE OTHER RANDOMISED CLUSTERS IN THIS EXPERIMENT
                {
                    MinDist = (*cl).MeanDist[i] + (*cl).MeanDist[j] +
                              ((*cl).S[i] + (*cl).S[j]);

                    if (MinDist < (tmp=NSIGMAsigma)) MinDist = tmp;

                    MinDist *= MinDist;//ITS A SQUARED DISTANCE, SO DONT USE sqrt():-

                    tmp = (*cl).x[i] - (*cl).x[j];
                    dist = tmp*tmp;
                    if (dist < MinDist)
                    {
                        tmp = (*cl).y[i] - (*cl).y[j];
                        dist += tmp*tmp;
                        if (dist < MinDist)
                        {
                            tmp = (*cl).z[i] - (*cl).z[j];
                            dist += tmp*tmp;
                            if (dist < MinDist)//THEY OVERLAP, SO UNRANDOMISE THEM; THEY WILL BE RE-RANDOMISED
                            {
                                Randomised[i] = 0;
                                Randomised[j] = 0;
                                Count++;
                            }
                        }
                    }
                }
            }
        }
    }
    return Count;
}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//fill the cluster structure for the ale
/*
struct Clusters{
  int TotalClusters;
  int *Nclusters;//number of clusters in experiment j = Nclusters[j]
  short int *experiment;//the experiment this cluster belongs to
  float *x;
  float *y;//coordintates of the cluster centres
  float *z;
  float *S;//spread of cluster j = S[j]
  float *MeanDist;//mean distance of foci from the centre
  int *Nfoci;//number of foci in cluster j = Nfoci[j]
};
*/
//======================================================================================================
//======================================================================================================
//======================================================================================================
int GetWithinExperimentClusters(float x[], float y[], float z[], short int experiment[], int iexperiment, int cluster[], int N, float sigma);
int FillClusterStructure(struct Coordinates *ale, struct Clusters *cl, float sigma)
{
    int TotalFoci=(*ale).TotalFoci;
    int foci;
    int iexp;
    int Count;
    int c;
    int index=0;
    int *cluster = NULL;
    double dist;
    double sum,sum2;
    //char txt[256];

    (*cl).TotalClusters=0;
    if (!((*cl).Nclusters = (int *)malloc((*ale).Nexperiments*sizeof(int)))) goto END;
    if (!((*cl).S = (float *)malloc(TotalFoci*sizeof(float)))) goto END;
    memset((*cl).S,0,TotalFoci*sizeof(float));
    if (!((*cl).MeanDist = (float *)malloc(TotalFoci*sizeof(float)))) goto END;
    memset((*cl).MeanDist,0,TotalFoci*sizeof(float));
    if (!((*cl).x = (float *)malloc(TotalFoci*sizeof(float)))) goto END;
    memset((*cl).x,0,TotalFoci*sizeof(float));
    if (!((*cl).y = (float *)malloc(TotalFoci*sizeof(float)))) goto END;
    memset((*cl).y,0,TotalFoci*sizeof(float));
    if (!((*cl).z = (float *)malloc(TotalFoci*sizeof(float)))) goto END;
    memset((*cl).z,0,TotalFoci*sizeof(float));
    if (!((*cl).experiment = (short int *)malloc(sizeof(short int)*TotalFoci))) goto END;
    if (!((*cl).Nfoci = (int *)malloc(sizeof(int)*TotalFoci))) goto END;
    if (!(cluster = (int *)malloc(TotalFoci*sizeof(int)))) goto END;
    memset(cluster,0,TotalFoci*sizeof(int));


//get the clusters for each experiment
///ADDED (index<TotalFoci) TO FOR LOOP CONDITION
///OTHERWISE CAN INDEX OVER END OF ARRAY IF THE FINAL EXPERIMENTS HAVE NO COORDINATES
    for (iexp=0; iexp<(*ale).Nexperiments && (index<TotalFoci); iexp++)
    {
        (*cl).Nclusters[iexp] = GetWithinExperimentClusters((*ale).x, (*ale).y, (*ale).z,
                                (*ale).experiment, iexp, cluster,
                                TotalFoci, sigma);


        (*cl).TotalClusters += (*cl).Nclusters[iexp];

//sprintf(txt,"%d %d",iexp,(*cl).Nclusters[iexp]);
//MessageBox(NULL,txt,"",MB_OK);

        (*cl).S[index]=(*cl).x[index]=(*cl).y[index]=(*cl).z[index]=0.0;

        for (c=1; c<=(*cl).Nclusters[iexp]; c++)
        {

            Count=0;
            for (foci=0; foci<TotalFoci; foci++)
            {
                if (((*ale).experiment[foci]==iexp) && (cluster[foci]==c))
                {
                    (*cl).x[index] += (*ale).x[foci];
                    (*cl).y[index] += (*ale).y[foci];
                    (*cl).z[index] += (*ale).z[foci];
                    Count++;
                }
            }
            if (Count)
            {
                (*cl).x[index]/=Count;
                (*cl).y[index]/=Count;
                (*cl).z[index]/=Count;

                (*cl).Nfoci[index] = Count;

                sum=sum2=0.0;
                for (foci=0; foci<TotalFoci; foci++)
                {
                    if (((*ale).experiment[foci]==iexp) && (cluster[foci]==c))
                    {

                        dist = sqrt(((*cl).x[index] - (*ale).x[foci])*((*cl).x[index] - (*ale).x[foci]) +
                                    ((*cl).y[index] - (*ale).y[foci])*((*cl).y[index] - (*ale).y[foci]) +
                                    ((*cl).z[index] - (*ale).z[foci])*((*cl).z[index] - (*ale).z[foci]));


                        sum+=dist;
                        sum2+=dist*dist;
                    }
                }
                if ((sum2/Count - sum*sum/Count/Count)>0.0) (*cl).S[index] = sqrt(sum2/Count - sum*sum/Count/Count);
                (*cl).MeanDist[index] = sum/Count;
                (*cl).experiment[index] = iexp;
                index++;
            }
        }
    }

    if (cluster) free(cluster);
    return 1;


END:
    FreeCluster(cl);
    if (cluster) free(cluster);

    return 0;
}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//Test FillClusterStructure
//======================================================================================================
//======================================================================================================
//======================================================================================================
int TestFillClusterStrucure(struct Image *image)
{
    struct Coordinates ale;
    struct Clusters clust;
    int i;
    FILE *fp;

    memset(&ale,0,sizeof(struct Coordinates));
    memset(&clust,0,sizeof(struct Clusters));

    LoadExperimentsCOORDINATES(NULL, &ale, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                               (*image).x0, (*image).y0, (*image).z0);


    FillClusterStructure(&ale, &clust, 6.5);

    fp=fopen("c:\\temp\\cluster.csv","w");
    for (i=0; i<clust.TotalClusters; i++)
    {
        if (fp) fprintf(fp,"%d,%d,%d,%d,%f,%f,%f,%f,%f\n",i,clust.experiment[i],clust.Nclusters[clust.experiment[i]],
                            clust.Nfoci[i],clust.x[i],clust.y[i],clust.z[i],clust.S[i],clust.MeanDist[i]);
    }


    if (fp) fclose(fp);


    FreeCoordinates(&ale);
    FreeCluster(&clust);

    return 1;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================
//Test the randomisation to make sure there is no bias
//just randomises an ALE file using RandomiseFociRandomEffects()
//then counts where the foci land in image.
//the result should be a smooth image with enough iterations
//======================================================================================================
//======================================================================================================
//======================================================================================================
int TestRandomEffectRandomisationScheme(HWND hwnd, struct Image *image)
{

    struct Clusters cl;
    struct Coordinates ale;
    float *counter=NULL;
    float max;
    double sigma, fwhm;
    int iter;
    int foci;

    memset(&cl,0,sizeof(struct Clusters));
    memset(&ale,0,sizeof(struct Coordinates));

    counter=(float *)malloc((*image).X*(*image).Y*(*image).Z*sizeof(float));

    LoadExperimentsCOORDINATES(hwnd, &ale, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                               (*image).x0, (*image).y0, (*image).z0);

    fwhm=FWHM_ALE(ale.Nexperiments);
    sigma=SD_ALE(fwhm);

    FillClusterStructure(&ale, &cl, sigma);
    memset(counter,0,(*image).X*(*image).Y*(*image).Z*sizeof(float));
    max=0.0;
    for (iter=0; iter<1000000; iter++)
    {
        RandomiseFociRandomEffects((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0,
                                  &ale, &cl, sigma);

        for (foci=0; foci<ale.TotalFoci; foci++)
        {
            counter[ale.voxel[foci]]+=1.0;
            if (counter[ale.voxel[foci]]>max) max=counter[ale.voxel[foci]];
        }

    }


    memcpy((*image).img, counter, (*image).X*(*image).Y*(*image).Z*sizeof(float));
    (*image).MaxIntensity=max;

    if (counter) free(counter);
    FreeCoordinates(&ale);
    FreeCluster(&cl);

    return 1;
}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//Test the distribution of ALE under permutation of voxels V the permutation of foci
//======================================================================================================
//======================================================================================================
//======================================================================================================
#define TEST_ALE_BINS 100
int TestPermutations(struct Image *image)
{
    struct Coordinates ale;
    struct Clusters clust;
    int i, voxel;
    int experiment;
    int bin;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    int voxel_count;
    double sigma=SD_ALE(10.0);
    double MaxALE;
    double a;
    double Hf[TEST_ALE_BINS];
    double Hv[TEST_ALE_BINS];
    float *MA=NULL;
    FILE *fp;

    memset(&ale,0,sizeof(struct Coordinates));
    memset(&clust,0,sizeof(struct Clusters));



    LoadExperimentsCOORDINATES(NULL, &ale, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                               (*image).x0, (*image).y0, (*image).z0);

    FillClusterStructure(&ale, &clust, sigma);

    MaxALE = MaxPossibleALE(&ale, (*image).dx, (*image).dy, (*image).dz, sigma);


    MA=(float *)malloc(sizeof(float)*voxels*(ale.Nexperiments));
    if (!MA) MessageBox(NULL,"help","",MB_OK);

    for (experiment=0; experiment<ale.Nexperiments; experiment++)
    {
        CreateExperimentMAmapALE((*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                 (*image).x0, (*image).y0, (*image).z0,
                                 &ale, experiment, &MA[experiment*voxels], sigma, 0, 1.0);
    }

    //voxel permutation test
    memset(Hv,0,sizeof(double)*TEST_ALE_BINS);
    for (i=0; i<1000000; i++)
    {
        a=1.0;
        for (experiment=0; experiment<ale.Nexperiments; experiment++)
        {
            voxel = RandomImageVoxel((*image).img, voxels);
            a *= (1.0 - MA[experiment*voxels + voxel]);
        }
        a = 1.0-a;
        bin = TEST_ALE_BINS*(a/MaxALE);
        if (bin<TEST_ALE_BINS)
        {
            Hv[bin]+=1.0/1000000;
        }
    }


    //now do the foci permutation test
    memset(Hf,0,sizeof(double)*TEST_ALE_BINS);

    voxel_count=0;
    for (voxel=0; voxel<voxels; voxel++) if (fabs((*image).img[voxel])>0.0) voxel_count++;
    for (i=0; i<300; i++)
    {
        RandomiseFociRandomEffects((*image).img, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                  (*image).x0, (*image).y0, (*image).z0,
                                  &ale, &clust, sigma);

        CombineExperimentsIntoALEimage(&ale, MA, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
                                       (*image).x0, (*image).y0, (*image).z0, sigma, 0, 1.0, 0.0);

        for (voxel=0; voxel<voxels; voxel++)
        {
            if ((*image).img[voxel]>0.0)
            {
                bin = TEST_ALE_BINS*(MA[voxel]/MaxALE);
                if (bin<TEST_ALE_BINS)
                {
                    Hf[bin]+=1.0/voxel_count/300;
                }
            }
        }
    }


    fp=fopen("c://temp//ALEhist.csv","w");
    for (i=0; i<TEST_ALE_BINS; i++)
    {
        fprintf(fp,"%f,%f,%f\n",i*MaxALE/TEST_ALE_BINS,Hv[i],Hf[i]);
    }
    fclose(fp);

    if (MA) free(MA);
    FreeCoordinates(&ale);
    FreeCluster(&clust);

    return 1;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================
//Count the number of clusters
//a cluster foci that overlap others within the same cluster
//a foci is part of a cluster if it overlaps another foci within the cluster
//the cluster number (>=1) that a significant foci belongs to is recorded in cluster[]
//======================================================================================================
//======================================================================================================
//======================================================================================================
int GetWithinExperimentClusters(float x[], float y[], float z[], short int experiment[], int iexperiment,
                                int cluster[], int N, float sigma)
{


    int foci, i;
    int StartFoci;
    int Clusters=0;
    int count, added;
    double dist, minsquaredist=NSIGMA95*NSIGMA95*sigma*sigma;
    //char txt[256];

    memset(cluster,0,sizeof(int)*N);


    do
    {
        count=0;
        StartFoci = N;
        for (foci=0; foci<N && (StartFoci==N); foci++)
        {
            if ((cluster[foci] == 0) && (experiment[foci]==iexperiment))  StartFoci = foci;
        }

//sprintf(txt,"%d %d %d",iexperiment,StartFoci,N);
//MessageBox(NULL,txt,"",MB_OK);

        if (StartFoci<N)
        {
            //we have a starting foci from which we will grow a cluster
            count++;
            Clusters++;
            cluster[StartFoci] = Clusters;
            do
            {
                added=0;
                for (foci=0; foci<N; foci++)
                {
                    if (cluster[foci]==Clusters)
                    {
                        for (i=0; i<N; i++)
                        {
                            //add foci to clusters
                            if ((experiment[i] == iexperiment) && (!cluster[i]))//IF IN THIS EXPERIMENT BUT NOT IN A CLUSTER
                            {
                                dist = (x[foci] - x[i])*(x[foci] - x[i]) + (y[foci] - y[i])*(y[foci] - y[i]) + (z[foci] - z[i])*(z[foci] - z[i]);

                                if (dist < (minsquaredist))
                                {
                                    cluster[i] = Clusters;
                                    added++;
                                }
                            }
                        }
                    }

                }
                count += added;
            }
            while (added);
        }
    }
    while (count);
//sprintf(txt,"%d",Clusters);
//MessageBox(NULL,txt,"",MB_OK);

    return Clusters;
}

//======================================================================================================
//======================================================================================================
//======================================================================================================
//get a random location for a foci given a centre point, a mean distance to the centre,
//and a variance on that distance
//used for the random effect model
//======================================================================================================
//======================================================================================================
//======================================================================================================
struct ThreeVector GetRandomFociRandomEffects(float *mask, int X, int Y, int Z, float dx, float dy, float dz,
        float xc, float yc, float zc, float MeanDist, float sd, int *vox)
{
    static struct ThreeVector V[1024];
    static float stdnorm[1024];
    static int First=1;
    struct ThreeVector result;
    //static int entry;
    int voxels=X*Y*Z;
    int XY=X*Y;
    int i;
    int dir,dist;
    int voxel;
    int x,y,z;
    int count;
    double scale;
    //char txt[256];



//get many random directions and normal distribution samples
    if (First)
    {
        i = GoldenRatioVectors(V, 1024);

        for (i=0; i<1024; i++)
        {
            do
            {
                stdnorm[i] = GaussRandomNumber_BoxMuller(0.0, 1.0);
            }
            while(fabs(stdnorm[i])>2.0);

        }
        First = 0;//wont compute again
    }
//-----------------------------------------------------------


    count=0;
    do
    {
        if (sd>0.0)
        {

            do
            {
                dist = rand()%1024;

                scale = MeanDist + sd*stdnorm[dist];
            }
            while ((scale<=0.0));

        }
        else scale = MeanDist;

        dir = rand()%1024;

        result.x = scale*V[dir].x + xc;
        result.y = scale*V[dir].y + yc;
        result.z = scale*V[dir].z + zc;

        x = (int)((result.x)/dx + 0.5);
        y = (int)((result.y)/dy + 0.5);//nearest voxel
        z = (int)((result.z)/dz + 0.5);
        count++;

    }
    while((count<5) && (((x<0) || (x>=X) || (y<0) || (y>=Y) || (z<0) || (z>=Z)) || (mask[(voxel=x + y*X + z*XY)]<=0.0)));


    if (count>=5)
    {
        /*fails++;
        if (fails>1000)
        {
        sprintf(txt,"%f",(float)fails/entry);
        MessageBox(NULL,txt,"",MB_OK);
        fails=entry=0;
        }*/


        voxel = RandomImageVoxel(mask, voxels);
        XYZfromVoxelNumber( voxel, &x, &y, &z, X, Y, Z );

        result.x = dx*x;
        result.y = dy*y;
        result.z = dz*z;

        *vox = voxel;
    }

    *vox = voxel;

    return result;//return the foci
}

//======================================================================================================
//======================================================================================================

//======================================================================================================
//======================================================================================================
//======================================================================================================
//find the clusters from the activations that contribute are significant
//return the number of such clusters
//======================================================================================================
//======================================================================================================
//======================================================================================================
int GetClusterNumberImage(struct Coordinates *sig,int clusters, float ClustALE[], float ClustNum[],
                          float dx, float dy, float dz,
                          float x0, float y0, float z0, int X, int Y, int Z, float sigma, double critical)
{

    int Nclusters=0;
    int cluster,cl;
    int voxel, voxels=X*Y*Z;
    int foci;
    int *sort = NULL;
    float *SingleClust = NULL;
    float *MaxALE = NULL;
    double *Nfoci = NULL;
    struct Coordinates ALEcpy;


    if (!(SingleClust = (float *)malloc(voxels*sizeof(float)))) goto END;
    if (!(MaxALE = (float *)malloc(voxels*sizeof(float)))) goto END;
    if (!(Nfoci = (double *)malloc(sizeof(double)*clusters))) goto END;
    if (!(sort = (int *)malloc(sizeof(int)*clusters))) goto END;

    memset(Nfoci, 0, sizeof(double)*clusters);
    for (foci=0; foci<(*sig).TotalFoci; foci++)
    {
        if ((*sig).cluster[foci]) Nfoci[(*sig).cluster[foci]-1] += 1.0;
    }
    QuickSort(Nfoci, sort, clusters);

    memset(&ALEcpy, 0, sizeof(struct Coordinates));
    memset(ClustNum,0,voxels*sizeof(float));
    memset(MaxALE,0,voxels*sizeof(float));
    for (cl=clusters-1; cl>=0; cl--)
    {
        cluster=sort[cl]+1;
        CopyCoordinates(sig, &ALEcpy);
        for (foci=0; foci<ALEcpy.TotalFoci; foci++)
        {
            if (ALEcpy.cluster[foci]!=cluster) ALEcpy.p[foci] = 1.0;
        }

        CombineExperimentsIntoALEimage(&ALEcpy, SingleClust, X, Y, Z,dx, dy, dz, x0, y0, z0, sigma, 0, critical, 0.0);
        for (voxel=0; voxel<voxels; voxel++)
        {
            if ( (SingleClust[voxel] >= MaxALE[voxel]) )
            {
                MaxALE[voxel] = SingleClust[voxel];
                if (ClustALE[voxel]>0.0) ClustNum[voxel] = cluster;
            }
        }


    }




END:
    if (SingleClust) free(SingleClust);
    if (MaxALE) free(MaxALE);
    if (Nfoci) free(Nfoci);
    if (sort) free(sort);

    return Nclusters;
}






//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//Histogram of GM structures
//The frequency reflects the size of the structure
//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
int *GetTalairachGMhistogram(int *N, char ExecDir[])
{
    int *H=NULL;
    FILE *fp;
    char fname[MAX_PATH];
    int i, index;

    sprintf(fname,"%s\\Talairach\\TalGMhist.txt",ExecDir);
    if ( (fp=fopen(fname,"r")) )
    {
        fscanf(fp,"%d",N);

        if ((H = (int *)malloc(sizeof(int)*((*N) + 1))))
        {
            for (i=0; i<=(*N); i++)
            {
                fscanf(fp,"%d %d", &index, &H[i]);
            }
        }
        fclose(fp);
    }

    return H;
}



























//================================================================================
//================================================================================
//================================================================================
//================================================================================
//================================================================================
//ONE TIME RUN FUNCTIONS
//================================================================================
//================================================================================
//================================================================================
//================================================================================
//================================================================================



//================================================================================
//================================================================================
//================================================================================
//create GM structure merge file
//This re-labels GM structures from the Talairach
//It does this by merging structures with matching entries in the labels database
//The labels database has 5 levels per record: Hemisphere, Lobe, Gyrus, Tissue type, Cell type
//Hemisphere MUST be matched
//Gyrus MUST be matched
//if MatchLevels = 3, then Cell Type must also be matched
//================================================================================
//================================================================================
//================================================================================


int CreateStructureMergeFile(HWND hwnd, char ExecDir[])
{
    struct Image TalGM;
    char *labels;
    int *H=NULL;
    int label, l;
    int N, Nlabels;
    int voxel,voxels;
    int X,Y,Z;
    int Largest;
    int Nmerges=0;
    int *Merge = NULL;
    int *tmp = NULL;
    FILE *fp;
    char fname[MAX_PATH];

    memset(&TalGM,0,sizeof(struct Image));

    sprintf(fname,"%s\\Talairach\\TalGM.nii", ExecDir);
    if (!LoadFromFileName(hwnd, fname, &TalGM,0)) goto END;
    X = TalGM.X;
    Y = TalGM.Y;
    Z = TalGM.Z;
    voxels = X*Y*Z;

    if (!(labels = LoadTalairachLabels(&N))) goto END;
    Nlabels = BiggestTalairachLabel(labels, N);

    if (!(H = (int *)malloc(sizeof(int)*(Nlabels+1)))) goto END;
    memset(H,0,sizeof(int)*(Nlabels+1));


    //Merge is the result. Merge[i] tells us what the ithe structure label should be after merging
    if (!(Merge = (int *)malloc(sizeof(int)*(Nlabels+1)))) goto END;
    memset(Merge,0,sizeof(int)*(Nlabels+1));
    if (!(tmp = (int *)malloc(sizeof(int)*(Nlabels+1)))) goto END;



    //GET THE HISTOGRAM OF THE GM STRUCTURES
    for (voxel=0; voxel<voxels; voxel++) H[(int)TalGM.img[voxel]]++;

    //perform the merging
    for (label=1; label<=Nlabels; label++)
    {
        if (H[label] && (!Merge[label]))
        {
            Largest = label;
            memset(tmp,0,sizeof(int)*(Nlabels+1));
            tmp[label] = 1;
            for (l=label+1; l<=Nlabels; l++)
            {
                if (H[l] && MatchedLevels(labels, N, label, l))
                {
                    if ((H[l] > H[Largest]) && label)  Largest = l;
                    tmp[l] = 1;
                    Nmerges++;
                }
            }
            for (l=label+1; l<=Nlabels; l++) if (tmp[l])
                {
                    Merge[l] = Largest;
                }
        }
        if (!Merge[label]) Merge[label] = label;
    }
    //merge those with gyrus and cell type unspecified (*) with the background
    for (l=1; l<=Nlabels; l++)
    {
        if (MatchedLevels(labels, N, 0, l)) Merge[l] = 0;
    }


//sprintf(txt,"%d", Nmerges);
//MessageBox(NULL,txt,"",MB_OK);

    sprintf(fname,"%s\\Talairach\\Merge.txt", ExecDir);
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"%d\n",Nlabels);
        for (label=0; label<=Nlabels; label++)
        {
            fprintf(fp,"%d %d\n",label,Merge[label]);
            /*if (label!=Merge[label])
            {
                b = FindEntryInTalairachLabels(labels, N, label);
                fprintf(fp,"%s\n",b);
                b = FindEntryInTalairachLabels(labels, N, Merge[label]);
                fprintf(fp,"%s\n",b);
            }*/
        }
        fclose(fp);
    }


END:
    ReleaseImage(&TalGM);
    if (H) free(H);
    if (Merge) free(Merge);
    if (tmp) free(tmp);

    return Nmerges;
}







//======================================================================================================
//TEST FOR SIGNIFICANT DIFFERENCES IN ACTIVATION BY HEMISPHERE
//NULL HYPOTHESIS: THE HEMISPHERE IS RANDOM
//GENERATE THE NULL BY RANDOMISATION OF THE HEMISPHERE
//======================================================================================================
double LateralizationTest(HWND hwnd, struct Coordinates *ale, float *mask, float *out, int X, int Y, int Z,
                          float dx, float dy, float dz, float x0, float y0, float z0,
                          float sigma, double critical, char directory[], int FCDR, int FCDRmode, double pmethod[], int SaveOutput)
{
    struct Coordinates ALEcopy;
    int foci, iexp, Count=0;
    int sample;
    int offset;
    int Nsig;
    int voxels = X*Y*Z;
    int clusters;
    int voxel;
    int bin;
    int notsig;
    float *xnull=NULL;
    float *ynull=NULL;
    float *znull=NULL;
    float *ALEvalues=NULL;
    float *SigResults=NULL;
    float MinALE, MaxALE;
    float Hale[ALE_BINS];
    double pfdr=0.0,pfcdr, poldfdr, presult=0.0;
    double *p=NULL;
    double randomnumber;
    HDC hDC=GetDC(hwnd);
    char txt[256];

    memset(&ALEcopy,0,sizeof(struct Coordinates));
    memset(Hale,0,ALE_BINS*sizeof(float));

    if (!(xnull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(ynull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(znull = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(SigResults = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(ALEvalues = (float *)malloc(sizeof(float)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    if (!(p = (double *)malloc(sizeof(double)*(*ale).TotalFoci*(P_SAMPLES+1)))) goto END;
    memset(p,0,sizeof(double)*(*ale).TotalFoci*(P_SAMPLES+1));



    CopyCoordinates(ale, &ALEcopy);
    memcpy(xnull, (*ale).x, sizeof(float)*(*ale).TotalFoci);
    memcpy(ynull, (*ale).y, sizeof(float)*(*ale).TotalFoci);
    memcpy(znull, (*ale).z, sizeof(float)*(*ale).TotalFoci);


//MaxALE for normalising the ALE histogram
    MaxALE = MaxPossibleALE(ale, dx, dy, dz, sigma);


//the ALE values for the observed foci
    //ComputeALEatFoci(ale, dx, dy, dz, ALEvalues, sigma, 0, (*ale).TotalFoci-1);
    ComputeALEatFociFast(ale, dx, dy, dz, ALEvalues, sigma);




//ALE values for randomised experiments
    Count=0;
    for (sample=1; sample<=P_SAMPLES; sample++)
    {
        Count++;
        if (Count>=100)
        {
            RemoveInput(hwnd);
            sprintf(txt,"%d of %d samples     ",sample, P_SAMPLES);
            TextOut(hDC,100,100,txt,strlen(txt));
            UpdateWindow(hwnd);
            Count=0;
        }

        CopyCoordinates(ale, &ALEcopy);

        for (iexp=0; iexp<ALEcopy.Nexperiments; iexp++)
        {
            randomnumber=(double)rand()/RAND_MAX;
            if (randomnumber>0.5)
            {
                for (foci=0; foci<ALEcopy.TotalFoci; foci++)
                {
                    if (ALEcopy.experiment[foci]==iexp) ALEcopy.x[foci] *= -1.0;//flip this experiment
                }
            }
        }

        ComputeALEatFociFast(&ALEcopy, dx, dy, dz, &ALEvalues[(*ale).TotalFoci*sample], sigma);

        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            bin = ALE_BINS * sqrt(ALEvalues[(*ale).TotalFoci*sample + foci]/MaxALE);
            if (bin<ALE_BINS) Hale[bin] += 1.0;
        }

        memcpy(&xnull[sample*(*ale).TotalFoci], ALEcopy.x, sizeof(float)*(*ale).TotalFoci);
        memcpy(&ynull[sample*(*ale).TotalFoci], ALEcopy.y, sizeof(float)*(*ale).TotalFoci);
        memcpy(&znull[sample*(*ale).TotalFoci], ALEcopy.z, sizeof(float)*(*ale).TotalFoci);
    }




//convert ALE histogram into CDF
    for (bin=ALE_BINS-2; bin>=0; bin--) Hale[bin] += Hale[bin+1];
    for (bin=ALE_BINS-1; bin>=0; bin--) Hale[bin] /= Hale[0];

    /*
            if (fp=fopen("c:\\temp\\CDF.csv","w"))
            {
                for (bin=0; bin<ALE_BINS; bin++)
                {
                    fprintf(fp,"%d,%f\n",bin,1.0-Hale[bin]);
                }
                fclose(fp);
            }
    */

//convert to fraction of iterations; p-value
    for (sample=0; sample<(P_SAMPLES+1)*(*ale).TotalFoci; sample++)
    {
        bin = ALE_BINS * sqrt(ALEvalues[sample]/MaxALE);
        p[sample] = Hale[bin];
    }


//collect the NULL significant results for FDR
    Nsig=0;
    for (sample=1; sample<=P_SAMPLES; sample++)
    {
        offset = (*ale).TotalFoci*sample;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if (p[offset + foci] <= critical)
            {
                SigResults[Nsig]=p[offset+foci];
                Nsig++;
            }
        }
    }


    for (foci=0; foci<(*ale).TotalFoci; foci++) (*ale).p[foci] = p[foci];




//CONTROL THE FALSE DISCOVERY RATE
    sprintf(txt,"Controlling False Positives          ");
    TextOut(hDC,100,150,txt,strlen(txt));

    poldfdr = FDR((*ale).p, (*ale).TotalFoci, critical);//STANDARD METHOD
    pmethod[BHFDR_METHOD] = poldfdr;

    pfdr = ControlFDR((*ale).p, (*ale).TotalFoci, SigResults, Nsig, P_SAMPLES, critical, directory);//NEW METHOD FOR FDR CONTROL
    pmethod[FDR_METHOD] = pfdr;

    //first do fast FCDR
    clusters=0;
    pfcdr = ControlFCDR(hwnd, (*ale).p, (*ale).TotalFoci, p, ALEvalues, xnull, ynull, znull, P_SAMPLES, sigma, critical, directory, &clusters); //NEW METHOD FOR CONTROLING
    //now do slow FCDR, but only while the number of clusters = clusters
    if (clusters) pfcdr = ControlFCDR(hwnd, (*ale).p, (*ale).TotalFoci, p, ALEvalues, xnull, ynull, znull, P_SAMPLES, sigma, critical, directory, &clusters); //NEW METHOD FOR CONTROLING

    pmethod[FCDR_METHOD] = pfcdr;                                                                                   //FALSE CLUSTER RATE
    sprintf(txt,"                                                      ");
    TextOut(hDC,100,150,txt,strlen(txt));

//sprintf(txt,"pfdr=%f pStandardFDR=%f pfcdr=%f",pfdr,poldfdr,pfcdr);
//MessageBox(NULL,txt,"",MB_OK);


    if (FCDR) presult=pfcdr;
    else presult=pfdr;

    if (SaveOutput)
    {


        sprintf(txt,"Computing Output images            ");
        TextOut(hDC,100,150,txt,strlen(txt));


        CombineExperimentsIntoALEimage(ale, out, X, Y, Z,dx, dy, dz, x0, y0, z0, sigma, 0, 1.0, 0.0);

        //&out[0] now contains the ALE

        //find the minimum ALE; the ALE corresponding to pnotsig (the most significant of the not significant foci)
        notsig=0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if (p[foci]>p[notsig]) notsig=foci;
        }
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ( (p[foci]>presult) && (p[foci]<p[notsig]) ) notsig = foci;
        }
        MinALE = 1.0;
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            if ( (p[foci]<=p[notsig]) && (out[(*ale).voxel[foci]]<MinALE) ) MinALE = out[(*ale).voxel[foci]];
        }



        if ( (clusters = CountSignificantMApeaks((*ale).x, (*ale).y, (*ale).z, (*ale).p, ALEvalues, (*ale).cluster, (*ale).TotalFoci, sigma, presult, 0)) )
        {
            CombineExperimentsIntoALEimage(ale, &out[CLUSTALE*voxels], X, Y, Z,dx, dy, dz, x0, y0, z0, sigma, 1, presult, 0.0);
            for (voxel=0; voxel<voxels; voxel++)
            {
                if (out[voxel]<MinALE) out[CLUSTALE*voxels+voxel]=0.0;
            }

            clusters=GetClusterNumberImage(ale, clusters, &out[CLUSTALE*voxels], &out[CLUSTNUM*voxels],
                                           dx, dy, dz, x0, y0, z0, X, Y, Z, sigma, presult);
        }



        //save ALL the foci in an image
        for (foci=0; foci<(*ale).TotalFoci; foci++)
        {
            voxel=(*ale).voxel[foci];
            out[FOCIIMG*voxels+voxel]=((float)((*ale).experiment[foci]+1))/(*ale).Nexperiments;
        }


        sprintf(txt,"Computing Output images DONE        ");
        TextOut(hDC,100,150,txt,strlen(txt));
    }

END:
    if (ALEvalues) free(ALEvalues);
    if (p) free(p);
    if (SigResults) free(SigResults);
    if (xnull) free(xnull);
    if (ynull) free(ynull);
    if (znull) free(znull);
    FreeCoordinates(&ALEcopy);
    ReleaseDC(hwnd,hDC);

    return presult;
}


//======================================================================================================
//make an image that represents the distribution of foci for the FWHM experiment in the second plos paper
//======================================================================================================
int TestFociDistribution(struct Image *image)
{
    float xfixed[3]= {-34.0,0.0,34.0};
    float yfixed[3]= {10.0,40.0,10.0};
    float zfixed[3]= {16.0,16.0,16.0};
    float r;
    float xf,yf,zf;
    float *dist=NULL;
    int X,Y,Z;
    int iter;
    int cluster;
    int voxel;
    double fwhm=10.0;
    double SD=SD_ALE(fwhm);

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;

    if (!(dist=(float *)malloc(X*Y*Z*sizeof(float)))) goto END;
    memset(dist,0,sizeof(float)*X*Y*Z);

    for (iter=0; iter<1000000; iter++)
    {
        for (cluster=0; cluster<3; cluster++)
        {
            do
            {
                r=GaussRandomNumber_BoxMuller(0.0, 1.0);
            }
            while(fabs(r)>2.0);
            xf=(xfixed[cluster] + r*SD + (*image).x0)/(*image).dx + 0.5;

            do
            {
                r=GaussRandomNumber_BoxMuller(0.0, 1.0);
            }
            while(fabs(r)>2.0);
            yf=(yfixed[cluster] + r*SD + (*image).y0)/(*image).dy + 0.5;

            do
            {
                r=GaussRandomNumber_BoxMuller(0.0, 1.0);
            }
            while(fabs(r)>2.0);
            zf=(zfixed[cluster] + r*SD + (*image).z0)/(*image).dz + 0.5;

            voxel=(int)xf + (int)yf*X + (int)zf*X*Y;

            if ((voxel>=0) && (voxel<X*Y*Z)) dist[voxel] += 1.0;

        }
    }

    memcpy ((*image).img, dist, sizeof(float)*X*Y*Z);

END:
    if (dist) free(dist);

    return 1;
}
//======================================================================================================
//MAKE A TEST ALE STRUCTURE WITH MULTIPLE CLUSTERS WITH DIFFERENT FRACTIONS OF THE EXPERIMENTS
//CONTRIBUTING TO THE CLUSTERS
//CONTRIBUTIONS ARE 40%, 50%, AND 60%
//N IS THE NUMBER OF STUDIES
//THE NUMBER OF FOCI PER STUDY IS 10
//THE NUMBER OF SUBJECTS IS 10, WHICH ACCORDING TO THE ALE ALGORITHM SETS THE FWHM AT 10mm
//======================================================================================================
int TestSaveALEforROC(struct Image *image, int N)
{
    struct Coordinates ale;
    char *TrueSig=NULL;

    memset(&ale,0,sizeof(struct Coordinates));
    MakeStructCoordinates(&ale, 10*N, N);

    TrueSig=(char *)malloc(10*N);

    PaperTestALEforROCcurve(image, &ale, N, 1, TrueSig);

    FreeCoordinates(&ale);
    free(TrueSig);
    return 1;
}
int PaperTestALEforROCcurve(struct Image *image, struct Coordinates *ale, int N, int save, char *TrueSig)
{
    int FociPerExperiment=10;
    int foci, experiment;
    int voxel;
    int xr,yr,zr;
    int i;
    int TotalPositives=0;
    double fwhm=10.0;
    double SD=SD_ALE(fwhm);
    double dist,mindist;
    float r;
    float xf,yf,zf;
    float xfixed[3]= {-34.0,0.0,34.0};
    float yfixed[3]= {10.0,40.0,10.0};
    float zfixed[3]= {16.0,16.0,16.0};
    float frac[3]= {0.4, 0.3, 0.2};
    char fname[MAX_PATH];

    for (experiment=0; experiment<N; experiment++)
    {
        sprintf((*ale).ID[experiment].txt,"%d",experiment);

        for (foci=0; foci<FociPerExperiment; foci++)
        {
            if ( (foci<3) && ( (frac[foci]*N) >= experiment) )
            {
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).x[foci + experiment*FociPerExperiment] = xfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).y[foci + experiment*FociPerExperiment] = yfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).z[foci + experiment*FociPerExperiment] = zfixed[foci] + SD*r;

                TrueSig[foci + experiment*FociPerExperiment]=1;
                TotalPositives++;

                (*ale).experiment[foci + experiment*FociPerExperiment] = experiment;
                (*ale).subjects[foci + experiment*FociPerExperiment] = 10;
            }
            else
            {
                do
                {
                    voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                    XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                    xf=(*image).dx*xr - (*image).x0;
                    yf=(*image).dy*yr - (*image).y0;
                    zf=(*image).dz*zr - (*image).z0;
                    mindist=10000.0;
                    for (i=0; i<3; i++)
                    {
                        dist = sqrt((xfixed[i]-xf)*(xfixed[i]-xf) + (yfixed[i]-yf)*(yfixed[i]-yf) + (zfixed[i]-zf)*(zfixed[i]-zf));
                        if (dist<mindist) mindist=dist;
                    }
                }
                while(mindist<2.0*SD);
                (*ale).x[foci + experiment*FociPerExperiment] = xf;
                (*ale).y[foci + experiment*FociPerExperiment] = yf;
                (*ale).z[foci + experiment*FociPerExperiment] = zf;
                (*ale).experiment[foci + experiment*FociPerExperiment] = experiment;
                (*ale).subjects[foci + experiment*FociPerExperiment] = 10;
                TrueSig[foci + experiment*FociPerExperiment]=0;
            }
        }
    }

    if (save)
    {
        sprintf(fname,"c://temp//PaperTestFWHM_ROC%d.txt",N);
        SaveExperimentsALE(ale, fname, (*image).filename, 1.0, 0);
    }


    return TotalPositives;
}
//======================================================================================================
//test PaperTestALEforROCcurve
//N is the number of studies
//======================================================================================================
int TestPaperTestALEforROCcurve(HWND hwnd, struct Image *image, float fwhm, double alpha, int Computefwhm)
{
    struct Coordinates ale;
    double pmethod[3];
    float pvalue;
    int X,Y,Z;
    int foci;
    int studies,minstudies,maxstudies;
    int TotalPositives[100];
    int s,i;
    float dx,dy,dz,x0,y0,z0;
    float *out=NULL;
    float sigma;
    float *ALEs=NULL;
    char *TrueSig=NULL;
    FILE *fp=NULL;
    char txt[256];
    int averages,Naverages[100];
    int index;
    double AvFalse[100], AvTrue[100];
    double TrueClust[100], FalseClust[100];
    char fname[MAX_PATH];
    HDC hDC=GetDC(hwnd);


    minstudies=10;
    maxstudies=150;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z/(*image).volumes;
    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;
    x0=(*image).x0;
    y0=(*image).y0;
    z0=(*image).z0;

    if (!(out=(float *)malloc(IMAGES * X * Y * Z * sizeof(float)))) goto END;


    memset(&ale,0,sizeof(struct Coordinates));


    index=0;
    for (studies=minstudies; studies<=maxstudies; studies+=10)
    {

        if (!(TrueSig=(char *)malloc(10*studies))) goto END;
        MakeStructCoordinates(&ale, 10*studies, studies);

        if (Computefwhm==1) fwhm=alpha/pow((double)studies,1.0/3);
        else if (Computefwhm==2)
        {
            if (studies<=30) fwhm=0.5*(10.0 + alpha/pow((double)studies,1.0/3));
            else fwhm=alpha/pow((double)studies,1.0/3);
        }
        sigma=SD_ALE(fwhm);

        if (!(ALEs=(float *)malloc(10*studies*sizeof(float)))) goto END;

        AvTrue[index]=AvFalse[index]=0.0;
        TrueClust[index]=FalseClust[index]=0.0;
        Naverages[index]=300;
        if (studies>50) Naverages[index]=100;

        for (averages=0; averages<Naverages[index]; averages++)
        {

            TotalPositives[index]=PaperTestALEforROCcurve(image, &ale, studies, 0, TrueSig);

            pvalue = ComputePvalueBySpatialRandomisation(hwnd, &ale, (*image).img, out,  X,  Y,  Z,
                     dx,  dy,  dz,  x0,  y0,  z0, sigma, 0.05, "c://temp//", 1, pmethod, 0);


            sprintf(txt,"Studies=%d          ",studies);
            TextOut(hDC,100,300,txt,strlen(txt));
            UpdateWindow(hwnd);

            ComputeALEatFociFast(&ale, dx, dy, dz, ALEs, sigma);
            CountSignificantMApeaks(ale.x, ale.y, ale.z, ale.p, ALEs, ale.cluster, ale.TotalFoci, sigma, pvalue, 0);


            for (foci=0; foci<ale.TotalFoci; foci++)
            {
                if (ale.p[foci]<=pvalue)
                {
                    if (TrueSig[foci]) AvTrue[index]+=1.0;
                    else AvFalse[index]+=1.0;
                }
            }

            for (foci=0; foci<ale.TotalFoci; foci++)
            {
                if (ale.cluster[foci])
                {
                    if (TrueSig[foci]) TrueClust[index]+=1.0;
                    else FalseClust[index]+=1.0;
                }
            }

        }

        if (TrueSig) free(TrueSig);
        TrueSig=NULL;
        if (ALEs) free(ALEs);
        ALEs=NULL;
        FreeCoordinates(&ale);





        if (Computefwhm==1) sprintf(fname,"c://temp//ROC_sig_alpha_%d.csv",(int)alpha);
        else if (Computefwhm==2) sprintf(fname,"c://temp//ROC_sig_Addaptive_alpha_%d.csv",(int)alpha);
        else sprintf(fname,"c://temp//ROC_sig_FWHM%f.csv",fwhm);
        //MessageBox(hwnd,fname,"",MB_OK);
        if ( (fp=fopen(fname,"w") ) )
        {
            //MessageBox(hwnd,fname,"",MB_OK);
            i=0;
            for (s=minstudies; s<=studies; s+=10)
            {
                if (Computefwhm==1) fwhm=alpha/pow((double)s,1.0/3);
                else if (Computefwhm==2)
                {
                    if (s<=30) fwhm=0.5*(10.0 + alpha/pow((double)s,1.0/3));
                    else fwhm=alpha/pow((double)s,1.0/3);
                }
                sigma=SD_ALE(fwhm);

                fprintf(fp,"%f,%d,%f,%f\n",fwhm,s,AvFalse[i]/TotalPositives[i]/Naverages[i], AvTrue[i]/TotalPositives[i]/Naverages[i]);
                i++;
            }
            fclose(fp);
        }


        if (Computefwhm==1) sprintf(fname,"c://temp//ROC_clust_alpha_%d.csv",(int)alpha);
        else if (Computefwhm==2) sprintf(fname,"c://temp//ROC_clust_Addaptive_alpha_%d.csv",(int)alpha);
        else sprintf(fname,"c://temp//ROC_clust_FWHM%f.csv",fwhm);
        if ( (fp=fopen(fname,"w") ) )
        {
            i=0;
            for (s=minstudies; s<=studies; s+=10)
            {
                if (Computefwhm==1) fwhm=alpha/pow((double)s,1.0/3);
                else if (Computefwhm==2)
                {
                    if (s<=30) fwhm=0.5*(10.0 + alpha/pow((double)s,1.0/3));
                    else fwhm=alpha/pow((double)s,1.0/3);
                }
                sigma=SD_ALE(fwhm);

                fprintf(fp,"%f,%d,%f,%f\n",fwhm,s,FalseClust[i]/TotalPositives[i]/Naverages[i],TrueClust[i]/TotalPositives[i]/Naverages[i]);
                i++;
            }
            fclose(fp);
        }

        index++;
    }//studies




//sprintf(txt,"%f",pvalue);
//MessageBox(NULL,txt,"",MB_OK);


END:
    if (out) free(out);
    if (TrueSig) free(TrueSig);
    if (ALEs) free(ALEs);
    ReleaseDC(hwnd,hDC);

    return 1;
}



//======================================================================================================
//MAKE AN ALE FILE WITH EXPERIMENTS HAVING SOME CONSISTENT POINTS PLUS SOME RANDOM POINTS
//FOR PAPER ON FWHM AND HETEROGENEITY
//======================================================================================================
int PaperALEforExploringFWHM(struct Image *image, int reflect)
{
    int Nexperiments=25;
    int FociPerExperiment=10;
    int TotalFoci=Nexperiments*FociPerExperiment;
    int foci, experiment;
    int voxel;
    int xr,yr,zr;
    double SD=5.0;
    float r;
    float sign;
    float x=34.0;//+- for the two sides
    float y=10.0;
    float z=16.0;
    struct Coordinates ale;
    char fname[MAX_PATH];

    memset(&ale,0,sizeof(struct Coordinates));

    MakeStructCoordinates(&ale, TotalFoci, Nexperiments);

    for (experiment=0; experiment<Nexperiments; experiment++)
    {
        sprintf(ale.ID[experiment].txt,"%d",experiment);

        for (foci=0; foci<FociPerExperiment; foci++)
        {
            if ( (foci<2) )
            {
                sign=1.0;
                if (reflect)
                {
                    if (foci) sign=-1.0;
                }
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.x[foci + experiment*FociPerExperiment] = sign*x + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.y[foci + experiment*FociPerExperiment] = y + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.z[foci + experiment*FociPerExperiment] = z + SD*r;
                ale.experiment[foci + experiment*FociPerExperiment] = experiment;
                ale.subjects[foci + experiment*FociPerExperiment] = 10;
            }
            else
            {

                voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                ale.x[foci + experiment*FociPerExperiment] = (*image).dx*xr - (*image).x0;
                ale.y[foci + experiment*FociPerExperiment]= (*image).dy*yr - (*image).y0;
                ale.z[foci + experiment*FociPerExperiment] = (*image).dz*zr - (*image).z0;
                ale.experiment[foci + experiment*FociPerExperiment] = experiment;
                ale.subjects[foci + experiment*FociPerExperiment] = 10;
            }
        }
    }

    if (reflect) sprintf(fname,"c://temp//PaperTestFWHM%d_reflect.txt",Nexperiments);
    else sprintf(fname,"c://temp//PaperTestFWHM%d.txt",Nexperiments);
    SaveExperimentsALE(&ale, fname, (*image).filename, 1.0, 0);


    FreeCoordinates(&ale);

    return 1;

}


//======================================================================================================
//MAKE AN ALE FILE WITH EXPERIMENTS HAVING SOME CONSISTENT POINTS PLUS SOME RANDOM POINTS
//FOR PAPER ON FWHM
//======================================================================================================
int TestOfDifferences(struct Image *image, int Nexperiments, float sign, int fixed, int Nrandom)
{

    int foci, experiment;
    int voxel;
    int xr,yr,zr;
    int i;
    double SD=SD_ALE(10.0);
    float r;
    float x=34.0;//+- for the two sides
    float y=10.0;
    float z=16.0;
    float xf,yf,zf;
    float dist, mindist;
    float FWHM=FWHM_ALE(Nexperiments);
    float xfixed[8]= {18.0,55.0,20.0, 40.0, -18.0,-55.0,-20.0, -40.0};
    float yfixed[8]= {60.0,-24.0,-86.0, -60.0,60.0,-24.0,-86.0, -60.0};
    float zfixed[8]= {16.0,16.0,16.0, 16.0,16.0,16.0,16.0, 16.0};
    int FociPerExperiment=fixed+1;
    int TotalFoci=Nexperiments*FociPerExperiment;
    struct Coordinates ale;
    char fname[MAX_PATH];

    if (fixed>8) fixed=8;

    if (sign>0.0) sign=1.0;
    else sign=-1.0;

    memset(&ale,0,sizeof(struct Coordinates));

    MakeStructCoordinates(&ale, TotalFoci, Nexperiments);

    for (experiment=0; experiment<Nexperiments; experiment++)
    {
        sprintf(ale.ID[experiment].txt,"%d",experiment);
        for (foci=0; foci<FociPerExperiment; foci++)
        {
            if ( (foci<1) && (experiment>=Nrandom) )
            {
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.x[foci + experiment*FociPerExperiment] = sign*x + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.y[foci + experiment*FociPerExperiment] = y + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.z[foci + experiment*FociPerExperiment] = z + SD*r;
                ale.experiment[foci + experiment*FociPerExperiment] = experiment;
                ale.subjects[foci + experiment*FociPerExperiment] = 10;
            }
            else if ( (foci<=fixed)  && (experiment>=Nrandom) )
            {
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.x[foci + experiment*FociPerExperiment] = xfixed[foci-1] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.y[foci + experiment*FociPerExperiment] = yfixed[foci-1] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.z[foci + experiment*FociPerExperiment] = zfixed[foci-1] + SD*r;
                ale.experiment[foci + experiment*FociPerExperiment] = experiment;
                ale.subjects[foci + experiment*FociPerExperiment] = 10;
            }
            else
            {
                do
                {
                    voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                    XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                    xf=(*image).dx*xr - (*image).x0;
                    yf=(*image).dy*yr - (*image).y0;
                    zf=(*image).dz*zr - (*image).z0;
                    mindist=sqrt((x-xf)*(x-xf) + (y-yf)*(y-yf) + (z-zf)*(z-zf));
                    for (i=0; i<8; i++)
                    {
                        dist = sqrt((xfixed[i]-xf)*(xfixed[i]-xf) + (yfixed[i]-yf)*(yfixed[i]-yf) + (zfixed[i]-zf)*(zfixed[i]-zf));
                        if (dist<mindist) mindist=dist;
                    }
                }
                while(mindist<1.2*FWHM);

                ale.x[foci + experiment*FociPerExperiment] = xf;
                ale.y[foci + experiment*FociPerExperiment] = yf;
                ale.z[foci + experiment*FociPerExperiment] = zf;
                ale.experiment[foci + experiment*FociPerExperiment] = experiment;
                ale.subjects[foci + experiment*FociPerExperiment] = 10;
            }
        }
    }

    if (sign>0.0) sprintf(fname,"c://temp//RightActivation_exp%d_rand%d_fixed%d.txt",Nexperiments,Nrandom,fixed);
    else sprintf(fname,"c://temp//LeftActivation_exp%d_rand%d_fixed%d.txt",Nexperiments,Nrandom,fixed);
    SaveExperimentsALE(&ale, fname, (*image).filename, 1.0, 0);


    FreeCoordinates(&ale);

    return 1;
}



//======================================================================================================
//MAKE AN ALE FILE WITH EXPERIMENTS HAVING SOME CONSISTENT POINTS PLUS SOME RANDOM POINTS
//FOR PAPER ON FWHM
//FOCI PER STUDY = Nclusters
//THE FIRST Nrandom STUDIES ARE JUST RANDOM FOCI
//THERE ARE A TOTAL OF Nstudies STUDIES IN THE EXPERIMENT
//======================================================================================================
int TestOfDifferences3(struct Image *image, int Nstudies, int Nclusters, int Nrandom)
{

    float xf,yf,zf;
    float dist, mindist;
    float FWHM=FWHM_ALE(Nstudies);
    int i;
    int foci, study;
    int voxel;
    int xr,yr,zr;
    int NfociPerStudy=Nclusters;
    double SD=SD_ALE(10.0);
    float r;
    double *random=NULL;
    int *sort=NULL;
    float xfixed[16]= {18.0,55.0,20.0, 40.0,-18.0,-55.0,-20.0, -40.0, 16.0, 40.0, 44.0, 26.0, -16.0, -40.0, -44.0, -26.0};
    float yfixed[16]= {60.0,-24.0,-86.0, -60.0, 60.0,-24.0,-86.0, -60.0, 40.0, 2.0, -42.0, -70.0, 40.0, 2.0, -42.0, -70.0};
    float zfixed[16]= {16.0,16.0,16.0, 16.0,16.0,16.0,16.0, 16.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0};
    int TotalFoci;
    struct Coordinates ale;
    char fname[MAX_PATH];

    if (Nclusters>16) Nclusters=16;

    TotalFoci=Nstudies*Nclusters;

    memset(&ale,0,sizeof(struct Coordinates));

    MakeStructCoordinates(&ale, TotalFoci, Nstudies);

    TotalFoci=0;
    for (study=0; study<Nstudies; study++)
    {
        sprintf(ale.ID[study].txt,"%d",study);

        if (study>=Nrandom)
        {

            for (foci=0; foci<Nclusters; foci++)
            {
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.x[TotalFoci] = xfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.y[TotalFoci] = yfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                ale.z[TotalFoci] = zfixed[foci] + SD*r;

                ale.experiment[TotalFoci] = study;
                ale.subjects[TotalFoci] = 10;

                TotalFoci++;
            }

        }
        else
        {
            for (foci=0; foci<Nclusters; foci++)
            {
                do
                {
                    voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                    XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                    xf=(*image).dx*xr - (*image).x0;
                    yf=(*image).dy*yr - (*image).y0;
                    zf=(*image).dz*zr - (*image).z0;
                    mindist=2.0*FWHM;
                    for (i=0; i<Nclusters; i++)
                    {
                        dist = sqrt((xfixed[i]-xf)*(xfixed[i]-xf) + (yfixed[i]-yf)*(yfixed[i]-yf) + (zfixed[i]-zf)*(zfixed[i]-zf));
                        if (dist<mindist) mindist=dist;
                    }
                }
                while(mindist<1.2*FWHM);

                ale.x[TotalFoci] = xf;
                ale.y[TotalFoci] = yf;
                ale.z[TotalFoci] = zf;
                ale.experiment[TotalFoci] = study;
                ale.subjects[TotalFoci] = 10;
                TotalFoci++;
            }
        }
    }
    ale.TotalFoci=TotalFoci;


    //decorrelate the clusters
    sort=(int *)malloc(Nstudies*sizeof(int));
    random=(double *)malloc(Nstudies*sizeof(double));
    for (foci=0; foci<NfociPerStudy; foci++)
    {
        for (study=0; study<Nstudies; study++) random[study]=(double)rand();
        QuickSort(random,sort, Nstudies);

        for (study=0; study<Nstudies; study++)
        {
            xf=ale.x[sort[study]*NfociPerStudy+foci];
            yf=ale.y[sort[study]*NfociPerStudy+foci];
            zf=ale.z[sort[study]*NfociPerStudy+foci];
            ale.x[sort[study]*NfociPerStudy+foci]=ale.x[study*NfociPerStudy+foci];
            ale.y[sort[study]*NfociPerStudy+foci]=ale.y[study*NfociPerStudy+foci];
            ale.z[sort[study]*NfociPerStudy+foci]=ale.z[study*NfociPerStudy+foci];
            ale.x[study*NfociPerStudy+foci]=xf;
            ale.y[study*NfociPerStudy+foci]=yf;
            ale.z[study*NfociPerStudy+foci]=zf;
        }
    }
    free(sort);
    free(random);

    sprintf(fname,"c://temp//Activation_studies_%d_clusters_%d_foci_%d_random_%d.txt",Nstudies,Nclusters,TotalFoci,Nrandom);
    SaveExperimentsALE(&ale, fname, (*image).filename, 1.0, 0);


    FreeCoordinates(&ale);

    return 1;
}
//======================================================================================================
//MAKE AN ALE WITH A SPECIFIED NUMBER OF CLUSTERS AND A SPECIFIED PROPORTION OF
//STUDIES REPORTING AT EACH CLUSTER
//THIS IS USED TO TEST THE FALSE POSITIVES IN THE PLOS PAPER
//======================================================================================================
int NullALEDifferenceSecondPlosPaper(HWND hwnd, struct Image *image)
{
    struct Coordinates ale1,ale2;
    int iter,counter[6];
    int Nstudies=15;
    int Nclusters=8;
    int Nrandom=10;
    int l;
    double level[6]= {0.5, 0.4, 0.3, 0.2,0.1,0.05};
    double pvalue;
    double sd=SD_ALE(10.0);
    float dx,dy,dz;
    HDC hDC=GetDC(hwnd);
    char txt[256];
    char *G=NULL;
    FILE *fp=NULL;


    if (!(G=(char *)malloc(2*Nstudies))) goto END;

    dx=(*image).dx;
    dy=(*image).dy;
    dz=(*image).dz;

    memset(&ale1,0,sizeof(struct Coordinates));
    MakeStructCoordinates(&ale1, 10*Nstudies, Nstudies);//100 foci, 10 studies
    memset(&ale2,0,sizeof(struct Coordinates));
    MakeStructCoordinates(&ale2, 10*Nstudies, Nstudies);//100 foci, 10 studies



    TestOfNullALEDifferenceSecondPlosPaper(&ale1, image, Nstudies, Nclusters, 10, Nrandom);
    SaveExperimentsALE(&ale1, "c://temp//ale1.txt","aa",0.01,0);
    //CopyCoordinates(&ale1,&ale2);
    TestOfNullALEDifferenceSecondPlosPaper(&ale2, image, Nstudies, Nclusters, 10, Nrandom);
    SaveExperimentsALE(&ale2, "c://temp//ale2.txt","aa",0.01,0);

    memset(counter,0,sizeof(int)*6);
    for (iter=0; iter<1000; iter++)
    {
        pvalue=DifferenceBetweenALEs(hwnd, &ale1, &ale2, sd, dx, dy, dz, "c://temp", 1, 0.05, 0.05, 0);

        for (l=0; l<6; l++)
        {
            if (pvalue<=level[l]) counter[l]++;
        }

        sprintf(txt,"iter=%d  level=%f  counter=%d  pvalue=%f",iter,level[0],counter[0],pvalue);
        TextOut(hDC,100,300,txt,strlen(txt));

        if (!(iter%10))
        {
            if ( (fp=fopen("c://temp//quantiles.csv","w")) )
            {
                for (l=0; l<6; l++)
                {
                    fprintf(fp,"%d,%f,%d,%f\n",iter,level[l],counter[l],(double)counter[l]/iter);
                }
                fclose(fp);
            }
        }

    }


END:
    FreeCoordinates(&ale1);
    FreeCoordinates(&ale2);
    ReleaseDC(hwnd,hDC);

    return 1;
}
int TestOfNullALEDifferenceSecondPlosPaper(struct Coordinates *ale, struct Image *image, int Nstudies, int Nclusters, int NfociPerStudy, int NrandomStudies)
{

    float xf,yf,zf;
    float dist, mindist;
    float FWHM=FWHM_ALE(Nstudies);
    int i;
    int foci, study;
    int voxel;
    int xr,yr,zr;
    double SD=SD_ALE(10.0);
    double *random=NULL;
    int *sort=NULL;
    float r;
    float xfixed[16]= {18.0,55.0,20.0, 40.0,-18.0,-55.0,-20.0, -40.0, 16.0, 40.0, 44.0, 26.0, -16.0, -40.0, -44.0, -26.0};
    float yfixed[16]= {60.0,-24.0,-86.0, -60.0, 60.0,-24.0,-86.0, -60.0, 40.0, 2.0, -42.0, -70.0, 40.0, 2.0, -42.0, -70.0};
    float zfixed[16]= {16.0,16.0,16.0, 16.0,16.0,16.0,16.0, 16.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0, 46.0};
    int TotalFoci;

    if (Nclusters>16) Nclusters=16;

    TotalFoci=0;
    for (study=0; study<Nstudies; study++)
    {
        sprintf((*ale).ID[study].txt,"%d",study);

        if (study>=NrandomStudies)
        {

            for (foci=0; foci<Nclusters; foci++)
            {
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).x[TotalFoci] = xfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).y[TotalFoci] = yfixed[foci] + SD*r;
                do
                {
                    r=GaussRandomNumber_BoxMuller(0.0, 1.0);
                }
                while(fabs(r)>2.0);
                (*ale).z[TotalFoci] = zfixed[foci] + SD*r;

                (*ale).experiment[TotalFoci] = study;
                (*ale).subjects[TotalFoci] = 10;

                TotalFoci++;
            }
            for (foci=Nclusters; foci<NfociPerStudy; foci++)
            {
                do
                {
                    voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                    XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                    xf=(*image).dx*xr - (*image).x0;
                    yf=(*image).dy*yr - (*image).y0;
                    zf=(*image).dz*zr - (*image).z0;
                    mindist=2.0*FWHM;
                    for (i=0; i<Nclusters; i++)
                    {
                        dist = sqrt((xfixed[i]-xf)*(xfixed[i]-xf) + (yfixed[i]-yf)*(yfixed[i]-yf) + (zfixed[i]-zf)*(zfixed[i]-zf));
                        if (dist<mindist) mindist=dist;
                    }
                }
                while(mindist<1.2*FWHM);

                (*ale).x[TotalFoci] = xf;
                (*ale).y[TotalFoci] = yf;
                (*ale).z[TotalFoci] = zf;
                (*ale).experiment[TotalFoci] = study;
                (*ale).subjects[TotalFoci] = 10;
                TotalFoci++;
            }
        }
        else
        {
            for (foci=0; foci<NfociPerStudy; foci++)
            {
                do
                {
                    voxel=RandomImageVoxel((*image).img, (*image).X*(*image).Y*(*image).Z);
                    XYZfromVoxelNumber(voxel, &xr, &yr, &zr,  (*image).X,(*image).Y,(*image).Z);
                    xf=(*image).dx*xr - (*image).x0;
                    yf=(*image).dy*yr - (*image).y0;
                    zf=(*image).dz*zr - (*image).z0;
                    mindist=2.0*FWHM;
                    for (i=0; i<Nclusters; i++)
                    {
                        dist = sqrt((xfixed[i]-xf)*(xfixed[i]-xf) + (yfixed[i]-yf)*(yfixed[i]-yf) + (zfixed[i]-zf)*(zfixed[i]-zf));
                        if (dist<mindist) mindist=dist;
                    }
                }
                while(mindist<1.2*FWHM);

                (*ale).x[TotalFoci] = xf;
                (*ale).y[TotalFoci] = yf;
                (*ale).z[TotalFoci] = zf;
                (*ale).experiment[TotalFoci] = study;
                (*ale).subjects[TotalFoci] = 10;
                TotalFoci++;
            }
        }
    }

    //decorrelate the clusters
    sort=(int *)malloc(Nstudies*sizeof(int));
    random=(double *)malloc(Nstudies*sizeof(double));
    for (foci=0; foci<NfociPerStudy; foci++)
    {
        for (study=0; study<Nstudies; study++) random[study]=(double)rand();
        QuickSort(random,sort, Nstudies);

        for (study=0; study<Nstudies; study++)
        {
            xf=(*ale).x[sort[study]*NfociPerStudy+foci];
            yf=(*ale).y[sort[study]*NfociPerStudy+foci];
            zf=(*ale).z[sort[study]*NfociPerStudy+foci];
            (*ale).x[sort[study]*NfociPerStudy+foci]=(*ale).x[study*NfociPerStudy+foci];
            (*ale).y[sort[study]*NfociPerStudy+foci]=(*ale).y[study*NfociPerStudy+foci];
            (*ale).z[sort[study]*NfociPerStudy+foci]=(*ale).z[study*NfociPerStudy+foci];
            (*ale).x[study*NfociPerStudy+foci]=xf;
            (*ale).y[study*NfociPerStudy+foci]=yf;
            (*ale).z[study*NfociPerStudy+foci]=zf;
        }
    }
    free(sort);
    free(random);

    return 1;
}

//======================================================================================================
//TEST THE MASK TO CHECK WHAT PROPORTION OF FOCI FALL WITHIN IT
//======================================================================================================
int TestMask(HWND hwnd, struct Image *image)
{
    struct Coordinates ale;
    int foci;
    int count, voxels,voxel;
    float proportion;
    char name[MAX_PATH];

    voxels=0;
    for (voxel=0; voxel<(*image).X*(*image).Y*(*image).Z; voxel++)
    {
        if ((*image).img[voxel]>0.0) voxels++;
    }
    sprintf(name,"Number of non-null voxels=%d",voxels);
    MessageBox(hwnd,name,"",MB_OK);
    return 0;

    memset(&ale,0,sizeof(struct Coordinates));

    LoadExperimentsCOORDINATES(hwnd, &ale, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0);

    count=0;
    for (foci=0; foci<ale.TotalFoci; foci++)
    {
        if ((*image).img[ale.voxel[foci]]>0.0) count++;
    }
    proportion=(float)count/ale.TotalFoci;

    sprintf(name,"proportion of foci in mask=%f",proportion);
    MessageBox(hwnd,name,"",MB_OK);


    FreeCoordinates(&ale);

    return 1;
}





//======================================================================================================
//NEUROSCIENCE AND BIOBEHAVIOURAL REVIEW
//======================================================================================================

//======================================================================================================
//explore the p values generated by gingerale under our null hypothesis. Are they uniformly distributed?
//======================================================================================================
#define PVALUE_BINS 101
int TestUniformDistributionOfPvalues(HWND hwnd, struct Image *pvalue)
{
    int result=0;
    int voxel,voxels;
    int n,N;
    int *sort=NULL;
    double *p=NULL;
    FILE *fp;

    voxels=(*pvalue).X*(*pvalue).Y*(*pvalue).Z;

    N=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*pvalue).img[voxel]<=0.05) N++;
    }

    if (!N) goto END;

    if (!(p=(double *)calloc(N,sizeof(double)))) goto END;
    if (!(sort=(int *)calloc(N,sizeof(int)))) goto END;

    n=0;
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*pvalue).img[voxel]<=0.05)
        {
            p[n]=(*pvalue).img[voxel];
            n++;
        }
    }


    QuickSort(p,sort,N);


    if ((fp=fopen("c:\\temp\\pvalue CDF.csv","w")))
    {
        for (n=0; n<N; n+=N/10)
        {
            fprintf(fp,"%d,%f,%f,%f\n",n,p[sort[n]],(double)n/226657,0.05*n/226657);
        }
        fclose(fp);
    }


    result=1;
END:
    if (p) free(p);
    if (sort) free(sort);

    return result;
}

//======================================================================================================
//produce a random version of a ALE file, but with systematic coordinates included too
//======================================================================================================
int TestSystematicAndRandomRealisationsOfALEfile(HWND hwnd, struct Image *mask)
{
    struct Coordinates ale;
    struct Clusters cl;
    double sigma;
    int result=0;
    int focus,iexp;
    char name[MAX_PATH];

    memset(&ale,0,sizeof(struct Coordinates));
    memset(&cl,0,sizeof(struct Clusters));

    if (!(LoadExperimentsCOORDINATES(hwnd, &ale, (*mask).X, (*mask).Y, (*mask).Z, (*mask).dx, (*mask).dy, (*mask).dz, (*mask).x0, (*mask).y0, (*mask).z0))) goto END;

    sigma=SD_ALE(FWHM_ALE(ale.Nexperiments));

    FillClusterStructure(&ale, &cl, sigma);
    RandomiseFociRandomEffects((*mask).img, (*mask).X, (*mask).Y, (*mask).Z,
                              (*mask).dx, (*mask).dy, (*mask).dz,
                              (*mask).x0, (*mask).y0, (*mask).z0,
                              &ale, &cl, sigma);

    sprintf(name,"c:\\temp\\NBR_Random.txt");
    SaveExperimentsALE(&ale, name, (*mask).filename, 0.0,0);

    focus=0;
    for (iexp=0; iexp<ale.Nexperiments; iexp++)
    {
        while((focus<ale.TotalFoci) && (ale.experiment[focus]!=iexp)) focus++;
        //now focus points to the first focus in experimentiexp
        ale.x[focus]=-36.0;
        ale.y[focus]=6.0;
        ale.z[focus]=6.0;

        if ((focus<ale.TotalFoci-1) && (ale.experiment[focus+1]==iexp))
        {
            focus++;
            ale.x[focus]=36.0;
            ale.y[focus]=6.0;
            ale.z[focus]=6.0;
        }
    }

    sprintf(name,"c:\\temp\\NBR_Systematic.txt");
    SaveExperimentsALE(&ale, name, (*mask).filename, 0.0,0);

    result=1;
END:
    FreeCoordinates(&ale);

    return result;
}





