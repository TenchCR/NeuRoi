/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "imageprocess.h"
#include "loader.h"
#include <winioctl.h>



int UpdateAnalyzeHeader(struct Image *image);
int UpdateNIFTIHeader(struct Image *image);
int SaveData(float *img, int voxels, int datatype, int swap, FILE *fp);
//=============================================================================================
//              Save as Analyze Or Nifti Image
//              Analyze files will be saved as Analyze, Nifti as Nifti.
//=============================================================================================
int SaveAs(struct Image *image){


	OPENFILENAME fnamedlg;
	char filename[MAX_PATH];        //the filename including path
	char headername[MAX_PATH];      //the Analyze header name including path

    filename[0]='\0';

	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=NULL;
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=filename;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrInitialDir="./";
	fnamedlg.lpstrTitle="Select image file";

    if ((*image).ImageType==HDR){
       fnamedlg.lpstrFilter="Image Files\0*.img\0\0";
	   fnamedlg.lpstrDefExt="img";
    }
    else{
       fnamedlg.lpstrFilter="Image Files\0*.nii\0\0";
	   fnamedlg.lpstrDefExt="nii";
    }

	if(GetSaveFileName(&fnamedlg)){
        if ((*image).ImageType==HDR){
            //get the header name
            sprintf(headername,"%s",filename);
            headername[strlen(headername)-3]='\0';
            sprintf(headername,"%shdr",headername);
            return SaveAnalyzeImage(image, headername, filename);
        }
        else return SaveNiftiImage(image, filename);
    }
    else return 0;

    return 1;
}







//=============================================================================================
//                      Save the image
//=============================================================================================
int Save(struct Image *image){

   if (((*image).ImageType==HDR) || (!(*image).ImageType)){

      return SaveAnalyzeImage(image, (*image).headername, (*image).filename);
   }
   else if ((*image).ImageType==NIFTI){return SaveNiftiImage(image, (*image).filename);}
   return 0;
}








//=============================================================================================
//                      Update Analyze header information
//=============================================================================================
int UpdateAnalyzeHeader(struct Image *image){

    short int org[3]={0,0,0};

    if ((*image).dx) org[0]=(short int)((*image).x0/(*image).dx);
    if ((*image).dy) org[1]=(short int)((*image).y0/(*image).dy);
    if ((*image).dz) org[2]=(short int)((*image).z0/(*image).dz);
//sprintf(txt,"%d",org[2]);
//MessageBox(NULL,txt,"",MB_OK);

    //--------collect the used parts from the header----------------------------
	//new changes to make image compatable with others
	if (!(*image).hdr.dime.dim[0]) (*image).hdr.dime.dim[0]=3;
	(*image).hdr.dime.cal_min=0.0;
    (*image).hdr.dime.cal_max=(*image).MaxIntensity;

   	(*image).hdr.dime.dim[1]=(*image).X;
	(*image).hdr.dime.dim[2]=(*image).Y;
	(*image).hdr.dime.dim[3]=(*image).Z/(*image).volumes;//its SLICES per VOLUME that needs to be saved
    (*image).hdr.dime.dim[4]=(*image).volumes;

	(*image).hdr.dime.pixdim[1]=(*image).dx;
	(*image).hdr.dime.pixdim[2]=(*image).dy;
	(*image).hdr.dime.pixdim[3]=(*image).dz;

    (*image).hdr.dime.funused1=(*image).scale;
    (*image).hdr.dime.funused2=(*image).offset;

    (*image).hdr.dime.datatype=(*image).DataType;
    (*image).hdr.dime.bitpix=BitsPerPixel((*image).DataType);

	memcpy((*image).hdr.hist.originator, org, sizeof(short int)*3);

    sprintf((*image).hdr.hist.descrip,"%s",(*image).Descrip);

	//some things are necessary for this header
	//set those things here if not set
	(*image).hdr.hk.regular='r';
	if (!(*image).hdr.hk.extents){
        (*image).hdr.hk.extents=16394;
        if ((*image).swapbytes) SwapBytes((char *)&(*image).hdr.hk.extents,  sizeof(int));
    }

    (*image).hdr.hk.sizeof_hdr=sizeof(struct dsr);
    if ((*image).swapbytes) SwapBytes((char *)&(*image).hdr.hk.sizeof_hdr,  sizeof(int));


	if ((*image).swapbytes){//IF BYTES ARE SWAPED, REVERSE THEM
		SwapBytes((char *)&(*image).hdr.dime.dim[1],        sizeof(short int));
		SwapBytes((char *)&(*image).hdr.dime.dim[2],        sizeof(short int));
		SwapBytes((char *)&(*image).hdr.dime.dim[3],        sizeof(short int));
		SwapBytes((char *)&(*image).hdr.dime.dim[4],        sizeof(short int));
		SwapBytes((char *)&(*image).hdr.dime.pixdim[1],     sizeof(float));
		SwapBytes((char *)&(*image).hdr.dime.pixdim[2],     sizeof(float));
		SwapBytes((char *)&(*image).hdr.dime.pixdim[3],     sizeof(float));
		SwapBytes((char *)&(*image).hdr.dime.funused1,      sizeof(float));
		SwapBytes((char *)&(*image).hdr.dime.funused2,      sizeof(float));
		SwapBytes((char *)&(*image).hdr.hist.originator[0], sizeof(short int));
		SwapBytes((char *)&(*image).hdr.hist.originator[2], sizeof(short int));
		SwapBytes((char *)&(*image).hdr.hist.originator[4], sizeof(short int));
		SwapBytes((char *)&(*image).hdr.dime.datatype,      sizeof(short int));
	    SwapBytes((char *)&(*image).hdr.dime.bitpix,        sizeof(short int));
    }



    return 1;
}








//=============================================================================================
//                      Update NIFTI header information
//=============================================================================================
int UpdateNIFTIHeader(struct Image *image){

        sprintf((*image).nifti.magic,"n+1");

        if ((*image).volumes == 1) (*image).nifti.dim[0]=3;
        if ((*image).volumes > 1) (*image).nifti.dim[0]=4;
  		(*image).nifti.dim[1]=(*image).X;
		(*image).nifti.dim[2]=(*image).Y;
		(*image).nifti.dim[3]=(*image).Z/(*image).volumes;//its SLICES per VOLUME that needs to be saved
	    (*image).nifti.dim[4]=(*image).volumes;

		(*image).nifti.pixdim[1]=(*image).dx;
		(*image).nifti.pixdim[2]=(*image).dy;
		(*image).nifti.pixdim[3]=(*image).dz;

		(*image).nifti.qoffset_x=(*image).x0;
        (*image).nifti.qoffset_y=(*image).y0;
        (*image).nifti.qoffset_z=(*image).z0;


		(*image).nifti.scl_slope=(*image).scale;
		(*image).nifti.scl_inter=(*image).offset;



        (*image).nifti.datatype=(*image).DataType;
        (*image).nifti.bitpix=BitsPerPixel((*image).DataType);

        sprintf((*image).nifti.descrip,"%s",(*image).Descrip);

	   //some things are necessary for this header
	   //set those things here
        if (!(*image).nifti.sizeof_hdr){
            (*image).nifti.sizeof_hdr=348;
            if ((*image).swapbytes) SwapBytes((char *)&(*image).nifti.sizeof_hdr,sizeof(int));
        }



    	if ((*image).swapbytes){//IF BYTES ARE SWAPED, REVERSE THEM
    	    SwapBytes((char *)&(*image).nifti.dim[0],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.dim[1],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.dim[2],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.dim[3],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.dim[4],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.dim[5],    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.datatype,  sizeof(short int));
			SwapBytes((char *)&(*image).nifti.bitpix,    sizeof(short int));
			SwapBytes((char *)&(*image).nifti.pixdim[1], sizeof(float));
			SwapBytes((char *)&(*image).nifti.pixdim[2], sizeof(float));
			SwapBytes((char *)&(*image).nifti.pixdim[3], sizeof(float));
			SwapBytes((char *)&(*image).nifti.qoffset_x, sizeof(float));
			SwapBytes((char *)&(*image).nifti.qoffset_y, sizeof(float));
			SwapBytes((char *)&(*image).nifti.qoffset_z, sizeof(float));
			SwapBytes((char *)&(*image).nifti.scl_slope, sizeof(float));
			SwapBytes((char *)&(*image).nifti.scl_inter, sizeof(float));
		}



    return 1;
}








//=============================================================================================
//                      Save the data. NIFTI
//=============================================================================================
int SaveNiftiImage(struct Image *image, char filename[]){

	FILE *fp;
    char tmp;
	int voxels,loop;
	int DataOffset=(*image).vox_offset-sizeof(struct nifti_1_header);


    //according to the NIFTI format, there must be at least 4 bytes after the end of the nifti header before the image data
	if ((DataOffset+sizeof(struct nifti_1_header))<352) DataOffset=4;



	//First Save the Header file
	UpdateNIFTIHeader(image);
	if ( (fp=fopen(filename,"wb")) ){
		fwrite(&(*image).nifti, 1, sizeof(struct nifti_1_header), fp);

		//fill upto the offset in the NIFTI header
		tmp=0;
		for (loop=0; loop<DataOffset; loop++) fwrite(&tmp,1,1,fp);

        voxels=(*image).X*(*image).Y*(*image).Z;

        SaveData((*image).img, voxels, (*image).DataType, (*image).swapbytes, fp);



		fclose(fp);


        //new 24/09/2021
        //compress the nifti file by setting the compressed attribute
        HANDLE hFile;
        DWORD   dwShareMode=NULL;
        hFile = CreateFile(filename,
                        GENERIC_READ | GENERIC_WRITE,
                        dwShareMode,
                        NULL,
                        OPEN_EXISTING,
                        FILE_FLAG_BACKUP_SEMANTICS,
                        NULL);

      DWORD dummy;
      USHORT format = COMPRESSION_FORMAT_DEFAULT;

      DeviceIoControl(hFile, FSCTL_SET_COMPRESSION, &format, sizeof(USHORT), NULL, 0, &dummy, NULL);
      CloseHandle(hFile);

        //now update the Image structure with the new filenames
	    sprintf((*image).filename,"%s",filename);


	}
	else return 0;

    return 1;
}







//=============================================================================================
//                      Save the data. ANALYZE
//=============================================================================================
int SaveAnalyzeImage(struct Image *image, char headername[], char filename[]){

	FILE *fp;
	int voxels;


	//First Save the Header file
	UpdateAnalyzeHeader(image);
	if ( (fp=fopen(headername,"wb")) ){
		fwrite(&(*image).hdr, 1, sizeof(struct dsr), fp);
		fclose(fp);


    	//Now save the image file
        voxels=(*image).X*(*image).Y*(*image).Z;
    	if ( (fp=fopen(filename,"wb")) ){

		    SaveData((*image).img, voxels, (*image).DataType, (*image).swapbytes, fp);
		    fclose(fp);

        //new 24/09/2021
        //compress the img file by setting the compressed attribute
        HANDLE hFile;
        DWORD   dwShareMode=NULL;
        hFile = CreateFile(filename,
                        GENERIC_READ | GENERIC_WRITE,
                        dwShareMode,
                        NULL,
                        OPEN_EXISTING,
                        FILE_FLAG_BACKUP_SEMANTICS,
                        NULL);

      DWORD dummy;
      USHORT format = COMPRESSION_FORMAT_DEFAULT;

      DeviceIoControl(hFile, FSCTL_SET_COMPRESSION, &format, sizeof(USHORT), NULL, 0, &dummy, NULL);
      CloseHandle(hFile);

	       //now update the Image structure with the new filenames
	       sprintf((*image).filename,"%s",filename);
	       sprintf((*image).headername,"%s",headername);
       }
       else return 0;
    }
    else return 0;

	return 1;
}




//=============================================================================================
//                      Save the image data
//=============================================================================================
int SaveData(float *img, int voxels, int datatype, int swap, FILE *fp){

    unsigned char cI;
    short int sI;
    int I;
    float fI;
    double dI;
    RGBQUAD rgb4;
    RGBTRIPLE rgb3;
    int voxel;

    if (!fp) return 0;

    if (datatype==DT_BINARY) return SaveBinary(img, voxels, fp);

    for (voxel=0;voxel<voxels;voxel++){
        switch(datatype){

            case DT_FLOAT:
                fI=img[voxel];
                if (swap) SwapBytes((char *)&fI, sizeof(float));
                fwrite(&fI, sizeof(float),1,fp);
            break;

            case DT_DOUBLE:
                dI=(double)img[voxel];
                if (swap) SwapBytes((char *)&dI, sizeof(double));
                fwrite(&dI, sizeof(double),1,fp);
            break;

            case DT_UNSIGNED_CHAR:
                if ((int)img[voxel]>255) cI=255;
                else cI=(unsigned char)img[voxel];
                fwrite(&cI, 1,1,fp);
            break;

            case DT_SIGNED_SHORT:
            case DT_UNSIGNED_SHORT:
                if ((int)img[voxel]>SHRT_MAX) sI=SHRT_MAX;
                else sI=(short int)img[voxel];
                if (swap) SwapBytes((char *)&sI, sizeof(short int));
                fwrite(&sI, sizeof(short int),1,fp);
            break;
            case DT_SIGNED_INT:
                if (img[voxel]>INT_MAX) I=INT_MAX;
                else I=(int)img[voxel];
                if (swap) SwapBytes((char *)&I, sizeof(int));
                fwrite(&I, sizeof(int),1,fp);
            break;
            case DT_RGB:
                memcpy(&rgb4,&img[voxel],sizeof(float));
                rgb3.rgbtRed=rgb4.rgbRed; rgb3.rgbtBlue=rgb4.rgbBlue; rgb3.rgbtGreen=rgb4.rgbGreen;
                if (swap) SwapBytes((char *)&rgb3, sizeof(RGBTRIPLE));
                fwrite(&rgb3, sizeof(RGBTRIPLE),1,fp);
            break;

        }
    }



    return 1;
}
//=============================================================================================
int SaveBinary(float img[], int voxels, FILE *fp)
{
    unsigned char c;
    int voxel;
    int i;

    for (voxel=0;voxel<voxels;voxel+=8)
    {
        c=0;
        for (i=0;i<8;i++)
        {
          if (img[voxel+i]>0.0) c+=1<<i;
        }
        fwrite(&c, 1,1,fp);
    }
    return 1;
}


//=============================================================================================

//=============================================================================================
//returns the number of bits per pixel for a specific datatype
//=============================================================================================
int BitsPerPixel(short int datatype){

    switch(datatype){
		case DT_DOUBLE:
			return sizeof(double)*8;
		break;
		case DT_FLOAT:
			return sizeof(float)*8;
		break;
		case DT_UNSIGNED_CHAR:
			return 8;
		break;
		case DT_SIGNED_SHORT:
			return sizeof(short int)*8;
		break;
		case DT_UNSIGNED_SHORT:
		    return sizeof(unsigned short int)*8;
		case DT_SIGNED_INT:
			return sizeof(int)*8;
		break;
		case DT_RGB:                                                            //3 bytes for RGB triplet, fit into 4 bytes of the float
		    return 3*8;
        break;
        case DT_BINARY:
            return 1;
            break;
	}
	return 0;
}




//================================================================
//CONVERT TO A CHAR IMAGE SO IT TAKES UP LITTLE SPACEPARITY
//USEFUL FOR RESULTS IMAGES
//THEN SAVE THE IMAGE
//================================================================
int SaveAsCharImage(struct Image *image, int Scale)
{
    int result=0;
    int voxel,voxels;
    float I;
    struct Image charimg;
    double maxintensity,gain;
    char fname[MAX_PATH];

    sprintf(fname,"%s",(*image).filename);
    fname[strlen(fname)-4]='\0';
    sprintf(fname,"%s_char.nii",fname);

    memset(&charimg,0,sizeof(struct Image));
    if (!MakeCopyOfImage(image, &charimg)) goto END;

    voxels=(*image).X*(*image).Y*(*image).Z*(*image).volumes;

    if (Scale)
    {
    maxintensity=0.0;
    for (voxel=0;voxel<voxels;voxel++)
    {
        I=(*image).img[voxel];
        if (I>maxintensity) maxintensity=I;
    }
    //if (maxintensity<=0.0) goto END;

    gain=125.0/maxintensity;
    for (voxel=0;voxel<voxels;voxel++) charimg.img[voxel] *= gain;
    charimg.scale /= gain;
    }
    else
    {
        charimg.scale=1.0;
        charimg.offset=0.0;
    }

    sprintf(charimg.filename,"%s",fname);
    charimg.DataType=DT_UNSIGNED_CHAR;
    charimg.ImageType=NIFTI;

    if (!Save(&charimg)) goto END;

    result=1;
END:
    ReleaseImage(&charimg);

    return result;
}
//========================================================================================================
int SaveAsBinaryCharImage(struct Image *image)
{
    int result=0;
    int voxel,voxels;
    struct Image charimg;
    char fname[MAX_PATH];

    sprintf(fname,"%s",(*image).filename);
    fname[strlen(fname)-4]='\0';
    sprintf(fname,"%s_binary_char.nii",fname);

    memset(&charimg,0,sizeof(struct Image));
    if (!MakeCopyOfImage(image, &charimg)) goto END;

    voxels=(*image).X*(*image).Y*(*image).Z*(*image).volumes;

    for (voxel=0;voxel<voxels;voxel++)
    {
        if ((*image).img[voxel]) charimg.img[voxel]=1.0;
        else charimg.img[voxel]=0.0;
    }

   charimg.scale=1.0;
   charimg.offset=0.0;


    sprintf(charimg.filename,"%s",fname);
    charimg.DataType=DT_UNSIGNED_CHAR;
    charimg.ImageType=NIFTI;

    if (!Save(&charimg)) goto END;

    result=1;
END:
    ReleaseImage(&charimg);

    return result;
}
