/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"
#include "loader.h"
#include "inhomogeneity.h"
#include "phaseunwrap.h"
#include "tensor.h"
#include "templatefunctions.h"
#include "imageprocess.h"
#include "options.h"
#include "coregister.h"
#include "fitT1.h"
#include "imageprocess.h"

#define MAX_JOBS 100

#define MAX_COMPONENTS_IN_SEQUENCE 10

#define BATCH_EXTRACT_BRAIN 1
#define BATCH_REDUCE_INHOMOGENEITY 2
#define BATCH_REMOVE_BACKGROUND 3
#define BATCH_ROTATE_X 4
#define BATCH_ROTATE_Y 5
#define BATCH_ROTATE_Z 6
#define BATCH_REGISTER_TO_TEMPLATE 7

struct BatchSequence
{
    int component[MAX_COMPONENTS_IN_SEQUENCE];
    double p1[MAX_COMPONENTS_IN_SEQUENCE];
    double p2[MAX_COMPONENTS_IN_SEQUENCE];
    int Ncomponenets;
};


int SaveProcessedFile(struct Image *image, char fname[], char append[]);
//===============================================================================
//save a processed file with a modified file name
//===============================================================================
int SaveProcessedFile(struct Image *image, char fname[], char append[])
{
    int divide;
    char directory[MAX_PATH];

    //save the processed file
    divide=DirectoryFileDivide(fname);
    sprintf(directory,"%s",fname);
    directory[divide+1]='\0';
    sprintf((*image).filename,"%s%s%s",directory, append, &fname[divide+1]);
    if ( ((*image).ImageType=HDR) )
    {
        sprintf((*image).headername,"%s%s%s",directory, append, &fname[divide+1]);
        (*image).headername[strlen((*image).headername)-3]='\0';
        sprintf((*image).headername,"%sHDR",(*image).headername);
    }
    return Save(image);
}



int BatchSequence(HWND hwnd, struct BatchSequence *seq);
//===============================================================================
//GENERAL BATCH SEQUENCE
//===============================================================================
int BatchSequence(HWND hwnd, struct BatchSequence *seq)
{
    char Files[MAX_JOBS][MAX_PATH];
    struct Image image;
    int file, nFiles;

    int comp;

    memset(&image,0,sizeof(struct Image));

    nFiles=0;
    while((nFiles<MAX_JOBS) && GetFileName(Files[nFiles]))
    {
        nFiles++;
    }

    if (!nFiles) goto END;

    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Files[file], &image, 0))
        {
            for (comp=0; comp<(*seq).Ncomponenets; comp++)
            {
                switch ((*seq).component[comp])
                {
                case BATCH_EXTRACT_BRAIN:
                    ExtractBrainByTemplateRegistrationNonParametric(hwnd, &image, REGISTRATION_PARAMETERS_ORDER5);
                    break;
                case BATCH_REDUCE_INHOMOGENEITY:
                    CorrectInhomogeneityUsingTemplateNonParametric(hwnd, &image, 0);
                    break;
                case BATCH_REMOVE_BACKGROUND:
                    AutoRemoveNoisyBackground(hwnd, &image,1);
                    break;
                case BATCH_ROTATE_X:
                    Rotate90(&image, X_AXIS);
                    break;
                case BATCH_ROTATE_Y:
                    Rotate90(&image, Y_AXIS);
                    break;
                case BATCH_ROTATE_Z:
                    Rotate90(&image, Z_AXIS);
                    break;
                case BATCH_REGISTER_TO_TEMPLATE:
                    TemplateRegistration(hwnd, &image);
                    break;
                }
            }
            SaveProcessedFile(&image, Files[file], "Processed_");
        }
    }




END:
    ReleaseImage(&image);

    return nFiles;
}


//===============================================================================
//          Fit T1
//
//===============================================================================
int BatchFitT1(HWND hwnd, int StandardiseScale, int smooth, int MLE)
{

    char Files[MAX_JOBS][MAX_TIs*MAX_PATH];
    char mask[MAX_JOBS][MAX_PATH];
    char directory[MAX_PATH];
    int n[MAX_TIs],nloaded;
    int nJobs=0;
    int job;
    struct Image image;

    memset(Files,0,MAX_JOBS*MAX_TIs*MAX_PATH);
    memset(mask,0,MAX_JOBS*MAX_PATH);
    memset(&image,0,sizeof(struct Image));

    while((nJobs<MAX_JOBS) && (n[nJobs]=GetImageFileNames(Files[nJobs], MAX_PATH, "Select Inversion Images"))&& GetFileNameTitle(mask[nJobs], "Select Mask Image"))
    {
        nJobs++;
    }

    if (!nJobs) return 0;

    for (job=0; job<nJobs; job++)
    {
        nloaded=LoadInversionImagesGivenNames(hwnd, directory, StandardiseScale, Files[job], n[job]);
        LoadFromFileName(hwnd, mask[job], &T1mask, 0);
        FitT1ToIR(hwnd, &image, smooth, StandardiseScale, MLE, nloaded);
        ReleaseImage(&image);
    }

    return nJobs;
}


//===============================================================================
//          Unwrap phase images
//          correct is whether to remove the inhomogeneity
//===============================================================================
int BatchUnwrapPhaseImages(HWND hwnd, int correct)
{

    struct Image image;
    char Files[MAX_JOBS][MAX_PATH];
    int nFiles=0;
    int file;


    memset(&image,0,sizeof(struct Image));

    while((nFiles<MAX_JOBS) && GetFileName(Files[nFiles]))
    {
        nFiles++;
    }

    if (!nFiles) return 0;

    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Files[file], &image, IsMenuItemChecked(hwnd, IDM_LOAD_WITH_STANDARD_SCALE)))
        {
            UnwrapPhaseWrappedImage(hwnd, &image, correct);

            SaveProcessedFile(&image, Files[file], "PHASE_");

            ReleaseImage(&image);
        }
    }

    return nFiles;
}


//===============================================================================
//          Reduce Large Inhomogeneity
//===============================================================================
int BatchReduceInhomogeneity(HWND hwnd, int UseTemplate)
{

    struct Image image;
    char Files[MAX_JOBS][MAX_PATH];
    int nFiles=0;
    int file;

    memset(&image,0,sizeof(struct Image));

    while((nFiles<MAX_JOBS) && GetFileName(Files[nFiles]))
    {
        nFiles++;
    }

    if (!nFiles) return 0;

    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Files[file], &image, 0))
        {

            if (UseTemplate) CorrectInhomogeneityUsingTemplateNonParametric(hwnd, &image, 0);
            else CorrectInhomogeneityUsingClassification(hwnd, &gImage, 4, 2);

            SaveProcessedFile(&image, Files[file], "FLAT_");

            ReleaseImage(&image);
        }
    }

    return nFiles;
}

//===============================================================================
//          ProcessDWI
//===============================================================================
int BatchProcessDWI(HWND hwnd, char execdir[])
{

    struct bMatrix B[MAX_DIFFUSION_DIRECTIONS];
    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];
    struct Image image;
    char BmatName[MAX_JOBS][MAX_PATH];
    char VName[MAX_JOBS][MAX_PATH];
    char DWIname[MAX_JOBS][MAX_PATH];
    OPENFILENAME fnamedlg;
    int jobs, j;
    int Load;
    int directions;
    int Bmatrices;

    jobs=0;
    do
    {
        Load=1;

        BmatName[jobs][0]='\0';
        memset(&fnamedlg,0,sizeof(OPENFILENAME));
        fnamedlg.lStructSize=sizeof(OPENFILENAME);
        fnamedlg.nFilterIndex=1;
        fnamedlg.lpstrFile=BmatName[jobs];
        fnamedlg.nMaxFile=MAX_PATH;
        fnamedlg.lpstrInitialDir=NULL;
        fnamedlg.lpstrTitle="Select B matrix (bmat) File";
        if (!GetOpenFileName(&fnamedlg)) Load=0;

        if (Load)
        {
            VName[jobs][0]='\0';
            memset(&fnamedlg,0,sizeof(OPENFILENAME));
            fnamedlg.lStructSize=sizeof(OPENFILENAME);
            fnamedlg.nFilterIndex=1;
            fnamedlg.lpstrFile=VName[jobs];
            fnamedlg.nMaxFile=MAX_PATH;
            fnamedlg.lpstrInitialDir=NULL;
            fnamedlg.lpstrTitle="Select aquisition direction (bvecs) File";
            if (!GetOpenFileName(&fnamedlg)) Load=0;
        }

        if (Load)
        {
            if (!GetFileName(DWIname[jobs])) Load=0;
        }

        if (Load) jobs++;
    }
    while (Load);

    memset(&image,0,sizeof(struct Image));
    for (j=0; j<jobs; j++)
    {

        if (LoadFromFileName(hwnd, DWIname[j], &image, 0))
        {

            directions=LoadAcquisitionDirectionsGivenFileName(V, VName[j]);

            Bmatrices=LoadbMatricesGivenFileName(B, image.volumes, BmatName[j]);

            if (directions==image.volumes && Bmatrices==image.volumes)
            {
                ProcessDWIGivenBmatAndV(hwnd, &image, B, V);
            }

            ReleaseImage(&image);
        }

    }


    return jobs;
}


//===============================================================================
//          Extract Brain
//===============================================================================
int BatchExtractBrain(HWND hwnd)
{

    struct Image image;
    char Files[MAX_JOBS][MAX_PATH];
    int nFiles=0;
    int file;

    memset(&image,0,sizeof(struct Image));

    while((nFiles<MAX_JOBS) && GetFileName(Files[nFiles]))
    {
        nFiles++;
    }

    if (!nFiles) return 0;

    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Files[file], &image, 0))
        {

            if( ExtractBrainByTemplateRegistrationNonParametric(hwnd, &image, MAX_REGISTRATION_PARAMETERS))
            {

                SaveProcessedFile(&image, Files[file], "BRAIN_");

            }

            ReleaseImage(&image);
        }
    }

    return nFiles;
}



//===============================================================================
//          Extract Brain
//===============================================================================
int BatchRemoveBackground(HWND hwnd)
{

    struct Image image;
    char Files[MAX_JOBS][MAX_PATH];
    int nFiles=0;
    int file;

    memset(&image,0,sizeof(struct Image));

    while((nFiles<MAX_JOBS) && GetFileName(Files[nFiles]))
    {
        nFiles++;
    }

    if (!nFiles) return 0;

    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Files[file], &image, 0))
        {

            if (AutoRemoveNoisyBackground(hwnd, &image,1))
            {
                FreeROIMemory();

                SaveProcessedFile(&image, Files[file], "BKGND_");

            }

            ReleaseImage(&image);
        }
    }

    return nFiles;
}

//===============================================================================
//                       Coregister images as a batch job
//Registration type must be: IDM_BATCH_REGISTER_RIGID or IDM_BATCH_REGISTER_AFFINE or IDM_BATCH_REGISTER_NONLIN
//===============================================================================
int BatchRegisterToTemplate(HWND hwnd, int BrainstemRegister)
{

    char Match[MAX_JOBS][MAX_PATH];
    int file,nFiles;
    int GotMatch;
    struct Image MatchImg;
    char ext[MAX_PATH];

    if (BrainstemRegister) sprintf(ext,"_REG_Brainstem");
    else sprintf(ext,"_REG_Template");

    memset(&MatchImg,0,sizeof(struct Image));


    nFiles=0;

    do
    {
        if ((GotMatch=GetFileNameTitle(Match[nFiles], "Select Match Image"))) nFiles++;
    }
    while((nFiles<MAX_JOBS) && GotMatch);


    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Match[file], &MatchImg, 0))
        {

           if (!BrainstemRegister) TemplateRegistration(hwnd, &MatchImg);
            else TemplateBrainstemRegistration(hwnd, &MatchImg);


         //generate the filename
        MatchImg.filename[strlen(MatchImg.filename)-4]='\0';
        if (MatchImg.ImageType==HDR)
        {
            sprintf(MatchImg.filename,"%s%s.img",MatchImg.filename,ext);
            MatchImg.headername[strlen(MatchImg.headername)-4]='\0';
            sprintf(MatchImg.headername,"%s%s.hdr",MatchImg.headername,ext);
        }
        else
            sprintf(MatchImg.filename,"%s%s.nii",MatchImg.filename,ext);
        Save(&MatchImg);

            ReleaseImage(&MatchImg);
        }
    }

    return nFiles;

}

//===============================================================================
//                       Coregister images as a batch job
//Registration type must be: IDM_BATCH_REGISTER_RIGID or IDM_BATCH_REGISTER_AFFINE or IDM_BATCH_REGISTER_NONLIN
//===============================================================================
int BatchRegister(HWND hwnd, int RegistrationType, int SameBase, double SmoothWidth)
{

    double parameters[MAX_REGISTRATION_PARAMETERS];
    char Match[MAX_JOBS][MAX_PATH];
    char Base[MAX_JOBS][MAX_PATH];
    int nFiles;
    int GotMatch, GotBase;
    int file;
    int Nparameters;
    struct Image MatchImg, BaseImg;
    unsigned char dummy;
    GotMatch=GotBase=0;
    switch(RegistrationType)
    {
        case IDM_BATCH_REGISTER_RIGID:
        case IDM_BATCH_REGISTER_RIGID_SAME_BASE:
        case IDM_BATCH_REGISTER_RIGID_SAME_BASE_UNSMOOTH:
            Nparameters=RIGID6;
            break;

        case IDM_BATCH_REGISTER_AFFINE:
        case IDM_BATCH_REGISTER_AFFINE_SAME_BASE:
        case IDM_BATCH_REGISTER_AFFINE_SAME_BASE_UNSMOOTH:
            Nparameters=AFFINE12;
        break;

        case     IDM_BATCH_REGISTER_NONLIN:
        case     IDM_BATCH_REGISTER_NONLIN_SAME_BASE:
        case     IDM_BATCH_REGISTER_NONLIN_SAME_BASE_UNSMOOTH:
            Nparameters=MAX_REGISTRATION_PARAMETERS;
        break;

        default: return 0;
    }



    memset(&MatchImg,0,sizeof(struct Image));
    memset(&BaseImg,0,sizeof(struct Image));

    nFiles=0;

    if (SameBase)
    {
        if (!(GotBase=GetFileNameTitle(Base[0], "Select Base Image"))) return 0;
    }
    do
    {
        if ((GotMatch=GetFileNameTitle(Match[nFiles], "Select Match Image")))
        {
            if (!SameBase)//either use a different Base each time, or select the Base image for the first time only
            {
                GotBase=GetFileNameTitle(Base[nFiles], "Select Base Image");
            }
            else
            {
                sprintf(Base[nFiles],"%s",Base[0]);//when using the same Base, the nth Base name is the same as the zeroth Base name
            }
            if (GotBase) nFiles++;
        }
    }
    while((nFiles<MAX_JOBS) && GotMatch && GotBase);


    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Match[file], &MatchImg, 0) && LoadFromFileName(hwnd, Base[file], &BaseImg,0))
        {

            InitialiseRegistrationParameters(parameters, Nparameters);
            RegisterTwoImagesP(hwnd, &BaseImg, &MatchImg, parameters, Nparameters, SmoothWidth, &dummy,0);

            SaveRegisteredImage(&BaseImg, &MatchImg,  parameters, Nparameters, 0, ID_CUBIC);

            ReleaseImage(&MatchImg);
            ReleaseImage(&BaseImg);
        }
    }

    return nFiles;

}



//===============================================================================
//                       Apply transformation to images as a batch job
/*
struct BaseDims{
       int X;
       int Y;
       int Zpv;
       float dx;
       float dy;
       float dz;
       float x0;
       float y0;
       float z0;
};*/
//===============================================================================
int BatchApplyTransformation(HWND hwnd)
{

    double *parameters=NULL;
    int Nparameters[MAX_JOBS],n;
    struct BaseDims bd[MAX_JOBS];
    char Imgnames[MAX_JOBS][MAX_PATH];
    char FileTitle[MAX_PATH];
    int nFiles,filestransformed;
    int GotImg;
    int file;
    struct Image Img;

    filestransformed=0;
    nFiles=0;
    memset(&Img,0,sizeof(struct Image));
    if (!(parameters=(double *)calloc(MAX_JOBS*MAX_REGISTRATION_PARAMETERS,sizeof(double)))) goto END;


    do
    {
        if ((GotImg=GetFileNameTitle(Imgnames[nFiles], "Select Image for transformation")))
        {
            n=Nparameters[nFiles]=LoadParameters(&parameters[nFiles*MAX_REGISTRATION_PARAMETERS], MAX_REGISTRATION_PARAMETERS, &bd[nFiles]);
            if (n) nFiles++;
        }
    }
    while((nFiles<MAX_JOBS) && GotImg && n);





    for (file=0; file<nFiles; file++)
    {
        if (LoadFromFileName(hwnd, Imgnames[file], &Img, 0) )
        {

            ReformatMatchImage(bd[file].X, bd[file].Y, bd[file].Zpv, bd[file].dx, bd[file].dy, bd[file].dz, bd[file].x0, bd[file].y0, bd[file].z0,
                                                    &Img, &parameters[file*MAX_REGISTRATION_PARAMETERS], Nparameters[file], ID_CUBIC);


            GetFileTitle(Img.filename, FileTitle, MAX_PATH);
            sprintf(Img.filename,"%s_transformed.nii",FileTitle);
            Save(&Img);

            ReleaseImage(&Img);
            filestransformed++;
        }
    }

END:

    if (parameters) free(parameters);
    return filestransformed;
}
