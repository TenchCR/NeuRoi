/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stats.h"
#include "menuresources.h"
#include "ROIs.h"
#include "global.h"

#define SCROLL_MAX 1000
#define SCROLL_MIN 1


struct ROIedge ROI[MAX_ROI_LENGTH];    //currently selected ROI
int gLength;                           //length of the currently selected ROI
int gSlice;                            //slice of the current selected ROI
int HandleMouseInputStats(HWND hwndStats, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, int *length, int slice, int X, int Y, int zoom);
//=============================================================================================
//                           Stats dialog callback function
//=============================================================================================
INT_PTR CALLBACK StatsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static float  binwidth;                                                         //hi and lo thresholds for binwidth
    int pos;
    char txt[256];


    switch(msg)
    {


    case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hStatsDlg=(HWND)NULL;
        EndDialog(hwnd,0);
        break;





    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        SendMessage(GetDlgItem(hwnd,ID_BINWIDTH),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);
        SendMessage(GetDlgItem(hwnd,ID_BINWIDTH),SBM_SETPOS,SCROLL_MAX/10,TRUE);
        binwidth=0.1;
        sprintf(txt,"Binwidth=%3.1f%%",100.0*binwidth);
        SendMessage(GetDlgItem(hwnd,ID_BINWIDTH_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        break;





    case WM_HSCROLL:
        pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
        switch (LOWORD(wParam))
        {
        case SB_LINELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-1) , TRUE);
            break;
        case SB_LINERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+1) , TRUE);
            break;
        case SB_PAGELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-SCROLL_MAX/10) , TRUE);
            break;
        case SB_PAGERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+SCROLL_MAX/10) , TRUE);
            break;
        case SB_THUMBTRACK:
            SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam) , TRUE);
            break;
        }

        binwidth = (float)SendMessage( GetDlgItem(hwnd,ID_BINWIDTH), SBM_GETPOS, 0, 0)/SCROLL_MAX;

        sprintf(txt,"Binwidth=%3.1f%%",100.0*binwidth);
        SendMessage(GetDlgItem(hwnd,ID_BINWIDTH_TEXT),WM_SETTEXT,0,(LPARAM)txt);
        break;




    case WM_MOUSEMOVE:                                                          //mouse input
    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONDOWN:
    case WM_MBUTTONDOWN:
        HandleMouseInputStats(hwnd, msg, wParam, lParam, &gMainPict, &gLength, gMainPict.slice, gMainPict.X, gMainPict.Y, gMainPict.zoom);
        break;




    case WM_COMMAND:
        switch (LOWORD(wParam))
        {

        case ID_SAVE_IMAGE_HIST:
        case ID_SAVE_ROI_HIST:
            SaveImageHistogram(&gImage, binwidth, (int)LOWORD(wParam));
            break;

        case ID_SAVE_ROI_STATS:
            SaveROIStats(GetParent(hwnd), &gImage, ID_INDIVIDUAL_ROIS);
            break;

        case ID_SAVE_OBJECTS_STATS:
            SaveROIStats(GetParent(hwnd), &gImage, ID_INDIVIDUAL_OBJECTS);
            break;

        case ID_SAVE_ALL_ROIS:
            SaveROIStats(GetParent(hwnd), &gImage, ID_ALL_ROIS);
            break;

        case ID_SAVE_IMAGE_STATS:
            SaveWholeImageStats(&gImage);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;


    }//switch(msg)
    return 0;
}











//=============================================================================================
//                           Show the Selected ROI
//                           Use the global variables ROI & gLength
//=============================================================================================
int DrawSelectedROI(struct Picture *picture, HDC hDC)
{

    if (!gLength || (*picture).slice!=gSlice) return 0;
    DrawROI(picture, hDC, ROI, gLength, Colour(0), 1);
    return 1;
}







//==============================================================================
//                         computes a standardized histogram
//                         width fraction controls how many bins to use
//                         mask limits the voxels included in the histogram
//                         returns the number of voxels included
//                         on output (*hist).min + i*(*hist).binwidth + (*hist).binwidth/2
//                              maps the intensities back to the image intensities
//==============================================================================
int GetStandardizedHistogramStats(struct Image *image, unsigned char mask[], struct Hist *hist, float widthfraction)
{
    GetStandardizedHistogram((*image).img, mask, (*image).X, (*image).Y, (*image).Z,
                             (*image).scale, (*image).offset, (*image).DataType, hist, widthfraction);
    return (*hist).count;
}







//==============================================================================
//              Get intensity of bin from histogram
//              Intensity of bin 0 is (*hist).min
//              Intensity of bin (*hist).N is (*hist).max
//==============================================================================
float IntensityOfBin(struct Hist *hist, int bin)
{
    return (*hist).min + (*hist).binwidth*bin;
}


//==============================================================================
//                       Save the histogram to file
//                       Saved file is normalised so that the area under the
//                          curve =AREA_UNDER_CURVE
//forgot to multiply dA by (*hist).scale, so when this wasnt equal to 1,
//the results wasnt normalised
//Fixed 23 May 2011
//==============================================================================
#define AREA_UNDER_CURVE 1000.0
int SaveHistogramFile(struct Hist *hist, char filename[])
{

    int n;
    double I;
    double area;
    double dA;
    FILE *fp;

    if ( !(*hist).count ) return 0;

    //work out the area of the histogram for normalisation
    area=0.0;
    for (n=0; n<(*hist).N; n++)
    {
        dA=(*hist).H[n]*(*hist).binwidth*(*hist).scale;
        area+=dA;
    }
    if (area<=0.0) return 0;

    if ( (fp=fopen(filename,"w")) )
    {
        for (n=0; n<(*hist).N; n++)
        {
            I=IntensityOfBin(hist, n);
            //save the histogram with the bins scaled appropriately
            fprintf(fp,"%f %f\n",(*hist).offset+(*hist).scale*I,(double)(*hist).H[n]*AREA_UNDER_CURVE/area);
        }
        fclose(fp);
        return 1;
    }

    return 0;
}







//==============================================================================
//                       Save the histogram of image to file
//                       option determines if the ROIs or whole image are used
//                        if option==ID_SAVE_IMAGE_HIST then a histogram of the whole
//                        image is saved
//                        otherwise the ROIs are used to identify the regions
//                        for the histogram
//==============================================================================
int SaveImageHistogram(struct Image *image, float widthfraction, int option)
{

    char filename[MAX_PATH];
    unsigned char *mask=NULL;
    struct Hist hist;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    int result=0;

    if ((option!=ID_SAVE_IMAGE_HIST) && (gNumberOfROIs<1))
    {
        MessageBox(NULL, "No ROIs defined to make histogram","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    if (GetHistogramFileName(filename, 1))
    {
        mask=(unsigned char *)malloc(voxels);
        memset(&hist,0,sizeof(struct Hist));
        if (mask)
        {
            if (option==ID_SAVE_IMAGE_HIST) memset(mask,1,voxels);
            else GetBinaryROImask(mask, (*image).X, (*image).Y, (*image).Z, 0, 0);

            GetStandardizedHistogramStats(image, mask, &hist, widthfraction);
            result=SaveHistogramFile(&hist, filename);

            free(mask);
        }
    }
    return result;
}










//==============================================================================
//                     Get histogram or stats file name
//                     Default extension is txt
//==============================================================================
int GetHistogramFileName(char filename[], int save)
{

    OPENFILENAME fnamedlg;

    filename[0]='\0';

    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Histogram/stats Files\0*.txt\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=filename;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Select histogram/stats file";
    fnamedlg.lpstrDefExt="txt";

    if (!save)
    {
        if(GetOpenFileName(&fnamedlg)) return 1;
    }
    else if(GetSaveFileName(&fnamedlg)) return 1;

    return 0;
}









//=============================================================================================
//                        Handle all the mous inputs for Stats
//=============================================================================================
int HandleMouseInputStats(HWND hwndStats, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, int *length, int slice, int X, int Y, int zoom)
{

    short int xim, yim, zim;
    int sellected=0;
    static int current;
    struct Hist hist;
    struct DescriptiveStats DS;
    char txt[256];

    if (!zoom) return 0;

    PictureToImage(pict, (int)LOWORD(lParam)-gMainPict.xpos, (int)HIWORD(lParam)-gMainPict.ypos, &xim, &yim, &zim, 0);


    switch (msg)
    {



    case WM_LBUTTONDOWN:
        if (!current || ROIs[current].slice!=slice) break;
        GetROIhistogram(&gImage, &hist, current, 0.001);
        DS=GetDescriptiveStatsFromHistogram(&hist);
        sprintf(txt,"%f",DS.mean);
        SendMessage(GetDlgItem(hwndStats,ID_MEAN),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",DS.sd);
        SendMessage(GetDlgItem(hwndStats,ID_SD),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",DS.voxels*gImage.dx*gImage.dy*gImage.dz);
        SendMessage(GetDlgItem(hwndStats,ID_VOLUME),WM_SETTEXT,0,(LPARAM)txt);
        break;



    case WM_MOUSEMOVE:
        sellected=GetNearestROI(xim, yim, slice);
        if (sellected>0 && sellected!=current)
        {
            SendMessage(GetParent(hwndStats), WM_COMMAND, ID_REFRESH,0);
            current=sellected;
            (*length)=ROIs[sellected].length;
            gSlice=slice;
            memcpy(ROI, ROIs[sellected].roi, (*length)*sizeof(struct ROIedge));
        }
        break;

    }


    return 1;
}










//==============================================================================
//              Get a histogram for a single ROI
//              widthfraction (0<=widthfraction<=1) controls how many bins to use
//              *hist contains the histogram on exit
//              roi is the ROI to get the histogram of
//==============================================================================
int GetROIhistogram(struct Image *image, struct Hist *hist, int roi, float widthfraction)
{

    unsigned char *mask;
    int X, Y, Z,XY;
    int voxel, voxels;
    int result=0;

    memset(hist,0,sizeof(struct Hist));

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    XY=X*Y;
    voxels=X*Y*Z;

    if (ROIs[roi].removed)
    {
        (*hist).N=(*hist).count=0;
        return 0;
    }

    mask=(unsigned char *)malloc(voxels);
    if (mask)
    {


        memset(mask,0,voxels);
        if (FloodFillROI(&mask[ROIs[roi].slice*X*Y], X, Y, ROIs[roi].roi, ROIs[roi].length))
        {

            //the way ROIs are defined is that the line falls off the region of interest
            //The edge therefore doesnt form part of the mask, and doesnt affect the statistics.

            for (voxel=ROIs[roi].slice*XY; voxel<(ROIs[roi].slice+1)*XY; voxel++)
            {
                if (mask[voxel]==EDGE) mask[voxel]=0;
            }

            result=GetStandardizedHistogramStats(image, mask, hist, widthfraction);
        }
        free(mask);
    }

    return result;
}










//==============================================================================
//              Get a histogram for a single object
//              If object=-1 then do all objects
//==============================================================================
int GetObjectHistogram(struct Image *image, struct Hist *hist, int object, float widthfraction)
{

    unsigned char *mask;
    unsigned char *slice;
    int X, Y, Z;
    int voxels;
    int pixel;
    int roi;
    int result=0;

    memset(hist,0,sizeof(struct Hist));

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    mask=(unsigned char *)malloc(voxels);
    slice=(unsigned char *)malloc(X*Y);
    if (mask && slice)
    {
        memset(mask,0,voxels);

        for (roi=1; roi<=gNumberOfROIs; roi++)
        {
            if ((!ROIs[roi].removed) && ((ROIs[roi].object==object) || (object==-1)))
            {
                memset(slice,0,X*Y);
                FloodFillROI(slice, X, Y, ROIs[roi].roi, ROIs[roi].length);
                for (pixel=0; pixel<X*Y; pixel++)
                {
                    if (slice[pixel]==FILL) mask[ROIs[roi].slice*X*Y+pixel]=1;
                }
            }
        }
        result=GetStandardizedHistogramStats(image, mask, hist, widthfraction);
    }

    if (mask) free(mask);
    if (slice) free(slice);

    return result;
}










//==============================================================================
//                  Get Descriptive Statistics from histogram
/*
struct DescriptiveStats{
  float mean;
  float min;
  float max;
  float sd;
  float median;
  float Q25;
  float Q75;
  int voxels;
};
struct Hist{
   int *H;                       //the histogram
   int N;                        //the length of the array H
   int count;                    //a normaliser
   float min;                    //the min intensity value
   float max;                    //the max intensity value
   float binwidth;               //the binwidth (I=min+i*binwidth) 0<=i<=N
   float scale;                  //from the Image structure
   float offset;
};*/
//==============================================================================
float EstimateQuantileByInterpolation(int i1, float f1, int i2, float f2, float iq);
struct DescriptiveStats GetDescriptiveStatsFromHistogram(struct Hist *hist)
{

    struct DescriptiveStats DS;
    int bin, count, countbak;
    float I,I1, I1bak;
    float sum2;

    memset(&DS,0,sizeof(struct DescriptiveStats));

    if (!(*hist).count) return DS;

    DS.min=(*hist).offset + (*hist).scale*(*hist).min;
    DS.max=(*hist).offset + (*hist).scale*(*hist).max;


    sum2=0.0;
    count=0;
    I1=0.0;
    for (bin=0; bin<(*hist).N; bin++)
    {
        countbak=count;//needed for interpolation
        I1bak=I1;
        I=IntensityOfBin(hist, bin);                                  //intensity of this bin
        I1=(*hist).offset + (*hist).scale*I;                          //scale to original image intensities
        DS.mean+=I1*(*hist).H[bin];
        sum2+=I1*I1*(*hist).H[bin];
        count+=(*hist).H[bin];
        if (((0.25*(*hist).count)>=countbak) && ((0.25*(*hist).count)<count))
            DS.Q25=EstimateQuantileByInterpolation(countbak, I1bak, count, I1, (float)(0.25*(*hist).count));
        if (((0.5*(*hist).count)>=countbak) && ((0.5*(*hist).count)<count))
            DS.median=EstimateQuantileByInterpolation(countbak, I1bak, count, I1, (float)(0.5*(*hist).count));
        if (((0.75*(*hist).count)>=countbak) && ((0.75*(*hist).count)<count))
            DS.Q75=EstimateQuantileByInterpolation(countbak, I1bak, count, I1, (float)(0.75*(*hist).count));
    }

    DS.voxels=(*hist).count;
    DS.mean/=DS.voxels;
    if ((sum2/DS.voxels - DS.mean*DS.mean)<0.0) DS.sd=0.0;
    else DS.sd=sqrt(sum2/DS.voxels - DS.mean*DS.mean);

    return DS;
}
//==============================================================================
//              Interpolate to get quantile estimates
//              i1<=iq<=i2. iq is some fraction fr between i1 and i2
//              return fr*f2 + (1-fr)*f1
//==============================================================================
float EstimateQuantileByInterpolation(int i1, float f1, int i2, float f2, float iq)
{

    float fr;
    if (i2<=i1) return f1;
    if ((iq<=i1)) return f1;
    if ((iq>=i2)) return f2;

    fr=(float)(iq-i1)/(i2-i1);

    return fr*f2 + (1.0-fr)*f1;
}






//==============================================================================
//                 Save Stats
/*struct DescriptiveStats{
  float mean;
  float min;
  float max;
  float sd;
  float median;
  float Q25;
  float Q75;
  int voxels;
};*/
//==============================================================================
int SaveROIStats(HWND hwnd, struct Image *image, int Mode)
{

    int roi,object, roivoxels;
    FILE *fp;
    char filename[MAX_PATH];
    struct DescriptiveStats DS;
    struct Hist hist;
    float dV=(*image).dx*(*image).dy*(*image).dz;
    char txt[256];
    HDC hDC;
    OPENFILENAME fnamedlg;

    filename[0]='\0';

    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Stats Files\0*.csv\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=filename;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Select stats file";
    fnamedlg.lpstrDefExt="csv";

    memset(&DS,0,sizeof(struct DescriptiveStats));
    memset(&hist,0,sizeof(struct Hist));

    if (!gNumberOfROIs)
    {
        MessageBox(NULL,"No ROIs defined","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    if (GetOpenFileName(&fnamedlg))
    {
        if ((fp=fopen(filename,"w")))
        {
            hDC=GetDC(hwnd);
            if (Mode==ID_INDIVIDUAL_ROIS)
            {

                fprintf(fp,"ROI,Object,Slice,Mean,SD,Median,Q25,Q75,Internal Volume,Internal Voxels,ROI voxels\n");
                for (roi=1; roi<=gNumberOfROIs; roi++)
                {
                    GetROIhistogram(image, &hist, roi, 0.01);
                    DS=GetDescriptiveStatsFromHistogram(&hist);
                    if (DS.voxels) fprintf(fp,"%d,%d,%d,%f,%f,%f,%f,%f,%f,%d,%d\n",
                                               roi, ROIs[roi].object, ROIs[roi].slice, DS.mean,
                                               DS.sd,DS.median,DS.Q25,DS.Q75,DS.voxels*dV, DS.voxels, ROIs[roi].length-2);
                    sprintf(txt,"roi %d of %d",roi,gNumberOfROIs);
                    TextOut(hDC,100,100,txt,strlen(txt));
                    RemoveInput(hwnd); //stops the window becoming unresponsive
                }

            }
            else if (Mode==ID_INDIVIDUAL_OBJECTS)
            {
                fprintf(fp,"Object,Mean,SD,Median,Q25,Q75,Internal Volume,Internal Voxels, ROI voxels\n");
                for (object=1; object<=gNumberOfObjects; object++)
                {
                    roivoxels=0;
                    for (roi=1; roi<=gNumberOfROIs; roi++)
                    {
                        if (ROIs[roi].object==object) roivoxels += ROIs[roi].length-2;
                    }
                    GetObjectHistogram(image, &hist, object, 0.01);
                    DS=GetDescriptiveStatsFromHistogram(&hist);
                    if (DS.voxels) fprintf(fp,"%d,%f,%f,%f,%f,%f,%f,%d,%d\n",
                                               object, DS.mean, DS.sd,DS.median,DS.Q25,DS.Q75,DS.voxels*dV, DS.voxels,roivoxels);
                    sprintf(txt,"object %d of %d",object,gNumberOfObjects);
                    TextOut(hDC,100,100,txt,strlen(txt));
                    RemoveInput(hwnd); //stops the window becoming unresponsive
                }
            }
            else
            {
                fprintf(fp,"Mean,SD,Median,Q25,Q75,Volume,Voxels\n");

                GetObjectHistogram(image, &hist, -1, 0.01);
                DS=GetDescriptiveStatsFromHistogram(&hist);
                if (DS.voxels) fprintf(fp,"%f,%f,%f,%f,%f,%f,%d\n",
                                           DS.mean, DS.sd,DS.median,DS.Q25,DS.Q75,DS.voxels*dV, DS.voxels);
            }
            ReleaseDC(hwnd,hDC);

            fprintf(fp,"\n%s\n",(*image).filename);
            fclose(fp);
            return 1;
        }
    }

    return 0;
}



//==============================================================================
//                 Save histogram of the whole image
/*struct DescriptiveStats{
  float mean;
  float min;
  float max;
  float sd;
  float median;
  float Q25;
  float Q75;
  int voxels;
};*/
//==============================================================================
int SaveWholeImageStats(struct Image *image)
{

    FILE *fp;
    char filename[MAX_PATH];
    struct DescriptiveStats DS;
    struct Hist hist;
    unsigned char *mask=NULL;
    int result=0;
    int voxels=(*image).X*(*image).Y*(*image).Z;
    float dV=(*image).dx*(*image).dy*(*image).dz;

    mask=(unsigned char *)malloc(voxels);
    memset(&hist,0,sizeof(struct Hist));

    if (mask && GetHistogramFileName(filename, 1))
    {
        if ((fp=fopen(filename,"w")))
        {
            memset(mask,1,voxels);
            GetStandardizedHistogramStats(image, mask, &hist, 0.01);
            DS=GetDescriptiveStatsFromHistogram(&hist);

            fprintf(fp,"Mean SD Median Q25 Q75 Volume Voxels\n");
            if (DS.voxels) fprintf(fp,"%f %f %f %f %f %f %d\n",
                                       DS.mean, DS.sd,DS.median,DS.Q25,DS.Q75,DS.voxels*dV, DS.voxels);

            fprintf(fp,"\n%s\n",(*image).filename);
            fclose(fp);
            result=1;
        }
    }

    if (mask) free(mask);

    return result;
}
















//==============================================================================
//              Combine histograms
//              Load each histogram, normalize, and add
//              Create a combined histogram
//              Then save normalized
//==============================================================================
int GetHistogramFileNames(char names[]);
int GetMinAndMaxBin(char file[], double *min, double *max, double *width);
int LoadHistogram(char file[], double bin[], double frequency[], double *width);
double Frequecy(double bin[], double frequency[], int bins, double x);
double Normalize(double bin[], double frequency[], int bins, double *mean, double *SD, double *medeian);
int SaveHistogram(double bin[], double frequency[], int bins, char name[]);
int FileNameRepeated(int last);
#define MAX_HISTOGRAMS 256
#define MAX_BINS 2048
#define MAX_HISTOGRAM_FILES 50
char HistogramFiles[MAX_HISTOGRAMS][MAX_PATH];//PUT THE FILENEMES HERE
int CombineHistogramFiles(void)
{

    char Names[MAX_HISTOGRAM_FILES*MAX_PATH];//should allow many files to be selected simultaneously
    char name[MAX_PATH];
    int FilesSelected;
    int count=0;
    int i,j;
    int Nbins,Cbins;
    double min,max,a,b,c;
    double binwidth;
    double bin[MAX_BINS];
    double frequency[MAX_BINS];
    double norm[MAX_HISTOGRAMS];
    double Bcomb[MAX_BINS];
    double Fcomb[MAX_BINS];
    double median[MAX_HISTOGRAMS], SD[MAX_HISTOGRAMS], mean[MAX_HISTOGRAMS];
    FILE *fp;

    //initialise the memory
    for (i=0; i<MAX_HISTOGRAMS; i++) memset(&HistogramFiles[i][0],0,MAX_PATH);
    memset(norm,0,sizeof(double)*MAX_HISTOGRAMS);//the normaliser




    //get the histogram filenames
    while( (FilesSelected=GetHistogramFileNames(Names)) &&  count<MAX_HISTOGRAMS)
    {

        if (FilesSelected==1)
        {
            if (count<MAX_HISTOGRAMS)
            {
                sprintf(HistogramFiles[count],"%s",Names);
                if (!FileNameRepeated(count)) count++;
                else MessageBox(NULL,"Histogram already loaded.","",MB_OK|MB_ICONWARNING);
            }
            else MessageBox(NULL,"Max number of histograms reached.","",MB_OK|MB_ICONWARNING);
        }
        else
        {
            for (i=1; i<=FilesSelected; i++)
            {
                if (count<MAX_HISTOGRAMS)
                {
                    GetNthFileName(Names, i, HistogramFiles[count]);
                    if (!FileNameRepeated(count)) count++;
                    else MessageBox(NULL,"Histogram already loaded.","",MB_OK|MB_ICONWARNING);
                }
                else MessageBox(NULL,"Max number of histograms reached.","",MB_OK|MB_ICONWARNING);
            }
        }
    }

    if (!count) return 0;

    //get the min and max of these histograms
    min=DBL_MAX;
    max=0.0;
    binwidth=DBL_MAX;
    for (i=0; i<count; i++)
    {
        if (GetMinAndMaxBin(HistogramFiles[i], &a, &b, &c))
        {
            if (a>0.0 && a<min) min=a;
            if (b>max) max=b;
            if (c<binwidth) binwidth=c;//minimize the binwidth
        }
    }
    if (binwidth<=0.0) return 0;




    Cbins=(max-min)/binwidth+1;
    if (Cbins>MAX_BINS)
    {
        MessageBox(NULL,"Failed! Number of bins too large.","",MB_OK|MB_ICONWARNING);
        return 0;
    }


    memset(Bcomb,0,sizeof(double)*MAX_BINS);
    Bcomb[0]=min;
    for (i=1; i<Cbins; i++)
    {
        Bcomb[i]=Bcomb[i-1] + binwidth;
    }

    memset(Fcomb,0,sizeof(double)*MAX_BINS);
    for (i=0; i<count; i++)
    {
        memset(frequency,0,sizeof(double)*MAX_BINS);//the frequencies
        memset(bin,0,sizeof(double)*MAX_BINS);//the bins
        if ( (Nbins=LoadHistogram(HistogramFiles[i], bin, frequency, &c)) )
        {
            norm[i]=Normalize(bin, frequency, Nbins, &mean[i], &SD[i], &median[i]);
            if (norm[i]>0.0)
            {
                for (j=0; j<Cbins; j++)
                {
                    Fcomb[j]+=Frequecy(bin, frequency, Nbins, Bcomb[j])/norm[i];//need to normalize
                }
            }
        }
    }




    //now save the histogram
    if (SaveHistogram(Bcomb, Fcomb, Cbins, name))
    {
        name[(strlen(name)-4)]='\0';
        sprintf(name,"%s_summary.txt",name);
        if ((fp=fopen(name,"w")))
        {
            fprintf(fp,"HistogramFiles mean SD Median Area\n");
            for (i=0; i<count; i++)
            {
                fprintf(fp,"%s %f %f %f %f\n",HistogramFiles[i], mean[i], SD[i], median[i], norm[i]);
            }
            //now the summary stats of the combined histogram
            norm[0]=Normalize(Bcomb, Fcomb, Cbins, &mean[0], &SD[0], &median[0]);
            fprintf(fp,"Combined Histogram %f %f %f %f\n", mean[0], SD[0], median[0], norm[0]);
            fclose(fp);
        }
    }


    return 1;
}


//=============================================================================================
//              Checks the histogram filenames to see if the last one is a repeat of any
//              previous filenames
//=============================================================================================
int FileNameRepeated(int last)
{

    int i;
    for (i=0; i<last; i++)
    {
        if (strstr(HistogramFiles[i], HistogramFiles[last])) return 1;
    }

    return 0;
}



//=============================================================================================
//                  Get frequency
//=============================================================================================
double Frequecy(double bin[], double frequency[], int bins, double x)
{

    int i;
    double del;
    double binwidth=bin[1]-bin[0];

    if (binwidth<=0.0) return 0.0;

    //return 0 if x outside histogram range
    if (x<(bin[0]-binwidth/2)) return 0.0;
    if (x>(bin[bins-1]+binwidth/2)) return 0.0;

    for (i=0; i<bins; i++)
    {
        if (x<bin[i])
        {
            del=(bin[i]-x)/binwidth;
            if (i>0) return del*frequency[i-1]+(1-del)*frequency[i];
            else return  (1-del)*frequency[i];
        }
    }
    if (x>=bin[bins-1]) return (1.0-(x-bin[bins-1])/binwidth)*frequency[bins-1];
    return 0.0;
}





//=============================================================================================
//                  Get histogram area and statistics
//=============================================================================================
double Normalize(double bin[], double frequency[], int bins, double *mean, double *SD, double *median)
{

    int i,iprev;
    double area;
    double width=bin[1]-bin[0];
    double dA;
    double sum,sum2;
    double frac, prev;
    double x;
    //char txt[256];

    sum=sum2=0.0;
    area=0.0;
    for (i=0; i<bins; i++)
    {
        dA=frequency[i]*width;
        if ((i==0) || (i==bins-1)) dA/=2.0;//half width bins at end points
        area+=dA;
        sum+=bin[i]*dA;
        sum2+=pow(bin[i],2)*dA;
    }
    if (area<=0.0) return 0;


    //find the median
    frac=0.0;
    i=0;
    do
    {
        prev=frac;
        iprev=i;
        dA=frequency[i]*width/area;
        if ((i==0) || (i==bins-1)) dA/=2.0;//half width bins at end points
        frac+=dA;
        i++;
    }
    while((frac<0.5) && (i<bins));
    //now frac should be >0.5, and prev<0.5
    //0.5=prev + (frac-prev)/width*x
    if (frac>prev) x=(0.5-prev)*width/(frac-prev);//frac must always be > prev
    else x=0.5*width;
    (*median)=bin[iprev]+x;
    //sprintf(txt,"frac=%f prev=%f x=%f",frac, prev, x/width);
    //MessageBox(NULL,txt,"",MB_OK);


    (*mean)=sum/area;
    (*SD)=sqrt(sum2/area - sum*sum/area/area);

    return area;
}


//=============================================================================================
//                              Get the OPEN filename(s)
//                              allows for multiple selections
//                              names must have a length at least 2*MAX_PATH
//=============================================================================================
int GetHistogramFileNames(char names[])
{

    OPENFILENAME fn;

    names[0]='\0';
    memset(&fn,0,sizeof(OPENFILENAME));
    fn.lStructSize=sizeof(OPENFILENAME);
    fn.hwndOwner=NULL;
    fn.lpstrFilter="Histogram Files\0*.txt;\0\0";
    fn.lpstrCustomFilter=NULL;
    fn.nFilterIndex=1;
    fn.lpstrFile=names;
    fn.nMaxFile=MAX_PATH*2;//this needs to be long enough to contain the directory and filenames
    fn.lpstrInitialDir=NULL;
    fn.lpstrTitle="Select Histograms(s)";
    fn.lpstrDefExt="txt";
    fn.Flags=OFN_ALLOWMULTISELECT|OFN_EXPLORER;

    if (GetOpenFileName(&fn)) return NumberOfFiles(names);

    return 0;
}



//=============================================================================================
//                              Get the OPEN filename(s)
//                              allows for multiple selections
//                              names must have a length at least 2*MAX_PATH
//=============================================================================================
int SaveHistogram(double bin[], double frequency[], int bins, char name[])
{

    FILE *fp;
    OPENFILENAME fn;
    double norm, mean, median, SD;
    int i;
    int save, ans;

    name[0]='\0';
    memset(&fn,0,sizeof(OPENFILENAME));
    fn.lStructSize=sizeof(OPENFILENAME);
    fn.hwndOwner=NULL;
    fn.lpstrFilter="Histogram Files\0*.txt;\0\0";
    fn.lpstrCustomFilter=NULL;
    fn.nFilterIndex=1;
    fn.lpstrFile=name;
    fn.nMaxFile=MAX_PATH;
    fn.lpstrInitialDir="./";
    fn.lpstrTitle="Select Histograms(s)";
    fn.lpstrDefExt="txt";

    do
    {
        if ((save=GetSaveFileName(&fn)))
        {
            norm=Normalize(bin, frequency, bins, &mean, &SD, &median);
            if ((fp=fopen(name,"w")) && (norm>0.0))
            {
                for (i=0; i<bins; i++)
                {
                    fprintf(fp,"%f %f\n",bin[i],frequency[i]/norm);
                }
                fclose(fp);
                return 1;
            }
        }
        if (!save)
        {
            ans=MessageBox(NULL,"No file selected to save histogram.\nTry again?","",MB_RETRYCANCEL|MB_ICONWARNING);
            if (ans==IDCANCEL) return 0;
        }
    }
    while(!save);


    return 0;
}



//=============================================================================================
//          Return the min and max bin value of the histogram in file[]
//=============================================================================================
int GetMinAndMaxBin(char file[], double *min, double *max, double *width)
{

    double bin[MAX_BINS];
    double frequency[MAX_BINS];
    int bins;

    memset(frequency,0,sizeof(double)*MAX_BINS);//the frequencies
    memset(bin,0,sizeof(double)*MAX_BINS);//the bins

    //load the histogram
    bins=LoadHistogram(file, bin, frequency, width);


    if (!bins) return 0;

    //work out the lowest and highest bin
    (*min)=bin[0];
    (*max)=bin[bins-1];


    return bins;
}

//=============================================================================================
//          Load the histogram into bin[] and frequency[]
//          return the number of bins
//=============================================================================================
int LoadHistogram(char file[], double bin[], double frequency[], double *width)
{

    FILE *fp;
    float a,b;
    int i=0;

    if (!(fp=fopen(file,"r"))) return 0;


    while(!feof(fp) && i<MAX_BINS)
    {
        fscanf(fp,"%f %f",&a,&b);
        bin[i]=a;
        frequency[i]=b;
        i++;
    }

    if (fp) fclose(fp);

    (*width)=bin[1]-bin[0];

    if ((*width)<=0.0)  return 0;

    return i-1;
}





