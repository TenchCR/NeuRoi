/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Rois_H)
//Do Nothing
#else
#define Rois_H
//--------------------------------------------------------------------------------------------
//                   routines for handling regions of interest
//                              19th Feb 2009
//--------------------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "display.h"





#define EDGE 2
#define FILL 3

#define MAX_ROI_LENGTH 10000
#define MAX_ROIS       6000

//ROI types                                 //numbers chosen to maintain compatibility with NeuRoi1
#define SQUARE         0
#define ELLIPSE         1
#define CLOSED         2
#define AUTO           3
#define LIMIT          4
#define NOROI          10                   //when ROI type is undefined



struct ROIedge{
  short int x;
  short int y;
};

struct XY{
  short int x;
  short int y;
};
struct XYZ{
  short int x;
  short int y;
  short int z;
};

struct ROI{
       struct ROIedge *roi;                  //the points that make the ROI
       char type;                            //type of roi
       short int slice;                      //slice in the image
       short int length;                     //
       short int Xseed;                      //seed point
       short int Yseed;
       short int object;                     //the object number. Many ROIs can have the same object number
       char removed;                         //has this ROI been deleted?
};

struct FillList{                             //used in flood fill algorithm
	short int x;
	short int y;
};


struct ROI ROIs[MAX_ROIS];
int gNumberOfROIs;                           //how many ROIs have been defined, including deleted ones
int gNumberOfObjects;                        //how many objects have been defined




int AcceptROI(int X, int Y, struct ROIedge ROI[], int length, int Xseed, int Yseed, int slice, int numrois, int object, char ROItype);

COLORREF Colour(int n);
int ConvertToROI(struct ROIedge init[], int initlength, struct ROIedge final[]);
int ConvertObjectToROIs(HWND hwnd, struct Image *image);
int CompareROIobjectMasks(HWND hwnd, struct Image *ROIobj1);
int CheckAndRepairROI(struct ROI *ROI);


int DrawAllROIs(struct Picture *picture, HDC hDC, int slice, int width, int DrawLimits);
//int DrawAllROIsObjectNumber(struct Picture *picture, HDC hDC);
int DrawAllROIsObjectNumber(struct Picture *picture, HDC hDC, int x0, int y0, float zoom);
int DrawROI(struct Picture *picture, HDC hDC, struct ROIedge ROI[], int length, COLORREF col, int width);

int FloodFillROI(unsigned char mask[], int X, int Y, struct ROIedge ROI[], int length);
int FloodFillToRegionEdge(unsigned char Mask[], int X, int Y, int Xseed, int Yseed);
int FloodFillToRegionEdgeFast(unsigned char Mask[], int X, int Y, int Xseed, int Yseed, struct FillList *list);
int RegionEdgeDetect(unsigned char image[], int XP, int YP, struct ROIedge ROI[], int L);
int FloodFillLimited(float image[], unsigned char result[], unsigned char Limit[], int X, int Y, int Xseed, int Yseed, float MIN, float MAX);
int FloodFillImage(float image[], unsigned char result[], int X, int Y, int Xseed, int Yseed, float MIN, float MAX);
int FloodFillImage3D(float image[], unsigned char result[], int X, int Y, int Z, int Xseed, int Yseed, int Zseed, float MIN, float MAX);
int FreeROIMemory(void);


int Grow2Dregion(unsigned char mask[], int X, int Y);
int GetNearestROI(int x, int y, int slice);
int GetBinaryROImask(unsigned char mask[], int X, int Y, int Z, int object, int IncludeEdge);
int GetROInumberMask(short int mask[], int X, int Y, int Z, int object, int IncludeEdge);
int GetSizedObjectsImage(HWND hwnd, float *SizedObjects, int X, int Y, int Z, int CountLabel);


int IsROIrepeated(int X, int Y, struct ROIedge ROI[], int slice, int XSEED, int YSEED, int length);

int LoadROIs(int X, int Y, int Z);

int ReNumberROIObjects(HWND hwnd, struct Image *image);

int SaveROIs(int BackUp, int X, int Y, int Z);
int SaveROIobject(struct Image *image, int binary);
int SaveROIcentroidsAndCharaceristicSizes(struct Image *image);

int TestROIenclosedAngle(struct Image *image);
#endif
