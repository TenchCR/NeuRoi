/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#define MAX_CLASSES 50

#include "classification.h"
#include "stats.h"
#include "numerical.h"


//==============================================================================
//Given vol, produce a new image (classimg) that has classes with intensities means as defined by fuzzy clustering
//means dont have to be initialised on entry
//classes must be < 100
//classimg must be malloced and contain a mask on entry; for whole brain just set all voxels to 1
//*img is unchanged on exit
//==============================================================================
int Fuzzy_cMeansClustering(float *img, unsigned char *classimg, int X, int Y, int Zpv, int classes, double means[], int iterations)
{


	struct Hist hist;
	float mu[MAX_CLASSES];
	float max;
	int cl;
	int voxel,voxels;
	int best, sort[MAX_CLASSES];
//	char txt[2048];

	if (classes>=MAX_CLASSES)
		classes=MAX_CLASSES;
	if (classes<1)
		return 0;

	voxels=X*Y*Zpv;
	if ((!voxels) || (!classimg))
		return 0;


	GetStandardizedHistogram(img, classimg, X, Y, Zpv,1.0, 0.0, DT_FLOAT, &hist, 0.01);

	//------------set the initial means-------------------
	for (cl=0; cl<classes; cl++)
		means[cl]=hist.min + (hist.max-hist.min)*cl/classes;
	//----------------------------------------------------


	if (!FuzzyClassifyHistogram(hist.H, hist.N, iterations, means, classes))
    {
        return 0;
    }



	QuickSort(means, sort, classes);
	for (cl=0; cl<classes; cl++)
		mu[cl]=means[sort[cl]];

	//rescale the intensities
	for (cl=0; cl<classes; cl++)
		means[cl]=hist.min + (mu[cl])*hist.binwidth;


	//Now we have found the means that do the clustering, compute the class image
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (fabs(img[voxel])>0.0)
		{
			max=fabs(img[voxel]-means[0]);
			best=0;
			for (cl=1; cl<classes; cl++)
			{
				if (fabs(img[voxel]-means[cl])<max)
				{
					best=cl;
					max=fabs(img[voxel]-means[cl]);
				}
			}
			classimg[voxel]=best+1;
		}
		else
			classimg[voxel]=0;
	}



	return 1;
}
//==============================================================================
int FuzzyClassifyHistogram(int *H, int N, int iterations, double means[], int classes)
{
	int iter;
	int I;
	int cl,cl1;
	double tmp;
	float mu[MAX_CLASSES], sum, sum1[MAX_CLASSES], sum2[MAX_CLASSES];

	if (classes>MAX_CLASSES)
    {
        MessageBox(NULL,"Too many classes in FuzzyClassifyHistogram","",MB_OK);
        return 0;
    }

	for (iter=0; iter<iterations; iter++)
	{
		memset(sum1,0,sizeof(float)*classes);
		memset(sum2,0,sizeof(float)*classes);
		for (I=0; I<N; I++)
		{
			if (H[I])
			{

				//=========calculate membership function for intensity I=============
				memset(mu,0,sizeof(float)*classes);
				for (cl1=0; cl1<classes; cl1++)
				{
					sum=0.0;
					tmp=(I-means[cl1])*(I-means[cl1]);
					for (cl=0; cl<classes; cl++)
					{
						if (fabs(I-means[cl])>0.0)
							sum+=tmp/(I-means[cl])/(I-means[cl]);
						else
							sum+=1.0e6;//make it unlikely to be assigned to another class if its exactly the same as one of the means means
					}
					if (fabs(sum)>0.0)
						mu[cl1]=1.0/sum;
					else
						mu[cl1]=0.0;
				}
				//===================================================================

				//-------------compute contribution from this intensity to the means-----------
				for (cl=0; cl<classes; cl++)
				{
					tmp = H[I]*mu[cl]*mu[cl];
					sum1[cl]+=I*tmp;
					sum2[cl]+=tmp;
				}
				//-----------------------------------------------------------------------------

			}

		}

		//==========update the means for this iteration=========
		for (cl=0; cl<classes; cl++)
		{
			if (fabs(sum2[cl])>0.0)
				means[cl]=sum1[cl]/sum2[cl];
			else
				means[cl]=0.0;
		}
		//======================================================

	}

	return 1;
}

//==============================================================================
//                  test the fuzzy classification
//==============================================================================
#define TEST_CLASSES 5
int TestFuzzyClassification(struct Image *image)
{

	double means[TEST_CLASSES];
	int voxel;
	int voxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;

	if ((*image).charimg)
		free((*image).charimg);
	(*image).charimg=(unsigned char *)malloc(voxels);

	if ((*image).charimg)
	{
		memset((*image).charimg,1,voxels);
		if (Fuzzy_cMeansClustering((*image).img, (*image).charimg, (*image).X, (*image).Y, (*image).Z/(*image).volumes,
		                           TEST_CLASSES, means, 100))
		{

			for (voxel=0; voxel<voxels; voxel++)
			{
				(*image).img[voxel]=means[(*image).charimg[voxel]-1];
			}
		}
		else
			MessageBox(NULL,"failed to classify","",MB_OK|MB_ICONWARNING);
	}

	if ((*image).charimg)
	{
		free((*image).charimg);
		(*image).charimg=NULL;
	}
	return 1;
}


//==============================================================================
//              Multi-Volume Classifier
//              Assume each class is Multivariate Normal
//==============================================================================
int MultiVolumeClassification(struct Image *image, int classes, int iterations)
{

	int X, Y, Zpv;
	int vol,volumes;
	int result=0;
	int voxel, voxels;
	int cl;
	int i;
	int iter;
	int *sort=NULL;
	double *mag=NULL;
	double *mu=NULL;
	double *sd=NULL;
	double *lnsd=NULL;
	double sum, sum2, norm, tmp;
	float *probs=NULL;
	float max;
	float *quantiles=NULL;

	if (classes<2)
		return 0;

	X=(*image).X;
	Y=(*image).Y;
	Zpv=(*image).Z/(*image).volumes;
	volumes=(*image).volumes;
	voxels=X*Y*Zpv;


	if (!(quantiles=(float *)malloc(sizeof(float)*(classes-1))))
		goto END;

	if (!(mu=(double *)malloc(sizeof(double)*classes*volumes)))
		goto END;

	if (!(sd=(double *)malloc(sizeof(double)*classes*volumes)))
		goto END;

	if (!(lnsd=(double *)malloc(sizeof(double)*classes*volumes)))
		goto END;

	if (!(probs=(float *)malloc(sizeof(float)*(classes+1)*voxels)))
		goto END;

	if (!(mag=(double *)malloc(sizeof(double)*classes)))
		goto END;

	if (!(sort=(int *)malloc(sizeof(int)*classes)))
		goto END;



	for (cl=1; cl<classes; cl++)
		quantiles[cl-1]=(float)cl/classes;

	Quantiles((*image).img, voxels, quantiles, classes-1);

//ASSIGN INITIAL CLASSES
	memset(probs,0,sizeof(float)*(classes+1)*voxels);
	for (voxel=0; voxel<voxels; voxel++)
	{
		tmp=(*image).img[voxel];
		if ( fabs(tmp)>0.0 )
		{
			cl=0;
			for (i=0; i<classes-1; i++)
				if (tmp>quantiles[i])
                {
                    cl=i+1;
                }

			probs[(cl+1)*voxels+voxel]=1.0;//this voxel is initially classified as class cl
		}
	}


//ITERATE THE PARAMETER ESTIMATION WITH PROBABILITY UPDATES
	iter=0;
	do
	{
		//UPDATE THE PARAMETERS
		memset(mu,0,sizeof(double)*classes*volumes);
		memset(sd,0,sizeof(double)*classes*volumes);
		memset(lnsd,0,sizeof(double)*classes*volumes);
		for (cl=0; cl<classes; cl++)
		{
			for (vol=0; vol<volumes; vol++)
			{
				norm=sum=sum2=0.0;
				for (voxel=0; voxel<voxels; voxel++)
				{
					if ((*image).img[voxel]>0.0)
					{
						tmp=(*image).img[voxel+vol*voxels];
						sum+=probs[(cl+1)*voxels+voxel]*tmp;
						sum2+=probs[(cl+1)*voxels+voxel]*tmp*tmp;
						norm+=probs[(cl+1)*voxels+voxel];
					}
				}
				if (norm>0.0)
				{
					mu[vol+cl*volumes]=sum/norm;
					sd[vol+cl*volumes]=sqrt(sum2/norm-sum*sum/norm/norm);
					if (sd[vol+cl*volumes]<=0.0)
						sd[vol+cl*volumes]=mu[vol+cl*volumes]/100.0;
					if (sd[vol+cl*volumes]<=0.0)
						sd[vol+cl*volumes]=1.0;
					lnsd[vol+cl*volumes]=log(sd[vol+cl*volumes]);
				}
			}
		}


		//UPDATE THE PROBABILITIES
		for (voxel=0; voxel<voxels; voxel++)
		{
			if ((*image).img[voxel]>0.0)
			{
				sum=0.0;
				for (cl=0; cl<classes; cl++)
				{
					probs[voxel+(cl+1)*voxels]=0.0;
					for (vol=0; vol<volumes; vol++)
					{
						probs[voxel+(cl+1)*voxels]+=-pow(((*image).img[voxel+vol*voxels]-mu[vol+cl*volumes])/sd[vol+cl*volumes],2)/2.0;
						probs[voxel+(cl+1)*voxels]-=lnsd[vol+cl*volumes];
					}
					probs[voxel+(cl+1)*voxels]=exp(probs[voxel+(cl+1)*voxels]);
					sum+=probs[voxel+(cl+1)*voxels];
				}
				if (sum>0.0)
				{
					max=0.0;
					i=0;
					for (cl=0; cl<classes; cl++)
					{
						probs[voxel+(cl+1)*voxels]/=sum;
						if (probs[voxel+(cl+1)*voxels]>max)
						{
							max=probs[voxel+(cl+1)*voxels];
							i=cl+1;
						}
					}
					probs[voxel]=(float)i;
				}
			}
		}

		iter++;
	}
	while (iter<iterations);

	//sort the means assosiated with the first volume
	for (cl=0; cl<classes; cl++)
		{
		    mag[cl]=fabs(mu[cl*volumes]);
		}

	QuickSort(mag, sort, classes);

	//sort the probabilities into largest mean order
	for (voxel=0; voxel<voxels; voxel++)
	{
		for (cl=0; cl<classes; cl++)
		{
			mag[cl]=probs[voxel+(sort[classes-1-cl]+1)*voxels];
		}
		for (cl=0; cl<classes; cl++)
		{
			probs[voxel+(cl+1)*voxels]=mag[cl];
		}
	}


	free((*image).img);
	(*image).img=NULL;
	(*image).img=(float *)malloc(sizeof(float)*(classes+1)*voxels);
	if ((*image).img)
	{
		memcpy((*image).img, probs, sizeof(float)*(classes+1)*voxels);
		(*image).volumes=classes+1;
		(*image).Z=(classes+1)*Zpv;
		(*image).MaxIntensity=(float)classes;
	}
	else
		goto END;


	result=1;
END:
	if (mu)
		free(mu);

	if (sd)
		free(sd);

	if (lnsd)
		free(lnsd);

	if (probs)
		free(probs);

	if (quantiles)
		free(quantiles);

	if (mag)
		free(mag);

    if (sort)
        free(sort);

	return result;
}


//==============================================================================
//              Single-Volume Classifier
//              Assume each class is Normal
//              Return the probability a voxel is of a class in probs[]
//                  which has as many volumes as there are classes
//==============================================================================
int SingleVolumeClassification(struct Image *image, int classes, unsigned char probs[], int iterations)
{

	int H[1001];
	int X, Y, Zpv;
	int result=0;
	int voxel, voxels;
	int cl,cl2;
	int i;
	int iter;
	int count;
	int *sort=NULL;
	double *mu=NULL;
	double *sd=NULL;
	double sum, sum2, norm, norm2, tmp;
	float *quant=NULL;
	float max;
	float e,etmp;

	if (classes<2)
		return 0;

	X=(*image).X;
	Y=(*image).Y;
	Zpv=(*image).Z/(*image).volumes;
	voxels=X*Y*Zpv;

	if (!(quant=(float *)malloc(sizeof(float)*classes)))
		goto END;
	if (!(mu=(double *)malloc(sizeof(double)*classes)))
		goto END;
	if (!(sd=(double *)malloc(sizeof(double)*classes)))
		goto END;
	if (!(sort=(int *)malloc(sizeof(int)*classes)))
		goto END;


	for (cl=0; cl<classes; cl++)
		quant[cl]=(float)(cl+1)/(classes+1);
	Quantiles((*image).img, voxels, quant, classes);
	for (cl=0; cl<classes; cl++)
		mu[cl]=(double)quant[cl];


//GET MAX
	max=0.0;
	sum=0.0;
	sum2=0.0;
	count=0;
	for (voxel=0; voxel<voxels; voxel++)
	{
		tmp=(*image).img[voxel];
		if ( fabs(tmp)>0.0 )
		{
			if (tmp>max)
				max=tmp;
			sum+=tmp;
			sum2+=tmp*tmp;
			count++;
		}
	}
	if ((fabs(max)<=0.0) || (sum2-sum*sum/count)<=0.0)
		goto END;

	//INITIALISE sd[]
	for (cl=0; cl<classes; cl++)
		sd[cl]=sqrt((sum2/count-sum*sum/count/count)/classes);


//COMPUTE THE HISTOGRAM
	memset(H,0,sizeof(int)*1001);
	for (voxel=0; voxel<voxels; voxel++)
	{
		if ( (tmp=(*image).img[voxel])>0.0 )
		{
			i=1000*tmp/max;
			if (i>=0 && i<1001)
				H[i]++;
		}
	}



//ITERATE THE PARAMETER ESTIMATION WITH PROBABILITY UPDATES
	iter=0;
	do
	{
		//UPDATE THE PARAMETERS
		for (cl=0; cl<classes; cl++)
		{
			norm=sum=sum2=0.0;
			for (i=0; i<1001; i++)
			{
				tmp=max/1000.0*i;
				norm2=0.0;
				for (cl2=0; cl2<classes; cl2++)
				{
					etmp=exp(-pow((tmp-mu[cl2])/sd[cl2],2)/2.0)/sd[cl2];
					norm2+=etmp;
					if (cl2==cl)
						e=etmp;
				}
				if (norm2>0.0)
					e/=norm2;
				sum+=e*H[i]*tmp;
				sum2+=e*H[i]*tmp*tmp;
				norm+=e*H[i];
			}
			if (norm>0.0)
			{
				mu[cl]=sum/norm;
				sd[cl]=sqrt(sum2/norm-sum*sum/norm/norm);
				if (sd[cl]<=0.0)
					sd[cl]=mu[cl]/100.0;
				if (sd[cl]<=0.0)
					sd[cl]=1.0;

			}
		}

		iter++;
	}
	while (iter<iterations);




	//sort the means assosiated with the first volume
	QuickSort(mu, sort, classes);



	//sort the probabilities into largest mean order
	for (voxel=0; voxel<voxels; voxel++)
	{
		if ((tmp=(*image).img[voxel])>0.0)
		{
			sum=0.0;
			for (cl=0; cl<classes; cl++)
			{
				quant[cl]=exp(-pow((tmp-mu[sort[classes-1-cl]])/sd[sort[classes-1-cl]],2))/sd[sort[classes-1-cl]];
				sum+=quant[cl];
			}
			for (cl=0; cl<classes; cl++)
			{
				probs[voxel+cl*voxels]=255*(quant[cl]/sum);
			}
		}
		else
			for (cl=0; cl<classes; cl++)
				probs[voxel+cl*voxels]=0;
	}

	/*
	    free((*image).img);(*image).img=NULL;
	    (*image).img=(float *)malloc(sizeof(float)*(classes)*voxels);
	    //MessageBox(NULL,"here","",MB_OK);
	    if ((*image).img){
	       (*image).volumes=classes;
	       (*image).Z=classes*Zpv;
	       (*image).MaxIntensity=(float)255;
	       for (voxel=0;voxel<voxels;voxel++){
	           for (cl=0;cl<classes;cl++){
	               (*image).img[voxel+cl*voxels]=(float)probs[voxel+cl*voxels];
	           }
	       }
	    }
	    else goto END;*/


	result=1;
END:
	if (mu)
		free(mu);
	if (sd)
		free(sd);
	if (quant)
		free(quant);

	return result;
}
int TestSingleVolumeClassifier(struct Image *image)
{

	unsigned char *probs=NULL;
	int voxels=(*image).X*(*image).Y*(*image).Z;

	probs=(unsigned char *)malloc(10*voxels);

	SingleVolumeClassification(image, 5, probs, 20);

	if (probs)
		free(probs);
	return 1;
}
//===========================================================================================================
/*
double KmeansClusteringOfCoordinates(float x[], float y[], float z[], int include[], short int cl[], int Ncoords, float xc[], float yc[], float zc[], int Nclusters)
{
	double SSD=0.0;
	int iter;
	float dx,dy,dz,shift;
	int i;
	int *CLcount=NULL;
	int p;

	if (!(CLcount=(int *)malloc(sizeof(int)*(Nclusters+1))))
		goto END;

	do
	{
		memset(CLcount,0,sizeof(int)*(Nclusters+1));
		for (i=0; i<Ncoords; i++)
		{
			if (include[i])
			{
				cl[i]=1 + rand()%Nclusters;
				CLcount[cl[i]]++;
			}
			else
				cl[i]=0;
		}
		p=1;
		for (i=1; i<=Nclusters; i++)
		{
			p *= cl[i];
		}
	}
	while (!p);


	iter=0;
	do
	{
		memset(xc,0,sizeof(float)*(Nclusters+1));
		memset(yc,0,sizeof(float)*(Nclusters+1));
		memset(zc,0,sizeof(float)*(Nclusters+1));
		memset(CLcount,0,sizeof(int)*(Nclusters+1));
		for (i=0; i<Ncoords; i++)
		{
			if (include[i])
			{
				xc[cl[i]]+=x[i];
				yc[cl[i]]+=y[i];
				zc[cl[i]]+=z[i];
				CLcount[cl[i]]++;
			}
		}

		for (i=1;i<=Nclusters;i++)
        {
            if (CLcount[i])
            {
                xc[i] /= CLcount[i];
                yc[i] /= CLcount[i];
                zc[i] /= CLcount[i];
            }
        }

        ///reassign cluster allocation


        ///compute error (SSD sum of squared deviations)

	}
	while (shift>0.001);

END:
	if (CLcount)
		free(CLcount);

	return SSD;
}
*/
