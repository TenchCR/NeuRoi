/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "global.h"
#include "loader.h"


//===============================================================================
//===============================================================================
int InterleaveIntensityChanges(struct Image *image)
{
	int X,Y,Z;
	int x,y,z;
	int voxel;
	double *means=NULL;
	int count;
	double grandmean;
	int grandcount;
	FILE *fp;
	char fname[MAX_PATH];

	X=(*image).X;
	Y=(*image).Y;
	Z=(*image).Z;

	AutoRemoveNoisyBackground(NULL, image, 1);

	if (!(means=(double *)calloc(Z,sizeof(double))))
		goto END;

	grandcount=0;
	grandmean=0.0;
	for (z=0; z<Z; z++)
	{
		count=0;
		for (y=0; y<Y; y++)
		{
			for (x=0; x<X; x++)
			{
				voxel=x + y*X + z*X*Y;
				if ((*image).img[voxel]>0.0)
				{
					count++;
					means[z]+=(*image).img[voxel];
					grandcount++;
					grandmean+=(*image).img[voxel];
				}
			}
		}
		if (count)
		{
			means[z]/=count;
		}
	}
	if (grandcount)
	{
		grandmean/=grandcount;
	}


	for (z=0; z<Z; z++)
	{
		for (y=0; y<Y; y++)
		{
			for (x=0; x<X; x++)
			{
				voxel=x + y*X + z*X*Y;
				(*image).img[voxel] *= grandmean/means[z];
			}
		}
	}

	sprintf(fname,"%s/SliceMeans.csv",REPORT_FOLDER);
	if ((fp=fopen(fname,"w")))
	{
		for (z=0; z<Z; z++)
		{
			fprintf(fp,"%d,%f\n",z,means[z]/grandmean);
		}
		fclose(fp);
	}


END:
	if (means)
		free(means);

	return 0;
}
//=============================================================================================
double WeightedVolume(struct Image *image)
{
	int voxel, voxels=(*image).X*(*image).Y*(*image).Z;
	double volume=0.0;
	double dV=(*image).dx*(*image).dy*(*image).dz;
	char txt[256];

	for (voxel=0; voxel<voxels; voxel++)
	{
		volume+=dV*(*image).img[voxel]*(*image).scale;
	}

	sprintf(txt,"%f",volume);
	MessageBox(NULL,txt,"",MB_OK);

	return volume;
}
//===============================================================================================
int ConvertRGBtoGrey(struct Image *image)
{

	struct Image fimg;
	unsigned char *rgb=NULL;
	unsigned int i,j,k;
	int voxel,voxels;
	RGBQUAD rgbq;
	unsigned char cl;


	if ((*image).DataType!=DT_RGB)
		return 0;

	voxels=(*image).X*(*image).Y*(*image).Z;


	rgb=(unsigned char *)calloc(256*256*256,1);

	memset(&fimg,0,sizeof(struct Image));
	MakeCopyOfImage(image, &fimg);

	fimg.DataType=DT_FLOAT;
	fimg.scale=1.0;
	fimg.offset=1.0;



	cl=0;
	for (voxel=0; voxel<voxels; voxel++)
	{
		memcpy(&rgbq, &(*image).img[voxel], sizeof(RGBQUAD));

		i=rgbq.rgbRed;
		j=rgbq.rgbGreen;
		k=rgbq.rgbBlue;

		if (i||j||k)
		{
			if (!rgb[i + 256*j + k*256*256])
			{
				cl++;
				rgb[i + 256*j + k*256*256]=cl;
				fimg.img[voxel]=(float)cl;
			}
			else
			{
				fimg.img[voxel]=(float)rgb[i + 256*j + k*256*256];
			}
		}
	}
char txt[256];
sprintf(txt,"%d",cl);
MessageBox(NULL,txt,"",MB_OK);

	free(rgb);

	SaveAs(&fimg);

	ReleaseImage(&fimg);

	return 1;
}
//============================================================================
int SaveROImeans(struct Image *MV)
{
	double *means=NULL;
	int *ROIsize;
	int max,volumes;
	struct Image ROI;
	char fname[MAX_PATH];
	int voxel,voxels,volume;
	int cl;
	volumes=(*MV).volumes;

	memset(&ROI,0,sizeof(struct Image));

	GetImageFileNames(fname, MAX_PATH, "Select ROI image");

	LoadFromFileName(NULL,fname,&ROI,0);

	voxels=ROI.X*ROI.Y*ROI.Z;
	max=0;
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (ROI.img[voxel]>max)
			max=ROI.img[voxel];
	}

	means=(double *)calloc(volumes*(max+1),sizeof(double));
	ROIsize=(int *)calloc((max+1),sizeof(int));

	for (voxel=0; voxel<voxels; voxel++)
	{
		if ((cl=(int)ROI.img[voxel]))
		{
			ROIsize[cl]++;
			for (volume=0; volume<volumes; volume++)
			{
				means[cl + volume*(max+1)]+=(*MV).img[voxel+voxels*volume];
			}
		}
	}

	for (cl=1; cl<=max; cl++)
	{
		if (ROIsize[cl])
		{
			for (volume=0; volume<volumes; volume++)
			{
				means[cl + volume*(max+1)]/=ROIsize[cl];
			}
		}
	}

FILE *fp;

sprintf(fname,"%s//density.csv",REPORT_FOLDER);

fp=fopen(fname,"w");
for (volume=0;volume<volumes;volume++)
{
for (cl=1; cl<=max; cl++)
	{
	    fprintf(fp,"%f,",means[cl + volume*(max+1)]);
	}
	fprintf(fp,"\n");
}

fclose(fp);


	ReleaseImage(&ROI);
	if (means)
		free(means);
    if (ROIsize) free(ROIsize);

	return 0;
}
//===================================================================================
int TestSuperResolutionPre(struct Image *big)
{
    struct Image little;
    int X, Y, Z;
    float dx, dy, dz;
    int x,y,z;
    int littlevoxel;
    int bigvoxel;
    int N=3;

    X=(*big).X;
    Y=(*big).Y;
    Z=(*big).Z;

    dx=(*big).dx;
    dy=(*big).dy;
    dz=(*big).dz;

    memset(&little,0,sizeof(struct Image));


    if (!(MakeImage(&little, X, Y, Z/N,1,dx,dy,dz*3, dx*X/2, dy*Y/2, dz*Z/8,  1,0.0, DT_FLOAT, NIFTI,"super res"))) goto END;

    for(y=0; y<Y;y++)
    {
        for (x=0;x<X;x++)
        {
            for (z=0;z<(Z-N)/N;z++)
            {
                littlevoxel=x + y*X + z*X*Y;
                bigvoxel=x + y*X + z*X*Y*N;

                little.img[littlevoxel] = ((*big).img[bigvoxel] + (*big).img[bigvoxel+X*Y] + (*big).img[bigvoxel+2*X*Y])/3;

            }
        }
    }
    sprintf(little.filename,"c://temp//small1.nii");
    SaveNiftiImage(&little, little.filename);

    for(y=0; y<Y;y++)
    {
        for (x=0;x<X;x++)
        {
            for (z=0;z<(Z-N)/N;z++)
            {
                littlevoxel=x + y*X + z*X*Y;
                bigvoxel=x + y*X + z*X*Y*N;

                little.img[littlevoxel] = ((*big).img[bigvoxel+X*Y] + (*big).img[bigvoxel+2*X*Y] + (*big).img[bigvoxel+3*X*Y])/3;

            }
        }
    }
    sprintf(little.filename,"c://temp//small2.nii");
    SaveNiftiImage(&little, little.filename);

     for(y=0; y<Y;y++)
    {
        for (x=0;x<X;x++)
        {
            for (z=0;z<(Z-N)/N;z++)
            {
                littlevoxel=x + y*X + z*X*Y;
                bigvoxel=x + y*X + z*X*Y*N;

                little.img[littlevoxel] = ((*big).img[bigvoxel+2*X*Y] + (*big).img[bigvoxel+3*X*Y] + (*big).img[bigvoxel+4*X*Y])/3;

            }
        }
    }
    sprintf(little.filename,"c://temp//small3.nii");
    SaveNiftiImage(&little, little.filename);

END:
    ReleaseImage(&little);

    return 0;
}
//==============================================================================================
int SuperResolveTest(void)
{
    struct Image little1,little2,little3;
    struct Image bigimg;
    int X, Y, Z;
    float dx, dy, dz;
    int N=3;
    int x,y,z;
    int bigvoxels;
    float a,b,c;
    int voxel1,voxel2,voxel3;
    float BC;

    memset(&little1,0,sizeof(struct Image));
    memset(&little2,0,sizeof(struct Image));
    memset(&little3,0,sizeof(struct Image));
    memset(&bigimg,0,sizeof(struct Image));

    if (!(LoadAnalyzeOrNifti(NULL, &little1,0))) goto END;
    if (!(LoadAnalyzeOrNifti(NULL, &little2,0))) goto END;
    if (!(LoadAnalyzeOrNifti(NULL, &little3,0))) goto END;

    X=little1.X;
    Y=little1.Y;
    Z=little1.Z*N;
    bigvoxels=X*Y*Z;

    dx=little1.dx;
    dy=little1.dy;
    dz=little1.dz/N;

    if (!(MakeImage(&bigimg, X, Y, Z, 1, dx, dy, dz, dx*X/2, dy*Y/2, dz*Z/2, 1.0, 0.0, DT_FLOAT, NIFTI, "super"))) goto END;

    for (y=0;y<Y;y++)
    {
        for (x=0;x<X;x++)
        {
            for (z=little1.Z-1; z>=0;z--)
            {
                BC=little3.img[x+y*X+(little3.Z-1)*X*Y];
                //BC=0.0;
                ////////first known is little3[z]///////////
                //unknowns are bigimg[N*z], bigimg[N*z+1], and bingim[N*z+2]

                voxel1=x + y*X + (N*z+N-1)*X*Y;
                voxel2=x + y*X + (N*z+N-1+1)*X*Y;
                voxel3=x + y*X + (N*z+N-1+2)*X*Y;

                //a is the unknown to compute
                b=BC;
                if (voxel2<bigvoxels) b=bigimg.img[voxel2];
                c=BC;
                if (voxel3<bigvoxels) b=bigimg.img[voxel3];

                a = 3.0*little3.img[x + y*X + z*X*Y] - b - c;
                bigimg.img[voxel1] = a/3;

                ///////////now little2/////////////
                voxel1=x + y*X + (N*z+N-1-1)*X*Y;
                voxel2=x + y*X + (N*z+N-1)*X*Y;
                voxel3=x + y*X + (N*z+N-1+1)*X*Y;

                //a is the unknown to compute
                b=BC;
                if (voxel2<bigvoxels) b=bigimg.img[voxel2];
                c=BC;
                if (voxel3<bigvoxels) b=bigimg.img[voxel3];

                a = 3.0*little2.img[x + y*X + z*X*Y] - b - c;
                bigimg.img[voxel1] = a/3;


                ///////////now little1////////////
                voxel1=x + y*X + (N*z+N-1-2)*X*Y;
                voxel2=x + y*X + (N*z+N-1-1)*X*Y;
                voxel3=x + y*X + (N*z+N-1)*X*Y;

                //a is the unknown to compute
                b=BC;
                if (voxel2<bigvoxels) b=bigimg.img[voxel2];
                c=BC;
                if (voxel3<bigvoxels) b=bigimg.img[voxel3];

                a = 3.0*little1.img[x + y*X + z*X*Y] - b - c;
                bigimg.img[voxel1] = a/3;

            }
        }
    }

    sprintf(bigimg.filename,"c://temp//big.nii");
    SaveNiftiImage(&bigimg, bigimg.filename);

END:
    ReleaseImage(&little1);
    ReleaseImage(&little2);
    ReleaseImage(&little3);
    ReleaseImage(&bigimg);
    return 0;
}
