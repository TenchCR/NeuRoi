/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "phaseunwrap.h"
#include "numerical.h"
#include "imageprocess.h"
#include "graphtheoryalgorithms.h"

float UnwrapVoxeln(float target, float ToUnwrap);

int FuzzyUnwrap(float *lookup, float *phase, int seed, float *unwraped, int X, int Y, int Z,
				HWND hwnd, float thresh, int iterations);
int GetPhaseImageNoiseEstimateImage(float phaseimg[], float lookup[], unsigned char bin[],
                                    int X, int Y, int Z,
                                    float dx, float dy, float dz);
//==============================================================================
//              Given the tensor do GT based tractography
//              Use the tensor ODF
//              Directions for integration of ODF are in ExecutableDirectory/directions
//==============================================================================
int UnwrapPhaseWrappedImage(HWND hwnd, struct Image *phase, int correct){

    float *noise=NULL;         //this contains the integrals over the ODF
    float *unwraped=NULL;
    int voxel, voxels;
    int X, Y, Zpv;
    int SelectedVoxel;
    int result=0;
    int count;
    float mean;
    float temp,min;
    unsigned char *mask=NULL;
    HCURSOR hourglass;
    HCURSOR	PrevCursor;

    hourglass=LoadCursor(NULL,IDC_WAIT);

    //preliminary operations
    X=(*phase).X;
    Y=(*phase).Y;
    Zpv=(*phase).Z/(*phase).volumes;
    voxels=X*Y*Zpv;


    if (!(mask=(unsigned char *)malloc(voxels))) goto END;
    memset(mask,0,voxels);

    for (voxel=0;voxel<voxels;voxel++){
		temp=(*phase).offset + (*phase).scale*(*phase).img[voxel];
		(*phase).img[voxel]=temp;
	}
    (*phase).offset=0.0;
    (*phase).scale=1.0;


    min=0.0;
	for (voxel=0;voxel<voxels;voxel++){
		if ((*phase).img[voxel]<min) min=(*phase).img[voxel];
	}
    for (voxel=0;voxel<voxels;voxel++){
		(*phase).img[voxel]-=min;
		if ((*phase).img[voxel]) mask[voxel]=1;
	}
    //need to create a mask because the phase can be zero and valid
    //dilation and erotion will fill holes in the mask
    //if the holes are not filled, they sho in the unwraped image
    DilateImage3D(mask, X, Y, Zpv);
    ErodeImage3D(mask, X, Y, Zpv);



    PrevCursor=SetCursor(hourglass);

    if (!(noise=(float *)malloc(sizeof(float)*voxels))) goto END;
    if (!(unwraped=(float *)malloc(sizeof(float)*voxels))) goto END;
   	memset(unwraped,0,sizeof(float)*voxels);


    GetPhaseImageNoiseEstimateImage((*phase).img, noise, mask, X, Y, Zpv,
                                    (*phase).dx, (*phase).dy, (*phase).dz);
    //GetNoisePoleImage((*phase).img, noise, X, Y, Zpv);




    SelectedVoxel=X/2 + Y/2*X + Zpv/2*X*Y;//the central voxel
    //find a voxel with a low noise
	while ((SelectedVoxel<voxels) && (noise[SelectedVoxel]<0.8)){SelectedVoxel++;}


    FuzzyUnwrap(noise, (*phase).img, SelectedVoxel, unwraped, X, Y, Zpv,
                hwnd, 0.0, 2*voxels);//allow more iterations than there are voxels. Changed 24/may/2011



   	memcpy((*phase).img, unwraped, sizeof(float)*voxels);

	if (correct){
	    NeighbourAverage(unwraped, X, Y, Zpv, (*phase).dx, (*phase).dy, (*phase).dz, 5.0,0);

		for (voxel=0;voxel<voxels;voxel++){
        	(*phase).img[voxel]-=unwraped[voxel];
    	}
	}


    count=0;
    mean=0.0;
   	min=0.0;
	for (voxel=0;voxel<voxels;voxel++){
		if (mask[voxel] && (*phase).img[voxel]<min) min=(*phase).img[voxel];
	}
    for (voxel=0;voxel<voxels;voxel++){
		if (mask[voxel]){
           (*phase).img[voxel]-=min;
           mean+=(*phase).img[voxel];
           count++;
        }
		else (*phase).img[voxel]=0.0;
	}
	if (count) mean/=count;
   	(*phase).DataType=DT_FLOAT;
   	(*phase).MaxIntensity=MaximumIntensity(phase);
   	(*phase).offset=-mean;
   	(*phase).scale=1.0;

/*
memcpy((*phase).img, noise, voxels*sizeof(float));
(*phase).MaxIntensity=1.0;
(*phase).offset=0.0;
(*phase).scale=1.0;
*/
    SetCursor(PrevCursor);

END:
    if (noise) free(noise);
    if (unwraped) free(unwraped);
    if (mask) free(mask);

    return result;
}








//==============================================================================
//				Noise estimates
//				Output image is lookup and is 1 volume
//				output range is 0...1
//				lookup==1 means low noise to signal ratio
//				lookup close to zero is high noise to signal ratio
//==============================================================================
#define WIDTH 1
int GetPhaseImageNoiseEstimateImage(float phaseimg[], float lookup[], unsigned char bin[],
                                    int X, int Y, int Z,
                                    float dx, float dy, float dz){

	int i,j,k;
	int x,y,z;
	int voxel,voxeln;
	int voxels;
	int n;
	float target;
	float sum, sum2, dummy;
	float max=0.0;

	voxels=X*Y*Z;

	memset(lookup,0,sizeof(float)*voxels);

	for (z=0;z<Z;z++){
		for (y=0;y<Y;y++){
			for (x=0;x<X;x++){
				voxel=x+y*X+z*X*Y;
				if (bin[voxel]){
                    target=phaseimg[voxel];
					sum=sum2=0.0;
					n=0;
					for (k=-WIDTH;k<=WIDTH;k++){
						for (j=-WIDTH;j<=WIDTH;j++){
							for (i=-WIDTH;i<=WIDTH;i++){
								if (InImageRange(x+i, y+j, z+k, X, Y, Z)){
									voxeln=voxel+i+j*X+k*X*Y;
									//if (phaseimg[voxeln]){
    									dummy=UnwrapVoxeln(target,phaseimg[voxeln]);
	       								sum+=dummy;
		      							sum2+=dummy*dummy;
			     						n++;
                                    //}
								}
							}
						}
					}
					if ((n>1) && (sum2>0.0)){
						lookup[voxel]=(sum2/n - sum*sum/n/n);
						if ( lookup[voxel]>max ) max=lookup[voxel];
					}
				}
			}
		}
	}

	if (max>0.0){
		for(voxel=0;voxel<voxels;voxel++) lookup[voxel]/=(max+0.1);//why was this +0.1? Try 0.0000001
		//GaussFilterFastEx(lookup, X, Y, Z, dx, dy, dz, 1.0, 1);
        for(voxel=0;voxel<voxels;voxel++) if (lookup[voxel]) lookup[voxel]=1.0-lookup[voxel];
	}


	return 1;
}
//==============================================================================
//==============================================================================
/*int TestNoiseImage(struct Image *image){

    int X,Y,Z;
    int voxel,voxels;
    float *temp;
    float max;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    temp=(float *)malloc(voxels*sizeof(float));
    if (temp){
        GetPhaseImageNoiseEstimateImage((*image).img, temp, X, Y, Z,
                                        (*image).dx, (*image).dy, (*image).dz);
        memcpy((*image).img, temp,voxels*sizeof(float));

        (*image).MaxIntensity=1.0;
        free(temp);
    }

    return 1;
}*/



//==============================================================================
//					Unwrap
//                  Can unwrap +-n2PI
//==============================================================================
float UnwrapVoxeln(float target, float ToUnwrap){

	float diff=target-ToUnwrap;
	int n=(int)(fabs(diff)/(2.0*PI) + 0.5);//convert to nearest integer rounding
	if (diff>0.0) return ToUnwrap + 2.0*PI*n;
	else return ToUnwrap - 2.0*PI*n;
}


//=========================================================================================================
//GetAffinity(float *lookup, int voxel, int neighbour)
//=========================================================================================================
int FuzzyUnwrap(float *lookup, float *phase, int seed, float *unwraped, int X, int Y, int Z,
				HWND hwnd, float thresh, int iterations){

	int x,y,z, voxel, voxeln, voxels=X*Y*Z;
	int i,j,k,l;
    int *inout=NULL;
    int *heap=NULL;
	int entered;
	int xn[6], yn[6], zn[6];
	float affinity;
	float *Connectedness;
    char txt[256];
	HDC hDC=GetDC(hwnd);
	int iter, count;

	inout=(int *)malloc(voxels*sizeof(int));
	heap=(int *)malloc(voxels*sizeof(int));
	Connectedness=(float *)malloc(voxels*sizeof(float));

    iter=0;
	if (inout && heap && Connectedness){
		memset(inout,0,voxels*sizeof(int));
		memset(heap,0,voxels*sizeof(int));
		memset(Connectedness,0,voxels*sizeof(float));


		//---------------------------Get neighbours----------------------------
		l=0;
		for (k=-1;k<=1;k++){
			for (j=-1;j<=1;j++){
				for (i=-1;i<=1;i++){
					if (( (abs(i) + abs(j) + abs(k))==1 ) && (l<6)){
						xn[l]=i;
						yn[l]=j;
						zn[l]=k;
						l++;
					}
				}
			}
		}
		//---------------------------------------------------------------------


		//----------------------initially there are no connections except the seed------------------
		entered=1;
		heap[entered]=seed;
		inout[seed]=entered;
		Connectedness[seed]=1.0;
		unwraped[seed]=phase[seed];
		//------------------------------------------------------------------------------------------


	//--------------------------Fill the Q------------------------------------------------------
	count=0;
	while( (Connectedness[heap[1]]>thresh) && (iter<iterations) && entered ){

		voxel=heap[1];																						//the current voxel, taken from the Q
		entered=RemoveRootElement(Connectedness, heap, entered, inout);	//take out of the Q


		for (l=0;l<6;l++){

            XYZfromVoxelNumber(voxel, &x, &y, &z, X, Y, Z);
			if (InImageRange(x+xn[l],y+yn[l],z+zn[l],X,Y,Z)){

    			voxeln=voxel + xn[l] + yn[l]*X + zn[l]*X*Y;

				if (Connectedness[voxeln]<Connectedness[voxel]){//cant update a highly connected voxel from a low connected voxel

				    affinity=lookup[voxeln]*Connectedness[voxel];

					if (affinity>Connectedness[voxel]) affinity=Connectedness[voxel];// cant connect stronger than current connectedness

					//----------------------ENTER NEIGHBOUR INTO Q---------------------------------------
					if ((affinity>thresh) && (affinity>Connectedness[voxeln])){


						count++;
						if (count>1000){
							sprintf(txt,"%d %d %f %f       ", entered,voxel,Connectedness[voxel], affinity);
							TextOut(hDC,100,100,txt,strlen(txt));
							count=0;
						}

						if (!inout[voxeln]){
							entered=NewHeapElement(Connectedness, heap, entered, voxeln, inout, affinity);		//put into the Q if not already there
						}
						else{
							UpdateHeap(Connectedness, heap, entered, voxeln, affinity, inout);					//if already in the Q, update connectedness
						}

						//unwrap this voxel
						unwraped[voxeln]=UnwrapVoxeln(unwraped[voxel], phase[voxeln]);
					    //unwraped[voxeln]=Connectedness[voxeln];//test the connectivities

                    }

					//-----------------------------------------------------------------------------------

				}//connectedned in neighbour < connectedness in current voxel

			}//in image range

		}//l {0<=l<26}


	}
	//-------------------------------------------------------------------------------------------

        iter++;
	}


	if (inout) free(inout);
	if (heap) free(heap);
	if (Connectedness) free(Connectedness);

	ReleaseDC(hwnd, hDC);

	return iter;
}


/*
//int GetNoisePoleImage(float ph[], float lookup[], int X, int Y, int Z);
//int NoisePole(float a, float b, float c, float d);
int TestNoisePole(struct Image *image);
//==============================================================================
//          Noise Pole Image
//==============================================================================
int GetNoisePoleImage(float ph[], float lookup[], int X, int Y, int Z){

    int x,y,z;
    int v, voxels=X*Y*Z;
    int sumxy, sumxz, sumyz;
    float max;
    char txt[256];

    memset(lookup,0,X*Y*Z*sizeof(float));

    max=0.0;
    for (z=0;z<Z;z++){
		for (y=1;y<Y-1;y++){
			for (x=1;x<X-1;x++){
				v=x+y*X+z*X*Y;
				if (ph[v]){
                    sumxy=NoisePole(ph[v], ph[v+1], ph[v+1+Y], ph[v+Y]);


					if (z<(Z-1)){
                        sumxz=NoisePole(ph[v], ph[v+1], ph[v+1+X*Y], ph[v+X*Y]);
                        sumyz=NoisePole(ph[v], ph[v+Y], ph[v+Y+X*Y], ph[v+X*Y]);
                    }
                    else{
                        sumxz=NoisePole(ph[v], ph[v+1], ph[v+1-X*Y], ph[v-X*Y]);
                        sumyz=NoisePole(ph[v], ph[v+Y], ph[v+Y-X*Y], ph[v-X*Y]);
                    }


				    lookup[v]=(float)(abs(sumxy) + abs(sumxz) + abs(sumyz));
                    if (lookup[v]>max) max=lookup[v];

                }
            }
        }
    }
    //sprintf(txt,"%f",max);
    //MessageBox(NULL,txt,"",MB_OK);
    if (max>0.0){
        for (v=0;v<voxels;v++){
            lookup[v]/=(max+0.1);
            if (ph[v]) lookup[v]=1.0-lookup[v];
        }
    }


    return 1;
}
//==============================================================================
//          Noise Pole value
//==============================================================================
int NoisePole(float a, float b, float c, float d){

    float d1,d2,d3,d4;
    d1=(b-a)/2.0/PI;
    d2=(c-b)/2.0/PI;
    d3=(d-c)/2.0/PI;
    d4=(a-d)/2.0/PI;

    if (d1>=0.0) d1+=0.5;
    else d1-=0.5;
    if (d2>=0.0) d2+=0.5;
    else d2-=0.5;
    if (d3>=0.0) d3+=0.5;
    else d3-=0.5;
    if (d4>=0.0) d4+=0.5;
    else d4-=0.5;

    return (int)d1 + (int)d2 + (int)d3 + (int)d4;
}

int TestNoisePole(struct Image *image){

    int X,Y,Z;
    int voxel,voxels;
    float *temp;
    float max;

    X=(*image).X;
    Y=(*image).Y;
    Z=(*image).Z;
    voxels=X*Y*Z;

    temp=(float *)malloc(voxels*sizeof(float));
    if (temp){
        GetNoisePoleImage((*image).img, temp, X, Y, Z);
        memcpy((*image).img, temp,voxels*sizeof(float));

        (*image).MaxIntensity=1.0;
        free(temp);
    }

    return 1;
}*/


