/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "global.h"
#include "menuresources.h"
#include "loader.h"
#include "imageprocess.h"
#include "ROIs.h"

//==========================================================================================
//                  Apply binary mask image to Image such that
//                  if (binary && !inverse) Image=Image, else Image=0
//                  if (binary && inverse) Image=0, else Image=Image
//==========================================================================================
int ApplyBinaryMaskToImage(HWND hwnd, struct Image *image, int inverse)
{

    struct Image binary;
    int result=0;
    int X, Y, Zpv, volumes, vol;
    int voxel, voxels;


    memset(&binary,0,sizeof(struct Image));
    if (LoadAnalyzeOrNifti(hwnd, &binary, 0))
    {
        X=(*image).X;
        Y=(*image).Y;
        Zpv=(*image).Z/(*image).volumes;
        volumes=(*image).volumes;
        //image dimensions must be the same in each image
        if (X==binary.X && Y==binary.Y && Zpv==binary.Z/binary.volumes)
        {

            //if both images have the same number of volumes
            if (binary.volumes==volumes)
            {
                voxels=X*Y*Zpv*volumes;
                for (voxel=0; voxel<voxels; voxel++)
                {
                    if (!binary.img[voxel] && (!inverse)) (*image).img[voxel]=0.0;
                    if (binary.img[voxel] && inverse) (*image).img[voxel]=0.0;
                }
                result=1;
            }
            if (binary.volumes<volumes)
            {
                voxels=X*Y*Zpv;
                for (vol=0; vol<volumes; vol++)
                {
                    for (voxel=0; voxel<voxels; voxel++)
                    {
                        if ((!binary.img[voxel]) && (!inverse)) (*image).img[voxel+vol*voxels]=0.0;
                        if (binary.img[voxel] && inverse) (*image).img[voxel+vol*voxels]=0.0;
                    }
                }
                result=1;
            }
        }
        else MessageBox(NULL,"Image dimensions different.","",MB_OK|MB_ICONWARNING);
    }

    ReleaseImage(&binary);

    return result;
}


//==========================================================================================
//CONVERT AN IMAGE TO BINARY
//INTENSITIES 1 OR ZERO
//==========================================================================================
int ConvertToBinary(HWND hwnd, struct Image *image)
{
    int voxel,voxels=(*image).X*(*image).Y*(*image).Z;

    for (voxel=0; voxel<voxels; voxel++)
    {
        if (fabs((*image).img[voxel])>0.0) (*image).img[voxel] = 1.0;
    }
    (*image).MaxIntensity = 1.0;
    (*image).scale = 1.0;
    (*image).offset = 0.0;
    (*image).DataType = DT_UNSIGNED_CHAR;

    return 1;
}

//=============================================================================================
//FIND THE LARGEST CONNECTED OBJECT IN A BINARY IMAGE
//=============================================================================================
int LargestConnectedObject(HWND hwnd, unsigned char *bin, int X, int Y, int Z)
{
    int x,y,z;
    int voxel,voxel2,voxels=X*Y*Z;
    int size,biggest;
    unsigned char *bin2=NULL;
    unsigned char *bigObject=NULL;

    biggest=0;
    if (!(bin2=(unsigned char *)malloc(voxels))) goto END;
    if (!(bigObject=(unsigned char *)malloc(voxels))) goto END;

    memcpy(bin2,bin,voxels);
    voxel=0;
    for (z=0;z<Z;z++)
    {
        for (y=0;y<Y;y++)
        {
            for (x=0;x<X;x++)
            {
                if (bin[voxel])
                {
                    memcpy(bin2,bin,voxels);
                    size=ConnectedObject(bin2, X, Y, Z, x, y, z);
                    for (voxel2=0;voxel2<voxels;voxel++)
                    {
                        if (bin2[voxel2]) bin[voxel2]=0;
                    }


                    if (size>biggest)
                    {
                        biggest=size;
                        memcpy(bigObject, bin2, voxels);
                    }
                }

                voxel++;
            }
        }
    }


    memcpy(bin,bigObject,voxels);
END:
    if (bin2) free(bin2);
    if (bigObject) free(bigObject);

    return biggest;
}

//=============================================================================================
//find the brain in an image
//the brain is assumed to be the connected object seeded nearest to the centre of the image
//DOESNT WORK IF THE IMAGE ISNT IN ONE PIECE
//=============================================================================================
int FindBrain(HWND hwnd, unsigned char *bin, int X, int Y, int Z)
{
    int seedX, seedY, seedZ;
    int Xav, Yav,Zav;
    int counter;
    int x,y,z;
    int voxel,voxels=X*Y*Z;
    int XY=X*Y;
    int length,maxlength;
    int result=0;
    unsigned char *bin2=NULL;
    struct ROIedge ROI[MAX_ROI_LENGTH];
//char txt[256];

    if (!(bin2=(unsigned char *)malloc(X*Y*Z))) goto END;

    FreeROIMemory();


    //FIND THE CENTRE OF INTENSITY
    Xav=Yav=Zav=0;
    voxel=counter=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if (bin[voxel])
                {
                    Xav+=x;
                    Yav+=y;
                    Zav+=z;
                    counter++;
                }

                voxel++;
            }
        }
    }

    if (!counter) goto END;

    Xav/=counter;
    Yav/=counter;//this is the centre of mass of the object containing the brain + other smaller objects
    Zav/=counter;

    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Finding Seed in function FindBrain\n");fclose(fp);}
    //FIND THE SEED CLOSEST TO THE CENTRE OF INTENSITY
    seedX=seedY=seedZ=0;
    voxel=0;
    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                if ((x==0) || (x==X-1) || (y==0) || (y==Y-1)) bin[voxel]=0;//cant do edges because the ROIs dont go beyond the edge
                if (bin[voxel])
                {
                    if ( ((x-Xav)*(x-Xav) + (y-Yav)*(y-Yav)  + (z-Zav)*(z-Zav))<((seedX-Xav)*(seedX-Xav) + (seedY-Yav)*(seedY-Yav) + (seedZ-Zav)*(seedZ-Zav)))
                    {
                        seedX=x;
                        seedY=y;//closest point to the origin so far becomes the seed
                        seedZ=z;
                    }
                }
                voxel++;
            }
        }
    }
    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Seed is %d %d %d\n",seedX, seedY, seedZ);fclose(fp);}

    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Getting Connected object in function FindBrain\n");fclose(fp);}
    //get the object connected to the seed

    ConnectedObject(bin, X, Y, Z, seedX, seedY, seedZ);

    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"Getting ROIs in function FindBrain\n");fclose(fp);}
    do
    {
        maxlength=0;
        for (z=0; z<Z; z++)
        {
//sprintf(txt,"binary.c findbrain %d %d",z,gNumberOfROIs);
//MessageBox(NULL,txt,"",MB_OK);

            length=RegionEdgeDetect8(&bin[z*XY], X, Y, ROI, MAX_ROI_LENGTH);
            if (length)
            {
                if ( (ROI[0].x==ROI[length-1].x) && (ROI[0].y==ROI[length-1].y))
                {
                    gNumberOfROIs=AcceptROI(X, Y, ROI, length, seedX, seedY, z, gNumberOfROIs, 1, AUTO);
                    //if ((fp=fopen(REPORT_FILE,"a"))) {fprintf(fp,"length is %d. Seeds are %d %d %d \n",length, seedX, seedY,z);fclose(fp);}
                    result++;
                }
            }
            if (length>maxlength) maxlength=length;
        }
        GetBinaryROImask(bin2, X, Y, Z, 0, 0);//this should be a brain mask with no holes
        for (voxel=0; voxel<voxels; voxel++)
        {
            if (bin2[voxel]) bin[voxel]=0;
        }
    }
    while((maxlength>0) && (gNumberOfROIs<MAX_ROIS));

    memcpy(bin,bin2,voxels);

    result=1;
END:
    if (bin2) free(bin2);

    return result;
}
