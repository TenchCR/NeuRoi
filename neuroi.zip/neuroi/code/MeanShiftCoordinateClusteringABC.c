/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MeanShiftCoordinateClusteringABC.h"

#define CLUSTER_TOL 0.001

#define GAUSS_LIKE 2.0
#define DOME_LIKE 1.0
#define FLAT 0.0


double GetShiftsABC(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[], short int IncludeFocus[], double p[], double critical, double dist2[], int Nfoci, double MaxDist, double shape);
int MeanShiftCoordinatesABC(float xc[], float yc[], float zc[], struct Coordinates *C, short int IncludeFocus[], double critical, double MaxDist, double shape);
int NumberClusteredABC(struct Image *img, struct Coordinates *C, char dummy[], double critical, double width, double shape, short int IncludeFocus[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters);
double MeanShiftKernelABC(double dist, double maxdist, double shape);
int LabelShiftedCoordinateClustersABC(float x[], float y[], float z[], short int c[], double pvalues[], double pmax, int Nfoci, float xc[], float yc[], float zc[]);
//================================================================================================================
//================================================================================================================

//=======================================================================================
int TestMeanShiftClustering(float xc[], float yc[], float zc[], struct Coordinates *C, short int IncludeFocus[], int MinStudies, double MaxWidth)
{
	FILE *fp=NULL;
	char fname[MAX_PATH];
	int Nfoci=(*C).TotalFoci;
	int focus;
	int X=gImage.X;
	int Y=gImage.Y;
	int Z=gImage.Z;
	float x0=gImage.x0;
	float y0=gImage.y0;
	float z0=gImage.z0;
	float dx=gImage.dx;
	float dy=gImage.dy;
	float dz=gImage.dz;
	int voxels=X*Y*Z;
	int voxel;
	int x,y,z;

	sprintf(fname,"%s//meanshift.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");

	MeanShiftCoordinatesABC(xc, yc, zc, C, IncludeFocus, 0.05,  MaxWidth, 2.0);

	for (focus=0; focus<Nfoci; focus++)
	{
		if (IncludeFocus[focus])
			fprintf(fp,"%d,%d,%f,%f,%f\n",focus, (*C).experiment[focus], xc[focus],yc[focus],zc[focus]);
	}
	if (fp)
		fclose(fp);

	memset(gImage.img,0,voxels*sizeof(float));
	gImage.MaxIntensity=0.0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (IncludeFocus[focus])
		{
			x=(xc[focus] + x0)/dx;
			y=(yc[focus] + y0)/dy;
			z=(zc[focus] + z0)/dz;
			voxel=x + y*X + z*X*Y;
			if (voxel>=0 && voxel<voxels)
				gImage.img[voxel]+=1.0;
			if (gImage.img[voxel]>gImage.MaxIntensity)
				gImage.MaxIntensity=gImage.img[voxel];
		}
	}
	gImage.offset=0.0;
	gImage.scale=1.0;


	return 0;
}
//================================================================================================================
//================================================================================================================
double OptimiseMeanShiftClusteringKernelABC(HWND hwnd, struct Image *img, struct Coordinates *C, double critical,
                                         short int IncludeFocus[], float xc[], float yc[], float zc[], int MinStudiesPerCluster,
                                         double MaxWidth, double *shape, char directory[])
{
	int Nfoci=(*C).TotalFoci;
	int focus;
	double width;
	double bestwidth=0.0;
	double bestshape=2.0;
	int Nclustered;
	int Nclusters;
	char *dummy=NULL;
	int Max;
	int Nsig;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	char txt[256];
	HDC hDC=GetDC(hwnd);

	*shape=bestshape;

	if (!(dummy=(char *)calloc(Nfoci,sizeof(char)))) return 0.0; ///default width;

	sprintf(fname,"%s//WidthOpt.csv",directory);
	fp=fopen(fname,"w");


	//number of significant coordinates to cluster
	Nsig=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if (IncludeFocus[focus])
		{
			Nsig++;
		}
	}

	if (Nsig<=0)
		return 0.0;



	if (fp)	fprintf(fp,"Kernel Width (mm), Shape, Number Clustered, Max Clustered, Clusters\n");

	//Gauss like kernel
	Max=0;
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClusteredABC(img, C, dummy, critical, width, GAUSS_LIKE, IncludeFocus, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max))
		{
			Max=Nclustered;
			bestwidth=width;
			bestshape=GAUSS_LIKE;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, GAUSS_LIKE, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm shape=Gauss (best=%5.3f)",width, bestwidth);
		if (hDC) TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}


	//Dome like kernel
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClusteredABC(img, C, dummy, critical, width, DOME_LIKE, IncludeFocus, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max))
		{
			Max=Nclustered;
			bestwidth=width;
            bestshape=DOME_LIKE;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, DOME_LIKE, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm  shape=dome (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}

	//Flat kernel
	for (width=3.0; width<=MaxWidth; width+=0.1)
	{

		Nclustered=NumberClusteredABC(img, C, dummy, critical, width, FLAT, IncludeFocus, xc, yc, zc, MinStudiesPerCluster, &Nclusters);


		if (Nclusters && (Nclustered>Max))
		{
			Max=Nclustered;
			bestwidth=width;
			bestshape=FLAT;
		}
		if (fp)
			fprintf(fp,"%f, %f,%d,%d,%d\n",width, FLAT, Nclustered, Max,Nclusters);

		sprintf(txt,"Optimising cluster kernel %5.3fmm shape=flat (best=%5.3f)",width, bestwidth);
		TextOut(hDC,100,150,txt,strlen(txt));
		RemoveInput(hwnd);
		UpdateWindow(hwnd);
	}

	if (fp) fprintf(fp,"%f,%f\n", bestwidth, bestshape);

	*shape=bestshape;

	if (fp )
		fclose(fp);

	if (hDC) ReleaseDC(hwnd,hDC);

    if (dummy) free(dummy);


	return bestwidth;
}

//================================================================================================================
int NumberClusteredABC(struct Image *img, struct Coordinates *C, char dummy[], double critical, double width, double shape,
                    short int IncludeFocus[], float xc[], float yc[], float zc[], int MinStudiesPerCluster, int *Nclusters)
{

	int clustered;
	int focus;
	int Nfoci=(*C).TotalFoci;

	(*Nclusters) = GetValidMeanShiftClustersABC(img, C, IncludeFocus, dummy, xc, yc, zc, MinStudiesPerCluster, critical, width, shape);
    if (!(*Nclusters)) return 0;

	clustered=0;
	for (focus=0; focus<Nfoci; focus++)
	{
		if ((*C).cluster[focus])
        {
            clustered++;
        }
	}

	return clustered;
}
//================================================================================================================
int GetValidMeanShiftClustersABC(struct Image *image, struct Coordinates *C, short int IncludeFocus[], char excluded[], float xc[], float yc[], float zc[],int MinStudiesPerCluster, double critical,  double width, double shape)
{
	int Nfoci=(*C).TotalFoci;
	int Nexperiments=(*C).Nexperiments;
	float *xms=NULL;
	float *yms=NULL;
	float *zms=NULL;
	int focus;
	int Nclusters=0;
	int NvalidClusters=0;
	int c;
	int iexp;
	short int *cl=NULL;
	short int *LookUp=NULL;
	int *ContributingFocus=NULL;
	int *SignificantContributingFocus=NULL;
	int SignificantContributorCount;

	//default the cluster numbers to zero
	memset((*C).cluster,0,sizeof(short int)*Nfoci);

	if (width<=0.0)
	{
		goto END;
	}


	if (!(xms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(yms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(zms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

	if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;

    if (!(LookUp=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;

	if (!(ContributingFocus=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;

	if (!(SignificantContributingFocus=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;


    ///shift the coordinates by mean shift clustering
	memcpy(xms, (*C).x,Nfoci*sizeof(float));
	memcpy(yms, (*C).y,Nfoci*sizeof(float));
	memcpy(zms, (*C).z,Nfoci*sizeof(float));

	MeanShiftCoordinatesABC(xms, yms, zms, C, IncludeFocus, critical, width, shape);

	Nclusters = LabelShiftedCoordinateClustersABC(xms, yms, zms, cl, (*C).p, critical, Nfoci, xc, yc, zc);

	///Save the cluster numbers so that only the most dense within study is part of the cluster
	for (c=1; c<=Nclusters; c++)
	{
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			ContributingFocus[iexp]=-1;
			SignificantContributingFocus[iexp]=-1;
		}

		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			for (focus=0; focus<Nfoci; focus++)
			{
				if ((*C).experiment[focus]==iexp &&  cl[focus]==c)
				{
					if (ContributingFocus[iexp]<0)
					{
						ContributingFocus[iexp]=focus;
						if (IncludeFocus[focus])
							SignificantContributingFocus[iexp]=focus;
					}
					else if ((*C).p[focus]<(*C).p[ContributingFocus[iexp]])
					{
						ContributingFocus[iexp] = focus;
						if (IncludeFocus[focus])
							SignificantContributingFocus[iexp]=focus;
					}
				}
			}
		}
		SignificantContributorCount=0;
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (SignificantContributingFocus[iexp]>=0)
			{
				SignificantContributorCount++;
			}
		}
		if (SignificantContributorCount>=MinStudiesPerCluster)
		{
			xc[NvalidClusters]=xc[c-1];
			yc[NvalidClusters]=yc[c-1];
			zc[NvalidClusters]=zc[c-1];

			NvalidClusters++;
			LookUp[c]=NvalidClusters;///stores true cluster numbering
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (ContributingFocus[iexp]>=0)
				{
					(*C).cluster[ContributingFocus[iexp]] = c;///temporary cluster number to be switched using LookUp
				}
			}
			///for valid clusters coordinates not included need the excluded flag set
            for (focus=0; focus<Nfoci; focus++)
            {
                if (cl[focus]==c && !(*C).cluster[focus]) excluded[focus]=1;
            }
		}
	}


	///change cluster numbers to consecutive numbers
	for (focus=0; focus<Nfoci; focus++)
    {
        if ((c=(*C).cluster[focus]))
        {
            (*C).cluster[focus]=LookUp[c];
        }
    }

END:

    if (xms) free(xms);

    if (yms) free(yms);

    if (zms) free(zms);

	if (cl)
		free(cl);

    if (LookUp) free(LookUp);

	if (ContributingFocus)
		free(ContributingFocus);

	if (SignificantContributingFocus)
		free(SignificantContributingFocus);

	return NvalidClusters;
}

//======================================================================================================
int MeanShiftCoordinatesABC(float xc[], float yc[], float zc[], struct Coordinates *C, short int IncludeFocus[], double critical, double MaxDist, double shape)
{
	int Nfoci=(*C).TotalFoci;
	double *dist2=NULL;
	int iter;
	int focus;
	int result=0;
	double shift=0.0;
	float *xs=NULL;
	float *ys=NULL;
	float *zs=NULL;


	if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci)))
		goto END;

	if (!(xs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	if (!(ys=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	if (!(zs=(float *)malloc(sizeof(float)*Nfoci)))
		goto END;

	memcpy(xc, (*C).x, sizeof(float)*Nfoci);
	memcpy(yc, (*C).y, sizeof(float)*Nfoci);
	memcpy(zc, (*C).z, sizeof(float)*Nfoci);

	iter=0;
	do
	{
		CoordinateDistance2MatrixWithSignificance(xc, yc, zc, (*C).experiment, (*C).p, critical, dist2, Nfoci);

		shift=GetShiftsABC(xs, ys, zs, xc, yc, zc, (*C).experiment, IncludeFocus, (*C).p, critical, dist2, Nfoci, MaxDist, shape);

		for (focus=0; focus<Nfoci; focus++)
		{
			if ((*C).p[focus]<=critical)
			{
				xc[focus]+=xs[focus];
				yc[focus]+=ys[focus];
				zc[focus]+=zs[focus];
			}
		}
		iter++;
	}
	while(iter<10000 && shift>CLUSTER_TOL);

	result=1;
END:
	if (dist2)
	{
		free(dist2);
	}
	if (xs)
	{
		free(xs);
	}
	if (ys)
	{
		free(ys);
	}
	if (zs)
	{
		free(zs);
	}
	return result;
}


//=======================================================================================================
double GetShiftsABC(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[],
                 short int IncludeFocus[], double p[], double critical, double dist2[], int Nfoci, double MaxDist, double shape)
{
	double MaxDist2=MaxDist*MaxDist;
	double norm;
	double *w=NULL,wtmp;
	int *bestfocus=NULL;
	int Nexperiments;
	int focus,i;
	double MaxShift=0.0;
	double shift;

	Nexperiments=0;
	for (i=0; i<Nfoci; i++)
	{
		if (iexp[i]>Nexperiments)
			Nexperiments=iexp[i];
	}
	Nexperiments++;

	if (!(w=(double *)malloc(sizeof(double)*Nexperiments)))
		goto END;

	if (!(bestfocus=(int *)malloc(sizeof(int)*Nexperiments)))
		goto END;

	if (MaxDist<=0.0)
		return 0.0;

	for (focus=0; focus<Nfoci; focus++)
	{
		xs[focus]=ys[focus]=zs[focus]=0.0;
		if (p[focus]<=critical)
		{
			memset(w,0,sizeof(double)*Nexperiments);
			for (i=0; i<Nfoci; i++)
			{
				if (IncludeFocus[i] && iexp[i]!=iexp[focus] && dist2[focus*Nfoci + i]<MaxDist2)
				{
					wtmp = MeanShiftKernelABC(sqrt(dist2[focus*Nfoci + i]), MaxDist, shape);
					if (wtmp>w[iexp[i]])
					{
						w[iexp[i]]=wtmp;
						bestfocus[iexp[i]]=i;
					}
				}
			}
			norm=0.0;
			for (i=0; i<Nexperiments; i++)
			{
				if (w[i]>0.0)
				{
					xs[focus] += w[i]*(x[bestfocus[i]]-x[focus]);
					ys[focus] += w[i]*(y[bestfocus[i]]-y[focus]);
					zs[focus] += w[i]*(z[bestfocus[i]]-z[focus]);
					norm+=w[i];
				}
			}

			if (norm>0.0)
			{
				norm*=2.0;
				xs[focus]/=norm;
				ys[focus]/=norm;
				zs[focus]/=norm;
				shift=xs[focus]*xs[focus] + ys[focus]*ys[focus] + zs[focus]*zs[focus];
				if (IncludeFocus[focus] && shift>MaxShift)
				{
					MaxShift=shift;
				}
			}
		}

	}

END:
	if (w)
		free(w);

	if (bestfocus)
		free(bestfocus);

	return MaxShift;
}
//=========================================================================================
double MeanShiftKernelABC(double dist, double maxdist, double shape)
{
    //beta
    double x=dist/maxdist;
	if (x<1.0) return pow(0.5 + x/2, shape)*pow(1.0-(0.5 + x/2), shape)*16;

	return 0.0;
}


//==============================================================================================
int LabelShiftedCoordinateClustersABC(float x[], float y[], float z[], short int c[], double pvalues[], double pmax, int Nfoci, float xc[], float yc[], float zc[])
{
    int Nclusters=0;
    int focus, focus2;
    double d2, min2=1.0;//min2 is tolerance after being mean shifted to convergence
    int *CLcount=NULL;
    int cl;

    if (!(CLcount=(int *)calloc(Nfoci, sizeof(int)))) goto END;

    memset(c,0,sizeof(short int)*Nfoci);
    memset(xc, 0, sizeof(float)*Nfoci);
    memset(yc, 0, sizeof(float)*Nfoci);
    memset(zc, 0, sizeof(float)*Nfoci);

    for (focus=0;focus<Nfoci;focus++)
    {
        if (!c[focus] && pvalues[focus]<=pmax)
        {

            Nclusters++;
            c[focus]=Nclusters;

            xc[Nclusters-1] += x[focus];
            yc[Nclusters-1] += y[focus];
            zc[Nclusters-1] += z[focus];
            CLcount[Nclusters-1]++;

            for (focus2=0;focus2<Nfoci;focus2++)
            {
                if (focus!=focus2 && pvalues[focus2]<=pmax)
                {
                        d2=(x[focus]-x[focus2])*(x[focus]-x[focus2]) + (y[focus]-y[focus2])*(y[focus]-y[focus2]) + (z[focus]-z[focus2])*(z[focus]-z[focus2]);
                        if (d2<=min2)
                        {
                            c[focus2]=Nclusters;
                            CLcount[Nclusters-1]++;
                            xc[Nclusters-1] += x[focus];
                            yc[Nclusters-1] += y[focus];
                            zc[Nclusters-1] += z[focus];
                        }
                 }
            }
        }
    }

    for (cl=0;cl<Nclusters;cl++)
    {
        if (CLcount[cl])
        {
            xc[cl] /= CLcount[cl];
            yc[cl] /= CLcount[cl];
            zc[cl] /= CLcount[cl];
        }
    }

    //just check there are non that should be clustered but aren't
    for (focus=0;focus<Nfoci;focus++)
    {
        if (pvalues[focus]<=pmax && !c[focus])
        {
            for (cl=0;cl<Nclusters;cl++)
            {
                d2=(x[focus]-xc[cl])*(x[focus]-xc[cl]) + (y[focus]-yc[cl])*(y[focus]-yc[cl]) + (z[focus]-zc[cl])*(z[focus]-zc[cl]);
                        if (d2<=min2)
                        {
                            c[focus]=cl+1;
                        }
            }
        }
    }


END:
    if (CLcount) free(CLcount);

    return Nclusters;
}










