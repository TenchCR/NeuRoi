/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "sphericalharmonicfunctions.h"



//===========================================================================================
//These functions work for Even order spherical harmonics only
//===========================================================================================



//===========================================================================================
//		An index into the SH lookup table
//		Works for even order harmonics
//		direction>=0
//		0<=n<=order
//		-n<=l<=n
//		Ordering scheme from Desconteaux 2007
//===========================================================================================
int IndexToSHlookup(int order, int n, int l, int direction){

	int N=NumberSHs(order);
	return direction*N + (n*n+n+2)/2 + l-1;
}



//===========================================================================================
//                  Get the spherical harmonic expansion in dir given the coefficients
//                  *coef: contains all the coefficients for the expansion
//                  SH[] is the lookup table for the spherical harmonics
//                  Only those coefficients that are estimated (est[]==TRUE) are included
//===========================================================================================
double SHexpansionLookup(double *coef, int order, double SH[], int dir){

    double result=0.0;
    int n, l, index;

    for(n=0;n<=order;n+=2){
        for (l=-n;l<=n;l++){
            index=IndexToSHlookup(order, n, l, 0);
            result+=coef[index]*SH[IndexToSHlookup(order, n, l, dir)];
        }
    }

    return result;
}



//===========================================================================================
//			Create Spherical Harmonic Lookup table
//          Will create a table for ALL harmonics upto order; (order+2)*(order+1)/2 of them
//===========================================================================================
int CreateSHlookupTable(int order, struct ThreeVector V[], int directions, double SH[]){

	int l,n;
	int i,dir;
	double R,theta,phi;

	for (n=0;n<=order;n+=2){
		for (l=-n;l<=n;l++){
			for (dir=0;dir<directions;dir++){
				Cartesian2Spherical(V[dir].x, V[dir].y, V[dir].z, &R, &theta, &phi);
				i=IndexToSHlookup(order, n, l, dir);
				SH[i]=SphericalHarmonicReal(n, l, theta, phi);
			}
		}
	}

	return 1;
}





//===========================================================================================
//        Compute the number of even harmonics given the order
//===========================================================================================
int NumberSHs(int order){
    return (order+2)*(order+1)/2;
}





//===========================================================================================
//      Get the values of n and l given the index from IndexToSH
//      works up to order 20
//===========================================================================================
int SHnumbersGivenIndexToLookup(int *n, int *l, int index){

    static int nlu[231];//up to SH of order 20
    static int llu[231];
    static int first=1;
    int i, n1,l1;

    if ((index<0) || (index>230)) return 0;

    if (first){
        for (n1=0;n1<=20;n1+=2){
            for (l1=-n1;l1<=n1;l1++){
                i=IndexToSHlookup(20,n1,l1,0);
                if (i>0 && i<231){ nlu[i]=n1; llu[i]=l1;}
            }
        }
        first=0;
    }
    (*n)=nlu[index];
    (*l)=llu[index];

    return 1;
}



//==============================================================================
//     Compute the overlap between the signal Sig[] and the columns of SH[]
//==============================================================================
int SHoverlap(double SH[],int order, int directions, double Sig[], double o[]){

    int harmonic, direction;
    int N=NumberSHs(order);

    for (harmonic=0;harmonic<N;harmonic++){
        o[harmonic]=0.0;
        for (direction=0;direction<directions;direction++){
            o[harmonic]+=SH[direction*N+harmonic]*Sig[direction];
        }

    }

    return 1;
}


//==============================================================================
//              Compute all spherical harmonics up to order
//                  for a specific direction
//              The order in which they are computed is determined by
//                  the IndexToSHlookup(n,l) function
//==============================================================================
int SHgivenDirection(double SH[], int order, struct ThreeVector *V){

    int n,l;
    int i;
    double R,theta,phi;

    Cartesian2Spherical((*V).x, (*V).y, (*V).z, &R, &theta, &phi);

    for(n=0;n<=order;n+=2){
        for (l=-n;l<=n;l++){
            i=IndexToSHlookup(order, n, l, 0);
            SH[i]=SphericalHarmonicReal(n, l, theta, phi);
        }
    }

    return 1;
}

