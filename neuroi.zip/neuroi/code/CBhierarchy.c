/*
Copyright 2009 - 2019 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "stdlib.h"
#include "loader.h"
#include "numerical.h"
#include "graphtheoryalgorithms.h"
#include "CoordinateProcess.h"
#include "ClusterZ.h"
#include "localALE.h"
#include "imageprocess.h"
#include "Talairachfunctions.h"
#include <math.h>

struct CBclusters
{
    int N;//number of clusters
    struct ThreeVector *V;//the cluster centres
};

struct ClusterCoordinates
{
    float *x;
    float *y;
    float *z;
    int n;
    double sigma2;
};
///external
double SmoothingKernalWidth(int N);


///internal
int MergeTwoClusters(struct Coordinates *Co, struct CBclusters *cbc, int cl1, int cl2);
double *ClusterDistanceMatrix(struct CBclusters *cbc);
double MinusStudyDensity(double P[], int Nparameters, void *cc) ;
int InitialiseCBclusters(struct Coordinates *Co, struct CBclusters *cbc);
int CanClustersMerge(struct Coordinates *Co, int cl1, int cl2);
int RemoveSmallClusters(struct Coordinates *Co, int Nclusters, int min);
int NumberOfStudiesInCluster(struct Coordinates *Co, int cl);
//=================================================================================
int ClusterCoordinatesHierarchical(struct Coordinates *Co)
{
    struct CBclusters cbc;
    int Nfoci=(*Co).TotalFoci;
    double *dij=NULL;
    double dist;
    int i,j;
    int Nclusters;


    memset(&cbc,0,sizeof(struct CBclusters));
    if (!(cbc.V=(struct ThreeVector *)malloc(sizeof(struct ThreeVector)*Nfoci)))
        goto END;

    InitialiseCBclusters(Co, &cbc);

    dij = ClusterDistanceMatrix(&cbc);
    for (dist=1.0; dist<=100.0; dist+=5.0)
    {
        for (j=0; j<cbc.N; j++)
        {
            for (i=j+1; i<cbc.N; i++)
            {
                if (dij[i+j*cbc.N]<dist)
                {
                    if (CanClustersMerge(Co, i+1, j+1))
                    {
                        MergeTwoClusters(Co, &cbc, i+1, j+1);
                        free(dij);
                        dij = ClusterDistanceMatrix(&cbc);
                    }
                }
            }
        }
    }

    Nclusters=RemoveSmallClusters(Co, cbc.N, 5);

END:
    if (cbc.V)
        free(cbc.V);

    return Nclusters;
}

//=================================================================================
int RemoveSmallClusters(struct Coordinates *Co, int Nclusters, int min)
{
    int cl;
    int *H=NULL;
    int *study=NULL;
    int iexp;
    int focus;
    int Nfoci=(*Co).TotalFoci;
    int newcl=0;

    if (!(H=(int *)calloc(Nclusters+1,sizeof(int))))
        goto END;

    for (cl=1; cl<=Nclusters; cl++)
    {
        H[cl] = NumberOfStudiesInCluster(Co, cl);
        if (H[cl]<min)
        {
            H[cl]=0;
        }
        else
        {
            newcl++;
            H[cl]=newcl;
        }
    }

    ///renumber the clusters
    for (focus=0; focus<Nfoci; focus++)
    {
        (*Co).cluster[focus]=H[(*Co).cluster[focus]];
    }


END:
    if (H)
        free(H);
    if (study)
        free(study);
    return newcl;
}
//=================================================================================
//=================================================================================
int NumberOfStudiesInCluster(struct Coordinates *Co, int cl)
{
    int focus;
    int iexp;
    int Nstudies=0;
    int *study=NULL;

    if (!(study=(int *)calloc((*Co).Nexperiments,sizeof(int)))) goto END;

    for (focus=0; focus<(*Co).TotalFoci; focus++)
    {
        if ((*Co).cluster[focus]==cl) study[(*Co).experiment[focus]]=1;
    }
    for (iexp=0; iexp<(*Co).Nexperiments; iexp++)
    {
        if (study[iexp])  Nstudies++;
    }

END:
    if (study) free(study);
    return Nstudies;
}
//=================================================================================
//=================================================================================
int InitialiseCBclusters(struct Coordinates *Co, struct CBclusters *cbc)
{
    int focus;
    for (focus=0; focus<(*Co).TotalFoci; focus++)
    {
        (*Co).cluster[focus]=focus+1;
        (*cbc).V[focus].x=(*Co).x[focus];
        (*cbc).V[focus].y=(*Co).y[focus];
        (*cbc).V[focus].z=(*Co).z[focus];
    }
    (*cbc).N=(*Co).TotalFoci;
    return 1;
}
//=================================================================================
//=================================================================================
double *ClusterDistanceMatrix(struct CBclusters *cbc)
{
    double *dm=NULL;
    double dij;
    int i,j;

    if (!(dm=(double *)malloc((*cbc).N*(*cbc).N*sizeof(double))))
        return dm;

    for (j=0; j<(*cbc).N; j++)
    {
        dm[j + (*cbc).N*j]=0.0;
        for (i=j+1; i<(*cbc).N; i++)
        {
            dij=sqrt(
                    ((*cbc).V[i].x - (*cbc).V[j].x)*((*cbc).V[i].x - (*cbc).V[j].x) +
                    ((*cbc).V[i].y - (*cbc).V[j].y)*((*cbc).V[i].y - (*cbc).V[j].y) +
                    ((*cbc).V[i].z - (*cbc).V[j].z)*((*cbc).V[i].z - (*cbc).V[j].z)
                );
            dm[i + (*cbc).N*j]=dij;
            dm[j + (*cbc).N*i]=dij;
        }
    }


    return dm;
}
//=================================================================================
//merge clusters cl1 and cl2
//change cluster numbers inside the Coordinates structure
//change cluster means inside CBclusters structure
int MergeTwoClusters(struct Coordinates *Co, struct CBclusters *cbc, int cl1, int cl2)
{
    int lo,hi;
    int Nfoci=(*Co).TotalFoci;
    int focus;
    struct ThreeVector V;
    int count;

    if (cl1<cl2)
    {
        lo=cl1;
        hi=cl2;
    }
    else
    {
        lo=cl2;
        hi=cl1;
    }

    //change cluster hi to cluster lo
    for (focus=0; focus<Nfoci; focus++)
    {
        if ((*Co).cluster[focus]==hi)
            (*Co).cluster[focus]=lo;
    }

    //change highest number cluster to cluster hi
    for (focus=0; focus<Nfoci; focus++)
    {
        if ((*Co).cluster[focus]==(*cbc).N)
            (*Co).cluster[focus]=hi;
    }
    (*cbc).V[hi-1]=(*cbc).V[(*cbc).N-1];
    (*cbc).N--;//there is now one less cluster

    //compute the new mean location of cluster lo
    V.x=V.y=V.z=0.0;
    count=0;
    for (focus=0; focus<Nfoci; focus++)
    {
        if ((*Co).cluster[focus]==lo)
        {
            V.x+=(*Co).x[focus];
            V.y+=(*Co).y[focus];
            V.z+=(*Co).z[focus];
            count++;
        }
    }
    if (count)
    {
        (*cbc).V[lo-1].x=V.x/count;
        (*cbc).V[lo-1].y=V.z/count;
        (*cbc).V[lo-1].y=V.z/count;
    }


    return 1;
}


//============================================================
//============================================================
int CanClustersMerge(struct Coordinates *Co, int cl1, int cl2)
{
    struct ClusterCoordinates CC;
    double P[3];
    double scale[3]= {1.0,1.0,1.0};
    int isolution;
    int focus;
    int Nfoci=(*Co).TotalFoci;
    double d2;
    double SD;
    float xs[2],ys[2],zs[2];
    int merge=0;//default cant be merged
    int Nstudies;

    memset(&CC,0,sizeof(struct ClusterCoordinates));

    if (!(CC.x=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
    if (!(CC.y=(float *)malloc(Nfoci*sizeof(float))))
        goto END;
    if (!(CC.z=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    //fill the simulated cluster structure
    CC.n=0;
    for (focus=0; focus<Nfoci; focus++)
    {
        if ((*Co).cluster[focus]==cl1 || (*Co).cluster[focus]==cl2)
        {
            CC.x[CC.n]=(*Co).x[focus];
            CC.y[CC.n]=(*Co).y[focus];
            CC.z[CC.n]=(*Co).z[focus];
            CC.n++;
        }
    }
    Nstudies=NumberOfStudiesInCluster(Co,cl1) + NumberOfStudiesInCluster(Co,cl2) ;
    CC.sigma2=pow(SmoothingKernalWidth(Nstudies),2);

    isolution=0;
    for (focus=0; focus<CC.n; focus++)
    {
        P[0]=CC.x[focus];
        P[1]=CC.y[focus];//initialise parameters at coordinates
        P[2]=CC.z[focus];
        DownHillSimplex(P,3,scale,1,MinusStudyDensity,&CC,20);
        xs[isolution]=P[0];
        ys[isolution]=P[1];//the solutions
        zs[isolution]=P[2];

        if (isolution)
        {
            d2=(xs[0]-xs[1])*(xs[0]-xs[1]) + (ys[0]-ys[1])*(ys[0]-ys[1]) + (zs[0]-zs[1])*(zs[0]-zs[1]);
            if (d2>1.0)
                goto END;
        }

        isolution=1;
    }


    merge=1;//can be merged
END:
    if (CC.x)
        free(CC.x);
    if (CC.y)
        free(CC.y);
    if (CC.z)
        free(CC.z);

    return merge;
}
//============================================================
//============================================================
//============================================================
double MinusStudyDensity(double P[], int Nparameters, void *cc)
{
    struct ClusterCoordinates *CC=(struct ClusterCoordinates *)cc;
    double x0,y0,z0;
    int Nc=(*CC).n;
    int i;
    double D=0.0;
    double spread2=(*CC).sigma2*2.0;

    x0=P[0];
    y0=P[1];
    z0=P[2];

    for (i=0; i<Nc; i++)
    {
        D+=exp(
               -((*CC).x[i]-x0)*((*CC).x[i]-x0)/spread2
               -((*CC).y[i]-y0)*((*CC).y[i]-y0)/spread2
               -((*CC).z[i]-z0)*((*CC).z[i]-z0)/spread2
           );
    }
    return -D;
}
