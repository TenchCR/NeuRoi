/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#define CLUSTER_TOL 0.1

#include "MeanShiftCoordinatesLOO.h"




int LabelShiftedCoordinateClusters(float x[], float y[], float z[], short int c[],
                                   short int experiment[], short int ToCluster[], int Nfoci, int Nexperiments,
                                   float xc[], float yc[], float zc[]);
int MeanShiftCoordinates(float xc[], float yc[], float zc[], struct Coordinates *C,  short int ToCluster[], double MaxDist);

int RemoveSmallClusters(struct Coordinates *C, int Nclusters, int MinStudies, float xc[], float yc[], float zc[]);
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[],
                 int Nexperiments, double dist2[], short int ToCluster[], int Nfoci, double MaxDist);



//================================================================================================================
//================================================================================================================
int GetValidMeanShiftClusters(struct Coordinates *C, float xc[], float yc[], float zc[],
                              int MinStudiesPerCluster, short int ToCluster[], double width)
{
    int Nfoci=(*C).TotalFoci;
    float *xms=NULL;
    float *yms=NULL;
    float *zms=NULL;
    int Nclusters=0;
    short int *cl=NULL;

    //default the cluster numbers to zero
    memset((*C).cluster,0,sizeof(short int)*Nfoci);

    if (width<=0.0)
    {
        goto END;
    }

    if (!(xms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(yms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(zms=(float *)malloc(Nfoci*sizeof(float))))
        goto END;

    if (!(cl=(short int *)calloc(Nfoci,sizeof(short int))))
        goto END;

    ///shift the coordinates by mean shift clustering
    memcpy(xms, (*C).x,Nfoci*sizeof(float));
    memcpy(yms, (*C).y,Nfoci*sizeof(float));
    memcpy(zms, (*C).z,Nfoci*sizeof(float));

    ///SHIFT THE COORDINATES
    MeanShiftCoordinates(xms, yms, zms, C, ToCluster, width);

    ///LABEL
    Nclusters = LabelShiftedCoordinateClusters(xms, yms, zms, cl, (*C).experiment, ToCluster, Nfoci, (*C).Nexperiments, xc, yc, zc);
    memcpy((*C).cluster, cl, sizeof(short int)*Nfoci);


END:

    if (xms)
        free(xms);

    if (yms)
        free(yms);

    if (zms)
        free(zms);

    if (cl)
        free(cl);

    return Nclusters;
}
//======================================================================================================
//==============================================================================================
int RemoveSmallClusters(struct Coordinates *C, int Nclusters, int MinStudies,
                        float xc[], float yc[], float zc[])
{
    int Nfoci=(*C).TotalFoci;
    int focus;
    int *count=NULL;
    int cl;
    int *clnew=NULL;
    char *StudyInCluster=NULL;
    int upto=0;

    if (!(StudyInCluster=(char *)calloc((Nclusters+1)*(*C).Nexperiments, sizeof(char))))
        goto END;

    if (!(count=(int *)calloc(Nclusters+1, sizeof(int))))
        goto END;

    if (!(clnew=(int *)calloc(Nclusters+1, sizeof(int))))
        goto END;

    for (focus=0; focus<Nfoci; focus++)
    {

            if ((cl=(*C).cluster[focus]) && !StudyInCluster[(*C).experiment[focus]*(Nclusters+1) + cl])
            {
                StudyInCluster[(*C).experiment[focus]*(Nclusters+1) + cl] = 1;
                count[cl]++;
            }

    }

    for (cl=1; cl<=Nclusters; cl++)
    {
        if (count[cl]>=MinStudies)
        {
            upto++;
            clnew[cl] = upto;
        }
    }

    for (focus=0; focus<Nfoci; focus++)
    {
        if ((cl=(*C).cluster[focus]))
        {
            (*C).cluster[focus] = clnew[cl];
        }
        else
        {
            (*C).cluster[focus]=0;
        }
    }

    memset(xc,0,sizeof(float)*Nfoci);
    memset(yc,0,sizeof(float)*Nfoci);
    memset(zc,0,sizeof(float)*Nfoci);
    memset(count,0,sizeof(int)*(Nclusters+1));
    for (focus=0; focus<Nfoci; focus++)
    {
        if ((cl=(*C).cluster[focus]))
        {
            xc[cl-1]+=(*C).x[focus];
            yc[cl-1]+=(*C).y[focus];
            zc[cl-1]+=(*C).z[focus];
            count[cl-1]++;
        }
    }
    for (cl=1; cl<=upto; cl++)
    {
        if (count[cl-1])
        {
            xc[cl-1]/=count[cl-1];
            yc[cl-1]/=count[cl-1];
            zc[cl-1]/=count[cl-1];
        }
    }

END:
    if (count)
        free(count);

    if (clnew)
        free(clnew);

    if (StudyInCluster)
        free(StudyInCluster);

    return upto;
}
//======================================================================================================
int MeanShiftCoordinates(float xc[], float yc[], float zc[],
                         struct Coordinates *C, short int ToCluster[],
                         double MaxDist)
{
    int Nfoci=(*C).TotalFoci;
    double *dist2=NULL;
    int iter;
    int focus;
    int result=0;
    double shift2=0.0;
    float *xs=NULL;
    float *ys=NULL;
    float *zs=NULL;


    if (!(dist2=(double *)malloc(sizeof(double)*Nfoci*Nfoci)))
        goto END;

    if (!(xs=(float *)malloc(sizeof(float)*Nfoci)))
        goto END;

    if (!(ys=(float *)malloc(sizeof(float)*Nfoci)))
        goto END;

    if (!(zs=(float *)malloc(sizeof(float)*Nfoci)))
        goto END;

    memcpy(xc, (*C).x, sizeof(float)*Nfoci);
    memcpy(yc, (*C).y, sizeof(float)*Nfoci);
    memcpy(zc, (*C).z, sizeof(float)*Nfoci);

    iter=0;
    do
    {
        CoordinateDistance2MatrixNoStudies(xc, yc, zc, dist2, Nfoci, 1.0);

        shift2 = GetShifts(xs, ys, zs, xc, yc, zc, (*C).experiment, (*C).Nexperiments, dist2, ToCluster, Nfoci, MaxDist);

        for (focus=0; focus<Nfoci; focus++)
        {
            xc[focus]+=xs[focus];
            yc[focus]+=ys[focus];
            zc[focus]+=zs[focus];
        }
        iter++;
    }
    while(iter<1000 && shift2>CLUSTER_TOL);

    result=1;
END:
    if (dist2)
    {
        free(dist2);
    }
    if (xs)
    {
        free(xs);
    }
    if (ys)
    {
        free(ys);
    }
    if (zs)
    {
        free(zs);
    }
    return result;
}




//=======================================================================================================
double GetShifts(float xs[], float ys[], float zs[], float x[], float y[], float z[], short int iexp[],
                 int Nexperiments,double dist2[], short int ToCluster[], int Nfoci, double MaxDist)
{
    double MaxDist2=MaxDist*MaxDist;
    double norm;
    double *w=NULL,wtmp;
    int *bestfocus=NULL;
    int focus,i;
    int FocusNfoci;
    double MaxShift2=0.0;
    double shift2;

    if (MaxDist<=0.0)
        return 0.0;

    if (!(w=(double *)malloc(sizeof(double)*Nexperiments)))
        goto END;

    if (!(bestfocus=(int *)malloc(sizeof(int)*Nexperiments)))
        goto END;



    for (focus=0; focus<Nfoci; focus++)
    {
        xs[focus]=ys[focus]=zs[focus]=0.0;
        if (ToCluster[focus])
        {

            FocusNfoci=focus*Nfoci;

            for (i=0; i<Nexperiments; i++)
            {
                w[i]=MaxDist2;
            }


            for (i=0; i<Nfoci; i++)
            {
                if (ToCluster[i])
                {
                    if (iexp[i]!=iexp[focus] && dist2[FocusNfoci + i]<MaxDist2)
                    {

                        wtmp = dist2[FocusNfoci + i];
                        if (wtmp<w[iexp[i]])
                        {
                            w[iexp[i]]=wtmp;
                            bestfocus[iexp[i]]=i;
                        }

                    }
                }
            }

            norm=0.0;
            for (i=0; i<Nexperiments; i++)
            {
                if (w[i]<MaxDist2)
                {
                    wtmp=1.0;
                    xs[focus] += wtmp*(x[bestfocus[i]]-x[focus]);
                    ys[focus] += wtmp*(y[bestfocus[i]]-y[focus]);
                    zs[focus] += wtmp*(z[bestfocus[i]]-z[focus]);
                    norm+=wtmp;
                }
            }


            if (norm>0.0)
            {
                norm*=2.0;//only move half way to mean
                xs[focus]/=norm;
                ys[focus]/=norm;
                zs[focus]/=norm;
                shift2=xs[focus]*xs[focus] + ys[focus]*ys[focus] + zs[focus]*zs[focus];
                if (shift2>MaxShift2)
                {
                    MaxShift2=shift2;
                }
            }


        }//ToCluster
    }//for (focus..



END:
    if (w)
        free(w);

    if (bestfocus)
        free(bestfocus);

    return MaxShift2;
}
//==============================================================================================
//xc, yc, zc are the cluster centres on exit
//x[], y[]. z[] are the shifted coordinates. These should coincide if they are in the same cluster
int LabelShiftedCoordinateClusters(float x[], float y[], float z[], short int c[],
                                   short int experiment[], short int ToCluster[], int Nfoci, int Nexperiments,
                                   float xc[], float yc[], float zc[])
{
    int Nclusters=0;
    int focus, focus2;
    int study;
    double d2, min2=4.0;//min2 is tolerance after being mean shifted to convergence
    double *closest=NULL;
    int *FocusInCluster=NULL;
    int *CLcount=NULL;
    int cl;

    if (!(CLcount=(int *)calloc(Nfoci, sizeof(int))))
        goto END;

    if (!(closest=(double *)calloc(Nexperiments, sizeof(double))))
        goto END;

    if (!(FocusInCluster=(int *)calloc(Nexperiments, sizeof(int))))
        goto END;

    memset(c,0,sizeof(short int)*Nfoci);
    memset(xc, 0, sizeof(float)*Nfoci);
    memset(yc, 0, sizeof(float)*Nfoci);
    memset(zc, 0, sizeof(float)*Nfoci);

    for (focus=0; focus<Nfoci; focus++)
    {
        if (ToCluster[focus] && !c[focus])
        {

            Nclusters++;
            c[focus]=Nclusters;

            xc[Nclusters-1] += x[focus];
            yc[Nclusters-1] += y[focus];
            zc[Nclusters-1] += z[focus];
            CLcount[Nclusters-1]++;

            for (focus2=focus+1; focus2<Nfoci; focus2++)
            {
                if (ToCluster[focus2] && focus!=focus2 && !c[focus2])
                {
                    d2=(x[focus]-x[focus2])*(x[focus]-x[focus2]) +
                       (y[focus]-y[focus2])*(y[focus]-y[focus2]) +
                       (z[focus]-z[focus2])*(z[focus]-z[focus2]);

                    if (d2<=min2)
                    {
                        c[focus2]=Nclusters;
                        CLcount[Nclusters-1]++;
                        xc[Nclusters-1] += x[focus];
                        yc[Nclusters-1] += y[focus];
                        zc[Nclusters-1] += z[focus];
                    }
                }
            }
        }
    }

    for (cl=1; cl<=Nclusters; cl++)
    {
        if (CLcount[cl-1])
        {
            xc[cl-1] /= CLcount[cl-1];
            yc[cl-1] /= CLcount[cl-1];
            zc[cl-1] /= CLcount[cl-1];
        }
    }


    ///Remove within study duplicate entries
    for (cl=1; cl<=Nclusters; cl++)
    {
        for (study=0; study<Nexperiments; study++)
        {
            closest[study]=DBL_MAX;
            FocusInCluster[study]=-1;
        }



        for (focus=0; focus<Nfoci; focus++)
        {
            if (ToCluster[focus] && c[focus]==cl)
            {
                d2=(x[focus]-xc[cl-1])*(x[focus]-xc[cl-1]) +
                   (y[focus]-yc[cl-1])*(y[focus]-yc[cl-1]) +
                   (z[focus]-zc[cl-1])*(z[focus]-zc[cl-1]);

                if (d2<closest[experiment[focus]])
                {
                    closest[experiment[focus]]=d2;
                    FocusInCluster[experiment[focus]]=focus;
                }
                c[focus]=0;
            }
        }
        //after this there will be at most 1 coordinate per study contributing to cl
        for (study=0; study<Nexperiments; study++)
        {
            if (FocusInCluster[study]>=0)
            {
                c[FocusInCluster[study]]=cl;
            }
        }
    }


END:
    if (CLcount)
        free(CLcount);

    if (closest)
        free(closest);

    if (FocusInCluster)
        free(FocusInCluster);

    return Nclusters;
}
