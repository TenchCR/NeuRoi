/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "string.h"
#include "stdlib.h"
#include <math.h>
#include "numerical.h"
#include "ClusterZ.h"
#include "localALE.h"
#include "talairachfunctions.h"
#include "global.h"
#include "CBclustering2.h"


/*
An attempt to overcome some limitations in CBclustering
Would like to work only with coordinates to reduce dependency on image resolution when peak finding
Would like to make the minimum number of studies forming a cluster depend on the number of studies
Would like to define a peak resolution limit that improves with the number of studies
*/

///define the proportion of the studies that need to report for in a cluster
#define STUDY_PROPORTION 0.085
///define the absolute minimum reporting studies for a cluster
#define MIN_STUDIES 4


#define BACKGROUND_CLUSTER 0

#define DENSITY_THRESHOLD 1.0



struct OptimisePeak
{
	struct Coordinates *Co;
	double KernelSD;
};
int SaveClusterCentreImage2(struct Image *image, float xc[], float yc[], float zc[], int Nc, char directory[]) ;
double SmoothingKernalWidth2(double N) ;
double MinimumStudies(int Nstudies);

int FindThePeakFromAvoxel(struct Image *image, float density[],
                          float x[], float y[], float z[],
                          short int cluster[],
                          short int experiment[],
                          char voi[],  int Nfoci, int Nexperiments,
                          int FocusVoxel, double kernelSD,
                          int *list, char *visited, int ClusteredOnly, int closest);
double MinimumDensity(int MinStudies);
int SaveMinDensity(void);
int SaveSignificantClusterMeanConnectivity(struct Image *image, struct Coordinates *Co, double pvalue, int Nstudies, double Aij[], int valid[], float xc[], float yc[], float zc[], int Nclusters, char directory[]);
int NearestCoordinatesPerStudy(float x[], float y[], float z[], short int experiment[], int Nexperiments, int Ncoordinates, double D2[]);
//=============================================================================================
//=============================================================================================
int GetClusters(struct Image *img, struct Coordinates *Co, float xc[], float yc[], float zc[], int MinStudiesForInference, int renumber, int save, char directory[])
{

	int Npeaks;
	FILE *fp;
	char fname[MAX_PATH];
	double kernelSD=SmoothingKernalWidth2(MinimumStudies((*Co).Nexperiments));//the smoothing depends on the minimum number of studies to form a cluster

	if (save)
	{
		sprintf(fname,"%s\\Parameters.txt",directory);
		if ((fp=fopen(fname,"w")))
		{
			fprintf(fp,"MinStudiesForInference=%d\n",MinStudiesForInference);
			fprintf(fp,"MIN_STUDIES=%d\n",MIN_STUDIES);
			fprintf(fp,"kernelSD=%f\n",SmoothingKernalWidth2(MinimumStudies((*Co).Nexperiments)));
			fclose(fp);
		}
	}


	Npeaks = GetValidClusters(img, (*Co).x, (*Co).y, (*Co).z, (*Co).voxel, (*Co).cluster, (*Co).experiment, (*Co).VOI, (*Co).TotalFoci, (*Co).Nexperiments,
	                          xc, yc,zc, MinStudiesForInference, kernelSD, save, directory, 0,1);


	if (renumber)
		Npeaks=RenumberClusters2((*Co).cluster, (*Co).TotalFoci, xc, yc, zc, MinStudiesForInference);

	if (save)
		SaveClusterCentreImage2(&gImage, xc, yc, zc, Npeaks, directory);
//return 0;
	return Npeaks;
}
//===================================================================================
int RenumberClusters2(short int cluster[], int TotalFoci, float xc[], float yc[], float zc[], int MinExperiments)
{
	double *H=NULL;
	int *sort=NULL;
	int *newcl=NULL;
	int focus;
	int MaxCluster;
	int cl;
	int Ncut;
	float *x=NULL;
	float *y=NULL;
	float *z=NULL;

	MaxCluster=0;
	for (focus=0; focus<TotalFoci; focus++)
	{
		if (cluster[focus]>MaxCluster)
			MaxCluster=cluster[focus];
	}

	if (!(x=(float *)calloc(MaxCluster,sizeof(float))))
		goto END;
	if (!(y=(float *)calloc(MaxCluster,sizeof(float))))
		goto END;
	if (!(z=(float *)calloc(MaxCluster,sizeof(float))))
		goto END;



	if (!(H=(double *)calloc(MaxCluster,sizeof(double))))
		goto END;
	if (!(sort=(int *)malloc(MaxCluster*sizeof(int))))
		goto END;
	if (!(newcl=(int *)malloc(MaxCluster*sizeof(int))))
		goto END;



	//sorting by size of cluster
	for (focus=0; focus<TotalFoci; focus++)
	{
		if ((cl=cluster[focus]))
			H[cl-1]+=1.0;
	}


	QuickSort(H,sort,MaxCluster);


	for (cl=0; cl<MaxCluster; cl++)
		newcl[sort[cl]]=MaxCluster-cl;



	for (focus=0; focus<TotalFoci; focus++)
	{
		if ((cl=cluster[focus]))
		{
			cluster[focus]=newcl[cl-1];
		}
	}



	for (cl=0; cl<MaxCluster; cl++)
	{
		x[newcl[cl]-1] = xc[cl];
		y[newcl[cl]-1] = yc[cl];
		z[newcl[cl]-1] = zc[cl];
	}


	for (cl=0; cl<MaxCluster; cl++)
	{
		xc[cl]=x[cl];
		yc[cl]=y[cl];
		zc[cl]=z[cl];
	}

	memset(H,0,sizeof(double)*MaxCluster);
	for (focus=0; focus<TotalFoci; focus++)
	{
		if ((cl=cluster[focus]))
			H[cl-1]+=1.0;
	}


	Ncut=0;
	for (cl=0; cl<MaxCluster; cl++)
	{
		if (H[cl]<MinExperiments)
			Ncut++;
	}

	MaxCluster-=Ncut;//remove small clusters


	for (focus=0; focus<TotalFoci; focus++)
	{
		if ((cluster[focus]>MaxCluster))
			cluster[focus]=BACKGROUND_CLUSTER;
	}



END:
	if (H)
		free(H);
	if (sort)
		free(sort);
	if (newcl)
		free(newcl);
	if (x)
		free(x);
	if (y)
		free(y);
	if (z)
		free(z);
	return MaxCluster;
}



//===================================================================================
//===================================================================================
//Having computed the number of peaks detected per simulation of N coordinates; N is the minimum number of coordinates
//This is the value of sigma that gives only a single peak 99% of the time
double SmoothingKernalWidth2(double N)
{

	if (N<=4.0)
		return 6.73;//1% using 5000 simulations
	else if (N>4.0 && N<5.0)
	{
		double dx=N-4.0;
		return (1.0-dx)*6.73 + dx*(8.8945*pow(5.0, -0.22));//the interpolated solution between 4 and 5 minimum studies
	}
	else
		return 8.8945*pow(N, -0.22);//1% using 5000 simulations
}


//===================================================================================
//===================================================================================
//===================================================================================
//The GM volume is around 70000mm^3 (Brain size and grey matter volume in the healthy human brain. Neuroreport 13, 2371�2374)
//95% of a cluster with typical spread of 4mm is 5885mm^3
//There are on average 10 clusters per study (The BrainMap strategy for standardization, sharing, and meta-analysis of neuroimaging data. BMC Res. Notes 4, 349)
//So the min is ~5885*10/70000 about 0.085
double MinimumStudies(int Nstudies)
{
	double n;

	n=STUDY_PROPORTION*Nstudies;
	if (n<(double)MIN_STUDIES)
		n=(double)MIN_STUDIES;

	return n;
}
//===================================================================================
//===================================================================================
int FilterNeighbouringPeaks(float img[], int X, int Y, int Z, int v[], int Nfoci)
{
	int i,j,k,n;
	int voxel,voxels=X*Y*Z;
	int voxeln;
	int vold,vnew;
	int corrections=0;
	int XY=X*Y;

	for (voxel=0; voxel<voxels; voxel++)
	{
		if (img[voxel])
		{
			for (k=-1; k<=1; k++)
			{
				for (j=-1; j<=1; j++)
				{
					for (i=-1; i<=1; i++)
					{
						if (i || j || k)
						{
							voxeln = voxel + i + j*X + k*XY;
							if (voxeln>=0 && voxeln<voxels && img[voxeln])
							{
								corrections++;
								if (img[voxeln]>img[voxel])
								{
									vold=voxel;
									vnew=voxeln;
								}
								else
								{
									vold=voxeln;
									vnew=voxel;
								}
								img[vnew]+=img[vold];
								img[vold]=0.0;
								for (n=0; n<Nfoci; n++)
								{
									if (v[n]==vold)
									{
										v[n]=vnew;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return corrections;
}
//===================================================================================
//===================================================================================
//===================================================================================
//===================================================================================
double ExperimentDensityEstimate2(float x[], float y[], float z[], short int cluster[], short int experiment[], char voi[], int Nfoci, int Nexperiments,
                                  float xc, float yc, float zc, double kernelSD, int ClusteredOnly)
{
	double *expdist2=NULL;
	int focus;
	int iexp;
	double D=0.0;
	double d2;
	double spread2=2.0*kernelSD*kernelSD;
	double dx,dy,dz;

	if (!(expdist2=(double *)malloc(Nexperiments*sizeof(double))))
		goto END;

	//initialise to large distance
	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		expdist2[iexp]=DBL_MAX;
	}


	for (focus=0; focus<Nfoci; focus++)
	{

		if ((!ClusteredOnly) || (ClusteredOnly && cluster[focus]) )
		{
			iexp=experiment[focus];
			if (!voi[iexp])/// NO VOI STUDIES SHOULD CONTRIBUTE TO THE DENSITY ESTIMATE
			{
				dx=xc - x[focus];
				dy=yc - y[focus];
				dz=zc - z[focus];

				d2=dx*dx + dy*dy + dz*dz;

				if (d2<expdist2[iexp])
				{
					expdist2[iexp]=d2;
				}

			}
		}
	}

	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		D+=exp(-expdist2[iexp]/spread2);
	}


END:
	if (expdist2)
	{
		free(expdist2);
	}

	return D;
}
int TestExperimentDensity2(struct Image *image, struct Coordinates *Co)
{
	int x,y,z;
	int voxel;
	float xf,yf,zf;
	double D,maxD=0.0;
	double kernelSD=SmoothingKernalWidth2(MinimumStudies((*Co).Nexperiments));
	voxel=0;
	for (z=0; z<(*image).Z; z++)
	{
		zf=(*image).dz*z - (*image).z0;
		for (y=0; y<(*image).Y; y++)
		{
			yf=(*image).dy*y - (*image).y0;
			for (x=0; x<(*image).X; x++)
			{
				xf=(*image).dx*x - (*image).x0;
				D=ExperimentDensityEstimate2((*Co).x, (*Co).y, (*Co).z, (*Co).cluster, (*Co).experiment, (*Co).VOI, (*Co).TotalFoci, (*Co).Nexperiments, xf, yf, zf, kernelSD, 0);
				(*image).img[voxel]=(float)D;
				if (D>maxD)
					maxD=D;
				voxel++;
			}
		}
	}
	(*image).MaxIntensity=maxD;

	/*int focus;
	for (focus=0;focus<(*Co).TotalFoci;focus++)
	{
	    (*image).img[(*Co).voxel[focus]]=maxD;
	}*/
	return 0;
}
//======================================================================================================
int SaveClusterCentreImage2(struct Image *image, float xc[], float yc[], float zc[], int Nc, char directory[])
{
	struct Image cpy;
	int c;
	int i,j,k;
	int ix,iy,iz;
	int width=4;

	memset(&cpy,0,sizeof(struct Image));

	MakeCopyOfImage(image, &cpy);
	memset(cpy.img, 0,cpy.X*cpy.Y*cpy.Z*sizeof(float));
	cpy.DataType=DT_BINARY;

	for (c=0; c<Nc; c++)
	{

		ix=(xc[c]+cpy.x0)/cpy.dx;
		iy=(yc[c]+cpy.y0)/cpy.dy;
		iz=(zc[c]+cpy.z0)/cpy.dz;

		for (k=-width; k<=width; k++)
		{
			for (j=-width; j<=width; j++)
			{
				for (i=-width; i<=width; i++)
				{
					if ((i*i + j*j + k*k)<=3*3)
					{
						if (InImageRange(ix+i, iy+j, iz+k,cpy.X, cpy.Y, cpy.Z))
						{
							cpy.img[ix+i + (iy+j)*cpy.X + (iz+k)*cpy.X*cpy.Y]=1.0;
						}
					}
				}
			}
		}
	}

	sprintf(cpy.filename,"%s\\ClusterCentres.nii",directory);
	cpy.ImageType=NIFTI;
	//Save(&cpy);
	SaveAsCharImage(&cpy,0);


	ReleaseImage(&cpy);

	return 1;
}
//====================================================================================
//define the minimum density, which is computed using the MinDensity function
//here a linear model of the linear density as a function of the min studies is used
//====================================================================================
double MinimumDensity(int MinStudies)
{
	return  0.3248*MinStudies + 0.8542;
}
//====================================================================================
//FIND THE MINIMUM DENSITY
struct MinDensityStruct
{
	float x[500];
	float y[500];
	float z[500];
	int N;
	double SD2;
};
//====================================================================================
double Density(double P[], int N, void *md);
double MinDensity(int StudiesInCluster)
{
	double D[1000];
	int sort[1000];
	struct MinDensityStruct MD;
	double mean[3];
	double Sigma[9];
	double r[3];
	int study;
	int iter;
	double P[3];
	double scale[3]= {1.0,1.0,1.0};
	double SD;

	MD.SD2=pow(SmoothingKernalWidth2((double)StudiesInCluster),2);
	MD.N=StudiesInCluster;
	for (iter=0; iter<1000; iter++)
	{
		do
		{
			SD=GaussRandomNumber_BoxMuller(4.0,0.4);
		}
		while(SD<3.0 || SD>5.0);
		memset(mean,0,sizeof(double)*3);
		memset(Sigma,0.0,9*sizeof(double));
		Sigma[0]=Sigma[4]=Sigma[8]=SD*SD;
		memset(P,0,sizeof (double));
		for (study=0; study<StudiesInCluster; study++)
		{
			rMVnorm(r, mean, Sigma, 3);
			MD.x[study]=r[0];
			MD.y[study]=r[1];
			MD.z[study]=r[2];
		}
		memset(P,0,sizeof(double)*3);
		D[iter] = -DownHillSimplex(P,3,scale,1,Density,&MD,40);
	}

	QuickSort(D, sort, 1000);

	return D[sort[50]];
}
//=========================================================
double Density(double P[], int N, void *md)
{
	struct MinDensityStruct *MD=(struct MinDensityStruct *)md;
	int i;
	double D=0.0;
	double d2;

	for (i=0; i<(*MD).N; i++)
	{
		d2=(P[0]-(*MD).x[i])*(P[0]-(*MD).x[i]) + (P[1]-(*MD).y[i])*(P[1]-(*MD).y[i]) + (P[2]-(*MD).z[i])*(P[2]-(*MD).z[i]);
		D += exp(-d2/2.0/(*MD).SD2);
	}

	return -D;
}
//==========================================================
int SaveMinDensity(void)
{
	int MinStudies;
	FILE *fp=NULL;
	char fname[MAX_PATH];
	sprintf(fname,"%s//MinD.csv",REPORT_FOLDER);
	fp=fopen(fname,"w");

	for (MinStudies=4; MinStudies<=10; MinStudies+=1)
	{
		fprintf(fp,"%d,%f\n",MinStudies, MinDensity(MinStudies));
	}
	fclose(fp);

	return 0;
}
//================================================================================================
//================================================================================================
int SaveSignificantClusterDensity2(struct Image *image, struct Coordinates *Co, double pvalue, int Nstudies, char directory[])
{
	struct Image Density;
	int focus;
	char fname[MAX_PATH];
	int voxel;
	int voxels;
	double KernelSD=SmoothingKernalWidth2(MinimumStudies(Nstudies));

	voxels=(*image).X*(*image).Y*(*image).Z;

	memset(&Density,0,sizeof(struct Image));
	if (!MakeCopyOfImage(image, &Density))
	{
		MessageBox(NULL,"Can't create image","SaveSignificantClusterDensity2",MB_OK);
		return 0;
	}

	Density.DataType=DT_FLOAT;
	Density.ImageType=NIFTI;

	for (focus=0; focus<(*Co).TotalFoci; focus++)
	{
		if ((*Co).p[focus]>pvalue)
			(*Co).cluster[focus]=0;
	}


	GetDensity2(&Density, (*Co).x, (*Co).y, (*Co).z, (*Co).cluster, (*Co).experiment, (*Co).VOI, (*Co).TotalFoci, (*Co).Nexperiments, KernelSD);
	for (voxel=0; voxel<voxels; voxel++)
	{
		if (Density.img[voxel]<DENSITY_THRESHOLD)
			Density.img[voxel]=0.0;
	}
	sprintf(fname,"%s\\ClusterDensity.nii",directory);
	sprintf(Density.filename, "%s", fname);
	//Save(&Density);
	SaveAsCharImage(&Density,1);

	ReleaseImage(&Density);

	return 1;
}
//================================================================================================
//================================================================================================
int SaveSignificantClusterMeanConnectivity(struct Image *image, struct Coordinates *Co, double pvalue, int Nstudies, double Aij[], int valid[], float xc[], float yc[], float zc[], int Nclusters, char directory[])
{
	struct Image Density;
	int focus;
	char fname[MAX_PATH];
	int voxel;
	int voxels;
	int cl,i;
	int xi,yi,zi;
	float xf,yf,zf;
	double dx2;
	double KernelSD=SmoothingKernalWidth2(MinimumStudies(Nstudies));
	double spread2=2.0*KernelSD*KernelSD;
	double *Dpeak=NULL;
	double *MeanR=NULL;

	memset(&Density,0,sizeof(struct Image));

	if (!(Dpeak=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	if (!(MeanR=(double *)malloc(Nclusters*sizeof(double))))
		goto END;
	///compute the RMS connectivity between clusters
	///also compute the peak density
	for (cl=1; cl<=Nclusters; cl++)
	{
		Dpeak[cl-1]=ExperimentDensityEstimate2((*Co).x, (*Co).y, (*Co).z, (*Co).cluster, (*Co).experiment, (*Co).VOI, (*Co).TotalFoci, (*Co).Nexperiments, xc[cl-1], yc[cl-1],zc[cl-1],KernelSD,1);
		MeanR[cl-1]=0.0;
		for (i=1; i<=Nclusters; i++)
		{
			if (cl!=i && valid[(cl-1)*Nclusters + i-1])
			{
				MeanR[cl-1] += Aij[(cl-1)*Nclusters + i-1]*Aij[(cl-1)*Nclusters + i-1];
			}
		}
	}
	//------------------------------------------------------------------------------------------------------

	voxels=(*image).X*(*image).Y*(*image).Z;
	if (!MakeCopyOfImage(image, &Density))
		return 0;
	Density.DataType=DT_FLOAT;
	Density.ImageType=NIFTI;
	memset(Density.img,0,voxels*sizeof(float));

	//non significant clusters are made background
	for (focus=0; focus<(*Co).TotalFoci; focus++)
	{
		if ((*Co).p[focus]>pvalue)
			(*Co).cluster[focus]=0;
	}

	///compute the mean covariance and remove density by normalising to peak density
	voxel=0;
	for (zi=0; zi<(*image).Z; zi++)
	{
		zf=(*image).dz*zi - (*image).z0;
		for (yi=0; yi<(*image).Y; yi++)
		{
			yf=(*image).dy*yi - (*image).y0;
			for (xi=0; xi<(*image).X; xi++)
			{
				xf=(*image).dx*xi - (*image).x0;

				for (focus=0; focus<(*Co).TotalFoci; focus++)
				{
					if ((cl=(*Co).cluster[focus]))
					{
						dx2=((*Co).x[focus] - xf)*((*Co).x[focus] - xf) +
						    ((*Co).y[focus] - yf)*((*Co).y[focus] - yf) +
						    ((*Co).z[focus] - zf)*((*Co).z[focus] - zf);
						Density.img[voxel]+=exp(-dx2/spread2)*MeanR[cl-1]/Dpeak[cl-1];
					}
				}

				voxel++;
			}
		}
	}


	sprintf(fname,"%s\\ClusterMeanCovariance.nii",directory);
	sprintf(Density.filename, "%s", fname);
	//Save(&Density);
	SaveAsCharImage(&Density,1);

END:
	ReleaseImage(&Density);
	if (Dpeak)
		free(Dpeak);
	if (MeanR)
		free(MeanR);

	return 1;
}
//================================================================================================
//===================================================================================
//===================================================================================
int GetDensity2(struct Image *image, float x[], float y[], float z[], short int cluster[], short int experiment[], char voi[], int Nfoci, int Nexperiments, double kernelSD)
{
	int voxel;
	float xf,yf,zf;
	int xi,yi,zi;
	double D;

	(*image).MaxIntensity=0.0;
	voxel=0;
	for (zi=0; zi<(*image).Z; zi++)
	{
		for (yi=0; yi<(*image).Y; yi++)
		{
			for (xi=0; xi<(*image).X; xi++)
			{
				xf=(*image).dx*xi - (*image).x0;
				yf=(*image).dy*yi - (*image).y0;
				zf=(*image).dz*zi - (*image).z0;
				D=ExperimentDensityEstimate2(x,y,z,cluster,experiment,voi,Nfoci,Nexperiments,xf,yf,zf,kernelSD,0);

				(*image).img[voxel]=D;

				if (D>(*image).MaxIntensity)
					(*image).MaxIntensity=D;
				voxel++;
			}
		}
	}


	return 0;
}
///=====================================================================================
/*
Starting from a focus voxel, find the peak voxel
Assigned: tells the function what peak voxel other foci are already assigned to; default to <0
Focus: this is the focus being assigned
PeakImg: this is an image of where the Peaks are
FocusImage: this tells us if there are foci (can be multiple) at a voxel
*/
int FindThePeakFromAvoxel(struct Image *image, float density[],
                          float x[], float y[], float z[],
                          short int cluster[],
                          short int experiment[],
                          char voi[],  int Nfoci, int Nexperiments,
                          int FocusVoxel, double kernelSD,
                          int *list, char *visited, int ClusteredOnly, int closest)
{
	int PeakVoxel=-1;
	int IsPeak;
	int voxel;
	int upto,current;
	int X=(*image).X;
	int Y=(*image).Y;
	int Z=(*image).Z;
	int XY=X*Y;
	int Neighbour26[26];
	int voxels;
	int xi,yi,zi;
	int l26,n;
	float xf,yf,zf;
	float xv,yv,zv;//the coordinate of the coordinate at FocusVoxel
	double dist2,d2;
	double peakdensity;

	l26=0;
	for (zi=-1; zi<=1; zi++)
	{
		for (yi=-1; yi<=1; yi++)
		{
			for (xi=-1; xi<=1; xi++)
			{
				if (x||y||z)
				{
					Neighbour26[l26]=xi+yi*X+zi*XY;
					l26++;
				}
			}
		}
	}

	voxels=X*Y*Z;
	memset(visited,0,voxels);

	XYZfromVoxelNumber(FocusVoxel, &xi, &yi, &zi, X, Y, Z);
	if (!InImageRange(xi,yi,zi,X,Y,Z))
		return -1;
	xf=(*image).dx*xi - (*image).x0;
	xv=xf;
	yf=(*image).dy*yi - (*image).y0;
	yv=yf;
	zf=(*image).dz*zi - (*image).z0;
	zv=zf;


	dist2=DBL_MAX;
	upto=current=0;
	list[current]=FocusVoxel;
	visited[FocusVoxel]=1;
	if (density[FocusVoxel]<=0.0)
	{
		density[FocusVoxel]=ExperimentDensityEstimate2(x, y, z, cluster, experiment, voi, Nfoci, Nexperiments, xf,yf,zf, kernelSD,ClusteredOnly);
	}

	peakdensity=0.0;
	while( (current<=upto) && upto<voxels)
	{
		voxel=list[current];
		IsPeak=1;//assume the voxel is a peak
		for (l26=0; l26<26; l26++)
		{
			n=voxel+Neighbour26[l26];
			XYZfromVoxelNumber(n, &xi, &yi, &zi, X, Y, Z);
			if (InImageRange(xi,yi,zi,X,Y,Z))
			{
				if (!visited[n])
				{
					visited[n]=1;
					xf=(*image).dx*xi - (*image).x0;
					yf=(*image).dy*yi - (*image).y0;
					zf=(*image).dz*zi - (*image).z0;

					density[n]=ExperimentDensityEstimate2(x, y, z, cluster, experiment, voi, Nfoci, Nexperiments, xf,yf,zf, kernelSD,ClusteredOnly);

					if (density[n]>=density[voxel])
					{
						upto++;
						list[upto]=n;
					}
				}

				if (density[n]>density[voxel])
				{
					IsPeak=0;
				}

			}
		}
		if (IsPeak)   //this voxel is a peak. Is it the closest peak?
		{
			if (closest)
			{
				XYZfromVoxelNumber(voxel, &xi, &yi, &zi, X, Y, Z);
				xf=(*image).dx*xi - (*image).x0;
				yf=(*image).dy*yi - (*image).y0;
				zf=(*image).dz*zi - (*image).z0;
				d2=(xv-xf)*(xv-xf) + (yv-yf)*(yv-yf) + (zv-zf)*(zv-zf);
				if (d2<dist2)
				{
					PeakVoxel=voxel;//record the closest peak
					dist2=d2;
				}
			}
			else
			{
				if (density[voxel]>peakdensity)//CHANGED TO HIGHEST, RATHER THAN NEAREST, 20/10/2020
				{
					peakdensity=density[voxel];
					PeakVoxel=voxel;
				}
			}

		}

		current++;
	}

	return PeakVoxel;
}


//===================================================================================
//===================================================================================
//This function does not produce clusters, only peaks that are separated my at least a minimum distance
//===================================================================================
//Modified to assign coordinate with highest density within study.
//Previously assigned coordinate neatest to peak
int GetValidClusters(struct Image *img, float x[], float y[], float z[], int voxel[],short int cluster[],short int experiment[], char voi[], int Nfoci, int Nexperiments,
                     float xc[], float yc[], float zc[], int MinStudiesExternal, double kernelSD, int save, char directory[], int ClusteredOnly, int closest)
{
	int Nclusters=0;
	int focus;
	int MinStudies;
	double MinD;
	double D;
	double *maxdensity=NULL;
	float xf,yf,zf;
	int xi,yi,zi;
	int count;
	int iexp;
	int *v=NULL;
	int *mostdense=NULL;
	int vox,voxels=(*img).X*(*img).Y*(*img).Z;
	struct Image im,density;
	short int *clusternumber=NULL;
	int *list=NULL;
	char *visited=NULL;

	if (!(list=(int *)malloc(voxels*sizeof(int))))
		goto END;
	if (!(visited=(char *)malloc(voxels)))
		goto END;

	memset(&im,0,sizeof(struct Image));
	memset(&density,0,sizeof(struct Image));

	MinStudies=(MinimumStudies(Nexperiments)>MinStudiesExternal) ? MinimumStudies(Nexperiments):MinStudiesExternal;//chose the biggest of these

	MinD=MinimumDensity(MinStudies);//the minimum density is for the min number of studies

	if (!(MakeCopyOfImage(img, &im)))
		goto END;
	if (!(MakeCopyOfImage(img, &density)))
		goto END;


	if (!(v=(int *)malloc(Nfoci*sizeof(int))))
		goto END;
	if (!(maxdensity=(double *)malloc(Nexperiments*sizeof(double))))
		goto END;
	if (!(mostdense=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(clusternumber=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;


	memset(im.img, 0, sizeof(float)*voxels);
	memset(density.img, 0, sizeof(float)*voxels);
	for (focus=0; focus<Nfoci; focus++)
	{
		if ( (!ClusteredOnly) || cluster[focus] )
		{
			vox=voxel[focus];///These must be correct. Check if randomising
			v[focus]=FindThePeakFromAvoxel(img, density.img, x, y, z, cluster, experiment, voi, Nfoci, Nexperiments, vox, kernelSD, list, visited, ClusteredOnly, closest);
			if (v[focus]>=0)
			{
				im.img[v[focus]]+=1.0;
			}
		}
		else
			v[focus]=-1;
	}


	if (save)
	{
		sprintf(density.filename,"%s/FindPeaks %5.2f.nii",directory,kernelSD);
		density.ImageType=NIFTI;
		density.offset=0.0;
		density.scale=1.0;
		Save(&density);
		SaveAsCharImage(&density,1);
	}


	if (save)
	{
		sprintf(im.filename,"%s/AllPeaks.nii",directory);
		im.ImageType=NIFTI;
		im.offset=0.0;
		im.scale=1.0;
		SaveAsCharImage(&im,0);
	}

	for (vox=0; vox<voxels; vox++)
	{
		if (im.img[vox]>=(float)MinStudies && density.img[vox]>=MinD)
		{
			XYZfromVoxelNumber(vox, &xi, &yi, &zi, im.X, im.Y, im.Z);
			xf=im.dx*xi - im.x0;
			yf=im.dy*yi - im.y0;
			zf=im.dz*zi - im.z0;

			memset(maxdensity,0,sizeof(double)*Nexperiments);

			//find the densest
			for (focus=0; focus<Nfoci; focus++)
			{
				iexp=experiment[focus];
				if (v[focus]==vox)
				{
					D=density.img[ voxel[ focus ] ];
					if (D>maxdensity[ iexp ])
					{
						maxdensity[ iexp ]=D;
						mostdense[ iexp ]=focus;
					}
				}
			}

			//how many experiments are contributing?
			count=0;
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (maxdensity[ iexp ] > 0.0)
				{
					count++;
				}
			}

			if ( count >= MinStudies )
			{
				xc[Nclusters]=xf;
				yc[Nclusters]=yf;
				zc[Nclusters]=zf;
				Nclusters++;
				for (iexp=0; iexp<Nexperiments; iexp++)
				{
					if (maxdensity[ iexp ] > 0.0)
					{
						clusternumber[ mostdense[ iexp ] ]=Nclusters;
					}
				}
			}
			else
				im.img[vox]=0.0;
		}
		else
			im.img[vox]=0.0;
	}
	memcpy(cluster, clusternumber, sizeof(short int)*Nfoci);


	if (save)
	{
		sprintf(im.filename,"%s/peaks.nii",directory);
		im.ImageType=NIFTI;
		im.offset=0.0;
		im.scale=1.0;
		SaveAsCharImage(&im,1);
	}

END:

	if (clusternumber)
		free(clusternumber);
	if (v)
		free(v);
	if (mostdense)
		free(mostdense);
	if (maxdensity)
		free(maxdensity);
	if (list)
		free(list);
	if (visited)
		free(visited);

	ReleaseImage(&im);
	ReleaseImage(&density);

	return Nclusters;
}

//======================================================================================================
//======================================================================================================
int ReportClustersCBMAN(HWND hwnd, struct Coordinates *CoordinateStruct,
                        char directory[], char file[],
                        int X, int Y, int Z, float z0,
                        float dx, float dy, float dz,
                        double critical,
                        float xc[], float yc[], float zc[], int Nclusters)
{
	char fname[MAX_PATH];
	FILE *fp;
	int cluster;
	int *experiments=NULL;      //how many experiments contribute to the clusters
	int Nfoci=(*CoordinateStruct).TotalFoci;
	int NsignificantFoci;
	int foci, iexp, FoundContributor;
	int xi,yi,zi;
	float x,y,z;
	char *labels=NULL;
	char *b=NULL;
	int Nentries,Nl;
	struct Image Tal;



//LOAD THE TALAIRACH DATA
	memset(&Tal,0,sizeof(struct Image));
	sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
	LoadFromFileName(hwnd, fname, &Tal, 0);
	labels=LoadTalairachLabels(&Nl);
	Nentries=BiggestTalairachLabel(labels, Nl);
	RemoveNonGM(&Tal, labels, Nl,Nentries);

//count the number of significant foci
	NsignificantFoci=0;
	for (foci=0; foci<Nfoci; foci++)
	{
		if ((*CoordinateStruct).p[foci]<=critical)
			NsignificantFoci++;
	}

//count the number of significant studies contributing to each cluster
	if (!(experiments=(int *)malloc((Nclusters+1)*sizeof(int))))
		goto END;
	memset(experiments,0,(Nclusters+1)*sizeof(int));
	for (cluster=1; cluster<=Nclusters; cluster++)
	{
		for (iexp=0; iexp<(*CoordinateStruct).Nexperiments; iexp++)
		{
			FoundContributor=0;
			for (foci=0; foci<Nfoci; foci++)
			{
				if (((*CoordinateStruct).experiment[foci] == iexp) &&
				        ((*CoordinateStruct).cluster[foci] == cluster) &&
				        ((*CoordinateStruct).p[foci] <= critical))
					FoundContributor=1;
			}
			if (FoundContributor)
				experiments[cluster]++;
		}
	}



	sprintf(fname,"%s\\%s",directory,file);
	if ((fp=fopen(fname,"w")))
	{
		fprintf(fp,"%s\n",(*CoordinateStruct).coordinate_file_name);

		if (critical>0.0)
			fprintf(fp,"p-value for significance <=, %f\n", critical);
		else
			fprintf(fp,"p-value for significance =, 0.0\n");

		fprintf(fp,"Proportion of foci that are significant,%f\n",(float)NsignificantFoci/Nfoci);
		fprintf(fp,"Number of foci, %d\n", (*CoordinateStruct).TotalFoci);
		fprintf(fp,"Number of studies, %d\n", (*CoordinateStruct).Nexperiments);
		fprintf(fp,"Talairach report, , , , , Cluster{x y z},Number Of significant Studies,Slice,,Studies,,,,,Nearest GM\n\n");
		for (cluster=1; cluster<=Nclusters; cluster++)
		{

			if (experiments[cluster])
			{

				if (fp)
					fprintf(fp,"cluster %d\n",cluster);

				x=xc[cluster-1];
				y=yc[cluster-1];
				z=zc[cluster-1];

				xi=(int)((x+Tal.x0)/Tal.dx+0.5);
				yi=(int)((y+Tal.y0)/Tal.dy+0.5);
				zi=(int)((z+Tal.z0)/Tal.dz+0.5);

				if (labels && Tal.img)
				{
					b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
					if (fp)
						fprintf(fp,"%s,",&b[1]);
				}

				zi=(int)((z+z0)/dz+0.5);
				if (fp)
					fprintf(fp," (%5.1f  %5.1f  %5.1f),%d,%d,,", x, y, z,experiments[cluster], zi);

				//list each experiment that contributes to this cluster
				//report the lowest p value for the experiment, and indicate if it is significant
				for (iexp=0; iexp<(*CoordinateStruct).Nexperiments; iexp++)
				{
					for (foci=0; foci<Nfoci; foci++)
					{
						if (((*CoordinateStruct).cluster[foci]==cluster) && ((*CoordinateStruct).experiment[foci] == iexp))
						{

							if (fp)
								fprintf(fp,"%s, %s, %s, %5.1f  %5.1f  %5.1f,Zscore=%5.1f,",
								        (*CoordinateStruct).ID[(*CoordinateStruct).experiment[foci]].txt,
								        (*CoordinateStruct).CTRST[(*CoordinateStruct).experiment[foci]].txt,
								        (*CoordinateStruct).CND[(*CoordinateStruct).experiment[foci]].txt,
								        (*CoordinateStruct).x[foci],(*CoordinateStruct).y[foci],(*CoordinateStruct).z[foci],(*CoordinateStruct).Zsc[foci]);

							if (labels && Tal.img)
							{
								xi=(int)(((*CoordinateStruct).x[foci]+Tal.x0)/Tal.dx+0.5);
								yi=(int)(((*CoordinateStruct).y[foci]+Tal.y0)/Tal.dy+0.5);
								zi=(int)(((*CoordinateStruct).z[foci]+Tal.z0)/Tal.dz+0.5);
								b=FindEntryInTalairachLabels(labels, Nl, NearestGM(Tal.img, Tal.X, Tal.Y, Tal.Z, xi, yi, zi));
								if (fp)
									fprintf(fp,"%s\n , , , , , , , , ,",&b[1]);
							}
						}
					}

				}

				if (fp)
					fprintf(fp,"\n");
			}
		}
		fclose(fp);
	}


END:
	if (labels)
		free(labels);
	if (experiments)
		free(experiments);
	ReleaseImage(&Tal);

	return Nclusters;
}
///==============================================================================================================
///==============================================================================================================
///==============================================================================================================
///==============================================================================================================
///==============================================================================================================
///==============================================================================================================
///==============================================================================================================
/*
///OLD METHOD ASSIGNS COORDINATE WITHIN EXPERIMENT THAT IS NEAREST TO THE PEAK
int GetValidClusters(struct Image *img, struct Coordinates *Co, float x[], float y[], float z[], int MinStudiesExternal, double kernelSD, int save, char directory[], int ClusteredOnly)
{
	int Nclusters=0;
	int Nfoci=(*Co).TotalFoci;
	int focus;
	int MinStudies;
	double MinD;
	double D, spread2;
	double dist2;
	double *mindist2=NULL;
	float xf,yf,zf;
	int xi,yi,zi;
	int count;
	int iexp,Nexperiments=(*Co).Nexperiments;
	int *v=NULL;
	int *closest=NULL;
	int voxel,voxels=(*img).X*(*img).Y*(*img).Z;
	struct Image im,density;
	short int *clusternumber=NULL;
	int *list=NULL;
	char *visited=NULL;

	if (!(list=(int *)malloc(voxels*sizeof(int))))
		goto END;
	if (!(visited=(char *)malloc(voxels)))
		goto END;

	memset(&im,0,sizeof(struct Image));
	memset(&density,0,sizeof(struct Image));

	MinStudies=(MinimumStudies(Nexperiments)>MinStudiesExternal) ? MinimumStudies(Nexperiments):MinStudiesExternal;//chose the biggest of these

	spread2=2.0*kernelSD*kernelSD;
	MinD=MinimumDensity(MinStudies);//the minimum density is for the min number of studies

	if (!(MakeCopyOfImage(img, &im)))
		goto END;
	if (!(MakeCopyOfImage(img, &density)))
		goto END;


	if (!(v=(int *)malloc(Nfoci*sizeof(int))))
		goto END;
	if (!(mindist2=(double *)malloc(Nexperiments*sizeof(double))))
		goto END;
	if (!(closest=(int *)malloc(Nexperiments*sizeof(int))))
		goto END;
	if (!(clusternumber=(short int *)calloc(Nfoci,sizeof(short int))))
		goto END;


	memset(im.img, 0, sizeof(float)*voxels);
	memset(density.img, 0, sizeof(float)*voxels);
	for (focus=0; focus<Nfoci; focus++)
	{
		if ( (!ClusteredOnly) || (*Co).cluster[focus] )
		{
			voxel=(*Co).voxel[focus];
			v[focus]=FindThePeakFromAvoxel(img, density.img, Co, voxel, kernelSD, list, visited, ClusteredOnly);
			if (v[focus]>=0)
            {
                im.img[v[focus]]+=1.0;
            }
		}
		else v[focus]=-1;
	}


	if (save)
	{
		sprintf(density.filename,"%s/FindPeaks %5.2f.nii",directory,kernelSD);
		density.ImageType=NIFTI;
		density.offset=0.0;
		density.scale=1.0;
		SaveAsCharImage(&density,1);
	}


	if (save)
	{
		sprintf(im.filename,"%s/AllPeaks.nii",directory);
		im.ImageType=NIFTI;
		im.offset=0.0;
		im.scale=1.0;
		SaveAsCharImage(&im,0);
	}

	for (voxel=0; voxel<voxels; voxel++)
	{
		if (im.img[voxel]>=(float)MinStudies && density.img[voxel]>=MinD)
		{
			XYZfromVoxelNumber(voxel, &xi, &yi, &zi, im.X, im.Y, im.Z);
			xf=im.dx*xi - im.x0;
			yf=im.dy*yi - im.y0;
			zf=im.dz*zi - im.z0;

			for (iexp=0; iexp<Nexperiments; iexp++)
				mindist2[iexp]=DBL_MAX;

			//find the closest to proposed peak
			for (focus=0; focus<Nfoci; focus++)
			{
				iexp=(*Co).experiment[focus];
				if (v[focus]==voxel)
				{
					dist2= ((*Co).x[focus]-xf)*((*Co).x[focus]-xf) + ((*Co).y[focus]-yf)*((*Co).y[focus]-yf) + ((*Co).z[focus]-zf)*((*Co).z[focus]-zf);
					if (dist2<mindist2[iexp])
					{
						mindist2[iexp]=dist2;
						closest[iexp]=focus;
					}
				}
			}

			//how many experiments are contributing?
			count=0;
			D=0.0;
			for (iexp=0; iexp<Nexperiments; iexp++)
			{
				if (mindist2[iexp]<DBL_MAX)
					{
					    count++;
                        D+=exp(-mindist2[iexp]/spread2);
					}
			}

			if (count>=MinStudies && D>=MinD)
			{
				x[Nclusters]=xf;
				y[Nclusters]=yf;
				z[Nclusters]=zf;
				Nclusters++;
				for (iexp=0; iexp<Nexperiments; iexp++)
				{
					if (mindist2[iexp]<DBL_MAX)
                    {
						clusternumber[closest[iexp]]=Nclusters;
                    }
				}
			}
			else
				im.img[voxel]=0.0;
		}
		else
			im.img[voxel]=0.0;
	}
	memcpy((*Co).cluster, clusternumber, sizeof(short int)*Nfoci);


	if (save)
	{
		sprintf(im.filename,"%s/peaks.nii",directory);
		im.ImageType=NIFTI;
		im.offset=0.0;
		im.scale=1.0;
		SaveAsCharImage(&im,1);
	}



END:

	if (clusternumber)
		free(clusternumber);
	if (v)
		free(v);
    if (mindist2)
        free(mindist2);
	if (closest)
		free(closest);
	if (list)
		free(list);
	if (visited)
		free(visited);

	ReleaseImage(&im);
	ReleaseImage(&density);

	return Nclusters;
}
*/
