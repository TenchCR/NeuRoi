/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "global.h"


#define SCROLL_MAX 10000
#define SCROLL_MIN 0

//=============================================================================================
//                           Auto ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK HighlightDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    int hi, lo;
    int pos;
    static float min, max;
    char txt[256];

    switch(msg) {

	case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        gMainPict.Highlight=0;
        SendMessage((HWND)GetParent(hwnd), WM_COMMAND, ID_REDRAW,0);
		EndDialog(hwnd,0);
		hRange=(HWND)NULL;
	break;



    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        if (!IsImageScalar(gImage.DataType)){
            MessageBox(NULL, "Used for scalar images","",MB_OK|MB_ICONWARNING);
            SendMessage(hwnd, WM_CLOSE,0,0);
        }
        gMainPict.Highlight=1;
        SendMessage(GetDlgItem(hwnd,ID_RANGE_HI),SBM_SETRANGE,SCROLL_MIN+1,SCROLL_MAX);
		SendMessage(GetDlgItem(hwnd,ID_RANGE_HI),SBM_SETPOS,SCROLL_MAX,TRUE);
		SendMessage(GetDlgItem(hwnd,ID_RANGE_LO),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX-1);
		SendMessage(GetDlgItem(hwnd,ID_RANGE_LO),SBM_SETPOS,SCROLL_MAX-1,TRUE);
		min=0.0;
		max=gImage.MaxIntensity;
    break;





    case WM_HSCROLL:
		pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		switch (LOWORD(wParam)){
			case SB_LINELEFT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-1) , TRUE);
				break;
			case SB_LINERIGHT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+1) , TRUE);
				break;
			case SB_PAGELEFT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos-SCROLL_MAX/10) , TRUE);
				break;
			case SB_PAGERIGHT:
				SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(pos+SCROLL_MAX/10) , TRUE);
				break;
			case SB_THUMBTRACK:
				SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam) , TRUE);
				break;
		}

		hi = (int)SendMessage( GetDlgItem(hwnd,ID_RANGE_HI), SBM_GETPOS, 0, 0);
		lo = (int)SendMessage( GetDlgItem(hwnd,ID_RANGE_LO), SBM_GETPOS, 0, 0);

		if (hi<=lo){                                                    //hi shouldnt be <= lo
            hi=lo+1;
            SendMessage(GetDlgItem(hwnd,ID_RANGE_HI),SBM_SETPOS,hi,TRUE);
        }
        min=(float)(gImage.MaxIntensity*lo/SCROLL_MAX);
        max=(float)(gImage.MaxIntensity*hi/SCROLL_MAX);
        sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*hi/SCROLL_MAX)));
        SendMessage(GetDlgItem(hwnd,ID_RANGE_HI_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		sprintf(txt,"%f",Intensity(&gImage, (float)(gImage.MaxIntensity*lo/SCROLL_MAX)));
		SendMessage(GetDlgItem(hwnd,ID_RANGE_LO_TEXT),WM_SETTEXT,0,(LPARAM)txt);
		gMainPict.HighlightHi=gImage.MaxIntensity*hi/SCROLL_MAX;
		gMainPict.HighlightLo=gImage.MaxIntensity*lo/SCROLL_MAX;
		SendMessage((HWND)GetParent(hwnd), WM_COMMAND, ID_REDRAW, 0);
    break;





    case WM_COMMAND:
	  switch (LOWORD(wParam)) {


        case ID_LIMIT_INTENSITY:

            IntensityFilter(&gImage, min, max);
        break;


        case ID_REMOVE_BACKGROUND:
            RemoveNoisyBackground(gImage.img, gImage.X, gImage.Y, gImage.Z/gImage.volumes, gImage.volumes, min);
        break;

		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
		break;
      }
	  break;
	}
	return 0;
}



