
#include "Testing.h"

int NumberOfOnes(int I, int bits);

//======================================================================================================
int NumberOfOnesTest(int I, int bits)
{
    int i, count=(I & 1);

    if (bits > sizeof(int)*8) return 0;

    for (i=1; i<bits; i++)
    {
        if ((I>>i)&1) count++;
    }
    return count;
}
int TestNumberOfOnes(void)
{
    int number = 7;
    char txt[256];

    sprintf(txt,"%d %d",number, NumberOfOnesTest(number,8));
    MessageBox(NULL,txt,"",MB_OK);

    return 0;
}
//======================================================================================================
//check permutation calculation for LocalALE
//Na (Nb): number of elements in group A (B)
//Ap (Bp): the number of positive results in group A (B)
int CheckPermutationCount(int Na, int Nb, int Ap, int Bp)
{
    int Np = Ap + Bp;
    int max;
    int i,ones;
    double sum = 0.0;
    double d = exp(LogFactorial(Na) + LogFactorial(Nb) - LogFactorial(Na+Nb));
    char txt[256];

    if (Np>10) return -1;

    max = pow(2,Np);

    for (i=0;i<=max;i++)
    {
        ones = NumberOfOnes(i, Np);
        if ( (ones <= Na) && (Np - ones <= Nb) )
        {
            sum += d*Combinations(Na + Nb - Ap - Bp, Na - ones);
        }
    }

    sprintf(txt,"%d %f",max,sum);
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}
