/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "global.h"
int GetUpdatedHeaderValues(HWND hwnd, float *dx, float *dy, float *dz, short int *X, short int *Y, short int *Z, short int *volumes,
                            float *offset, float *scale, float *x0, float *y0, float *z0, char descrip[]);
//=============================================================================================
//                           Edit header dialog box function
//=============================================================================================
INT_PTR CALLBACK HeaderDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

    char txt[256];
    short int X, Y, Z;
    short int volumes;
    int voxel, voxels;
    int i;
    int slicespv;
    float dx, dy, dz;
    float x0, y0, z0;
    float scale, offset;

    switch(msg) {


	case WM_CLOSE:
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hHeader=(HWND)NULL;
		EndDialog(hwnd,0);
	break;





    case WM_INITDIALOG:
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        sprintf(txt,"%f",gImage.dx);
        SendMessage(GetDlgItem(hwnd,ID_VOXEL_XDIM),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",gImage.dy);
        SendMessage(GetDlgItem(hwnd,ID_VOXEL_YDIM),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",gImage.dz);
        SendMessage(GetDlgItem(hwnd,ID_VOXEL_ZDIM),WM_SETTEXT,0,(LPARAM)txt);

        sprintf(txt,"%d",gImage.X);
        SendMessage(GetDlgItem(hwnd,ID_MATRIX_XDIM),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%d",gImage.Y);
        SendMessage(GetDlgItem(hwnd,ID_MATRIX_YDIM),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%d",gImage.Z);
        SendMessage(GetDlgItem(hwnd,ID_MATRIX_ZDIM),WM_SETTEXT,0,(LPARAM)txt);

        sprintf(txt,"%d",gImage.volumes);
        SendMessage(GetDlgItem(hwnd,ID_MATRIX_VOLUMES),WM_SETTEXT,0,(LPARAM)txt);

        sprintf(txt,"%f",gImage.x0);
        SendMessage(GetDlgItem(hwnd,ID_ORG_X),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",gImage.y0);
        SendMessage(GetDlgItem(hwnd,ID_ORG_Y),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",gImage.z0);
        SendMessage(GetDlgItem(hwnd,ID_ORG_Z),WM_SETTEXT,0,(LPARAM)txt);

        sprintf(txt,"%f",gImage.scale);
        SendMessage(GetDlgItem(hwnd,ID_SCALE),WM_SETTEXT,0,(LPARAM)txt);
        sprintf(txt,"%f",gImage.offset);
        SendMessage(GetDlgItem(hwnd,ID_OFFSET),WM_SETTEXT,0,(LPARAM)txt);

        sprintf(txt,"%s",gImage.Descrip);
        SendMessage(GetDlgItem(hwnd,ID_DESCRIP),WM_SETTEXT,0,(LPARAM)txt);

    break;




    case WM_COMMAND:
	  switch (LOWORD(wParam)) {



        case ID_CHANGE_HEADER:
            GetUpdatedHeaderValues(hwnd, &dx, &dy, &dz, &X, &Y, &Z, &volumes,
                            &offset, &scale, &x0, &y0, &z0, gImage.Descrip);
            if (dx>0.0 && dy>0.0 && dz>0.0){
                gImage.dx=dx;
                gImage.dy=dy;
                gImage.dz=dz;
            }

            if (volumes && !(gImage.Z%volumes))   gImage.volumes=volumes;
            else MessageBox(NULL,"The number of slices must be a finite multiple of the number of volumes", "", MB_OK|MB_ICONWARNING);


            gImage.x0=x0;
            gImage.y0=y0;
            gImage.z0=z0;


            gImage.scale=scale;
            gImage.offset=offset;
            SendMessage(hwnd, WM_INITDIALOG, 0, 0);
        break;



        case ID_CHANGE_IMAGE:
            GetUpdatedHeaderValues(hwnd, &dx, &dy, &dz, &X, &Y, &Z, &volumes,
                            &offset, &scale, &x0, &y0, &z0, gImage.Descrip);
            if ((dx<=0.0) || (dy<=0.0) || (dz<=0.0) || (X<=0) || (Y<=0) || (Z<=0)){
                MessageBox(NULL,"Voxel sizes must be > 0", "", MB_OK|MB_ICONWARNING);
                goto out;
            }

            if ((((int)(gImage.dx/dx*gImage.X+0.5)!=gImage.X)
                 || ((int)(gImage.dy/dy*gImage.Y+0.5)!=gImage.Y)
                 || ((int)(gImage.dz/dz*gImage.Z+0.5)!=gImage.Z))){             //change voxel sizes by interpolation/integration

                ReSizeImage(&gImage, dx, dy, dz);
            }
            else if ((X!=gImage.X) || (Y!=gImage.Y) || (Z!=gImage.Z)){
                    dx=gImage.dx*gImage.X/X;
                    dy=gImage.dy*gImage.Y/Y;
                    dz=gImage.dz*gImage.Z/Z;

                    ReSizeImage(&gImage, dx, dy, dz);
            }

            out:
            SendMessage(hwnd, WM_INITDIALOG, 0, 0);
            gMainPict.ML.valid=0;
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,1);
            SetFocus(GetParent(hwnd));
        break;


        case ID_MAKE_SLICE_FIRST:
            slicespv=gImage.Z/gImage.volumes;
            voxel=gImage.X*gImage.Y*gMainPict.slice;
            voxels=gImage.X*gImage.Y*(gImage.Z-gMainPict.slice);
            for (i=0;i<voxels;i++) gImage.img[i]=gImage.img[i+voxel];
            gImage.img=(float *)realloc(gImage.img,voxels*sizeof(float));
            gImage.Z=(gImage.Z-gMainPict.slice);
            gImage.volumes=gImage.Z/slicespv;
            if (gImage.volumes*slicespv!=gImage.Z) gImage.volumes=1;
            if (!gImage.img){
                MessageBox(NULL,"Memory error. This program will close","",MB_OK|MB_ICONWARNING);
                SendMessage(GetParent(hwnd), WM_CLOSE,0,0);
                break;
            }
            gImage.changed=1;
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,1);
        break;

        case ID_MAKE_SLICE_LAST:
            slicespv=gImage.Z/gImage.volumes;
            voxels=gImage.X*gImage.Y*(gMainPict.slice+1)*sizeof(float);
            gImage.img=(float *)realloc(gImage.img,voxels);
            gImage.Z=gMainPict.slice+1;
            gImage.volumes=gImage.Z/slicespv;
            if (gImage.volumes*slicespv!=gImage.Z) gImage.volumes=1;
            if (!gImage.img){
                MessageBox(NULL,"Memory error. This program will close","",MB_OK|MB_ICONWARNING);
                SendMessage(GetParent(hwnd), WM_CLOSE,0,0);
                break;
            }
            gImage.changed=1;
            SendMessage(GetParent(hwnd), WM_COMMAND, ID_REDRAW,1);
        break;

        case IDM_MIRROR:
            SendMessage(GetParent(hwnd), WM_COMMAND, IDM_MIRROR,0);
        break;

		case IDOK:
			SendMessage(hwnd, WM_CLOSE,0,0);
		break;

      }
	  break;
	}
	return 0;
}


//=============================================================================================
//                              get the updates values
//=============================================================================================
int GetUpdatedHeaderValues(HWND hwnd, float *dx, float *dy, float *dz, short int *X, short int *Y, short int *Z, short int *volumes,
                            float *offset, float *scale, float *x0, float *y0, float *z0, char descrip[]){

    char txt[256];

    SendMessage(GetDlgItem(hwnd,ID_MATRIX_XDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*X)=atoi(txt);
    SendMessage(GetDlgItem(hwnd,ID_MATRIX_YDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*Y)=atoi(txt);
    SendMessage(GetDlgItem(hwnd,ID_MATRIX_ZDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*Z)=atoi(txt);


    SendMessage(GetDlgItem(hwnd,ID_VOXEL_XDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*dx)=atof(txt);
    SendMessage(GetDlgItem(hwnd,ID_VOXEL_YDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*dy)=atof(txt);
    SendMessage(GetDlgItem(hwnd,ID_VOXEL_ZDIM),WM_GETTEXT,256,(LPARAM)txt);
    (*dz)=atof(txt);


    SendMessage(GetDlgItem(hwnd,ID_MATRIX_VOLUMES),WM_GETTEXT,256,(LPARAM)txt);
    if (atoi(txt) && !(gImage.Z%atoi(txt)))  (*volumes)=atoi(txt);

    SendMessage(GetDlgItem(hwnd,ID_ORG_X),WM_GETTEXT,256,(LPARAM)txt);
    (*x0)=atof(txt);
    SendMessage(GetDlgItem(hwnd,ID_ORG_Y),WM_GETTEXT,256,(LPARAM)txt);
    (*y0)=atof(txt);
    SendMessage(GetDlgItem(hwnd,ID_ORG_Z),WM_GETTEXT,256,(LPARAM)txt);
    (*z0)=atof(txt);

    SendMessage(GetDlgItem(hwnd,ID_SCALE),WM_GETTEXT,256,(LPARAM)txt);
    (*scale)=atof(txt);
    SendMessage(GetDlgItem(hwnd,ID_OFFSET),WM_GETTEXT,256,(LPARAM)txt);
    (*offset)=atof(txt);


    SendMessage(GetDlgItem(hwnd,ID_DESCRIP),WM_GETTEXT,80,(LPARAM)descrip);

    return 1;
}




//=============================================================================================
//                             Display header information
//=============================================================================================
int ShowHeader(struct Image *image){

    char txt[2048];

    sprintf(txt,"%s\n\n", (*image).filename);                                     //FILENAME
    sprintf(txt,"%sMatrix {X,Y,Z, volumes}={%d, %d, %d, %d}\n\n",txt,(*image).X,(*image).Y,(*image).Z,(*image).volumes);
    sprintf(txt,"%sVoxel size ( %s ) {x,y,z}={%f, %f, %f}\n\n",txt,(*image).VoxUnits,(*image).dx,(*image).dy,(*image).dz);
    sprintf(txt,"%sScale=%f, Offset=%f\n\n",txt,(*image).scale, (*image).offset);
    sprintf(txt,"%sPatient ID: %s\n\n",txt,(*image).PatientID);
    sprintf(txt,"%sDescription: %s\n\n",txt,(*image).Descrip);
    if ((*image).ImageType==HDR) sprintf(txt,"%sImageType: Analyze\n\n",txt);
    else
    {
        sprintf(txt,"%sImageType: NIFTI (method=%d)\n",txt, (*image).NIFTImethod);
        if ((*image).NIFTImethod!=1) sprintf(txt,"%sWarning: NIFTI coordinate transform ignored\n\n", txt);
        else sprintf(txt,"%s\n",txt);
    }

    switch ((*image).DataType){
        case DT_SIGNED_SHORT:
            sprintf(txt,"%sDataType: Short int\n\n",txt);
        break;
        case DT_FLOAT:
            sprintf(txt,"%sDataType: Float\n\n",txt);
        break;
        case DT_DOUBLE:
            sprintf(txt,"%sDataType: Double\n\n",txt);
        break;
        case DT_UNSIGNED_CHAR:
            sprintf(txt,"%sDataType: Unsigned char\n\n",txt);
        break;
        case DT_RGB:
            sprintf(txt,"%sDataType: RGB\n\n",txt);
        break;
    }
    if ((*image).swapbytes) sprintf(txt,"%sBytes swapped\n\n",txt);
    if ((*image).changed) sprintf(txt,"%sThe image has been modified since load",txt);
    MessageBox(NULL,txt,"Header Information",MB_OK);

    return 1;
}


