/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#define MAX_FILES_FOR_BLINDING 100

#include "global.h"
#include "loader.h"

struct ImageID
{
    char filename[MAX_PATH];
    char PatientID[256];
    char descrip[256];
    int r;
};

int Rused(struct ImageID *IDs, int n, int r);

//==========================================================================
//==========================================================================
//==========================================================================
int BlindImageFiles(void)
{

    struct ImageID IDs[MAX_FILES_FOR_BLINDING];
    char *names=NULL;
    char directory[MAX_PATH];
    char fname[MAX_PATH];
    int Nfiles=0;
    int n, r;
    struct Image image;
    FILE *fp;
    char output[MAX_PATH];


    if (!(names=(char *)malloc(MAX_FILES_FOR_BLINDING*MAX_PATH))) goto END;

    Nfiles = GetImageFileNames(names, MAX_FILES_FOR_BLINDING*MAX_PATH, "Select image files for blinding");
    //MessageBox(NULL,names,"",MB_OK);

    sprintf(directory,"%s\\Blinded\\",names);
    //MessageBox(NULL,directory,"",MB_OK);
    CreateDirectory(directory, NULL);


    memset(&image,0,sizeof(struct Image));
    for (n=1;n<=Nfiles;n++)
    {
        GetNthFileName(names, n, fname);
        //MessageBox(NULL,fname,"",MB_OK);
        LoadFromFileName(NULL, fname, &image, 0);
        sprintf(IDs[n-1].filename,"%s",image.filename);
        sprintf(IDs[n-1].PatientID,"%s",image.PatientID);
        sprintf(IDs[n-1].descrip,"%s",image.Descrip);

        do
        {
                r=rand()%500;
        }
        while (Rused(IDs, n, r));
        IDs[n-1].r=r;

        sprintf(image.filename,"%s\\%3d.nii",directory,r);
        sprintf(image.PatientID,"blinded r");
        sprintf(image.Descrip,"r");
        image.ImageType=NIFTI;
        Save(&image);

        ReleaseImage(&image);
    }

    sprintf(output,"%s\\unblind.txt",directory);
    fp=fopen(output,"w");
    for (n=1;n<=Nfiles;n++)
    {
        if (fp)
        {
            fprintf(fp,"Filename: %s\n",IDs[n-1].filename);
            fprintf(fp,"Patient ID: %s\n",IDs[n-1].PatientID);
            fprintf(fp,"Description: %s\n",IDs[n-1].descrip);
            fprintf(fp,"Blinded as %d.nii\n\n\n",IDs[n-1].r);
        }
    }

END:
    if (fp) fclose(fp);
    if (names) free(names);

    return Nfiles;
}
//================================================================================================
//================================================================================================
int Rused(struct ImageID *IDs, int n, int r)
{
    int i;

    for (i=1;i<n;i++)
    {
        if (IDs[i].r == r) return 1;
    }
    return 0;
}
