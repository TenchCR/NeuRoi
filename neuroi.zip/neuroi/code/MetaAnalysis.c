/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


///DO FIXED AND RANDOM EFFECT META-ANALYSIS AS DESCRIBED IN
//A basic introduction to fixed-effect and random-effects models for meta-analysis
//Michael Borensteina, Larry V. Hedges, Julian P.T. Higgins and Hannah R. Rothstein
//DOI: 10.1002/jrsm.12
//Res. Syn. Meth. 2010, 1 97--111

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include "numerical.h"

double FixedEffectMA(double effect[], double weight[], int N, double *var);
double RandomEffectMA(double effect[], double weight[], int N, double *var);
//================================================================================================
//Do fixed effect meta-analysis
//================================================================================================
double FixedEffectMA(double effect[], double weight[], int N, double *var)
{
    double mean=0.0;
    double weightsum=0.0;
    int i;

    for (i=0;i<N;i++)
    {
        mean+=weight[i]*effect[i];
        weightsum+=weight[i];
    }

    if (weightsum>0.0)
    {
        mean/=weightsum;
        (*var)=1.0/weightsum;
    }
    else
    {
        (*var)=DBL_MAX;
    }
    return mean;
}

//================================================================================================
//Do Random Effect meta-analysis
//================================================================================================
double RandomEffectMA(double effect[], double weight[], int N, double *var)
{
    double mean=0.0;
    double weightsum=0.0;
    double weight2sum=0.0;
    double C=0.0;
    double Q=0.0;
    int i;

    for (i=0;i<N;i++)
    {
        weightsum+=weight[i];
        weight2sum+=weight[i]*weight[i];
        mean+=weight[i]*effect[i];
    }

    if (weightsum>0.0)
    {
            mean/=weightsum;
            C=weightsum-weight2sum/weightsum;

            for (i=0;i<N;i++)
            {
                Q+=weight[i]*(effect[i]-mean)*(effect[i]-mean);
            }

            if (Q>(double)(N-1))
            {
                (*var)=(Q-(double)(N-1))/C/N;
            }
            else (*var)=0.0;
    }


    return mean;
}
//================================================================================================
//================================================================================================
//================================================================================================
#define MA_TEST_POINTS 100
int TestMA(void)
{

    double e[MA_TEST_POINTS];
    double w[MA_TEST_POINTS];
    double studyvar=1.0;
    double sigma=5.0;
    double mean=10.0;
    double r;
    int i;
    double meanFFX,meanRFX;
    double varFFX, varRFX;
    char txt[256];

    for (i=0;i<MA_TEST_POINTS;i++)
    {
        w[i]=1.0/studyvar;
        r=GaussRandomNumber_BoxMuller(mean,sigma);
        e[i]=GaussRandomNumber_BoxMuller(r,sqrt(studyvar));
    }

    meanFFX=FixedEffectMA(e,w,MA_TEST_POINTS,&varFFX);
    meanRFX=RandomEffectMA(e,w,MA_TEST_POINTS,&varRFX);

    sprintf(txt,"%f  %f\n%f  %f",meanFFX,varFFX,meanRFX,varRFX);
    MessageBox(NULL,txt,"",MB_OK);

    return 1;
}


