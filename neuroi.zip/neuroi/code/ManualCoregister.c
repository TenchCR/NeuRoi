/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/





#define SCROLL_MAX 10
#define SCROLL_MIN 0

#define MAX_POINTS 100

#define BASE 0
#define MATCH 1

#include "coregister.h"
#include "global.h"

int SwapImages(HWND hwnd, struct Image *image);
int ShowBaseMatchMixManual(HWND hwnd, struct Image *Base, struct Image *Match, int slice, struct AffineMatrix *Amat, double fraction, float saturation);
//=============================================================================================
//                           Manual Coregistration dialog callback function
//                              Uses 12 parameters for affine transformation
//=============================================================================================
INT_PTR CALLBACK ManualCoregisterDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	struct AffineMatrix M;
	int posinit,pos;
	int xi,yi,zi;
	float xf,yf,zf;
	char txt[256];
	static struct ThreeVector Vbase[MAX_POINTS];
	static struct ThreeVector Vmatch[MAX_POINTS];
	static struct Image match, base;
	static int BaseCount, MatchCount;
	static int turn;

	switch(msg)
	{


	case WM_CLOSE:///---------------------------
		SetMenuItemState(GetParent(hwnd), MF_ENABLED);

		ReleaseImage(&base);
		ReleaseImage(&match);

		hCoregisterDlg=(HWND)NULL;
		EndDialog(hwnd,0);
		break;


	case WM_SHOWWINDOW:///--------------------

		break;


	case WM_INITDIALOG:///---------------------------
		memset(&Vbase,0,sizeof(struct ThreeVector)*MAX_POINTS);
		memset(&Vmatch,0,sizeof(struct ThreeVector)*MAX_POINTS);

		memset(&match,0,sizeof(struct Image));
		memset(&base,0,sizeof(struct Image));

		MakeCopyOfImage(&gImage, &base);

		turn=BASE;
		BaseCount=MatchCount=0;
		break;





	case WM_HSCROLL:///-----------------------------
		posinit = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		switch (LOWORD(wParam))
		{
		case SB_LINELEFT:
			SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-1), TRUE);
			break;
		case SB_LINERIGHT:
			SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+1), TRUE);
			break;
		case SB_PAGELEFT:
			SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-SCROLL_MAX/5), TRUE);
			break;
		case SB_PAGERIGHT:
			SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+SCROLL_MAX/5), TRUE);
			break;
		case SB_THUMBTRACK:
			SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam), TRUE);
			break;
		}
		pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
		if (pos!=posinit)
		{
			//SHOW MIXED IMAGE
			if (turn==BASE)
				ShowBaseMatchMixManual(GetParent(hwnd), &base, &match, gMainPict.slice, &M, (double)pos/SCROLL_MAX, gMainPict.saturation);
		}
		SetFocus(GetParent(hwnd));
		break;


	case WM_LBUTTONDOWN:///--------------------------
		if (!match.img || !base.img)
			break;
		if (MatchCount>=MAX_POINTS-1)
			break;

		RemoveInput(GetParent(hwnd));

		xi=gMainPict.x;
		yi=gMainPict.y;
		zi=gMainPict.slice;
		xf=gImage.dx*xi - gImage.x0;
		yf=gImage.dy*yi - gImage.y0;
		zf=gImage.dz*zi - gImage.z0;
		sprintf(txt,"%d %d %d\n%f %f %f",xi,yi,zi,xf,yf,zf);
		MessageBox(NULL,txt,"",MB_OK);

		if (turn==BASE)
		{
			Vbase[BaseCount].x=xf;
			Vbase[BaseCount].y=yf;
			Vbase[BaseCount].z=zf;
			BaseCount++;
			SwapImages(GetParent(hwnd),  &match);
			turn=MATCH;
			sprintf(txt,"%d",BaseCount);
			SendMessage(GetDlgItem(hwnd,ID_BASE_POINTS),WM_SETTEXT,0,(LPARAM)txt);
			UpdateWindow(hwnd);
		}
		else
		{
			Vmatch[MatchCount].x=xf;
			Vmatch[MatchCount].y=yf;
			Vmatch[MatchCount].z=zf;
			MatchCount++;
			SwapImages(GetParent(hwnd), &base);
			turn=BASE;
			sprintf(txt,"%d",MatchCount);
			SendMessage(GetDlgItem(hwnd,ID_MATCH_POINTS),WM_SETTEXT,0,(LPARAM)txt);
			UpdateWindow(hwnd);
		}
		break;


	case WM_COMMAND:
		switch (LOWORD(wParam))
		{

		case ID_UNDO_LAST_POINT:///------------
			if (turn==BASE && BaseCount>0)
			{
				if (SwapImages(GetParent(hwnd),  &match))
				{
					BaseCount--;
					turn=MATCH;
					sprintf(txt,"%d",BaseCount);
					SendMessage(GetDlgItem(hwnd,ID_BASE_POINTS),WM_SETTEXT,0,(LPARAM)txt);
					UpdateWindow(hwnd);
				}
			}
			else if (MatchCount>0)
			{
				if (SwapImages(GetParent(hwnd),  &base))
				{
					MatchCount--;
					turn=BASE;
					sprintf(txt,"%d",MatchCount);
					SendMessage(GetDlgItem(hwnd,ID_MATCH_POINTS),WM_SETTEXT,0,(LPARAM)txt);
					UpdateWindow(hwnd);
				}
			}
			break;


		case ID_LOAD_MATCH:///------------
			if (!LoadAnalyzeOrNifti(GetParent(hwnd), &match, 0))
			{
				MessageBox(NULL,"Load Failed","",MB_OK|MB_ICONWARNING);
			}
			break;


		case IDOK:///----------------------
			SendMessage(hwnd, WM_CLOSE,0,0);
			break;

		}
		break;


	}
	return 0;
}
//=============================================================================================================
//=============================================================================================================
//=============================================================================================================
int SwapImages(HWND hwnd, struct Image *image)
{
	if ((*image).img && ReleaseImage(&gImage))
	{
		if (MakeCopyOfImage(image, &gImage))
		{
			InitialisePicture(hwnd, &gImage, &gMainPict);
			SendMessage(hwnd, WM_COMMAND, ID_REDRAW,1);
			return 1;
		}
	}
	return 0;
}
//=============================================================================================
//                  Show mix of Base and Match Image
//                  Helps to check the register
//=============================================================================================
#define PICT_SIZE 512
int ShowBaseMatchMixManual(HWND hwnd, struct Image *Base, struct Image *Match, int slice, struct AffineMatrix *Amat, double fraction, float saturation)
{

	struct BITMAPINFO256 bmpinf;
	int Xb,Yb,Zb;
	int width,height;
	int icol;
	int xi,yi;
	int Ib, Im, I;
	int checkX, checkY;
	int penX,penY;
	unsigned char *pict=NULL;
	float *MatchReg=NULL;
	float max, maxb;
	float scale;
	float dx,dy,dz;
	float xf, yf, zf;
	float x0,y0,z0;
	float matchdx, matchdy, matchdz;
	HDC hMemDC, hDC=GetDC(hwnd);
	HBITMAP hbmp, hOldbmp;
	int *polyorder=NULL;
	double *poly=NULL;

	if ((!(*Match).X) || (!(*Match).Y) || (!(*Match).Z) || (!(*Match).volumes))
		return 0;


	if (!(poly=(double *)malloc(MAX_REGISTRATION_PARAMETERS/3*sizeof(double))))
		goto END;
	if (!(polyorder=(int *)malloc(MAX_REGISTRATION_PARAMETERS/3*sizeof(int))))
		goto END;


	Xb=(*Base).X;
	Yb=(*Base).Y;
	Zb=(*Base).Z/(*Base).volumes;
	if (slice>Zb)
		slice=Zb/2;

	dx=(*Base).dx;
	dy=(*Base).dy;
	dz=(*Base).dz;

	width=Xb+(4-Xb%4);
	height=Yb;


	x0=(*Match).dx*(*Match).X/2.0;
	y0=(*Match).dy*(*Match).Y/2.0;
	z0=(*Match).dz*(*Match).Z/2.0;
	matchdx=(*Match).dx;
	matchdy=(*Match).dy;
	matchdz=(*Match).dz;

	if (!(pict=(unsigned char *)malloc(width*height)))
		goto END;

	memset(pict,0,width*height);

	hMemDC=CreateCompatibleDC(hDC);

	memset(&bmpinf,0,sizeof(struct BITMAPINFO256));      //null the structure to start with

	bmpinf.bmiHdr.biSize=sizeof(BITMAPINFOHEADER);
	bmpinf.bmiHdr.biWidth=width;
	bmpinf.bmiHdr.biHeight=height;
	bmpinf.bmiHdr.biPlanes=1;
	bmpinf.bmiHdr.biBitCount=8;
	bmpinf.bmiHdr.biCompression=BI_RGB;
	bmpinf.bmiHdr.biClrUsed=256;


	//--------arrange the grey scale part of the colour map---------
	for (icol=0; icol<256; icol++)
	{
		bmpinf.bmicolours[icol].rgbRed=icol;
		bmpinf.bmicolours[icol].rgbGreen=icol;
		bmpinf.bmicolours[icol].rgbBlue=icol;
	}



	//GET THE RESAMPLED MATCH SLICE
	MatchReg=(float *)malloc(Xb*Yb*sizeof(float));
	max=maxb=0.0;
	if (!MatchReg)
		goto END;
	for (yi=0; yi<Yb; yi++)
	{
		for (xi=0; xi<Xb; xi++)
		{
			xf=dx*(xi-Xb/2);
			yf=dy*(yi-Yb/2);
			zf=dz*(slice-Zb/2);

			//GetTransformedVoxelCoordinates(&xf, &yf, &zf, (*Match).dx*(*Match).X/2.0, (*Match).dy*(*Match).Y/2.0, (*Match).dz*(*Match).Z/2.0/(*Match).volumes,
			//                              (*Match).dx, (*Match).dy, (*Match).dz, Amat, p, poly, Nparameters);

			AffineTransformCoordinates(&xf, &yf, &zf, Amat);
			xf=(xf+x0)/matchdx;
			yf=(yf+y0)/matchdy;
			zf=(zf+z0)/matchdz;

			MatchReg[xi+yi*Xb] = InterpolateImage(Match, 0, xf, yf, zf, ID_TRILINEAR);

			if (MatchReg[xi+yi*Xb]>max)
				max=MatchReg[xi+yi*Xb];
			if ((*Base).img[xi + yi*Xb + slice*Xb*Yb]>maxb)
				maxb=(*Base).img[xi + yi*Xb + slice*Xb*Yb];
		}
	}
	//sprintf(txt,"%f %f",max,maxb);
	//MessageBox(NULL,txt,"",MB_OK);
	if (max<=0.0)
		max=1.0;//TO PREVENT /ZERO
	if (maxb<=0.0)
		maxb=1.0;//TO PREVENT /ZERO



	checkX=checkY=penX=penY=0;
	scale=(double)PICT_SIZE/Xb;
	if (((double)PICT_SIZE/Yb)<scale)
		scale=(double)PICT_SIZE/Yb;
	if (saturation<=0.0)
		saturation=1.0;
	for (yi=0; yi<Yb; yi++)
	{
		checkX=0;
		penX=0;
		if (checkY>Yb/2)
		{
			checkY=0;
			penY=(penY==1)?0:1;
		}
		for (xi=0; xi<Xb; xi++)
		{

			Im=255*MatchReg[xi+yi*Xb]/max/saturation;

			Ib=255*(*Base).img[xi + yi*Xb + slice*Xb*Yb]/saturation/maxb;
			I=(1.0-fraction)*Ib + fraction*Im;
			if (I>255)
				I=255;


			//PRODUCES CHECKERBOARD EFFECT
			if (checkX>Xb/2)
			{
				checkX=0;
				penX=(penX==1)?0:1;
			}

			if (fraction<1.0e-6)//floating point fraction=0.0
			{
				if (penX+penY==1)
					pict[xi+yi*width]=(char)Ib;
				else
					pict[xi+yi*width]=(char)Im;
			}
			else
				pict[xi+yi*width]=(char)I;
			//pict[xi+yi*width]=(char)I;

			checkX++;
		}
		checkY++;
	}


	hbmp=CreateDIBitmap(  hDC, (LPBITMAPINFOHEADER)&bmpinf.bmiHdr, CBM_INIT, pict,
	                      (LPBITMAPINFO)&bmpinf, DIB_RGB_COLORS  );
	hOldbmp=SelectObject(hMemDC, hbmp);


	StretchBlt(hDC, 20, 50, (int)(scale*width), (int)(scale*height), hMemDC, 0,0, width, height, SRCCOPY);

	SelectObject(hMemDC, hOldbmp);
	DeleteObject(hbmp);


END:

	if (pict)
		free(pict);

	if (MatchReg)
		free(MatchReg);

	if (poly)
		free(poly);

	if (polyorder)
		free(polyorder);

	return 1;
}
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
struct AffineMatrix AlignPoints(struct ThreeVector Vbase[], struct ThreeVector Vmatch[], int points)
{
	struct AffineMatrix A;
	int i;
	struct ThreeVector BaseMean, MatchMean;

	memset(&BaseMean,0,sizeof(struct ThreeVector));
	memset(&MatchMean,0,sizeof(struct ThreeVector));

	memset(&A, 0, sizeof(struct AffineMatrix));

	A.M[0][0]=A.M[1][1]=A.M[2][2]=A.M[3][3]=1.0;

	if (!points) return A;

	for (i=0; i<points; i++)
	{
		BaseMean.x+=Vbase[i].x;
		BaseMean.y+=Vbase[i].y;
		BaseMean.z+=Vbase[i].z;

		MatchMean.x+=Vmatch[i].x;
		MatchMean.y+=Vmatch[i].y;
		MatchMean.z+=Vmatch[i].z;
	}

	BaseMean.x/=points;
	BaseMean.y/=points;
	BaseMean.z/=points;

	MatchMean.x/=points;
	MatchMean.y/=points;
	MatchMean.z/=points;

	A.M[0][3]=BaseMean.x - MatchMean.x;
	A.M[1][3]=BaseMean.x - MatchMean.x;
	A.M[2][3]=BaseMean.x - MatchMean.x;


	return A;
};
