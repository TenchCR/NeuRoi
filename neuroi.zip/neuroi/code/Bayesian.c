/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "global.h"
#include "numerical.h"



//=======================================================================================
//          Do Bayesian Linear Regression
//          Prior mean and inverse covariance are provided
//          means[] are estimated and returned; i.e. the least square estimates of the parameters
//          knownsp[] and X[] are unchanged on exit
//=======================================================================================
int BayesLinearRegression(double knowns[], double X[], double means[], int rows, int columns, double PriorInvCov[], double PriorMean[])
{
    double *XtX=NULL;
    double *InvXtX=NULL;
    int r,c;
    int rindex, index;
    int i;
    int result=0;

    memcpy(means,PriorMean, columns*sizeof(double));//initialise to the prior in case no calculation possible


    if (!(XtX=(double *)malloc(columns*columns*sizeof(double)))) goto END;
    if (!(InvXtX=(double *)malloc(columns*columns*sizeof(double)))) goto END;


    //Design matrix
    rindex=0;
    for (r=0; r<columns; r++)
    {
        for (c=0; c<columns; c++)
        {
            index=0;
            XtX[c+rindex]=0.0;
            for (i=0; i<rows; i++)
            {
                XtX[c+rindex]+=X[index+c]*X[index+r];
                index+=columns;
            }
        }
        rindex+=columns;
    }
    memcpy(InvXtX,XtX,columns*columns*sizeof(double));
    if (!(InvertMatrixA(InvXtX,columns))) goto END;

    result = BayesLinearRegressionEx(knowns, X, XtX, InvXtX, means, rows, columns, PriorInvCov, PriorMean);

END:
    if (XtX) free(XtX);
    if (InvXtX) free(InvXtX);

    return result;
}

//=======================================================================================
//          Do Bayesian Linear Regression
//          Prior mean and inverse covariance are provided
//          means[] are estimated and returned; i.e. the least square estimates of the parameters
//          knownsp[] and X[] are unchanged on exit
//          The XtX and inverse matrix XtX is provided, which means no inverse is needed
//=======================================================================================
int BayesLinearRegressionEx(double knowns[], double X[], double XtX[], double InvXtX[], double means[], int rows, int columns, double PriorInvCov[], double PriorMean[])
{
    double *tmp=NULL;
    double sigma2, sum;
    int r,c;
    int rindex;
    int result=0;
    //char txt[256];

    memcpy(means,PriorMean, columns*sizeof(double));//initialise to the prior in case no calculation possible

    if (!(tmp=(double *)malloc(columns*sizeof(double)))) goto END;



    //compute least squares estimate of mean
    for (c=0; c<columns; c++)
    {
        rindex=0;
        tmp[c]=0.0;
        for (r=0; r<rows; r++)
        {
            tmp[c]+=X[rindex+c]*knowns[r];
            rindex+=columns;
        }
    }
    rindex=0;
    for (r=0; r<columns; r++)
    {
        means[r]=0.0;
        for (c=0; c<columns; c++)
        {
            means[r]+=InvXtX[rindex+c]*tmp[c];
        }
        rindex+=columns;
    }



    //estimate sigma^2
    sigma2=0;
    rindex=0;
    for (r=0; r<rows; r++)
    {
        sum=-knowns[r];
        for (c=0; c<columns; c++)
        {
            sum+=X[c+rindex]*means[c];
        }
        sigma2+=sum*sum;
        rindex+=columns;
    }
    sigma2/=rows;

    //sprintf(txt,"sigma2=%f",sigma2);
    //MessageBox(NULL,txt,"",MB_OK);

    if (sigma2<=0.0) goto END;


    for (c=0; c<columns; c++)
    {
        rindex=0;
        for (r=0; r<columns; r++)
        {
            //XtX[r*columns+c]/=sigma2;
            PriorInvCov[rindex+c]*=sigma2;
            rindex+=columns;
        }
    }


    result=BayesMVnormalKnownCovariance(means, XtX, PriorMean, PriorInvCov, columns);

END:
    if (tmp) free(tmp);

    return result;
}


//=======================================================================================
//         Bayesian on multivariate normal
//         Use Conjugate prior for known covariance
//         Given measured mean[N] and known inverse covariance InvCov[NxN]
//         The prior mean is Pmean[N], and the prior inverse covariance InvPcov[NxN]
//         http://en.wikipedia.org/wiki/Conjugate_prior
//         Wiki seems to eroneously include the number of observations
//=======================================================================================
int BayesMVnormalKnownCovariance(double mean[], double InvCov[], double Pmean[], double InvPcov[], int N)
{
    double *PostInvCov=NULL;
    double *PostMean=NULL;
    int i,j;
    int jindex,iindex;
    int result=0;

    if (!(PostInvCov=(double *)malloc(N*N*sizeof(double)))) goto END;
    if (!(PostMean=(double *)malloc(N*sizeof(double)))) goto END;

    //compute the posterior covariance
    //PostCov=(InverseCovariance + InversePriorCovariance)^-1
    jindex=0;
    for (j=0; j<N; j++)
    {
        for (i=0; i<N; i++)
        {
            PostInvCov[i+jindex]=InvCov[i+jindex] + InvPcov[i+jindex];
        }
        jindex+=N;
    }
    if (!(InvertMatrixA(PostInvCov,N))) goto END;


    //compute the Posterior Mean
    //=InversePostCov * (InversePriorCovariance*PriorMean + InverseCov*mean)
    for (j=0; j<N; j++)
    {
        iindex=0;
        PostMean[j]=0.0;
        for (i=0; i<N; i++)
        {
            PostMean[j]+=InvPcov[j+iindex]*Pmean[i] + InvCov[j+iindex]*mean[i];
            iindex+=N;
        }
    }
    for (j=0; j<N; j++)
    {
        iindex=0;
        mean[j]=0.0;
        for (i=0; i<N; i++)
        {
            mean[j]+=PostInvCov[j+iindex]*PostMean[i];
            iindex+=N;
        }
    }

    memcpy(InvCov,PostInvCov,sizeof(double)*N*N);

    result=1;
END:
    if (PostInvCov) free(PostInvCov);
    if (PostMean) free(PostMean);

    return result;
}
//===================================================================================================
//===================================================================================================
//===================================================================================================
//===================================================================================================
int PosteriorRejectionSampling(double Sample[], int (*Prior)(double *), int N, double MaxLikelihood, double (*Likelihood)(double *, int, void *), void *dat)
{

    double r;
    double L;
    FILE *fp;
    char fname[MAX_PATH];
    sprintf(fname,"%s\\RejSampl.txt",REPORT_FOLDER);

     if ((fp=fopen(fname,"a")))
            {
                fprintf(fp,"%g\n",MaxLikelihood);
                fclose(fp);
            }

    do
    {
            r=(double)rand()/RAND_MAX;
            Prior(Sample);
            L=Likelihood(Sample, N, dat)/MaxLikelihood;

            if ((fp=fopen(fname,"a")))
            {
                fprintf(fp,"%f %g %f %f %f %f %f\n",r,L, Sample[0],Sample[1],Sample[2],Sample[3],Sample[4]);
                fclose(fp);
            }
    }
    while (L<r);

    return 1;
}
//===================================================================================================
//===================================================================================================
//===================================================================================================
//===================================================================================================
double MCMCSampling(double Sample[], double currentposterior, double Proposed[], int (*Proposal)(double *), int N, double (*Posterior)(double *, int, void *), void *dat)
{

    double r;
    double prop;
    //FILE *fp;
    //char fname[MAX_PATH];
    //sprintf(fname,"%s\\MCMCsampl.txt",REPORT_FOLDER);

    memcpy(Proposed, Sample, N*sizeof(double));

    Proposal(Proposed);//get the new proposed sample

    prop=Posterior(Proposed, N, dat);//the new proposed posterior

    if (prop>=currentposterior)
    {
        //accept this new proposed sample
        memcpy(Sample, Proposed, N*sizeof(double));
        currentposterior=prop;
    }
    else
    {
        r=(double)rand()/RAND_MAX;
        if (prop/currentposterior>r)
        {
            memcpy(Sample, Proposed, N*sizeof(double));
            currentposterior=prop;
        }
    }

          /*  if ((fp=fopen(fname,"a")))
            {
                fprintf(fp,"%g %f %f %f\n",currentposterior, Sample[0],Sample[1],Sample[2]);
                fclose(fp);
            }*/

    return currentposterior;
}
