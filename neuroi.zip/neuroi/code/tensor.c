/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "options.h"
#include "tensor.h"
#include "menuresources.h"
#include "display.h"
#include "imageprocess.h"
#include "templatefunctions.h"
#include "fODF.h"
#include "classification.h"
#include "coregister.h"
#include "registerDWI.h"

double InterpolateFODF(float *interpolated, float *fa, float *fODF, int X, int Y, int Zpv, int volumes,
                       float dx, float dy, float dz, float x, float y, float z);
int PseudoInverseForTensorFit(double pinv[], int volumes, struct bMatrix B[]);

//=============================================================================================
//						The attenuation of a single tensor in direction acquisition
//						The principal evector of the tensor is principal
//						The eigenvalues are evalue1 and evalue2
//                      assumes evalue3=evalue2
//=============================================================================================
double AttenuationSymmetric(double bvalue, double evalue1, double evalue2, struct ThreeVector principal, struct ThreeVector acquisition)
{
    return exp(-bvalue*((evalue1-evalue2)*pow(DPThreeVector(&principal, &acquisition),2) + evalue2));
}






//==============================================================================
//          Generate a signal vector
//          Signal made using 'Tensors' symmetric tensors with evalues e1,e2
//              and 'principal' evectors
//          The tensors have specified 'volume' fractions
//          The b value is bval
//          Signal S[] generated in directions Vdirs[]
//==============================================================================
int GenerateDiffusionSignal(int Tensors, struct ThreeVector principal[], double volume[], float e1, float e2,
                            float bval, struct ThreeVector Vdirs[], int directions, double S[])
{

    int tensor;
    int dir;
    double vol;
    //char txt[256];

    //sprintf(txt,"%f %f %f",volume[0],volume[1],volume[2]);
    //MessageBox(NULL,txt,"",MB_OK);

    for (dir=0; dir<directions; dir++)
    {
        S[dir]=0.0;
        vol=0.0;
        for (tensor=0; tensor<Tensors; tensor++)
        {
            S[dir]+=volume[tensor]*AttenuationSymmetric(bval, e1, e2, Vdirs[dir], principal[tensor]);
            vol+=volume[tensor];
        }
        if (S[dir]/vol>1.0) MessageBox(NULL,"prob","",MB_OK);

    }

    return 1;
}



//=============================================================================================
//              given the 3 eigenvalues from the tensor, return the FA
//=============================================================================================

double FracAnisotropy(double e1, double e2, double e3)
{
    double sum_eval2=e1*e1+e2*e2+e3*e3;
    double mean=(e1+e2+e3)/3.0;
    double del1=(e1-mean)*(e1-mean);
    double del2=(e2-mean)*(e2-mean);
    double del3=(e3-mean)*(e3-mean);

    if (sum_eval2) return sqrt(1.5)*sqrt((del1+del2+del3)/(sum_eval2));
    else return 0.0;
}














//=============================================================================================
//              given the 3 eigenvalues from the tensor, return the RA
//=============================================================================================
double RelAnisotropy(double e1, double e2, double e3)
{
    double MeanEval=(e1+e2+e3)/3.0;
    if (MeanEval) return sqrt(( (e1-MeanEval)*(e1-MeanEval) + (e2-MeanEval)*(e2-MeanEval) + (e3-MeanEval)*(e3-MeanEval) )/3)/MeanEval;
    else return 0.0;
}

















//=============================================================================================
//              given the 3 eigenvalues from the tensor, return the TRACE
//=============================================================================================
double DTtrace(double e1, double e2, double e3)
{
    return e1+e2+e3;
}













//=============================================================================================
//                 -Given the tensor image, get an interpolated tensor
//                  at point {x,y,z} in mm
//                 -T is the tensor on exit
//                 -offset & scale converts positive definate Timage to DT
//                 -returns the TRACE of the tensor
//=============================================================================================
double InterpolateTensorImage(double T[], double *fa, float *Timage, float *faimg, int X, int Y, int Zpv,
                              float dx, float dy, float dz, float x, float y, float z, float scale, float offset)
{

    int xi, yi, zi;
    int voxels=X*Y*Zpv;
    float xf, yf, zf;
    float c[8];


    xf=(x/dx);
    yf=(y/dy);
    zf=(z/dz);
    xi=(int)xf;
    yi=(int)yf;
    zi=(int)zf;


    if (xf>=0.0 && xf<(double)(X-1) &&
            yf>=0.0 && yf<(double)(Y-1) &&
            zf>=0.0 && zf<(double)(Zpv-1))
    {

        Lagrange3DCoefficients(xf-xi, yf-yi, zf-zi, c);


        T[0]=       offset+scale*Lagrange3DA(Timage, X, Y, Zpv, xf, yf, zf, c);
        T[1]=T[3]=  offset+scale*Lagrange3DA(&Timage[Dxy*voxels], X, Y, Zpv, xf, yf, zf, c);
        T[2]=T[6]=  offset+scale*Lagrange3DA(&Timage[Dxz*voxels], X, Y, Zpv, xf, yf, zf, c);
        T[4]=       offset+scale*Lagrange3DA(&Timage[Dyy*voxels], X, Y, Zpv, xf, yf, zf, c);
        T[5]=T[7]=  offset+scale*Lagrange3DA(&Timage[Dyz*voxels], X, Y, Zpv, xf, yf, zf, c);
        T[8]=       offset+scale*Lagrange3DA(&Timage[Dzz*voxels], X, Y, Zpv, xf, yf, zf, c);

        *fa=        Lagrange3DA(faimg, X, Y, Zpv, xf, yf, zf, c);

        return T[0]+T[4]+T[8];
    }

    memset(T,0,sizeof(double)*9);
    return 0.0;


}


















//=============================================================================================
//                 -Given the fODF image, get an interpolated fODF
//                  at point {x,y,z} in mm
//                 -Results in *interpolated on exit
//                 -returns the interpolated value of the first volume of fODF
//=============================================================================================
double InterpolateFODF(float *interpolated, float *fa, float *fODF, int X, int Y, int Zpv, int volumes,
                       float dx, float dy, float dz, float x, float y, float z)
{

    int xi, yi, zi;
    int voxels=X*Y*Zpv;
    int volume;
    float xf, yf, zf;
    float c[8];


    xf=(x/dx);
    yf=(y/dy);
    zf=(z/dz);
    xi=(int)xf;
    yi=(int)yf;
    zi=(int)zf;


    if ( (xf>=0.0) && xf<(double)(X-1) &&
          (yf>=0.0) && yf<(double)(Y-1) &&
          (zf>=0.0) && zf<(double)(Zpv-1))
    {

        Lagrange3DCoefficients(xf-xi, yf-yi, zf-zi, c);

        for (volume=0; volume<volumes; volume++)
        {
            interpolated[volume]=Lagrange3DA(&fODF[voxels*volume], X, Y, Zpv, (double)xf, (double)yf, (double)zf, c);
        }

        return Lagrange3DA(fa, X, Y, Zpv, (double)xf, (double)yf, (double)zf, c);
    }


    return 0.0;
}























//=============================================================================================
//             -Get tracking direction using TEND (Tensor Deflection) algorithm
//             -K must be the direction of the previous step on entry
//             -P is an array of 3vectors. The nth vector starts at P[(n-1)*3]
//             -P is needed for the interpolation algorithm
//*****Should write a routine for quickly calculating the principal evector******
//****Could chnage algorithm to add more parameters as suggested in TEND paper*****
//=============================================================================================
double TensorDeflection(void *Tim, float P[], int n, float K[])
{

    double length;
    double T[9];
    double V[9],e[3];
    double fa, Trace;
    float Kinit[3];
    int i;
    struct Tractography *Timage=(struct Tractography *)Tim;

    //first get the tensor
    if ((Trace=InterpolateTensorImage(T, &fa, (*Timage).tnsr, (*Timage).fa, (*Timage).X, (*Timage).Y, (*Timage).Zpv,
                                      (*Timage).dx, (*Timage).dy, (*Timage).dz, P[n*3], P[n*3+1], P[n*3+2], (*Timage). scale, (*Timage).offset))<=0.0)
    {
        memset(K,0,sizeof(float)*3);
        return 0.0;
    }


    if (!n) //initially just set off in the direction of the principal eigen vector
    {
        if (JacobiEigenSystemSolver(T, V, e, 3, 1))
        {

            fa=FracAnisotropy(e[0], e[1], e[2]);
            if (fa<(*Timage).MinFA)                                    //Minimum fa constraint
            {
                memset(K,0,sizeof(float)*3);
                return 0.0;
            }
            K[0]=(*Timage).direction*V[2];
            K[1]=(*Timage).direction*V[5];
            K[2]=(*Timage).direction*V[8];
            return 1.0;
        }
        else
        {
            memset(K,0,sizeof(float)*3);
            return 0.0;
        }
    }


    Trace=fabs(Trace);//should be positive, but just in case

    if (fa<(*Timage).MinFA)                                             //Minimum fa constraint
    {
        memset(K,0,sizeof(float)*3);
        return 0.0;
    }

    Kinit[0]=K[0];
    Kinit[1]=K[1]; //store original direction
    Kinit[2]=K[2];



    for (i=0; i<(*Timage).n; i++)
    {
        TensorDeflectVector(T, K);//multiply previous vector by tensor
        K[0]/=Trace;
        K[1]/=Trace;   //this makes sure the repeated multiplication doesnt make K zero
        K[2]/=Trace;
    }



    length=sqrt(K[0]*K[0] + K[1]*K[1] + K[2]*K[2]);
    if (length>0.0)
    {
        K[0]/=length;
        K[1]/=length;
        K[2]/=length;
        if ((Kinit[0]*K[0] + Kinit[1]*K[1] + Kinit[2]*K[2])<(*Timage).Mindp) return 0.0;//Maximum curvature constraint
    }
    else return 0.0;//cant be a NULL vector

    return 1.0;
}

//=============================================================================================
//              DEFLECT A VECTOR BY MULTIPLYING BY A TENSOR
//              Deflect vetor V[3]
//              T is assumed symmetric, and the subdiagonals dont need to be set
//=============================================================================================
int TensorDeflectVector(double T[], float V[])
{

    float V1[3];
    float trace=fabs(T[0]+T[4]+T[8]);
    if (!trace) return 0;

    memcpy(V1,V,sizeof(float)*3);

    V[0]=T[0]*V1[0] + T[1]*V1[1] + T[2]*V1[2];
    V[1]=T[1]*V1[0] + T[4]*V1[1] + T[5]*V1[2];
    V[2]=T[2]*V1[0] + T[5]*V1[1] + T[8]*V1[2];

    V[0]/=trace;
    V[1]/=trace;
    V[2]/=trace;

    return 1;
}




//=============================================================================================
//             -Get tracking direction using fODF deflection algorithm
//             -K must be the direction of the previous step on entry
//             -P is an array of 3vectors. The nth vector starts at P[(n-1)*3]
//             -P is needed for the interpolation algorithm
//****Could chnage algorithm to add more parameters as suggested in TEND paper*****
//=============================================================================================
double FodfDeflectionTractography(void *Tim, float P[], int n, float K[])
{

    double length;
    double fa;
    float fODF[MAX_DIFFUSION_DIRECTIONS];
    struct ThreeVector K1, Kinit;
    int i;
    struct Tractography *Timage=(struct Tractography *)Tim;

    //interpolate the fODF
    fa=InterpolateFODF(fODF, (*Timage).fa, (*Timage).fODF, (*Timage).X, (*Timage).Y, (*Timage).Zpv, (*Timage).volumes,
                       (*Timage).dx, (*Timage).dy, (*Timage).dz, P[n*3], P[n*3+1], P[n*3+2]);


    if (fa<(*Timage).MinFA)                                             //Minimum fa constraint
    {
        memset(K,0,sizeof(float)*3);
        return 0.0;
    }

    if (n>0)
    {
        Kinit.x=K[0];
        Kinit.y=K[1]; //store original direction
        Kinit.z=K[2];
    }
    else
    {
        Kinit=(*Timage).InitDir;//the launch direction is specified in the Tractography structure
        Kinit.x*=(*Timage).direction;
        Kinit.y*=(*Timage).direction;
        Kinit.z*=(*Timage).direction;
    }

    if (!NormaliseThreeVector(&Kinit)) return 0.0;
    K1=Kinit;


    //repeat the operation of fODF on the initial vector (*Timage).n times
    //increase this to increase the impact of the ODF peaks


    for (i=0; i<(*Timage).n; i++)
    {
        //Get new direction after operating with interpolated fODF
        K1=FodfDeflection(fODF,(*Timage).idirections, (*Timage).directions, Kinit);
    }



    K[0]=K1.x;
    K[1]=K1.y;
    K[2]=K1.z;



    length=sqrt(K[0]*K[0] + K[1]*K[1] + K[2]*K[2]);
    if (length)
    {
        K[0]/=length;
        K[1]/=length;
        K[2]/=length;
        if ((Kinit.x*K[0] + Kinit.y*K[1] + Kinit.z*K[2])<(*Timage).Mindp) return 0.0;//Maximum curvature constraint
    }
    else return 0.0;//cant be a NULL vector

    //if its the first vector to be computed, update InitDir
    if (!n)
    {
        (*Timage).InitDir.x=K[0];
        (*Timage).InitDir.y=K[1];
        (*Timage).InitDir.z=K[2];
    }




    return 1.0;
}



//=============================================================================================
//				Given the fODF value at a set of vectors
//				And given an initial direction Vinit
//				Deflect Vinit using fODF deflection
//=============================================================================================
struct ThreeVector FodfDeflection(float fODF[], int directions, struct ThreeVector Vectors[], struct ThreeVector InitDir)
{

    struct ThreeVector Ksum, *Vdir;
    int dir;
    float dp, weight, dp6weight;

    //Get new direction after operating with fODF
    memset(&Ksum,0,sizeof(struct ThreeVector));
    for (dir=0; dir<directions; dir++)
    {
        Vdir=&Vectors[dir];
        weight=fODF[dir];

        dp=DPThreeVector(Vdir, &InitDir);
        //dp2=dp*dp;
        //dp4=dp2*dp2;
        //dp6=dp4*dp2;

        if (dp>0.0)
        {
            //dp6weight=dp6*weight;
            dp6weight=pow(dp,6)*weight;
            Ksum.x+=dp6weight*(*Vdir).x;
            Ksum.y+=dp6weight*(*Vdir).y;
            Ksum.z+=dp6weight*(*Vdir).z;
        }
        else
        {
            //dp6weight=dp6*weight;
            dp6weight=pow(dp,6)*weight;
            Ksum.x-=dp6weight*(*Vdir).x;
            Ksum.y-=dp6weight*(*Vdir).y;
            Ksum.z-=dp6weight*(*Vdir).z;
        }

    }

    NormaliseThreeVector(&Ksum);

    return Ksum;
}

















//=============================================================================================
//                  -get a trajectory from the seed
//                  -get path in both directions and merge
//                  -returns the length of the path
//                  -mode is either DTI_TRACTOGRAPHY or FODF_TRACTOGRAPHY
//=============================================================================================
#define STEPS 1.5//number of steps across a whole voxel
int GetTrajectory(struct Trajectory *traj, struct Tractography *tractog, float x, float y, float z, int mode)
{

    float A[MAX_TRAJECTORY_LENGTH*3/2];//*3 because x,y,z triplets
    float B[MAX_TRAJECTORY_LENGTH*3/2];
    float h;
    int NA, NB;
    int i;

    A[0]=x;
    A[1]=y;
    A[2]=z;
    B[0]=x;
    B[1]=y;
    B[2]=z;

    h=( (*tractog).dx<(*tractog).dy) ? (*tractog).dx/STEPS:(*tractog).dy/STEPS;
    h=( h<(*tractog).dz/STEPS) ? h:(*tractog).dz/STEPS;


//Do tractography forwards and backwards
    switch (mode)
    {
    case DTI_TRACTOGRAPHY:
        (*tractog).direction=1.0;
        NA=RK2(tractog, h, A, 3, MAX_TRAJECTORY_LENGTH/2, TensorDeflection);

        (*tractog).direction=-1.0;
        NB=RK2(tractog, h, B, 3, MAX_TRAJECTORY_LENGTH/2, TensorDeflection);
        break;
    case FODF_TRACTOGRAPHY:
        (*tractog).direction=1.0;
        NA=RK2(tractog, h, A, 3, MAX_TRAJECTORY_LENGTH/2, FodfDeflectionTractography);

        (*tractog).direction=-1.0;
        NB=RK2(tractog, h, B, 3, MAX_TRAJECTORY_LENGTH/2, FodfDeflectionTractography);
        break;
    default:
        NA=NB=0;
        break;
    }



//Join forwards and backwards together
    for (i=0; i<NA; i++)
    {
        (*traj).xyz[3*i]=A[3*(NA-1-i)];
        (*traj).xyz[3*i+1]=A[3*(NA-1-i)+1];
        (*traj).xyz[3*i+2]=A[3*(NA-1-i)+2];
    }
    (*traj).seed=NA-1;
    for (i=1; i<NB; i++)
    {
        (*traj).xyz[3*(i+NA-1)]   =B[3*i];
        (*traj).xyz[3*(i+NA-1)+1] =B[3*i+1];
        (*traj).xyz[3*(i+NA-1)+2] =B[3*i+2];
    }
    (*traj).length=(NA+NB>0) ? (NA+NB-1):0;

//char txt[256];
//sprintf(txt,"%d %d",NA,NB);
//MessageBox(NULL,txt,"",MB_OK);

    return (*traj).length;
}



//=============================================================================================
//              -Test GetTrajectory
//=============================================================================================
int TestGetTrajectory( struct Tractography *tractography)
{

    int x,y,z;
    int X,Y,Z;
    int length;
    float dx, dy, dz;
    struct Trajectory traj;

    X=(*tractography).X;
    Y=(*tractography).Y;
    Z=(*tractography).Zpv;
    dx=(*tractography).dx;
    dy=(*tractography).dy;
    dz=(*tractography).dz;

    for (z=0; z<Z; z++)
    {
        for (y=0; y<Y; y++)
        {
            for (x=0; x<X; x++)
            {
                length=GetTrajectory(&traj, tractography, x*dx, y*dy, z*dz, DTI_TRACTOGRAPHY);
                if (length)
                {
//                sprintf(txt,"%d",length);
//                MessageBox(NULL,txt,"",MB_OK);
                }
            }
        }
    }

    return 1.0;
}














//=============================================================================================
//Format is:
//Number of matrices Nm (number of directions/b-values)
//Then repeated Nm times: the b-value then a matrix
//stores the b-matrices in the struct bMatrix B
//returns the number of DW directions
//b matrix structure
//struct bMatrix{
//	double b[3][3];								//b matrix
//	double bValue;								//b value
//};
//=============================================================================================
int LoadbMatrices(struct bMatrix B[], int volumes, int Rearranging)
{

    int count, zeroes, i;
    char fname[MAX_PATH];
    OPENFILENAME fnamedlg;

    fname[0]='\0';
    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Bmat files\0*.*\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=fname;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Load b matrices (bmat)";
    if(!GetOpenFileName(&fnamedlg)) return 0;

    count=LoadbMatricesGivenFileName(B, volumes, fname);

    if (count!=volumes)
    {
        MessageBox(NULL,"The number of diffusion weighted images seems wrong!","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    //if rearranging we dont expect the number of b=0 volumes to be 1, so dont check
    if (Rearranging) return count;

    //make sure the number of zero bvalues is 1
    zeroes=0;
    for (i=0;i<count;i++)
    {
        if (B[i].bValue==0.0) zeroes++;
    }
    if (zeroes!=1)
    {
        MessageBox(NULL,"Number of volumes with b=0 must be 1.\nPlease use the sort DWI function first.","",MB_OK|MB_ICONWARNING);
        return 0;
    }


    return count;
}


//=============================================================================================
//Format is:
//Number of matrices Nm (number of directions/b-values)
//Then repeated Nm times: the b-value then a matrix
//stores the b-matrices in the struct bMatrix B
//returns the number of DW directions
//b matrix structure
//struct bMatrix{
//	double b[3][3];								//b matrix
//	double bValue;								//b value
//};
//=============================================================================================
int LoadbMatricesGivenFileName(struct bMatrix B[], int volumes, char fname[])
{

    FILE *fp;
    int directions, count, row;
    char txt[1024],a[256],b[256],c[256];

    count=0;
    if (!(fp=fopen(fname,"r"))) return count;

    //clear the matrix memory
    memset(B,0,sizeof(struct bMatrix)*volumes);

    //read the first line. It may, or may not, contain a version number v#
    fscanf(fp,"%s",txt);
    if (!strstr(txt,"v")) rewind(fp);


    fscanf(fp,"%d",&directions);
    if (directions!=volumes)
    {
        //MessageBox(NULL,"Number of directions is not equal to the number of volumes.","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    if (directions>=MAX_DIFFUSION_DIRECTIONS)
    {
        //MessageBox(NULL,"Number of directions is greater than the maximum.","",MB_OK|MB_ICONWARNING);
        return 0;
    }

    if (directions)
    {
        count=0;
        do
        {
            if (!feof(fp)) fscanf(fp,"%s",txt);
            //Get the b value first
            B[count].bValue=atof(txt);
            for (row=0; row<3; row++)
            {
                //now get the b matrix elements
                if (!feof(fp)) fscanf(fp,"%s%s%s",a,b,c);
                //if (!feof(fp)) n=fscanf(fp,"%f %f %f",&B[count].b[row][0],&B[count].b[row][1],&B[count].b[row][2]);

                B[count].b[row][0]=atof(a);
                B[count].b[row][1]=atof(b);
                B[count].b[row][2]=atof(c);
            }
//sprintf(txt,"Loaded bmat\n %f %f %f\n%f %f %f\n%f %f %f",B[count].b[0][0],B[count].b[0][1],B[count].b[0][2],
//                                                       B[count].b[1][0],B[count].b[1][1],B[count].b[1][2],
//                                                       B[count].b[2][0],B[count].b[2][1],B[count].b[2][2]);
//MessageBox(NULL,txt,"",MB_OK);

            count++;
        }
        while(count<directions && !feof(fp));
    }

    fclose(fp);

    return count;
}

















//==============================================================================
//				Create a bmat file from bvecs and bvals file
//==============================================================================
int CreateBmatrixFile(void)
{

    struct ThreeVector xyz[MAX_DIFFUSION_DIRECTIONS];
    float bvals[MAX_DIFFUSION_DIRECTIONS];
    int ndirections, nbvals;
    int dir;
    char txt[256];
    char fname[MAX_PATH];
    FILE *fp;
    OPENFILENAME fnamedlg;

    fname[0]='\0';
    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="b matrix files\0*.*\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=fname;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.nMaxFileTitle=MAX_PATH;
    fnamedlg.lpstrInitialDir="./";
    fnamedlg.lpstrTitle="Save b matrix file";


    ndirections=LoadAcquisitionDirections( xyz );
    nbvals=LoadAcquisitionBvalues( bvals );



    if (ndirections!=nbvals-1)
    {
        sprintf(txt,"Number of directions and b-values not commensurate: Ndirs=%d Nbvals=%d",ndirections,nbvals);
        MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
        return 0;
    }

    if(!GetSaveFileName(&fnamedlg)) return 0;
    if ( (fp=fopen(fname,"w")) )
    {
        fprintf(fp,"%d\n",ndirections);
        for (dir=0; dir<ndirections; dir++)
        {
            fprintf(fp,"%f\n",bvals[dir]);
            fprintf(fp,"%f %f %f\n",xyz[dir].x*xyz[dir].x, xyz[dir].x*xyz[dir].y, xyz[dir].x*xyz[dir].z);
            fprintf(fp,"%f %f %f\n",xyz[dir].y*xyz[dir].x, xyz[dir].y*xyz[dir].y, xyz[dir].y*xyz[dir].z);
            fprintf(fp,"%f %f %f\n",xyz[dir].z*xyz[dir].x, xyz[dir].z*xyz[dir].y, xyz[dir].z*xyz[dir].z);
        }
        fclose(fp);
    }


    return 1;
}



//==============================================================================
//          Load directions sets; as saved by generate directions program
//          return the number of directions loaded
//==============================================================================
int LoadDirections(struct ThreeVector V[], char filename[])
{

    FILE *fp;
    int i;
    int n;
    //char txt[256];


    if (!(fp=fopen(filename,"r"))) return 0;

    fscanf(fp,"%d",&n);
    i=0;
    while(!feof(fp) && i<n)
    {
        fscanf(fp,"%f %f %f",&V[i].x,&V[i].y,&V[i].z);
        //sprintf(txt,"%f %f %f",V[i].x, V[i].y, V[i].z);
        //MessageBox(NULL,txt,"",MB_OK);
        i++;
    }

    fclose(fp);

    if (i==n) return n;
    else return 0;
}

//==============================================================================
//loads directions from the set*_bvecs files
//these files contain VOLUMES direction vectors, i.e. they include the NULL T2 direction
//the files contain a list of N x components, then N y components, then N z components
//cant handle more than MAX_DIFFUSION_DIRECTIONS direction vectors. But this should be plenty.
//returns the number of directions loaded, including the {0,0,0} direction
//==============================================================================
int LoadAcquisitionDirections(struct ThreeVector xyz[])
{

    int  count;
    char fname[MAX_PATH];
    OPENFILENAME fnamedlg;

    fname[0]='\0';
    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="Direction files\0*.*\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=fname;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Load directions (bvecs file)";

    if(!GetOpenFileName(&fnamedlg)) return 0;

    count=LoadAcquisitionDirectionsGivenFileName(xyz, fname);

    return count;
}

//==============================================================================
//loads directions from the set*_bvecs files
//these files contain VOLUMES direction vectors, i.e. they include the NULL T2 direction
//the files contain a list of N x components, then N y components, then N z components
//cant handle more than MAX_DIFFUSION_DIRECTIONS direction vectors. But this should be plenty.
//returns the number of directions loaded, including the {0,0,0} direction
//==============================================================================
int LoadAcquisitionDirectionsGivenFileName(struct ThreeVector xyz[], char fname[])
{

    FILE *fp;
    int direction, count;
    char a[256];
    float In[MAX_DIFFUSION_DIRECTIONS*3];

    if (!(fp=fopen(fname,"r"))) return 0;

    //----------load the entries and put them into array In[]------
    count=0;
    do
    {
        if (!feof(fp)) fscanf(fp,"%s",a);
        In[count]=atof(a);
        count++;
    }
    while(count<MAX_DIFFUSION_DIRECTIONS*3 && !feof(fp));
    fclose(fp);
    //-------------------------------------------------------------

    //the actual number of vectors is count / 3
    count/=3;

    for (direction=0; direction<count; direction++)
    {
        xyz[direction].x=In[direction];
        xyz[direction].y=In[direction+count];
        xyz[direction].z=In[direction+2*count];
        NormaliseThreeVector(&xyz[direction]);
    }

    return count;
}





//==============================================================================
//loads b-values from the _bvals files
//==============================================================================
int LoadAcquisitionBvalues(float bvals[])
{

    FILE *fp;
    int  count;
    char a[256];
    char fname[MAX_PATH];
    OPENFILENAME fnamedlg;

    fname[0]='\0';
    memset(&fnamedlg,0,sizeof(OPENFILENAME));
    fnamedlg.lStructSize=sizeof(OPENFILENAME);
    fnamedlg.hwndOwner=NULL;
    fnamedlg.lpstrFilter="B value files\0*.*\0\0";
    fnamedlg.lpstrCustomFilter=NULL;
    fnamedlg.nFilterIndex=1;
    fnamedlg.lpstrFile=fname;
    fnamedlg.nMaxFile=MAX_PATH;
    fnamedlg.nMaxFileTitle=MAX_PATH;
    fnamedlg.lpstrInitialDir=NULL;
    fnamedlg.lpstrTitle="Load b-values (bvals file)";

    if(!GetOpenFileName(&fnamedlg)) return 0;


    memset(bvals,0,sizeof(float)*MAX_DIFFUSION_DIRECTIONS);

    if (!(fp=fopen(fname,"r"))) return 0;

    //----------load the entries and put them into array bvals[]------
    count=0;
    do
    {
        if (!feof(fp)) fscanf(fp,"%s",a);
        bvals[count]=atof(a);
        count++;
    }
    while(count<MAX_DIFFUSION_DIRECTIONS && !feof(fp));
    fclose(fp);
    //-------------------------------------------------------------


    return count;
}











//=============================================================================================
//              Get the Psuedo inverse for fitting tensor
//              pinv has 6 columns and volumes-1 rows
//              Its volumes - 1 because the b=0 image isnt involved
//              volumes is the number of volumes in the DWI image
//              On return pinv is the psuedo inverse matrix that is used
//                  in the fitting of the tensor
//=============================================================================================
int PseudoInverseForTensorFit(double pinv[], int volumes, struct bMatrix B[])
{

    int direction, dir;

    if (volumes<7) return 0;//cantfit tensor to less than 6 directions and one T2 (b=0)

    direction=0;
    for (dir=0; dir<volumes; dir++)
    {
        if (B[dir].bValue>0.0) //only those with nonzero b value
        {
            pinv[direction*6 + Dxx]=B[dir].bValue*B[dir].b[0][0];
            pinv[direction*6 + Dyy]=B[dir].bValue*B[dir].b[1][1];
            pinv[direction*6 + Dzz]=B[dir].bValue*B[dir].b[2][2];
            pinv[direction*6 + Dxy]=B[dir].bValue*2.0*B[dir].b[0][1];
            pinv[direction*6 + Dxz]=B[dir].bValue*2.0*B[dir].b[0][2];
            pinv[direction*6 + Dyz]=B[dir].bValue*2.0*B[dir].b[1][2];
            direction++;
        }
    }

    return PsuedoInverse(pinv, direction, 6);
}









//=============================================================================================
//                 -Get the tensor from the DWI data by multiplying
//                  by the Psuedo inverse tensor of b matrices
//                 -Uses 0.01 as minimum relative DWI signal
//=============================================================================================
int ComputeTensor(float DWI[], int X, int Y, int Zpv, int volumes, int voxel, double Xinv[], float *tnsr, struct bMatrix B[])
{

    int voxels = X*Y*Zpv;
    int vol, row;
    int i;
    int T2vol;
    double lnDWI, T2, ratio;


    //find the zero bvalue image (rather than assuming its the last
    vol=0;
    while((B[vol].bValue>0.0) && (vol<volumes))
    {
        vol++;
    }
    T2vol=vol;
    if (T2vol>=volumes)
    {
        MessageBox(NULL,"In ComputeTensor: No zero b value image found!","",MB_OK|MB_ICONWARNING);
        return -1;
    }


    //wont try to compute where there is no T2 signal
    if ((T2=DWI[voxel+T2vol])<=0.0) return 0;

    for (i=0; i<6; i++) tnsr[voxel+i*voxels]=0.0;
    row=0;
    for (vol=0; vol<volumes; vol++)
    {
        if (vol!=T2vol)
        {
            //compute the log ratio of the DWI signal to the T2
            if ((ratio=DWI[voxel+vol*voxels]/T2)>0.01) lnDWI=-log( ratio );
            else lnDWI=-log(0.01);
            for (i=0; i<6; i++)  tnsr[voxel+i*voxels]+=Xinv[i + row*6]*lnDWI;
            row++;
        }
    }

    return 1;
}








//=============================================================================================
//                          Fit a tensor to the DWI data
//                          Put the tensor elements in DT
//=============================================================================================
int FitTensorModel(float DWI[], int X, int Y, int Zpv, int volumes, float *DT, struct bMatrix B[])
{

    double *Xinv=NULL;
    int voxel, voxels=X*Y*Zpv;
    int pinv=0;

    Xinv=(double *)malloc(6*(volumes-1)*sizeof(double));

    if (Xinv)
    {
        if ((pinv=PseudoInverseForTensorFit(Xinv, volumes, B)))
        {
            for (voxel=0; voxel<voxels; voxel++)
            {
                if (ComputeTensor(DWI, X, Y, Zpv, volumes, voxel, Xinv, DT, B)==-1) goto end;
            }
        }
        else
        {
            MessageBox(NULL,"Psuedo inverse failed in FitTensorModel.","",MB_OK|MB_ICONWARNING);
            memset(DT,0,sizeof(float)*voxels*6);
            goto end;
        }
    }
    else return 0;

end:
    if (Xinv) free(Xinv);

    return pinv;
}




















//=============================================================================================
//                    -Conver DWI data to tensor image
//                    -replace current image with tensor
//                    -the tensor is 6 volumes
//                    -will load b-matrices
//=============================================================================================
int ConvertDWItoTensor(struct Image *DWI)
{

    struct bMatrix B[MAX_DIFFUSION_DIRECTIONS];

    if ((*DWI).volumes<7)
    {
        MessageBox(NULL,"In ConvertDWItoTensor: Not enough DWI images!", "", MB_OK);
        return 0;
    }

    if ((*DWI).volumes>=MAX_DIFFUSION_DIRECTIONS)
    {
        MessageBox(NULL,"In ConvertDWItoTensor: Too many directions. Please complain to author", "", MB_OK);
        return 0;
    }

    //load the b-matrices
    if (!LoadbMatrices(B, (*DWI).volumes, 0)) return 0;

    return ConvertDWItoTensorGivenBmatrices(DWI, B);
}





//=============================================================================================
//                    -Conver DWI data to tensor image given the B matrices
//                    -replace current image with tensor
//                    -the tensor is 6 volumes
//                    -will load b-matrices
//=============================================================================================
int ConvertDWItoTensorGivenBmatrices(struct Image *DWI, struct bMatrix B[])
{

    float *DT;
    float min,max;
    int X, Y, Zpv;
    int voxel, voxels, vol;
    int result=0;

    if ((*DWI).volumes<7)
    {
        MessageBox(NULL,"In ConvertDWItoTensor: Not enough DWI images!", "", MB_OK);
        return 0;
    }

    if ((*DWI).volumes>=MAX_DIFFUSION_DIRECTIONS)
    {
        MessageBox(NULL,"In ConvertDWItoTensor: Too many directions. Please complain to author", "", MB_OK);
        return 0;
    }


    X=(*DWI).X;
    Y=(*DWI).Y;
    Zpv=(*DWI).Z/(*DWI).volumes;
    voxels=X*Y*Zpv*6;


    if (!(DT=(float *)malloc(voxels*sizeof(float))))
    {
        MessageBox(NULL,"In ConvertDWItoTensor: Unable to allocate memory","",MB_OK|MB_ICONWARNING);
        return 0;
    }
    memset(DT,0,voxels*sizeof(float));


    //Now fit the tensor to the DWI data
    if (FitTensorModel((*DWI).img, X, Y, Zpv, (*DWI).volumes, DT, B))
    {
        ImageMinMax(DT, X, Y, Zpv*6, DT_FLOAT, &min, &max);

        //sprintf(txt,"Convert DWI to Tensor\n%f %f",min,max);
        //MessageBox(NULL,txt,"",MB_OK);

        for (vol=0; vol<6; vol++)
        {
            for (voxel=0; voxel<X*Y*Zpv; voxel++)
            {
                if ((*DWI).img[voxel]) DT[voxel+vol*X*Y*Zpv]-=min;
            }
        }


        (*DWI).img=(float *)realloc((*DWI).img, voxels*sizeof(float));
        memcpy((*DWI).img, DT, voxels*sizeof(float));



        (*DWI).offset=min;
        (*DWI).scale=1.0;
        (*DWI).MaxIntensity=max-min;
        (*DWI).DataType=DT_FLOAT;
        (*DWI).Z=Zpv*6;
        (*DWI).volumes=6;
        (*DWI).filename[0]='\0';
        (*DWI).headername[0]='\0';
        sprintf((*DWI).Descrip,"Tensor");
        (*DWI).changed=1;

        result=1;
    }


    if (DT) free(DT);
    return result;
}














//=============================================================================================
//                   -Convert a tensor image to a colour principal evector image
//=============================================================================================
int ConvertTensorToPrincipalEvector(struct Image *DT)
{

    float *evect;
    RGBQUAD rgb;
    double V[9], evals[3];
    double fa;
    int voxel, voxels;
    char txt[256];




    if ((*DT).volumes!=6)
    {
        sprintf(txt,"In ConvertTensorToPrincipalEvector: Wrong number of volumes\nvolumes=%d (should be 6).",(*DT).volumes);
        MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
        return 0;
    }

    voxels=(*DT).X*(*DT).Y*(*DT).Z/6;


    evect=(float *)malloc(voxels*sizeof(float));
    if (!evect)
    {
        sprintf(txt,"In ConvertTensorToPrincipalEvector: Failed to allocate memory\nBytes requested=%d",(int)(voxels*sizeof(float)));
        MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
    }

    memset(&rgb,0,sizeof(RGBQUAD));
    memset(evect, 0, sizeof(float)*voxels);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*DT).img[voxel+Dxx*voxels] || (*DT).img[voxel+Dyy*voxels] || (*DT).img[voxel+Dzz*voxels])
        {
            if (EigenSolutionsForDTI(DT, voxel, evals, V))
            {
                fa=FracAnisotropy(evals[HIGH], evals[MID], evals[LOW]);

                if (fa>1.0) fa=1.0;

                rgb.rgbRed  =(unsigned char)(fa*fabs(V[2])*255);
                rgb.rgbGreen=(unsigned char)(fa*fabs(V[5])*255);
                rgb.rgbBlue =(unsigned char)(fa*fabs(V[8])*255);

                memcpy(&evect[voxel], &rgb, sizeof(float));
            }

        }

    }

    if ( ((*DT).img=(float *)realloc((*DT).img, voxels*sizeof(float))) )
    {
        memcpy((*DT).img, evect, voxels*sizeof(float));

        (*DT).offset=0.0;
        (*DT).scale=1.0;
        (*DT).MaxIntensity=255.0;
        (*DT).DataType=DT_RGB;
        (*DT).Z/=6;
        (*DT).volumes=1;
        (*DT).filename[0]='\0';
        (*DT).headername[0]='\0';
        sprintf((*DT).Descrip,"Principal evector weighted by fa");
        (*DT).changed=1;
    }


    if (evect) free(evect);

    return 1;
}


//=============================================================================================
//              Compute eigen system
//=============================================================================================
int EigenSolutionsForDTI(struct Image *DT, int voxel, double evals[], double V[])
{

    double M[9];

    GetMatrixFromTensor(M, (*DT).img, (*DT).X, (*DT).Y, (*DT).Z/6, voxel, (*DT).scale, (*DT).offset);

    if (JacobiEigenSystemSolver(M, V, evals, 3, 1) /*&& evals[0]>0.0 && evals[1]>0.0 && evals[2]>0.0*/)
    {
        if (evals[0]<0.0) evals[0]=0.0;
        if (evals[1]<0.0) evals[1]=0.0;
        if (evals[2]<0.0) evals[2]=0.0;
        return 1;
    }

    return 0;
}






//=============================================================================================
//                   -Convert a tensor image to SCALAR
//                   -SCALAR is either FA, RA, or TRACE, EVAL
//=============================================================================================
int ConvertTensorToScalar(struct Image *DT, int SCALAR)
{

    float *scalar;
    double M[9], V[9], evals[3];
    double fa, ra, trace, max;
    int voxel, voxels;
    int volumes=1;
    char txt[256];




    if ((*DT).volumes!=6)
    {
        sprintf(txt,"In ConvertTensorToPrincipalEvector: Wrong number of volumes\nvolumes=%d (should be 6).",(*DT).volumes);
        MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
        return 0;
    }

    voxels=(*DT).X*(*DT).Y*(*DT).Z/6;

    if (SCALAR==EVALS) volumes=3;

    scalar=(float *)malloc(voxels*volumes*sizeof(float));
    if (!scalar)
    {
        sprintf(txt,"In ConvertTensorToScalar: Failed to allocate memory\nBytes requested=%d",(int)(voxels*volumes*sizeof(float)));
        MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
        return 0;
    }

    max=0.0;
    memset(scalar, 0, sizeof(float)*voxels*volumes);
    for (voxel=0; voxel<voxels; voxel++)
    {
        if ((*DT).img[voxel+Dxx*voxels] || (*DT).img[voxel+Dyy*voxels] || (*DT).img[voxel+Dzz*voxels])
        {
            GetMatrixFromTensor(M, (*DT).img, (*DT).X, (*DT).Y, (*DT).Z/6, voxel, (*DT).scale, (*DT).offset);

            if (JacobiEigenSystemSolver(M, V, evals, 3, 1) /*&& evals[0]>0.0 && evals[1]>0.0 && evals[2]>0.0*/)
            {
                if (evals[0]<0.0) evals[0]=0.0;
                if (evals[1]<0.0) evals[1]=0.0;
                if (evals[2]<0.0) evals[2]=0.0;

                if (SCALAR==FA)
                {
                    fa=FracAnisotropy(evals[HIGH], evals[MID], evals[LOW]);
                    if (fa>1.0) fa=1.0;
                    scalar[voxel]=fa;
                }

                if (SCALAR==RA)
                {
                    ra=RelAnisotropy(evals[HIGH], evals[MID], evals[LOW]);
                    scalar[voxel]=ra;
                }

                if (SCALAR==TRACE)
                {
                    trace=DTtrace(evals[HIGH], evals[MID], evals[LOW]);
                    scalar[voxel]=trace;
                }

                if (SCALAR==EVALS)
                {
                    scalar[voxel]=evals[HIGH];
                    scalar[voxel+voxels]=evals[MID];
                    scalar[voxel+2*voxels]=evals[LOW];
                }

                if (scalar[voxel]>max) max=scalar[voxel];

            }
        }
    }

    if ( ((*DT).img=(float *)realloc((*DT).img, voxels*volumes*sizeof(float))) )
    {
        memcpy((*DT).img, scalar, voxels*volumes*sizeof(float));

        (*DT).offset=0.0;
        (*DT).scale=1.0;
        (*DT).MaxIntensity=max;
        (*DT).DataType=DT_FLOAT;
        (*DT).Z/=6;
        (*DT).Z*=volumes;
        (*DT).volumes=volumes;
        (*DT).filename[0]='\0';
        (*DT).headername[0]='\0';
        if (SCALAR==FA) sprintf((*DT).Descrip,"fa");
        if (SCALAR==RA) sprintf((*DT).Descrip,"ra");
        if (SCALAR==TRACE) sprintf((*DT).Descrip,"Trace");
        if (SCALAR==EVALS) sprintf((*DT).Descrip,"Evalues");
        (*DT).changed=1;
    }


    if (scalar) free(scalar);

    return 1;
}






//=============================================================================================
//                  -Matrix from 6 volume tensor image at given voxel
//=============================================================================================
int GetMatrixFromTensor(double M[], float tens[], int X, int Y, int Zpv, int voxel, float scale, float offset)
{

    int voxels=X*Y*Zpv;

    M[0]=(tens[voxel+Dxx*voxels]*scale+offset);
    M[4]=(tens[voxel+Dyy*voxels]*scale+offset);
    M[8]=(tens[voxel+Dzz*voxels]*scale+offset);
    M[1]=M[3]=(tens[voxel+Dxy*voxels]*scale+offset);
    M[2]=M[6]=(tens[voxel+Dxz*voxels]*scale+offset);
    M[5]=M[7]=(tens[voxel+Dyz*voxels]*scale+offset);

    return 1;
}

























//==============================================================================
//         Tensor ODF
//         Tinv[] is the inverse of the tensor
//         **NOT normalised
//         See Stams thesis, page 32
//==============================================================================
double TensorODF(double Tinv[], struct ThreeVector V)
{

    double vTv;
    double odf=0.0;

    vTv=V.x*(Tinv[0]*V.x + Tinv[1]*V.y + Tinv[2]*V.z) +
        V.y*(Tinv[3]*V.x + Tinv[4]*V.y + Tinv[5]*V.z) +
        V.z*(Tinv[6]*V.x + Tinv[7]*V.y + Tinv[8]*V.z);
    if (vTv)
    {
        //ODF in direction V[dir].From Y. Iturria-Medina, NeuroiImage, 36, 2007
        odf=pow(1.0/vTv , 4);//raised the power because otherwise there is little directionality
    }
    return odf;
}








//==============================================================================
//              Compute 2 vectors that are orthogonal to a given vector:
//                  V[0],V[1],V[2], which is assumed to be normalised
//==============================================================================
int OrthogonalVectors(double V[])
{

    double length;

    if (fabs(V[0])>0.0 && (V[0]>=V[1]) && (V[0]>=V[2]))
    {
        V[3]=-(V[1]*V[1]+V[2]*V[2])/V[0];
        V[4]=V[1];
        V[5]=V[2];
    }
    else if (fabs(V[1])>0.0 && (V[1]>=V[0]) && (V[1]>=V[2]))
    {
        V[4]=-(V[0]*V[0]+V[2]*V[2])/V[1];
        V[3]=V[0];
        V[5]=V[2];
    }
    else if (fabs(V[2])>0.0)
    {
        V[5]=-(V[0]*V[0]+V[1]*V[1])/V[2];
        V[3]=V[0];
        V[4]=V[1];
    }
    else
    {
        memset(V,0,9*sizeof(double));
        return 0;
    }

    length=sqrt(V[3]*V[3]+V[4]*V[4]+V[5]*V[5]);
    if (length)
    {
        V[3]/=length;
        V[4]/=length;
        V[5]/=length;
        //the third vector is the cross-product between the other two
        V[6]=V[1]*V[5]-V[2]*V[4];
        V[7]=V[0]*V[5]-V[2]*V[3];
        V[8]=V[0]*V[4]-V[1]*V[3];
        length=sqrt(V[6]*V[6]+V[7]*V[7]+V[8]*V[8]);
        if (length)
        {
            V[6]/=length;
            V[7]/=length;
            V[8]/=length;
        }
    }


    return 1;
}

//===================================================================================
//PROCESS A SINGLE DW SCAN WITH A T2
//AS USED IN WiRMS
//DONT KNOW WHICH VOLUME IS THE T2, BUT IT SHOULD BE THE ONE WITH THE HIGHEST INTENSITY
//===================================================================================
int Process2volumeDWscan(HWND hwnd, struct Image *DWI, struct bMatrix B[])
{
    int result=0;
    int i;
    int voxel,voxels;
    int DWIindicator=(B[0].bValue>B[1].bValue) ? 0:1;
    char *p=NULL;
    char dir[MAX_PATH];
    char directory[MAX_PATH];
    struct Image ratio;

    memset(&ratio,0,sizeof(struct Image));

    if (B[DWIindicator].bValue<=0.0) goto END;//no diffusion weighting so END

    //CREATE THE DIRECTORY TO STORE THE PROCESSEDIMAGES
    sprintf(dir,"%s",(*DWI).filename);
    i=DirectoryFileDivide(dir);
    if (i)
    {
        p=&dir[i+1];
        dir[i]='\0';
    }
    else return 0;
    if ((i=strlen(p))>3) p[i-4]='\0';
    sprintf(directory,"%s\\processedDWI_%s",dir, p);
    if ((!CreateDirectory(directory, NULL)) && (GetLastError()!=ERROR_ALREADY_EXISTS))
    {
        return 0;
    }


    //BRAIN EXTRACTION OPTION
    if (gOptions.ExtractBrain)
    {
        //first extract the brain so that the processing works better
        ExtractBrainByTemplateRegistrationNonParametric(hwnd, DWI, REGISTRATION_PARAMETERS_ORDER3);
    }


    voxels=(*DWI).X*(*DWI).Y*(*DWI).Z/(*DWI).volumes;
    if (!MakeImage(&ratio, (*DWI).X, (*DWI).Y, (*DWI).Z/(*DWI).volumes, 1, (*DWI).dx, (*DWI).dy, (*DWI).dz, (*DWI).x0, (*DWI).y0, (*DWI).z0, 1.0, 0.0, DT_FLOAT, HDR, "DWIratio")) goto END;


    for (voxel=0;voxel<voxels;voxel++)
    {
        if ( ((*DWI).img[voxel]>0.0) && ((*DWI).img[voxel + voxels]>0.0) )
        {
            if (!DWIindicator) ratio.img[voxel] = (*DWI).img[voxel] / (*DWI).img[voxel + voxels];
            else ratio.img[voxel] =  (*DWI).img[voxel + voxels] / (*DWI).img[voxel];
        }
    }


    //convert to an ADC
    for (voxel=0;voxel<voxels;voxel++)
    {
        if (ratio.img[voxel]>0.0) ratio.img[voxel] = -log(ratio.img[voxel]) / B[DWIindicator].bValue;
        else ratio.img[voxel]=0.0;

        if (ratio.img[voxel]<0.0) ratio.img[voxel]=0.0;
    }


    sprintf(ratio.filename,"%s/ADC.img",directory);
    sprintf(ratio.headername,"%s/ADC.hdr",directory);
    Save(&ratio);

    result=1;
END:
    ReleaseImage(&ratio);

    return result;
}


//===================================================================================
//          Process the DWI images
//===================================================================================
int ProcessDWI(HWND hwnd, struct Image *DWI)
{

    struct bMatrix B[MAX_DIFFUSION_DIRECTIONS];
    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS];

     if ((*DWI).volumes==2)
    {
        //ASSUME THIS IS A SINGLE DW SCAN AND A T2
        if (!LoadbMatrices(B, (*DWI).volumes, 0)) return 0;
        return Process2volumeDWscan(hwnd, DWI, B);
    }


    if ((*DWI).volumes<7)
    {
        MessageBox(NULL,"In ProcessDWI: Not enough DWI images!", "", MB_OK);
        return 0;
    }

    if ((*DWI).volumes>=MAX_DIFFUSION_DIRECTIONS)
    {
        MessageBox(NULL,"In ProcessDWI: Too many directions. Please complain to the author", "", MB_OK);
        return 0;
    }

    //load the b-matrices
    if (!LoadbMatrices(B, (*DWI).volumes, 0)) return 0;
    if (!LoadAcquisitionDirections(V)) return 0;

    return ProcessDWIGivenBmatAndV(hwnd, DWI, B, V);
}

//===================================================================================
//          Process the DWI images, with optional smoothing
//===================================================================================
int ProcessDWIGivenBmatAndV(HWND hwnd, struct Image *DWI, struct bMatrix B[], struct ThreeVector V[])
{

    struct Image image, tensor, fODF, classimg;
    int i;
    int voxels=(*DWI).X*(*DWI).Y*(*DWI).Z/(*DWI).volumes;
    double firstchange, change;
    char dir[MAX_PATH];
    char directory[MAX_PATH];
    char txt[256];
    char *p=NULL;
    HDC hDC;


    memset(&classimg, 0, sizeof(struct Image));
    memset(&image, 0, sizeof(struct Image));
    memset(&fODF, 0, sizeof(struct Image));
    memset(&tensor, 0, sizeof(struct Image));




    if ((*DWI).volumes<7)
    {
        //MessageBox(NULL,"In ProcessDWI: Not enough DWI images!", "", MB_OK);
        return 0;
    }

    if ((*DWI).volumes>=MAX_DIFFUSION_DIRECTIONS)
    {
        //MessageBox(NULL,"In ProcessDWI: Too many directions. Please complain to the author", "", MB_OK);
        return 0;
    }



    //CREATE THE DIRECTORY TO STORE THE PROCESSEDIMAGES
    sprintf(dir,"%s",(*DWI).filename);
    i=DirectoryFileDivide(dir);
    if (i)
    {
        p=&dir[i+1];
        dir[i]='\0';
    }
    else return 0;
    if ((i=strlen(p))>3) p[i-4]='\0';
    sprintf(directory,"%s\\processedDWI_%s",dir, p);
    if ((!CreateDirectory(directory, NULL)) && (GetLastError()!=ERROR_ALREADY_EXISTS))
    {
        return 0;
    }





    //ALLIGN DWI OPTION
    if (gOptions.alignDWI)
    {
        AllignDWIimages(hwnd, DWI, V);
        if ((*DWI).ImageType==HDR)
        {
            sprintf((*DWI).filename,"%s/DWI_aligned.img",directory);
            sprintf((*DWI).headername,"%s/DWI_aligned.hdr",directory);
        }
        else
        {
            sprintf((*DWI).filename,"%s/DWI_aligned.nii",directory);
        }

        Save(DWI);
        //MessageBox(hwnd,"Aligned","",MB_OK);
    }




    //BRAIN EXTRACTION OPTION
    if (gOptions.ExtractBrain)
    {
        //first extract the brain so that the processing works better
        ExtractBrainByTemplateRegistrationNonParametric(hwnd, DWI, REGISTRATION_PARAMETERS_ORDER3);
    }




    //SMOOTHING OPTION
    if (gOptions.SmoothDWI)
    {
        hDC=GetDC(hwnd);
        i=0;
        //MessageBox(hwnd,directory,"",MB_OK);
        firstchange=SmoothMultiVolumeResidualWeighted(DWI);
        sprintf(txt,"Smoothing: iteration %d",i);
        TextOut(hDC,100,200,txt,strlen(txt));
        do
        {
            change=SmoothMultiVolumeResidualWeighted(DWI);
            i++;
            sprintf(txt,"Smoothing: iteration %d                              ",i);
            RemoveInput(hwnd);
            TextOut(hDC,100,200,txt,strlen(txt));
            UpdateWindow(hwnd);
        }
        while(i<20 && (change>(firstchange/10.0)));
        if ((*DWI).ImageType==HDR)
        {
            sprintf((*DWI).filename,"%s/DWI_smoothed.img",directory);
            sprintf((*DWI).headername,"%s/DWI_smoothed.hdr",directory);
        }
        else
        {
            sprintf((*DWI).filename,"%s/DWI_smoothed.nii",directory);
        }
        Save(DWI);
        ReleaseDC(hwnd, hDC);
        //MessageBox(hwnd,"Smoothed","",MB_OK);
    }




#if defined (DEVELOP)
    //fODF OPTION
    if (MakeCopyOfImage(DWI,&fODF))
    {
        ComputeFODF(hwnd, &fODF, V, B);

        if ((*DWI).ImageType==HDR)
        {
            sprintf(fODF.filename,"%s/fODF.img",directory);
            sprintf(fODF.headername,"%s/fODF.hdr",directory);
        }
        else
        {
            sprintf(fODF.filename,"%s/fODF.nii",directory);
        }
        Save(&fODF);
        ReleaseImage(&fODF);
    }
#endif


//get the tensor
    if (!(MakeCopyOfImage(DWI,&tensor) && ConvertDWItoTensorGivenBmatrices(&tensor, B))) goto END;


    //Tensor
    if ((*DWI).ImageType==HDR)
    {
        sprintf(tensor.filename,"%s/Tensor.img", directory);
        sprintf(tensor.headername,"%s/Tensor.hdr", directory);
    }
    else
    {
        sprintf(tensor.filename,"%s/Tensor.nii", directory);
    }
    Save(&tensor);



//FA
    MakeCopyOfImage(&tensor,&image);
    ConvertTensorToScalar(&image, FA);

    //get the FA for use with the tissue classifier
    if( MakeCopyOfImage(&image, &classimg) )
    {
        if ( (classimg.img=(float *)realloc(classimg.img, 4*voxels*sizeof(float))) )
        {
            memcpy(classimg.img, image.img, voxels*sizeof(float));
            classimg.volumes=4;
            classimg.Z*=4;
        }
    }



    if ((*DWI).ImageType==HDR)
    {
        sprintf(image.filename,"%s/fa.img",directory);
        sprintf(image.headername,"%s/fa.hdr",directory);
    }
    else
    {
        sprintf(image.filename,"%s/fa.nii",directory);
    }
    Save(&image);


    //RA
    if (MakeCopyOfImage(&tensor,&image))
    {
        ConvertTensorToScalar(&image, RA);
        if ((*DWI).ImageType==HDR)
        {
            sprintf(image.filename,"%s/ra.img",directory);
            sprintf(image.headername,"%s/ra.hdr",directory);
        }
        else
        {
            sprintf(image.filename,"%s/ra.nii",directory);
        }

        Save(&image);
        ReleaseImage(&image);
    }

    //TRACE
    if (MakeCopyOfImage(&tensor,&image))
    {
        ConvertTensorToScalar(&image, TRACE);
        if ((*DWI).ImageType==HDR)
        {
            sprintf(image.filename,"%s/trace.img", directory);
            sprintf(image.headername,"%s/trace.hdr", directory);
        }
        else
        {
            sprintf(image.filename,"%s/trace.nii",directory);
        }

        Save(&image);
        ReleaseImage(&image);
    }


    //EVALS
    if (MakeCopyOfImage(&tensor,&image))
    {
        ConvertTensorToScalar(&image, EVALS);
        if ((*DWI).ImageType==HDR)
        {
            sprintf(image.filename,"%s/eigen values.img", directory);
            sprintf(image.headername,"%s/eigen values.hdr", directory);
        }
        else
        {
            sprintf(image.filename,"%s/eigen.nii",directory);
        }

        Save(&image);
        if (classimg.img) memcpy(&classimg.img[voxels], image.img, voxels*3*sizeof(float));
        ReleaseImage(&image);
    }


    //Principal eigenvector
    if (MakeCopyOfImage(&tensor,&image))
    {
        ConvertTensorToPrincipalEvector(&image);
        if ((*DWI).ImageType==HDR)
        {
            sprintf(image.filename,"%s/Pvect.img", directory);
            sprintf(image.headername,"%s/Pvect.hdr", directory);
        }
        else
        {
            sprintf(image.filename,"%s/Pevect.nii", directory);
        }

        Save(&image);
        ReleaseImage(&image);
    }


    //PROBABILITY
    if ((gOptions.TissueClass) && (classimg.img))
    {
        MultiVolumeClassification(&classimg, 3, 20);
        if ((*DWI).ImageType==HDR)
        {
            sprintf(classimg.filename,"%s/class.img", directory);
            sprintf(classimg.headername,"%s/class.hdr", directory);
        }
        else
        {
            sprintf(classimg.filename,"%s/class.nii", directory);
        }

        Save(&classimg);
        ReleaseImage(&classimg);
    }





END:
    ReleaseImage(&tensor);
    ReleaseImage(&image);
    ReleaseImage(&fODF);
    ReleaseImage(&classimg);

    return 1;
}





//===================================================================================
//          Rearrange the DWI so that there is only 1 b=0 volume, and it is the
//          first volume
//===================================================================================
int RearrangeDWI(struct Image *DWI)
{

    struct Image DWIcpy;
    int result=0;
    int i,n;
    int NumberOfB0;
    int voxel, voxels=(*DWI).X*(*DWI).Y*(*DWI).Z/(*DWI).volumes;
    struct bMatrix B[MAX_DIFFUSION_DIRECTIONS], Bcopy[MAX_DIFFUSION_DIRECTIONS];
    struct ThreeVector V[MAX_DIFFUSION_DIRECTIONS], Vcopy[MAX_DIFFUSION_DIRECTIONS];
    float bvals[MAX_DIFFUSION_DIRECTIONS];
    char dir[MAX_PATH];
    char directory[MAX_PATH];
    char txt[256];
    char fname[MAX_PATH];
    char *p=NULL;


    memset(&DWIcpy,0, sizeof(struct Image));
    memset(Bcopy, 0, sizeof(struct bMatrix)*MAX_DIFFUSION_DIRECTIONS);
    memset(Vcopy, 0, sizeof(struct ThreeVector)*MAX_DIFFUSION_DIRECTIONS);
    memset(bvals, 0, sizeof(float)*MAX_DIFFUSION_DIRECTIONS);

    //CHECKS
    if ((*DWI).volumes<7)
    {
        MessageBox(NULL,"In RearrangeDWI: Not enough DWI images!", "", MB_OK);
        return 0;
    }
    if ((*DWI).volumes>=MAX_DIFFUSION_DIRECTIONS)
    {
        MessageBox(NULL,"In RearrangeDWI: Too many directions. Please complain to the author", "", MB_OK);
        return 0;
    }

    //LOAD DIRECTIONS AND BMATRICES
    if ((n=LoadAcquisitionDirections(V))!=(*DWI).volumes)
    {
        sprintf(txt,"In RearrangeDWI: Number of volumes (%d) is not equal to the number of directions (%d)!",(*DWI).volumes,n);
        MessageBox(NULL,txt , "", MB_OK);
        return 0;
    }
    if ((n=LoadbMatrices(B, (*DWI).volumes, 1))!=(*DWI).volumes)
    {
        sprintf(txt,"In RearrangeDWI: Number of volumes (%d) is not equal to the number of b matrices (%d)!",(*DWI).volumes,n);
        MessageBox(NULL,txt , "", MB_OK);
        return 0;
    }


    //COUNT HOW MANY B VALUES=0; SHOULD JUST BE THE FIRST FOR NeuRoi
    NumberOfB0=0;
    for (i=0; i<(*DWI).volumes; i++)
    {
        if (B[i].bValue==0.0) NumberOfB0++;
    }
    if (!NumberOfB0)
    {
        MessageBox(NULL,"No b=0 images found!","",MB_OK|MB_ICONWARNING);
        return 0;
    }
//sprintf(txt,"%d",NumberOfB0);
//MessageBox(NULL,txt,"",MB_OK);


    //IF ONLY THE FIRST B VALUE IS ZERO, THEN NO REARRANGING IS REQUIRED
    if ((NumberOfB0==1) && (B[0].bValue==0.0))
    {
        MessageBox(NULL,"DWI images do not need rearranging","",MB_OK);
        return 0;
    }

    if (MakeCopyOfImage( DWI, &DWIcpy ))
    {
        //make image including only the non zero bval volumes
        n=1;
        for (i=0; i<(*DWI).volumes; i++)
        {
            if ((B[i].bValue>0.0) && (n<(*DWI).volumes))
            {
                bvals[n]=B[i].bValue;
                Bcopy[n]=B[i];
                Vcopy[n]=V[i];
                memcpy(&DWIcpy.img[voxels*n], &(*DWI).img[voxels*i], voxels*sizeof(float));
                n++;
            }
        }
        //create the first image, which has b=0, and is an average of all b=0 images in DWI
        memset(DWIcpy.img,0,voxels*sizeof(float));
        for (i=0; i<(*DWI).volumes; i++)
        {
            if (!(B[i].bValue))
            {
                for (voxel=0; voxel<voxels; voxel++)
                {
                    DWIcpy.img[voxel]+=(*DWI).img[voxel+i*voxels]/NumberOfB0;
                }
            }
        }

        //adjust the number of volumes
        DWIcpy.volumes -= (NumberOfB0-1);
        DWIcpy.Z -= (NumberOfB0-1)*(*DWI).Z/(*DWI).volumes;

        //save the bmat, bvals, bvecs, and DWI image files to a sub-folder
        //CREATE THE DIRECTORY TO STORE THE PROCESSEDIMAGES
        sprintf(dir,"%s",(*DWI).filename);
        i=DirectoryFileDivide(dir);
        if (i)
        {
            p=&dir[i+1];
            dir[i]='\0';
        }
        else return 0;
        if ((i=strlen(p))>3) p[i-4]='\0';
        sprintf(directory,"%s\\processedDWI_%s",dir, p);
        if ((!CreateDirectory(directory, NULL)) && (GetLastError()!=ERROR_ALREADY_EXISTS))
        {
            return 0;
        }

        //save the DWI
        sprintf(DWIcpy.filename,"%s/DWI.img", directory);
        sprintf(DWIcpy.headername,"%s/DWI.hdr", directory);
        DWIcpy.ImageType=HDR;
        Save(&DWIcpy);

        sprintf(fname,"%s/bmat", directory);
        SaveBmatrices(fname, Bcopy, DWIcpy.volumes);

        sprintf(fname,"%s/bvals", directory);
        SaveBvalues(fname, bvals, DWIcpy.volumes);

        sprintf(fname,"%s/bvecs", directory);
        SaveGradientVectors(fname, Vcopy, DWIcpy.volumes);

        //****************************************************************

    }
    else goto END;


    result=1;
END:
    ReleaseImage(&DWIcpy);

    return result;
}







//===================================================================================
//          Save B matrices
//===================================================================================
int SaveBmatrices(char fname[], struct bMatrix *B, int N)
{

    FILE *fp;
    int i;

    if (!(fp=fopen(fname, "w"))) return 0;


    fprintf(fp,"%d\n",N);
    for (i=0; i<N; i++)
    {
        fprintf(fp,"%f\n",B[i].bValue);
        fprintf(fp,"%f %f %f\n",B[i].b[0][0], B[i].b[0][1], B[i].b[0][2]);
        fprintf(fp,"%f %f %f\n",B[i].b[1][0], B[i].b[1][1], B[i].b[1][2]);
        fprintf(fp,"%f %f %f\n",B[i].b[2][0], B[i].b[2][1], B[i].b[2][2]);
    }

    fclose (fp);

    return 0;
}

//===================================================================================
//          Save B values
//===================================================================================
int SaveBvalues(char fname[], float *bvals, int N)
{

    FILE *fp;
    int i;

    if (!(fp=fopen(fname, "w"))) return 0;

    for (i=0; i<N; i++)
    {
        fprintf(fp,"%f ",bvals[i]);
    }

    fclose (fp);

    return 0;
}






//===================================================================================
//          Save gradient vectors
//===================================================================================
int SaveGradientVectors(char fname[], struct ThreeVector *V, int N)
{

    FILE *fp;
    int i;

    if (!(fp=fopen(fname, "w"))) return 0;

    for (i=0; i<N; i++) fprintf(fp,"%f ",V[i].x);
    for (i=0; i<N; i++) fprintf(fp,"%f ",V[i].y);
    for (i=0; i<N; i++) fprintf(fp,"%f ",V[i].z);

    fclose (fp);

    return 0;
}






//===================================================================================
//CONVERT FSL V# FILES TO RGB
//V# FILES ARE 3 VOLUME, WITH EACH VOLUME BEING A VECTOR COMPONENT
//===================================================================================
int ConvertFSL_V_to_RGB(HWND hwnd, struct Image *image)
{
    RGBQUAD rgb;
    struct Image RGBimg;
    struct Image modulation;
    struct ThreeVector V;
    int voxel, voxelspv=(*image).X*(*image).Y*(*image).Z/3;
    int result=0;
    float max;
    float m;

    memset(&RGBimg,0,sizeof(struct Image));

    if ( (*image).volumes!=3 ) goto END;

    if (!MakeImage(&RGBimg, (*image).X,(*image).Y, (*image).Z/3, 1, (*image).dx, (*image).dy, (*image).dz,
                     (*image).x0, (*image).y0, (*image).z0, 1.0, 0.0, DT_RGB,
                     NIFTI, "RGB")) goto END;
    sprintf(RGBimg.filename,"./FSL_V#_to_RGB.nii");

    memset(&modulation,0,sizeof(struct Image));
    if (!LoadAnalyzeOrNiftiEx(hwnd, &modulation, "Load modulating image", 1)) goto END;
    if ((modulation.X!=(*image).X) ||
        (modulation.Y!=(*image).Y) ||
        (modulation.Z/modulation.volumes!=(*image).Z/(*image).volumes)) goto END;
    max=0.0;
    for (voxel=0;voxel<voxelspv;voxel++)
    {
        if (fabs(modulation.img[voxel])>max) max=fabs(modulation.img[voxel]);
    }
    if (max>0.0){ for (voxel=0;voxel<voxelspv;voxel++) modulation.img[voxel]=fabs(modulation.img[voxel]/max); }

    for (voxel=0;voxel<voxelspv*3;voxel++)
    {
        (*image).img[voxel]=(*image).offset+(*image).scale*(*image).img[voxel];
    }



    for (voxel=0;voxel<voxelspv;voxel++)
    {
        if ((m=modulation.img[voxel])>0.0)
        {
            V.x=(*image).img[voxel];
            V.y=(*image).img[voxel+voxelspv];
            V.z=(*image).img[voxel+2*voxelspv];
            NormaliseThreeVector(&V);

            if (m>1.0) m=1.0;

            rgb.rgbRed=255*(fabs(V.x)*modulation.img[voxel]);
            rgb.rgbGreen=255*(fabs(V.y)*modulation.img[voxel]);
            rgb.rgbBlue=255*(fabs(V.z)*modulation.img[voxel]);
            memcpy(&RGBimg.img[voxel],&rgb,sizeof(RGBQUAD));
        }
    }
    ReleaseImage(image);
    MakeCopyOfImage(&RGBimg, image);
    (*image).MaxIntensity=255.0;
    (*image).scale=1.0;
    (*image).offset=0.0;

    result=1;

END:
    ReleaseImage(&RGBimg);
    ReleaseImage(&modulation);

    return result;
}



