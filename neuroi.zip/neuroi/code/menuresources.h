/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Resources_H)
//Do Nothing
#else
#define Resources_H

///COMMENT OUT FOR RELEASE VERSION
//#define DEVELOP
///-------------------------------

#include <windows.h>
//==============================================================================
//                         MENU IDs start 100
//==============================================================================
#define IDMAINMENU              100
#define ID_NEUROI_ICON          101
#define IDM_FILE_EXIT           105                                             //File
#define IDM_FILE_OPEN           110
#define IDM_FILE_SAVE           115
#define IDM_FILE_SAVEAS         120
#define IDM_SAVE_BITMAP         121
#define IDM_SAVE_ALL_BITMAPS    122
#define IDM_OPEN_TEMPLATE       125
#define IDM_OPEN_TALAIRACH      126
#define IDM_OPEN_GM                  127
#define IDM_LOAD_OVERLAY        130
#define IDM_ADD_OVERLAY         135
#define IDM_FILE_SAVEAS_FLOAT 136
#define IDM_FILE_SAVEAS_CHAR 137
#define IDM_SAVE_AS_NIFTI 138
#define IDM_SAVE_AS_ANALYZE 139
#define IDM_FILE_SAVEAS_BINARY_CHAR 140
#define IDM_FILTER_GAUSS_1      200                                             //filters
#define IDM_FILTER_GAUSS_2      205
#define IDM_FILTER_GAUSS_3      210
#define IDM_FILTER_GAUSS_4      215
#define IDM_FILTER_MEDIAN       220
#define IDM_FILTER_SOBEL2D        225
#define IDM_FILTER_SOBEL3D      226
#define IDM_FILTER_MGS          230
#define IDM_MULTI_VOLUME_FILTER 231
#define IDM_COLOUR_BACKGROUND   235                                             //settings
#define IDM_VIEW_PLANES         240
#define IDM_SHOW_CROSS          245
#define IDM_SHOW_ROI_NUMBERS    246
#define IDM_STANDARD_SCALE      248
#define IDM_LOAD_WITH_STANDARD_SCALE 249
#define IDM_SHOW_ROIS			250
#define IDM_LINK_PROGRAMS       251
#define IDM_CROSS_HAIR          255
#define IDM_OPTIONS             260
#define IDM_SHOW_OVERLAYS       265
#define IDM_OVERLAY_RGB         266
#define IDM_OVERLAY_RBG         267
#define IDM_OVERLAY_GRB         268
#define IDM_OVERLAY_GBR         269
#define IDM_OVERLAY_BRG         270
#define IDM_OVERLAY_BGR         271
#define IDM_SHOW_SOLID_OVERLAYS 272
#define IDM_ROTATE_X            300                                             //reformat
#define IDM_ROTATE_Y            305
#define IDM_ROTATE_Z            310
#define IDM_FORCE_1x1x1         315
#define IDM_MIRROR              320
#define IDM_HISTOGRAM_EQUALISE  325                                             //Process
#define IDM_AUTO_ROIS           340                                             //ROIs
#define IDM_MANUAL_ROIS         341
#define IDM_LOAD_ROIS           342
#define IDM_SAVE_ROIS           343
#define IDM_CLEAR_ROIS          344
#define IDM_SAVE_ROI_BINARY     345
#define IDM_SAVE_OBJECTS        346
#define IDM_ROIs_TO_OBJECTS     347
#define IDM_ROI_OBJECT_OVERLAP  348
#define IDM_CONVERT_OBJECT_TO_ROIs  349
#define IDM_TRANSFORM_ROIs      350
#define IDM_RANGE_TOOL          359                                             //Tools
#define IDM_EDIT_HEADER         360
#define IDM_AUTO_THRESHOLD      361
#define IDM_AUTO_THRESHOLD_BRAIN      362
#define IDM_INTERLEAVE          363
#define IDM_APPEND_VOLUMES      364
#define IDM_COREGISTER          365
#define IDM_MV_COREGISTER       366
#define IDM_MANUAL_REGISTRATION 367
#define IDM_COMPUTE_MTR         370
#define IDM_COMPUTE_MTR_MVOL    371
#define IDM_CONVERT_TO_MIP      372
#define IDM_UNWRAP				373
#define IDM_UNWRAP_CORRECT		374
#define IDM_ADD_IMAGES			376
#define IDM_SEPARATE_VOLUMES    377
#define IDM_FIT_T1              380
#define IDM_FIT_T1S             382
#define IDM_T1_CALIBRATION      383
#define IDM_FIT_T1_MLE          384
#define IDM_INHOMOGENEITY       386
#define IDM_APPLY_MASK          387
#define IDM_APPLY_NOT_MASK      388
#define IDM_LARGE_INHOMOGENEITY 389
#define IDM_CONVERT_TO_BINARY   390
#define IDM_LOCALALE            392
#define IDM_METAL               393
#define IDM_CLUSTERZ            394
#define IDM_CBMAN               395
#define IDM_META_HOMOGENEITY_TEST 396
#define IDM_SLICE_ORDER         397
#define IDM_VOLUME_ORDER        398
#define IDM_SORT_BY_STUDYID     399
#define IDM_SORT_BY_CONDITION   400
#define IDM_SORT_BY_CONTRAST    401
#define IDM_CORRELATE_Z_SCORES  402
#define IDM_ANALYSIS_OF_BRAIN_COORDINATES 403
#define IDM_CROSS_VALIDATION_CBMA 405
#define IDM_FLATTEN_OCT         410
#define IDM_CROP_TOP_OCT        411
#define IDM_CROP_BOTTOM_OCT     412
#define IDM_DIFFERENCE          415
#define IDM_CBRESS              416
#define IDM_BLIND_IMAGES 417
#define IDM_STATS               450                                             //Analysis
#define IDM_CORD_AREA           455
#define IDM_COMBINE_HISTOGRAMS  460
#define IDM_CONVERT_DT_TO_RGB   505                                             //DIFFUSION TENSOR
#define IDM_TENSOR_ROIS         510
#define IDM_DWI_FILTER          520
#define IDM_DWI_FILTER_RESIDUAL 521
#define IDM_ALIGN_DWI           525
#define IDM_DTI_GT              546
#define IDM_DTI_GT_CONNECT_ROIs 547
#define IDM_GENERATE_ORTHOGONAL_DIRECTIONS 551
#define IDM_CHECK_ORTHONORMALITY 552
#define IDM_GENERATE_FODF		553
#define IDM_FODF_ROIS			554
#define IDM_FODF_GT             555
#define IDM_FODF_GT_CONNECT_ROIs    556
#define IDM_GENERATE_BMAT_FILE	565
#define IDM_PROCESS_DWI         566
#define IDM_CHECK_DIRECTIONS    571
#define IDM_ARRANGE_DWI_VOLUMES 572
#define IDM_CONVERT_FSL_V_RGB   575
#define IDM_EXTRACT_BRAIN       650                                             //TEMPLATE TOOLS
#define IDM_REGISTER_TEMPLATE   655
#define IDM_REGISTER_TEMPLATE_BRAINSTEM   656
#define IDM_TEMPLATE_DIR        660
#define IDM_CLASSIFY_WM_GM_CSF  661
#define IDM_CLASSIFY_PRIOR		662
#define IDM_CLASSIFY_WM_GM_CSF_INHOMOGENEITY 663
#define IDM_INHOMOGENEITY_CLASS 664
#define IDM_BATCH_INHOMOGENEITY   670                                     //BATCH JOBS
#define IDM_BATCH_INHOMOGENEITY_TEMPLATE   672
#define IDM_BATCH_PHASE_UNWRAP          675
#define IDM_BATCH_PHASE_UNWRAP_CORRECT  680
#define IDM_BATCH_PROCESS_DWI           685
#define IDM_BATCH_EXTRACT_BRAIN         688
#define IDM_BATCH_REMOVE_BACKGROUND         690
#define IDM_BATCH_REGISTER_RIGID            692
#define IDM_BATCH_REGISTER_AFFINE            693
#define IDM_BATCH_REGISTER_NONLIN            694
#define IDM_BATCH_REGISTER_RIGID_SAME_BASE            695
#define IDM_BATCH_REGISTER_AFFINE_SAME_BASE            696
#define IDM_BATCH_REGISTER_NONLIN_SAME_BASE            697
#define IDM_BATCH_REGISTER_RIGID_UNSMOOTH            698
#define IDM_BATCH_REGISTER_AFFINE_UNSMOOTH            699
#define IDM_BATCH_REGISTER_NONLIN_UNSMOOTH            700
#define IDM_BATCH_REGISTER_RIGID_SAME_BASE_UNSMOOTH            701
#define IDM_BATCH_REGISTER_AFFINE_SAME_BASE_UNSMOOTH            702
#define IDM_BATCH_REGISTER_NONLIN_SAME_BASE_UNSMOOTH            703
#define IDM_BATCH_APPLY_TRANSFORM            704
#define IDM_BATCH_REGISTER_TO_TEMPLATE 705
#define IDM_BATCH_REGISTER_TO_TEMPLATE_BRAINSTEM 706
#define IDM_BATCH_FITt1         720
#define IDM_BATCH_FITt1_SMOOTH  721
#define IDM_BATCH_FITt1_MLE     722
#define IDM_TEST                998                                             //HELP
#define IDM_ABOUT               999
//==============================================================================
//                         TOOLBAR IDs start 1000
//==============================================================================
#define ID_TOOLBAR              1000
#define ID_ZOOM_UP              1005
#define ID_ZOOM_DOWN            1010
#define ID_ZOOM_BITMAP          1015
#define ID_ROI_NUMBERS_BITMAP   1020
#define ID_ROIs_BITMAP   		1021
#define ID_CROSS_BITMAP         1022
#define ID_SET_ORIGIN           1030
//==============================================================================
//                         MESSAGE IDs start 2000
//==============================================================================
#define ID_REFRESH              2000
#define ID_REDRAW               2010
//==============================================================================
//                         DIALOG BOX IDs start 5000
//==============================================================================
#define DLG_ABOUT                5000                                           //abour DLG

#define DLG_AUTO_ROI             5010                                           //AUTO ROIs
#define ID_ROI_HI                5020
#define ID_ROI_LO                5030
#define ID_ROI_HI_TEXT           5040
#define ID_ROI_LO_TEXT           5050
#define ID_ACCEPT_ROI            5060
#define ID_AUTOROI_SEED          5070
#define ID_SELECT_OBJECT         5080
#define ID_HOLD_OBJECT           5081
#define ID_ROI_SEED              5085
#define ID_ROI_LIMIT             5090
#define ID_ROI_DELETE            5091
#define ID_ROI_RENUMBER          5092
#define ID_ROI_EDIT              5093
#define ID_CLEAR_LIMITS          5100
#define ID_INTENSITY             5110
#define ID_GOTO_MANUAL           5115
#define ID_GROW_REGION           5116

#define DLG_AUTO_VOI             5120                                           //AUTO VOI
#define ID_VOI_LO                5130
#define ID_VOI_HI                5135
#define ID_VOI_LO_TEXT           5140
#define ID_VOI_HI_TEXT           5141
#define ID_ACCEPT_VOI            5145
#define ID_VOI_RADIUS            5155
#define ID_VOI_RADIUS_TEXT       5160

#define DLG_RANGE                5200                                           //RANGE TOOL
#define ID_RANGE_HI              5210
#define ID_RANGE_LO              5220
#define ID_RANGE_HI_TEXT         5230
#define ID_RANGE_LO_TEXT         5240
#define ID_LIMIT_INTENSITY       5260
#define ID_REMOVE_BACKGROUND     5270

#define DLG_MANUAL_ROI           5400                                           //Manual ROIs
#define ID_ROI_SQUARE            5410
#define ID_ROI_ELLIPSE          5415
#define ID_ROI_CLOSED            5420
#define ID_ROI_POLY              5430
#define ID_GOTO_AUTO             5440

#define DLG_STATS                5500                                           //Stats Dialog
#define ID_SAVE_IMAGE_HIST       5510
#define ID_SAVE_ROI_HIST         5520
#define ID_SAVE_ROI_STATS        5530
#define ID_SAVE_OBJECTS_STATS    5540
#define ID_SAVE_IMAGE_STATS      5550
#define ID_SAVE_ALL_ROIS            5555
#define ID_BINWIDTH              5560
#define ID_BINWIDTH_TEXT         5570
#define ID_MEAN                  5580
#define ID_VOLUME                5590
#define ID_SD                    5600

#define DLG_HEADER               5700                                           //Edit the header information
#define ID_VOXEL_XDIM            5710
#define ID_VOXEL_YDIM            5720
#define ID_VOXEL_ZDIM            5730
#define ID_MATRIX_XDIM           5740
#define ID_MATRIX_YDIM           5750
#define ID_MATRIX_ZDIM           5760
#define ID_MATRIX_VOLUMES        5770
#define ID_ORG_X                 5780
#define ID_ORG_Y                 5790
#define ID_ORG_Z                 5800
#define ID_SCALE                 5810
#define ID_OFFSET                5820
#define ID_MAKE_SLICE_LAST       5830
#define ID_MAKE_SLICE_FIRST      5840
#define ID_CHANGE_HEADER         5850
#define ID_CHANGE_IMAGE          5860
#define ID_DESCRIP               5865

#define DLG_TENSOR_ROI           5900                                           //TENSOR ROI DIALOG
#define ID_SHOW_FA               5910
#define ID_SHOW_RGB_EVECT        5920
#define ID_FA_THRESHOLD          5930
#define ID_FA_THRESHOLD_TEXT     5940
#define ID_ANGLE_THRESHOLD       5950
#define ID_ANGLE_THRESHOLD_TEXT  5960
#define ID_CLEAR_REGION          5965
#define ID_FIND_REGION           5970
#define ID_R2_THRESHOLD          5975
#define ID_R2_THRESHOLD_TEXT     5980
#define ID_ACCEPT_REGION         5985
#define ID_MEDIAN_FA             5990
#define ID_MEDIAN_TRACE          5991
#define ID_SAVE_OBJECT           5992
#define DLG_FODF_ROI			 5993

#define DLG_INTERACTIVE_TRACTOGRAPHY 6000
#define ID_SAVE_CONNECTIVITY     6002
#define ID_START_SEED			 6003
#define ID_END_SEED				 6004

#define DLG_COREGISTER           6100                                           //IMAGE REGISTRATION
#define DLG_MANUAL_COREGISTER 6101
#define ID_LOAD_MATCH            6105
#define ID_RIGID                 6110
#define ID_AFFINE                6115
#define ID_NONLINEAR             6116
#define ID_IMAGE_MIX             6120
#define ID_REGISTER              6125
#define ID_SAVE_REGISTERED       6130
#define ID_RESET_MATRIX          6135
#define ID_LOAD_MATRIX           6140
#define ID_RELATIVE_ERROR        6145
#define ID_TRILINEAR             6150
#define ID_NEAREST_NEIGHBOUR     6155
#define ID_CUBIC                 6157
#define ID_SMOOTH           6158
#define ID_BASE_POINTS 6159
#define ID_MATCH_POINTS 6160
#define ID_UNDO_LAST_POINT 6161

#define DLG_T1_CALIBRATION       6200                                           //CALIBRATE THE T1
#define ID_C                     6201
#define ID_T1                    6202
#define ID_F                     6203
#define ID_T1_F                  6204
#define ID_T12                   6205
#define ID_F2                    6206
#define ID_SAVE_CALIBRATION      6207
#define ID_LOAD_CALIBRATION      6208
#define ID_CALIBRATE             6209

#define DLG_RH0_TRACTS           6300
#define ID_ACCEPT_SEED           6305
#define ID_COMPUTE_P_VALUES      6310
#define ID_SEED_NAME             6315

#define DLG_GENERATE_DIRECTIONS  6500                                           //GENERATE DIRECTIONS DIALOG
#define ID_N_DIRECTIONS          6501

#define DLG_GENERATE_ORTHOGONAL_DIRECTIONS 6502
#define ID_SH_ORDER              6503

#define DLG_OPTIONS              6600                                           //OPTIONS DIALOG
#define ID_RED_BKGRND            6605
#define ID_GREEN_BKGRND          6610
#define ID_BLUE_BKGRND           6615
#define ID_COLOUR_BKGRND         6620
#define ID_RED_BKGRND_TEXT       6625
#define ID_GREEN_BKGRND_TEXT     6630
#define ID_BLUE_BKGRND_TEXT      6635
#define ID_DEFAULT_OPTIONS       6640
#define ID_DEFLECTIONS_TEXT      6645

#define DLG_LOCAL_ALE            6650                                           //LocalALE
#define ID_MERGE_GROUPS          6655
#define ID_P_VALUE_TXT           6660
#define ID_R_THRESHOLD           6661
#define ID_FWHM_TXT              6665
#define ID_FWHM2_TXT             6666
#define ID_LOAD_ACTIVATIONS      6670
#define ID_LOAD_ACTIVATIONS2     6671
#define ID_ALE_FILE_TXT          6675
#define ID_ALE_FILE_TXT2         6676
#define ID_RUN_ALE               6680
#define ID_COMPARE_ALE           6685
#define ID_TEST_FWHM             6690
#define ID_TEST_CONTRIBUTORS     6695
#define ID_MIN_EXPERIMENTS_TEXT  6700
#define ID_SAVE_CHECKS           6706
#define ID_DO_FCDR               6708
#define ID_LABEL_FILTER          6709
#define ID_FILTER_KEYWORDS       6710
#define ID_FILTER_ALE            6711
#define ID_ADD_KEYWORD           6712
#define ID_CLEAR_KEYWORDS        6713
#define ID_MEAN_FCDR             6714
#define ID_MEDIAN_FCDR           6715
#define ID_PASS_FILTER           6717
#define ID_STOP_FILTER           6718
#define ID_P_CONTRAST            6719

#define DLG_CLUSTERZ             6720
#define ID_CLUSTERZ              6721
#define ID_MEANZ                 6722
#define ID_REGRESSIONZ           6723
#define ID_CORRECTED_MEANZ       6724
#define ID_POSTHOC_REGRESSIONZ   6725
#define ID_TEST_CLUSTERZ         6726
#define ID_USE_T                 6727
#define ID_CLUSTER_DISTANCE_TXT  6728
#define ID_DO_FWE                6729
#define ID_FWER                  6730
#define ID_CLUSTER_ALL           6731
#define ID_CLUSTER_BY_EFFECT_SIGN 6732
#define ID_MARKER_SIZE           6733
#define ID_CBMAN_CLUSTERING   6734
//#define ID_DBSCAN_CLUSTERING   6735

#define DLG_CBMAN                6740
#define ID_CBMAN                 6741
#define ID_ONE_GROUP             6742
#define ID_COMPARE_GROUPS        6743
#define ID_CLUSTER_EXTENT   6744

#define DLG_ACTIVATIONS_FILE     6760
#define ID_MNI                   6761
#define ID_SUBJECTS_TXT          6762
#define ID_STUDYID_TXT           6763
#define ID_NEW_GROUP_ALE         6764
#define ID_NUMBER_OF_TABLES_ALE  6765
#define ID_SAVE_ALE              6766
#define ID_FLIPX                 6767
#define ID_USE_Z_SCORE           6768
#define ID_USE_MAP               6789
#define ID_USE_SUGGESTED_FWHM    6790
#define ID_USE_ALL_Z             6791
#define ID_USE_POSITIVE_Z        6792
#define ID_USE_NEGATIVE_Z        6793
#define ID_SAVE_CLOSEST_COORDINATES    6794

#define DLG_Z_CORRELATION        6850
#define ID_REGION_EXTENT_TXT     6855
#define ID_ADD_REGION            6860
#define ID_SAVE_CORRELATIONS     6865
#define ID_REGION_COUNT          6870

#define DLG_DIFFERENCE           7200                                           //FIND DIFFERENCES
#define ID_NORMALISE_IMAGE       7205
#define ID_SAVE_NORMALISED       7210
#define ID_DIFFERENCE_THRESHOLD  7215
#define ID_TIMER                 7220
#define ID_AUTO_FLIP             7225

#define DLG_ANALYSIS_BRAIN_COORDINATES 8000                             //Analysis of Brain Coordinates
#define ID_COORDINATE_FILES 8005
#define ID_CONTRAST_FILES 8007
#define ID_ADD_COORDINATE_FILE 8010
#define ID_ADD_CONTRAST_COORDINATE_FILE 8012
#define ID_RUN_ABC_ANALYSIS 8015
#define ID_MIN_STUDIES_TXT 8020
#define ID_VOLUME_TXT 8025
#define ID_TISSUE_VOLUMES 8030
#define ID_INDEPENDENT_COORDINATES 8035

#define DLG_CROSS_VALIDATION_COORDINATE_ANALYSIS 8040
#define ID_RUN_CVCA_ANALYSIS 8045
#define ID_RUN_CVCA_CONTRAST 8046
#define ID_RANDOMISATIONS 8047

#endif
