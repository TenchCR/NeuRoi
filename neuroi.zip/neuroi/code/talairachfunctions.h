/*
Copyright 2009 - 2015 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Talairach_H)
//Do Nothing
#else



#define Talairach_H



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include "loader.h"
#include "menuresources.h"
#include "imageprocess.h"





int BiggestTalairachLabel(char labels[], int L);


char *FindEntryInTalairachLabels(char *labels, int L, int entry);


int GetGMlabelVectors(struct Image *Tal, struct ThreeVector *VL, int *GMlabels, int Nlabeled);
int GetNearestGMimage(struct Image *GMmask, short int *nearGM, struct Image *Tal);
int GetTalairachStructureHistogram(float *Tal, int X, int Y, int Z, double *H, int Nlabels);
int GetCumulativeTalairachStructureHistogram(float *Tal, int X, int Y, int Z, double *H, int Nlabels);

int IsLabelGM(char labels[], int label, int max);
int IsMatchedString(char *i1, char *i2, int column);
int IsSubLabelInLabel(char *Label, char *SubLabel, int column);
int ShortTalairachLabel(char *BigLabel, char *shortlabel, char *sep);

char *LoadTalairachLabels(int *N);

int MatchedLevels(char labels[], int N, int l1, int l2);

int NearestGMlabel(struct ThreeVector *VL, int *GMlabels, int Nlabels, float Tal_x, float Tal_y, float Tal_z);
int NearestGM(float *TalGM, int X, int Y, int Z, int x0, int y0, int z0);

int RemoveNonGM(struct Image *Tal, char labels[], int LengthLabels, int BiggestLabel);

int CreateMergedTalairachImage(HWND hwnd, char ExecDir[]);
int ConvertTalairachToSize(HWND hwnd, struct Image *image, char ExecDir[]);
int MakeNearestGMimage(HWND hwnd);
int CreateTalGMhistogram(HWND hwnd, char ExecDir[]);

int TestShortTalairachLabel(HWND hwnd);
#endif
