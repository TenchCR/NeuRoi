/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(CLUSTERZ_H)
//Do Nothing
#else

#define CLUSTERZ_H

#include <windows.h>
#include <windowsx.h>
#include "localALE.h"



//definition of overlapping coordinates for forming clusters
//an overlap of 0 is a coordinate by itself in the CoordinateOverlaps function
#define MIN_OVERLAP 3

#define DEFAULT_MARKER_SIZE 3

#define SAVE 1
#define DONT_SAVE 0

#define CD_PROPORTION 0.05///the proportion of coordinates forming clusters under null

struct EffectSample
{
    short int Samples;//the number of samples=number of studies
    double mean;//the estimate of the mean PARAMETER
    double sigma;//the estimate of the standard deviation PARAMETER
    double covariate;//the estimate of the covariate PARAMETER for REGRESSION model
    double Ll0;//the log likelihood of the null
    double Lla;//the log likelihood of the alternative
    double *d;//The effect size, which is Z/sqrt(Number of subjects)
    double *cov;//the covariate. Could be the group indicator
    double *CensorLevel;//This is normalised absolute value and could be the minimum magnitude Z from a study, or a reported threshold, or other...
    double *SampleSD;//The within study standard deviation sqrt(1/N)
    short int *censor;//The censor indicator is LEFT_CENSORED, RIGHT_CENSORED, INTERVAL_CENSORED, ROI_CENSORED, or 0 if not censored
    int Model;
};

double pCBRESS(HWND hwnd, struct Image *image, struct Coordinates *Co, float critical, int model,
               char directory[], int MergeStudies, int *SigClusters,
               int save, int MarkerSize);

int CoordinateOverlaps(struct Coordinates *ale, double DM2[], float *overlap, float ClusteringDistance, int EffectSignMultiplier);


int RandomiseCoordinatesForTesting(float mask[],
                                   int X, int Y, int Z,
                                   float dx, float dy, float dz,
                                   float x0, float y0, float z0,
                                   struct Coordinates *Co,
                                   double ClusteringDistance);




int ForestPlotR(struct Coordinates *c, struct EffectSample *Es, double pvalue, int cluster, char directory[], int subanalysis);

double FWHMfromClusteringDistance(double CD);



double LogLikelihoodOfEffect(double Effect, double mean, double SD, double CensorThreshold, short int censor);

double ComputeMeanCovariate(struct Coordinates *Co);

double MinClusteringDistanceNonFractureRate(int studies, double minCD, double maxCD);


int CensorLevels(struct Coordinates *CoordinateStruct);

double EstimateClusteringDistanceUsingNull(HWND hwnd, struct Coordinates *CoordinateStruct, float mask[], int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0, float proportion, int MergeStudies);

int FillEffectStructureWithCluster(struct EffectSample *Es, int cluster, struct Coordinates *CoordinateStruct, int contrast, int model, int save, char directory[],
                                   int Use_t, int subanalysis);

double EstimateMinClusteringDistance(int studies, double maxCD);

double SDfromClusteringDistance(double CD);

int FreeEffectSampleStructure(struct EffectSample *Zs);

int GetAllClusters(struct Coordinates *Co, double minCD, double ClusteringDistance, int MinOverlapping, int ClusterMode);

int MakeEffectSampleStructure(struct EffectSample *Es, int Studies, int model);

double PvalueOfClusterRandomEffect(struct EffectSample *Es, int cluster, int model, int save, char directory[], int subanalysis);

int SaveSignificantEffectClusters(double critical, int X, int Y, int Z, float dx, float dy, float dz, float x0, float y0, float z0,
                                                                     struct Coordinates *CoordinateStruct, char fname[], char fnameRGB[], char fnameSignRGB[], int Marker);

int ReportClusterZ(HWND hwnd, struct Coordinates *CoordinateStruct, char directory[], char file[], int X, int Y, int Z, float z0, float dx, float dy, float dz, double critical, int MergeGroups, int control, int Use_t, double ClusteringDistance);

int PeakFocus(struct Coordinates *Co, float overlap[], int Cluster);

int WithinClusterCoordinateOverlaps(struct Coordinates *CoordinateStruct, float *overlap, float ClusteringDistance);
double WithinStudyStandardDeviation(int n1, int n2, int Use_t);

int DistanceMatrix(float x[], float y[], float z[], short int experiment[], int Ncoordinates, double DM[]);
int Distance2Matrix(float x[], float y[], float z[], short int experiment[], int Ncoordinates, double DM[]);

struct ThreeVector CentreOfCluster(struct Coordinates *Co, int cluster);

int TestCoreFocusClusteringDistance(struct Coordinates *Co, double minCD, double ClusteringDistance);

int TestProportionOfCorrectClustering(void);
int TestMinDistance(void);

///NEW CLUSTERING
int GetClusters(struct Image *img, struct Coordinates *Co, float xc[], float yc[], float zc[], int MinStudiesForInference, int renumber, int save, char directory[]);
int SaveSignificantClusterDensity2(struct Image *image, struct Coordinates *Co, double pvalue, int Nstudies, char directory[]);
int GetDensity2(struct Image *image, float x[], float y[], float z[], short int cluster[], short int experiment[], char voi[], int Nfoci, int Nexperiments, double kernelSD);
#endif
