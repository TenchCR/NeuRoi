/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(Atlas_H)
//Do Nothing
#else

#define Atlas_H
//--------------------------------------------------------------------------------------------
//                              routines for Atlas functions
//                              21th Sept 2009
//--------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>
#include "menuresources.h"
#include "loader.h"
#include "options.h"
#include "polynomial.h"

#define WMPRIOR 1
#define GMPRIOR 2
#define CSFPRIOR 3
#define NBPRIOR 4



int TemplateRegistration(HWND hwnd, struct Image *image);
int TemplateBrainstemRegistration(HWND hwnd, struct Image *image);

int Classify_WM_GM_CSF_NonParametric(HWND hwnd, struct Image *image, int ReturnProbs, int RegParameters);
int ExtractBrainByTemplateRegistrationNonParametric(HWND hwnd, struct Image *image, int RegParameters);
int CorrectInhomogeneityUsingTemplateNonParametric(HWND hwnd, struct Image *image, int classify);


#endif
