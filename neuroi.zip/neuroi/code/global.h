/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#if defined(Global_H)
//Do Nothing
#else
#define Global_H

#if defined(W32BIT)
#define _WIN32_IE 0x0300
#endif // 32bit windows

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>
#include "menuresources.h"
#include "statusbar.h"
#include "toolbar.h"
#include "loader.h"
#include "display.h"
#include "numerical.h"
#include "autoROI.h"
#include "manualROIs.h"
#include "stats.h"
#include "ROIs.h"
#include "imageprocess.h"
#include "interleave.h"
#include "tensor.h"
#include "tensorROIs.h"
#include "coregister.h"
#include "templatefunctions.h"
#include "fitT1.h"
#include "fODF.h"
#include "generatedirections.h"
#include "options.h"
#include "inhomogeneity.h"
#include "phaseunwrap.h"
#include "FFT.h"
#include "GT_tractography.h"
#include "classification.h"
#include "overlays.h"
#include "registerDWI.h"
#include "DWI_ROIsegment.h"
#include "general3paramfit.h"
#include "statsanalysis.h"
#include "OCT.h"
#include "batch.h"
#include "difference.h"
#include "CBMAN.h"
#include "localALE.h"
#include "ClusterZ.h"
#include "CoordinateDensityAnalysis.h"

#if defined (DEVELOP)
#include "mostprobpathtract.h"
#include "fitT2.h"
#include "SHdecomposition.h"
#include "lesionexp.h"
#endif


#define CLASSNAME "NeuRoiClass"                 //class name for this window

#define ID_SET_ORTHOGONAL_COORDINATES 10001     //communication from other instances


#define MAX_ZOOM 16.0                              //dont need to zoom forever!


#define X_ORIGIN    10//origin of the display screen
#define Y_ORIGIN    60

#if defined(CROSS_COMPILE)
#define REPORT_FOLDER "/home/chris/temp"
#define REPORT_FILE "/home/chris/temp/NeuROIoutput.txt"
#else
#define REPORT_FOLDER "c:\\temp"
#define REPORT_FILE "c:\\temp\\NeuROIoutput.txt"
#endif




HWND hRange;                                    //Intensity range dialog box handle
HWND hHeader;
char ExecutableDirectory[MAX_PATH];



//inputs
int WMcommandKeyFuncs(HWND hwndMain, HWND hwndStatus, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, struct Image *image);
int WMcommandFunc(HWND hwnd, WPARAM wParam, LPARAM lParam);
int ProcessWMmouseFuncs(HWND hwndMain, HWND hwndStatus, UINT msg, WPARAM wParam, LPARAM lParam, struct Picture *pict, struct Image *image);
int SendCursorPositionToEachInstance(HWND hwndMain, struct Picture *picture, struct Image *image);
int SetOrthogonalPlanes(HWND hwnd, RECT rect, struct Picture *picture, struct Image *image, LPARAM lParam);
int SetOrthogonalPlanesFromExternalCall(HWND hwnd, RECT rect, struct Picture *picture, struct Image *image, COPYDATASTRUCT *coordinates);
int IsMenuItemChecked(HWND hwnd, int ID);
int SetMenuItemState(HWND hwnd, int state);
int RemoveInput(HWND hwnd);
int EscapePressed(HWND hwnd);
int InitialisePicture(HWND hwnd, struct Image *image, struct Picture *picture);
INT_PTR CALLBACK AboutDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int EnableMainMenuItem(HWND hwnd);

//dialog boxs
INT_PTR CALLBACK HighlightDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK HeaderDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
INT_PTR CALLBACK HeaderFileEditDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

//header
int ShowHeader(struct Image *image);

//cord
double ComputeMeanCordArea(struct Image *image);
int SaveCordPhantomImage(void);


//test phantoms
int MakeSimplePhantom(void);
int MakeGaussNoisePhantom(void);
int MakeTestRGBImage(struct Image *image);
int MakeT1TestImages(char fpath[]);
int MakeT2TestImages(char fpath[]);
int ContrastTestImage(struct Image *image);
int MakePhantomCord(void);

//binary
int ApplyBinaryMaskToImage(HWND hwnd, struct Image *image, int inverse);
int ConvertToBinary(HWND hwnd, struct Image *image);
int FindBrain(HWND hwnd, unsigned char *bin, int X, int Y, int Z);
int LargestConnectedObject(HWND hwnd, unsigned char *bin, int X, int Y, int Z);

//MTR
int ComputeMTR(HWND hwnd, struct Image *image, int StandardiseScale);
int ComputeMTRfromTwoVolume(HWND hwnd, struct Image *image, int StandardiseScale);

//TEST FUNCTIONS
int InterleaveIntensityChanges(struct Image *image);
int TestPvalueOfCoordinate(void);
int TestCorrelationSampleSize(void);
int ConvertRGBtoGrey(struct Image *image);
int SaveROImeans(struct Image *MV);
#endif
//########################################################################################
