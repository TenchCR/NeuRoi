/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


#if defined(OPTIONS_H)
//Do Nothing
#else

#define OPTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <math.h>
#include <float.h>
#include <limits.h>
//#include <time.h>

struct NeuRoiOptions{
    char TemplateDir[MAX_PATH]; //where are the template images?
    int UseColourBackground;    //Use the bacground colour?
    unsigned char Red;
    unsigned char Green;        //set the background colour
    unsigned char Blue;
    float FAmin_GTmask;         //When doing graph theory tractography, what FA min determines the mask?
    int TensorDeflect_n;        //When doing tensor deflection tractography, how many operations?
    char TissueClass;           //produce a tissue class image when processing DWI
    char alignDWI;              //align the DWI images before procssing
    char SmoothDWI;             //Smooth the DWI images before processing
    char ExtractBrain;
    char standardise_scale;
};


HWND hwndOptions;
struct NeuRoiOptions gOptions;

INT_PTR CALLBACK OptionsDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
int DefaultOptions(struct NeuRoiOptions *opt);
int SaveOptions(char ExecutableDirectory[], struct NeuRoiOptions *opt);
int LoadOptions(char ExecutableDirectory[], struct NeuRoiOptions *opt);

#endif
