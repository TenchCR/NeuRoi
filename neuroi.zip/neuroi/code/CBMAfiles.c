/*
Copyright 2009 - 2021 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

//=======================================================================================================
//FUNCTIONS FOR DEALING WITH CBMA FILES
//=======================================================================================================
#include <stdio.h>
#include <ctype.h>
#include "talairachfunctions.h"
#include "numerical.h"
#include "CBMAfiles.h"
//======================================================================================================
//load an set of experiments
//file format is described in GingerALE documentation:
/*
//USE
//FLIP TO INDICATE IF x SHOULD BE FLIPED
//MNI TO INDICATE THE MNI COORDINATE SYSTEM
//CONDITIONID TO INDICATE THE SUBJECTS; HC, PATIENT....
//CONTRASTID TO INDICATE THE CONTRAST USED
//DESCRIPTION CAN BE FREE TEXT
// Subjects=n
x1 y1 z1
x2 y2 z2
...
xi yi zi

// Subjects=n
x1 y1 z1
x2 y2 z2
...
xj yj zj
*/
//There should be a space between experiments
//======================================================================================================
#define ERROR_FILE_LENGTH 10000
int LoadExperimentsCOORDINATES(HWND hwnd, struct Coordinates *Co, int X, int Y, int Z, float dx, float dy, float dz,
                               float x0, float y0, float z0)
{

	FILE *fp;
	int result=0;
	int subjects, controls;
	int experiment, foci;
	int i,n;
	int TotalFoci, Nexperiments;
	int line_number;
	int MNI, flip;
	int columns=3;//by default assume 3 columns unless the file contains the term //4COLUMN
	int ScoreType, dof;
	OPENFILENAME fnamedlg;
	char txt[CBMA_TEXT_LENGTH], *pc=NULL;
	char FileErrors[ERROR_FILE_LENGTH];
	char fname[MAX_PATH];
	float x,y,z,Zsc;


//GET THE FILENAME FOR THE COORDINATES
	fname[0]='\0';
	memset(&fnamedlg,0,sizeof(OPENFILENAME));
	fnamedlg.lStructSize=sizeof(OPENFILENAME);
	fnamedlg.hwndOwner=hwnd;
	fnamedlg.lpstrFilter="Foci Files\0*.txt\0\0";
	fnamedlg.lpstrCustomFilter=NULL;
	fnamedlg.nFilterIndex=1;
	fnamedlg.lpstrFile=fname;
	fnamedlg.nMaxFile=MAX_PATH;
	fnamedlg.lpstrFileTitle=NULL;
	//fnamedlg.lpstrInitialDir="./";
	fnamedlg.lpstrInitialDir=NULL;
	fnamedlg.lpstrDefExt="txt";
	fnamedlg.Flags=OFN_ENABLESIZING;

	if (!GetOpenFileName(&fnamedlg))
		goto END;



	if (!(fp=fopen(fname,"r")))
		goto END;


//COUNT THE NUMBER OF EXPERIMENTS AND FOCI
	Nexperiments=TotalFoci=0;
	line_number=0;
	FileErrors[0]='\0';
	while (!feof(fp))
	{
		if (fgetl(fp, txt, 1024))
		{
			//MessageBox(NULL,txt,"",MB_OK);
			line_number++;
			if (strstr(txt,"// "))
			{
				if ((strlen(FileErrors) + strlen("Error: space after // ")) < ERROR_FILE_LENGTH)
					sprintf(FileErrors,"Error: space after //\n");
				if ((strlen(FileErrors) + strlen(txt)) < ERROR_FILE_LENGTH)
					sprintf(FileErrors,"%s\n%d) %s",FileErrors,line_number,txt);
			}
			for (i=0; i<strlen(txt); i++)
				txt[i]=toupper(txt[i]);
			if (strstr(txt,"4COLUMN"))
				columns=4;
			if (strstr(txt,"//SUBJECTS="))
			{
				Nexperiments++;
				pc=strstr(txt,"=");
				subjects=atoi(&pc[1]);
				do
				{
					x=y=z=0;
					if (columns==3)
					{
						if ((n=fscanf(fp,"%f %f %f",&x,&y,&z))==columns)
							TotalFoci++;
					}
					else  if ((n=fscanf(fp,"%f %f %f %f",&x,&y,&z,&Zsc))==columns)
						TotalFoci++;

					if ( (fabs(x)>80.0) || (fabs(y)>110.0) || (fabs(z)>80.0) )
					{
						if ((strlen(FileErrors) + strlen("Error: Strange coordinate ")) < ERROR_FILE_LENGTH)
							sprintf(FileErrors,"Error: Strange coordinate\n");
						sprintf(txt,"%d) %f %f %f",line_number,x,y,z);
						if ((strlen(FileErrors) + strlen(txt)) < ERROR_FILE_LENGTH)
							sprintf(FileErrors,"%s\n%s",FileErrors,txt);
					}
				}
				while ((n==columns) && (!feof(fp)));
			}
		}
	}
	fclose(fp);


//MAKE THE DATA STRUCTURE FOR THE COORDINATES AND Z SCORES IF REQUIRED
	if (!MakeStructCoordinates(Co, TotalFoci, Nexperiments))
		goto END;
	if (columns==4)
		(*Co).ZscoreUsed=1;//This file includes the Zscore
	sprintf((*Co).coordinate_file_name,"%s",fname);


//LOAD THE COORDINATE DATA
	if (!(fp=fopen(fname,"r")))
		goto END;

	line_number=experiment=foci=0;
	while ((!feof(fp)) && (experiment<Nexperiments) )
	{

		//GET THE HEADER INFORMATION; FLIP, MNI, SUBJECTS, CONTRASTID, CONDITIONID, DESCRIPTION, STUDYID
		flip = 0;//assume noflip
		MNI = 0;//assume Talairach
		subjects = 0;
		sprintf((*Co).ID[experiment].txt,"%d",experiment);//DEFAULT IN CASE OF NO STUDYID
		dof=0;
		ScoreType=ZTYPE;//default to Zscore
		do
		{

			do
			{
				if ((!feof(fp)) && fgetl(fp, txt, 1024))
				{
					line_number++;
					for (i=0; i<strlen(txt); i++)
						txt[i]=toupper(txt[i]);
				}
			}
			while ((!(strstr(txt,"//MNI") || strstr(txt,"//FLIPX") || strstr(txt,"//SUBJECTS=")  || strstr(txt,"//CONTROLS=") || strstr(txt,"//STUDYID")  ||
			          strstr(txt,"//PVALUE") || strstr(txt,"//TDOF=") || strstr(txt,"//CENSOR=") || strstr(txt,"//COVARIATE=") || strstr(txt,"//CONTRASTID") ||
			          strstr(txt,"//CONDITIONID") || strstr(txt,"//DESCRIPTION") || strstr(txt,"//UNCORRECTED") || strstr(txt,"//SUBANALYSIS") ||
			          strstr(txt,"//WB") || strstr(txt,"//VOI") ||strstr(txt,"//CORRECTED") || strstr(txt,"//PET") || strstr(txt,"//FMRI") || strstr(txt,"//STRUCTURAL") ||
			          strstr(txt,"//SPECT"))) && (!feof(fp)));


			if (strstr(txt,"MNI"))
				MNI=1;                            ///MNI OR TALAIRACH

			if (strstr(txt,"FLIPX"))
				flip=1;                                                ///FLIP THE X COORDINATE

			if (strstr(txt,"STUDYID"))                                                      ///STUDYID
			{
				if (strlen(&txt[9])>256)
					txt[9+256] = '\0';
				sprintf((*Co).ID[experiment].txt,"%s",&txt[9]);
			}

			if (strstr(txt,"//CORRECTED"))
				(*Co).corrected[experiment] = CORRECTED;        ///CORRECTED STATISTICS

			if (strstr(txt,"//PET"))
				(*Co).modality[experiment] = PET_STUDY;
			if (strstr(txt,"//FMRI"))
				(*Co).modality[experiment] = FMRI_STUDY;
			if (strstr(txt,"//STRUCTURAL"))
				(*Co).modality[experiment] = STRUCTURAL_STUDY; ///MODALITY OF STUDY
			if (strstr(txt,"//SPECT"))
				(*Co).modality[experiment] = SPECT_STUDY;

			if (strstr(txt,"//SUBANALYSIS"))
				(*Co).subanalysis[experiment]=1;                ///FOR SUBANALYSIS

			if (strstr(txt,"//VOI"))
				(*Co).VOI[experiment]=1;                                ///for whole brain studies

			if (strstr(txt,"CONTRASTID"))                                                   ///BOOKKEEPING
			{
				if (strlen(&txt[12])>256)
					txt[12+256] = '\0';
				sprintf((*Co).CTRST[experiment].txt,"%s",&txt[12]);
			}

			if (strstr(txt,"CONDITIONID"))                                                  ///BOOKKEEPING
			{
				if (strlen(&txt[13])>256)
					txt[13+256] = '\0';
				sprintf((*Co).CND[experiment].txt,"%s",&txt[13]);
			}

			if (strstr(txt,"DESCRIPTION"))                                                  ///STUDY DESCRIPTION
			{
				pc=RemoveCommas(txt);
				if (strlen(&pc[13])>256)
					pc[13+256] = '\0';
				sprintf((*Co).DESC[experiment].txt,"%s",&pc[13]);
			}

			if (strstr(txt,"COVARIATE="))                                                   ///COVARIATE
			{
				pc=strstr(txt,"=");
				(*Co).covariate[experiment]=fabs(atof(&pc[1]));
			}

			if (strstr(txt,"CENSOR="))                                                      ///CENSOR VALUE
			{
				pc=strstr(txt,"=");
				(*Co).Zcensor[experiment]=fabs(atof(&pc[1]));
			}

			if (strstr(txt,"SUBJECTS="))                                                    ///SUBJECT NUMBERS
			{
				pc=strstr(txt,"=");
				subjects=atoi(&pc[1]);
				(*Co).SubjectsInExp[experiment]=subjects;
				if (subjects<=0)
				{
					sprintf(txt,"Apparent error on line %d: \n experiment = %s %f %f %f.\n The number of subjects (%d) must be >0.",
					        line_number,(*Co).ID[experiment].txt, x,y,z, dof);
					MessageBox(NULL,txt,"",MB_OK);
					FreeCoordinates(Co);
					goto END;
				}
			}

			if (strstr(txt,"CONTROLS="))                                                    ///CONTROL GROUP NUMBERS
			{
				pc=strstr(txt,"=");
				controls=atoi(&pc[1]);
				(*Co).ControlsInExp[experiment]=controls;
				if (controls<0)
				{
					sprintf(txt,"Apparent error on line %d: \n experiment = %s %f %f %f.\n The number of controls (%d) must be >=0.",
					        line_number, (*Co).ID[experiment].txt, x,y,z, dof);
					MessageBox(NULL,txt,"",MB_OK);
					FreeCoordinates(Co);
					goto END;
				}
			}



			if (columns==4)
			{
				if (strstr(txt,"TDOF="))
				{
					ScoreType=TTYPE;
					pc=strstr(txt,"=");
					dof=atoi(&pc[1]);
					if (dof<=0)
					{
						sprintf(txt,"Apparent error on line %d: \n experiment = %s %f %f %f.\n The degrees of freedom (%d) must be >0.",
						        line_number,(*Co).ID[experiment].txt, x,y,z, dof);
						MessageBox(NULL,txt,"",MB_OK);
						FreeCoordinates(Co);
						goto END;
					}
				}
				if (strstr(txt,"PVALUE"))
				{
					ScoreType=PTYPE;
				}
			}

		}
		while ((!subjects) && (!feof(fp)));




		// (*Co).SubjectsInExp[experiment]=subjects;
		do
		{
			x=y=z=Zsc=0.0;
			if (columns==3)
				n=fscanf(fp,"%f %f %f",&x,&y,&z);
			else
				n=fscanf(fp,"%f %f %f %f",&x,&y,&z,&Zsc);

			//sprintf(txt,"line:%d n=%d foci=%d x=%f y=%f z=%f",line_number,n,foci,x,y,z);
			//MessageBox(NULL,txt,"",MB_OK);

			line_number++;
			if ((n>0) && (n!=columns))
			{
				sprintf(txt,"Apparent error on line %d: \n Number of columns seems wrong. \n Experiment = %s %f %f %f",line_number, (*Co).ID[experiment].txt, x,y,z);
				MessageBox(NULL,txt,"",MB_OK);
				FreeCoordinates(Co);
				goto END;
			}

			//convert to Z statistic if required
			if ((columns==4) && ((ScoreType==TTYPE) || (ScoreType==PTYPE)))
			{
				if (ScoreType==PTYPE)
				{
					///A p value <0 means 'deactivation'
					if (Zsc<0.0)
						Zsc = Zvalue(fabs(Zsc));//this is a deactivation
					else
						Zsc = -Zvalue(fabs(Zsc));//this is an activation
				}
				else
					Zsc = ZscoreFromT(Zsc, dof);
			}


			if ((n==columns) && (foci<TotalFoci))
			{
				if (flip)
					x *= -1.0;//flip the x coordinates if required
				if (MNI)
					MNI2TAL(&x, &y, &z);//CONVERT EVERYTHING TO TALAIRACH COORDINATES

				(*Co).experiment[foci] =   experiment;
				(*Co).subjects[foci] =        subjects;
				(*Co).voxel[foci] =            FociVoxelALE(x, y, z, X, Y, Z, dx, dy, dz, x0, y0, z0);
				(*Co).x[foci] =                   x;
				(*Co).y[foci] =                   y;
				(*Co).z[foci] =                   z;
				(*Co).Zsc[foci] =               Zsc;
				(*Co).p[foci] =                   1.0;//initiall p-value
				(*Co).cluster[foci]=           0;
				(*Co).TalLabel[foci] =      0;

				if ( (fabs(x)>80.0) || (fabs(y)>110.0) || (fabs(z)>80.0) )
				{
					sprintf(txt,"?Coordinate error? on line %d: \n #loaded=%d experiment = %s %f %f %f",line_number, n, (*Co).ID[experiment].txt, x,y,z);
					MessageBox(NULL,txt,"",MB_OK);
				}

				if ( (fabs(Zsc)>8.0) && (*Co).ZscoreUsed )
				{
					sprintf(txt,"%d) In study %s \nHigh magnitude Zscore. Are you sure this is not t? %f",line_number,(*Co).ID[experiment].txt,Zsc);
					if ((strlen(FileErrors) + strlen(txt)) < ERROR_FILE_LENGTH)
						sprintf(FileErrors,"%s\n%s",FileErrors,txt);
				}
				if ( (fabs(Zsc)<1.0) && (*Co).ZscoreUsed )
				{
					sprintf(txt,"%d) In study %s \nLow magnitude Zscore. Are you sure this is correct? %f",line_number,(*Co).ID[experiment].txt,Zsc);
					if ((strlen(FileErrors) + strlen(txt)) < ERROR_FILE_LENGTH)
						sprintf(FileErrors,"%s\n%s",FileErrors,txt);
				}

				foci++;
			}
		}
		while ((n==columns) && (!feof(fp)));
		experiment++;

	}
	fclose(fp);


	///CONTRAST STUDY ERROR
	if (!IsContrastStudy(Co))
	{
		n=0;
		for (experiment=0; experiment<(*Co).Nexperiments; experiment++)
		{
			if ((*Co).ControlsInExp[experiment]>0)
				n=1;
		}
		if (n)
		{
			sprintf(txt,"\nError in control numbers. Some are zero, and some >0.\nIt is not recommended that you include studies with controls along with single group studies\n");
			if ((strlen(FileErrors) + strlen(txt)) < ERROR_FILE_LENGTH)
				sprintf(FileErrors,"%s\n%s",FileErrors,txt);
		}
	}




	///SAVE PROCESSED COORDINATES FILE
	i = DirectoryFileDivide(fname);
	fname[i] = '\0';
	sprintf(fname,"%s\\ProcessedCoordinates.txt",fname);
	SaveExperimentsALE(Co, fname, "Processed coordinates", 1.0,0);

	fname[i] = '\0';
	sprintf(fname,"%s\\Study table.csv",fname);
	SaveStudyTable(Co, fname);


	///SAVE POSSIBLE ERRORS IN THE COORDINATE FILE
	fname[i] = '\0';
	sprintf(fname,"%s\\FileErrors.txt",fname);
	if ((fp=fopen(fname,"w")))
	{
		if (strlen(FileErrors))
		{
			sprintf(txt,"An ErrorFile.txt has been written.\nIt lists possible issues with the coordinate file.\nThese include a space between the // and a keyword, or extreme coordinates");
			MessageBox(NULL,txt,"",MB_OK|MB_ICONWARNING);
			fprintf(fp,"This file points to potential errors. There should be no space between // and any key word\n");
			fprintf(fp,"%s",FileErrors);
			fprintf(fp,"\n\n\nStudies=%d\nCoordinates=%d\n",(*Co).Nexperiments,(*Co).TotalFoci);
		}
		fclose(fp);
	}




	result=1;
END:



	return result;
}


//======================================================================================================
//make a struct Coordinates
//======================================================================================================
int MakeStructCoordinates(struct Coordinates *Co, int TotalFoci, int Nexperiments)
{

	int result=0;

	if ((*Co).TotalFoci)
		FreeCoordinates(Co);

	memset(Co,0,sizeof(struct Coordinates));

	if (!((*Co).x=(float *)malloc(TotalFoci*sizeof(float))))
		goto END;
	if (!((*Co).y=(float *)malloc(TotalFoci*sizeof(float))))
		goto END;
	if (!((*Co).z=(float *)malloc(TotalFoci*sizeof(float))))
		goto END;
	if (!((*Co).Zsc=(float *)malloc(TotalFoci*sizeof(float))))
		goto END;
	if (!((*Co).Zcensor=(float *)calloc(Nexperiments,sizeof(float))))
		goto END;
	if (!((*Co).covariate=(float *)calloc(Nexperiments,sizeof(float))))
		goto END;
	if (!((*Co).p=(double *)malloc(TotalFoci*sizeof(double))))
		goto END;
	if (!((*Co).subjects=(short int *)calloc(TotalFoci,sizeof(short int))))
		goto END;
	if (!((*Co).voxel=(int *)calloc(TotalFoci,sizeof(int))))
		goto END;
	if (!((*Co).experiment=(short int *)calloc(TotalFoci,sizeof(short int))))
		goto END;
	if (!((*Co).cluster=(short int *)calloc(TotalFoci,sizeof(short int))))
		goto END;
	if (!((*Co).TalLabel=(short int *)calloc(TotalFoci,sizeof(short int))))
		goto END;
	if (!((*Co).SubjectsInExp=(short int *)calloc(Nexperiments,sizeof(short int))))
		goto END;
	if (!((*Co).ControlsInExp=(short int *)calloc(Nexperiments,sizeof(short int))))
		goto END;
	if (!((*Co).corrected=(char *)calloc(Nexperiments,sizeof(char))))
		goto END;
	if (!((*Co).modality=(char *)calloc(Nexperiments,sizeof(char))))
		goto END;
	if (!((*Co).subanalysis=(char *)calloc(Nexperiments,sizeof(char))))
		goto END;
	if (!((*Co).VOI=(char *)calloc(Nexperiments,sizeof(char))))
		goto END;
	if (!((*Co).ID=(struct TextLabel *)malloc(Nexperiments*sizeof(struct TextLabel))))
		goto END;
	if (!((*Co).CTRST=(struct TextLabel *)malloc(Nexperiments*sizeof(struct TextLabel))))
		goto END;
	if (!((*Co).CND=(struct TextLabel *)malloc(Nexperiments*sizeof(struct TextLabel))))
		goto END;
	if (!((*Co).DESC=(struct TextLabel *)malloc(Nexperiments*sizeof(struct TextLabel))))
		goto END;


	memset((*Co).ID,0,Nexperiments*sizeof(struct TextLabel));
	memset((*Co).CTRST,0,Nexperiments*sizeof(struct TextLabel));
	memset((*Co).CND,0,Nexperiments*sizeof(struct TextLabel));
	memset((*Co).DESC,0,Nexperiments*sizeof(struct TextLabel));

	(*Co).TotalFoci=TotalFoci;
	(*Co).Nexperiments=Nexperiments;

	result=1;
END:
	return result;
}



//======================================================================================================
//free the memory in the ALE structure
//======================================================================================================
int FreeCoordinates(struct Coordinates *Co)
{
	if ((*Co).TalLabel)
		free((*Co).TalLabel);
	if ((*Co).cluster)
		free((*Co).cluster);
	if ((*Co).experiment)
		free((*Co).experiment);
	if ((*Co).subjects)
		free((*Co).subjects);
	if ((*Co).voxel)
		free((*Co).voxel);
	if ((*Co).x)
		free((*Co).x);
	if ((*Co).y)
		free((*Co).y);
	if ((*Co).z)
		free((*Co).z);
	if ((*Co).Zsc)
		free((*Co).Zsc);
	if ((*Co).Zcensor)
		free((*Co).Zcensor);
	if ((*Co).covariate)
		free((*Co).covariate);
	if ((*Co).SubjectsInExp)
		free((*Co).SubjectsInExp);
	if ((*Co).ControlsInExp)
		free((*Co).ControlsInExp);
	if ((*Co).corrected)
		free((*Co).corrected);
	if ((*Co).modality)
		free((*Co).modality);
	if ((*Co).subanalysis)
		free((*Co).subanalysis);
	if ((*Co).VOI)
		free((*Co).VOI);
	if ((*Co).p)
		free((*Co).p);
	if ((*Co).ID)
		free((*Co).ID);
	if ((*Co).CTRST)
		free((*Co).CTRST);
	if ((*Co).CND)
		free((*Co).CND);
	if ((*Co).DESC)
		free((*Co).DESC);
	memset(Co,0,sizeof(struct Coordinates));
	return 1;
}



//======================================================================================================
//copy A to B
//======================================================================================================
int CopyCoordinates(struct Coordinates *A, struct Coordinates *B)
{
	int foci;
	int iExp;

	if ((*B).TotalFoci)
		FreeCoordinates(B);

	if (!MakeStructCoordinates(B,(*A).TotalFoci, (*A).Nexperiments))
		return 0;

	sprintf((*B).coordinate_file_name,"%s",(*A).coordinate_file_name);
	(*B).TotalFoci=(*A).TotalFoci;
	(*B).Nexperiments=(*A).Nexperiments;
	(*B).ZscoreUsed=(*A).ZscoreUsed;

	for (foci=0; foci<(*A).TotalFoci; foci++)
	{
		CopyCoordinatesentry(A, foci, B, foci);
	}


	//THIS IS NEEDED BECAUSE SOME EXPERIMENTS DONT HAVE FOCI
	//SO COPYING USING THE ABOVE LOOP WONT WORK FOR THEM
	for (iExp=0; iExp<(*A).Nexperiments; iExp++)
	{
		(*B).Zcensor[iExp]=(*A).Zcensor[iExp];
		(*B).covariate[iExp]=(*A).covariate[iExp];
		(*B).SubjectsInExp[iExp]=(*A).SubjectsInExp[iExp];
		(*B).ControlsInExp[iExp]=(*A).ControlsInExp[iExp];
		(*B).corrected[iExp]=(*A).corrected[iExp];
		(*B).modality[iExp]=(*A).modality[iExp];
		(*B).subanalysis[iExp]=(*A).subanalysis[iExp];
		(*B).VOI[iExp]=(*A).VOI[iExp];
		sprintf((*B).ID[iExp].txt,"%s",(*A).ID[iExp].txt);
		sprintf((*B).CTRST[iExp].txt,"%s",(*A).CTRST[iExp].txt);
		sprintf((*B).CND[iExp].txt,"%s",(*A).CND[iExp].txt);
		sprintf((*B).DESC[iExp].txt,"%s",(*A).DESC[iExp].txt);
		//MessageBox(NULL, (*B).ID[iExp].txt,"",MB_OK);
	}

	return 1;
}
//======================================================================================================
//======================================================================================================
//======================================================================================================
//copy a single entry [i] in one struct Coordinates to another single entry [j] in another struct Coordinates
//======================================================================================================
//======================================================================================================
//======================================================================================================
int CopyCoordinatesentry(struct Coordinates *A, int i, struct Coordinates *B, int j)
{

	//the destination experiment in B is the same as the source experiment ((*A).experiment[i])
	CopyCoordinatesentryExt(A, i, (*A).experiment[i], B, j, (*A).experiment[i]);

	return 1;
}


//======================================================================================================
//======================================================================================================
//======================================================================================================
//copy a single entry [i] in one struct Coordinates to another single entry [j] in another struct Coordinates
///COPY A TO B
//======================================================================================================
//======================================================================================================
//======================================================================================================
int CopyCoordinatesentryExt(struct Coordinates *A, int FocusA, int StudyA, struct Coordinates *B, int FocusB, int StudyB)
{

	(*B).x[FocusB]=(*A).x[FocusA];
	(*B).y[FocusB]=(*A).y[FocusA];
	(*B).z[FocusB]=(*A).z[FocusA];
	(*B).Zsc[FocusB]=(*A).Zsc[FocusA];

	(*B).p[FocusB]=(*A).p[FocusA];

	(*B).subjects[FocusB]=(*A).subjects[FocusA];
	(*B).voxel[FocusB]=(*A).voxel[FocusA];
	(*B).experiment[FocusB]=StudyB;
	(*B).cluster[FocusB]=(*A).cluster[FocusA];
	(*B).TalLabel[FocusB]=(*A).TalLabel[FocusA];


	(*B).Zcensor[StudyB]=(*A).Zcensor[StudyA];
	(*B).covariate[StudyB]=(*A).covariate[StudyA];
	(*B).SubjectsInExp[StudyB]=(*A).SubjectsInExp[StudyA];
	(*B).ControlsInExp[StudyB]=(*A).ControlsInExp[StudyA];
	(*B).corrected[StudyB]=(*A).corrected[StudyA];
	(*B).modality[StudyB]=(*A).modality[StudyA];
	(*B).subanalysis[StudyB]=(*A).subanalysis[StudyA];
	(*B).VOI[StudyB]=(*A).VOI[StudyA];

	sprintf((*B).ID[StudyB].txt,"%s",(*A).ID[StudyA].txt);
	sprintf((*B).CTRST[StudyB].txt,"%s",(*A).CTRST[StudyA].txt);
	sprintf((*B).CND[StudyB].txt,"%s",(*A).CND[StudyA].txt);
	sprintf((*B).DESC[StudyB].txt,"%s",(*A).DESC[StudyA].txt);

	return 1;
}
//======================================================================================================
//REMOVE THE ',' FROM TEXT AND REPLACE WITH ' '
//======================================================================================================
char *RemoveCommas(char text[])
{
	int len=strlen(text);
	int i;

	for (i=0; i<len; i++)
	{
		if (text[i]==',')
			text[i]=' ';
	}

	return text;
}


//======================================================================================================
//READ A LINE OF TEXT FROM A FILE
//======================================================================================================
int fgetl(FILE *fp, char txt[], int L)
{
	int n=0;
	int c;

	txt[0]='\0';

	if (feof(fp))
		return 0;

	do
	{
		if ( (c = getc(fp)) != EOF )
		{
			if (c!='\n')
			{
				txt[n] = (char)c;
				n++;
			}
		}
	}
	while((n<L) && (!feof(fp)) && (c != '\n'));

	if (n<L)
		txt[n] = '\0';
	else
		txt[L-1] = '\0';

//MessageBox(NULL,txt,"",MB_OK);

	return n;
}

//======================================================================================================
//save files that should work with SDM
//======================================================================================================
int SaveSDMfiles(struct Coordinates *Co, float x0, float y0, float z0, char directory[], char SaveDir[])
{
	int result=0;
	int iExp,foci;
	int x,y,z;
	int dof;
	char NewDir[MAX_PATH];
	char fname[MAX_PATH];
	char name[MAX_PATH];
	FILE *fp;

	CensorLevels(Co);


	sprintf(NewDir,"%s//%s",directory,SaveDir);
	if ((!CreateDirectory(NewDir,NULL)) && (GetLastError()!=ERROR_ALREADY_EXISTS))
		goto END;

	sprintf(fname,"%s//sdm_table.txt",NewDir);
	if (!(fp=fopen(fname,"w")))
		goto END;
	fprintf(fp,"study\tn1\tn2\tt_thr\n");
	fclose(fp);



	for (iExp=0; iExp<(*Co).Nexperiments; iExp++)
	{
		NoSpaces((*Co).ID[iExp].txt,name);
		sprintf(fname,"%s//%s.other_tal.txt",NewDir,name);
		if ((fp=fopen(fname,"w")))
		{
			//MessageBox(NULL,fname,"",MB_OK);
			for (foci=0; foci<(*Co).TotalFoci; foci++)
			{
				if ((*Co).experiment[foci]==iExp)
				{
					x=(int)((*Co).x[foci]+x0+0.5) - x0;
					y=(int)((*Co).y[foci]+y0+0.5) - y0;
					z=(int)((*Co).z[foci]+z0+0.5) - z0;

					fprintf(fp,"%d,%d,%d",x,y,z);
					if (fabs((*Co).Zsc[foci])==1.0)
					{
						if ((*Co).Zsc[foci]>0.0)
							fprintf(fp,",p\n");
						else
							fprintf(fp,",n\n");
					}
					else
					{
						if ((*Co).ControlsInExp[(*Co).experiment[foci]]>0)
							dof=(*Co).SubjectsInExp[(*Co).experiment[foci]] + (*Co).ControlsInExp[(*Co).experiment[foci]]-2;
						else
							dof=(*Co).SubjectsInExp[(*Co).experiment[foci]]-1;
						fprintf(fp,",%f\n",TstatisticFromZscore((*Co).Zsc[foci], dof));
					}
				}
			}

			fclose(fp);
		}
		else
		{
			MessageBox(NULL,fname,"Cant open file",MB_OK|MB_ICONWARNING);
		}
		sprintf(fname,"%s//sdm_table.txt",NewDir);
		if ((fp=fopen(fname,"a")))
		{
			fprintf(fp,"%s\t%d\t%d\t%f\n",name,(*Co).SubjectsInExp[iExp],(*Co).ControlsInExp[iExp], (*Co).Zcensor[iExp]);
			fclose(fp);
		}
	}

	result=1;
END:

	return result;
}

//======================================================================================================
//save files that should work with SDM
//======================================================================================================
int SaveMKDAfiles(struct Coordinates *Co, float x0, float y0, float z0, char directory[], char SaveDir[])
{
	int result=0;
	int iExp,foci;
	int x,y,z;
	char NewDir[MAX_PATH];
	char fname[MAX_PATH];
	char name[MAX_PATH];
	FILE *fp;

	sprintf(NewDir,"%s//%s",directory,SaveDir);
	if ((!CreateDirectory(NewDir,NULL)) && (GetLastError()!=ERROR_ALREADY_EXISTS))
		goto END;

	sprintf(fname,"%s//MKDA_table.txt",NewDir);
	if (!(fp=fopen(fname,"w")))
		goto END;
	fprintf(fp,"7\n");
	fprintf(fp,"X\tY\tZ\tStudy\tContrast\tCoordSys N\n");


	for (iExp=0; iExp<(*Co).Nexperiments; iExp++)
	{

		NoSpaces((*Co).ID[iExp].txt,name);

		for (foci=0; foci<(*Co).TotalFoci; foci++)
		{
			if ((*Co).experiment[foci]==iExp)
			{
				x=(int)((*Co).x[foci]+x0+0.5) - x0;
				y=(int)((*Co).y[foci]+y0+0.5) - y0;
				z=(int)((*Co).z[foci]+z0+0.5) - z0;

				fprintf(fp,"%d\t%d\t%d\t%s\t%d\tT88\t%d\n",x,y,z,name,iExp, (*Co).SubjectsInExp[iExp]);

			}
		}

	}

	result=1;
END:
	if (fp)
		fclose(fp);

	return result;
}
//======================================================================================================
//Save Activation file
//TempImageName is the filename of the template image used to define the null
//fixed 13/8/2015 to deal with experiments with no coordinates correctly
//======================================================================================================
int SaveExperimentsALE(struct Coordinates *Co, char fname[], char TempImageName[], double critical, int FullReport)
{

	int experiment;
	int foci;
	int result=0;
	FILE *fp;
	char talname[MAX_PATH];
	char *labels=NULL;
	char *b=NULL;
	int Nentries,Nl;
	struct Image Tal;


	memset(&Tal,0,sizeof(struct Image));
	if (FullReport)
	{
		//LOAD THE TALAIRACH DATA
		sprintf(talname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
		if (!LoadFromFileName(NULL, talname, &Tal, 0))
			goto END;
		labels=LoadTalairachLabels(&Nl);
		if (Nl<=0)
			goto END;
		Nentries=BiggestTalairachLabel(labels, Nl);
		RemoveNonGM(&Tal, labels, Nl,Nentries);
	}


	if (!(fp=fopen(fname,"w")))
		goto END;

	if ((*Co).ZscoreUsed)
		fprintf(fp,"//4COLUMN\n");

	fprintf(fp,"//Reference=Talairach\n");

	fprintf(fp,"//%s\n",TempImageName);

	if (FullReport)
		fprintf(fp,"//p values for significance <=%f\n",critical);


	for (experiment=0; experiment<(*Co).Nexperiments; experiment++)
	{
		fprintf(fp,"//STUDYID %s\n",(*Co).ID[experiment].txt);
		if ((*Co).corrected[experiment])
			fprintf(fp,"//CORRECTED\n");
		else
			fprintf(fp,"//UNCORRECTED\n");
		switch((*Co).modality[experiment])
		{
		case PET_STUDY:
			fprintf(fp,"//PET\n");
			break;
		case FMRI_STUDY:
			fprintf(fp,"//FMRI\n");
			break;
		case STRUCTURAL_STUDY:
			fprintf(fp,"//STRUCTURAL\n");
			break;
		case SPECT_STUDY:
			fprintf(fp,"//SPECT\n");
			break;
		}
		if ((*Co).subanalysis[experiment])
			fprintf(fp,"//SUBANALYSIS\n");
		if ((*Co).VOI[experiment])
			fprintf(fp,"//VOI\n");
		else
			fprintf(fp,"//WB\n");

		fprintf(fp,"//CENSOR=%f\n",(*Co).Zcensor[experiment]);
		fprintf(fp,"//COVARIATE=%f\n",(*Co).covariate[experiment]);
		fprintf(fp,"//DESCRIPTION %s\n",(*Co).DESC[experiment].txt);
		fprintf(fp,"//CONDITIONID %s\n",(*Co).CND[experiment].txt);
		fprintf(fp,"//CONTRASTID %s\n",(*Co).CTRST[experiment].txt);
		fprintf(fp,"//controls=%d\n",(*Co).ControlsInExp[experiment]);
		fprintf(fp,"//subjects=%d\n",(*Co).SubjectsInExp[experiment]);
		for (foci=0; foci<(*Co).TotalFoci; foci++)
		{
			if ((*Co).experiment[foci]==experiment)
			{
				if (!FullReport)
					fprintf(fp,"%f %f %f ",(*Co).x[foci],(*Co).y[foci],(*Co).z[foci]);
				else
					fprintf(fp,"%d) %f %f %f ",foci,(*Co).x[foci],(*Co).y[foci],(*Co).z[foci]);
				if ((*Co).ZscoreUsed)
					fprintf(fp,"%f ",(*Co).Zsc[foci]);

				if (!FullReport)
					fprintf(fp,"\n");
				else
				{
					if (labels && Tal.img)
					{
						b=FindEntryInTalairachLabels(labels, Nl, (*Co).TalLabel[foci]);
						fprintf(fp,"pvalue=%f cluster=%d %s\n",(*Co).p[foci],(*Co).cluster[foci],b);
					}
				}
			}
		}
		fprintf(fp,"\n");
	}

	fclose(fp);

	result = 1;
END:
	if (labels)
		free(labels);
	ReleaseImage(&Tal);

	return result;
}


//================================================================================================
//================================================================================================
//================================================================================================
//APPEND AN ALE
//append ale2 onto ale1
/*

struct Coordinates{
   char fname[MAX_PATH];
   char Zscore;//1 if Z scores are included, otherwise 0
   int Nexperiments;
   int TotalFoci;
   short int *experiment;//starts at 0 [0...TotalFoci]
   short int *subjects;//[0...TotalFoci]
   int *voxel;
   short int *cluster;//which cluster does this foci contribute to
   short int *TalLabel;//where is it in the Talairach atlas (GM)
   struct TextLabel *ID;//this is a study identifier
   struct TextLabel *CTRST;//contrast identifier
   struct TextLabel *CND;//condition identifier
   struct TextLabel *DESC;//study description
   short int *SubjectsInExp;//there are Nexperiments elements in this array
   short int *ControlsInExp;//there are Nexperiments elements in this array
   char *corrected;//did the study use statistical correction for multiple comparisons (0=No, 1=Yes)
   char *modality;//was it fMRI, PET, or structural?
   double *p;
   float *x;//
   float *y;//Talairach coordinates; transformed on entry
   float *z;//
   float *Zsc;//The Z score at each foci
   float *Zcensor;//the ABSOLUTE Z value used for censoring
};
*/
//================================================================================================
//================================================================================================
//================================================================================================
int AppendCoordinates(struct Coordinates *Co1, struct Coordinates *Co2)
{
	struct Coordinates aleapp;
	int result=0;
	int foci1,foci2;
	int study;
	int Nexp1,Nexp2;
	int foci;

	foci1=(*Co1).TotalFoci;
	foci2=(*Co2).TotalFoci;
	Nexp1=(*Co1).Nexperiments;
	Nexp2=(*Co2).Nexperiments;


	memset(&aleapp,0,sizeof(struct Coordinates));

	if ((*Co1).ZscoreUsed != (*Co2).ZscoreUsed)
	{
		(*Co1).ZscoreUsed=0;
	}

	if (!MakeStructCoordinates(&aleapp, foci1 + foci2, Nexp1 + Nexp2))
		goto END;

	aleapp.ZscoreUsed=(*Co1).ZscoreUsed;

	sprintf(aleapp.coordinate_file_name,"%s",(*Co1).coordinate_file_name);
	aleapp.TotalFoci=0;
	for (foci=0; foci<foci1; foci++)
	{
		aleapp.x[aleapp.TotalFoci]=(*Co1).x[foci];
		aleapp.y[aleapp.TotalFoci]=(*Co1).y[foci];
		aleapp.z[aleapp.TotalFoci]=(*Co1).z[foci];
		aleapp.Zsc[aleapp.TotalFoci]=(*Co1).Zsc[foci];

		aleapp.p[aleapp.TotalFoci]=(*Co1).p[foci];

		aleapp.subjects[aleapp.TotalFoci]=(*Co1).subjects[foci];
		aleapp.voxel[aleapp.TotalFoci]=(*Co1).voxel[foci];
		aleapp.experiment[aleapp.TotalFoci]=(*Co1).experiment[foci];
		aleapp.cluster[aleapp.TotalFoci]=(*Co1).cluster[foci];
		aleapp.TalLabel[aleapp.TotalFoci]=(*Co1).TalLabel[foci];



		aleapp.TotalFoci++;
	}

	for (study=0;study<Nexp1;study++)
    {
        aleapp.Zcensor[study]=(*Co1).Zcensor[study];
		aleapp.covariate[study]=(*Co1).covariate[study];
		aleapp.SubjectsInExp[study]=(*Co1).SubjectsInExp[study];
		aleapp.ControlsInExp[study]=(*Co1).ControlsInExp[study];
		aleapp.corrected[study]=(*Co1).corrected[study];
		aleapp.modality[study]=(*Co1).modality[study];
		aleapp.subanalysis[study]=(*Co1).subanalysis[study];
		aleapp.VOI[study]=(*Co1).VOI[study];

		sprintf(aleapp.ID[study].txt,"%s",(*Co1).ID[study].txt);
		sprintf(aleapp.CTRST[study].txt,"%s",(*Co1).CTRST[study].txt);
		sprintf(aleapp.CND[study].txt,"%s",(*Co1).CND[study].txt);
		sprintf(aleapp.DESC[study].txt,"%s",(*Co1).DESC[study].txt);
    }

	for (foci=0; foci<foci2; foci++)
	{
		aleapp.x[aleapp.TotalFoci]=(*Co2).x[foci];
		aleapp.y[aleapp.TotalFoci]=(*Co2).y[foci];
		aleapp.z[aleapp.TotalFoci]=(*Co2).z[foci];
		aleapp.Zsc[aleapp.TotalFoci]=(*Co2).Zsc[foci];

		aleapp.p[aleapp.TotalFoci]=(*Co2).p[foci];

		aleapp.subjects[aleapp.TotalFoci]=(*Co2).subjects[foci];
		aleapp.voxel[aleapp.TotalFoci]=(*Co2).voxel[foci];
		aleapp.experiment[aleapp.TotalFoci]=(*Co2).experiment[foci] + Nexp1;
		aleapp.cluster[aleapp.TotalFoci]=(*Co2).cluster[foci];
		aleapp.TalLabel[aleapp.TotalFoci]=(*Co2).TalLabel[foci];


		aleapp.TotalFoci++;
	}

	for (study=0;study<Nexp2;study++)
    {
        aleapp.Zcensor[study + Nexp1]=(*Co2).Zcensor[study];
		aleapp.covariate[study + Nexp1]=(*Co2).covariate[study];
		aleapp.SubjectsInExp[study + Nexp1]=(*Co2).SubjectsInExp[study];
		aleapp.ControlsInExp[study + Nexp1]=(*Co2).ControlsInExp[study];
		aleapp.corrected[study + Nexp1]=(*Co2).corrected[study];
		aleapp.modality[study + Nexp1]=(*Co2).modality[study];
		aleapp.subanalysis[study + Nexp1]=(*Co2).subanalysis[study];
		aleapp.VOI[study + Nexp1]=(*Co2).VOI[study];

		sprintf(aleapp.ID[study + Nexp1].txt,"%s",(*Co2).ID[study].txt);
		sprintf(aleapp.CTRST[study + Nexp1].txt,"%s",(*Co2).CTRST[study].txt);
		sprintf(aleapp.CND[study + Nexp1].txt,"%s",(*Co2).CND[study].txt);
		sprintf(aleapp.DESC[study + Nexp1].txt,"%s",(*Co2).DESC[study].txt);
    }

	FreeCoordinates(Co1);
	CopyCoordinates(&aleapp, Co1);


	result=1;
END:
	FreeCoordinates(&aleapp);

	return result;
}
//======================================================================================================
int TestAppendCoordinates(struct Image *image)
{
	struct Coordinates a,b;

	memset(&a,0,sizeof(struct Coordinates));
	memset(&b,0,sizeof(struct Coordinates));

	//LoadExperimentsCOORDINATES(struct Coordinates *ale, int X, int Y, int Z, float dx, float dy, float dz,float x0, float y0, float z0)
	LoadExperimentsCOORDINATES(NULL,&a, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0);
	LoadExperimentsCOORDINATES(NULL,&b, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0);

	AppendCoordinates(&a,&b);

	SaveExperimentsALE(&a, "c:\\temp\\append.txt", (*image).filename, 1.0, 0);

	FreeCoordinates(&a);
	FreeCoordinates(&b);

	return 0;
}


//======================================================================================================
//MERGE STUDIES BY PAPER
//THERE WILL BE FEWER STUDIES AFTER IF MORE THAN 1 TABLE IS REPORTED WITHIN A PAPER
//modified 13/08/2015 to fix bug relating to studies with zero coordinates; these would not be reordered correctly
//ASSUMES THAT EXPERIMENTS THAT ARE BEING MERGED ARE SIMILAR IN TERMS OF:
//CORRECTED
//ZCENSOR
//COVARIATE
//MODALITY
//======================================================================================================
int MergeCoordinatesbyStudy(struct Coordinates *Co)
{
	int TotalFoci=(*Co).TotalFoci;
	int Nexperiments=(*Co).Nexperiments;
	int g,NmergedExperiments;
	int iexp,foci, iexp2;
	int result=0;
	int counter;
	short int *indicator=NULL;
	short int *subjects=NULL;
	short int *controls=NULL;
	short int *experiment=NULL;
	short int *mergedExp=NULL;
	struct Coordinates M;
	char contrastid[256];
	char conditionid[256];
	//FILE *fp;

	memset(&M,0,sizeof(struct Coordinates));
	if (!CopyCoordinates(Co,&M))
		goto END;

	if (!(mergedExp=(short int *)calloc(Nexperiments,sizeof(short int))))
		goto END;


	mergedExp[0]=0;///first mergedExp is zero
	NmergedExperiments=1;
	for (iexp=1; iexp<Nexperiments; iexp++)
	{
		mergedExp[iexp]=-1;
		for (iexp2=0; iexp2<iexp; iexp2++)
		{
			if ((mergedExp[iexp]<0) && EqualStudyID(Co, iexp, iexp2))
			{
				mergedExp[iexp]=mergedExp[iexp2];//give later studies with same STUDYID the same mergedExp number
			}
		}
		if (mergedExp[iexp]<0)//THIS STUDY HAS NOT BEEN ASSIGNED TO A mergedExp BECAUSE IT DOES NOT HAVE A MATCHING STUDYID, SO ITS A NEW mergedExp
		{
			mergedExp[iexp]=NmergedExperiments;
			NmergedExperiments++;
		}
	}


	if (!(indicator=(short int *)malloc(sizeof(short int)*(NmergedExperiments))))
		goto END;
	if (!(subjects=(short int *)malloc(sizeof(short int)*(NmergedExperiments))))
		goto END;
	if (!(controls=(short int *)malloc(sizeof(short int)*(NmergedExperiments))))
		goto END;
	if (!(experiment=(short int *)malloc(sizeof(short int)*(NmergedExperiments))))
		goto END;
	memset(indicator,0,sizeof(short int)*(NmergedExperiments));
	memset(experiment,0,sizeof(short int)*(NmergedExperiments));

	//renumber the papers so they go from 0 to a max
	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		indicator[mergedExp[iexp]] = 1;//there are fewer NmergedExperiments than experiments if there has been merging, so some indicators will be =0
		if (!experiment[mergedExp[iexp]])
		{
			experiment[mergedExp[iexp]] = iexp+1;
		}
	}

	//the indicator is either 1 or 0 currently, but want it to be an incrementing mergedExp number
	counter=1;
	for (g=0; g<NmergedExperiments; g++)
	{
		if (indicator[g])
		{
			indicator[g]=counter;
			counter++;
		}
	}

	//edited to be smallest number of subjects, rather than largest; 20/4/2017
	//if the papers are to be merged, the foci need the same number of subjects
	//we choose the smallest number of subjects from all tables from the same mergedExp
	for (g=0; g<NmergedExperiments; g++)
	{
		subjects[g]=10000;//initialise with a large number
		controls[g]=10000;
	}
	for (iexp=0; iexp<Nexperiments; iexp++)
	{
		g = mergedExp[iexp];
		if ((*Co).SubjectsInExp[iexp]<subjects[g])
		{
			subjects[g]=(*Co).SubjectsInExp[iexp];
		}

		if ((*Co).ControlsInExp[iexp]<controls[g])
		{
			controls[g]=(*Co).ControlsInExp[iexp];
		}
	}

//fp=fopen("./merging.txt","w");
	M.TotalFoci=0;///INITIALISATION OF THE COORDINATE STRUCTURE
	M.Nexperiments=0;
	for (g=0; g<NmergedExperiments; g++)
	{
		//fprintf(fp,"%d ",g);

		contrastid[0]='\0';
		conditionid[0]='\0';
		for (iexp=0; iexp<Nexperiments; iexp++)
		{
			if (mergedExp[iexp] == g)
			{
				if (strlen(contrastid) + strlen((*Co).CTRST[iexp].txt)<256)
                {
                    sprintf(contrastid,"%s %s",contrastid,(*Co).CTRST[iexp].txt);
                }

				if (strlen(conditionid) + strlen((*Co).CND[iexp].txt)<256)
                {
                    sprintf(conditionid,"%s %s",conditionid,(*Co).CND[iexp].txt);
                }

				//fprintf(fp,"%s ",(*Co).CTRST[iexp].txt);
				for (foci=0; foci<TotalFoci; foci++)
				{
					if ((*Co).experiment[foci]==iexp)
					{
						CopyCoordinatesentry(Co,foci,&M,M.TotalFoci);
						M.subjects[M.TotalFoci] = subjects[g];
						M.experiment[M.TotalFoci] =indicator[g]-1;//the Paper indicator and the experiment indicator
						M.TotalFoci++;
					}
				}
				M.Nexperiments = (indicator[g]>M.Nexperiments) ? indicator[g] : M.Nexperiments;
				M.Zcensor[indicator[g]-1]=(*Co).Zcensor[iexp];
				M.covariate[indicator[g]-1]=(*Co).covariate[iexp];
				M.SubjectsInExp[indicator[g]-1]=subjects[g];
				M.ControlsInExp[indicator[g]-1]=controls[g];
				M.corrected[indicator[g]-1]=(*Co).corrected[iexp];
				M.modality[indicator[g]-1]=(*Co).modality[iexp];
				M.subanalysis[indicator[g]-1]=(*Co).subanalysis[iexp];
				M.VOI[indicator[g]-1]=(*Co).VOI[iexp];
				sprintf(M.ID[indicator[g]-1].txt,"%s", (*Co).ID[iexp].txt);
				sprintf(M.CTRST[indicator[g]-1].txt,"%s",contrastid);
				sprintf(M.CND[indicator[g]-1].txt,"%s", conditionid);
				sprintf(M.DESC[indicator[g]-1].txt,"%s",(*Co).DESC[iexp].txt);
			}

		}
		// fprintf(fp,"\n");
	}
	FreeCoordinates(Co);
	CopyCoordinates(&M,Co);
//fclose(fp);

	result=1;
END:
	FreeCoordinates(&M);
	if (indicator)
		free(indicator);
	if (subjects)
		free(subjects);
	if (controls)
		free(controls);
	if (experiment)
		free(experiment);
	if (mergedExp)
		free(mergedExp);

	return result;
}

//======================================================================================================
//test if the STUDYID is equal for two studies in an ALE
//edited 20/04/2017 to also ignore tab characters
//======================================================================================================
int EqualStudyID(struct Coordinates *Co, int iexp1, int iexp2)
{
	int i,j;
	int L1,L2;

	L1=strlen((*Co).ID[iexp1].txt);
	L2=strlen((*Co).ID[iexp2].txt);

	i=j=-1;
	do
	{
		//get past the spaces
		i++;
		while ( (i<L1) && ((*Co).ID[iexp1].txt[i]==' ' || (*Co).ID[iexp1].txt[i]=='\t') )
			i++;
		j++;
		while ( (j<L2) && ((*Co).ID[iexp2].txt[j]==' ' || (*Co).ID[iexp2].txt[j]=='\t') )
			j++;
	}
	while ( (i<L1) && (j<L2) && ((*Co).ID[iexp1].txt[i]==(*Co).ID[iexp2].txt[j]) );

	if ((i<L1) || (j<L2))
		return 0;
	return 1;
}


//======================================================================================================
//FILTER THE ALEs BY POSITIVE OR NEGATIVE Z
//THIS ALLOWS US TO SPECIFY ACTIVATIONS OR DEACTIVATIONS ONLY
//======================================================================================================
int ZfilterCoordinates(struct Coordinates *Co, int Zfilter)
{
	int result=0;
	struct Coordinates Zf;
	int foci;
	int TotalFoci=(*Co).TotalFoci;
	int sign;

	if (!(*Co).ZscoreUsed)
		return 0;

	if (Zfilter==ID_USE_POSITIVE_Z)
		sign=1;
	else if (Zfilter==ID_USE_NEGATIVE_Z)
		sign=-1;
	else
		return 0;


	memset(&Zf, 0, sizeof(struct Coordinates));
	CopyCoordinates(Co,&Zf);

	Zf.TotalFoci=0;

	for (foci=0; foci<TotalFoci; foci++)
	{
		if ((*Co).Zsc[foci]*sign>0.0)
		{
		    CopyCoordinatesentry(Co, foci, &Zf, Zf.TotalFoci);
			/*Zf.x[Zf.TotalFoci] = (*Co).x[foci];
			Zf.y[Zf.TotalFoci] = (*Co).y[foci];
			Zf.z[Zf.TotalFoci] = (*Co).z[foci];
			Zf.experiment[Zf.TotalFoci] = (*Co).experiment[foci];
			Zf.subjects[Zf.TotalFoci] = (*Co).subjects[foci];
			Zf.p[Zf.TotalFoci] = (*Co).p[foci];
			Zf.Zsc[Zf.TotalFoci] = (*Co).Zsc[foci];
			Zf.TalLabel[Zf.TotalFoci] = (*Co).TalLabel[foci];*/
			Zf.TotalFoci++;
		}
	}


	FreeCoordinates(Co);
	CopyCoordinates(&Zf, Co);
	FreeCoordinates(&Zf);
	return result;
}


//===================================================================================================
//===================================================================================================
//===================================================================================================
//ORDER THE EXPERIMENTS BY STUDYID, CONTRASTID, or CONDITIONID
//THIS WILL MAKE GROUPING EASIER
//===================================================================================================
//===================================================================================================
//===================================================================================================
int OrderExperimentsBy(int label)
{
	int result=0;
	struct Coordinates Co, SortedCo;
	char A[256];
	char B[256];
	char directory[MAX_PATH];
	struct TextLabel *c=NULL;
	int tmp;
	int Nexp;
	int iexp,jexp, experiment;
	int foci;
	int i,j;
	short int *M=NULL;
	FILE *fp;



	memset(&Co,0,sizeof(struct Coordinates));
	memset(&SortedCo,0,sizeof(struct Coordinates));

//load ALE
	//if (!LoadExperimentsCOORDINATES(&Co, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz,
	//                        (*image).x0, (*image).y0, (*image).z0)) goto END;
	if (!LoadExperimentsCOORDINATES(NULL,&Co, 100, 100, 100, 1.0, 1.0, 1.0, 50.0, 50.0, 50.0))
		goto END;//dont need real image dimensions for this procedure


	if (label==STUDYID_LABEL)
		c=Co.ID;
	else if (label==CONTRAST_LABEL)
		c=Co.CTRST;
	else if (label==CONDITION_LABEL)
		c=Co.CND;

	Nexp=Co.Nexperiments;
	if (!(M=(short int *)malloc(Nexp*sizeof(short int))))
		goto END;
	memset(M,0,Nexp*sizeof(short int));
	for (iexp=0; iexp<Nexp; iexp++)
	{
		if (!M[iexp])
		{
			M[iexp] = iexp+1;//add 1 so that 0 is special; not yet matched/considered
			i=0;
			while ((i<strlen(c[iexp].txt)) && (c[iexp].txt[i]==' '))
				i++;//skip past the initial spaces
			sprintf(A,"%s",&c[iexp].txt[i]);
			i=0;
			while ((i<strlen(A)) && (A[i]!=' '))
				i++;
			A[i]='\0';
			//MessageBox(NULL,A,"",MB_OK);
			for (jexp=iexp+1; jexp<Nexp; jexp++)
			{
				if (!M[jexp])
				{
					j=0;
					while ((j<strlen(c[jexp].txt)) && c[jexp].txt[j]==' ')
						j++;//skip past the initial spaces
					sprintf(B,"%s",&c[jexp].txt[j]);
					j=0;
					while ((j<strlen(B)) && (B[j]!=' '))
						j++;
					B[j]='\0';


					if (strlen(A)==strlen(B) && (strstr(A,B) || strstr(B,A)))
					{
						M[jexp] = iexp+1;

						//fprintf(fp,"*%d,%s,%d,%s\n",iexp,A,jexp,B);
					}
					//else fprintf(fp,"%d,%s,%d,%s\n",iexp,A,jexp,B);

				}

			}
		}
	}


	tmp=DirectoryFileDivide(Co.coordinate_file_name);
	sprintf(directory,"%s",Co.coordinate_file_name);
	directory[tmp]='\0';
	sprintf(directory,"%s//SortedActivations.txt",directory);


	if( (fp=fopen(directory,"w") ) )
	{
		if (Co.ZscoreUsed)
			fprintf(fp,"//4COLUMN\n");
		experiment=0;
		for (iexp=0; iexp<Nexp; iexp++)
		{
			for (jexp=0; jexp<Nexp; jexp++)
			{
				if (M[jexp]==iexp+1)
				{
					switch(Co.modality[jexp])
					{
					case PET_STUDY:
						fprintf(fp,"//PET\n");
						break;
					case FMRI_STUDY:
						fprintf(fp,"//FMRI\n");
						break;
					case STRUCTURAL_STUDY:
						fprintf(fp,"//STRUCTURAL\n");
						break;
					case SPECT_STUDY:
						fprintf(fp,"//SPECT\n");
						break;
					}
					if (Co.subanalysis[jexp])
						fprintf(fp,"//SUBANALYSIS\n");
					if (Co.VOI[jexp])
						fprintf(fp,"//VOI\n");
					else
						fprintf(fp,"//WB\n");
					fprintf(fp,"//CENSOR=%f\n",Co.Zcensor[jexp]);
					fprintf(fp,"//COVARIATE=%f\n",Co.covariate[jexp]);
					fprintf(fp,"//DESCRIPTION %s\n",Co.DESC[jexp].txt);
					fprintf(fp,"//CONDITIONID %s\n",Co.CND[jexp].txt);
					fprintf(fp,"//CONTRASTID %s\n",Co.CTRST[jexp].txt);
					fprintf(fp,"//STUDYID %s\n",Co.ID[jexp].txt);
					foci=0;
					while((foci<Co.TotalFoci) && (Co.experiment[foci]!=jexp))
						foci++;
					fprintf(fp,"//controls=%d\n",Co.ControlsInExp[jexp]);
					fprintf(fp,"//subjects=%d\n",Co.SubjectsInExp[jexp]);
					while((foci<Co.TotalFoci) && (Co.experiment[foci]==jexp))
					{
						if (Co.ZscoreUsed)
							fprintf(fp,"%f %f %f %f\n",Co.x[foci], Co.y[foci], Co.z[foci], Co.Zsc[foci]);
						else
							fprintf(fp,"%f %f %f\n",Co.x[foci], Co.y[foci], Co.z[foci]);
						foci++;
					}
					fprintf(fp,"\n\n");
					experiment++;
				}
			}
		}
		fclose(fp);
	}



END:

	FreeCoordinates(&Co);
	FreeCoordinates(&SortedCo);
	if (M)
		free(M);

	return result;
}


//===============================================================================================
//FILL THE TALAIRACH LABELS IN THE COORDINATES STRUCTURE WITHOUT THE TALAIRACH IMAGE
//===============================================================================================
int GetTalairachLabels(struct Coordinates *Co)
{
	struct Image TalGM;
	char fname[MAX_PATH];

	memset(&TalGM,0,sizeof(struct Image));

	sprintf(fname,"%s\\Talairach\\talairach.nii", ExecutableDirectory);
	LoadFromFileName(NULL, fname, &TalGM, 0);

	GetTalairachLabelsEx(Co, &TalGM);

	ReleaseImage(&TalGM);
	return 1;

}
//===============================================================================================
//put the Talairach labels in Coordinates structure
//===============================================================================================
//===============================================================================================
//===============================================================================================
int GetTalairachLabelsEx(struct Coordinates *Co, struct Image *TalGM)
{

	int foci, xi, yi, zi;
	float x,y,z;

	for (foci=0; foci<(*Co).TotalFoci; foci++)
	{

		//get the GM structure
		x=(*Co).x[foci];
		y=(*Co).y[foci];
		z=(*Co).z[foci];


		xi = (int)(((x + (*TalGM).x0)/(*TalGM).dx) + 0.5);
		yi = (int)(((y + (*TalGM).y0)/(*TalGM).dy) + 0.5);
		zi = (int)(((z + (*TalGM).z0)/(*TalGM).dz) + 0.5);

		(*Co).TalLabel[foci] = NearestGM((*TalGM).img, (*TalGM).X, (*TalGM).Y, (*TalGM).Z, xi, yi, zi);
	}

	return 1;
}


//===============================================================================================
//get subanalysis studies only
//===============================================================================================
int GetSubAnlysesCoordinates(struct Coordinates *Co)
{
	int result=0;
	int study;
	int SAstudies;
	int focus, SAfocus;
	int FociAdded;
	struct Coordinates SAco;
	//char txt[256];

	memset(&SAco,0,sizeof(struct Coordinates));
	if (!CopyCoordinates(Co,&SAco))
		goto END;

	SAfocus=0;
	SAstudies=0;
	for (study=0; study<(*Co).Nexperiments; study++)
	{
		if ((*Co).subanalysis[study])
		{
			FociAdded=0;
			for (focus=0; focus<(*Co).TotalFoci; focus++)
			{
				if ((*Co).experiment[focus]==study)
				{
					//(struct Coordinates *A, int FocusA, int StudyA, struct Coordinates *B, int FocusB, int StudyB);
					if (!CopyCoordinatesentryExt(Co, focus, study, &SAco, SAfocus, SAstudies))
						goto END;
					SAfocus++;
					FociAdded=1;

					//sprintf(txt,"%d %d %d %d",focus,study,SAfocus,SAstudies);
					//MessageBox(NULL,txt,"",MB_OK);
				}
			}
			if (FociAdded)
				SAstudies++;
			else
			{
				//if no new foci were added, then the study has no results
				//in this case, just copy the study without any coordinates
				SAco.Zcensor[SAstudies]=(*Co).Zcensor[study];
				SAco.covariate[SAstudies]=(*Co).covariate[study];
				SAco.SubjectsInExp[SAstudies]=(*Co).SubjectsInExp[study];
				SAco.ControlsInExp[SAstudies]=(*Co).ControlsInExp[study];
				SAco.corrected[SAstudies]=(*Co).corrected[study];
				SAco.modality[SAstudies]=(*Co).modality[study];
				SAco.subanalysis[SAstudies]=(*Co).subanalysis[study];
				SAco.VOI[SAstudies]=(*Co).VOI[study];
				sprintf(SAco.ID[SAstudies].txt,"%s",(*Co).ID[study].txt);
				sprintf(SAco.CTRST[SAstudies].txt,"%s",(*Co).CTRST[study].txt);
				sprintf(SAco.CND[SAstudies].txt,"%s",(*Co).CND[study].txt);
				sprintf(SAco.DESC[SAstudies].txt,"%s",(*Co).DESC[study].txt);
				SAstudies++;
			}
		}
	}

	SAco.TotalFoci=SAfocus;
	SAco.Nexperiments=SAstudies;

	if (SAstudies<=1)
		goto END;//cant do sub analysis with single study


	FreeCoordinates(Co);
	if (!CopyCoordinates(&SAco,Co))
		goto END;
	//sprintf(txt,"%d %d",SAfocus,SAstudies);
	//MessageBox(NULL,txt,"",MB_OK);

	result=SAstudies;
END:
	FreeCoordinates(&SAco);
	return result;

}
int TestGetSubAnalyses(struct Image *image)
{
	struct Coordinates Co;
	char fname[MAX_PATH];

	memset(&Co,0,sizeof(struct Coordinates));

	LoadExperimentsCOORDINATES(NULL,&Co, (*image).X, (*image).Y, (*image).Z, (*image).dx, (*image).dy, (*image).dz, (*image).x0, (*image).y0, (*image).z0);

	GetSubAnlysesCoordinates(&Co);

	sprintf(fname,"c://temp//subanalysis test.txt");
	SaveExperimentsALE(&Co,fname,"",1.0,0);
	return 1;
}



//======================================================================================================
//SAVE THE STUDY TABLE
//======================================================================================================
int SaveStudyTable(struct Coordinates *C, char *fname)
{

	FILE *fp=NULL;
	int result=0;
	int iexp;
	int coordinates,focus;

	if ((fp=fopen(fname,"w")))
	{
		fprintf(fp,"Study,Description,CONTRASTID,CONDITIONID,corrected,modality,coordinates,subjects,controls,covariate, VOI\n");
		for (iexp=0; iexp<(*C).Nexperiments; iexp++)
		{
			coordinates=0;
			for (focus=0; focus<(*C).TotalFoci; focus++)
			{
				if ((*C).experiment[focus]==iexp)
					coordinates++;
			}
			fprintf(fp,"%s,%s,%s,%s,",(*C).ID[iexp].txt, (*C).DESC[iexp].txt, (*C).CTRST[iexp].txt, (*C).CND[iexp].txt);
			if ((*C).corrected[iexp])
				fprintf(fp,"Yes,");
			else
				fprintf(fp,"No,");
			switch ((*C).modality[iexp])
			{
			case PET_STUDY:
				fprintf(fp,"PET,%d,%d,%d",coordinates,(*C).SubjectsInExp[iexp],(*C).ControlsInExp[iexp]);
				break;
			case FMRI_STUDY:
				fprintf(fp,"fMRI,%d,%d,%d",coordinates,(*C).SubjectsInExp[iexp],(*C).ControlsInExp[iexp]);
				break;
			case SPECT_STUDY:
				fprintf(fp,"SPECT,%d,%d,%d",coordinates,(*C).SubjectsInExp[iexp],(*C).ControlsInExp[iexp]);
				break;
			default:
				fprintf(fp,",%d,%d,%d",coordinates,(*C).SubjectsInExp[iexp],(*C).ControlsInExp[iexp]);
				break;
			}
			fprintf(fp,",%f,%d\n",(*C).covariate[iexp], (*C).VOI[iexp]);
		}
		fclose(fp);
		result=1;
	}


	return result;
}


//======================================================================================================
//======================================================================================================
//======================================================================================================
//GIVEN SOME TEXT (In) PUT A VERSION INTO Out
//RETURN THE LENGTH OF Out
//changed 7 Nov 2016 because its not just spaces causing issues. So now removes all white space
//======================================================================================================
//======================================================================================================
//======================================================================================================
#define CHARACTERS "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
int NoSpaces(char In[], char Out[])
{
	int i,j;
	char character[2];
	//FILE *fp;
	//char fname[MAX_PATH];

	//sprintf(fname,"%s//characters.txt",REPORT_FOLDER);
	//fp=fopen(fname,"a");

	//fprintf(fp,"%s\n",In);

	j=0;
	for (i=0; i<strlen(In); i++)
	{
		character[0]=In[i];
		character[1]='\0';
		//fprintf(fp,"%s\n",character);
		if (strstr(CHARACTERS,character)!='\0'/*In[i]!=' '*/)
		{
			Out[j]=In[i];
			j++;
		}
	}
	Out[j]='\0';
	//fprintf(fp,"%s\n",Out);

	//fclose(fp);
	return j;
}

//======================================================================================
//Remove duplicated coordinates within study
//======================================================================================
int RemoveWithinStudyDuplicates(struct Coordinates *C)
{
    int Nfoci=(*C).TotalFoci;
    int Nexp=(*C).Nexperiments;
    int study;
    int focus1, focus2;
    int count=0;
    char *include=NULL;
    struct Coordinates Cpy;
    double *SmallP=NULL;
    //char txt[256];

    memset(&Cpy,0,sizeof(struct Coordinates));
    if (!CopyCoordinates(C, &Cpy)) goto END;

    if (!(include=(char *)malloc(Nfoci*sizeof(char)))) goto END;
    if (!(SmallP=(double *)malloc(Nfoci*sizeof(double)))) goto END;

    //include all initially
    for (focus1=0;focus1<Nfoci;focus1++)
    {
        include[focus1]=1;
        SmallP[focus1]=1.0;
    }

    for (study=0;study<Nexp;study++)
    {
        for (focus1=0;focus1<Nfoci;focus1++)
        {
            if ((*C).experiment[focus1]==study && include[focus1])
            {
                if ((*C).p[focus1]<SmallP[focus1])
                {
                    SmallP[focus1]=(*C).p[focus1];
                }
                for (focus2=focus1+1;focus2<Nfoci;focus2++)
                {
                    if ((*C).experiment[focus2]==study && include[focus2])
                    {
                            if ((*C).voxel[focus1]==(*C).voxel[focus2])
                            {
                                //sprintf(txt,"%s %d %d\n%f %f %f\n%f %f %f",(*C).ID[study].txt,focus1,focus2,(*C).x[focus1],(*C).y[focus1],(*C).z[focus1],(*C).x[focus2],(*C).y[focus2],(*C).z[focus2]);
                                //MessageBox(NULL,txt,"",MB_OK);
                                include[focus2]=0;
                                count++;
                            }
                    }
                }
            }
        }
    }

    (*C).TotalFoci=0;
     for (focus1=0;focus1<Nfoci;focus1++)
     {
         if (include[focus1])
         {
             CopyCoordinatesentry(&Cpy, focus1, C, (*C).TotalFoci);
             (*C).p[(*C).TotalFoci]=SmallP[focus1];//this keeps the most significant of the duplicates
             (*C).TotalFoci++;
         }
     }




END:
    if (include) free(include);
    if (SmallP) free(SmallP);
    FreeCoordinates(&Cpy);

return 0;
}


//======================================================================================
int NumberOfIndependentStudies(struct Coordinates *C)
{

    struct Coordinates Cpy;
	int N=0;

	memset(&Cpy,0,sizeof(struct Coordinates));
	if (CopyCoordinates(C, &Cpy))
    {
            MergeCoordinatesbyStudy(&Cpy);
            N=Cpy.Nexperiments;
            FreeCoordinates(&Cpy);
    }

	return N;
}
//======================================================================================
int NumberOfNonNullIndependentStudies(struct Coordinates *C)
{

	struct Coordinates Cpy;
	int N=0;
	int iexp;

	memset(&Cpy,0,sizeof(struct Coordinates));
	if (CopyCoordinates(C, &Cpy))
    {
            MergeCoordinatesbyStudy(&Cpy);
            for (iexp=0;iexp<Cpy.Nexperiments;iexp++)
            {
                if (CoordinatesInStudy(&Cpy, iexp)) N++;
            }
            FreeCoordinates(&Cpy);
    }

	return N;
}
