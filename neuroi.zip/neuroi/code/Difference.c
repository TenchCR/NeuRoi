/*
Copyright 2009 - 2022 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "difference.h"

#define SCROLL_MAX_FINE 1000
#define SCROLL_MAX 10
#define SCROLL_MIN 0


/*
//detect the difference between two images (A&B) of the same person
//therefore use affine registration
//need the images to be similar contrast (both T2, T1....)
//Functions:
//1) remove background. This applies to image A only and will help with the normalising of intensities
//2) Register the images; affine
//3) Normalise the images. Divide B by A and fit a low order polynomial. Then normalise B
//4) Detect A>B, B>A, and A<>B
//5) Save the registered image
*/


struct RegData gRegStruct;



//=============================================================================================
//                           Auto ROI dialog callback function
//=============================================================================================
INT_PTR CALLBACK DifferenceDlg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    static int flip;
    static int AutoSwitch;
    static double RegParameters[AFFINE12];
    static double sd,Z;
    double frac;
    int posinit,pos;
    int voxel,voxels;
    static HCURSOR hourglass;
    HCURSOR	PrevCursor;
    HDC hDC;
    static RECT A,B;
    static HBRUSH brush;
    COLORREF Green;
    unsigned char dummy;

    switch (msg)
    {


    case WM_CLOSE:
        DeleteBrush(brush);
        if (AutoSwitch) KillTimer(hwnd, ID_TIMER);
        SetMenuItemState(GetParent(hwnd), MF_ENABLED);
        hDifference=(HWND)NULL;
        ReleaseRegData(&gRegStruct);
        EndDialog(hwnd,0);
        break;



    case WM_SHOWWINDOW:
        if (AutoSwitch) SendMessage(GetDlgItem(hwnd,ID_AUTO_FLIP),BM_SETCHECK,BST_CHECKED,0);
        else SendMessage(GetDlgItem(hwnd,ID_AUTO_FLIP),BM_SETCHECK,BST_UNCHECKED,0);
        break;





    case WM_INITDIALOG:
        hourglass=LoadCursor(NULL,IDC_WAIT);
        SetMenuItemState(GetParent(hwnd), MF_GRAYED);
        memset(&gRegStruct,0,sizeof(struct RegData));
        InitialiseRegistrationParameters(RegParameters,AFFINE12);
        //PREPROCESS THE BASE IMAGE
        if (!ProcessForRegistration(&gImage, PRE_PROCESS_SMOOTH, CLASSES)) SendMessage(hwnd, WM_CLOSE,0,0);

        //GET REGISTRATION SAMPLE POINTS
        if (!(gRegStruct.Points.used=GetTestPoints(&gRegStruct, gImage.img, gImage.charimg, gImage.X, gImage.Y, gImage.Z/gImage.volumes,
                                     gImage.dx, gImage.dy, gImage.dz, &dummy,0))) SendMessage(hwnd, WM_CLOSE,0,0);

        //SETUP THE IMAGE MIX SCROLL BARS
        SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX);
        SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX),SBM_SETPOS,SCROLL_MIN,TRUE);
        SendMessage(GetDlgItem(hwnd,ID_DIFFERENCE_THRESHOLD),SBM_SETRANGE,SCROLL_MIN,SCROLL_MAX_FINE);
        SendMessage(GetDlgItem(hwnd,ID_DIFFERENCE_THRESHOLD),SBM_SETPOS,SCROLL_MIN,TRUE);
        AutoSwitch=0;
        flip=0;
        A.left=10;
        A.right=70;
        A.top=220;
        A.bottom=310;///rectangle coordinates for 'flashing' switch
        B.left=330;
        B.right=390;
        B.top=220;
        B.bottom=310;
        Green=RGB(0,255,0);
        brush=CreateSolidBrush(Green);
        break;

    case WM_TIMER:
        switch (LOWORD(wParam))
        {
        case ID_TIMER:

            flip=1-flip;
            if (gRegStruct.Match.img)
            {
                if (flip) frac=1.0;
                else frac=0.01;//not 0 or we wont get the whole image
                ShowBaseMatchMix((HWND)GetParent(hwnd), &gImage, &gRegStruct.Match, gMainPict.slice,
                                 RegParameters, AFFINE12, frac, gMainPict.saturation);

                if (flip) SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX), SBM_SETPOS, SCROLL_MAX, TRUE);
                else SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX), SBM_SETPOS, SCROLL_MIN, TRUE);



                if ( (hDC=GetDC(hwnd)) )
                {
                    if (flip)
                    {
                        FillRect(hDC, &A, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
                        FillRect(hDC, &B, brush);
                    }
                    else
                    {
                        FillRect(hDC, &A, brush);
                        FillRect(hDC, &B, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
                    }
                    ReleaseDC(hwnd,hDC);
                }
            }
            break;
        }
        break;


    case WM_HSCROLL:
        posinit = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
        switch (LOWORD(wParam))
        {
        case SB_LINELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-1), TRUE);
            break;
        case SB_LINERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+1), TRUE);
            break;
        case SB_PAGELEFT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit-SCROLL_MAX/5), TRUE);
            break;
        case SB_PAGERIGHT:
            SendMessage( (HWND) lParam, SBM_SETPOS, (WPARAM)(posinit+SCROLL_MAX/5), TRUE);
            break;
        case SB_THUMBTRACK:
            SendMessage( (HWND) lParam, SBM_SETPOS, HIWORD(wParam), TRUE);
            break;
        }
        pos = (int)SendMessage( (HWND) lParam, SBM_GETPOS, 0, 0);
        if ((pos!=posinit) && ((HWND)lParam==GetDlgItem(hwnd,ID_IMAGE_MIX)))
        {
            //SHOW MIXED IMAGE
            if (gRegStruct.Match.img) ShowBaseMatchMix((HWND)GetParent(hwnd), &gImage, &gRegStruct.Match, gMainPict.slice,
                        RegParameters, AFFINE12, (double)pos/SCROLL_MAX, gMainPict.saturation);
        }
        else if ((gRegStruct.Match.floatimg) && (sd>0.0) && (pos!=posinit) && ((HWND)lParam==GetDlgItem(hwnd,ID_DIFFERENCE_THRESHOLD)))
        {
            //------a Z score to do the thresholding with-------
            Z=(double)pos/SCROLL_MAX_FINE*5;//----0<=Z<=5.0-----
            voxels=gRegStruct.Match.X*gRegStruct.Match.Y*gRegStruct.Match.Z;
            if (Z<=0.0) memcpy(gRegStruct.Match.img, gRegStruct.Match.floatimg, sizeof(float)*voxels);
            else
            {
                for (voxel=0; voxel<voxels; voxel++)
                {
                    if ( (gRegStruct.Match.floatimg[voxel]-gImage.img[voxel])/sd >= Z ) gRegStruct.Match.img[voxel]=gRegStruct.Match.floatimg[voxel];
                    else gRegStruct.Match.img[voxel]=0.0;
                }
            }

            //SHOW MIXED IMAGE
            pos = (int)SendMessage(GetDlgItem(hwnd,ID_IMAGE_MIX), SBM_GETPOS, 0, 0);
            if (gRegStruct.Match.img) ShowBaseMatchMix((HWND)GetParent(hwnd), &gImage, &gRegStruct.Match, gMainPict.slice,
                        RegParameters, AFFINE12, (double)pos/SCROLL_MAX, gMainPict.saturation);
        }
        SetFocus(GetParent(hwnd));
        break;




    case WM_COMMAND:
        switch (LOWORD(wParam))
        {


        case ID_AUTO_FLIP:
            if ( (hDC=GetDC(hwnd)) )
                {
                    FillRect(hDC, &A, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
                    FillRect(hDC, &B, (HBRUSH)GetStockObject(LTGRAY_BRUSH));
                    ReleaseDC(hwnd,hDC);
                }
            if (!AutoSwitch)
            {


                SendMessage(GetDlgItem(hwnd,ID_AUTO_FLIP),BM_SETCHECK,BST_CHECKED,0);
                AutoSwitch=1;
                SetTimer(hwnd,                  // handle to main window
                         ID_TIMER,              // timer identifier
                         750,                   // 3/4-second interval
                         (TIMERPROC) NULL);     // no timer callback
            }
            else
            {
                SendMessage(GetDlgItem(hwnd,ID_AUTO_FLIP),BM_SETCHECK,BST_UNCHECKED,0);
                AutoSwitch=0;
                KillTimer(hwnd, ID_TIMER);
            }
            break;



        case IDM_AUTO_THRESHOLD:
            gImage.changed=AutoRemoveNoisyBackground(GetParent(hwnd), &gImage,1);
            break;


        case ID_LOAD_MATCH:
            if (gRegStruct.Match.img) ReleaseImage(&gRegStruct.Match);
            LoadAnalyzeOrNiftiEx(GetParent(hwnd), &gRegStruct.Match, "Load Comparison Image", 0);
            voxels=gRegStruct.Match.X*gRegStruct.Match.Y*gRegStruct.Match.Z;
            if (!(gRegStruct.Match.floatimg=(float *)malloc(voxels*sizeof(float)))) SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        case ID_NORMALISE_IMAGE:
            PrevCursor=SetCursor(hourglass);

            if ((gRegStruct.Match.img) && (ProcessForRegistration(&gRegStruct.Match, PRE_PROCESS_SMOOTH, CLASSES)))
            {
                MinimiseRegistrationError(GetParent(hwnd), GetDlgItem(hwnd, ID_RELATIVE_ERROR), RegParameters, AFFINE12, &gRegStruct);

                //----reformat the match image-------
                ReformatMatchImage(gImage.X, gImage.Y, gImage.Z/gImage.volumes, gImage.dx, gImage.dy, gImage.dz,
                                   gImage.x0, gImage.y0, gImage.z0, &gRegStruct.Match, RegParameters, AFFINE12, ID_CUBIC);
                InitialiseRegistrationParameters(RegParameters,AFFINE12);

                //----normalise the intensities------
                sd=NormalizeIntensity(&gImage, &gRegStruct.Match);

                voxels=gRegStruct.Match.X*gRegStruct.Match.Y*gRegStruct.Match.Z;
                memcpy(gRegStruct.Match.floatimg, gRegStruct.Match.img,voxels*sizeof(float));
            }
            SetCursor(PrevCursor);
            break;

        case ID_SAVE_NORMALISED:
            SaveAs(&gRegStruct.Match);
            break;

        case IDOK:
            SendMessage(hwnd, WM_CLOSE,0,0);
            break;

        }
        break;
    }



    return 0;
}


