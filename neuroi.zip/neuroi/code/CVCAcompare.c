/*
Copyright 2009 - 2024 Christopher Tench

This file is part of NeuRoi.

    NeuRoi is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    NeuRoi is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with NeuRoi.  If not, see <http://www.gnu.org/licenses/>.
*/


/*
Do CVCA on 2 coordinate files
This will give the optimal kernel width
Derive the activation map for each study given the optimal kernel widths
Do PCA, and remove those with eigenvalues < 1/N; this removes some noise
Do BLR and backwards regression
Do cross validation to estimate prediction accuracy
*/


#include "KernelLOO.h"

struct ProbabilitiesAB {
    double A;
    double B;
};

int GetStudyActivationImages(struct Image *image, struct Coordinates *C, unsigned char StudyActivation[], double width, short int valid[]);

double CompareThreshold(float MetaDifference[], int NstudiesA, int NstudiesB, char director[]);

int ActivationAtFociStudy(unsigned char *ActivationsAtFoci, unsigned char *Activations,
                          int voxelsA[], int NfociA, int voxelsB[], int NfociB,
                          int NstudiesA, int NstudiesB,
                          int Voxels);

double ABprediction(unsigned char *ActivationFocusStudy, short int studyA[], short int studyB[],
                    int NfociA, int NfociB, int NstudiesA, int NstudiesB,  int LeaveOutA, int LeaveOutB,
                    double thresholdA, double thresholdB);

int SaveStudyImage(struct Image *image, unsigned char *Activations, int Nstudies, int voxels, char directory[], char fname[]);

double SaveDifferenceImage(struct Image *image, unsigned char *Activations, int NstudiesA, int NstudiesB, int voxels, double thresholdA, double thresholdB, char directory[], char fname[]);

struct ProbabilitiesAB ProbabilityCompareFoci(unsigned char *ActivationFocusStudy, int focus, int NstudiesA, int NstudiesB, int LeaveOutA, int LeaveOutB);
//============================================================================================
int CompareCoordinatesUsingLOO(HWND hwnd, struct Image *image,
                               struct Coordinates *CA, struct Coordinates *CB,
                               int NumberOfPermutations)
{
    struct Coordinates CApermuted, CBpermuted;
    double score;
    double NullScoreSum;
    double NullScore2Sum;
    double NullScoreVariance;
    FILE *fp;
    char fname[MAX_PATH];
    char directory[MAX_PATH];
    int iter;
    int tmp;

    tmp=DirectoryFileDivide((*CA).coordinate_file_name);
					sprintf(directory,"%s",(*CA).coordinate_file_name);
    directory[tmp]='\0';
    sprintf(directory,"%s//CVCAcontrast",directory);
    CreateDirectory(directory, NULL);


    sprintf(fname,"%s\\File Descriptions.txt",directory);
    if ((fp=fopen(fname,"w")))
    {
        fprintf(fp,"\nscores.csv: This file has the scores measuring the differences. \nThe first entry is for the original coordinates. \nSubsequent entries are for permuted coordinates.\n");
        fprintf(fp,"The Z score indicates the significance of the differences (Z>2 is usually considered significant\n");
        fclose(fp);
    }


    sprintf(fname,"%s//scores.csv",directory);

    memset(&CApermuted,0,sizeof(struct Coordinates));
    memset(&CBpermuted,0,sizeof(struct Coordinates));

    score=CVCAcompare(hwnd, image, CA, CB, directory, 1);
    if ((fp=fopen(fname,"w")))
    {
            fprintf(fp,"0, %f\n",score);
            fclose(fp);
    }



    NullScoreSum=NullScore2Sum=0.0;
    for (iter=1; iter<=NumberOfPermutations; iter++) {
        if ((fp=fopen(fname,"a"))) {
            PermuteStudies(CA, &CApermuted, CB, &CBpermuted);

            score=CVCAcompare(hwnd, image, &CApermuted, &CBpermuted, directory, 0);

            NullScoreSum+=score;
            NullScore2Sum+=score*score;

            fprintf(fp,"%d, %f\n",iter,score);

            fclose(fp);
        }
    }

    if ((fp=fopen(fname,"a"))) {

        fprintf(fp,"Mean Null score=,%f\n",NullScoreSum/20);
        NullScoreVariance=NullScore2Sum/20 - NullScoreSum*NullScoreSum/20/20;
        if (NullScoreVariance>0.0)
        {
            fprintf(fp,"Null score standard deviation=,%f\n",sqrt(NullScoreVariance));
            fprintf(fp,"Z score=,%f\n",NullScoreSum/20/sqrt(NullScoreVariance));
        }
        else
        {
            fprintf(fp,"Zscore=,INFINITY\n");
        }
        fclose(fp);
    }

    FreeCoordinates(&CApermuted);
    FreeCoordinates(&CBpermuted);
    return 1;
}
//============================================================================================

double CVCAcompare(HWND hwnd, struct Image *image, struct Coordinates *CA, struct Coordinates *CB, char directory[], int save)
{

    struct KernelMinimise structKMA;
    struct KernelMinimise structKMB;
    int NfociA=(*CA).TotalFoci;
    int NfociB=(*CB).TotalFoci;
    int NstudiesA=(*CA).Nexperiments;
    int NstudiesB=(*CB).Nexperiments;
    int Nstudies=NstudiesA+NstudiesB;
    int focus;
    int ImageVoxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int tmp;
    int j;
    int studyA,studyB;
    short int *IsFocusConcordant=NULL;
    unsigned char *ActivationImages=NULL;
    unsigned char *ActivationStudyFocus=NULL;
    double widthA,widthB;
    double score;
    double threshold;
    double maxscore;
    double bestthreshold;
    FILE *fp=NULL;
    char fname[MAX_PATH];

    memset(&structKMA,0,sizeof(struct KernelMinimise));
    memset(&structKMB,0,sizeof(struct KernelMinimise));

    if (!(structKMA.dist2=(double *)malloc(NfociA*NfociA*sizeof(double))))
        goto END;

    if (!(structKMB.dist2=(double *)malloc(NfociB*NfociB*sizeof(double))))
        goto END;

    if (!(ActivationImages=(unsigned char *)calloc((NstudiesA+NstudiesB)*ImageVoxels,sizeof(unsigned char))))
        goto END;


    if (!(ActivationStudyFocus=(unsigned char *)calloc((NfociA + NfociB)*Nstudies,sizeof(unsigned char))))
        goto END;

    tmp=(NfociA>NfociB) ? NfociA:NfociB;
    if (!(IsFocusConcordant=(short int *)malloc(tmp*sizeof(short int))))
        goto END;


    sprintf(fname,"%s\\File Descriptions.txt",directory);
    if ((fp=fopen(fname,"a")))
    {
        fprintf(fp,"\nThreshold.csv: This file records the score for the difference image for a given threshold.\nThe maximum threshold is the optimal solution.\n");
        fclose(fp);
    }

    MaxKernelLOOscore(CA, &structKMA);
    widthA=structKMA.width;
    ConcordantCoordinates(NfociA, (*CA).Nexperiments, structKMA.dist2, (*CA).experiment, widthA, IsFocusConcordant, structKMA.Neighbours, -1);
    free(structKMA.dist2);///don't need this any more

    GetStudyActivationImages(image, CA, ActivationImages, widthA, IsFocusConcordant);

    MaxKernelLOOscore(CB, &structKMB);
    widthB=structKMB.width;
    ConcordantCoordinates(NfociB, (*CB).Nexperiments, structKMB.dist2, (*CB).experiment, widthB, IsFocusConcordant, structKMB.Neighbours, -1);
    free(structKMB.dist2);///don't need this any more

    GetStudyActivationImages(image, CB, &ActivationImages[NstudiesA*ImageVoxels], widthB,IsFocusConcordant);

    //get activation from each study at each focus
    ActivationAtFociStudy(ActivationStudyFocus, ActivationImages,(*CA).voxel, NfociA, (*CB).voxel, NfociB,NstudiesA, NstudiesB,ImageVoxels);


    sprintf(fname,"%s//Threshold.csv",directory);
     if ((fp=fopen(fname,"w")))
    {
          fclose(fp);
    }

    score=0.0;
    maxscore=0.0;
    bestthreshold=0.0;
    for (j=1; j<100; j++) {
        threshold=(double)j/100;
            for (studyA=0;studyA<NstudiesA;studyA++)
            {
                for (studyB=0;studyB<NstudiesB;studyB++)
                {
                    score += ABprediction(ActivationStudyFocus, (*CA).experiment,(*CB).experiment,
                                      NfociA, NfociB, NstudiesA, NstudiesB,  studyA, studyB, threshold, threshold);
                }
            }
            score /= NstudiesA*NstudiesB;
            if (score > maxscore) {
                maxscore=score;
                bestthreshold=threshold;
            }


            if ((fp=fopen(fname,"a")))
            {
                fprintf(fp,"%f,%f\n",threshold,score);
                fclose(fp);
            }
    }



    if (save) {

        sprintf(fname,"%s\\File Descriptions.txt",directory);
        if ((fp=fopen(fname,"a")))
        {
            fprintf(fp,"\nA: This image is the CVCA solution for coordinates A.\n");
            fprintf(fp,"Coordinates A are from file %s\n",(*CA).coordinate_file_name);
            fprintf(fp,"\nB: This image is the CVCA solution for coordinates B.\n");
            fprintf(fp,"Coordinates B are from file %s\n",(*CB).coordinate_file_name);
            fprintf(fp,"\ndifference: This image is the difference between the A and B solutions.\n");
            fprintf(fp,"\ndifference threshold: This image is the difference between the A and B solutions with the optimal threshold applied.\n");
            fprintf(fp,"\nReported Structures A(B): This CSV file indicates where differences between study groups are in Talairach space. It reports proportion of studies reported in each structure and the mean coordinate reported in that structure.\n");
            fclose(fp);
        }

        SaveDifferenceImage(image, ActivationImages, NstudiesA, NstudiesB, ImageVoxels, 0.0, 0.0, directory, "difference");
        SaveDifferenceImage(image, ActivationImages, NstudiesA, NstudiesB, ImageVoxels, bestthreshold, bestthreshold, directory, "difference threshold");

        sprintf(fname,"%s//Reported Structures A.csv",directory);
        memset(IsFocusConcordant,0,sizeof(short int)*NfociA);
        for (focus=0;focus<NfociA;focus++)
        {
            if ((*image).img[(*CA).voxel[focus]]>0.0) IsFocusConcordant[focus]=1;
        }
        SaveReportedStructuresCVCAfilename(CA, fname, IsFocusConcordant);

        sprintf(fname,"%s//Reported Structures B.csv",directory);
        memset(IsFocusConcordant,0,sizeof(short int)*NfociB);
        for (focus=0;focus<NfociB;focus++)
        {
            if ((*image).img[(*CB).voxel[focus]]<0.0) IsFocusConcordant[focus]=1;
        }
        SaveReportedStructuresCVCAfilename(CB, fname, IsFocusConcordant);

        SaveStudyImage(image, ActivationImages, NstudiesA, ImageVoxels, directory, "A");
        SaveStudyImage(image, &ActivationImages[ImageVoxels*NstudiesA], NstudiesB, ImageVoxels, directory, "B");
    }


END:

    if (ActivationImages)
        free(ActivationImages);

    if (IsFocusConcordant)
        free(IsFocusConcordant);

    if (ActivationStudyFocus)
        free(ActivationStudyFocus);

    return maxscore;
}



//========================================================================================
int SaveStudyImage(struct Image *image, unsigned char *ActivationImages, int Nstudies, int ImageVoxels, char directory[], char fname[])
{
    int voxel;
    int study;

    memset((*image).img, 0, sizeof(float)*ImageVoxels);

    for (study=0; study<Nstudies; study++) {
        for (voxel=0; voxel<ImageVoxels; voxel++) {
            (*image).img[voxel] += (double)ActivationImages[voxel+study*ImageVoxels]/255;
        }
    }
    (*image).offset=0.0;
    (*image).scale=1.0;
    (*image).DataType=DT_FLOAT;
    (*image).ImageType=NIFTI;
    sprintf((*image).filename,"%s//%s.nii",directory,fname);
    SaveNiftiImage(image, (*image).filename);


    return 0;
}
//========================================================================================
double SaveDifferenceImage(struct Image *image, unsigned char *ActivationImages, int NstudiesA, int NstudiesB, int ImageVoxels, double thresholdA, double thresholdB, char directory[], char fname[])
{
    int voxel;
    int study;
    double ImageNormalise;
    float *Bimage=NULL;
    double MaxDifference=0.0;

    if (!(Bimage=(float *)calloc(ImageVoxels,sizeof(float))))
        goto END;

    memset((*image).img, 0, sizeof(float)*ImageVoxels);

    ImageNormalise=255.0*NstudiesA;
    for (voxel=0; voxel<ImageVoxels; voxel++) {
        for (study=0; study<NstudiesA; study++) {
            (*image).img[voxel] += (float)ActivationImages[voxel + study*ImageVoxels];
        }
        (*image).img[voxel] /= ImageNormalise;
    }


    ImageNormalise=255.0*NstudiesB;
    for (voxel=0; voxel<ImageVoxels; voxel++) {
        for (study=0; study<NstudiesB; study++) {
            Bimage[voxel] += (float)ActivationImages[voxel+(study+NstudiesA)*ImageVoxels];
        }
        Bimage[voxel] /= ImageNormalise;
    }


    for (voxel=0; voxel<ImageVoxels; voxel++) {
        (*image).img[voxel] -= Bimage[voxel];

        if ((*image).img[voxel]<thresholdA && (*image).img[voxel]>-thresholdB)
            (*image).img[voxel]=0.0;

        if (fabs((*image).img[voxel])>MaxDifference)
            MaxDifference=fabs((*image).img[voxel]);
    }

    (*image).offset=0.0;
    (*image).scale=1.0;
    (*image).DataType=DT_FLOAT;
    (*image).ImageType=NIFTI;
    sprintf((*image).filename,"%s//%s.nii",directory,fname);
    SaveNiftiImage(image, (*image).filename);

END:
    if (Bimage)
        free(Bimage);

    return MaxDifference;
}



//========================================================================================
int ActivationAtFociStudy(unsigned char *ActivationsAtFoci, unsigned char *Activations,
                          int FocusVoxelsA[], int NfociA, int FocusVoxelsB[], int NfociB,
                          int NstudiesA, int NstudiesB,
                          int ImageVoxels)
{
    int focus;
    int study;
    int Nstudies=NstudiesA+NstudiesB;

    //foci from study A
    for (focus=0; focus<NfociA; focus++) {
        for (study=0; study<Nstudies; study++) {
            ActivationsAtFoci[focus*Nstudies + study]=Activations[FocusVoxelsA[focus]+study*ImageVoxels];
        }
    }

    //foci from study B
    for (focus=0; focus<NfociB; focus++) {
        for (study=0; study<Nstudies; study++) {
            ActivationsAtFoci[(focus+NfociA)*Nstudies + study]=Activations[FocusVoxelsB[focus]+study*ImageVoxels];
        }
    }

    return 0;
}
//========================================================================================
double ABprediction(unsigned char *ActivationFocusStudy, short int studyA[], short int studyB[],
                    int NfociA, int NfociB, int NstudiesA, int NstudiesB,  int LeaveOutA, int LeaveOutB,
                    double thresholdA, double thresholdB)
{
    int focus;
    struct ProbabilitiesAB P;
    int Ain, Aout, Bin, Bout;
    double score;

    Ain=Aout=0;
    Bin=Bout=0;

    //probability of each focus in A
    for (focus=0; focus<NfociA; focus++) {
        if (studyA[focus]==LeaveOutA) {
            P = ProbabilityCompareFoci(ActivationFocusStudy, focus, NstudiesA, NstudiesB, LeaveOutA, LeaveOutB);
            if (P.A-P.B>thresholdA) {
                Ain++;
            } else if (P.B-P.A>thresholdB) {
                Aout++;
            }

        }
    }


    //probability of each focus in B
    //difference=0.0;
    for (focus=0; focus<NfociB; focus++) {
        if (studyB[focus]==LeaveOutB) {
            P = ProbabilityCompareFoci(ActivationFocusStudy, focus+NfociA, NstudiesA, NstudiesB, LeaveOutA, LeaveOutB);

            if (P.B-P.A>thresholdB) {
                Bin++;
            } else if (P.A-P.B>thresholdA) {
                Bout++;
            }

        }
    }


    if (Ain+Aout+Bin+Bout)
        score=(double)(Ain+Bin)/(Ain+Bin+Aout+Bout);
    else
        score=0.0;

    return score;
}
//========================================================================================
struct ProbabilitiesAB ProbabilityCompareFoci(unsigned char *ActivationFocusStudy, int focus, int NstudiesA, int NstudiesB, int LeaveOutA, int LeaveOutB)
{
    int study;
    int Nstudies=NstudiesA+NstudiesB;
    struct ProbabilitiesAB P;

    P.A=0.0;
    for (study=0; study<NstudiesA; study++) {
        if (study!=LeaveOutA)
            P.A += (double)ActivationFocusStudy[focus*Nstudies + study]/255;
    }
    P.A/=NstudiesA-1;

    P.B=0.0;
    for (study=0; study<NstudiesB; study++) {
        if (study!=LeaveOutB)
            P.B += (double)ActivationFocusStudy[focus*Nstudies + (study+NstudiesA)]/255;
    }
    P.B/=NstudiesB-1;

    return P;
}
//========================================================================================
double StudyActivationImage(struct Image *image, struct Coordinates *C, int study, double width, short int valid[]);
int GetStudyActivationImages(struct Image *image, struct Coordinates *C, unsigned char ActivationImages[], double width, short int valid[])
{
    struct Image CpyOfImage;
    int Nstudies=(*C).Nexperiments;
    int study;
    int ImageVoxels=(*image).X*(*image).Y*(*image).Z/(*image).volumes;
    int voxel;
    double MaxActivation;

    memset(&CpyOfImage,0,sizeof(struct Image));

    if (!(MakeCopyOfImage(image, &CpyOfImage)))
        goto END;

    for (study=0; study<Nstudies; study++) {
        MaxActivation=StudyActivationImage(&CpyOfImage, C, study, width,valid);
        if (MaxActivation>0.0) {

            for (voxel=0; voxel<ImageVoxels; voxel++) {
                CpyOfImage.img[voxel] /= MaxActivation;
                ActivationImages[study*ImageVoxels + voxel] = 255*CpyOfImage.img[voxel];
            }

        }
    }



END:
    ReleaseImage(&CpyOfImage);

    return 0;
}
//===================================================================================
double StudyActivationImage(struct Image *image, struct Coordinates *C, int study, double width, short int valid[])
{
    double KernelMax=0.0;
    int UptoInList, EndOfList;
    int focus;
    int voxel;
    int a,b,c;
    int NeighbourVoxel;
    int xi,yi,zi;
    int Nfoci=(*C).TotalFoci;
    int *VoxelList=NULL;
    int ImageVoxels=(*image).X*(*image).Y*(*image).Z;
    float xf,yf,zf;
    double kernel;
    double dist2,smallestd2;

    if (!(VoxelList=(int *)malloc(sizeof(int)*ImageVoxels)))
        goto END;

    memset((*image).img,0,sizeof(float)*ImageVoxels);

    KernelMax=KernelCBMA(0.0, width, BETA_KERNEL);

    UptoInList=0;
    for (focus=0; focus<Nfoci; focus++) {
        if ((*C).experiment[focus]==study && valid[focus]) {
            voxel = (*C).voxel[focus];
            if (UptoInList<ImageVoxels) {
                (*image).img[voxel] = KernelMax;
                VoxelList[UptoInList] = voxel;
                UptoInList++;
            }
        }
    }


    EndOfList=UptoInList;
    UptoInList=0;
    while (UptoInList<EndOfList) {
        voxel=VoxelList[UptoInList];
        XYZfromVoxelNumber(voxel, &xi, &yi, &zi, (*image).X, (*image).Y, (*image).Z);
        for (c=-1; c<=1; c++) {
            for (b=-1; b<=1; b++) {
                for (a=-1; a<=1; a++) {
                    if ((a||b||c) && InImageRange(xi+a, yi+b, zi+c, (*image).X, (*image).Y, (*image).Z)) {
                        NeighbourVoxel=voxel + a + b*(*image).X + c*(*image).X*(*image).Y;
                        if ((*image).img[NeighbourVoxel]==0.0) {
                            xf=(xi+a)*(*image).dx - (*image).x0;
                            yf=(yi+b)*(*image).dy - (*image).y0;
                            zf=(zi+c)*(*image).dz - (*image).z0;

                            smallestd2=DBL_MAX;
                            for (focus=0; focus<Nfoci; focus++) {
                                if ((*C).experiment[focus]==study && valid[focus]) {
                                    dist2= ((*C).x[focus]-xf)*((*C).x[focus]-xf) +
                                           ((*C).y[focus]-yf)*((*C).y[focus]-yf) +
                                           ((*C).z[focus]-zf)*((*C).z[focus]-zf);
                                    if (dist2<smallestd2) {
                                        smallestd2=dist2;
                                    }
                                }
                            }

                            kernel=KernelCBMA(sqrt(smallestd2), width, BETA_KERNEL);

                            if (EndOfList<ImageVoxels) {
                                if (kernel<=0.0) {
                                    (*image).img[NeighbourVoxel]=-1;
                                } else {
                                    VoxelList[EndOfList]=NeighbourVoxel;
                                    (*image).img[NeighbourVoxel]=kernel;
                                    EndOfList++;
                                }
                            }
                        }
                    }
                }
            }
        }
        UptoInList++;
    }


    for(voxel=0; voxel<ImageVoxels; voxel++) {
        if ((*image).img[voxel]<0.0)
            (*image).img[voxel]=0.0;
    }

END:
    if (VoxelList)
        free(VoxelList);

    return KernelMax;
}



